from pathlib import Path
import hashlib,json,shutil

root=Path(__file__).resolve().parent
repo=root.parents[1]
dest=root/'runtime'
if dest.exists(): raise RuntimeError('Refusing to overwrite staged runtime')
for arm,source in [('flow',repo/'src/AgentLang.Cli/bin/Release/net9.0'),('conventional',repo/'experiments/AgentLang.Conventional.Cli/bin/Release/net9.0')]:
    shutil.copytree(source,dest/arm)
rows=[]
for path in sorted(dest.rglob('*')):
    if path.is_file():
        rows.append({'path':str(path.relative_to(root)),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
broker=repo/'scripts/Start-SubagentTrialHostV2.ps1'
rows.append({'path':str(broker),'bytes':broker.stat().st_size,'sha256':hashlib.sha256(broker.read_bytes()).hexdigest()})
(root/'setup/staged-runtime.json').write_text(json.dumps({'status':'staged, not final frozen trial','files':rows},indent=2))
print(f'Staged {len(rows)-1} runtime files and recorded broker hash.')

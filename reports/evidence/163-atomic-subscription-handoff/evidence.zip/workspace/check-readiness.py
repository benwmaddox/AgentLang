from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
assert not any((root/f'trace-{arm}.jsonl').exists() for arm in ['flow','conventional'])
paths=['control/control-summary-agentlang.json','control/control-summary-agentlang-actor.json',
 'control/control-summary-agentlang-actor-ignore-overlap.json',
 'control/conventional/evidence/run-006/conventional-suite-summary.json',
 'control/conventional/evidence/run-004/conventional-suite-summary.json',
 'control/conventional/evidence/run-005/conventional-suite-summary.json']
proofs=[]
for index,name in enumerate(paths):
    path=root/name
    data=json.loads(path.read_text())
    assert data['caseCount']==33,name
    if index<3:
        arms=data['arms']
        assert all(a['executedCaseCount']==33 and a['setupErrorCount']==0 for a in arms.values()),name
        if index==0:
            assert data['status']=='passed' and arms['composed']['passedCaseCount']==33
            assert all(a['failingCaseIds'] for n,a in arms.items() if n!='composed')
            coverage=data['qualification']['tests']['data']['coverage']
            assert coverage['instructionsCovered']==coverage['instructionsTotal']==25
            assert coverage['branchesCovered']==coverage['branchesTotal']==4
            assert coverage['finiteCoverage']['complete']
            assert data['qualification']['commit']['ok']
        elif index==1:
            assert arms['composed']['passedCaseCount']==33
        else:
            assert len(arms)==1
            assert next(iter(arms.values()))['failingCaseIds']==['third-party-overlap']
        if index>0:
            assert data['targetWordRedefined'] is False
            assert data['definedWordNames']==['handoff.control.scoring-observe']
            assert data['setupFailure'] is None
    else:
        assert data['status']=='pass'
        assert all(a['executedCaseCount']==33 and not a['setupFailure'] for a in data['controls']),name
        if index==3:
            assert len(data['controls'])==7
            assert all(a['status']==('pass' if a['control']=='composed' else 'behavioral-rejection') for a in data['controls'])
        elif index==4:
            assert data['controls'][0]['passedCaseCount']==33
        else:
            assert data['controls'][0]['status']=='behavioral-rejection'
            assert len(data['controls'][0]['failingCaseIds'])==3
    proofs.append({'path':name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
readiness={'actualControlsPassed':True,'promptReviewResolved':True,'participantsDispatched':False,
 'caseCount':33,'proofs':proofs,'review':'setup/pre-dispatch-review.md',
 'limitations':'Single matched pair; prompt-level isolation; orphan-reference robustness separated from public-valid states.'}
target=root/'setup/dispatch-readiness.json'
if target.exists(): raise RuntimeError('Refusing to overwrite readiness')
target.write_text(json.dumps(readiness,indent=2))
print('All runtime controls and saved-target scorer gates verified.')

from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
def load(project):
    store=project/'.agentlang/store'
    current=json.loads((store/'CURRENT').read_text())
    return json.loads((store/'manifests'/(current['manifestHash']+'.json')).read_text())
seed=load(root/'seeds/agentlang-project')
actor=load(root/'actors/flow')
words={row['wordId']:row for row in actor['words']}
revisions={(row['wordId'],row['revision']):row for row in actor['revisions']}
assert all(words.get(row['wordId'])==row for row in seed['words'])
assert all(revisions.get((row['wordId'],row['revision']))==row for row in seed['revisions'])
assert seed['types']==actor['types']
original_ids={row['wordId'] for row in seed['words']}
new=[row for row in actor['words'] if row['wordId'] not in original_ids]
assert len(new)==1 and new[0]['currentName']=='subscription.handoff'
revision=revisions[(new[0]['wordId'],new[0]['currentRevision'])]
assert revision['maturity']=='library'
inventory=json.loads((root/'setup/inventory.json').read_text())
checked=0
prefix='seeds\\agentlang-project\\.agentlang\\store\\objects\\'
for row in inventory['files']:
    if row['path'].startswith(prefix):
        path=root/'actors/flow/.agentlang/store/objects'/row['path'][len(prefix):]
        assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256']
        checked+=1
result={'status':'pass','originalAuthoredWordRows':len(seed['words']),
 'originalRevisions':len(seed['revisions']),'originalTypeRows':len(seed['types']),
 'originalSourceObjectsUnchanged':checked,'newFunctions':['subscription.handoff'],
 'newMaturity':revision['maturity'],'attachedTests':len(revision['tests']),
 'manifestFormatBefore':seed['formatVersion'],'manifestFormatAfter':actor['formatVersion']}
(root/'preservation-flow.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))

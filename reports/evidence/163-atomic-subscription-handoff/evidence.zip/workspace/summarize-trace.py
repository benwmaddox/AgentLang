"""Protocol metrics only: payload bytes are not tokens or model turns."""
from pathlib import Path
import json,sys,datetime

path=Path(sys.argv[1])
rows=[json.loads(line) for line in path.read_text(encoding='utf-8').splitlines()]
starts=[r for r in rows if r['event']=='session-start']
ends=[r for r in rows if r['event']=='session-end']
assert len(starts)==1 and len(ends)==1
exchanges=[r for r in rows if r['event']=='exchange']
assert ends[0]['exchangeCount']==len(exchanges)
operations={}
errors=[]
for r in exchanges:
    operations[r['operation']]=operations.get(r['operation'],0)+1
    response=r.get('response') or {}
    payload=response.get('rawLine')
    if payload:
        parsed=json.loads(payload)
        if parsed.get('ok') is False:
            errors.append({'index':r['index'],'operation':r['operation'],'error':parsed.get('error'),'text':parsed.get('text')})
started=datetime.datetime.fromisoformat(starts[0]['startedUtc'])
finished=datetime.datetime.fromisoformat(ends[0]['finishedUtc'])
summary={'trace':str(path),'brokerExchanges':len(exchanges),'brokerResponseErrors':len(errors),
 'sessionDurationSeconds':(finished-started).total_seconds(),
 'requestPayloadUtf8Bytes':sum(r['request']['payloadUtf8Bytes'] for r in exchanges),
 'responsePayloadUtf8Bytes':sum((r.get('response') or {}).get('payloadUtf8Bytes',0) for r in exchanges),
 'operations':operations,'errors':errors,'terminationKind':ends[0]['terminationKind'],
 'hostExitCode':ends[0]['hostExitCode'],'runtimeExitCode':ends[0]['runtimeExitCode'],
 'limitations':'Protocol bytes are not LLM tokens; broker exchanges are not model turns. Session duration excludes pre-launch handling.'}
print(json.dumps(summary,indent=2))

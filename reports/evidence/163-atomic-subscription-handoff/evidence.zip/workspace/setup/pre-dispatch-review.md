# Pre-dispatch review findings

Independent Luna/max review, before any participants were dispatched.

1. Prompt project paths had not yet been staged. The broker would create an
   absent project empty. Resolved by `stage-actors.py`, which creates both actor
   copies and verifies all inventoried seed files (259 AgentLang, seven F#).
2. The initial independent model did not check missing customer/product after
   valid duplicate/term/period checks, although retained creation rules do. Its
   fixtures all had valid owner references, so bypassing those checks could pass.
   Routed to scorer owner to add orphan-owner cases and model/adapters. Public
   contract is kept broad; it is not narrowed to hide the missing cases.
3. Initial cancellation cases did not combine already-cancelled with a handoff
   before original start. Such a case is needed to distinguish reversed error
   precedence. Routed to scorer owner along with item 2.

Items 2 and 3 are now covered by the expanded 33-case actual-runtime controls:
both composed implementations pass, and all six faulty variants execute and
receive behavioral rejections. Both dedicated saved-submission scorers also
pass a saved correct implementation and reject a saved faulty implementation,
without replacing the target under test.
These findings are about experiment validity, not new participant outcomes.

The F# `Store` has private record fields and no public owner-removal operation,
so ordinary public constructors cannot create orphan owner references. Hidden
reflective fixture construction may exercise those checks for robustness, but
must be disclosed and separated from the common valid-reference case results.
It must not enter the actor project or change the domain API. This is a real
structural difference between the seeds, not evidence of agent reliability.

The conventional seed now includes frozen `Reference/Business.fs` outside its
compiled source list. Broker smoke attempt 003 confirms it is readable; the
public prompt forbids editing it. This corrects source discovery access while
retaining the same executable domain library. Seed inventory preserves both
the initial seven-file inventory and the refreshed eight-file inventory.

Review completed without finding helper-name or hidden-acceptance leakage in
the prompts. Library publication and editing workflows differ intentionally;
the requested behavioral result is shared. Final dispatch still requires the
expanded actual controls and a full pre-dispatch input freeze.

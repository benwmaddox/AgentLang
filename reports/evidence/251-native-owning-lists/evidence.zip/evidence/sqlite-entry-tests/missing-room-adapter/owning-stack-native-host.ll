%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [10 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 6, i32 11, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 4 }, %AlOwningTypeDescriptor { i32 1, i32 27, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 6, i32 28, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 3 }, %AlOwningTypeDescriptor { i32 4, i32 30, i32 0, i32 6, i32 4294967295, i32 4294967295, i32 48, i32 48, i32 0 }, %AlOwningTypeDescriptor { i32 1, i32 37, i32 6, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 39, i32 6, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 8, i32 41, i32 6, i32 2, i32 4294967295, i32 4294967295, i32 16, i32 16, i32 2 }, %AlOwningTypeDescriptor { i32 7, i32 42, i32 8, i32 2, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 2 }, %AlOwningTypeDescriptor { i32 7, i32 43, i32 10, i32 2, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 2 }], align 4
@al_owning_fields = private constant [12 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 2, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 9, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 3, i32 4294967295, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 5, i32 4294967295, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 6, i32 4294967295, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 6, i32 4294967295, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 8, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 1, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 4, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 4294967295, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 6, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 4294967295, i32 8, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 5, ptr @al_owning_types, i32 10, ptr @al_owning_fields, i32 12 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_locate_sum_case(ptr, ptr, i32, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_commit_host_output(ptr, ptr, i32, i32, i32, i32, i32, i32, ptr)
declare i32 @al_host_campfire_rooms_find_for_user_v1(ptr, i64, i64, ptr, i32, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_float_format(ptr, i64, ptr, ptr, i32)
declare i32 @al_owning_ascii_string_write(ptr, i32, i32, ptr, i32, i32, i32)
declare i32 @al_owning_int_format(ptr, i64, ptr, ptr, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal_typed(ptr, ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %provider.context, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %call.arguments.76 = alloca [2 x %AlOwningDescriptor], align 4
  %call.results.97 = alloca [1 x %AlOwningDescriptor], align 4
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 37
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 37, 37
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %descriptor.element.43 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.44 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 0
  %descriptor.value.45 = load i32, ptr %descriptor.field.44, align 4
  %descriptor.field.46 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 1
  %descriptor.value.47 = load i32, ptr %descriptor.field.46, align 4
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 2
  %descriptor.value.49 = load i32, ptr %descriptor.field.48, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 3
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 4
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %argument.type.valid.54 = icmp eq i32 %descriptor.value.45, 27
  br i1 %argument.type.valid.54, label %argument.type.ok.55, label %frame.failure.0
argument.type.ok.55:
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %stack.sub.60 = sub i32 %descriptor.value.53, %descriptor.value.47
  %descriptor.owner.inside.58 = icmp ule i32 %descriptor.value.53, %context.value.57
  %descriptor.offset.inside.59 = icmp ule i32 %descriptor.value.47, %descriptor.value.53
  %descriptor.extent.inside.61 = icmp ule i32 %descriptor.value.49, %stack.sub.60
  %descriptor.payload.inside.62 = icmp ule i32 %descriptor.value.51, %descriptor.value.49
  %descriptor.owner.offset.valid.63 = and i1 %descriptor.owner.inside.58, %descriptor.offset.inside.59
  %descriptor.range.inside.65 = and i1 %descriptor.owner.offset.valid.63, %descriptor.extent.inside.61
  %descriptor.range.valid.64 = and i1 %descriptor.range.inside.65, %descriptor.payload.inside.62
  %descriptor.type.valid.66 = icmp eq i32 27, 27
  %descriptor.valid.67 = and i1 %descriptor.range.valid.64, %descriptor.type.valid.66
  br i1 %descriptor.valid.67, label %descriptor.valid.68, label %descriptor.invalid.69
descriptor.invalid.69:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.68:
  %descriptor.initialized.status.70 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.47, i32 %descriptor.value.49)
  %helper.ok.71 = icmp eq i32 %descriptor.initialized.status.70, 0
  br i1 %helper.ok.71, label %helper.continue.72, label %frame.failure.0
helper.continue.72:
  %step.status.73 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.74 = icmp eq i32 %step.status.73, 0
  br i1 %helper.ok.74, label %helper.continue.75, label %frame.failure.0
helper.continue.75:
  %descriptor.element.77 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.76, i32 0
  %descriptor.field.78 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 0
  store i32 37, ptr %descriptor.field.78, align 4
  %descriptor.field.79 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.79, align 4
  %descriptor.field.80 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.80, align 4
  %descriptor.field.81 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.81, align 4
  %descriptor.field.82 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.82, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 37, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %descriptor.element.87 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.76, i32 1
  %descriptor.field.88 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 0
  store i32 27, ptr %descriptor.field.88, align 4
  %descriptor.field.89 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 1
  store i32 %descriptor.value.47, ptr %descriptor.field.89, align 4
  %descriptor.field.90 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 2
  store i32 %descriptor.value.49, ptr %descriptor.field.90, align 4
  %descriptor.field.91 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 3
  store i32 %descriptor.value.51, ptr %descriptor.field.91, align 4
  %descriptor.field.92 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 4
  store i32 %descriptor.value.53, ptr %descriptor.field.92, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 27, i32 %descriptor.value.47, i32 20, i32 %descriptor.value.51, i32 %descriptor.value.53, i32 %descriptor.value.49)
  %context.field.93 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.94 = load i32, ptr %context.field.93, align 4
  %runtime.ok.95 = icmp eq i32 %context.value.94, 0
  br i1 %runtime.ok.95, label %runtime.continue.96, label %frame.failure.0
runtime.continue.96:
  %callee.status.98 = call i32 @agentlang_word_0000(ptr %ctx, ptr %provider.context, ptr %call.arguments.76, ptr %call.results.97, i32 2)
  %helper.ok.99 = icmp eq i32 %callee.status.98, 0
  br i1 %helper.ok.99, label %helper.continue.100, label %frame.failure.0
helper.continue.100:
  %descriptor.element.101 = getelementptr inbounds %AlOwningDescriptor, ptr %call.results.97, i32 0
  %descriptor.field.102 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.101, i32 0, i32 0
  %descriptor.value.103 = load i32, ptr %descriptor.field.102, align 4
  %descriptor.field.104 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.101, i32 0, i32 1
  %descriptor.value.105 = load i32, ptr %descriptor.field.104, align 4
  %descriptor.field.106 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.101, i32 0, i32 2
  %descriptor.value.107 = load i32, ptr %descriptor.field.106, align 4
  %descriptor.field.108 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.101, i32 0, i32 3
  %descriptor.value.109 = load i32, ptr %descriptor.field.108, align 4
  %descriptor.field.110 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.101, i32 0, i32 4
  %descriptor.value.111 = load i32, ptr %descriptor.field.110, align 4
  %callee.result.type.valid.112 = icmp eq i32 %descriptor.value.103, 41
  br i1 %callee.result.type.valid.112, label %callee.result.type.ok.113, label %frame.failure.0
callee.result.type.ok.113:
  %context.field.114 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.115 = load i32, ptr %context.field.114, align 4
  %stack.sub.118 = sub i32 %descriptor.value.111, %descriptor.value.105
  %descriptor.owner.inside.116 = icmp ule i32 %descriptor.value.111, %context.value.115
  %descriptor.offset.inside.117 = icmp ule i32 %descriptor.value.105, %descriptor.value.111
  %descriptor.extent.inside.119 = icmp ule i32 %descriptor.value.107, %stack.sub.118
  %descriptor.payload.inside.120 = icmp ule i32 %descriptor.value.109, %descriptor.value.107
  %descriptor.owner.offset.valid.121 = and i1 %descriptor.owner.inside.116, %descriptor.offset.inside.117
  %descriptor.range.inside.123 = and i1 %descriptor.owner.offset.valid.121, %descriptor.extent.inside.119
  %descriptor.range.valid.122 = and i1 %descriptor.range.inside.123, %descriptor.payload.inside.120
  %descriptor.type.valid.124 = icmp eq i32 41, 41
  %descriptor.valid.125 = and i1 %descriptor.range.valid.122, %descriptor.type.valid.124
  br i1 %descriptor.valid.125, label %descriptor.valid.126, label %descriptor.invalid.127
descriptor.invalid.127:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.126:
  %descriptor.initialized.status.128 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.105, i32 %descriptor.value.107)
  %helper.ok.129 = icmp eq i32 %descriptor.initialized.status.128, 0
  br i1 %helper.ok.129, label %helper.continue.130, label %frame.failure.0
helper.continue.130:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 41, i32 %descriptor.value.105, i32 20, i32 %descriptor.value.109, i32 %descriptor.value.111, i32 %descriptor.value.107)
  %context.field.131 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.132 = load i32, ptr %context.field.131, align 4
  %runtime.ok.133 = icmp eq i32 %context.value.132, 0
  br i1 %runtime.ok.133, label %runtime.continue.134, label %frame.failure.0
runtime.continue.134:
  %context.field.135 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.136 = load i32, ptr %context.field.135, align 4
  %stack.sub.139 = sub i32 %descriptor.value.111, %descriptor.value.105
  %descriptor.owner.inside.137 = icmp ule i32 %descriptor.value.111, %context.value.136
  %descriptor.offset.inside.138 = icmp ule i32 %descriptor.value.105, %descriptor.value.111
  %descriptor.extent.inside.140 = icmp ule i32 %descriptor.value.107, %stack.sub.139
  %descriptor.payload.inside.141 = icmp ule i32 %descriptor.value.109, %descriptor.value.107
  %descriptor.owner.offset.valid.142 = and i1 %descriptor.owner.inside.137, %descriptor.offset.inside.138
  %descriptor.range.inside.144 = and i1 %descriptor.owner.offset.valid.142, %descriptor.extent.inside.140
  %descriptor.range.valid.143 = and i1 %descriptor.range.inside.144, %descriptor.payload.inside.141
  %descriptor.type.valid.145 = icmp eq i32 41, 41
  %descriptor.valid.146 = and i1 %descriptor.range.valid.143, %descriptor.type.valid.145
  br i1 %descriptor.valid.146, label %descriptor.valid.147, label %descriptor.invalid.148
descriptor.invalid.148:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.147:
  %descriptor.initialized.status.149 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.105, i32 %descriptor.value.107)
  %helper.ok.150 = icmp eq i32 %descriptor.initialized.status.149, 0
  br i1 %helper.ok.150, label %helper.continue.151, label %frame.failure.0
helper.continue.151:
  %descriptor.element.152 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.153 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.152, i32 0, i32 0
  store i32 41, ptr %descriptor.field.153, align 4
  %descriptor.field.154 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.152, i32 0, i32 1
  store i32 %descriptor.value.105, ptr %descriptor.field.154, align 4
  %descriptor.field.155 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.152, i32 0, i32 2
  store i32 %descriptor.value.107, ptr %descriptor.field.155, align 4
  %descriptor.field.156 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.152, i32 0, i32 3
  store i32 %descriptor.value.109, ptr %descriptor.field.156, align 4
  %descriptor.field.157 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.152, i32 0, i32 4
  store i32 %descriptor.value.111, ptr %descriptor.field.157, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 41, i32 %descriptor.value.105, i32 20, i32 %descriptor.value.109, i32 %descriptor.value.111, i32 %descriptor.value.107)
  %context.field.158 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.159 = load i32, ptr %context.field.158, align 4
  %runtime.ok.160 = icmp eq i32 %context.value.159, 0
  br i1 %runtime.ok.160, label %runtime.continue.161, label %frame.failure.0
runtime.continue.161:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.162 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.163 = load i32, ptr %context.field.162, align 4
  %context.field.164 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.165 = load i32, ptr %context.field.164, align 4
  %context.field.166 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.167 = load i32, ptr %context.field.166, align 4
  %stack.offset.168 = add i32 %context.value.5, %context.value.7
  %stack.offset.169 = add i32 %context.value.163, %context.value.165
  %stack.sub.170 = sub i32 %stack.offset.168, %stack.offset.169
  %stack.sub.171 = sub i32 %context.value.7, %context.value.165
  %stack.sub.172 = sub i32 %context.value.167, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.170, i32 %stack.sub.171)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.172)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, ptr %provider.context, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %local.active.2 = alloca i1, align 1
  %local.offset.3 = alloca i32, align 4
  %local.extent.4 = alloca i32, align 4
  %local.payload.5 = alloca i32, align 4
  %local.owner.end.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  %local.active.8 = alloca i1, align 1
  %local.offset.9 = alloca i32, align 4
  %local.extent.10 = alloca i32, align 4
  %local.payload.11 = alloca i32, align 4
  %local.owner.end.12 = alloca i32, align 4
  %local.type.13 = alloca i32, align 4
  %call.arguments.410 = alloca [2 x %AlOwningDescriptor], align 4
  %call.results.431 = alloca [1 x %AlOwningDescriptor], align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  %context.field.14 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.15 = load i32, ptr %context.field.14, align 4
  %context.field.16 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.17 = load i32, ptr %context.field.16, align 4
  %context.field.18 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.19 = load i32, ptr %context.field.18, align 4
  %context.field.20 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.21 = load i32, ptr %context.field.20, align 4
  %frame.entered.22 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.23 = icmp eq i32 %frame.entered.22, 0
  br i1 %frame.enter.ok.23, label %frame.enter.continue.24, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.24:
  %descriptor.element.25 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.26 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 0
  %descriptor.value.27 = load i32, ptr %descriptor.field.26, align 4
  %descriptor.field.28 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 1
  %descriptor.value.29 = load i32, ptr %descriptor.field.28, align 4
  %descriptor.field.30 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 2
  %descriptor.value.31 = load i32, ptr %descriptor.field.30, align 4
  %descriptor.field.32 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 3
  %descriptor.value.33 = load i32, ptr %descriptor.field.32, align 4
  %descriptor.field.34 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 4
  %descriptor.value.35 = load i32, ptr %descriptor.field.34, align 4
  %argument.type.valid.36 = icmp eq i32 %descriptor.value.27, 37
  br i1 %argument.type.valid.36, label %argument.type.ok.37, label %frame.failure.0
argument.type.ok.37:
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %stack.sub.42 = sub i32 %descriptor.value.35, %descriptor.value.29
  %descriptor.owner.inside.40 = icmp ule i32 %descriptor.value.35, %context.value.39
  %descriptor.offset.inside.41 = icmp ule i32 %descriptor.value.29, %descriptor.value.35
  %descriptor.extent.inside.43 = icmp ule i32 %descriptor.value.31, %stack.sub.42
  %descriptor.payload.inside.44 = icmp ule i32 %descriptor.value.33, %descriptor.value.31
  %descriptor.owner.offset.valid.45 = and i1 %descriptor.owner.inside.40, %descriptor.offset.inside.41
  %descriptor.range.inside.47 = and i1 %descriptor.owner.offset.valid.45, %descriptor.extent.inside.43
  %descriptor.range.valid.46 = and i1 %descriptor.range.inside.47, %descriptor.payload.inside.44
  %descriptor.type.valid.48 = icmp eq i32 37, 37
  %descriptor.valid.49 = and i1 %descriptor.range.valid.46, %descriptor.type.valid.48
  br i1 %descriptor.valid.49, label %descriptor.valid.50, label %descriptor.invalid.51
descriptor.invalid.51:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.50:
  %descriptor.initialized.status.52 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.29, i32 %descriptor.value.31)
  %helper.ok.53 = icmp eq i32 %descriptor.initialized.status.52, 0
  br i1 %helper.ok.53, label %helper.continue.54, label %frame.failure.0
helper.continue.54:
  %descriptor.element.55 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.56 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.55, i32 0, i32 0
  %descriptor.value.57 = load i32, ptr %descriptor.field.56, align 4
  %descriptor.field.58 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.55, i32 0, i32 1
  %descriptor.value.59 = load i32, ptr %descriptor.field.58, align 4
  %descriptor.field.60 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.55, i32 0, i32 2
  %descriptor.value.61 = load i32, ptr %descriptor.field.60, align 4
  %descriptor.field.62 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.55, i32 0, i32 3
  %descriptor.value.63 = load i32, ptr %descriptor.field.62, align 4
  %descriptor.field.64 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.55, i32 0, i32 4
  %descriptor.value.65 = load i32, ptr %descriptor.field.64, align 4
  %argument.type.valid.66 = icmp eq i32 %descriptor.value.57, 27
  br i1 %argument.type.valid.66, label %argument.type.ok.67, label %frame.failure.0
argument.type.ok.67:
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %stack.sub.72 = sub i32 %descriptor.value.65, %descriptor.value.59
  %descriptor.owner.inside.70 = icmp ule i32 %descriptor.value.65, %context.value.69
  %descriptor.offset.inside.71 = icmp ule i32 %descriptor.value.59, %descriptor.value.65
  %descriptor.extent.inside.73 = icmp ule i32 %descriptor.value.61, %stack.sub.72
  %descriptor.payload.inside.74 = icmp ule i32 %descriptor.value.63, %descriptor.value.61
  %descriptor.owner.offset.valid.75 = and i1 %descriptor.owner.inside.70, %descriptor.offset.inside.71
  %descriptor.range.inside.77 = and i1 %descriptor.owner.offset.valid.75, %descriptor.extent.inside.73
  %descriptor.range.valid.76 = and i1 %descriptor.range.inside.77, %descriptor.payload.inside.74
  %descriptor.type.valid.78 = icmp eq i32 27, 27
  %descriptor.valid.79 = and i1 %descriptor.range.valid.76, %descriptor.type.valid.78
  br i1 %descriptor.valid.79, label %descriptor.valid.80, label %descriptor.invalid.81
descriptor.invalid.81:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.80:
  %descriptor.initialized.status.82 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.59, i32 %descriptor.value.61)
  %helper.ok.83 = icmp eq i32 %descriptor.initialized.status.82, 0
  br i1 %helper.ok.83, label %helper.continue.84, label %frame.failure.0
helper.continue.84:
  %step.status.85 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.86 = icmp eq i32 %step.status.85, 0
  br i1 %helper.ok.86, label %helper.continue.87, label %frame.failure.0
helper.continue.87:
  store i1 true, ptr %local.active.2, align 1
  store i32 %descriptor.value.59, ptr %local.offset.3, align 4
  store i32 %descriptor.value.61, ptr %local.extent.4, align 4
  store i32 %descriptor.value.63, ptr %local.payload.5, align 4
  store i32 %descriptor.value.65, ptr %local.owner.end.6, align 4
  store i32 27, ptr %local.type.7, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 27, i32 %descriptor.value.59, i32 20, i32 %descriptor.value.63, i32 %descriptor.value.65, i32 %descriptor.value.61)
  %context.field.88 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.89 = load i32, ptr %context.field.88, align 4
  %runtime.ok.90 = icmp eq i32 %context.value.89, 0
  br i1 %runtime.ok.90, label %runtime.continue.91, label %frame.failure.0
runtime.continue.91:
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %stack.sub.96 = sub i32 %descriptor.value.35, %descriptor.value.29
  %descriptor.owner.inside.94 = icmp ule i32 %descriptor.value.35, %context.value.93
  %descriptor.offset.inside.95 = icmp ule i32 %descriptor.value.29, %descriptor.value.35
  %descriptor.extent.inside.97 = icmp ule i32 %descriptor.value.31, %stack.sub.96
  %descriptor.payload.inside.98 = icmp ule i32 %descriptor.value.33, %descriptor.value.31
  %descriptor.owner.offset.valid.99 = and i1 %descriptor.owner.inside.94, %descriptor.offset.inside.95
  %descriptor.range.inside.101 = and i1 %descriptor.owner.offset.valid.99, %descriptor.extent.inside.97
  %descriptor.range.valid.100 = and i1 %descriptor.range.inside.101, %descriptor.payload.inside.98
  %descriptor.type.valid.102 = icmp eq i32 37, 37
  %descriptor.valid.103 = and i1 %descriptor.range.valid.100, %descriptor.type.valid.102
  br i1 %descriptor.valid.103, label %descriptor.valid.104, label %descriptor.invalid.105
descriptor.invalid.105:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.104:
  %descriptor.initialized.status.106 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.29, i32 %descriptor.value.31)
  %helper.ok.107 = icmp eq i32 %descriptor.initialized.status.106, 0
  br i1 %helper.ok.107, label %helper.continue.108, label %frame.failure.0
helper.continue.108:
  %local.is.active.109 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.109, label %local.descriptor.active.110, label %local.descriptor.inactive.111
local.descriptor.active.110:
  %local.check.offset.113 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.114 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.115 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.116 = load i32, ptr %local.owner.end.6, align 4
  %context.field.117 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.118 = load i32, ptr %context.field.117, align 4
  %stack.sub.121 = sub i32 %local.check.owner.end.116, %local.check.offset.113
  %descriptor.owner.inside.119 = icmp ule i32 %local.check.owner.end.116, %context.value.118
  %descriptor.offset.inside.120 = icmp ule i32 %local.check.offset.113, %local.check.owner.end.116
  %descriptor.extent.inside.122 = icmp ule i32 %local.check.extent.114, %stack.sub.121
  %descriptor.payload.inside.123 = icmp ule i32 %local.check.payload.115, %local.check.extent.114
  %descriptor.owner.offset.valid.124 = and i1 %descriptor.owner.inside.119, %descriptor.offset.inside.120
  %descriptor.range.inside.126 = and i1 %descriptor.owner.offset.valid.124, %descriptor.extent.inside.122
  %descriptor.range.valid.125 = and i1 %descriptor.range.inside.126, %descriptor.payload.inside.123
  br i1 %descriptor.range.valid.125, label %descriptor.valid.127, label %descriptor.invalid.128
descriptor.invalid.128:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.127:
  %descriptor.initialized.status.129 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.113, i32 %local.check.extent.114)
  %helper.ok.130 = icmp eq i32 %descriptor.initialized.status.129, 0
  br i1 %helper.ok.130, label %helper.continue.131, label %frame.failure.0
helper.continue.131:
  br label %local.descriptor.checked.112
local.descriptor.inactive.111:
  br label %local.descriptor.checked.112
local.descriptor.checked.112:
  %local.is.active.132 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.132, label %local.descriptor.active.133, label %local.descriptor.inactive.134
local.descriptor.active.133:
  %local.check.offset.136 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.137 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.138 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.139 = load i32, ptr %local.owner.end.12, align 4
  %context.field.140 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.141 = load i32, ptr %context.field.140, align 4
  %stack.sub.144 = sub i32 %local.check.owner.end.139, %local.check.offset.136
  %descriptor.owner.inside.142 = icmp ule i32 %local.check.owner.end.139, %context.value.141
  %descriptor.offset.inside.143 = icmp ule i32 %local.check.offset.136, %local.check.owner.end.139
  %descriptor.extent.inside.145 = icmp ule i32 %local.check.extent.137, %stack.sub.144
  %descriptor.payload.inside.146 = icmp ule i32 %local.check.payload.138, %local.check.extent.137
  %descriptor.owner.offset.valid.147 = and i1 %descriptor.owner.inside.142, %descriptor.offset.inside.143
  %descriptor.range.inside.149 = and i1 %descriptor.owner.offset.valid.147, %descriptor.extent.inside.145
  %descriptor.range.valid.148 = and i1 %descriptor.range.inside.149, %descriptor.payload.inside.146
  br i1 %descriptor.range.valid.148, label %descriptor.valid.150, label %descriptor.invalid.151
descriptor.invalid.151:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.150:
  %descriptor.initialized.status.152 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.136, i32 %local.check.extent.137)
  %helper.ok.153 = icmp eq i32 %descriptor.initialized.status.152, 0
  br i1 %helper.ok.153, label %helper.continue.154, label %frame.failure.0
helper.continue.154:
  br label %local.descriptor.checked.135
local.descriptor.inactive.134:
  br label %local.descriptor.checked.135
local.descriptor.checked.135:
  %step.status.155 = call i32 @al_owning_charge_step(ptr %ctx, i32 4)
  %helper.ok.156 = icmp eq i32 %step.status.155, 0
  br i1 %helper.ok.156, label %helper.continue.157, label %frame.failure.0
helper.continue.157:
  store i1 true, ptr %local.active.8, align 1
  store i32 %descriptor.value.29, ptr %local.offset.9, align 4
  store i32 %descriptor.value.31, ptr %local.extent.10, align 4
  store i32 %descriptor.value.33, ptr %local.payload.11, align 4
  store i32 %descriptor.value.35, ptr %local.owner.end.12, align 4
  store i32 37, ptr %local.type.13, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 37, i32 %descriptor.value.29, i32 20, i32 %descriptor.value.33, i32 %descriptor.value.35, i32 %descriptor.value.31)
  %context.field.158 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.159 = load i32, ptr %context.field.158, align 4
  %runtime.ok.160 = icmp eq i32 %context.value.159, 0
  br i1 %runtime.ok.160, label %runtime.continue.161, label %frame.failure.0
runtime.continue.161:
  %local.is.active.162 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.162, label %local.descriptor.active.163, label %local.descriptor.inactive.164
local.descriptor.active.163:
  %local.check.offset.166 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.167 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.168 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.169 = load i32, ptr %local.owner.end.6, align 4
  %context.field.170 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.171 = load i32, ptr %context.field.170, align 4
  %stack.sub.174 = sub i32 %local.check.owner.end.169, %local.check.offset.166
  %descriptor.owner.inside.172 = icmp ule i32 %local.check.owner.end.169, %context.value.171
  %descriptor.offset.inside.173 = icmp ule i32 %local.check.offset.166, %local.check.owner.end.169
  %descriptor.extent.inside.175 = icmp ule i32 %local.check.extent.167, %stack.sub.174
  %descriptor.payload.inside.176 = icmp ule i32 %local.check.payload.168, %local.check.extent.167
  %descriptor.owner.offset.valid.177 = and i1 %descriptor.owner.inside.172, %descriptor.offset.inside.173
  %descriptor.range.inside.179 = and i1 %descriptor.owner.offset.valid.177, %descriptor.extent.inside.175
  %descriptor.range.valid.178 = and i1 %descriptor.range.inside.179, %descriptor.payload.inside.176
  br i1 %descriptor.range.valid.178, label %descriptor.valid.180, label %descriptor.invalid.181
descriptor.invalid.181:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.180:
  %descriptor.initialized.status.182 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.166, i32 %local.check.extent.167)
  %helper.ok.183 = icmp eq i32 %descriptor.initialized.status.182, 0
  br i1 %helper.ok.183, label %helper.continue.184, label %frame.failure.0
helper.continue.184:
  br label %local.descriptor.checked.165
local.descriptor.inactive.164:
  br label %local.descriptor.checked.165
local.descriptor.checked.165:
  %local.is.active.185 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.185, label %local.descriptor.active.186, label %local.descriptor.inactive.187
local.descriptor.active.186:
  %local.check.offset.189 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.190 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.191 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.192 = load i32, ptr %local.owner.end.12, align 4
  %context.field.193 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.194 = load i32, ptr %context.field.193, align 4
  %stack.sub.197 = sub i32 %local.check.owner.end.192, %local.check.offset.189
  %descriptor.owner.inside.195 = icmp ule i32 %local.check.owner.end.192, %context.value.194
  %descriptor.offset.inside.196 = icmp ule i32 %local.check.offset.189, %local.check.owner.end.192
  %descriptor.extent.inside.198 = icmp ule i32 %local.check.extent.190, %stack.sub.197
  %descriptor.payload.inside.199 = icmp ule i32 %local.check.payload.191, %local.check.extent.190
  %descriptor.owner.offset.valid.200 = and i1 %descriptor.owner.inside.195, %descriptor.offset.inside.196
  %descriptor.range.inside.202 = and i1 %descriptor.owner.offset.valid.200, %descriptor.extent.inside.198
  %descriptor.range.valid.201 = and i1 %descriptor.range.inside.202, %descriptor.payload.inside.199
  br i1 %descriptor.range.valid.201, label %descriptor.valid.203, label %descriptor.invalid.204
descriptor.invalid.204:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.203:
  %descriptor.initialized.status.205 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.189, i32 %local.check.extent.190)
  %helper.ok.206 = icmp eq i32 %descriptor.initialized.status.205, 0
  br i1 %helper.ok.206, label %helper.continue.207, label %frame.failure.0
helper.continue.207:
  br label %local.descriptor.checked.188
local.descriptor.inactive.187:
  br label %local.descriptor.checked.188
local.descriptor.checked.188:
  %step.status.208 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.209 = icmp eq i32 %step.status.208, 0
  br i1 %helper.ok.209, label %helper.continue.210, label %frame.failure.0
helper.continue.210:
  %local.resolved.offset.211 = load i32, ptr %local.offset.9, align 4
  %local.resolved.extent.212 = load i32, ptr %local.extent.10, align 4
  %local.resolved.payload.213 = load i32, ptr %local.payload.11, align 4
  %local.resolved.owner.end.214 = load i32, ptr %local.owner.end.12, align 4
  %context.field.215 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.216 = load i32, ptr %context.field.215, align 4
  %stack.sub.219 = sub i32 %local.resolved.owner.end.214, %local.resolved.offset.211
  %descriptor.owner.inside.217 = icmp ule i32 %local.resolved.owner.end.214, %context.value.216
  %descriptor.offset.inside.218 = icmp ule i32 %local.resolved.offset.211, %local.resolved.owner.end.214
  %descriptor.extent.inside.220 = icmp ule i32 %local.resolved.extent.212, %stack.sub.219
  %descriptor.payload.inside.221 = icmp ule i32 %local.resolved.payload.213, %local.resolved.extent.212
  %descriptor.owner.offset.valid.222 = and i1 %descriptor.owner.inside.217, %descriptor.offset.inside.218
  %descriptor.range.inside.224 = and i1 %descriptor.owner.offset.valid.222, %descriptor.extent.inside.220
  %descriptor.range.valid.223 = and i1 %descriptor.range.inside.224, %descriptor.payload.inside.221
  %descriptor.type.valid.225 = icmp eq i32 37, 37
  %descriptor.valid.226 = and i1 %descriptor.range.valid.223, %descriptor.type.valid.225
  br i1 %descriptor.valid.226, label %descriptor.valid.227, label %descriptor.invalid.228
descriptor.invalid.228:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.227:
  %descriptor.initialized.status.229 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.211, i32 %local.resolved.extent.212)
  %helper.ok.230 = icmp eq i32 %descriptor.initialized.status.229, 0
  br i1 %helper.ok.230, label %helper.continue.231, label %frame.failure.0
helper.continue.231:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 37, i32 %local.resolved.offset.211, i32 20, i32 %local.resolved.payload.213, i32 %local.resolved.owner.end.214, i32 %local.resolved.extent.212)
  %context.field.232 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.233 = load i32, ptr %context.field.232, align 4
  %runtime.ok.234 = icmp eq i32 %context.value.233, 0
  br i1 %runtime.ok.234, label %runtime.continue.235, label %frame.failure.0
runtime.continue.235:
  %context.field.236 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.237 = load i32, ptr %context.field.236, align 4
  %stack.sub.240 = sub i32 %local.resolved.owner.end.214, %local.resolved.offset.211
  %descriptor.owner.inside.238 = icmp ule i32 %local.resolved.owner.end.214, %context.value.237
  %descriptor.offset.inside.239 = icmp ule i32 %local.resolved.offset.211, %local.resolved.owner.end.214
  %descriptor.extent.inside.241 = icmp ule i32 %local.resolved.extent.212, %stack.sub.240
  %descriptor.payload.inside.242 = icmp ule i32 %local.resolved.payload.213, %local.resolved.extent.212
  %descriptor.owner.offset.valid.243 = and i1 %descriptor.owner.inside.238, %descriptor.offset.inside.239
  %descriptor.range.inside.245 = and i1 %descriptor.owner.offset.valid.243, %descriptor.extent.inside.241
  %descriptor.range.valid.244 = and i1 %descriptor.range.inside.245, %descriptor.payload.inside.242
  %descriptor.type.valid.246 = icmp eq i32 37, 37
  %descriptor.valid.247 = and i1 %descriptor.range.valid.244, %descriptor.type.valid.246
  br i1 %descriptor.valid.247, label %descriptor.valid.248, label %descriptor.invalid.249
descriptor.invalid.249:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.248:
  %descriptor.initialized.status.250 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.211, i32 %local.resolved.extent.212)
  %helper.ok.251 = icmp eq i32 %descriptor.initialized.status.250, 0
  br i1 %helper.ok.251, label %helper.continue.252, label %frame.failure.0
helper.continue.252:
  %local.is.active.253 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.253, label %local.descriptor.active.254, label %local.descriptor.inactive.255
local.descriptor.active.254:
  %local.check.offset.257 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.258 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.259 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.260 = load i32, ptr %local.owner.end.6, align 4
  %context.field.261 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.262 = load i32, ptr %context.field.261, align 4
  %stack.sub.265 = sub i32 %local.check.owner.end.260, %local.check.offset.257
  %descriptor.owner.inside.263 = icmp ule i32 %local.check.owner.end.260, %context.value.262
  %descriptor.offset.inside.264 = icmp ule i32 %local.check.offset.257, %local.check.owner.end.260
  %descriptor.extent.inside.266 = icmp ule i32 %local.check.extent.258, %stack.sub.265
  %descriptor.payload.inside.267 = icmp ule i32 %local.check.payload.259, %local.check.extent.258
  %descriptor.owner.offset.valid.268 = and i1 %descriptor.owner.inside.263, %descriptor.offset.inside.264
  %descriptor.range.inside.270 = and i1 %descriptor.owner.offset.valid.268, %descriptor.extent.inside.266
  %descriptor.range.valid.269 = and i1 %descriptor.range.inside.270, %descriptor.payload.inside.267
  br i1 %descriptor.range.valid.269, label %descriptor.valid.271, label %descriptor.invalid.272
descriptor.invalid.272:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.271:
  %descriptor.initialized.status.273 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.257, i32 %local.check.extent.258)
  %helper.ok.274 = icmp eq i32 %descriptor.initialized.status.273, 0
  br i1 %helper.ok.274, label %helper.continue.275, label %frame.failure.0
helper.continue.275:
  br label %local.descriptor.checked.256
local.descriptor.inactive.255:
  br label %local.descriptor.checked.256
local.descriptor.checked.256:
  %local.is.active.276 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.276, label %local.descriptor.active.277, label %local.descriptor.inactive.278
local.descriptor.active.277:
  %local.check.offset.280 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.281 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.282 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.283 = load i32, ptr %local.owner.end.12, align 4
  %context.field.284 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.285 = load i32, ptr %context.field.284, align 4
  %stack.sub.288 = sub i32 %local.check.owner.end.283, %local.check.offset.280
  %descriptor.owner.inside.286 = icmp ule i32 %local.check.owner.end.283, %context.value.285
  %descriptor.offset.inside.287 = icmp ule i32 %local.check.offset.280, %local.check.owner.end.283
  %descriptor.extent.inside.289 = icmp ule i32 %local.check.extent.281, %stack.sub.288
  %descriptor.payload.inside.290 = icmp ule i32 %local.check.payload.282, %local.check.extent.281
  %descriptor.owner.offset.valid.291 = and i1 %descriptor.owner.inside.286, %descriptor.offset.inside.287
  %descriptor.range.inside.293 = and i1 %descriptor.owner.offset.valid.291, %descriptor.extent.inside.289
  %descriptor.range.valid.292 = and i1 %descriptor.range.inside.293, %descriptor.payload.inside.290
  br i1 %descriptor.range.valid.292, label %descriptor.valid.294, label %descriptor.invalid.295
descriptor.invalid.295:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.294:
  %descriptor.initialized.status.296 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.280, i32 %local.check.extent.281)
  %helper.ok.297 = icmp eq i32 %descriptor.initialized.status.296, 0
  br i1 %helper.ok.297, label %helper.continue.298, label %frame.failure.0
helper.continue.298:
  br label %local.descriptor.checked.279
local.descriptor.inactive.278:
  br label %local.descriptor.checked.279
local.descriptor.checked.279:
  %step.status.299 = call i32 @al_owning_charge_step(ptr %ctx, i32 6)
  %helper.ok.300 = icmp eq i32 %step.status.299, 0
  br i1 %helper.ok.300, label %helper.continue.301, label %frame.failure.0
helper.continue.301:
  %local.resolved.offset.302 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.303 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.304 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.305 = load i32, ptr %local.owner.end.6, align 4
  %context.field.306 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.307 = load i32, ptr %context.field.306, align 4
  %stack.sub.310 = sub i32 %local.resolved.owner.end.305, %local.resolved.offset.302
  %descriptor.owner.inside.308 = icmp ule i32 %local.resolved.owner.end.305, %context.value.307
  %descriptor.offset.inside.309 = icmp ule i32 %local.resolved.offset.302, %local.resolved.owner.end.305
  %descriptor.extent.inside.311 = icmp ule i32 %local.resolved.extent.303, %stack.sub.310
  %descriptor.payload.inside.312 = icmp ule i32 %local.resolved.payload.304, %local.resolved.extent.303
  %descriptor.owner.offset.valid.313 = and i1 %descriptor.owner.inside.308, %descriptor.offset.inside.309
  %descriptor.range.inside.315 = and i1 %descriptor.owner.offset.valid.313, %descriptor.extent.inside.311
  %descriptor.range.valid.314 = and i1 %descriptor.range.inside.315, %descriptor.payload.inside.312
  %descriptor.type.valid.316 = icmp eq i32 27, 27
  %descriptor.valid.317 = and i1 %descriptor.range.valid.314, %descriptor.type.valid.316
  br i1 %descriptor.valid.317, label %descriptor.valid.318, label %descriptor.invalid.319
descriptor.invalid.319:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.318:
  %descriptor.initialized.status.320 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.302, i32 %local.resolved.extent.303)
  %helper.ok.321 = icmp eq i32 %descriptor.initialized.status.320, 0
  br i1 %helper.ok.321, label %helper.continue.322, label %frame.failure.0
helper.continue.322:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 27, i32 %local.resolved.offset.302, i32 20, i32 %local.resolved.payload.304, i32 %local.resolved.owner.end.305, i32 %local.resolved.extent.303)
  %context.field.323 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.324 = load i32, ptr %context.field.323, align 4
  %runtime.ok.325 = icmp eq i32 %context.value.324, 0
  br i1 %runtime.ok.325, label %runtime.continue.326, label %frame.failure.0
runtime.continue.326:
  %context.field.327 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.328 = load i32, ptr %context.field.327, align 4
  %stack.sub.331 = sub i32 %local.resolved.owner.end.214, %local.resolved.offset.211
  %descriptor.owner.inside.329 = icmp ule i32 %local.resolved.owner.end.214, %context.value.328
  %descriptor.offset.inside.330 = icmp ule i32 %local.resolved.offset.211, %local.resolved.owner.end.214
  %descriptor.extent.inside.332 = icmp ule i32 %local.resolved.extent.212, %stack.sub.331
  %descriptor.payload.inside.333 = icmp ule i32 %local.resolved.payload.213, %local.resolved.extent.212
  %descriptor.owner.offset.valid.334 = and i1 %descriptor.owner.inside.329, %descriptor.offset.inside.330
  %descriptor.range.inside.336 = and i1 %descriptor.owner.offset.valid.334, %descriptor.extent.inside.332
  %descriptor.range.valid.335 = and i1 %descriptor.range.inside.336, %descriptor.payload.inside.333
  %descriptor.type.valid.337 = icmp eq i32 37, 37
  %descriptor.valid.338 = and i1 %descriptor.range.valid.335, %descriptor.type.valid.337
  br i1 %descriptor.valid.338, label %descriptor.valid.339, label %descriptor.invalid.340
descriptor.invalid.340:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.339:
  %descriptor.initialized.status.341 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.211, i32 %local.resolved.extent.212)
  %helper.ok.342 = icmp eq i32 %descriptor.initialized.status.341, 0
  br i1 %helper.ok.342, label %helper.continue.343, label %frame.failure.0
helper.continue.343:
  %context.field.344 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.345 = load i32, ptr %context.field.344, align 4
  %stack.sub.348 = sub i32 %local.resolved.owner.end.305, %local.resolved.offset.302
  %descriptor.owner.inside.346 = icmp ule i32 %local.resolved.owner.end.305, %context.value.345
  %descriptor.offset.inside.347 = icmp ule i32 %local.resolved.offset.302, %local.resolved.owner.end.305
  %descriptor.extent.inside.349 = icmp ule i32 %local.resolved.extent.303, %stack.sub.348
  %descriptor.payload.inside.350 = icmp ule i32 %local.resolved.payload.304, %local.resolved.extent.303
  %descriptor.owner.offset.valid.351 = and i1 %descriptor.owner.inside.346, %descriptor.offset.inside.347
  %descriptor.range.inside.353 = and i1 %descriptor.owner.offset.valid.351, %descriptor.extent.inside.349
  %descriptor.range.valid.352 = and i1 %descriptor.range.inside.353, %descriptor.payload.inside.350
  %descriptor.type.valid.354 = icmp eq i32 27, 27
  %descriptor.valid.355 = and i1 %descriptor.range.valid.352, %descriptor.type.valid.354
  br i1 %descriptor.valid.355, label %descriptor.valid.356, label %descriptor.invalid.357
descriptor.invalid.357:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.356:
  %descriptor.initialized.status.358 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.302, i32 %local.resolved.extent.303)
  %helper.ok.359 = icmp eq i32 %descriptor.initialized.status.358, 0
  br i1 %helper.ok.359, label %helper.continue.360, label %frame.failure.0
helper.continue.360:
  %local.is.active.361 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.361, label %local.descriptor.active.362, label %local.descriptor.inactive.363
local.descriptor.active.362:
  %local.check.offset.365 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.366 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.367 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.368 = load i32, ptr %local.owner.end.6, align 4
  %context.field.369 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.370 = load i32, ptr %context.field.369, align 4
  %stack.sub.373 = sub i32 %local.check.owner.end.368, %local.check.offset.365
  %descriptor.owner.inside.371 = icmp ule i32 %local.check.owner.end.368, %context.value.370
  %descriptor.offset.inside.372 = icmp ule i32 %local.check.offset.365, %local.check.owner.end.368
  %descriptor.extent.inside.374 = icmp ule i32 %local.check.extent.366, %stack.sub.373
  %descriptor.payload.inside.375 = icmp ule i32 %local.check.payload.367, %local.check.extent.366
  %descriptor.owner.offset.valid.376 = and i1 %descriptor.owner.inside.371, %descriptor.offset.inside.372
  %descriptor.range.inside.378 = and i1 %descriptor.owner.offset.valid.376, %descriptor.extent.inside.374
  %descriptor.range.valid.377 = and i1 %descriptor.range.inside.378, %descriptor.payload.inside.375
  br i1 %descriptor.range.valid.377, label %descriptor.valid.379, label %descriptor.invalid.380
descriptor.invalid.380:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.379:
  %descriptor.initialized.status.381 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.365, i32 %local.check.extent.366)
  %helper.ok.382 = icmp eq i32 %descriptor.initialized.status.381, 0
  br i1 %helper.ok.382, label %helper.continue.383, label %frame.failure.0
helper.continue.383:
  br label %local.descriptor.checked.364
local.descriptor.inactive.363:
  br label %local.descriptor.checked.364
local.descriptor.checked.364:
  %local.is.active.384 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.384, label %local.descriptor.active.385, label %local.descriptor.inactive.386
local.descriptor.active.385:
  %local.check.offset.388 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.389 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.390 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.391 = load i32, ptr %local.owner.end.12, align 4
  %context.field.392 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.393 = load i32, ptr %context.field.392, align 4
  %stack.sub.396 = sub i32 %local.check.owner.end.391, %local.check.offset.388
  %descriptor.owner.inside.394 = icmp ule i32 %local.check.owner.end.391, %context.value.393
  %descriptor.offset.inside.395 = icmp ule i32 %local.check.offset.388, %local.check.owner.end.391
  %descriptor.extent.inside.397 = icmp ule i32 %local.check.extent.389, %stack.sub.396
  %descriptor.payload.inside.398 = icmp ule i32 %local.check.payload.390, %local.check.extent.389
  %descriptor.owner.offset.valid.399 = and i1 %descriptor.owner.inside.394, %descriptor.offset.inside.395
  %descriptor.range.inside.401 = and i1 %descriptor.owner.offset.valid.399, %descriptor.extent.inside.397
  %descriptor.range.valid.400 = and i1 %descriptor.range.inside.401, %descriptor.payload.inside.398
  br i1 %descriptor.range.valid.400, label %descriptor.valid.402, label %descriptor.invalid.403
descriptor.invalid.403:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.402:
  %descriptor.initialized.status.404 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.388, i32 %local.check.extent.389)
  %helper.ok.405 = icmp eq i32 %descriptor.initialized.status.404, 0
  br i1 %helper.ok.405, label %helper.continue.406, label %frame.failure.0
helper.continue.406:
  br label %local.descriptor.checked.387
local.descriptor.inactive.386:
  br label %local.descriptor.checked.387
local.descriptor.checked.387:
  %step.status.407 = call i32 @al_owning_charge_step(ptr %ctx, i32 7)
  %helper.ok.408 = icmp eq i32 %step.status.407, 0
  br i1 %helper.ok.408, label %helper.continue.409, label %frame.failure.0
helper.continue.409:
  %descriptor.element.411 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.410, i32 0
  %descriptor.field.412 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.411, i32 0, i32 0
  store i32 37, ptr %descriptor.field.412, align 4
  %descriptor.field.413 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.411, i32 0, i32 1
  store i32 %local.resolved.offset.211, ptr %descriptor.field.413, align 4
  %descriptor.field.414 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.411, i32 0, i32 2
  store i32 %local.resolved.extent.212, ptr %descriptor.field.414, align 4
  %descriptor.field.415 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.411, i32 0, i32 3
  store i32 %local.resolved.payload.213, ptr %descriptor.field.415, align 4
  %descriptor.field.416 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.411, i32 0, i32 4
  store i32 %local.resolved.owner.end.214, ptr %descriptor.field.416, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 37, i32 %local.resolved.offset.211, i32 20, i32 %local.resolved.payload.213, i32 %local.resolved.owner.end.214, i32 %local.resolved.extent.212)
  %context.field.417 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.418 = load i32, ptr %context.field.417, align 4
  %runtime.ok.419 = icmp eq i32 %context.value.418, 0
  br i1 %runtime.ok.419, label %runtime.continue.420, label %frame.failure.0
runtime.continue.420:
  %descriptor.element.421 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.410, i32 1
  %descriptor.field.422 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.421, i32 0, i32 0
  store i32 27, ptr %descriptor.field.422, align 4
  %descriptor.field.423 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.421, i32 0, i32 1
  store i32 %local.resolved.offset.302, ptr %descriptor.field.423, align 4
  %descriptor.field.424 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.421, i32 0, i32 2
  store i32 %local.resolved.extent.303, ptr %descriptor.field.424, align 4
  %descriptor.field.425 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.421, i32 0, i32 3
  store i32 %local.resolved.payload.304, ptr %descriptor.field.425, align 4
  %descriptor.field.426 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.421, i32 0, i32 4
  store i32 %local.resolved.owner.end.305, ptr %descriptor.field.426, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 27, i32 %local.resolved.offset.302, i32 20, i32 %local.resolved.payload.304, i32 %local.resolved.owner.end.305, i32 %local.resolved.extent.303)
  %context.field.427 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.428 = load i32, ptr %context.field.427, align 4
  %runtime.ok.429 = icmp eq i32 %context.value.428, 0
  br i1 %runtime.ok.429, label %runtime.continue.430, label %frame.failure.0
runtime.continue.430:
  %callee.status.432 = call i32 @agentlang_word_0001(ptr %ctx, ptr %provider.context, ptr %call.arguments.410, ptr %call.results.431, i32 8)
  %helper.ok.433 = icmp eq i32 %callee.status.432, 0
  br i1 %helper.ok.433, label %helper.continue.434, label %frame.failure.0
helper.continue.434:
  %descriptor.element.435 = getelementptr inbounds %AlOwningDescriptor, ptr %call.results.431, i32 0
  %descriptor.field.436 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.435, i32 0, i32 0
  %descriptor.value.437 = load i32, ptr %descriptor.field.436, align 4
  %descriptor.field.438 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.435, i32 0, i32 1
  %descriptor.value.439 = load i32, ptr %descriptor.field.438, align 4
  %descriptor.field.440 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.435, i32 0, i32 2
  %descriptor.value.441 = load i32, ptr %descriptor.field.440, align 4
  %descriptor.field.442 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.435, i32 0, i32 3
  %descriptor.value.443 = load i32, ptr %descriptor.field.442, align 4
  %descriptor.field.444 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.435, i32 0, i32 4
  %descriptor.value.445 = load i32, ptr %descriptor.field.444, align 4
  %callee.result.type.valid.446 = icmp eq i32 %descriptor.value.437, 41
  br i1 %callee.result.type.valid.446, label %callee.result.type.ok.447, label %frame.failure.0
callee.result.type.ok.447:
  %context.field.448 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.449 = load i32, ptr %context.field.448, align 4
  %stack.sub.452 = sub i32 %descriptor.value.445, %descriptor.value.439
  %descriptor.owner.inside.450 = icmp ule i32 %descriptor.value.445, %context.value.449
  %descriptor.offset.inside.451 = icmp ule i32 %descriptor.value.439, %descriptor.value.445
  %descriptor.extent.inside.453 = icmp ule i32 %descriptor.value.441, %stack.sub.452
  %descriptor.payload.inside.454 = icmp ule i32 %descriptor.value.443, %descriptor.value.441
  %descriptor.owner.offset.valid.455 = and i1 %descriptor.owner.inside.450, %descriptor.offset.inside.451
  %descriptor.range.inside.457 = and i1 %descriptor.owner.offset.valid.455, %descriptor.extent.inside.453
  %descriptor.range.valid.456 = and i1 %descriptor.range.inside.457, %descriptor.payload.inside.454
  %descriptor.type.valid.458 = icmp eq i32 41, 41
  %descriptor.valid.459 = and i1 %descriptor.range.valid.456, %descriptor.type.valid.458
  br i1 %descriptor.valid.459, label %descriptor.valid.460, label %descriptor.invalid.461
descriptor.invalid.461:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.460:
  %descriptor.initialized.status.462 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.439, i32 %descriptor.value.441)
  %helper.ok.463 = icmp eq i32 %descriptor.initialized.status.462, 0
  br i1 %helper.ok.463, label %helper.continue.464, label %frame.failure.0
helper.continue.464:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 41, i32 %descriptor.value.439, i32 20, i32 %descriptor.value.443, i32 %descriptor.value.445, i32 %descriptor.value.441)
  %context.field.465 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.466 = load i32, ptr %context.field.465, align 4
  %runtime.ok.467 = icmp eq i32 %context.value.466, 0
  br i1 %runtime.ok.467, label %runtime.continue.468, label %frame.failure.0
runtime.continue.468:
  %context.field.469 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.470 = load i32, ptr %context.field.469, align 4
  %stack.sub.473 = sub i32 %descriptor.value.445, %descriptor.value.439
  %descriptor.owner.inside.471 = icmp ule i32 %descriptor.value.445, %context.value.470
  %descriptor.offset.inside.472 = icmp ule i32 %descriptor.value.439, %descriptor.value.445
  %descriptor.extent.inside.474 = icmp ule i32 %descriptor.value.441, %stack.sub.473
  %descriptor.payload.inside.475 = icmp ule i32 %descriptor.value.443, %descriptor.value.441
  %descriptor.owner.offset.valid.476 = and i1 %descriptor.owner.inside.471, %descriptor.offset.inside.472
  %descriptor.range.inside.478 = and i1 %descriptor.owner.offset.valid.476, %descriptor.extent.inside.474
  %descriptor.range.valid.477 = and i1 %descriptor.range.inside.478, %descriptor.payload.inside.475
  %descriptor.type.valid.479 = icmp eq i32 41, 41
  %descriptor.valid.480 = and i1 %descriptor.range.valid.477, %descriptor.type.valid.479
  br i1 %descriptor.valid.480, label %descriptor.valid.481, label %descriptor.invalid.482
descriptor.invalid.482:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.481:
  %descriptor.initialized.status.483 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.439, i32 %descriptor.value.441)
  %helper.ok.484 = icmp eq i32 %descriptor.initialized.status.483, 0
  br i1 %helper.ok.484, label %helper.continue.485, label %frame.failure.0
helper.continue.485:
  %local.is.active.486 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.486, label %local.descriptor.active.487, label %local.descriptor.inactive.488
local.descriptor.active.487:
  %local.check.offset.490 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.491 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.492 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.493 = load i32, ptr %local.owner.end.6, align 4
  %context.field.494 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.495 = load i32, ptr %context.field.494, align 4
  %stack.sub.498 = sub i32 %local.check.owner.end.493, %local.check.offset.490
  %descriptor.owner.inside.496 = icmp ule i32 %local.check.owner.end.493, %context.value.495
  %descriptor.offset.inside.497 = icmp ule i32 %local.check.offset.490, %local.check.owner.end.493
  %descriptor.extent.inside.499 = icmp ule i32 %local.check.extent.491, %stack.sub.498
  %descriptor.payload.inside.500 = icmp ule i32 %local.check.payload.492, %local.check.extent.491
  %descriptor.owner.offset.valid.501 = and i1 %descriptor.owner.inside.496, %descriptor.offset.inside.497
  %descriptor.range.inside.503 = and i1 %descriptor.owner.offset.valid.501, %descriptor.extent.inside.499
  %descriptor.range.valid.502 = and i1 %descriptor.range.inside.503, %descriptor.payload.inside.500
  br i1 %descriptor.range.valid.502, label %descriptor.valid.504, label %descriptor.invalid.505
descriptor.invalid.505:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.504:
  %descriptor.initialized.status.506 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.490, i32 %local.check.extent.491)
  %helper.ok.507 = icmp eq i32 %descriptor.initialized.status.506, 0
  br i1 %helper.ok.507, label %helper.continue.508, label %frame.failure.0
helper.continue.508:
  br label %local.descriptor.checked.489
local.descriptor.inactive.488:
  br label %local.descriptor.checked.489
local.descriptor.checked.489:
  %local.is.active.509 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.509, label %local.descriptor.active.510, label %local.descriptor.inactive.511
local.descriptor.active.510:
  %local.check.offset.513 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.514 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.515 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.516 = load i32, ptr %local.owner.end.12, align 4
  %context.field.517 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.518 = load i32, ptr %context.field.517, align 4
  %stack.sub.521 = sub i32 %local.check.owner.end.516, %local.check.offset.513
  %descriptor.owner.inside.519 = icmp ule i32 %local.check.owner.end.516, %context.value.518
  %descriptor.offset.inside.520 = icmp ule i32 %local.check.offset.513, %local.check.owner.end.516
  %descriptor.extent.inside.522 = icmp ule i32 %local.check.extent.514, %stack.sub.521
  %descriptor.payload.inside.523 = icmp ule i32 %local.check.payload.515, %local.check.extent.514
  %descriptor.owner.offset.valid.524 = and i1 %descriptor.owner.inside.519, %descriptor.offset.inside.520
  %descriptor.range.inside.526 = and i1 %descriptor.owner.offset.valid.524, %descriptor.extent.inside.522
  %descriptor.range.valid.525 = and i1 %descriptor.range.inside.526, %descriptor.payload.inside.523
  br i1 %descriptor.range.valid.525, label %descriptor.valid.527, label %descriptor.invalid.528
descriptor.invalid.528:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.527:
  %descriptor.initialized.status.529 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.513, i32 %local.check.extent.514)
  %helper.ok.530 = icmp eq i32 %descriptor.initialized.status.529, 0
  br i1 %helper.ok.530, label %helper.continue.531, label %frame.failure.0
helper.continue.531:
  br label %local.descriptor.checked.512
local.descriptor.inactive.511:
  br label %local.descriptor.checked.512
local.descriptor.checked.512:
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %descriptor.element.532 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.533 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.532, i32 0, i32 0
  store i32 41, ptr %descriptor.field.533, align 4
  %descriptor.field.534 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.532, i32 0, i32 1
  store i32 %descriptor.value.439, ptr %descriptor.field.534, align 4
  %descriptor.field.535 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.532, i32 0, i32 2
  store i32 %descriptor.value.441, ptr %descriptor.field.535, align 4
  %descriptor.field.536 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.532, i32 0, i32 3
  store i32 %descriptor.value.443, ptr %descriptor.field.536, align 4
  %descriptor.field.537 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.532, i32 0, i32 4
  store i32 %descriptor.value.445, ptr %descriptor.field.537, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 41, i32 %descriptor.value.439, i32 20, i32 %descriptor.value.443, i32 %descriptor.value.445, i32 %descriptor.value.441)
  %context.field.538 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.539 = load i32, ptr %context.field.538, align 4
  %runtime.ok.540 = icmp eq i32 %context.value.539, 0
  br i1 %runtime.ok.540, label %runtime.continue.541, label %frame.failure.0
runtime.continue.541:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.15, i32 0, i32 0, i32 0)
  %context.field.542 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.543 = load i32, ptr %context.field.542, align 4
  %context.field.544 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.545 = load i32, ptr %context.field.544, align 4
  %context.field.546 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.547 = load i32, ptr %context.field.546, align 4
  %stack.offset.548 = add i32 %context.value.17, %context.value.19
  %stack.offset.549 = add i32 %context.value.543, %context.value.545
  %stack.sub.550 = sub i32 %stack.offset.548, %stack.offset.549
  %stack.sub.551 = sub i32 %context.value.19, %context.value.545
  %stack.sub.552 = sub i32 %context.value.547, %context.value.21
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.550, i32 %stack.sub.551)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.552)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0001(ptr %ctx, ptr %provider.context, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %local.active.2 = alloca i1, align 1
  %local.offset.3 = alloca i32, align 4
  %local.extent.4 = alloca i32, align 4
  %local.payload.5 = alloca i32, align 4
  %local.owner.end.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  %local.active.8 = alloca i1, align 1
  %local.offset.9 = alloca i32, align 4
  %local.extent.10 = alloca i32, align 4
  %local.payload.11 = alloca i32, align 4
  %local.owner.end.12 = alloca i32, align 4
  %local.type.13 = alloca i32, align 4
  %host.output.extent.pointer.449 = alloca i32, align 4
  %host.output.payload.pointer.452 = alloca i32, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  %context.field.14 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.15 = load i32, ptr %context.field.14, align 4
  %context.field.16 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.17 = load i32, ptr %context.field.16, align 4
  %context.field.18 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.19 = load i32, ptr %context.field.18, align 4
  %context.field.20 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.21 = load i32, ptr %context.field.20, align 4
  %frame.entered.22 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.23 = icmp eq i32 %frame.entered.22, 0
  br i1 %frame.enter.ok.23, label %frame.enter.continue.24, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.24:
  %descriptor.element.25 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.26 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 0
  %descriptor.value.27 = load i32, ptr %descriptor.field.26, align 4
  %descriptor.field.28 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 1
  %descriptor.value.29 = load i32, ptr %descriptor.field.28, align 4
  %descriptor.field.30 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 2
  %descriptor.value.31 = load i32, ptr %descriptor.field.30, align 4
  %descriptor.field.32 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 3
  %descriptor.value.33 = load i32, ptr %descriptor.field.32, align 4
  %descriptor.field.34 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 4
  %descriptor.value.35 = load i32, ptr %descriptor.field.34, align 4
  %argument.type.valid.36 = icmp eq i32 %descriptor.value.27, 37
  br i1 %argument.type.valid.36, label %argument.type.ok.37, label %frame.failure.0
argument.type.ok.37:
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %stack.sub.42 = sub i32 %descriptor.value.35, %descriptor.value.29
  %descriptor.owner.inside.40 = icmp ule i32 %descriptor.value.35, %context.value.39
  %descriptor.offset.inside.41 = icmp ule i32 %descriptor.value.29, %descriptor.value.35
  %descriptor.extent.inside.43 = icmp ule i32 %descriptor.value.31, %stack.sub.42
  %descriptor.payload.inside.44 = icmp ule i32 %descriptor.value.33, %descriptor.value.31
  %descriptor.owner.offset.valid.45 = and i1 %descriptor.owner.inside.40, %descriptor.offset.inside.41
  %descriptor.range.inside.47 = and i1 %descriptor.owner.offset.valid.45, %descriptor.extent.inside.43
  %descriptor.range.valid.46 = and i1 %descriptor.range.inside.47, %descriptor.payload.inside.44
  %descriptor.type.valid.48 = icmp eq i32 37, 37
  %descriptor.valid.49 = and i1 %descriptor.range.valid.46, %descriptor.type.valid.48
  br i1 %descriptor.valid.49, label %descriptor.valid.50, label %descriptor.invalid.51
descriptor.invalid.51:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.50:
  %descriptor.initialized.status.52 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.29, i32 %descriptor.value.31)
  %helper.ok.53 = icmp eq i32 %descriptor.initialized.status.52, 0
  br i1 %helper.ok.53, label %helper.continue.54, label %frame.failure.0
helper.continue.54:
  %descriptor.element.55 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.56 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.55, i32 0, i32 0
  %descriptor.value.57 = load i32, ptr %descriptor.field.56, align 4
  %descriptor.field.58 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.55, i32 0, i32 1
  %descriptor.value.59 = load i32, ptr %descriptor.field.58, align 4
  %descriptor.field.60 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.55, i32 0, i32 2
  %descriptor.value.61 = load i32, ptr %descriptor.field.60, align 4
  %descriptor.field.62 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.55, i32 0, i32 3
  %descriptor.value.63 = load i32, ptr %descriptor.field.62, align 4
  %descriptor.field.64 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.55, i32 0, i32 4
  %descriptor.value.65 = load i32, ptr %descriptor.field.64, align 4
  %argument.type.valid.66 = icmp eq i32 %descriptor.value.57, 27
  br i1 %argument.type.valid.66, label %argument.type.ok.67, label %frame.failure.0
argument.type.ok.67:
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %stack.sub.72 = sub i32 %descriptor.value.65, %descriptor.value.59
  %descriptor.owner.inside.70 = icmp ule i32 %descriptor.value.65, %context.value.69
  %descriptor.offset.inside.71 = icmp ule i32 %descriptor.value.59, %descriptor.value.65
  %descriptor.extent.inside.73 = icmp ule i32 %descriptor.value.61, %stack.sub.72
  %descriptor.payload.inside.74 = icmp ule i32 %descriptor.value.63, %descriptor.value.61
  %descriptor.owner.offset.valid.75 = and i1 %descriptor.owner.inside.70, %descriptor.offset.inside.71
  %descriptor.range.inside.77 = and i1 %descriptor.owner.offset.valid.75, %descriptor.extent.inside.73
  %descriptor.range.valid.76 = and i1 %descriptor.range.inside.77, %descriptor.payload.inside.74
  %descriptor.type.valid.78 = icmp eq i32 27, 27
  %descriptor.valid.79 = and i1 %descriptor.range.valid.76, %descriptor.type.valid.78
  br i1 %descriptor.valid.79, label %descriptor.valid.80, label %descriptor.invalid.81
descriptor.invalid.81:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.80:
  %descriptor.initialized.status.82 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.59, i32 %descriptor.value.61)
  %helper.ok.83 = icmp eq i32 %descriptor.initialized.status.82, 0
  br i1 %helper.ok.83, label %helper.continue.84, label %frame.failure.0
helper.continue.84:
  %step.status.85 = call i32 @al_owning_charge_step(ptr %ctx, i32 9)
  %helper.ok.86 = icmp eq i32 %step.status.85, 0
  br i1 %helper.ok.86, label %helper.continue.87, label %frame.failure.0
helper.continue.87:
  store i1 true, ptr %local.active.2, align 1
  store i32 %descriptor.value.59, ptr %local.offset.3, align 4
  store i32 %descriptor.value.61, ptr %local.extent.4, align 4
  store i32 %descriptor.value.63, ptr %local.payload.5, align 4
  store i32 %descriptor.value.65, ptr %local.owner.end.6, align 4
  store i32 27, ptr %local.type.7, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 27, i32 %descriptor.value.59, i32 20, i32 %descriptor.value.63, i32 %descriptor.value.65, i32 %descriptor.value.61)
  %context.field.88 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.89 = load i32, ptr %context.field.88, align 4
  %runtime.ok.90 = icmp eq i32 %context.value.89, 0
  br i1 %runtime.ok.90, label %runtime.continue.91, label %frame.failure.0
runtime.continue.91:
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %stack.sub.96 = sub i32 %descriptor.value.35, %descriptor.value.29
  %descriptor.owner.inside.94 = icmp ule i32 %descriptor.value.35, %context.value.93
  %descriptor.offset.inside.95 = icmp ule i32 %descriptor.value.29, %descriptor.value.35
  %descriptor.extent.inside.97 = icmp ule i32 %descriptor.value.31, %stack.sub.96
  %descriptor.payload.inside.98 = icmp ule i32 %descriptor.value.33, %descriptor.value.31
  %descriptor.owner.offset.valid.99 = and i1 %descriptor.owner.inside.94, %descriptor.offset.inside.95
  %descriptor.range.inside.101 = and i1 %descriptor.owner.offset.valid.99, %descriptor.extent.inside.97
  %descriptor.range.valid.100 = and i1 %descriptor.range.inside.101, %descriptor.payload.inside.98
  %descriptor.type.valid.102 = icmp eq i32 37, 37
  %descriptor.valid.103 = and i1 %descriptor.range.valid.100, %descriptor.type.valid.102
  br i1 %descriptor.valid.103, label %descriptor.valid.104, label %descriptor.invalid.105
descriptor.invalid.105:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.104:
  %descriptor.initialized.status.106 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.29, i32 %descriptor.value.31)
  %helper.ok.107 = icmp eq i32 %descriptor.initialized.status.106, 0
  br i1 %helper.ok.107, label %helper.continue.108, label %frame.failure.0
helper.continue.108:
  %local.is.active.109 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.109, label %local.descriptor.active.110, label %local.descriptor.inactive.111
local.descriptor.active.110:
  %local.check.offset.113 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.114 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.115 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.116 = load i32, ptr %local.owner.end.6, align 4
  %context.field.117 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.118 = load i32, ptr %context.field.117, align 4
  %stack.sub.121 = sub i32 %local.check.owner.end.116, %local.check.offset.113
  %descriptor.owner.inside.119 = icmp ule i32 %local.check.owner.end.116, %context.value.118
  %descriptor.offset.inside.120 = icmp ule i32 %local.check.offset.113, %local.check.owner.end.116
  %descriptor.extent.inside.122 = icmp ule i32 %local.check.extent.114, %stack.sub.121
  %descriptor.payload.inside.123 = icmp ule i32 %local.check.payload.115, %local.check.extent.114
  %descriptor.owner.offset.valid.124 = and i1 %descriptor.owner.inside.119, %descriptor.offset.inside.120
  %descriptor.range.inside.126 = and i1 %descriptor.owner.offset.valid.124, %descriptor.extent.inside.122
  %descriptor.range.valid.125 = and i1 %descriptor.range.inside.126, %descriptor.payload.inside.123
  br i1 %descriptor.range.valid.125, label %descriptor.valid.127, label %descriptor.invalid.128
descriptor.invalid.128:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.127:
  %descriptor.initialized.status.129 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.113, i32 %local.check.extent.114)
  %helper.ok.130 = icmp eq i32 %descriptor.initialized.status.129, 0
  br i1 %helper.ok.130, label %helper.continue.131, label %frame.failure.0
helper.continue.131:
  br label %local.descriptor.checked.112
local.descriptor.inactive.111:
  br label %local.descriptor.checked.112
local.descriptor.checked.112:
  %local.is.active.132 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.132, label %local.descriptor.active.133, label %local.descriptor.inactive.134
local.descriptor.active.133:
  %local.check.offset.136 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.137 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.138 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.139 = load i32, ptr %local.owner.end.12, align 4
  %context.field.140 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.141 = load i32, ptr %context.field.140, align 4
  %stack.sub.144 = sub i32 %local.check.owner.end.139, %local.check.offset.136
  %descriptor.owner.inside.142 = icmp ule i32 %local.check.owner.end.139, %context.value.141
  %descriptor.offset.inside.143 = icmp ule i32 %local.check.offset.136, %local.check.owner.end.139
  %descriptor.extent.inside.145 = icmp ule i32 %local.check.extent.137, %stack.sub.144
  %descriptor.payload.inside.146 = icmp ule i32 %local.check.payload.138, %local.check.extent.137
  %descriptor.owner.offset.valid.147 = and i1 %descriptor.owner.inside.142, %descriptor.offset.inside.143
  %descriptor.range.inside.149 = and i1 %descriptor.owner.offset.valid.147, %descriptor.extent.inside.145
  %descriptor.range.valid.148 = and i1 %descriptor.range.inside.149, %descriptor.payload.inside.146
  br i1 %descriptor.range.valid.148, label %descriptor.valid.150, label %descriptor.invalid.151
descriptor.invalid.151:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.150:
  %descriptor.initialized.status.152 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.136, i32 %local.check.extent.137)
  %helper.ok.153 = icmp eq i32 %descriptor.initialized.status.152, 0
  br i1 %helper.ok.153, label %helper.continue.154, label %frame.failure.0
helper.continue.154:
  br label %local.descriptor.checked.135
local.descriptor.inactive.134:
  br label %local.descriptor.checked.135
local.descriptor.checked.135:
  %step.status.155 = call i32 @al_owning_charge_step(ptr %ctx, i32 10)
  %helper.ok.156 = icmp eq i32 %step.status.155, 0
  br i1 %helper.ok.156, label %helper.continue.157, label %frame.failure.0
helper.continue.157:
  store i1 true, ptr %local.active.8, align 1
  store i32 %descriptor.value.29, ptr %local.offset.9, align 4
  store i32 %descriptor.value.31, ptr %local.extent.10, align 4
  store i32 %descriptor.value.33, ptr %local.payload.11, align 4
  store i32 %descriptor.value.35, ptr %local.owner.end.12, align 4
  store i32 37, ptr %local.type.13, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 37, i32 %descriptor.value.29, i32 20, i32 %descriptor.value.33, i32 %descriptor.value.35, i32 %descriptor.value.31)
  %context.field.158 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.159 = load i32, ptr %context.field.158, align 4
  %runtime.ok.160 = icmp eq i32 %context.value.159, 0
  br i1 %runtime.ok.160, label %runtime.continue.161, label %frame.failure.0
runtime.continue.161:
  %local.is.active.162 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.162, label %local.descriptor.active.163, label %local.descriptor.inactive.164
local.descriptor.active.163:
  %local.check.offset.166 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.167 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.168 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.169 = load i32, ptr %local.owner.end.6, align 4
  %context.field.170 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.171 = load i32, ptr %context.field.170, align 4
  %stack.sub.174 = sub i32 %local.check.owner.end.169, %local.check.offset.166
  %descriptor.owner.inside.172 = icmp ule i32 %local.check.owner.end.169, %context.value.171
  %descriptor.offset.inside.173 = icmp ule i32 %local.check.offset.166, %local.check.owner.end.169
  %descriptor.extent.inside.175 = icmp ule i32 %local.check.extent.167, %stack.sub.174
  %descriptor.payload.inside.176 = icmp ule i32 %local.check.payload.168, %local.check.extent.167
  %descriptor.owner.offset.valid.177 = and i1 %descriptor.owner.inside.172, %descriptor.offset.inside.173
  %descriptor.range.inside.179 = and i1 %descriptor.owner.offset.valid.177, %descriptor.extent.inside.175
  %descriptor.range.valid.178 = and i1 %descriptor.range.inside.179, %descriptor.payload.inside.176
  br i1 %descriptor.range.valid.178, label %descriptor.valid.180, label %descriptor.invalid.181
descriptor.invalid.181:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.180:
  %descriptor.initialized.status.182 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.166, i32 %local.check.extent.167)
  %helper.ok.183 = icmp eq i32 %descriptor.initialized.status.182, 0
  br i1 %helper.ok.183, label %helper.continue.184, label %frame.failure.0
helper.continue.184:
  br label %local.descriptor.checked.165
local.descriptor.inactive.164:
  br label %local.descriptor.checked.165
local.descriptor.checked.165:
  %local.is.active.185 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.185, label %local.descriptor.active.186, label %local.descriptor.inactive.187
local.descriptor.active.186:
  %local.check.offset.189 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.190 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.191 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.192 = load i32, ptr %local.owner.end.12, align 4
  %context.field.193 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.194 = load i32, ptr %context.field.193, align 4
  %stack.sub.197 = sub i32 %local.check.owner.end.192, %local.check.offset.189
  %descriptor.owner.inside.195 = icmp ule i32 %local.check.owner.end.192, %context.value.194
  %descriptor.offset.inside.196 = icmp ule i32 %local.check.offset.189, %local.check.owner.end.192
  %descriptor.extent.inside.198 = icmp ule i32 %local.check.extent.190, %stack.sub.197
  %descriptor.payload.inside.199 = icmp ule i32 %local.check.payload.191, %local.check.extent.190
  %descriptor.owner.offset.valid.200 = and i1 %descriptor.owner.inside.195, %descriptor.offset.inside.196
  %descriptor.range.inside.202 = and i1 %descriptor.owner.offset.valid.200, %descriptor.extent.inside.198
  %descriptor.range.valid.201 = and i1 %descriptor.range.inside.202, %descriptor.payload.inside.199
  br i1 %descriptor.range.valid.201, label %descriptor.valid.203, label %descriptor.invalid.204
descriptor.invalid.204:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.203:
  %descriptor.initialized.status.205 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.189, i32 %local.check.extent.190)
  %helper.ok.206 = icmp eq i32 %descriptor.initialized.status.205, 0
  br i1 %helper.ok.206, label %helper.continue.207, label %frame.failure.0
helper.continue.207:
  br label %local.descriptor.checked.188
local.descriptor.inactive.187:
  br label %local.descriptor.checked.188
local.descriptor.checked.188:
  %step.status.208 = call i32 @al_owning_charge_step(ptr %ctx, i32 11)
  %helper.ok.209 = icmp eq i32 %step.status.208, 0
  br i1 %helper.ok.209, label %helper.continue.210, label %frame.failure.0
helper.continue.210:
  %local.resolved.offset.211 = load i32, ptr %local.offset.9, align 4
  %local.resolved.extent.212 = load i32, ptr %local.extent.10, align 4
  %local.resolved.payload.213 = load i32, ptr %local.payload.11, align 4
  %local.resolved.owner.end.214 = load i32, ptr %local.owner.end.12, align 4
  %context.field.215 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.216 = load i32, ptr %context.field.215, align 4
  %stack.sub.219 = sub i32 %local.resolved.owner.end.214, %local.resolved.offset.211
  %descriptor.owner.inside.217 = icmp ule i32 %local.resolved.owner.end.214, %context.value.216
  %descriptor.offset.inside.218 = icmp ule i32 %local.resolved.offset.211, %local.resolved.owner.end.214
  %descriptor.extent.inside.220 = icmp ule i32 %local.resolved.extent.212, %stack.sub.219
  %descriptor.payload.inside.221 = icmp ule i32 %local.resolved.payload.213, %local.resolved.extent.212
  %descriptor.owner.offset.valid.222 = and i1 %descriptor.owner.inside.217, %descriptor.offset.inside.218
  %descriptor.range.inside.224 = and i1 %descriptor.owner.offset.valid.222, %descriptor.extent.inside.220
  %descriptor.range.valid.223 = and i1 %descriptor.range.inside.224, %descriptor.payload.inside.221
  %descriptor.type.valid.225 = icmp eq i32 37, 37
  %descriptor.valid.226 = and i1 %descriptor.range.valid.223, %descriptor.type.valid.225
  br i1 %descriptor.valid.226, label %descriptor.valid.227, label %descriptor.invalid.228
descriptor.invalid.228:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.227:
  %descriptor.initialized.status.229 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.211, i32 %local.resolved.extent.212)
  %helper.ok.230 = icmp eq i32 %descriptor.initialized.status.229, 0
  br i1 %helper.ok.230, label %helper.continue.231, label %frame.failure.0
helper.continue.231:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 37, i32 %local.resolved.offset.211, i32 20, i32 %local.resolved.payload.213, i32 %local.resolved.owner.end.214, i32 %local.resolved.extent.212)
  %context.field.232 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.233 = load i32, ptr %context.field.232, align 4
  %runtime.ok.234 = icmp eq i32 %context.value.233, 0
  br i1 %runtime.ok.234, label %runtime.continue.235, label %frame.failure.0
runtime.continue.235:
  %context.field.236 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.237 = load i32, ptr %context.field.236, align 4
  %stack.sub.240 = sub i32 %local.resolved.owner.end.214, %local.resolved.offset.211
  %descriptor.owner.inside.238 = icmp ule i32 %local.resolved.owner.end.214, %context.value.237
  %descriptor.offset.inside.239 = icmp ule i32 %local.resolved.offset.211, %local.resolved.owner.end.214
  %descriptor.extent.inside.241 = icmp ule i32 %local.resolved.extent.212, %stack.sub.240
  %descriptor.payload.inside.242 = icmp ule i32 %local.resolved.payload.213, %local.resolved.extent.212
  %descriptor.owner.offset.valid.243 = and i1 %descriptor.owner.inside.238, %descriptor.offset.inside.239
  %descriptor.range.inside.245 = and i1 %descriptor.owner.offset.valid.243, %descriptor.extent.inside.241
  %descriptor.range.valid.244 = and i1 %descriptor.range.inside.245, %descriptor.payload.inside.242
  %descriptor.type.valid.246 = icmp eq i32 37, 37
  %descriptor.valid.247 = and i1 %descriptor.range.valid.244, %descriptor.type.valid.246
  br i1 %descriptor.valid.247, label %descriptor.valid.248, label %descriptor.invalid.249
descriptor.invalid.249:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.248:
  %descriptor.initialized.status.250 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.211, i32 %local.resolved.extent.212)
  %helper.ok.251 = icmp eq i32 %descriptor.initialized.status.250, 0
  br i1 %helper.ok.251, label %helper.continue.252, label %frame.failure.0
helper.continue.252:
  %local.is.active.253 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.253, label %local.descriptor.active.254, label %local.descriptor.inactive.255
local.descriptor.active.254:
  %local.check.offset.257 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.258 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.259 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.260 = load i32, ptr %local.owner.end.6, align 4
  %context.field.261 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.262 = load i32, ptr %context.field.261, align 4
  %stack.sub.265 = sub i32 %local.check.owner.end.260, %local.check.offset.257
  %descriptor.owner.inside.263 = icmp ule i32 %local.check.owner.end.260, %context.value.262
  %descriptor.offset.inside.264 = icmp ule i32 %local.check.offset.257, %local.check.owner.end.260
  %descriptor.extent.inside.266 = icmp ule i32 %local.check.extent.258, %stack.sub.265
  %descriptor.payload.inside.267 = icmp ule i32 %local.check.payload.259, %local.check.extent.258
  %descriptor.owner.offset.valid.268 = and i1 %descriptor.owner.inside.263, %descriptor.offset.inside.264
  %descriptor.range.inside.270 = and i1 %descriptor.owner.offset.valid.268, %descriptor.extent.inside.266
  %descriptor.range.valid.269 = and i1 %descriptor.range.inside.270, %descriptor.payload.inside.267
  br i1 %descriptor.range.valid.269, label %descriptor.valid.271, label %descriptor.invalid.272
descriptor.invalid.272:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.271:
  %descriptor.initialized.status.273 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.257, i32 %local.check.extent.258)
  %helper.ok.274 = icmp eq i32 %descriptor.initialized.status.273, 0
  br i1 %helper.ok.274, label %helper.continue.275, label %frame.failure.0
helper.continue.275:
  br label %local.descriptor.checked.256
local.descriptor.inactive.255:
  br label %local.descriptor.checked.256
local.descriptor.checked.256:
  %local.is.active.276 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.276, label %local.descriptor.active.277, label %local.descriptor.inactive.278
local.descriptor.active.277:
  %local.check.offset.280 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.281 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.282 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.283 = load i32, ptr %local.owner.end.12, align 4
  %context.field.284 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.285 = load i32, ptr %context.field.284, align 4
  %stack.sub.288 = sub i32 %local.check.owner.end.283, %local.check.offset.280
  %descriptor.owner.inside.286 = icmp ule i32 %local.check.owner.end.283, %context.value.285
  %descriptor.offset.inside.287 = icmp ule i32 %local.check.offset.280, %local.check.owner.end.283
  %descriptor.extent.inside.289 = icmp ule i32 %local.check.extent.281, %stack.sub.288
  %descriptor.payload.inside.290 = icmp ule i32 %local.check.payload.282, %local.check.extent.281
  %descriptor.owner.offset.valid.291 = and i1 %descriptor.owner.inside.286, %descriptor.offset.inside.287
  %descriptor.range.inside.293 = and i1 %descriptor.owner.offset.valid.291, %descriptor.extent.inside.289
  %descriptor.range.valid.292 = and i1 %descriptor.range.inside.293, %descriptor.payload.inside.290
  br i1 %descriptor.range.valid.292, label %descriptor.valid.294, label %descriptor.invalid.295
descriptor.invalid.295:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.294:
  %descriptor.initialized.status.296 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.280, i32 %local.check.extent.281)
  %helper.ok.297 = icmp eq i32 %descriptor.initialized.status.296, 0
  br i1 %helper.ok.297, label %helper.continue.298, label %frame.failure.0
helper.continue.298:
  br label %local.descriptor.checked.279
local.descriptor.inactive.278:
  br label %local.descriptor.checked.279
local.descriptor.checked.279:
  %step.status.299 = call i32 @al_owning_charge_step(ptr %ctx, i32 12)
  %helper.ok.300 = icmp eq i32 %step.status.299, 0
  br i1 %helper.ok.300, label %helper.continue.301, label %frame.failure.0
helper.continue.301:
  %local.resolved.offset.302 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.303 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.304 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.305 = load i32, ptr %local.owner.end.6, align 4
  %context.field.306 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.307 = load i32, ptr %context.field.306, align 4
  %stack.sub.310 = sub i32 %local.resolved.owner.end.305, %local.resolved.offset.302
  %descriptor.owner.inside.308 = icmp ule i32 %local.resolved.owner.end.305, %context.value.307
  %descriptor.offset.inside.309 = icmp ule i32 %local.resolved.offset.302, %local.resolved.owner.end.305
  %descriptor.extent.inside.311 = icmp ule i32 %local.resolved.extent.303, %stack.sub.310
  %descriptor.payload.inside.312 = icmp ule i32 %local.resolved.payload.304, %local.resolved.extent.303
  %descriptor.owner.offset.valid.313 = and i1 %descriptor.owner.inside.308, %descriptor.offset.inside.309
  %descriptor.range.inside.315 = and i1 %descriptor.owner.offset.valid.313, %descriptor.extent.inside.311
  %descriptor.range.valid.314 = and i1 %descriptor.range.inside.315, %descriptor.payload.inside.312
  %descriptor.type.valid.316 = icmp eq i32 27, 27
  %descriptor.valid.317 = and i1 %descriptor.range.valid.314, %descriptor.type.valid.316
  br i1 %descriptor.valid.317, label %descriptor.valid.318, label %descriptor.invalid.319
descriptor.invalid.319:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.318:
  %descriptor.initialized.status.320 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.302, i32 %local.resolved.extent.303)
  %helper.ok.321 = icmp eq i32 %descriptor.initialized.status.320, 0
  br i1 %helper.ok.321, label %helper.continue.322, label %frame.failure.0
helper.continue.322:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 27, i32 %local.resolved.offset.302, i32 20, i32 %local.resolved.payload.304, i32 %local.resolved.owner.end.305, i32 %local.resolved.extent.303)
  %context.field.323 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.324 = load i32, ptr %context.field.323, align 4
  %runtime.ok.325 = icmp eq i32 %context.value.324, 0
  br i1 %runtime.ok.325, label %runtime.continue.326, label %frame.failure.0
runtime.continue.326:
  %context.field.327 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.328 = load i32, ptr %context.field.327, align 4
  %stack.sub.331 = sub i32 %local.resolved.owner.end.214, %local.resolved.offset.211
  %descriptor.owner.inside.329 = icmp ule i32 %local.resolved.owner.end.214, %context.value.328
  %descriptor.offset.inside.330 = icmp ule i32 %local.resolved.offset.211, %local.resolved.owner.end.214
  %descriptor.extent.inside.332 = icmp ule i32 %local.resolved.extent.212, %stack.sub.331
  %descriptor.payload.inside.333 = icmp ule i32 %local.resolved.payload.213, %local.resolved.extent.212
  %descriptor.owner.offset.valid.334 = and i1 %descriptor.owner.inside.329, %descriptor.offset.inside.330
  %descriptor.range.inside.336 = and i1 %descriptor.owner.offset.valid.334, %descriptor.extent.inside.332
  %descriptor.range.valid.335 = and i1 %descriptor.range.inside.336, %descriptor.payload.inside.333
  %descriptor.type.valid.337 = icmp eq i32 37, 37
  %descriptor.valid.338 = and i1 %descriptor.range.valid.335, %descriptor.type.valid.337
  br i1 %descriptor.valid.338, label %descriptor.valid.339, label %descriptor.invalid.340
descriptor.invalid.340:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.339:
  %descriptor.initialized.status.341 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.211, i32 %local.resolved.extent.212)
  %helper.ok.342 = icmp eq i32 %descriptor.initialized.status.341, 0
  br i1 %helper.ok.342, label %helper.continue.343, label %frame.failure.0
helper.continue.343:
  %context.field.344 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.345 = load i32, ptr %context.field.344, align 4
  %stack.sub.348 = sub i32 %local.resolved.owner.end.305, %local.resolved.offset.302
  %descriptor.owner.inside.346 = icmp ule i32 %local.resolved.owner.end.305, %context.value.345
  %descriptor.offset.inside.347 = icmp ule i32 %local.resolved.offset.302, %local.resolved.owner.end.305
  %descriptor.extent.inside.349 = icmp ule i32 %local.resolved.extent.303, %stack.sub.348
  %descriptor.payload.inside.350 = icmp ule i32 %local.resolved.payload.304, %local.resolved.extent.303
  %descriptor.owner.offset.valid.351 = and i1 %descriptor.owner.inside.346, %descriptor.offset.inside.347
  %descriptor.range.inside.353 = and i1 %descriptor.owner.offset.valid.351, %descriptor.extent.inside.349
  %descriptor.range.valid.352 = and i1 %descriptor.range.inside.353, %descriptor.payload.inside.350
  %descriptor.type.valid.354 = icmp eq i32 27, 27
  %descriptor.valid.355 = and i1 %descriptor.range.valid.352, %descriptor.type.valid.354
  br i1 %descriptor.valid.355, label %descriptor.valid.356, label %descriptor.invalid.357
descriptor.invalid.357:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.356:
  %descriptor.initialized.status.358 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.302, i32 %local.resolved.extent.303)
  %helper.ok.359 = icmp eq i32 %descriptor.initialized.status.358, 0
  br i1 %helper.ok.359, label %helper.continue.360, label %frame.failure.0
helper.continue.360:
  %local.is.active.361 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.361, label %local.descriptor.active.362, label %local.descriptor.inactive.363
local.descriptor.active.362:
  %local.check.offset.365 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.366 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.367 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.368 = load i32, ptr %local.owner.end.6, align 4
  %context.field.369 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.370 = load i32, ptr %context.field.369, align 4
  %stack.sub.373 = sub i32 %local.check.owner.end.368, %local.check.offset.365
  %descriptor.owner.inside.371 = icmp ule i32 %local.check.owner.end.368, %context.value.370
  %descriptor.offset.inside.372 = icmp ule i32 %local.check.offset.365, %local.check.owner.end.368
  %descriptor.extent.inside.374 = icmp ule i32 %local.check.extent.366, %stack.sub.373
  %descriptor.payload.inside.375 = icmp ule i32 %local.check.payload.367, %local.check.extent.366
  %descriptor.owner.offset.valid.376 = and i1 %descriptor.owner.inside.371, %descriptor.offset.inside.372
  %descriptor.range.inside.378 = and i1 %descriptor.owner.offset.valid.376, %descriptor.extent.inside.374
  %descriptor.range.valid.377 = and i1 %descriptor.range.inside.378, %descriptor.payload.inside.375
  br i1 %descriptor.range.valid.377, label %descriptor.valid.379, label %descriptor.invalid.380
descriptor.invalid.380:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.379:
  %descriptor.initialized.status.381 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.365, i32 %local.check.extent.366)
  %helper.ok.382 = icmp eq i32 %descriptor.initialized.status.381, 0
  br i1 %helper.ok.382, label %helper.continue.383, label %frame.failure.0
helper.continue.383:
  br label %local.descriptor.checked.364
local.descriptor.inactive.363:
  br label %local.descriptor.checked.364
local.descriptor.checked.364:
  %local.is.active.384 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.384, label %local.descriptor.active.385, label %local.descriptor.inactive.386
local.descriptor.active.385:
  %local.check.offset.388 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.389 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.390 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.391 = load i32, ptr %local.owner.end.12, align 4
  %context.field.392 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.393 = load i32, ptr %context.field.392, align 4
  %stack.sub.396 = sub i32 %local.check.owner.end.391, %local.check.offset.388
  %descriptor.owner.inside.394 = icmp ule i32 %local.check.owner.end.391, %context.value.393
  %descriptor.offset.inside.395 = icmp ule i32 %local.check.offset.388, %local.check.owner.end.391
  %descriptor.extent.inside.397 = icmp ule i32 %local.check.extent.389, %stack.sub.396
  %descriptor.payload.inside.398 = icmp ule i32 %local.check.payload.390, %local.check.extent.389
  %descriptor.owner.offset.valid.399 = and i1 %descriptor.owner.inside.394, %descriptor.offset.inside.395
  %descriptor.range.inside.401 = and i1 %descriptor.owner.offset.valid.399, %descriptor.extent.inside.397
  %descriptor.range.valid.400 = and i1 %descriptor.range.inside.401, %descriptor.payload.inside.398
  br i1 %descriptor.range.valid.400, label %descriptor.valid.402, label %descriptor.invalid.403
descriptor.invalid.403:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.402:
  %descriptor.initialized.status.404 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.388, i32 %local.check.extent.389)
  %helper.ok.405 = icmp eq i32 %descriptor.initialized.status.404, 0
  br i1 %helper.ok.405, label %helper.continue.406, label %frame.failure.0
helper.continue.406:
  br label %local.descriptor.checked.387
local.descriptor.inactive.386:
  br label %local.descriptor.checked.387
local.descriptor.checked.387:
  %step.status.407 = call i32 @al_owning_charge_step(ptr %ctx, i32 13)
  %helper.ok.408 = icmp eq i32 %step.status.407, 0
  br i1 %helper.ok.408, label %helper.continue.409, label %frame.failure.0
helper.continue.409:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 27, i32 %local.resolved.offset.302, i32 %local.resolved.extent.303, i32 %local.resolved.payload.304, i32 0, i32 0)
  %context.field.410 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.411 = load i32, ptr %context.field.410, align 4
  %runtime.ok.412 = icmp eq i32 %context.value.411, 0
  br i1 %runtime.ok.412, label %runtime.continue.413, label %frame.failure.0
runtime.continue.413:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 37, i32 %local.resolved.offset.211, i32 %local.resolved.extent.212, i32 %local.resolved.payload.213, i32 0, i32 0)
  %context.field.414 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.415 = load i32, ptr %context.field.414, align 4
  %runtime.ok.416 = icmp eq i32 %context.value.415, 0
  br i1 %runtime.ok.416, label %runtime.continue.417, label %frame.failure.0
runtime.continue.417:
  %host.user.id.418 = call i64 @al_owning_load_i64(ptr %ctx, i32 %local.resolved.offset.211)
  %context.field.420 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.421 = load i32, ptr %context.field.420, align 4
  %runtime.ok.422 = icmp eq i32 %context.value.421, 0
  br i1 %runtime.ok.422, label %runtime.continue.423, label %frame.failure.0
runtime.continue.423:
  %host.room.id.419 = call i64 @al_owning_load_i64(ptr %ctx, i32 %local.resolved.offset.302)
  %context.field.424 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.425 = load i32, ptr %context.field.424, align 4
  %runtime.ok.426 = icmp eq i32 %context.value.425, 0
  br i1 %runtime.ok.426, label %runtime.continue.427, label %frame.failure.0
runtime.continue.427:
  %context.field.428 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.429 = load i32, ptr %context.field.428, align 4
  %context.field.430 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 1
  %context.value.431 = load i32, ptr %context.field.430, align 4
  %stack.sub.432 = sub i32 %context.value.431, %context.value.429
  %host.output.below.limit.433 = icmp ult i32 %stack.sub.432, 65536
  %host.output.capacity.434 = select i1 %host.output.below.limit.433, i32 %stack.sub.432, i32 65536
  %host.output.minimum.fits.435 = icmp uge i32 %host.output.capacity.434, 16
  br i1 %host.output.minimum.fits.435, label %host.output.minimum.fits.436, label %host.output.minimum.too.small.437
host.output.minimum.too.small.437:
  %stack.offset.438 = add i32 %context.value.429, 16
  %reserve.status.439 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.438, i32 14)
  %reserve.ok.440 = icmp eq i32 %reserve.status.439, 0
  br i1 %reserve.ok.440, label %reserve.continue.441, label %frame.failure.0
reserve.continue.441:
  br label %frame.failure.0
host.output.minimum.fits.436:
  %stack.offset.442 = add i32 %context.value.429, %host.output.capacity.434
  %reserve.status.443 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.442, i32 15)
  %reserve.ok.444 = icmp eq i32 %reserve.status.443, 0
  br i1 %reserve.ok.444, label %reserve.continue.445, label %frame.failure.0
reserve.continue.445:
  %host.stack.data.field.446 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 25
  %host.stack.data.447 = load ptr, ptr %host.stack.data.field.446, align 8
  %host.output.pointer.448 = getelementptr inbounds i8, ptr %host.stack.data.447, i32 %context.value.429
  store i32 0, ptr %host.output.extent.pointer.449, align 4
  %host.call.status.450 = call i32 @al_host_campfire_rooms_find_for_user_v1(ptr %provider.context, i64 %host.user.id.418, i64 %host.room.id.419, ptr %host.output.pointer.448, i32 %host.output.capacity.434, ptr %host.output.extent.pointer.449)
  %host.output.extent.451 = load i32, ptr %host.output.extent.pointer.449, align 4
  store i32 0, ptr %host.output.payload.pointer.452, align 4
  %host.output.commit.status.454 = call i32 @al_owning_commit_host_output(ptr %ctx, ptr @al_owning_layout, i32 7, i32 %context.value.429, i32 %stack.offset.442, i32 %host.output.extent.451, i32 %host.call.status.450, i32 16, ptr %host.output.payload.pointer.452)
  %helper.ok.455 = icmp eq i32 %host.output.commit.status.454, 0
  br i1 %helper.ok.455, label %helper.continue.456, label %frame.failure.0
helper.continue.456:
  %host.output.payload.453 = load i32, ptr %host.output.payload.pointer.452, align 4
  %stack.offset.457 = add i32 %context.value.429, %host.output.extent.451
  %context.field.458 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.459 = load i32, ptr %context.field.458, align 4
  %stack.sub.462 = sub i32 %stack.offset.457, %context.value.429
  %descriptor.owner.inside.460 = icmp ule i32 %stack.offset.457, %context.value.459
  %descriptor.offset.inside.461 = icmp ule i32 %context.value.429, %stack.offset.457
  %descriptor.extent.inside.463 = icmp ule i32 %host.output.extent.451, %stack.sub.462
  %descriptor.payload.inside.464 = icmp ule i32 %host.output.payload.453, %host.output.extent.451
  %descriptor.owner.offset.valid.465 = and i1 %descriptor.owner.inside.460, %descriptor.offset.inside.461
  %descriptor.range.inside.467 = and i1 %descriptor.owner.offset.valid.465, %descriptor.extent.inside.463
  %descriptor.range.valid.466 = and i1 %descriptor.range.inside.467, %descriptor.payload.inside.464
  %descriptor.type.valid.468 = icmp eq i32 41, 41
  %descriptor.valid.469 = and i1 %descriptor.range.valid.466, %descriptor.type.valid.468
  br i1 %descriptor.valid.469, label %descriptor.valid.470, label %descriptor.invalid.471
descriptor.invalid.471:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.470:
  %descriptor.initialized.status.472 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.429, i32 %host.output.extent.451)
  %helper.ok.473 = icmp eq i32 %descriptor.initialized.status.472, 0
  br i1 %helper.ok.473, label %helper.continue.474, label %frame.failure.0
helper.continue.474:
  %local.is.active.475 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.475, label %local.descriptor.active.476, label %local.descriptor.inactive.477
local.descriptor.active.476:
  %local.check.offset.479 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.480 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.481 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.482 = load i32, ptr %local.owner.end.6, align 4
  %context.field.483 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.484 = load i32, ptr %context.field.483, align 4
  %stack.sub.487 = sub i32 %local.check.owner.end.482, %local.check.offset.479
  %descriptor.owner.inside.485 = icmp ule i32 %local.check.owner.end.482, %context.value.484
  %descriptor.offset.inside.486 = icmp ule i32 %local.check.offset.479, %local.check.owner.end.482
  %descriptor.extent.inside.488 = icmp ule i32 %local.check.extent.480, %stack.sub.487
  %descriptor.payload.inside.489 = icmp ule i32 %local.check.payload.481, %local.check.extent.480
  %descriptor.owner.offset.valid.490 = and i1 %descriptor.owner.inside.485, %descriptor.offset.inside.486
  %descriptor.range.inside.492 = and i1 %descriptor.owner.offset.valid.490, %descriptor.extent.inside.488
  %descriptor.range.valid.491 = and i1 %descriptor.range.inside.492, %descriptor.payload.inside.489
  br i1 %descriptor.range.valid.491, label %descriptor.valid.493, label %descriptor.invalid.494
descriptor.invalid.494:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.493:
  %descriptor.initialized.status.495 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.479, i32 %local.check.extent.480)
  %helper.ok.496 = icmp eq i32 %descriptor.initialized.status.495, 0
  br i1 %helper.ok.496, label %helper.continue.497, label %frame.failure.0
helper.continue.497:
  br label %local.descriptor.checked.478
local.descriptor.inactive.477:
  br label %local.descriptor.checked.478
local.descriptor.checked.478:
  %local.is.active.498 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.498, label %local.descriptor.active.499, label %local.descriptor.inactive.500
local.descriptor.active.499:
  %local.check.offset.502 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.503 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.504 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.505 = load i32, ptr %local.owner.end.12, align 4
  %context.field.506 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.507 = load i32, ptr %context.field.506, align 4
  %stack.sub.510 = sub i32 %local.check.owner.end.505, %local.check.offset.502
  %descriptor.owner.inside.508 = icmp ule i32 %local.check.owner.end.505, %context.value.507
  %descriptor.offset.inside.509 = icmp ule i32 %local.check.offset.502, %local.check.owner.end.505
  %descriptor.extent.inside.511 = icmp ule i32 %local.check.extent.503, %stack.sub.510
  %descriptor.payload.inside.512 = icmp ule i32 %local.check.payload.504, %local.check.extent.503
  %descriptor.owner.offset.valid.513 = and i1 %descriptor.owner.inside.508, %descriptor.offset.inside.509
  %descriptor.range.inside.515 = and i1 %descriptor.owner.offset.valid.513, %descriptor.extent.inside.511
  %descriptor.range.valid.514 = and i1 %descriptor.range.inside.515, %descriptor.payload.inside.512
  br i1 %descriptor.range.valid.514, label %descriptor.valid.516, label %descriptor.invalid.517
descriptor.invalid.517:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.516:
  %descriptor.initialized.status.518 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.502, i32 %local.check.extent.503)
  %helper.ok.519 = icmp eq i32 %descriptor.initialized.status.518, 0
  br i1 %helper.ok.519, label %helper.continue.520, label %frame.failure.0
helper.continue.520:
  br label %local.descriptor.checked.501
local.descriptor.inactive.500:
  br label %local.descriptor.checked.501
local.descriptor.checked.501:
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %descriptor.element.521 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.522 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.521, i32 0, i32 0
  store i32 41, ptr %descriptor.field.522, align 4
  %descriptor.field.523 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.521, i32 0, i32 1
  store i32 %context.value.429, ptr %descriptor.field.523, align 4
  %descriptor.field.524 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.521, i32 0, i32 2
  store i32 %host.output.extent.451, ptr %descriptor.field.524, align 4
  %descriptor.field.525 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.521, i32 0, i32 3
  store i32 %host.output.payload.453, ptr %descriptor.field.525, align 4
  %descriptor.field.526 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.521, i32 0, i32 4
  store i32 %stack.offset.457, ptr %descriptor.field.526, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 41, i32 %context.value.429, i32 20, i32 %host.output.payload.453, i32 %stack.offset.457, i32 %host.output.extent.451)
  %context.field.527 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.528 = load i32, ptr %context.field.527, align 4
  %runtime.ok.529 = icmp eq i32 %context.value.528, 0
  br i1 %runtime.ok.529, label %runtime.continue.530, label %frame.failure.0
runtime.continue.530:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.15, i32 0, i32 0, i32 0)
  %context.field.531 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.532 = load i32, ptr %context.field.531, align 4
  %context.field.533 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.534 = load i32, ptr %context.field.533, align 4
  %context.field.535 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.536 = load i32, ptr %context.field.535, align 4
  %stack.offset.537 = add i32 %context.value.17, %context.value.19
  %stack.offset.538 = add i32 %context.value.532, %context.value.534
  %stack.sub.539 = sub i32 %stack.offset.537, %stack.offset.538
  %stack.sub.540 = sub i32 %context.value.19, %context.value.534
  %stack.sub.541 = sub i32 %context.value.536, %context.value.21
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.539, i32 %stack.sub.540)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.541)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute_with_host_context(ptr %ctx, ptr %provider.context, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  %entry.input.descriptors.18 = alloca [2 x %AlOwningDescriptor], align 4
  %input.payload.pointer.28 = alloca i32, align 4
  %input.measured.extent.pointer.29 = alloca i32, align 4
  %input.payload.pointer.48 = alloca i32, align 4
  %input.measured.extent.pointer.49 = alloca i32, align 4
  %entry.output.descriptors.95 = alloca [1 x %AlOwningDescriptor], align 4
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.host.context.present.7 = icmp ne ptr %provider.context, null
  br i1 %entry.host.context.present.7, label %entry.host.context.ok.8, label %entry.host.context.missing.9
entry.host.context.missing.9:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 17, i32 0, i32 0)
  br label %entry.failure.0
entry.host.context.ok.8:
  %entry.input.count.ok.10 = icmp eq i32 %input.count, 2
  br i1 %entry.input.count.ok.10, label %entry.input.counted.11, label %entry.input.count.failure.12
entry.input.count.failure.12:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 2, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.11:
  %entry.input.extents.present.13 = icmp ne ptr %input.extents, null
  %entry.input.bytes.present.14 = icmp ne ptr %input, null
  %entry.input.pointers.present.15 = and i1 %entry.input.extents.present.13, %entry.input.bytes.present.14
  br i1 %entry.input.pointers.present.15, label %entry.input.pointers.ok.16, label %entry.input.pointers.invalid.17
entry.input.pointers.invalid.17:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 2, i32 0)
  br label %entry.failure.0
entry.input.pointers.ok.16:
  %input.extent.pointer.19 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.20 = load i32, ptr %input.extent.pointer.19, align 4
  %stack.sub.21 = sub i32 %input.bytes, 0
  %input.offset.within.bytes.22 = icmp ule i32 0, %input.bytes
  %input.extent.within.bytes.23 = icmp ule i32 %input.host.extent.20, %stack.sub.21
  %input.slice.within.bytes.24 = and i1 %input.offset.within.bytes.22, %input.extent.within.bytes.23
  br i1 %input.slice.within.bytes.24, label %input.slice.ready.25, label %input.slice.invalid.26
input.slice.invalid.26:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 18, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.25:
  %host.pointer.27 = getelementptr inbounds i8, ptr %input, i32 0
  %input.measure.status.30 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 5, ptr %host.pointer.27, i32 %input.host.extent.20, i32 0, i32 18, ptr %input.payload.pointer.28, ptr %input.measured.extent.pointer.29)
  %helper.ok.31 = icmp eq i32 %input.measure.status.30, 0
  br i1 %helper.ok.31, label %helper.continue.32, label %entry.failure.0
helper.continue.32:
  %input.measured.payload.33 = load i32, ptr %input.payload.pointer.28, align 4
  %input.measured.extent.34 = load i32, ptr %input.measured.extent.pointer.29, align 4
  %input.extent.exact.35 = icmp eq i32 %input.measured.extent.34, %input.host.extent.20
  br i1 %input.extent.exact.35, label %input.extent.exact.36, label %input.extent.invalid.37
input.extent.invalid.37:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 18, i32 %input.measured.extent.34, i32 %input.host.extent.20)
  br label %entry.failure.0
input.extent.exact.36:
  %stack.offset.38 = add i32 0, %input.host.extent.20
  %input.extent.pointer.39 = getelementptr inbounds i32, ptr %input.extents, i32 1
  %input.host.extent.40 = load i32, ptr %input.extent.pointer.39, align 4
  %stack.sub.41 = sub i32 %input.bytes, %stack.offset.38
  %input.offset.within.bytes.42 = icmp ule i32 %stack.offset.38, %input.bytes
  %input.extent.within.bytes.43 = icmp ule i32 %input.host.extent.40, %stack.sub.41
  %input.slice.within.bytes.44 = and i1 %input.offset.within.bytes.42, %input.extent.within.bytes.43
  br i1 %input.slice.within.bytes.44, label %input.slice.ready.45, label %input.slice.invalid.46
input.slice.invalid.46:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 19, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.45:
  %host.pointer.47 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.38
  %input.measure.status.50 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 2, ptr %host.pointer.47, i32 %input.host.extent.40, i32 0, i32 19, ptr %input.payload.pointer.48, ptr %input.measured.extent.pointer.49)
  %helper.ok.51 = icmp eq i32 %input.measure.status.50, 0
  br i1 %helper.ok.51, label %helper.continue.52, label %entry.failure.0
helper.continue.52:
  %input.measured.payload.53 = load i32, ptr %input.payload.pointer.48, align 4
  %input.measured.extent.54 = load i32, ptr %input.measured.extent.pointer.49, align 4
  %input.extent.exact.55 = icmp eq i32 %input.measured.extent.54, %input.host.extent.40
  br i1 %input.extent.exact.55, label %input.extent.exact.56, label %input.extent.invalid.57
input.extent.invalid.57:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 19, i32 %input.measured.extent.54, i32 %input.host.extent.40)
  br label %entry.failure.0
input.extent.exact.56:
  %stack.offset.58 = add i32 %stack.offset.38, %input.host.extent.40
  %input.total.exact.59 = icmp eq i32 %stack.offset.58, %input.bytes
  br i1 %input.total.exact.59, label %input.valid.60, label %input.invalid.61
input.invalid.61:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.58, i32 %input.bytes)
  br label %entry.failure.0
input.valid.60:
  %reserve.status.62 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.58, i32 20)
  %reserve.ok.63 = icmp eq i32 %reserve.status.62, 0
  br i1 %reserve.ok.63, label %reserve.continue.64, label %entry.failure.0
reserve.continue.64:
  %host.pointer.65 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.66 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.65, i32 %input.host.extent.20, i32 0, i32 %input.measured.payload.33, i32 %input.host.extent.20, i32 37, i32 21)
  %helper.ok.67 = icmp eq i32 %input.copy.status.66, 0
  br i1 %helper.ok.67, label %helper.continue.68, label %entry.failure.0
helper.continue.68:
  %stack.offset.69 = add i32 0, %input.host.extent.20
  %descriptor.element.70 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.18, i32 0
  %descriptor.field.71 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.70, i32 0, i32 0
  store i32 37, ptr %descriptor.field.71, align 4
  %descriptor.field.72 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.70, i32 0, i32 1
  store i32 0, ptr %descriptor.field.72, align 4
  %descriptor.field.73 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.70, i32 0, i32 2
  store i32 %input.host.extent.20, ptr %descriptor.field.73, align 4
  %descriptor.field.74 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.70, i32 0, i32 3
  store i32 %input.measured.payload.33, ptr %descriptor.field.74, align 4
  %descriptor.field.75 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.70, i32 0, i32 4
  store i32 %stack.offset.69, ptr %descriptor.field.75, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 37, i32 0, i32 20, i32 %input.measured.payload.33, i32 %stack.offset.69, i32 %input.host.extent.20)
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %runtime.ok.78 = icmp eq i32 %context.value.77, 0
  br i1 %runtime.ok.78, label %runtime.continue.79, label %entry.failure.0
runtime.continue.79:
  %host.pointer.80 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.38
  %input.copy.status.81 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.38, ptr %host.pointer.80, i32 %input.host.extent.40, i32 0, i32 %input.measured.payload.53, i32 %input.host.extent.40, i32 27, i32 22)
  %helper.ok.82 = icmp eq i32 %input.copy.status.81, 0
  br i1 %helper.ok.82, label %helper.continue.83, label %entry.failure.0
helper.continue.83:
  %stack.offset.84 = add i32 %stack.offset.38, %input.host.extent.40
  %descriptor.element.85 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.18, i32 1
  %descriptor.field.86 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.85, i32 0, i32 0
  store i32 27, ptr %descriptor.field.86, align 4
  %descriptor.field.87 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.85, i32 0, i32 1
  store i32 %stack.offset.38, ptr %descriptor.field.87, align 4
  %descriptor.field.88 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.85, i32 0, i32 2
  store i32 %input.host.extent.40, ptr %descriptor.field.88, align 4
  %descriptor.field.89 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.85, i32 0, i32 3
  store i32 %input.measured.payload.53, ptr %descriptor.field.89, align 4
  %descriptor.field.90 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.85, i32 0, i32 4
  store i32 %stack.offset.84, ptr %descriptor.field.90, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 27, i32 %stack.offset.38, i32 20, i32 %input.measured.payload.53, i32 %stack.offset.84, i32 %input.host.extent.40)
  %context.field.91 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.92 = load i32, ptr %context.field.91, align 4
  %runtime.ok.93 = icmp eq i32 %context.value.92, 0
  br i1 %runtime.ok.93, label %runtime.continue.94, label %entry.failure.0
runtime.continue.94:
  %entry.body.status.96 = call i32 @agentlang_entry_frame(ptr %ctx, ptr %provider.context, ptr %entry.input.descriptors.18, ptr %entry.output.descriptors.95, i32 23)
  %entry.body.ok.97 = icmp eq i32 %entry.body.status.96, 0
  br i1 %entry.body.ok.97, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.98 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.95, i32 0
  %descriptor.field.99 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.98, i32 0, i32 0
  %descriptor.value.100 = load i32, ptr %descriptor.field.99, align 4
  %descriptor.field.101 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.98, i32 0, i32 1
  %descriptor.value.102 = load i32, ptr %descriptor.field.101, align 4
  %descriptor.field.103 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.98, i32 0, i32 2
  %descriptor.value.104 = load i32, ptr %descriptor.field.103, align 4
  %descriptor.field.105 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.98, i32 0, i32 3
  %descriptor.value.106 = load i32, ptr %descriptor.field.105, align 4
  %descriptor.field.107 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.98, i32 0, i32 4
  %descriptor.value.108 = load i32, ptr %descriptor.field.107, align 4
  %entry.output.type.valid.109 = icmp eq i32 %descriptor.value.100, 41
  br i1 %entry.output.type.valid.109, label %entry.output.type.ok.110, label %entry.output.type.invalid.111
entry.output.type.invalid.111:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.110:
  %context.field.112 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.113 = load i32, ptr %context.field.112, align 4
  %stack.sub.116 = sub i32 %descriptor.value.108, %descriptor.value.102
  %descriptor.owner.inside.114 = icmp ule i32 %descriptor.value.108, %context.value.113
  %descriptor.offset.inside.115 = icmp ule i32 %descriptor.value.102, %descriptor.value.108
  %descriptor.extent.inside.117 = icmp ule i32 %descriptor.value.104, %stack.sub.116
  %descriptor.payload.inside.118 = icmp ule i32 %descriptor.value.106, %descriptor.value.104
  %descriptor.owner.offset.valid.119 = and i1 %descriptor.owner.inside.114, %descriptor.offset.inside.115
  %descriptor.range.inside.121 = and i1 %descriptor.owner.offset.valid.119, %descriptor.extent.inside.117
  %descriptor.range.valid.120 = and i1 %descriptor.range.inside.121, %descriptor.payload.inside.118
  %descriptor.type.valid.122 = icmp eq i32 41, 41
  %descriptor.valid.123 = and i1 %descriptor.range.valid.120, %descriptor.type.valid.122
  br i1 %descriptor.valid.123, label %descriptor.valid.124, label %descriptor.invalid.125
descriptor.invalid.125:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.124:
  %descriptor.initialized.status.126 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.102, i32 %descriptor.value.104)
  %helper.ok.127 = icmp eq i32 %descriptor.initialized.status.126, 0
  br i1 %helper.ok.127, label %helper.continue.128, label %entry.failure.0
helper.continue.128:
  %entry.output.size.i64.129 = zext i32 %descriptor.value.104 to i64
  %entry.output.total.i64.130 = add i64 0, %entry.output.size.i64.129
  %entry.retained.capacity.i64.131 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.132 = icmp ule i64 %entry.output.total.i64.130, 4294967295
  %entry.retained.required.truncated.133 = trunc i64 %entry.output.total.i64.130 to i32
  %entry.retained.required.134 = select i1 %entry.retained.required.fits.u32.132, i32 %entry.retained.required.truncated.133, i32 4294967295
  %entry.retained.capacity.ok.135 = icmp ule i64 %entry.output.total.i64.130, %entry.retained.capacity.i64.131
  br i1 %entry.retained.capacity.ok.135, label %entry.retained.capacity.ready.136, label %entry.retained.capacity.failure.137
entry.retained.capacity.failure.137:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.134, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.136:
  %host.pointer.138 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.139 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.138, i32 %stack.sub.139, i32 %descriptor.value.102, i32 %descriptor.value.104, i32 41)
  %context.field.140 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.141 = load i32, ptr %context.field.140, align 4
  %runtime.ok.142 = icmp eq i32 %context.value.141, 0
  br i1 %runtime.ok.142, label %runtime.continue.143, label %entry.failure.0
runtime.continue.143:
  %stack.offset.144 = add i32 0, %descriptor.value.104
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.145 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.146 = load i32, ptr %context.field.145, align 4
  %context.field.147 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.148 = load i32, ptr %context.field.147, align 4
  %stack.sub.149 = sub i32 0, %context.value.146
  %stack.sub.150 = sub i32 0, %context.value.148
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.149, i32 %stack.sub.150)
  %context.field.151 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.152 = load i32, ptr %context.field.151, align 4
  %runtime.ok.153 = icmp eq i32 %context.value.152, 0
  br i1 %runtime.ok.153, label %runtime.continue.154, label %entry.failure.0
runtime.continue.154:
  br label %entry.return.status
entry.failure.0:
  %context.field.155 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.156 = load i32, ptr %context.field.155, align 4
  %context.field.157 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.158 = load i32, ptr %context.field.157, align 4
  %context.field.159 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.160 = load i32, ptr %context.field.159, align 4
  %stack.offset.161 = add i32 %context.value.156, %context.value.158
  %stack.sub.162 = sub i32 0, %stack.offset.161
  %stack.sub.163 = sub i32 0, %context.value.158
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.162, i32 %stack.sub.163)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.160)
  br label %entry.return.status
entry.return.status:
  %context.field.164 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.165 = load i32, ptr %context.field.164, align 4
  ret i32 %context.value.165
}


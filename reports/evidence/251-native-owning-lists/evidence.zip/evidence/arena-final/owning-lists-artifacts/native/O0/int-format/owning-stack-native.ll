%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [2 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 9, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }], align 4
@al_owning_fields = private constant [1 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 0, i32 0, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 5, ptr @al_owning_types, i32 2, ptr @al_owning_fields, i32 0 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_locate_sum_case(ptr, ptr, i32, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_float_format(ptr, i64, ptr, ptr, i32)
declare i32 @al_owning_ascii_string_write(ptr, i32, i32, ptr, i32, i32, i32)
declare i32 @al_owning_int_format(ptr, i64, ptr, ptr, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal_typed(ptr, ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %call.arguments.46 = alloca [1 x %AlOwningDescriptor], align 4
  %call.results.57 = alloca [1 x %AlOwningDescriptor], align 4
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 1
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 1, 1
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %step.status.43 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.44 = icmp eq i32 %step.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %frame.failure.0
helper.continue.45:
  %descriptor.element.47 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.46, i32 0
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 0
  store i32 1, ptr %descriptor.field.48, align 4
  %descriptor.field.49 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.49, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.50, align 4
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.51, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.52, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.53 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.54 = load i32, ptr %context.field.53, align 4
  %runtime.ok.55 = icmp eq i32 %context.value.54, 0
  br i1 %runtime.ok.55, label %runtime.continue.56, label %frame.failure.0
runtime.continue.56:
  %callee.status.58 = call i32 @agentlang_word_0000(ptr %ctx, ptr %call.arguments.46, ptr %call.results.57, i32 2)
  %helper.ok.59 = icmp eq i32 %callee.status.58, 0
  br i1 %helper.ok.59, label %helper.continue.60, label %frame.failure.0
helper.continue.60:
  %descriptor.element.61 = getelementptr inbounds %AlOwningDescriptor, ptr %call.results.57, i32 0
  %descriptor.field.62 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 0
  %descriptor.value.63 = load i32, ptr %descriptor.field.62, align 4
  %descriptor.field.64 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 1
  %descriptor.value.65 = load i32, ptr %descriptor.field.64, align 4
  %descriptor.field.66 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 2
  %descriptor.value.67 = load i32, ptr %descriptor.field.66, align 4
  %descriptor.field.68 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 3
  %descriptor.value.69 = load i32, ptr %descriptor.field.68, align 4
  %descriptor.field.70 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 4
  %descriptor.value.71 = load i32, ptr %descriptor.field.70, align 4
  %callee.result.type.valid.72 = icmp eq i32 %descriptor.value.63, 9
  br i1 %callee.result.type.valid.72, label %callee.result.type.ok.73, label %frame.failure.0
callee.result.type.ok.73:
  %context.field.74 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.75 = load i32, ptr %context.field.74, align 4
  %stack.sub.78 = sub i32 %descriptor.value.71, %descriptor.value.65
  %descriptor.owner.inside.76 = icmp ule i32 %descriptor.value.71, %context.value.75
  %descriptor.offset.inside.77 = icmp ule i32 %descriptor.value.65, %descriptor.value.71
  %descriptor.extent.inside.79 = icmp ule i32 %descriptor.value.67, %stack.sub.78
  %descriptor.payload.inside.80 = icmp ule i32 %descriptor.value.69, %descriptor.value.67
  %descriptor.owner.offset.valid.81 = and i1 %descriptor.owner.inside.76, %descriptor.offset.inside.77
  %descriptor.range.inside.83 = and i1 %descriptor.owner.offset.valid.81, %descriptor.extent.inside.79
  %descriptor.range.valid.82 = and i1 %descriptor.range.inside.83, %descriptor.payload.inside.80
  %descriptor.type.valid.84 = icmp eq i32 9, 9
  %descriptor.valid.85 = and i1 %descriptor.range.valid.82, %descriptor.type.valid.84
  br i1 %descriptor.valid.85, label %descriptor.valid.86, label %descriptor.invalid.87
descriptor.invalid.87:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.86:
  %descriptor.initialized.status.88 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.65, i32 %descriptor.value.67)
  %helper.ok.89 = icmp eq i32 %descriptor.initialized.status.88, 0
  br i1 %helper.ok.89, label %helper.continue.90, label %frame.failure.0
helper.continue.90:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 9, i32 %descriptor.value.65, i32 20, i32 %descriptor.value.69, i32 %descriptor.value.71, i32 %descriptor.value.67)
  %context.field.91 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.92 = load i32, ptr %context.field.91, align 4
  %runtime.ok.93 = icmp eq i32 %context.value.92, 0
  br i1 %runtime.ok.93, label %runtime.continue.94, label %frame.failure.0
runtime.continue.94:
  %context.field.95 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.96 = load i32, ptr %context.field.95, align 4
  %stack.sub.99 = sub i32 %descriptor.value.71, %descriptor.value.65
  %descriptor.owner.inside.97 = icmp ule i32 %descriptor.value.71, %context.value.96
  %descriptor.offset.inside.98 = icmp ule i32 %descriptor.value.65, %descriptor.value.71
  %descriptor.extent.inside.100 = icmp ule i32 %descriptor.value.67, %stack.sub.99
  %descriptor.payload.inside.101 = icmp ule i32 %descriptor.value.69, %descriptor.value.67
  %descriptor.owner.offset.valid.102 = and i1 %descriptor.owner.inside.97, %descriptor.offset.inside.98
  %descriptor.range.inside.104 = and i1 %descriptor.owner.offset.valid.102, %descriptor.extent.inside.100
  %descriptor.range.valid.103 = and i1 %descriptor.range.inside.104, %descriptor.payload.inside.101
  %descriptor.type.valid.105 = icmp eq i32 9, 9
  %descriptor.valid.106 = and i1 %descriptor.range.valid.103, %descriptor.type.valid.105
  br i1 %descriptor.valid.106, label %descriptor.valid.107, label %descriptor.invalid.108
descriptor.invalid.108:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.107:
  %descriptor.initialized.status.109 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.65, i32 %descriptor.value.67)
  %helper.ok.110 = icmp eq i32 %descriptor.initialized.status.109, 0
  br i1 %helper.ok.110, label %helper.continue.111, label %frame.failure.0
helper.continue.111:
  %descriptor.element.112 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.113 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 0
  store i32 9, ptr %descriptor.field.113, align 4
  %descriptor.field.114 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 1
  store i32 %descriptor.value.65, ptr %descriptor.field.114, align 4
  %descriptor.field.115 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 2
  store i32 %descriptor.value.67, ptr %descriptor.field.115, align 4
  %descriptor.field.116 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 3
  store i32 %descriptor.value.69, ptr %descriptor.field.116, align 4
  %descriptor.field.117 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 4
  store i32 %descriptor.value.71, ptr %descriptor.field.117, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 9, i32 %descriptor.value.65, i32 20, i32 %descriptor.value.69, i32 %descriptor.value.71, i32 %descriptor.value.67)
  %context.field.118 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.119 = load i32, ptr %context.field.118, align 4
  %runtime.ok.120 = icmp eq i32 %context.value.119, 0
  br i1 %runtime.ok.120, label %runtime.continue.121, label %frame.failure.0
runtime.continue.121:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.122 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.123 = load i32, ptr %context.field.122, align 4
  %context.field.124 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.125 = load i32, ptr %context.field.124, align 4
  %context.field.126 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.127 = load i32, ptr %context.field.126, align 4
  %stack.offset.128 = add i32 %context.value.5, %context.value.7
  %stack.offset.129 = add i32 %context.value.123, %context.value.125
  %stack.sub.130 = sub i32 %stack.offset.128, %stack.offset.129
  %stack.sub.131 = sub i32 %context.value.7, %context.value.125
  %stack.sub.132 = sub i32 %context.value.127, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.130, i32 %stack.sub.131)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.132)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %local.active.2 = alloca i1, align 1
  %local.offset.3 = alloca i32, align 4
  %local.extent.4 = alloca i32, align 4
  %local.payload.5 = alloca i32, align 4
  %local.owner.end.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  %int.to.string.ascii.buffer.160 = alloca [32 x i8], align 1
  %int.to.string.length.pointer.162 = alloca i32, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %context.field.14 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.15 = load i32, ptr %context.field.14, align 4
  %frame.entered.16 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.17 = icmp eq i32 %frame.entered.16, 0
  br i1 %frame.enter.ok.17, label %frame.enter.continue.18, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.18:
  %descriptor.element.19 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 0
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 1
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %descriptor.field.24 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 2
  %descriptor.value.25 = load i32, ptr %descriptor.field.24, align 4
  %descriptor.field.26 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 3
  %descriptor.value.27 = load i32, ptr %descriptor.field.26, align 4
  %descriptor.field.28 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 4
  %descriptor.value.29 = load i32, ptr %descriptor.field.28, align 4
  %argument.type.valid.30 = icmp eq i32 %descriptor.value.21, 1
  br i1 %argument.type.valid.30, label %argument.type.ok.31, label %frame.failure.0
argument.type.ok.31:
  %context.field.32 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.33 = load i32, ptr %context.field.32, align 4
  %stack.sub.36 = sub i32 %descriptor.value.29, %descriptor.value.23
  %descriptor.owner.inside.34 = icmp ule i32 %descriptor.value.29, %context.value.33
  %descriptor.offset.inside.35 = icmp ule i32 %descriptor.value.23, %descriptor.value.29
  %descriptor.extent.inside.37 = icmp ule i32 %descriptor.value.25, %stack.sub.36
  %descriptor.payload.inside.38 = icmp ule i32 %descriptor.value.27, %descriptor.value.25
  %descriptor.owner.offset.valid.39 = and i1 %descriptor.owner.inside.34, %descriptor.offset.inside.35
  %descriptor.range.inside.41 = and i1 %descriptor.owner.offset.valid.39, %descriptor.extent.inside.37
  %descriptor.range.valid.40 = and i1 %descriptor.range.inside.41, %descriptor.payload.inside.38
  %descriptor.type.valid.42 = icmp eq i32 1, 1
  %descriptor.valid.43 = and i1 %descriptor.range.valid.40, %descriptor.type.valid.42
  br i1 %descriptor.valid.43, label %descriptor.valid.44, label %descriptor.invalid.45
descriptor.invalid.45:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.44:
  %descriptor.initialized.status.46 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.23, i32 %descriptor.value.25)
  %helper.ok.47 = icmp eq i32 %descriptor.initialized.status.46, 0
  br i1 %helper.ok.47, label %helper.continue.48, label %frame.failure.0
helper.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %helper.ok.50, label %helper.continue.51, label %frame.failure.0
helper.continue.51:
  store i1 true, ptr %local.active.2, align 1
  store i32 %descriptor.value.23, ptr %local.offset.3, align 4
  store i32 %descriptor.value.25, ptr %local.extent.4, align 4
  store i32 %descriptor.value.27, ptr %local.payload.5, align 4
  store i32 %descriptor.value.29, ptr %local.owner.end.6, align 4
  store i32 1, ptr %local.type.7, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %descriptor.value.23, i32 20, i32 %descriptor.value.27, i32 %descriptor.value.29, i32 %descriptor.value.25)
  %context.field.52 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.53 = load i32, ptr %context.field.52, align 4
  %runtime.ok.54 = icmp eq i32 %context.value.53, 0
  br i1 %runtime.ok.54, label %runtime.continue.55, label %frame.failure.0
runtime.continue.55:
  %local.is.active.56 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.56, label %local.descriptor.active.57, label %local.descriptor.inactive.58
local.descriptor.active.57:
  %local.check.offset.60 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.61 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.62 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.63 = load i32, ptr %local.owner.end.6, align 4
  %context.field.64 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.65 = load i32, ptr %context.field.64, align 4
  %stack.sub.68 = sub i32 %local.check.owner.end.63, %local.check.offset.60
  %descriptor.owner.inside.66 = icmp ule i32 %local.check.owner.end.63, %context.value.65
  %descriptor.offset.inside.67 = icmp ule i32 %local.check.offset.60, %local.check.owner.end.63
  %descriptor.extent.inside.69 = icmp ule i32 %local.check.extent.61, %stack.sub.68
  %descriptor.payload.inside.70 = icmp ule i32 %local.check.payload.62, %local.check.extent.61
  %descriptor.owner.offset.valid.71 = and i1 %descriptor.owner.inside.66, %descriptor.offset.inside.67
  %descriptor.range.inside.73 = and i1 %descriptor.owner.offset.valid.71, %descriptor.extent.inside.69
  %descriptor.range.valid.72 = and i1 %descriptor.range.inside.73, %descriptor.payload.inside.70
  br i1 %descriptor.range.valid.72, label %descriptor.valid.74, label %descriptor.invalid.75
descriptor.invalid.75:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.74:
  %descriptor.initialized.status.76 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.60, i32 %local.check.extent.61)
  %helper.ok.77 = icmp eq i32 %descriptor.initialized.status.76, 0
  br i1 %helper.ok.77, label %helper.continue.78, label %frame.failure.0
helper.continue.78:
  br label %local.descriptor.checked.59
local.descriptor.inactive.58:
  br label %local.descriptor.checked.59
local.descriptor.checked.59:
  %step.status.79 = call i32 @al_owning_charge_step(ptr %ctx, i32 4)
  %helper.ok.80 = icmp eq i32 %step.status.79, 0
  br i1 %helper.ok.80, label %helper.continue.81, label %frame.failure.0
helper.continue.81:
  %local.resolved.offset.82 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.83 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.84 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.85 = load i32, ptr %local.owner.end.6, align 4
  %context.field.86 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.87 = load i32, ptr %context.field.86, align 4
  %stack.sub.90 = sub i32 %local.resolved.owner.end.85, %local.resolved.offset.82
  %descriptor.owner.inside.88 = icmp ule i32 %local.resolved.owner.end.85, %context.value.87
  %descriptor.offset.inside.89 = icmp ule i32 %local.resolved.offset.82, %local.resolved.owner.end.85
  %descriptor.extent.inside.91 = icmp ule i32 %local.resolved.extent.83, %stack.sub.90
  %descriptor.payload.inside.92 = icmp ule i32 %local.resolved.payload.84, %local.resolved.extent.83
  %descriptor.owner.offset.valid.93 = and i1 %descriptor.owner.inside.88, %descriptor.offset.inside.89
  %descriptor.range.inside.95 = and i1 %descriptor.owner.offset.valid.93, %descriptor.extent.inside.91
  %descriptor.range.valid.94 = and i1 %descriptor.range.inside.95, %descriptor.payload.inside.92
  %descriptor.type.valid.96 = icmp eq i32 1, 1
  %descriptor.valid.97 = and i1 %descriptor.range.valid.94, %descriptor.type.valid.96
  br i1 %descriptor.valid.97, label %descriptor.valid.98, label %descriptor.invalid.99
descriptor.invalid.99:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.98:
  %descriptor.initialized.status.100 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.82, i32 %local.resolved.extent.83)
  %helper.ok.101 = icmp eq i32 %descriptor.initialized.status.100, 0
  br i1 %helper.ok.101, label %helper.continue.102, label %frame.failure.0
helper.continue.102:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %local.resolved.offset.82, i32 20, i32 %local.resolved.payload.84, i32 %local.resolved.owner.end.85, i32 %local.resolved.extent.83)
  %context.field.103 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.104 = load i32, ptr %context.field.103, align 4
  %runtime.ok.105 = icmp eq i32 %context.value.104, 0
  br i1 %runtime.ok.105, label %runtime.continue.106, label %frame.failure.0
runtime.continue.106:
  %context.field.107 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.108 = load i32, ptr %context.field.107, align 4
  %stack.sub.111 = sub i32 %local.resolved.owner.end.85, %local.resolved.offset.82
  %descriptor.owner.inside.109 = icmp ule i32 %local.resolved.owner.end.85, %context.value.108
  %descriptor.offset.inside.110 = icmp ule i32 %local.resolved.offset.82, %local.resolved.owner.end.85
  %descriptor.extent.inside.112 = icmp ule i32 %local.resolved.extent.83, %stack.sub.111
  %descriptor.payload.inside.113 = icmp ule i32 %local.resolved.payload.84, %local.resolved.extent.83
  %descriptor.owner.offset.valid.114 = and i1 %descriptor.owner.inside.109, %descriptor.offset.inside.110
  %descriptor.range.inside.116 = and i1 %descriptor.owner.offset.valid.114, %descriptor.extent.inside.112
  %descriptor.range.valid.115 = and i1 %descriptor.range.inside.116, %descriptor.payload.inside.113
  %descriptor.type.valid.117 = icmp eq i32 1, 1
  %descriptor.valid.118 = and i1 %descriptor.range.valid.115, %descriptor.type.valid.117
  br i1 %descriptor.valid.118, label %descriptor.valid.119, label %descriptor.invalid.120
descriptor.invalid.120:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.119:
  %descriptor.initialized.status.121 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.82, i32 %local.resolved.extent.83)
  %helper.ok.122 = icmp eq i32 %descriptor.initialized.status.121, 0
  br i1 %helper.ok.122, label %helper.continue.123, label %frame.failure.0
helper.continue.123:
  %local.is.active.124 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.124, label %local.descriptor.active.125, label %local.descriptor.inactive.126
local.descriptor.active.125:
  %local.check.offset.128 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.129 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.130 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.131 = load i32, ptr %local.owner.end.6, align 4
  %context.field.132 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.133 = load i32, ptr %context.field.132, align 4
  %stack.sub.136 = sub i32 %local.check.owner.end.131, %local.check.offset.128
  %descriptor.owner.inside.134 = icmp ule i32 %local.check.owner.end.131, %context.value.133
  %descriptor.offset.inside.135 = icmp ule i32 %local.check.offset.128, %local.check.owner.end.131
  %descriptor.extent.inside.137 = icmp ule i32 %local.check.extent.129, %stack.sub.136
  %descriptor.payload.inside.138 = icmp ule i32 %local.check.payload.130, %local.check.extent.129
  %descriptor.owner.offset.valid.139 = and i1 %descriptor.owner.inside.134, %descriptor.offset.inside.135
  %descriptor.range.inside.141 = and i1 %descriptor.owner.offset.valid.139, %descriptor.extent.inside.137
  %descriptor.range.valid.140 = and i1 %descriptor.range.inside.141, %descriptor.payload.inside.138
  br i1 %descriptor.range.valid.140, label %descriptor.valid.142, label %descriptor.invalid.143
descriptor.invalid.143:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.142:
  %descriptor.initialized.status.144 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.128, i32 %local.check.extent.129)
  %helper.ok.145 = icmp eq i32 %descriptor.initialized.status.144, 0
  br i1 %helper.ok.145, label %helper.continue.146, label %frame.failure.0
helper.continue.146:
  br label %local.descriptor.checked.127
local.descriptor.inactive.126:
  br label %local.descriptor.checked.127
local.descriptor.checked.127:
  %step.status.147 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.148 = icmp eq i32 %step.status.147, 0
  br i1 %helper.ok.148, label %helper.continue.149, label %frame.failure.0
helper.continue.149:
  %context.field.150 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.151 = load i32, ptr %context.field.150, align 4
  %inline.target.depth.within.interpreter.limit.152 = icmp ule i32 %context.value.151, 65
  br i1 %inline.target.depth.within.interpreter.limit.152, label %inline.target.depth.ok.153, label %inline.target.depth.invalid.154
inline.target.depth.invalid.154:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 6, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.153:
  %int.to.string.input.155 = call i64 @al_owning_load_i64(ptr %ctx, i32 %local.resolved.offset.82)
  %context.field.156 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.157 = load i32, ptr %context.field.156, align 4
  %runtime.ok.158 = icmp eq i32 %context.value.157, 0
  br i1 %runtime.ok.158, label %runtime.continue.159, label %frame.failure.0
runtime.continue.159:
  %int.to.string.ascii.161 = getelementptr inbounds [32 x i8], ptr %int.to.string.ascii.buffer.160, i64 0, i64 0
  %int.to.string.format.status.163 = call i32 @al_owning_int_format(ptr %ctx, i64 %int.to.string.input.155, ptr %int.to.string.ascii.161, ptr %int.to.string.length.pointer.162, i32 7)
  %helper.ok.164 = icmp eq i32 %int.to.string.format.status.163, 0
  br i1 %helper.ok.164, label %helper.continue.165, label %frame.failure.0
helper.continue.165:
  %int.to.string.length.166 = load i32, ptr %int.to.string.length.pointer.162, align 4
  %int.to.string.length.nonempty.167 = icmp uge i32 %int.to.string.length.166, 1
  %int.to.string.length.within.bound.168 = icmp ule i32 %int.to.string.length.166, 20
  %int.to.string.length.valid.169 = and i1 %int.to.string.length.nonempty.167, %int.to.string.length.within.bound.168
  br i1 %int.to.string.length.valid.169, label %int.to.string.length.ready.171, label %int.to.string.length.failure.170
int.to.string.length.failure.170:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 8, i32 %int.to.string.length.166, i32 20)
  br label %frame.failure.0
int.to.string.length.ready.171:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %local.resolved.offset.82, i32 %local.resolved.extent.83, i32 %local.resolved.payload.84, i32 0, i32 0)
  %context.field.172 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.173 = load i32, ptr %context.field.172, align 4
  %runtime.ok.174 = icmp eq i32 %context.value.173, 0
  br i1 %runtime.ok.174, label %runtime.continue.175, label %frame.failure.0
runtime.continue.175:
  %int.to.string.utf16.length.176 = mul i32 %int.to.string.length.166, 2
  %int.to.string.payload.177 = add i32 %int.to.string.utf16.length.176, 8
  %int.to.string.payload.with.padding.178 = add i32 %int.to.string.payload.177, 7
  %int.to.string.extent.179 = and i32 %int.to.string.payload.with.padding.178, -8
  %context.field.180 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.181 = load i32, ptr %context.field.180, align 4
  %stack.offset.182 = add i32 %context.value.181, %int.to.string.extent.179
  %reserve.status.183 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.182, i32 9)
  %reserve.ok.184 = icmp eq i32 %reserve.status.183, 0
  br i1 %reserve.ok.184, label %reserve.continue.185, label %frame.failure.0
reserve.continue.185:
  %int.to.string.write.status.186 = call i32 @al_owning_ascii_string_write(ptr %ctx, i32 %context.value.181, i32 %int.to.string.extent.179, ptr %int.to.string.ascii.161, i32 %int.to.string.length.166, i32 9, i32 10)
  %helper.ok.187 = icmp eq i32 %int.to.string.write.status.186, 0
  br i1 %helper.ok.187, label %helper.continue.188, label %frame.failure.0
helper.continue.188:
  call void @al_owning_update_live(ptr %ctx, i32 %int.to.string.payload.177, i32 0)
  %context.field.189 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.190 = load i32, ptr %context.field.189, align 4
  %runtime.ok.191 = icmp eq i32 %context.value.190, 0
  br i1 %runtime.ok.191, label %runtime.continue.192, label %frame.failure.0
runtime.continue.192:
  %context.field.193 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.194 = load i32, ptr %context.field.193, align 4
  %stack.sub.197 = sub i32 %stack.offset.182, %context.value.181
  %descriptor.owner.inside.195 = icmp ule i32 %stack.offset.182, %context.value.194
  %descriptor.offset.inside.196 = icmp ule i32 %context.value.181, %stack.offset.182
  %descriptor.extent.inside.198 = icmp ule i32 %int.to.string.extent.179, %stack.sub.197
  %descriptor.payload.inside.199 = icmp ule i32 %int.to.string.payload.177, %int.to.string.extent.179
  %descriptor.owner.offset.valid.200 = and i1 %descriptor.owner.inside.195, %descriptor.offset.inside.196
  %descriptor.range.inside.202 = and i1 %descriptor.owner.offset.valid.200, %descriptor.extent.inside.198
  %descriptor.range.valid.201 = and i1 %descriptor.range.inside.202, %descriptor.payload.inside.199
  %descriptor.type.valid.203 = icmp eq i32 9, 9
  %descriptor.valid.204 = and i1 %descriptor.range.valid.201, %descriptor.type.valid.203
  br i1 %descriptor.valid.204, label %descriptor.valid.205, label %descriptor.invalid.206
descriptor.invalid.206:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.205:
  %descriptor.initialized.status.207 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.181, i32 %int.to.string.extent.179)
  %helper.ok.208 = icmp eq i32 %descriptor.initialized.status.207, 0
  br i1 %helper.ok.208, label %helper.continue.209, label %frame.failure.0
helper.continue.209:
  %local.is.active.210 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.210, label %local.descriptor.active.211, label %local.descriptor.inactive.212
local.descriptor.active.211:
  %local.check.offset.214 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.215 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.216 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.217 = load i32, ptr %local.owner.end.6, align 4
  %context.field.218 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.219 = load i32, ptr %context.field.218, align 4
  %stack.sub.222 = sub i32 %local.check.owner.end.217, %local.check.offset.214
  %descriptor.owner.inside.220 = icmp ule i32 %local.check.owner.end.217, %context.value.219
  %descriptor.offset.inside.221 = icmp ule i32 %local.check.offset.214, %local.check.owner.end.217
  %descriptor.extent.inside.223 = icmp ule i32 %local.check.extent.215, %stack.sub.222
  %descriptor.payload.inside.224 = icmp ule i32 %local.check.payload.216, %local.check.extent.215
  %descriptor.owner.offset.valid.225 = and i1 %descriptor.owner.inside.220, %descriptor.offset.inside.221
  %descriptor.range.inside.227 = and i1 %descriptor.owner.offset.valid.225, %descriptor.extent.inside.223
  %descriptor.range.valid.226 = and i1 %descriptor.range.inside.227, %descriptor.payload.inside.224
  br i1 %descriptor.range.valid.226, label %descriptor.valid.228, label %descriptor.invalid.229
descriptor.invalid.229:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.228:
  %descriptor.initialized.status.230 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.214, i32 %local.check.extent.215)
  %helper.ok.231 = icmp eq i32 %descriptor.initialized.status.230, 0
  br i1 %helper.ok.231, label %helper.continue.232, label %frame.failure.0
helper.continue.232:
  br label %local.descriptor.checked.213
local.descriptor.inactive.212:
  br label %local.descriptor.checked.213
local.descriptor.checked.213:
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %descriptor.element.233 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.234 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.233, i32 0, i32 0
  store i32 9, ptr %descriptor.field.234, align 4
  %descriptor.field.235 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.233, i32 0, i32 1
  store i32 %context.value.181, ptr %descriptor.field.235, align 4
  %descriptor.field.236 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.233, i32 0, i32 2
  store i32 %int.to.string.extent.179, ptr %descriptor.field.236, align 4
  %descriptor.field.237 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.233, i32 0, i32 3
  store i32 %int.to.string.payload.177, ptr %descriptor.field.237, align 4
  %descriptor.field.238 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.233, i32 0, i32 4
  store i32 %stack.offset.182, ptr %descriptor.field.238, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 9, i32 %context.value.181, i32 20, i32 %int.to.string.payload.177, i32 %stack.offset.182, i32 %int.to.string.extent.179)
  %context.field.239 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.240 = load i32, ptr %context.field.239, align 4
  %runtime.ok.241 = icmp eq i32 %context.value.240, 0
  br i1 %runtime.ok.241, label %runtime.continue.242, label %frame.failure.0
runtime.continue.242:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.9, i32 0, i32 0, i32 0)
  %context.field.243 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.244 = load i32, ptr %context.field.243, align 4
  %context.field.245 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.246 = load i32, ptr %context.field.245, align 4
  %context.field.247 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.248 = load i32, ptr %context.field.247, align 4
  %stack.offset.249 = add i32 %context.value.11, %context.value.13
  %stack.offset.250 = add i32 %context.value.244, %context.value.246
  %stack.sub.251 = sub i32 %stack.offset.249, %stack.offset.250
  %stack.sub.252 = sub i32 %context.value.13, %context.value.246
  %stack.sub.253 = sub i32 %context.value.248, %context.value.15
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.251, i32 %stack.sub.252)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.253)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  %entry.input.descriptors.15 = alloca [1 x %AlOwningDescriptor], align 4
  %input.payload.pointer.25 = alloca i32, align 4
  %input.measured.extent.pointer.26 = alloca i32, align 4
  %entry.output.descriptors.57 = alloca [1 x %AlOwningDescriptor], align 4
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 1
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %entry.input.extents.present.10 = icmp ne ptr %input.extents, null
  %entry.input.bytes.present.11 = icmp ne ptr %input, null
  %entry.input.pointers.present.12 = and i1 %entry.input.extents.present.10, %entry.input.bytes.present.11
  br i1 %entry.input.pointers.present.12, label %entry.input.pointers.ok.13, label %entry.input.pointers.invalid.14
entry.input.pointers.invalid.14:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 0)
  br label %entry.failure.0
entry.input.pointers.ok.13:
  %input.extent.pointer.16 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.17 = load i32, ptr %input.extent.pointer.16, align 4
  %stack.sub.18 = sub i32 %input.bytes, 0
  %input.offset.within.bytes.19 = icmp ule i32 0, %input.bytes
  %input.extent.within.bytes.20 = icmp ule i32 %input.host.extent.17, %stack.sub.18
  %input.slice.within.bytes.21 = and i1 %input.offset.within.bytes.19, %input.extent.within.bytes.20
  br i1 %input.slice.within.bytes.21, label %input.slice.ready.22, label %input.slice.invalid.23
input.slice.invalid.23:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 11, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.22:
  %host.pointer.24 = getelementptr inbounds i8, ptr %input, i32 0
  %input.measure.status.27 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 0, ptr %host.pointer.24, i32 %input.host.extent.17, i32 0, i32 11, ptr %input.payload.pointer.25, ptr %input.measured.extent.pointer.26)
  %helper.ok.28 = icmp eq i32 %input.measure.status.27, 0
  br i1 %helper.ok.28, label %helper.continue.29, label %entry.failure.0
helper.continue.29:
  %input.measured.payload.30 = load i32, ptr %input.payload.pointer.25, align 4
  %input.measured.extent.31 = load i32, ptr %input.measured.extent.pointer.26, align 4
  %input.extent.exact.32 = icmp eq i32 %input.measured.extent.31, %input.host.extent.17
  br i1 %input.extent.exact.32, label %input.extent.exact.33, label %input.extent.invalid.34
input.extent.invalid.34:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 11, i32 %input.measured.extent.31, i32 %input.host.extent.17)
  br label %entry.failure.0
input.extent.exact.33:
  %stack.offset.35 = add i32 0, %input.host.extent.17
  %input.total.exact.36 = icmp eq i32 %stack.offset.35, %input.bytes
  br i1 %input.total.exact.36, label %input.valid.37, label %input.invalid.38
input.invalid.38:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.35, i32 %input.bytes)
  br label %entry.failure.0
input.valid.37:
  %reserve.status.39 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.35, i32 12)
  %reserve.ok.40 = icmp eq i32 %reserve.status.39, 0
  br i1 %reserve.ok.40, label %reserve.continue.41, label %entry.failure.0
reserve.continue.41:
  %host.pointer.42 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.43 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.42, i32 %input.host.extent.17, i32 0, i32 %input.measured.payload.30, i32 %input.host.extent.17, i32 1, i32 13)
  %helper.ok.44 = icmp eq i32 %input.copy.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %entry.failure.0
helper.continue.45:
  %stack.offset.46 = add i32 0, %input.host.extent.17
  %descriptor.element.47 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.15, i32 0
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 0
  store i32 1, ptr %descriptor.field.48, align 4
  %descriptor.field.49 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 1
  store i32 0, ptr %descriptor.field.49, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 2
  store i32 %input.host.extent.17, ptr %descriptor.field.50, align 4
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 3
  store i32 %input.measured.payload.30, ptr %descriptor.field.51, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 4
  store i32 %stack.offset.46, ptr %descriptor.field.52, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 0, i32 20, i32 %input.measured.payload.30, i32 %stack.offset.46, i32 %input.host.extent.17)
  %context.field.53 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.54 = load i32, ptr %context.field.53, align 4
  %runtime.ok.55 = icmp eq i32 %context.value.54, 0
  br i1 %runtime.ok.55, label %runtime.continue.56, label %entry.failure.0
runtime.continue.56:
  %entry.body.status.58 = call i32 @agentlang_entry_frame(ptr %ctx, ptr %entry.input.descriptors.15, ptr %entry.output.descriptors.57, i32 14)
  %entry.body.ok.59 = icmp eq i32 %entry.body.status.58, 0
  br i1 %entry.body.ok.59, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.60 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.57, i32 0
  %descriptor.field.61 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 0
  %descriptor.value.62 = load i32, ptr %descriptor.field.61, align 4
  %descriptor.field.63 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 1
  %descriptor.value.64 = load i32, ptr %descriptor.field.63, align 4
  %descriptor.field.65 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 2
  %descriptor.value.66 = load i32, ptr %descriptor.field.65, align 4
  %descriptor.field.67 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 3
  %descriptor.value.68 = load i32, ptr %descriptor.field.67, align 4
  %descriptor.field.69 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 4
  %descriptor.value.70 = load i32, ptr %descriptor.field.69, align 4
  %entry.output.type.valid.71 = icmp eq i32 %descriptor.value.62, 9
  br i1 %entry.output.type.valid.71, label %entry.output.type.ok.72, label %entry.output.type.invalid.73
entry.output.type.invalid.73:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.72:
  %context.field.74 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.75 = load i32, ptr %context.field.74, align 4
  %stack.sub.78 = sub i32 %descriptor.value.70, %descriptor.value.64
  %descriptor.owner.inside.76 = icmp ule i32 %descriptor.value.70, %context.value.75
  %descriptor.offset.inside.77 = icmp ule i32 %descriptor.value.64, %descriptor.value.70
  %descriptor.extent.inside.79 = icmp ule i32 %descriptor.value.66, %stack.sub.78
  %descriptor.payload.inside.80 = icmp ule i32 %descriptor.value.68, %descriptor.value.66
  %descriptor.owner.offset.valid.81 = and i1 %descriptor.owner.inside.76, %descriptor.offset.inside.77
  %descriptor.range.inside.83 = and i1 %descriptor.owner.offset.valid.81, %descriptor.extent.inside.79
  %descriptor.range.valid.82 = and i1 %descriptor.range.inside.83, %descriptor.payload.inside.80
  %descriptor.type.valid.84 = icmp eq i32 9, 9
  %descriptor.valid.85 = and i1 %descriptor.range.valid.82, %descriptor.type.valid.84
  br i1 %descriptor.valid.85, label %descriptor.valid.86, label %descriptor.invalid.87
descriptor.invalid.87:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.86:
  %descriptor.initialized.status.88 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.64, i32 %descriptor.value.66)
  %helper.ok.89 = icmp eq i32 %descriptor.initialized.status.88, 0
  br i1 %helper.ok.89, label %helper.continue.90, label %entry.failure.0
helper.continue.90:
  %entry.output.size.i64.91 = zext i32 %descriptor.value.66 to i64
  %entry.output.total.i64.92 = add i64 0, %entry.output.size.i64.91
  %entry.retained.capacity.i64.93 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.94 = icmp ule i64 %entry.output.total.i64.92, 4294967295
  %entry.retained.required.truncated.95 = trunc i64 %entry.output.total.i64.92 to i32
  %entry.retained.required.96 = select i1 %entry.retained.required.fits.u32.94, i32 %entry.retained.required.truncated.95, i32 4294967295
  %entry.retained.capacity.ok.97 = icmp ule i64 %entry.output.total.i64.92, %entry.retained.capacity.i64.93
  br i1 %entry.retained.capacity.ok.97, label %entry.retained.capacity.ready.98, label %entry.retained.capacity.failure.99
entry.retained.capacity.failure.99:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.96, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.98:
  %host.pointer.100 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.101 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.100, i32 %stack.sub.101, i32 %descriptor.value.64, i32 %descriptor.value.66, i32 9)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %entry.failure.0
runtime.continue.105:
  %stack.offset.106 = add i32 0, %descriptor.value.66
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.107 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.108 = load i32, ptr %context.field.107, align 4
  %context.field.109 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.110 = load i32, ptr %context.field.109, align 4
  %stack.sub.111 = sub i32 0, %context.value.108
  %stack.sub.112 = sub i32 0, %context.value.110
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.111, i32 %stack.sub.112)
  %context.field.113 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.114 = load i32, ptr %context.field.113, align 4
  %runtime.ok.115 = icmp eq i32 %context.value.114, 0
  br i1 %runtime.ok.115, label %runtime.continue.116, label %entry.failure.0
runtime.continue.116:
  br label %entry.return.status
entry.failure.0:
  %context.field.117 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.118 = load i32, ptr %context.field.117, align 4
  %context.field.119 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.120 = load i32, ptr %context.field.119, align 4
  %context.field.121 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.122 = load i32, ptr %context.field.121, align 4
  %stack.offset.123 = add i32 %context.value.118, %context.value.120
  %stack.sub.124 = sub i32 0, %stack.offset.123
  %stack.sub.125 = sub i32 0, %context.value.120
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.124, i32 %stack.sub.125)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.122)
  br label %entry.return.status
entry.return.status:
  %context.field.126 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.127 = load i32, ptr %context.field.126, align 4
  ret i32 %context.value.127
}


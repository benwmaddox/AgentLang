%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [5 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 2, i32 2, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 4, i32 4, i32 0, i32 1, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 4, i32 5, i32 1, i32 1, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 5, i32 6, i32 2, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }], align 4
@al_owning_fields = private constant [2 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 4, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 4, i32 0, i32 0, i32 0 }], align 4
@agentlang_owning_mailbox_layout = constant %AlOwningLayout { i32 5, ptr @al_owning_types, i32 5, ptr @al_owning_fields, i32 2 }, align 8
@al_owning_string_literal_0 = private unnamed_addr constant [16 x i8] c"\04\00\00\00\00\00\00\00\46\00\41\00\49\00\4C\00", align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_locate_sum_case(ptr, ptr, i32, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_float_format(ptr, i64, ptr, ptr, i32)
declare i32 @al_owning_ascii_string_write(ptr, i32, i32, ptr, i32, i32, i32)
declare i32 @al_owning_int_format(ptr, i64, ptr, ptr, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal_typed(ptr, ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare i32 @agentlang_owning_mailbox_preflight(ptr, ptr, i32, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @agentlang_owning_mailbox_associated_preflight(ptr, ptr, i32, ptr, i32, ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_mailbox_initialize_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %call.arguments.46 = alloca [1 x %AlOwningDescriptor], align 4
  %call.results.57 = alloca [1 x %AlOwningDescriptor], align 4
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 6
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 6, 6
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %step.status.43 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.44 = icmp eq i32 %step.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %frame.failure.0
helper.continue.45:
  %descriptor.element.47 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.46, i32 0
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 0
  store i32 6, ptr %descriptor.field.48, align 4
  %descriptor.field.49 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.49, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.50, align 4
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.51, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.52, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.53 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.54 = load i32, ptr %context.field.53, align 4
  %runtime.ok.55 = icmp eq i32 %context.value.54, 0
  br i1 %runtime.ok.55, label %runtime.continue.56, label %frame.failure.0
runtime.continue.56:
  %callee.status.58 = call i32 @agentlang_word_0001(ptr %ctx, ptr %call.arguments.46, ptr %call.results.57, i32 2)
  %helper.ok.59 = icmp eq i32 %callee.status.58, 0
  br i1 %helper.ok.59, label %helper.continue.60, label %frame.failure.0
helper.continue.60:
  %descriptor.element.61 = getelementptr inbounds %AlOwningDescriptor, ptr %call.results.57, i32 0
  %descriptor.field.62 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 0
  %descriptor.value.63 = load i32, ptr %descriptor.field.62, align 4
  %descriptor.field.64 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 1
  %descriptor.value.65 = load i32, ptr %descriptor.field.64, align 4
  %descriptor.field.66 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 2
  %descriptor.value.67 = load i32, ptr %descriptor.field.66, align 4
  %descriptor.field.68 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 3
  %descriptor.value.69 = load i32, ptr %descriptor.field.68, align 4
  %descriptor.field.70 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 4
  %descriptor.value.71 = load i32, ptr %descriptor.field.70, align 4
  %callee.result.type.valid.72 = icmp eq i32 %descriptor.value.63, 5
  br i1 %callee.result.type.valid.72, label %callee.result.type.ok.73, label %frame.failure.0
callee.result.type.ok.73:
  %context.field.74 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.75 = load i32, ptr %context.field.74, align 4
  %stack.sub.78 = sub i32 %descriptor.value.71, %descriptor.value.65
  %descriptor.owner.inside.76 = icmp ule i32 %descriptor.value.71, %context.value.75
  %descriptor.offset.inside.77 = icmp ule i32 %descriptor.value.65, %descriptor.value.71
  %descriptor.extent.inside.79 = icmp ule i32 %descriptor.value.67, %stack.sub.78
  %descriptor.payload.inside.80 = icmp ule i32 %descriptor.value.69, %descriptor.value.67
  %descriptor.owner.offset.valid.81 = and i1 %descriptor.owner.inside.76, %descriptor.offset.inside.77
  %descriptor.range.inside.83 = and i1 %descriptor.owner.offset.valid.81, %descriptor.extent.inside.79
  %descriptor.range.valid.82 = and i1 %descriptor.range.inside.83, %descriptor.payload.inside.80
  %descriptor.type.valid.84 = icmp eq i32 5, 5
  %descriptor.valid.85 = and i1 %descriptor.range.valid.82, %descriptor.type.valid.84
  br i1 %descriptor.valid.85, label %descriptor.valid.86, label %descriptor.invalid.87
descriptor.invalid.87:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.86:
  %descriptor.initialized.status.88 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.65, i32 %descriptor.value.67)
  %helper.ok.89 = icmp eq i32 %descriptor.initialized.status.88, 0
  br i1 %helper.ok.89, label %helper.continue.90, label %frame.failure.0
helper.continue.90:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.65, i32 20, i32 %descriptor.value.69, i32 %descriptor.value.71, i32 %descriptor.value.67)
  %context.field.91 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.92 = load i32, ptr %context.field.91, align 4
  %runtime.ok.93 = icmp eq i32 %context.value.92, 0
  br i1 %runtime.ok.93, label %runtime.continue.94, label %frame.failure.0
runtime.continue.94:
  %context.field.95 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.96 = load i32, ptr %context.field.95, align 4
  %stack.sub.99 = sub i32 %descriptor.value.71, %descriptor.value.65
  %descriptor.owner.inside.97 = icmp ule i32 %descriptor.value.71, %context.value.96
  %descriptor.offset.inside.98 = icmp ule i32 %descriptor.value.65, %descriptor.value.71
  %descriptor.extent.inside.100 = icmp ule i32 %descriptor.value.67, %stack.sub.99
  %descriptor.payload.inside.101 = icmp ule i32 %descriptor.value.69, %descriptor.value.67
  %descriptor.owner.offset.valid.102 = and i1 %descriptor.owner.inside.97, %descriptor.offset.inside.98
  %descriptor.range.inside.104 = and i1 %descriptor.owner.offset.valid.102, %descriptor.extent.inside.100
  %descriptor.range.valid.103 = and i1 %descriptor.range.inside.104, %descriptor.payload.inside.101
  %descriptor.type.valid.105 = icmp eq i32 5, 5
  %descriptor.valid.106 = and i1 %descriptor.range.valid.103, %descriptor.type.valid.105
  br i1 %descriptor.valid.106, label %descriptor.valid.107, label %descriptor.invalid.108
descriptor.invalid.108:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.107:
  %descriptor.initialized.status.109 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.65, i32 %descriptor.value.67)
  %helper.ok.110 = icmp eq i32 %descriptor.initialized.status.109, 0
  br i1 %helper.ok.110, label %helper.continue.111, label %frame.failure.0
helper.continue.111:
  %descriptor.element.112 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.113 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 0
  store i32 5, ptr %descriptor.field.113, align 4
  %descriptor.field.114 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 1
  store i32 %descriptor.value.65, ptr %descriptor.field.114, align 4
  %descriptor.field.115 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 2
  store i32 %descriptor.value.67, ptr %descriptor.field.115, align 4
  %descriptor.field.116 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 3
  store i32 %descriptor.value.69, ptr %descriptor.field.116, align 4
  %descriptor.field.117 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 4
  store i32 %descriptor.value.71, ptr %descriptor.field.117, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.65, i32 20, i32 %descriptor.value.69, i32 %descriptor.value.71, i32 %descriptor.value.67)
  %context.field.118 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.119 = load i32, ptr %context.field.118, align 4
  %runtime.ok.120 = icmp eq i32 %context.value.119, 0
  br i1 %runtime.ok.120, label %runtime.continue.121, label %frame.failure.0
runtime.continue.121:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.122 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.123 = load i32, ptr %context.field.122, align 4
  %context.field.124 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.125 = load i32, ptr %context.field.124, align 4
  %context.field.126 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.127 = load i32, ptr %context.field.126, align 4
  %stack.offset.128 = add i32 %context.value.5, %context.value.7
  %stack.offset.129 = add i32 %context.value.123, %context.value.125
  %stack.sub.130 = sub i32 %stack.offset.128, %stack.offset.129
  %stack.sub.131 = sub i32 %context.value.7, %context.value.125
  %stack.sub.132 = sub i32 %context.value.127, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.130, i32 %stack.sub.131)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.132)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_mailbox_begin_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %call.arguments.76 = alloca [2 x %AlOwningDescriptor], align 4
  %call.results.97 = alloca [2 x %AlOwningDescriptor], align 4
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 5
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 5, 5
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %descriptor.element.43 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.44 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 0
  %descriptor.value.45 = load i32, ptr %descriptor.field.44, align 4
  %descriptor.field.46 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 1
  %descriptor.value.47 = load i32, ptr %descriptor.field.46, align 4
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 2
  %descriptor.value.49 = load i32, ptr %descriptor.field.48, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 3
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 4
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %argument.type.valid.54 = icmp eq i32 %descriptor.value.45, 6
  br i1 %argument.type.valid.54, label %argument.type.ok.55, label %frame.failure.0
argument.type.ok.55:
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %stack.sub.60 = sub i32 %descriptor.value.53, %descriptor.value.47
  %descriptor.owner.inside.58 = icmp ule i32 %descriptor.value.53, %context.value.57
  %descriptor.offset.inside.59 = icmp ule i32 %descriptor.value.47, %descriptor.value.53
  %descriptor.extent.inside.61 = icmp ule i32 %descriptor.value.49, %stack.sub.60
  %descriptor.payload.inside.62 = icmp ule i32 %descriptor.value.51, %descriptor.value.49
  %descriptor.owner.offset.valid.63 = and i1 %descriptor.owner.inside.58, %descriptor.offset.inside.59
  %descriptor.range.inside.65 = and i1 %descriptor.owner.offset.valid.63, %descriptor.extent.inside.61
  %descriptor.range.valid.64 = and i1 %descriptor.range.inside.65, %descriptor.payload.inside.62
  %descriptor.type.valid.66 = icmp eq i32 6, 6
  %descriptor.valid.67 = and i1 %descriptor.range.valid.64, %descriptor.type.valid.66
  br i1 %descriptor.valid.67, label %descriptor.valid.68, label %descriptor.invalid.69
descriptor.invalid.69:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.68:
  %descriptor.initialized.status.70 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.47, i32 %descriptor.value.49)
  %helper.ok.71 = icmp eq i32 %descriptor.initialized.status.70, 0
  br i1 %helper.ok.71, label %helper.continue.72, label %frame.failure.0
helper.continue.72:
  %step.status.73 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.74 = icmp eq i32 %step.status.73, 0
  br i1 %helper.ok.74, label %helper.continue.75, label %frame.failure.0
helper.continue.75:
  %descriptor.element.77 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.76, i32 0
  %descriptor.field.78 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 0
  store i32 5, ptr %descriptor.field.78, align 4
  %descriptor.field.79 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.79, align 4
  %descriptor.field.80 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.80, align 4
  %descriptor.field.81 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.81, align 4
  %descriptor.field.82 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.82, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %descriptor.element.87 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.76, i32 1
  %descriptor.field.88 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 0
  store i32 6, ptr %descriptor.field.88, align 4
  %descriptor.field.89 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 1
  store i32 %descriptor.value.47, ptr %descriptor.field.89, align 4
  %descriptor.field.90 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 2
  store i32 %descriptor.value.49, ptr %descriptor.field.90, align 4
  %descriptor.field.91 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 3
  store i32 %descriptor.value.51, ptr %descriptor.field.91, align 4
  %descriptor.field.92 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 4
  store i32 %descriptor.value.53, ptr %descriptor.field.92, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %descriptor.value.47, i32 20, i32 %descriptor.value.51, i32 %descriptor.value.53, i32 %descriptor.value.49)
  %context.field.93 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.94 = load i32, ptr %context.field.93, align 4
  %runtime.ok.95 = icmp eq i32 %context.value.94, 0
  br i1 %runtime.ok.95, label %runtime.continue.96, label %frame.failure.0
runtime.continue.96:
  %callee.status.98 = call i32 @agentlang_word_0000(ptr %ctx, ptr %call.arguments.76, ptr %call.results.97, i32 4)
  %helper.ok.99 = icmp eq i32 %callee.status.98, 0
  br i1 %helper.ok.99, label %helper.continue.100, label %frame.failure.0
helper.continue.100:
  %descriptor.element.101 = getelementptr inbounds %AlOwningDescriptor, ptr %call.results.97, i32 0
  %descriptor.field.102 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.101, i32 0, i32 0
  %descriptor.value.103 = load i32, ptr %descriptor.field.102, align 4
  %descriptor.field.104 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.101, i32 0, i32 1
  %descriptor.value.105 = load i32, ptr %descriptor.field.104, align 4
  %descriptor.field.106 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.101, i32 0, i32 2
  %descriptor.value.107 = load i32, ptr %descriptor.field.106, align 4
  %descriptor.field.108 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.101, i32 0, i32 3
  %descriptor.value.109 = load i32, ptr %descriptor.field.108, align 4
  %descriptor.field.110 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.101, i32 0, i32 4
  %descriptor.value.111 = load i32, ptr %descriptor.field.110, align 4
  %callee.result.type.valid.112 = icmp eq i32 %descriptor.value.103, 5
  br i1 %callee.result.type.valid.112, label %callee.result.type.ok.113, label %frame.failure.0
callee.result.type.ok.113:
  %context.field.114 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.115 = load i32, ptr %context.field.114, align 4
  %stack.sub.118 = sub i32 %descriptor.value.111, %descriptor.value.105
  %descriptor.owner.inside.116 = icmp ule i32 %descriptor.value.111, %context.value.115
  %descriptor.offset.inside.117 = icmp ule i32 %descriptor.value.105, %descriptor.value.111
  %descriptor.extent.inside.119 = icmp ule i32 %descriptor.value.107, %stack.sub.118
  %descriptor.payload.inside.120 = icmp ule i32 %descriptor.value.109, %descriptor.value.107
  %descriptor.owner.offset.valid.121 = and i1 %descriptor.owner.inside.116, %descriptor.offset.inside.117
  %descriptor.range.inside.123 = and i1 %descriptor.owner.offset.valid.121, %descriptor.extent.inside.119
  %descriptor.range.valid.122 = and i1 %descriptor.range.inside.123, %descriptor.payload.inside.120
  %descriptor.type.valid.124 = icmp eq i32 5, 5
  %descriptor.valid.125 = and i1 %descriptor.range.valid.122, %descriptor.type.valid.124
  br i1 %descriptor.valid.125, label %descriptor.valid.126, label %descriptor.invalid.127
descriptor.invalid.127:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.126:
  %descriptor.initialized.status.128 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.105, i32 %descriptor.value.107)
  %helper.ok.129 = icmp eq i32 %descriptor.initialized.status.128, 0
  br i1 %helper.ok.129, label %helper.continue.130, label %frame.failure.0
helper.continue.130:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.105, i32 20, i32 %descriptor.value.109, i32 %descriptor.value.111, i32 %descriptor.value.107)
  %context.field.131 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.132 = load i32, ptr %context.field.131, align 4
  %runtime.ok.133 = icmp eq i32 %context.value.132, 0
  br i1 %runtime.ok.133, label %runtime.continue.134, label %frame.failure.0
runtime.continue.134:
  %descriptor.element.135 = getelementptr inbounds %AlOwningDescriptor, ptr %call.results.97, i32 1
  %descriptor.field.136 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.135, i32 0, i32 0
  %descriptor.value.137 = load i32, ptr %descriptor.field.136, align 4
  %descriptor.field.138 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.135, i32 0, i32 1
  %descriptor.value.139 = load i32, ptr %descriptor.field.138, align 4
  %descriptor.field.140 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.135, i32 0, i32 2
  %descriptor.value.141 = load i32, ptr %descriptor.field.140, align 4
  %descriptor.field.142 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.135, i32 0, i32 3
  %descriptor.value.143 = load i32, ptr %descriptor.field.142, align 4
  %descriptor.field.144 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.135, i32 0, i32 4
  %descriptor.value.145 = load i32, ptr %descriptor.field.144, align 4
  %callee.result.type.valid.146 = icmp eq i32 %descriptor.value.137, 4
  br i1 %callee.result.type.valid.146, label %callee.result.type.ok.147, label %frame.failure.0
callee.result.type.ok.147:
  %context.field.148 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.149 = load i32, ptr %context.field.148, align 4
  %stack.sub.152 = sub i32 %descriptor.value.145, %descriptor.value.139
  %descriptor.owner.inside.150 = icmp ule i32 %descriptor.value.145, %context.value.149
  %descriptor.offset.inside.151 = icmp ule i32 %descriptor.value.139, %descriptor.value.145
  %descriptor.extent.inside.153 = icmp ule i32 %descriptor.value.141, %stack.sub.152
  %descriptor.payload.inside.154 = icmp ule i32 %descriptor.value.143, %descriptor.value.141
  %descriptor.owner.offset.valid.155 = and i1 %descriptor.owner.inside.150, %descriptor.offset.inside.151
  %descriptor.range.inside.157 = and i1 %descriptor.owner.offset.valid.155, %descriptor.extent.inside.153
  %descriptor.range.valid.156 = and i1 %descriptor.range.inside.157, %descriptor.payload.inside.154
  %descriptor.type.valid.158 = icmp eq i32 4, 4
  %descriptor.valid.159 = and i1 %descriptor.range.valid.156, %descriptor.type.valid.158
  br i1 %descriptor.valid.159, label %descriptor.valid.160, label %descriptor.invalid.161
descriptor.invalid.161:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.160:
  %descriptor.initialized.status.162 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.139, i32 %descriptor.value.141)
  %helper.ok.163 = icmp eq i32 %descriptor.initialized.status.162, 0
  br i1 %helper.ok.163, label %helper.continue.164, label %frame.failure.0
helper.continue.164:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %descriptor.value.139, i32 20, i32 %descriptor.value.143, i32 %descriptor.value.145, i32 %descriptor.value.141)
  %context.field.165 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.166 = load i32, ptr %context.field.165, align 4
  %runtime.ok.167 = icmp eq i32 %context.value.166, 0
  br i1 %runtime.ok.167, label %runtime.continue.168, label %frame.failure.0
runtime.continue.168:
  %context.field.169 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.170 = load i32, ptr %context.field.169, align 4
  %stack.sub.173 = sub i32 %descriptor.value.111, %descriptor.value.105
  %descriptor.owner.inside.171 = icmp ule i32 %descriptor.value.111, %context.value.170
  %descriptor.offset.inside.172 = icmp ule i32 %descriptor.value.105, %descriptor.value.111
  %descriptor.extent.inside.174 = icmp ule i32 %descriptor.value.107, %stack.sub.173
  %descriptor.payload.inside.175 = icmp ule i32 %descriptor.value.109, %descriptor.value.107
  %descriptor.owner.offset.valid.176 = and i1 %descriptor.owner.inside.171, %descriptor.offset.inside.172
  %descriptor.range.inside.178 = and i1 %descriptor.owner.offset.valid.176, %descriptor.extent.inside.174
  %descriptor.range.valid.177 = and i1 %descriptor.range.inside.178, %descriptor.payload.inside.175
  %descriptor.type.valid.179 = icmp eq i32 5, 5
  %descriptor.valid.180 = and i1 %descriptor.range.valid.177, %descriptor.type.valid.179
  br i1 %descriptor.valid.180, label %descriptor.valid.181, label %descriptor.invalid.182
descriptor.invalid.182:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.181:
  %descriptor.initialized.status.183 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.105, i32 %descriptor.value.107)
  %helper.ok.184 = icmp eq i32 %descriptor.initialized.status.183, 0
  br i1 %helper.ok.184, label %helper.continue.185, label %frame.failure.0
helper.continue.185:
  %context.field.186 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.187 = load i32, ptr %context.field.186, align 4
  %stack.sub.190 = sub i32 %descriptor.value.145, %descriptor.value.139
  %descriptor.owner.inside.188 = icmp ule i32 %descriptor.value.145, %context.value.187
  %descriptor.offset.inside.189 = icmp ule i32 %descriptor.value.139, %descriptor.value.145
  %descriptor.extent.inside.191 = icmp ule i32 %descriptor.value.141, %stack.sub.190
  %descriptor.payload.inside.192 = icmp ule i32 %descriptor.value.143, %descriptor.value.141
  %descriptor.owner.offset.valid.193 = and i1 %descriptor.owner.inside.188, %descriptor.offset.inside.189
  %descriptor.range.inside.195 = and i1 %descriptor.owner.offset.valid.193, %descriptor.extent.inside.191
  %descriptor.range.valid.194 = and i1 %descriptor.range.inside.195, %descriptor.payload.inside.192
  %descriptor.type.valid.196 = icmp eq i32 4, 4
  %descriptor.valid.197 = and i1 %descriptor.range.valid.194, %descriptor.type.valid.196
  br i1 %descriptor.valid.197, label %descriptor.valid.198, label %descriptor.invalid.199
descriptor.invalid.199:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.198:
  %descriptor.initialized.status.200 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.139, i32 %descriptor.value.141)
  %helper.ok.201 = icmp eq i32 %descriptor.initialized.status.200, 0
  br i1 %helper.ok.201, label %helper.continue.202, label %frame.failure.0
helper.continue.202:
  %descriptor.element.203 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.204 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.203, i32 0, i32 0
  store i32 5, ptr %descriptor.field.204, align 4
  %descriptor.field.205 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.203, i32 0, i32 1
  store i32 %descriptor.value.105, ptr %descriptor.field.205, align 4
  %descriptor.field.206 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.203, i32 0, i32 2
  store i32 %descriptor.value.107, ptr %descriptor.field.206, align 4
  %descriptor.field.207 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.203, i32 0, i32 3
  store i32 %descriptor.value.109, ptr %descriptor.field.207, align 4
  %descriptor.field.208 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.203, i32 0, i32 4
  store i32 %descriptor.value.111, ptr %descriptor.field.208, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.105, i32 20, i32 %descriptor.value.109, i32 %descriptor.value.111, i32 %descriptor.value.107)
  %context.field.209 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.210 = load i32, ptr %context.field.209, align 4
  %runtime.ok.211 = icmp eq i32 %context.value.210, 0
  br i1 %runtime.ok.211, label %runtime.continue.212, label %frame.failure.0
runtime.continue.212:
  %descriptor.element.213 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 1
  %descriptor.field.214 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 0
  store i32 4, ptr %descriptor.field.214, align 4
  %descriptor.field.215 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 1
  store i32 %descriptor.value.139, ptr %descriptor.field.215, align 4
  %descriptor.field.216 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 2
  store i32 %descriptor.value.141, ptr %descriptor.field.216, align 4
  %descriptor.field.217 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 3
  store i32 %descriptor.value.143, ptr %descriptor.field.217, align 4
  %descriptor.field.218 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.213, i32 0, i32 4
  store i32 %descriptor.value.145, ptr %descriptor.field.218, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %descriptor.value.139, i32 20, i32 %descriptor.value.143, i32 %descriptor.value.145, i32 %descriptor.value.141)
  %context.field.219 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.220 = load i32, ptr %context.field.219, align 4
  %runtime.ok.221 = icmp eq i32 %context.value.220, 0
  br i1 %runtime.ok.221, label %runtime.continue.222, label %frame.failure.0
runtime.continue.222:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.223 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.224 = load i32, ptr %context.field.223, align 4
  %context.field.225 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.226 = load i32, ptr %context.field.225, align 4
  %context.field.227 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.228 = load i32, ptr %context.field.227, align 4
  %stack.offset.229 = add i32 %context.value.5, %context.value.7
  %stack.offset.230 = add i32 %context.value.224, %context.value.226
  %stack.sub.231 = sub i32 %stack.offset.229, %stack.offset.230
  %stack.sub.232 = sub i32 %context.value.7, %context.value.226
  %stack.sub.233 = sub i32 %context.value.228, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.231, i32 %stack.sub.232)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.233)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_mailbox_resume_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %call.arguments.106 = alloca [3 x %AlOwningDescriptor], align 4
  %call.results.137 = alloca [1 x %AlOwningDescriptor], align 4
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 5
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 5, 5
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %descriptor.element.43 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.44 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 0
  %descriptor.value.45 = load i32, ptr %descriptor.field.44, align 4
  %descriptor.field.46 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 1
  %descriptor.value.47 = load i32, ptr %descriptor.field.46, align 4
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 2
  %descriptor.value.49 = load i32, ptr %descriptor.field.48, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 3
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 4
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %argument.type.valid.54 = icmp eq i32 %descriptor.value.45, 4
  br i1 %argument.type.valid.54, label %argument.type.ok.55, label %frame.failure.0
argument.type.ok.55:
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %stack.sub.60 = sub i32 %descriptor.value.53, %descriptor.value.47
  %descriptor.owner.inside.58 = icmp ule i32 %descriptor.value.53, %context.value.57
  %descriptor.offset.inside.59 = icmp ule i32 %descriptor.value.47, %descriptor.value.53
  %descriptor.extent.inside.61 = icmp ule i32 %descriptor.value.49, %stack.sub.60
  %descriptor.payload.inside.62 = icmp ule i32 %descriptor.value.51, %descriptor.value.49
  %descriptor.owner.offset.valid.63 = and i1 %descriptor.owner.inside.58, %descriptor.offset.inside.59
  %descriptor.range.inside.65 = and i1 %descriptor.owner.offset.valid.63, %descriptor.extent.inside.61
  %descriptor.range.valid.64 = and i1 %descriptor.range.inside.65, %descriptor.payload.inside.62
  %descriptor.type.valid.66 = icmp eq i32 4, 4
  %descriptor.valid.67 = and i1 %descriptor.range.valid.64, %descriptor.type.valid.66
  br i1 %descriptor.valid.67, label %descriptor.valid.68, label %descriptor.invalid.69
descriptor.invalid.69:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.68:
  %descriptor.initialized.status.70 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.47, i32 %descriptor.value.49)
  %helper.ok.71 = icmp eq i32 %descriptor.initialized.status.70, 0
  br i1 %helper.ok.71, label %helper.continue.72, label %frame.failure.0
helper.continue.72:
  %descriptor.element.73 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 2
  %descriptor.field.74 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 0
  %descriptor.value.75 = load i32, ptr %descriptor.field.74, align 4
  %descriptor.field.76 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 1
  %descriptor.value.77 = load i32, ptr %descriptor.field.76, align 4
  %descriptor.field.78 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 2
  %descriptor.value.79 = load i32, ptr %descriptor.field.78, align 4
  %descriptor.field.80 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 3
  %descriptor.value.81 = load i32, ptr %descriptor.field.80, align 4
  %descriptor.field.82 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 4
  %descriptor.value.83 = load i32, ptr %descriptor.field.82, align 4
  %argument.type.valid.84 = icmp eq i32 %descriptor.value.75, 6
  br i1 %argument.type.valid.84, label %argument.type.ok.85, label %frame.failure.0
argument.type.ok.85:
  %context.field.86 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.87 = load i32, ptr %context.field.86, align 4
  %stack.sub.90 = sub i32 %descriptor.value.83, %descriptor.value.77
  %descriptor.owner.inside.88 = icmp ule i32 %descriptor.value.83, %context.value.87
  %descriptor.offset.inside.89 = icmp ule i32 %descriptor.value.77, %descriptor.value.83
  %descriptor.extent.inside.91 = icmp ule i32 %descriptor.value.79, %stack.sub.90
  %descriptor.payload.inside.92 = icmp ule i32 %descriptor.value.81, %descriptor.value.79
  %descriptor.owner.offset.valid.93 = and i1 %descriptor.owner.inside.88, %descriptor.offset.inside.89
  %descriptor.range.inside.95 = and i1 %descriptor.owner.offset.valid.93, %descriptor.extent.inside.91
  %descriptor.range.valid.94 = and i1 %descriptor.range.inside.95, %descriptor.payload.inside.92
  %descriptor.type.valid.96 = icmp eq i32 6, 6
  %descriptor.valid.97 = and i1 %descriptor.range.valid.94, %descriptor.type.valid.96
  br i1 %descriptor.valid.97, label %descriptor.valid.98, label %descriptor.invalid.99
descriptor.invalid.99:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.98:
  %descriptor.initialized.status.100 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.77, i32 %descriptor.value.79)
  %helper.ok.101 = icmp eq i32 %descriptor.initialized.status.100, 0
  br i1 %helper.ok.101, label %helper.continue.102, label %frame.failure.0
helper.continue.102:
  %step.status.103 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.104 = icmp eq i32 %step.status.103, 0
  br i1 %helper.ok.104, label %helper.continue.105, label %frame.failure.0
helper.continue.105:
  %descriptor.element.107 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.106, i32 0
  %descriptor.field.108 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.107, i32 0, i32 0
  store i32 5, ptr %descriptor.field.108, align 4
  %descriptor.field.109 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.107, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.109, align 4
  %descriptor.field.110 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.107, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.110, align 4
  %descriptor.field.111 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.107, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.111, align 4
  %descriptor.field.112 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.107, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.112, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.113 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.114 = load i32, ptr %context.field.113, align 4
  %runtime.ok.115 = icmp eq i32 %context.value.114, 0
  br i1 %runtime.ok.115, label %runtime.continue.116, label %frame.failure.0
runtime.continue.116:
  %descriptor.element.117 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.106, i32 1
  %descriptor.field.118 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.117, i32 0, i32 0
  store i32 4, ptr %descriptor.field.118, align 4
  %descriptor.field.119 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.117, i32 0, i32 1
  store i32 %descriptor.value.47, ptr %descriptor.field.119, align 4
  %descriptor.field.120 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.117, i32 0, i32 2
  store i32 %descriptor.value.49, ptr %descriptor.field.120, align 4
  %descriptor.field.121 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.117, i32 0, i32 3
  store i32 %descriptor.value.51, ptr %descriptor.field.121, align 4
  %descriptor.field.122 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.117, i32 0, i32 4
  store i32 %descriptor.value.53, ptr %descriptor.field.122, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %descriptor.value.47, i32 20, i32 %descriptor.value.51, i32 %descriptor.value.53, i32 %descriptor.value.49)
  %context.field.123 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.124 = load i32, ptr %context.field.123, align 4
  %runtime.ok.125 = icmp eq i32 %context.value.124, 0
  br i1 %runtime.ok.125, label %runtime.continue.126, label %frame.failure.0
runtime.continue.126:
  %descriptor.element.127 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.106, i32 2
  %descriptor.field.128 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.127, i32 0, i32 0
  store i32 6, ptr %descriptor.field.128, align 4
  %descriptor.field.129 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.127, i32 0, i32 1
  store i32 %descriptor.value.77, ptr %descriptor.field.129, align 4
  %descriptor.field.130 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.127, i32 0, i32 2
  store i32 %descriptor.value.79, ptr %descriptor.field.130, align 4
  %descriptor.field.131 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.127, i32 0, i32 3
  store i32 %descriptor.value.81, ptr %descriptor.field.131, align 4
  %descriptor.field.132 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.127, i32 0, i32 4
  store i32 %descriptor.value.83, ptr %descriptor.field.132, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %descriptor.value.77, i32 20, i32 %descriptor.value.81, i32 %descriptor.value.83, i32 %descriptor.value.79)
  %context.field.133 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.134 = load i32, ptr %context.field.133, align 4
  %runtime.ok.135 = icmp eq i32 %context.value.134, 0
  br i1 %runtime.ok.135, label %runtime.continue.136, label %frame.failure.0
runtime.continue.136:
  %callee.status.138 = call i32 @agentlang_word_0002(ptr %ctx, ptr %call.arguments.106, ptr %call.results.137, i32 6)
  %helper.ok.139 = icmp eq i32 %callee.status.138, 0
  br i1 %helper.ok.139, label %helper.continue.140, label %frame.failure.0
helper.continue.140:
  %descriptor.element.141 = getelementptr inbounds %AlOwningDescriptor, ptr %call.results.137, i32 0
  %descriptor.field.142 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.141, i32 0, i32 0
  %descriptor.value.143 = load i32, ptr %descriptor.field.142, align 4
  %descriptor.field.144 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.141, i32 0, i32 1
  %descriptor.value.145 = load i32, ptr %descriptor.field.144, align 4
  %descriptor.field.146 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.141, i32 0, i32 2
  %descriptor.value.147 = load i32, ptr %descriptor.field.146, align 4
  %descriptor.field.148 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.141, i32 0, i32 3
  %descriptor.value.149 = load i32, ptr %descriptor.field.148, align 4
  %descriptor.field.150 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.141, i32 0, i32 4
  %descriptor.value.151 = load i32, ptr %descriptor.field.150, align 4
  %callee.result.type.valid.152 = icmp eq i32 %descriptor.value.143, 5
  br i1 %callee.result.type.valid.152, label %callee.result.type.ok.153, label %frame.failure.0
callee.result.type.ok.153:
  %context.field.154 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.155 = load i32, ptr %context.field.154, align 4
  %stack.sub.158 = sub i32 %descriptor.value.151, %descriptor.value.145
  %descriptor.owner.inside.156 = icmp ule i32 %descriptor.value.151, %context.value.155
  %descriptor.offset.inside.157 = icmp ule i32 %descriptor.value.145, %descriptor.value.151
  %descriptor.extent.inside.159 = icmp ule i32 %descriptor.value.147, %stack.sub.158
  %descriptor.payload.inside.160 = icmp ule i32 %descriptor.value.149, %descriptor.value.147
  %descriptor.owner.offset.valid.161 = and i1 %descriptor.owner.inside.156, %descriptor.offset.inside.157
  %descriptor.range.inside.163 = and i1 %descriptor.owner.offset.valid.161, %descriptor.extent.inside.159
  %descriptor.range.valid.162 = and i1 %descriptor.range.inside.163, %descriptor.payload.inside.160
  %descriptor.type.valid.164 = icmp eq i32 5, 5
  %descriptor.valid.165 = and i1 %descriptor.range.valid.162, %descriptor.type.valid.164
  br i1 %descriptor.valid.165, label %descriptor.valid.166, label %descriptor.invalid.167
descriptor.invalid.167:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.166:
  %descriptor.initialized.status.168 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.145, i32 %descriptor.value.147)
  %helper.ok.169 = icmp eq i32 %descriptor.initialized.status.168, 0
  br i1 %helper.ok.169, label %helper.continue.170, label %frame.failure.0
helper.continue.170:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.145, i32 20, i32 %descriptor.value.149, i32 %descriptor.value.151, i32 %descriptor.value.147)
  %context.field.171 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.172 = load i32, ptr %context.field.171, align 4
  %runtime.ok.173 = icmp eq i32 %context.value.172, 0
  br i1 %runtime.ok.173, label %runtime.continue.174, label %frame.failure.0
runtime.continue.174:
  %context.field.175 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.176 = load i32, ptr %context.field.175, align 4
  %stack.sub.179 = sub i32 %descriptor.value.151, %descriptor.value.145
  %descriptor.owner.inside.177 = icmp ule i32 %descriptor.value.151, %context.value.176
  %descriptor.offset.inside.178 = icmp ule i32 %descriptor.value.145, %descriptor.value.151
  %descriptor.extent.inside.180 = icmp ule i32 %descriptor.value.147, %stack.sub.179
  %descriptor.payload.inside.181 = icmp ule i32 %descriptor.value.149, %descriptor.value.147
  %descriptor.owner.offset.valid.182 = and i1 %descriptor.owner.inside.177, %descriptor.offset.inside.178
  %descriptor.range.inside.184 = and i1 %descriptor.owner.offset.valid.182, %descriptor.extent.inside.180
  %descriptor.range.valid.183 = and i1 %descriptor.range.inside.184, %descriptor.payload.inside.181
  %descriptor.type.valid.185 = icmp eq i32 5, 5
  %descriptor.valid.186 = and i1 %descriptor.range.valid.183, %descriptor.type.valid.185
  br i1 %descriptor.valid.186, label %descriptor.valid.187, label %descriptor.invalid.188
descriptor.invalid.188:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.187:
  %descriptor.initialized.status.189 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.145, i32 %descriptor.value.147)
  %helper.ok.190 = icmp eq i32 %descriptor.initialized.status.189, 0
  br i1 %helper.ok.190, label %helper.continue.191, label %frame.failure.0
helper.continue.191:
  %descriptor.element.192 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.193 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.192, i32 0, i32 0
  store i32 5, ptr %descriptor.field.193, align 4
  %descriptor.field.194 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.192, i32 0, i32 1
  store i32 %descriptor.value.145, ptr %descriptor.field.194, align 4
  %descriptor.field.195 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.192, i32 0, i32 2
  store i32 %descriptor.value.147, ptr %descriptor.field.195, align 4
  %descriptor.field.196 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.192, i32 0, i32 3
  store i32 %descriptor.value.149, ptr %descriptor.field.196, align 4
  %descriptor.field.197 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.192, i32 0, i32 4
  store i32 %descriptor.value.151, ptr %descriptor.field.197, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.145, i32 20, i32 %descriptor.value.149, i32 %descriptor.value.151, i32 %descriptor.value.147)
  %context.field.198 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.199 = load i32, ptr %context.field.198, align 4
  %runtime.ok.200 = icmp eq i32 %context.value.199, 0
  br i1 %runtime.ok.200, label %runtime.continue.201, label %frame.failure.0
runtime.continue.201:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.202 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.203 = load i32, ptr %context.field.202, align 4
  %context.field.204 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.205 = load i32, ptr %context.field.204, align 4
  %context.field.206 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.207 = load i32, ptr %context.field.206, align 4
  %stack.offset.208 = add i32 %context.value.5, %context.value.7
  %stack.offset.209 = add i32 %context.value.203, %context.value.205
  %stack.sub.210 = sub i32 %stack.offset.208, %stack.offset.209
  %stack.sub.211 = sub i32 %context.value.7, %context.value.205
  %stack.sub.212 = sub i32 %context.value.207, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.210, i32 %stack.sub.211)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.212)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %local.active.2 = alloca i1, align 1
  %local.offset.3 = alloca i32, align 4
  %local.extent.4 = alloca i32, align 4
  %local.payload.5 = alloca i32, align 4
  %local.owner.end.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  %local.active.8 = alloca i1, align 1
  %local.offset.9 = alloca i32, align 4
  %local.extent.10 = alloca i32, align 4
  %local.payload.11 = alloca i32, align 4
  %local.owner.end.12 = alloca i32, align 4
  %local.type.13 = alloca i32, align 4
  %local.active.14 = alloca i1, align 1
  %local.offset.15 = alloca i32, align 4
  %local.extent.16 = alloca i32, align 4
  %local.payload.17 = alloca i32, align 4
  %local.owner.end.18 = alloca i32, align 4
  %local.type.19 = alloca i32, align 4
  %local.active.20 = alloca i1, align 1
  %local.offset.21 = alloca i32, align 4
  %local.extent.22 = alloca i32, align 4
  %local.payload.23 = alloca i32, align 4
  %local.owner.end.24 = alloca i32, align 4
  %local.type.25 = alloca i32, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  store i1 false, ptr %local.active.20, align 1
  store i32 0, ptr %local.offset.21, align 4
  store i32 0, ptr %local.extent.22, align 4
  store i32 0, ptr %local.payload.23, align 4
  store i32 0, ptr %local.owner.end.24, align 4
  store i32 0, ptr %local.type.25, align 4
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %context.field.28 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.29 = load i32, ptr %context.field.28, align 4
  %context.field.30 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.31 = load i32, ptr %context.field.30, align 4
  %context.field.32 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.33 = load i32, ptr %context.field.32, align 4
  %frame.entered.34 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.35 = icmp eq i32 %frame.entered.34, 0
  br i1 %frame.enter.ok.35, label %frame.enter.continue.36, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.36:
  %descriptor.element.37 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.38 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.37, i32 0, i32 0
  %descriptor.value.39 = load i32, ptr %descriptor.field.38, align 4
  %descriptor.field.40 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.37, i32 0, i32 1
  %descriptor.value.41 = load i32, ptr %descriptor.field.40, align 4
  %descriptor.field.42 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.37, i32 0, i32 2
  %descriptor.value.43 = load i32, ptr %descriptor.field.42, align 4
  %descriptor.field.44 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.37, i32 0, i32 3
  %descriptor.value.45 = load i32, ptr %descriptor.field.44, align 4
  %descriptor.field.46 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.37, i32 0, i32 4
  %descriptor.value.47 = load i32, ptr %descriptor.field.46, align 4
  %argument.type.valid.48 = icmp eq i32 %descriptor.value.39, 5
  br i1 %argument.type.valid.48, label %argument.type.ok.49, label %frame.failure.0
argument.type.ok.49:
  %context.field.50 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.51 = load i32, ptr %context.field.50, align 4
  %stack.sub.54 = sub i32 %descriptor.value.47, %descriptor.value.41
  %descriptor.owner.inside.52 = icmp ule i32 %descriptor.value.47, %context.value.51
  %descriptor.offset.inside.53 = icmp ule i32 %descriptor.value.41, %descriptor.value.47
  %descriptor.extent.inside.55 = icmp ule i32 %descriptor.value.43, %stack.sub.54
  %descriptor.payload.inside.56 = icmp ule i32 %descriptor.value.45, %descriptor.value.43
  %descriptor.owner.offset.valid.57 = and i1 %descriptor.owner.inside.52, %descriptor.offset.inside.53
  %descriptor.range.inside.59 = and i1 %descriptor.owner.offset.valid.57, %descriptor.extent.inside.55
  %descriptor.range.valid.58 = and i1 %descriptor.range.inside.59, %descriptor.payload.inside.56
  %descriptor.type.valid.60 = icmp eq i32 5, 5
  %descriptor.valid.61 = and i1 %descriptor.range.valid.58, %descriptor.type.valid.60
  br i1 %descriptor.valid.61, label %descriptor.valid.62, label %descriptor.invalid.63
descriptor.invalid.63:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.62:
  %descriptor.initialized.status.64 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.41, i32 %descriptor.value.43)
  %helper.ok.65 = icmp eq i32 %descriptor.initialized.status.64, 0
  br i1 %helper.ok.65, label %helper.continue.66, label %frame.failure.0
helper.continue.66:
  %descriptor.element.67 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.68 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.67, i32 0, i32 0
  %descriptor.value.69 = load i32, ptr %descriptor.field.68, align 4
  %descriptor.field.70 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.67, i32 0, i32 1
  %descriptor.value.71 = load i32, ptr %descriptor.field.70, align 4
  %descriptor.field.72 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.67, i32 0, i32 2
  %descriptor.value.73 = load i32, ptr %descriptor.field.72, align 4
  %descriptor.field.74 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.67, i32 0, i32 3
  %descriptor.value.75 = load i32, ptr %descriptor.field.74, align 4
  %descriptor.field.76 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.67, i32 0, i32 4
  %descriptor.value.77 = load i32, ptr %descriptor.field.76, align 4
  %argument.type.valid.78 = icmp eq i32 %descriptor.value.69, 6
  br i1 %argument.type.valid.78, label %argument.type.ok.79, label %frame.failure.0
argument.type.ok.79:
  %context.field.80 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.81 = load i32, ptr %context.field.80, align 4
  %stack.sub.84 = sub i32 %descriptor.value.77, %descriptor.value.71
  %descriptor.owner.inside.82 = icmp ule i32 %descriptor.value.77, %context.value.81
  %descriptor.offset.inside.83 = icmp ule i32 %descriptor.value.71, %descriptor.value.77
  %descriptor.extent.inside.85 = icmp ule i32 %descriptor.value.73, %stack.sub.84
  %descriptor.payload.inside.86 = icmp ule i32 %descriptor.value.75, %descriptor.value.73
  %descriptor.owner.offset.valid.87 = and i1 %descriptor.owner.inside.82, %descriptor.offset.inside.83
  %descriptor.range.inside.89 = and i1 %descriptor.owner.offset.valid.87, %descriptor.extent.inside.85
  %descriptor.range.valid.88 = and i1 %descriptor.range.inside.89, %descriptor.payload.inside.86
  %descriptor.type.valid.90 = icmp eq i32 6, 6
  %descriptor.valid.91 = and i1 %descriptor.range.valid.88, %descriptor.type.valid.90
  br i1 %descriptor.valid.91, label %descriptor.valid.92, label %descriptor.invalid.93
descriptor.invalid.93:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.92:
  %descriptor.initialized.status.94 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.71, i32 %descriptor.value.73)
  %helper.ok.95 = icmp eq i32 %descriptor.initialized.status.94, 0
  br i1 %helper.ok.95, label %helper.continue.96, label %frame.failure.0
helper.continue.96:
  %step.status.97 = call i32 @al_owning_charge_step(ptr %ctx, i32 7)
  %helper.ok.98 = icmp eq i32 %step.status.97, 0
  br i1 %helper.ok.98, label %helper.continue.99, label %frame.failure.0
helper.continue.99:
  store i1 true, ptr %local.active.2, align 1
  store i32 %descriptor.value.71, ptr %local.offset.3, align 4
  store i32 %descriptor.value.73, ptr %local.extent.4, align 4
  store i32 %descriptor.value.75, ptr %local.payload.5, align 4
  store i32 %descriptor.value.77, ptr %local.owner.end.6, align 4
  store i32 6, ptr %local.type.7, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %descriptor.value.71, i32 20, i32 %descriptor.value.75, i32 %descriptor.value.77, i32 %descriptor.value.73)
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %runtime.ok.102 = icmp eq i32 %context.value.101, 0
  br i1 %runtime.ok.102, label %runtime.continue.103, label %frame.failure.0
runtime.continue.103:
  %context.field.104 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.105 = load i32, ptr %context.field.104, align 4
  %stack.sub.108 = sub i32 %descriptor.value.47, %descriptor.value.41
  %descriptor.owner.inside.106 = icmp ule i32 %descriptor.value.47, %context.value.105
  %descriptor.offset.inside.107 = icmp ule i32 %descriptor.value.41, %descriptor.value.47
  %descriptor.extent.inside.109 = icmp ule i32 %descriptor.value.43, %stack.sub.108
  %descriptor.payload.inside.110 = icmp ule i32 %descriptor.value.45, %descriptor.value.43
  %descriptor.owner.offset.valid.111 = and i1 %descriptor.owner.inside.106, %descriptor.offset.inside.107
  %descriptor.range.inside.113 = and i1 %descriptor.owner.offset.valid.111, %descriptor.extent.inside.109
  %descriptor.range.valid.112 = and i1 %descriptor.range.inside.113, %descriptor.payload.inside.110
  %descriptor.type.valid.114 = icmp eq i32 5, 5
  %descriptor.valid.115 = and i1 %descriptor.range.valid.112, %descriptor.type.valid.114
  br i1 %descriptor.valid.115, label %descriptor.valid.116, label %descriptor.invalid.117
descriptor.invalid.117:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.116:
  %descriptor.initialized.status.118 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.41, i32 %descriptor.value.43)
  %helper.ok.119 = icmp eq i32 %descriptor.initialized.status.118, 0
  br i1 %helper.ok.119, label %helper.continue.120, label %frame.failure.0
helper.continue.120:
  %local.is.active.121 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.121, label %local.descriptor.active.122, label %local.descriptor.inactive.123
local.descriptor.active.122:
  %local.check.offset.125 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.126 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.127 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.128 = load i32, ptr %local.owner.end.6, align 4
  %context.field.129 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.130 = load i32, ptr %context.field.129, align 4
  %stack.sub.133 = sub i32 %local.check.owner.end.128, %local.check.offset.125
  %descriptor.owner.inside.131 = icmp ule i32 %local.check.owner.end.128, %context.value.130
  %descriptor.offset.inside.132 = icmp ule i32 %local.check.offset.125, %local.check.owner.end.128
  %descriptor.extent.inside.134 = icmp ule i32 %local.check.extent.126, %stack.sub.133
  %descriptor.payload.inside.135 = icmp ule i32 %local.check.payload.127, %local.check.extent.126
  %descriptor.owner.offset.valid.136 = and i1 %descriptor.owner.inside.131, %descriptor.offset.inside.132
  %descriptor.range.inside.138 = and i1 %descriptor.owner.offset.valid.136, %descriptor.extent.inside.134
  %descriptor.range.valid.137 = and i1 %descriptor.range.inside.138, %descriptor.payload.inside.135
  br i1 %descriptor.range.valid.137, label %descriptor.valid.139, label %descriptor.invalid.140
descriptor.invalid.140:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.139:
  %descriptor.initialized.status.141 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.125, i32 %local.check.extent.126)
  %helper.ok.142 = icmp eq i32 %descriptor.initialized.status.141, 0
  br i1 %helper.ok.142, label %helper.continue.143, label %frame.failure.0
helper.continue.143:
  br label %local.descriptor.checked.124
local.descriptor.inactive.123:
  br label %local.descriptor.checked.124
local.descriptor.checked.124:
  %local.is.active.144 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.144, label %local.descriptor.active.145, label %local.descriptor.inactive.146
local.descriptor.active.145:
  %local.check.offset.148 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.149 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.150 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.151 = load i32, ptr %local.owner.end.12, align 4
  %context.field.152 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.153 = load i32, ptr %context.field.152, align 4
  %stack.sub.156 = sub i32 %local.check.owner.end.151, %local.check.offset.148
  %descriptor.owner.inside.154 = icmp ule i32 %local.check.owner.end.151, %context.value.153
  %descriptor.offset.inside.155 = icmp ule i32 %local.check.offset.148, %local.check.owner.end.151
  %descriptor.extent.inside.157 = icmp ule i32 %local.check.extent.149, %stack.sub.156
  %descriptor.payload.inside.158 = icmp ule i32 %local.check.payload.150, %local.check.extent.149
  %descriptor.owner.offset.valid.159 = and i1 %descriptor.owner.inside.154, %descriptor.offset.inside.155
  %descriptor.range.inside.161 = and i1 %descriptor.owner.offset.valid.159, %descriptor.extent.inside.157
  %descriptor.range.valid.160 = and i1 %descriptor.range.inside.161, %descriptor.payload.inside.158
  br i1 %descriptor.range.valid.160, label %descriptor.valid.162, label %descriptor.invalid.163
descriptor.invalid.163:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.162:
  %descriptor.initialized.status.164 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.148, i32 %local.check.extent.149)
  %helper.ok.165 = icmp eq i32 %descriptor.initialized.status.164, 0
  br i1 %helper.ok.165, label %helper.continue.166, label %frame.failure.0
helper.continue.166:
  br label %local.descriptor.checked.147
local.descriptor.inactive.146:
  br label %local.descriptor.checked.147
local.descriptor.checked.147:
  %local.is.active.167 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.167, label %local.descriptor.active.168, label %local.descriptor.inactive.169
local.descriptor.active.168:
  %local.check.offset.171 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.172 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.173 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.174 = load i32, ptr %local.owner.end.18, align 4
  %context.field.175 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.176 = load i32, ptr %context.field.175, align 4
  %stack.sub.179 = sub i32 %local.check.owner.end.174, %local.check.offset.171
  %descriptor.owner.inside.177 = icmp ule i32 %local.check.owner.end.174, %context.value.176
  %descriptor.offset.inside.178 = icmp ule i32 %local.check.offset.171, %local.check.owner.end.174
  %descriptor.extent.inside.180 = icmp ule i32 %local.check.extent.172, %stack.sub.179
  %descriptor.payload.inside.181 = icmp ule i32 %local.check.payload.173, %local.check.extent.172
  %descriptor.owner.offset.valid.182 = and i1 %descriptor.owner.inside.177, %descriptor.offset.inside.178
  %descriptor.range.inside.184 = and i1 %descriptor.owner.offset.valid.182, %descriptor.extent.inside.180
  %descriptor.range.valid.183 = and i1 %descriptor.range.inside.184, %descriptor.payload.inside.181
  br i1 %descriptor.range.valid.183, label %descriptor.valid.185, label %descriptor.invalid.186
descriptor.invalid.186:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.185:
  %descriptor.initialized.status.187 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.171, i32 %local.check.extent.172)
  %helper.ok.188 = icmp eq i32 %descriptor.initialized.status.187, 0
  br i1 %helper.ok.188, label %helper.continue.189, label %frame.failure.0
helper.continue.189:
  br label %local.descriptor.checked.170
local.descriptor.inactive.169:
  br label %local.descriptor.checked.170
local.descriptor.checked.170:
  %local.is.active.190 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.190, label %local.descriptor.active.191, label %local.descriptor.inactive.192
local.descriptor.active.191:
  %local.check.offset.194 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.195 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.196 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.197 = load i32, ptr %local.owner.end.24, align 4
  %context.field.198 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.199 = load i32, ptr %context.field.198, align 4
  %stack.sub.202 = sub i32 %local.check.owner.end.197, %local.check.offset.194
  %descriptor.owner.inside.200 = icmp ule i32 %local.check.owner.end.197, %context.value.199
  %descriptor.offset.inside.201 = icmp ule i32 %local.check.offset.194, %local.check.owner.end.197
  %descriptor.extent.inside.203 = icmp ule i32 %local.check.extent.195, %stack.sub.202
  %descriptor.payload.inside.204 = icmp ule i32 %local.check.payload.196, %local.check.extent.195
  %descriptor.owner.offset.valid.205 = and i1 %descriptor.owner.inside.200, %descriptor.offset.inside.201
  %descriptor.range.inside.207 = and i1 %descriptor.owner.offset.valid.205, %descriptor.extent.inside.203
  %descriptor.range.valid.206 = and i1 %descriptor.range.inside.207, %descriptor.payload.inside.204
  br i1 %descriptor.range.valid.206, label %descriptor.valid.208, label %descriptor.invalid.209
descriptor.invalid.209:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.208:
  %descriptor.initialized.status.210 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.194, i32 %local.check.extent.195)
  %helper.ok.211 = icmp eq i32 %descriptor.initialized.status.210, 0
  br i1 %helper.ok.211, label %helper.continue.212, label %frame.failure.0
helper.continue.212:
  br label %local.descriptor.checked.193
local.descriptor.inactive.192:
  br label %local.descriptor.checked.193
local.descriptor.checked.193:
  %step.status.213 = call i32 @al_owning_charge_step(ptr %ctx, i32 8)
  %helper.ok.214 = icmp eq i32 %step.status.213, 0
  br i1 %helper.ok.214, label %helper.continue.215, label %frame.failure.0
helper.continue.215:
  store i1 true, ptr %local.active.8, align 1
  store i32 %descriptor.value.41, ptr %local.offset.9, align 4
  store i32 %descriptor.value.43, ptr %local.extent.10, align 4
  store i32 %descriptor.value.45, ptr %local.payload.11, align 4
  store i32 %descriptor.value.47, ptr %local.owner.end.12, align 4
  store i32 5, ptr %local.type.13, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.41, i32 20, i32 %descriptor.value.45, i32 %descriptor.value.47, i32 %descriptor.value.43)
  %context.field.216 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.217 = load i32, ptr %context.field.216, align 4
  %runtime.ok.218 = icmp eq i32 %context.value.217, 0
  br i1 %runtime.ok.218, label %runtime.continue.219, label %frame.failure.0
runtime.continue.219:
  %local.is.active.220 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.220, label %local.descriptor.active.221, label %local.descriptor.inactive.222
local.descriptor.active.221:
  %local.check.offset.224 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.225 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.226 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.227 = load i32, ptr %local.owner.end.6, align 4
  %context.field.228 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.229 = load i32, ptr %context.field.228, align 4
  %stack.sub.232 = sub i32 %local.check.owner.end.227, %local.check.offset.224
  %descriptor.owner.inside.230 = icmp ule i32 %local.check.owner.end.227, %context.value.229
  %descriptor.offset.inside.231 = icmp ule i32 %local.check.offset.224, %local.check.owner.end.227
  %descriptor.extent.inside.233 = icmp ule i32 %local.check.extent.225, %stack.sub.232
  %descriptor.payload.inside.234 = icmp ule i32 %local.check.payload.226, %local.check.extent.225
  %descriptor.owner.offset.valid.235 = and i1 %descriptor.owner.inside.230, %descriptor.offset.inside.231
  %descriptor.range.inside.237 = and i1 %descriptor.owner.offset.valid.235, %descriptor.extent.inside.233
  %descriptor.range.valid.236 = and i1 %descriptor.range.inside.237, %descriptor.payload.inside.234
  br i1 %descriptor.range.valid.236, label %descriptor.valid.238, label %descriptor.invalid.239
descriptor.invalid.239:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.238:
  %descriptor.initialized.status.240 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.224, i32 %local.check.extent.225)
  %helper.ok.241 = icmp eq i32 %descriptor.initialized.status.240, 0
  br i1 %helper.ok.241, label %helper.continue.242, label %frame.failure.0
helper.continue.242:
  br label %local.descriptor.checked.223
local.descriptor.inactive.222:
  br label %local.descriptor.checked.223
local.descriptor.checked.223:
  %local.is.active.243 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.243, label %local.descriptor.active.244, label %local.descriptor.inactive.245
local.descriptor.active.244:
  %local.check.offset.247 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.248 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.249 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.250 = load i32, ptr %local.owner.end.12, align 4
  %context.field.251 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.252 = load i32, ptr %context.field.251, align 4
  %stack.sub.255 = sub i32 %local.check.owner.end.250, %local.check.offset.247
  %descriptor.owner.inside.253 = icmp ule i32 %local.check.owner.end.250, %context.value.252
  %descriptor.offset.inside.254 = icmp ule i32 %local.check.offset.247, %local.check.owner.end.250
  %descriptor.extent.inside.256 = icmp ule i32 %local.check.extent.248, %stack.sub.255
  %descriptor.payload.inside.257 = icmp ule i32 %local.check.payload.249, %local.check.extent.248
  %descriptor.owner.offset.valid.258 = and i1 %descriptor.owner.inside.253, %descriptor.offset.inside.254
  %descriptor.range.inside.260 = and i1 %descriptor.owner.offset.valid.258, %descriptor.extent.inside.256
  %descriptor.range.valid.259 = and i1 %descriptor.range.inside.260, %descriptor.payload.inside.257
  br i1 %descriptor.range.valid.259, label %descriptor.valid.261, label %descriptor.invalid.262
descriptor.invalid.262:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.261:
  %descriptor.initialized.status.263 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.247, i32 %local.check.extent.248)
  %helper.ok.264 = icmp eq i32 %descriptor.initialized.status.263, 0
  br i1 %helper.ok.264, label %helper.continue.265, label %frame.failure.0
helper.continue.265:
  br label %local.descriptor.checked.246
local.descriptor.inactive.245:
  br label %local.descriptor.checked.246
local.descriptor.checked.246:
  %local.is.active.266 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.266, label %local.descriptor.active.267, label %local.descriptor.inactive.268
local.descriptor.active.267:
  %local.check.offset.270 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.271 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.272 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.273 = load i32, ptr %local.owner.end.18, align 4
  %context.field.274 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.275 = load i32, ptr %context.field.274, align 4
  %stack.sub.278 = sub i32 %local.check.owner.end.273, %local.check.offset.270
  %descriptor.owner.inside.276 = icmp ule i32 %local.check.owner.end.273, %context.value.275
  %descriptor.offset.inside.277 = icmp ule i32 %local.check.offset.270, %local.check.owner.end.273
  %descriptor.extent.inside.279 = icmp ule i32 %local.check.extent.271, %stack.sub.278
  %descriptor.payload.inside.280 = icmp ule i32 %local.check.payload.272, %local.check.extent.271
  %descriptor.owner.offset.valid.281 = and i1 %descriptor.owner.inside.276, %descriptor.offset.inside.277
  %descriptor.range.inside.283 = and i1 %descriptor.owner.offset.valid.281, %descriptor.extent.inside.279
  %descriptor.range.valid.282 = and i1 %descriptor.range.inside.283, %descriptor.payload.inside.280
  br i1 %descriptor.range.valid.282, label %descriptor.valid.284, label %descriptor.invalid.285
descriptor.invalid.285:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.284:
  %descriptor.initialized.status.286 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.270, i32 %local.check.extent.271)
  %helper.ok.287 = icmp eq i32 %descriptor.initialized.status.286, 0
  br i1 %helper.ok.287, label %helper.continue.288, label %frame.failure.0
helper.continue.288:
  br label %local.descriptor.checked.269
local.descriptor.inactive.268:
  br label %local.descriptor.checked.269
local.descriptor.checked.269:
  %local.is.active.289 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.289, label %local.descriptor.active.290, label %local.descriptor.inactive.291
local.descriptor.active.290:
  %local.check.offset.293 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.294 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.295 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.296 = load i32, ptr %local.owner.end.24, align 4
  %context.field.297 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.298 = load i32, ptr %context.field.297, align 4
  %stack.sub.301 = sub i32 %local.check.owner.end.296, %local.check.offset.293
  %descriptor.owner.inside.299 = icmp ule i32 %local.check.owner.end.296, %context.value.298
  %descriptor.offset.inside.300 = icmp ule i32 %local.check.offset.293, %local.check.owner.end.296
  %descriptor.extent.inside.302 = icmp ule i32 %local.check.extent.294, %stack.sub.301
  %descriptor.payload.inside.303 = icmp ule i32 %local.check.payload.295, %local.check.extent.294
  %descriptor.owner.offset.valid.304 = and i1 %descriptor.owner.inside.299, %descriptor.offset.inside.300
  %descriptor.range.inside.306 = and i1 %descriptor.owner.offset.valid.304, %descriptor.extent.inside.302
  %descriptor.range.valid.305 = and i1 %descriptor.range.inside.306, %descriptor.payload.inside.303
  br i1 %descriptor.range.valid.305, label %descriptor.valid.307, label %descriptor.invalid.308
descriptor.invalid.308:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.307:
  %descriptor.initialized.status.309 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.293, i32 %local.check.extent.294)
  %helper.ok.310 = icmp eq i32 %descriptor.initialized.status.309, 0
  br i1 %helper.ok.310, label %helper.continue.311, label %frame.failure.0
helper.continue.311:
  br label %local.descriptor.checked.292
local.descriptor.inactive.291:
  br label %local.descriptor.checked.292
local.descriptor.checked.292:
  %step.status.312 = call i32 @al_owning_charge_step(ptr %ctx, i32 9)
  %helper.ok.313 = icmp eq i32 %step.status.312, 0
  br i1 %helper.ok.313, label %helper.continue.314, label %frame.failure.0
helper.continue.314:
  %context.field.315 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.316 = load i32, ptr %context.field.315, align 4
  store i1 false, ptr %local.active.20, align 1
  store i32 0, ptr %local.offset.21, align 4
  store i32 0, ptr %local.extent.22, align 4
  store i32 0, ptr %local.payload.23, align 4
  store i32 0, ptr %local.owner.end.24, align 4
  store i32 0, ptr %local.type.25, align 4
  %step.status.317 = call i32 @al_owning_charge_step(ptr %ctx, i32 10)
  %helper.ok.318 = icmp eq i32 %step.status.317, 0
  br i1 %helper.ok.318, label %helper.continue.319, label %frame.failure.0
helper.continue.319:
  %local.resolved.offset.320 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.321 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.322 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.323 = load i32, ptr %local.owner.end.6, align 4
  %context.field.324 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.325 = load i32, ptr %context.field.324, align 4
  %stack.sub.328 = sub i32 %local.resolved.owner.end.323, %local.resolved.offset.320
  %descriptor.owner.inside.326 = icmp ule i32 %local.resolved.owner.end.323, %context.value.325
  %descriptor.offset.inside.327 = icmp ule i32 %local.resolved.offset.320, %local.resolved.owner.end.323
  %descriptor.extent.inside.329 = icmp ule i32 %local.resolved.extent.321, %stack.sub.328
  %descriptor.payload.inside.330 = icmp ule i32 %local.resolved.payload.322, %local.resolved.extent.321
  %descriptor.owner.offset.valid.331 = and i1 %descriptor.owner.inside.326, %descriptor.offset.inside.327
  %descriptor.range.inside.333 = and i1 %descriptor.owner.offset.valid.331, %descriptor.extent.inside.329
  %descriptor.range.valid.332 = and i1 %descriptor.range.inside.333, %descriptor.payload.inside.330
  %descriptor.type.valid.334 = icmp eq i32 6, 6
  %descriptor.valid.335 = and i1 %descriptor.range.valid.332, %descriptor.type.valid.334
  br i1 %descriptor.valid.335, label %descriptor.valid.336, label %descriptor.invalid.337
descriptor.invalid.337:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.336:
  %descriptor.initialized.status.338 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.320, i32 %local.resolved.extent.321)
  %helper.ok.339 = icmp eq i32 %descriptor.initialized.status.338, 0
  br i1 %helper.ok.339, label %helper.continue.340, label %frame.failure.0
helper.continue.340:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %local.resolved.offset.320, i32 20, i32 %local.resolved.payload.322, i32 %local.resolved.owner.end.323, i32 %local.resolved.extent.321)
  %context.field.341 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.342 = load i32, ptr %context.field.341, align 4
  %runtime.ok.343 = icmp eq i32 %context.value.342, 0
  br i1 %runtime.ok.343, label %runtime.continue.344, label %frame.failure.0
runtime.continue.344:
  %context.field.345 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.346 = load i32, ptr %context.field.345, align 4
  %stack.sub.349 = sub i32 %local.resolved.owner.end.323, %local.resolved.offset.320
  %descriptor.owner.inside.347 = icmp ule i32 %local.resolved.owner.end.323, %context.value.346
  %descriptor.offset.inside.348 = icmp ule i32 %local.resolved.offset.320, %local.resolved.owner.end.323
  %descriptor.extent.inside.350 = icmp ule i32 %local.resolved.extent.321, %stack.sub.349
  %descriptor.payload.inside.351 = icmp ule i32 %local.resolved.payload.322, %local.resolved.extent.321
  %descriptor.owner.offset.valid.352 = and i1 %descriptor.owner.inside.347, %descriptor.offset.inside.348
  %descriptor.range.inside.354 = and i1 %descriptor.owner.offset.valid.352, %descriptor.extent.inside.350
  %descriptor.range.valid.353 = and i1 %descriptor.range.inside.354, %descriptor.payload.inside.351
  %descriptor.type.valid.355 = icmp eq i32 6, 6
  %descriptor.valid.356 = and i1 %descriptor.range.valid.353, %descriptor.type.valid.355
  br i1 %descriptor.valid.356, label %descriptor.valid.357, label %descriptor.invalid.358
descriptor.invalid.358:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.357:
  %descriptor.initialized.status.359 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.320, i32 %local.resolved.extent.321)
  %helper.ok.360 = icmp eq i32 %descriptor.initialized.status.359, 0
  br i1 %helper.ok.360, label %helper.continue.361, label %frame.failure.0
helper.continue.361:
  %local.is.active.362 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.362, label %local.descriptor.active.363, label %local.descriptor.inactive.364
local.descriptor.active.363:
  %local.check.offset.366 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.367 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.368 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.369 = load i32, ptr %local.owner.end.6, align 4
  %context.field.370 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.371 = load i32, ptr %context.field.370, align 4
  %stack.sub.374 = sub i32 %local.check.owner.end.369, %local.check.offset.366
  %descriptor.owner.inside.372 = icmp ule i32 %local.check.owner.end.369, %context.value.371
  %descriptor.offset.inside.373 = icmp ule i32 %local.check.offset.366, %local.check.owner.end.369
  %descriptor.extent.inside.375 = icmp ule i32 %local.check.extent.367, %stack.sub.374
  %descriptor.payload.inside.376 = icmp ule i32 %local.check.payload.368, %local.check.extent.367
  %descriptor.owner.offset.valid.377 = and i1 %descriptor.owner.inside.372, %descriptor.offset.inside.373
  %descriptor.range.inside.379 = and i1 %descriptor.owner.offset.valid.377, %descriptor.extent.inside.375
  %descriptor.range.valid.378 = and i1 %descriptor.range.inside.379, %descriptor.payload.inside.376
  br i1 %descriptor.range.valid.378, label %descriptor.valid.380, label %descriptor.invalid.381
descriptor.invalid.381:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.380:
  %descriptor.initialized.status.382 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.366, i32 %local.check.extent.367)
  %helper.ok.383 = icmp eq i32 %descriptor.initialized.status.382, 0
  br i1 %helper.ok.383, label %helper.continue.384, label %frame.failure.0
helper.continue.384:
  br label %local.descriptor.checked.365
local.descriptor.inactive.364:
  br label %local.descriptor.checked.365
local.descriptor.checked.365:
  %local.is.active.385 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.385, label %local.descriptor.active.386, label %local.descriptor.inactive.387
local.descriptor.active.386:
  %local.check.offset.389 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.390 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.391 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.392 = load i32, ptr %local.owner.end.12, align 4
  %context.field.393 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.394 = load i32, ptr %context.field.393, align 4
  %stack.sub.397 = sub i32 %local.check.owner.end.392, %local.check.offset.389
  %descriptor.owner.inside.395 = icmp ule i32 %local.check.owner.end.392, %context.value.394
  %descriptor.offset.inside.396 = icmp ule i32 %local.check.offset.389, %local.check.owner.end.392
  %descriptor.extent.inside.398 = icmp ule i32 %local.check.extent.390, %stack.sub.397
  %descriptor.payload.inside.399 = icmp ule i32 %local.check.payload.391, %local.check.extent.390
  %descriptor.owner.offset.valid.400 = and i1 %descriptor.owner.inside.395, %descriptor.offset.inside.396
  %descriptor.range.inside.402 = and i1 %descriptor.owner.offset.valid.400, %descriptor.extent.inside.398
  %descriptor.range.valid.401 = and i1 %descriptor.range.inside.402, %descriptor.payload.inside.399
  br i1 %descriptor.range.valid.401, label %descriptor.valid.403, label %descriptor.invalid.404
descriptor.invalid.404:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.403:
  %descriptor.initialized.status.405 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.389, i32 %local.check.extent.390)
  %helper.ok.406 = icmp eq i32 %descriptor.initialized.status.405, 0
  br i1 %helper.ok.406, label %helper.continue.407, label %frame.failure.0
helper.continue.407:
  br label %local.descriptor.checked.388
local.descriptor.inactive.387:
  br label %local.descriptor.checked.388
local.descriptor.checked.388:
  %local.is.active.408 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.408, label %local.descriptor.active.409, label %local.descriptor.inactive.410
local.descriptor.active.409:
  %local.check.offset.412 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.413 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.414 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.415 = load i32, ptr %local.owner.end.18, align 4
  %context.field.416 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.417 = load i32, ptr %context.field.416, align 4
  %stack.sub.420 = sub i32 %local.check.owner.end.415, %local.check.offset.412
  %descriptor.owner.inside.418 = icmp ule i32 %local.check.owner.end.415, %context.value.417
  %descriptor.offset.inside.419 = icmp ule i32 %local.check.offset.412, %local.check.owner.end.415
  %descriptor.extent.inside.421 = icmp ule i32 %local.check.extent.413, %stack.sub.420
  %descriptor.payload.inside.422 = icmp ule i32 %local.check.payload.414, %local.check.extent.413
  %descriptor.owner.offset.valid.423 = and i1 %descriptor.owner.inside.418, %descriptor.offset.inside.419
  %descriptor.range.inside.425 = and i1 %descriptor.owner.offset.valid.423, %descriptor.extent.inside.421
  %descriptor.range.valid.424 = and i1 %descriptor.range.inside.425, %descriptor.payload.inside.422
  br i1 %descriptor.range.valid.424, label %descriptor.valid.426, label %descriptor.invalid.427
descriptor.invalid.427:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.426:
  %descriptor.initialized.status.428 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.412, i32 %local.check.extent.413)
  %helper.ok.429 = icmp eq i32 %descriptor.initialized.status.428, 0
  br i1 %helper.ok.429, label %helper.continue.430, label %frame.failure.0
helper.continue.430:
  br label %local.descriptor.checked.411
local.descriptor.inactive.410:
  br label %local.descriptor.checked.411
local.descriptor.checked.411:
  %local.is.active.431 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.431, label %local.descriptor.active.432, label %local.descriptor.inactive.433
local.descriptor.active.432:
  %local.check.offset.435 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.436 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.437 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.438 = load i32, ptr %local.owner.end.24, align 4
  %context.field.439 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.440 = load i32, ptr %context.field.439, align 4
  %stack.sub.443 = sub i32 %local.check.owner.end.438, %local.check.offset.435
  %descriptor.owner.inside.441 = icmp ule i32 %local.check.owner.end.438, %context.value.440
  %descriptor.offset.inside.442 = icmp ule i32 %local.check.offset.435, %local.check.owner.end.438
  %descriptor.extent.inside.444 = icmp ule i32 %local.check.extent.436, %stack.sub.443
  %descriptor.payload.inside.445 = icmp ule i32 %local.check.payload.437, %local.check.extent.436
  %descriptor.owner.offset.valid.446 = and i1 %descriptor.owner.inside.441, %descriptor.offset.inside.442
  %descriptor.range.inside.448 = and i1 %descriptor.owner.offset.valid.446, %descriptor.extent.inside.444
  %descriptor.range.valid.447 = and i1 %descriptor.range.inside.448, %descriptor.payload.inside.445
  br i1 %descriptor.range.valid.447, label %descriptor.valid.449, label %descriptor.invalid.450
descriptor.invalid.450:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.449:
  %descriptor.initialized.status.451 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.435, i32 %local.check.extent.436)
  %helper.ok.452 = icmp eq i32 %descriptor.initialized.status.451, 0
  br i1 %helper.ok.452, label %helper.continue.453, label %frame.failure.0
helper.continue.453:
  br label %local.descriptor.checked.434
local.descriptor.inactive.433:
  br label %local.descriptor.checked.434
local.descriptor.checked.434:
  %step.status.454 = call i32 @al_owning_charge_step(ptr %ctx, i32 11)
  %helper.ok.455 = icmp eq i32 %step.status.454, 0
  br i1 %helper.ok.455, label %helper.continue.456, label %frame.failure.0
helper.continue.456:
  store i1 true, ptr %local.active.20, align 1
  store i32 %local.resolved.offset.320, ptr %local.offset.21, align 4
  store i32 %local.resolved.extent.321, ptr %local.extent.22, align 4
  store i32 %local.resolved.payload.322, ptr %local.payload.23, align 4
  store i32 %local.resolved.owner.end.323, ptr %local.owner.end.24, align 4
  store i32 6, ptr %local.type.25, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %local.resolved.offset.320, i32 20, i32 %local.resolved.payload.322, i32 %local.resolved.owner.end.323, i32 %local.resolved.extent.321)
  %context.field.457 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.458 = load i32, ptr %context.field.457, align 4
  %runtime.ok.459 = icmp eq i32 %context.value.458, 0
  br i1 %runtime.ok.459, label %runtime.continue.460, label %frame.failure.0
runtime.continue.460:
  %local.is.active.461 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.461, label %local.descriptor.active.462, label %local.descriptor.inactive.463
local.descriptor.active.462:
  %local.check.offset.465 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.466 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.467 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.468 = load i32, ptr %local.owner.end.6, align 4
  %context.field.469 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.470 = load i32, ptr %context.field.469, align 4
  %stack.sub.473 = sub i32 %local.check.owner.end.468, %local.check.offset.465
  %descriptor.owner.inside.471 = icmp ule i32 %local.check.owner.end.468, %context.value.470
  %descriptor.offset.inside.472 = icmp ule i32 %local.check.offset.465, %local.check.owner.end.468
  %descriptor.extent.inside.474 = icmp ule i32 %local.check.extent.466, %stack.sub.473
  %descriptor.payload.inside.475 = icmp ule i32 %local.check.payload.467, %local.check.extent.466
  %descriptor.owner.offset.valid.476 = and i1 %descriptor.owner.inside.471, %descriptor.offset.inside.472
  %descriptor.range.inside.478 = and i1 %descriptor.owner.offset.valid.476, %descriptor.extent.inside.474
  %descriptor.range.valid.477 = and i1 %descriptor.range.inside.478, %descriptor.payload.inside.475
  br i1 %descriptor.range.valid.477, label %descriptor.valid.479, label %descriptor.invalid.480
descriptor.invalid.480:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.479:
  %descriptor.initialized.status.481 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.465, i32 %local.check.extent.466)
  %helper.ok.482 = icmp eq i32 %descriptor.initialized.status.481, 0
  br i1 %helper.ok.482, label %helper.continue.483, label %frame.failure.0
helper.continue.483:
  br label %local.descriptor.checked.464
local.descriptor.inactive.463:
  br label %local.descriptor.checked.464
local.descriptor.checked.464:
  %local.is.active.484 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.484, label %local.descriptor.active.485, label %local.descriptor.inactive.486
local.descriptor.active.485:
  %local.check.offset.488 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.489 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.490 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.491 = load i32, ptr %local.owner.end.12, align 4
  %context.field.492 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.493 = load i32, ptr %context.field.492, align 4
  %stack.sub.496 = sub i32 %local.check.owner.end.491, %local.check.offset.488
  %descriptor.owner.inside.494 = icmp ule i32 %local.check.owner.end.491, %context.value.493
  %descriptor.offset.inside.495 = icmp ule i32 %local.check.offset.488, %local.check.owner.end.491
  %descriptor.extent.inside.497 = icmp ule i32 %local.check.extent.489, %stack.sub.496
  %descriptor.payload.inside.498 = icmp ule i32 %local.check.payload.490, %local.check.extent.489
  %descriptor.owner.offset.valid.499 = and i1 %descriptor.owner.inside.494, %descriptor.offset.inside.495
  %descriptor.range.inside.501 = and i1 %descriptor.owner.offset.valid.499, %descriptor.extent.inside.497
  %descriptor.range.valid.500 = and i1 %descriptor.range.inside.501, %descriptor.payload.inside.498
  br i1 %descriptor.range.valid.500, label %descriptor.valid.502, label %descriptor.invalid.503
descriptor.invalid.503:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.502:
  %descriptor.initialized.status.504 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.488, i32 %local.check.extent.489)
  %helper.ok.505 = icmp eq i32 %descriptor.initialized.status.504, 0
  br i1 %helper.ok.505, label %helper.continue.506, label %frame.failure.0
helper.continue.506:
  br label %local.descriptor.checked.487
local.descriptor.inactive.486:
  br label %local.descriptor.checked.487
local.descriptor.checked.487:
  %local.is.active.507 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.507, label %local.descriptor.active.508, label %local.descriptor.inactive.509
local.descriptor.active.508:
  %local.check.offset.511 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.512 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.513 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.514 = load i32, ptr %local.owner.end.18, align 4
  %context.field.515 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.516 = load i32, ptr %context.field.515, align 4
  %stack.sub.519 = sub i32 %local.check.owner.end.514, %local.check.offset.511
  %descriptor.owner.inside.517 = icmp ule i32 %local.check.owner.end.514, %context.value.516
  %descriptor.offset.inside.518 = icmp ule i32 %local.check.offset.511, %local.check.owner.end.514
  %descriptor.extent.inside.520 = icmp ule i32 %local.check.extent.512, %stack.sub.519
  %descriptor.payload.inside.521 = icmp ule i32 %local.check.payload.513, %local.check.extent.512
  %descriptor.owner.offset.valid.522 = and i1 %descriptor.owner.inside.517, %descriptor.offset.inside.518
  %descriptor.range.inside.524 = and i1 %descriptor.owner.offset.valid.522, %descriptor.extent.inside.520
  %descriptor.range.valid.523 = and i1 %descriptor.range.inside.524, %descriptor.payload.inside.521
  br i1 %descriptor.range.valid.523, label %descriptor.valid.525, label %descriptor.invalid.526
descriptor.invalid.526:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.525:
  %descriptor.initialized.status.527 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.511, i32 %local.check.extent.512)
  %helper.ok.528 = icmp eq i32 %descriptor.initialized.status.527, 0
  br i1 %helper.ok.528, label %helper.continue.529, label %frame.failure.0
helper.continue.529:
  br label %local.descriptor.checked.510
local.descriptor.inactive.509:
  br label %local.descriptor.checked.510
local.descriptor.checked.510:
  %local.is.active.530 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.530, label %local.descriptor.active.531, label %local.descriptor.inactive.532
local.descriptor.active.531:
  %local.check.offset.534 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.535 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.536 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.537 = load i32, ptr %local.owner.end.24, align 4
  %context.field.538 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.539 = load i32, ptr %context.field.538, align 4
  %stack.sub.542 = sub i32 %local.check.owner.end.537, %local.check.offset.534
  %descriptor.owner.inside.540 = icmp ule i32 %local.check.owner.end.537, %context.value.539
  %descriptor.offset.inside.541 = icmp ule i32 %local.check.offset.534, %local.check.owner.end.537
  %descriptor.extent.inside.543 = icmp ule i32 %local.check.extent.535, %stack.sub.542
  %descriptor.payload.inside.544 = icmp ule i32 %local.check.payload.536, %local.check.extent.535
  %descriptor.owner.offset.valid.545 = and i1 %descriptor.owner.inside.540, %descriptor.offset.inside.541
  %descriptor.range.inside.547 = and i1 %descriptor.owner.offset.valid.545, %descriptor.extent.inside.543
  %descriptor.range.valid.546 = and i1 %descriptor.range.inside.547, %descriptor.payload.inside.544
  br i1 %descriptor.range.valid.546, label %descriptor.valid.548, label %descriptor.invalid.549
descriptor.invalid.549:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.548:
  %descriptor.initialized.status.550 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.534, i32 %local.check.extent.535)
  %helper.ok.551 = icmp eq i32 %descriptor.initialized.status.550, 0
  br i1 %helper.ok.551, label %helper.continue.552, label %frame.failure.0
helper.continue.552:
  br label %local.descriptor.checked.533
local.descriptor.inactive.532:
  br label %local.descriptor.checked.533
local.descriptor.checked.533:
  %step.status.553 = call i32 @al_owning_charge_step(ptr %ctx, i32 12)
  %helper.ok.554 = icmp eq i32 %step.status.553, 0
  br i1 %helper.ok.554, label %helper.continue.555, label %frame.failure.0
helper.continue.555:
  %local.resolved.offset.556 = load i32, ptr %local.offset.21, align 4
  %local.resolved.extent.557 = load i32, ptr %local.extent.22, align 4
  %local.resolved.payload.558 = load i32, ptr %local.payload.23, align 4
  %local.resolved.owner.end.559 = load i32, ptr %local.owner.end.24, align 4
  %context.field.560 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.561 = load i32, ptr %context.field.560, align 4
  %stack.sub.564 = sub i32 %local.resolved.owner.end.559, %local.resolved.offset.556
  %descriptor.owner.inside.562 = icmp ule i32 %local.resolved.owner.end.559, %context.value.561
  %descriptor.offset.inside.563 = icmp ule i32 %local.resolved.offset.556, %local.resolved.owner.end.559
  %descriptor.extent.inside.565 = icmp ule i32 %local.resolved.extent.557, %stack.sub.564
  %descriptor.payload.inside.566 = icmp ule i32 %local.resolved.payload.558, %local.resolved.extent.557
  %descriptor.owner.offset.valid.567 = and i1 %descriptor.owner.inside.562, %descriptor.offset.inside.563
  %descriptor.range.inside.569 = and i1 %descriptor.owner.offset.valid.567, %descriptor.extent.inside.565
  %descriptor.range.valid.568 = and i1 %descriptor.range.inside.569, %descriptor.payload.inside.566
  %descriptor.type.valid.570 = icmp eq i32 6, 6
  %descriptor.valid.571 = and i1 %descriptor.range.valid.568, %descriptor.type.valid.570
  br i1 %descriptor.valid.571, label %descriptor.valid.572, label %descriptor.invalid.573
descriptor.invalid.573:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.572:
  %descriptor.initialized.status.574 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.556, i32 %local.resolved.extent.557)
  %helper.ok.575 = icmp eq i32 %descriptor.initialized.status.574, 0
  br i1 %helper.ok.575, label %helper.continue.576, label %frame.failure.0
helper.continue.576:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %local.resolved.offset.556, i32 20, i32 %local.resolved.payload.558, i32 %local.resolved.owner.end.559, i32 %local.resolved.extent.557)
  %context.field.577 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.578 = load i32, ptr %context.field.577, align 4
  %runtime.ok.579 = icmp eq i32 %context.value.578, 0
  br i1 %runtime.ok.579, label %runtime.continue.580, label %frame.failure.0
runtime.continue.580:
  %context.field.581 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.582 = load i32, ptr %context.field.581, align 4
  %stack.sub.585 = sub i32 %local.resolved.owner.end.559, %local.resolved.offset.556
  %descriptor.owner.inside.583 = icmp ule i32 %local.resolved.owner.end.559, %context.value.582
  %descriptor.offset.inside.584 = icmp ule i32 %local.resolved.offset.556, %local.resolved.owner.end.559
  %descriptor.extent.inside.586 = icmp ule i32 %local.resolved.extent.557, %stack.sub.585
  %descriptor.payload.inside.587 = icmp ule i32 %local.resolved.payload.558, %local.resolved.extent.557
  %descriptor.owner.offset.valid.588 = and i1 %descriptor.owner.inside.583, %descriptor.offset.inside.584
  %descriptor.range.inside.590 = and i1 %descriptor.owner.offset.valid.588, %descriptor.extent.inside.586
  %descriptor.range.valid.589 = and i1 %descriptor.range.inside.590, %descriptor.payload.inside.587
  %descriptor.type.valid.591 = icmp eq i32 6, 6
  %descriptor.valid.592 = and i1 %descriptor.range.valid.589, %descriptor.type.valid.591
  br i1 %descriptor.valid.592, label %descriptor.valid.593, label %descriptor.invalid.594
descriptor.invalid.594:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.593:
  %descriptor.initialized.status.595 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.556, i32 %local.resolved.extent.557)
  %helper.ok.596 = icmp eq i32 %descriptor.initialized.status.595, 0
  br i1 %helper.ok.596, label %helper.continue.597, label %frame.failure.0
helper.continue.597:
  %local.is.active.598 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.598, label %local.descriptor.active.599, label %local.descriptor.inactive.600
local.descriptor.active.599:
  %local.check.offset.602 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.603 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.604 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.605 = load i32, ptr %local.owner.end.6, align 4
  %context.field.606 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.607 = load i32, ptr %context.field.606, align 4
  %stack.sub.610 = sub i32 %local.check.owner.end.605, %local.check.offset.602
  %descriptor.owner.inside.608 = icmp ule i32 %local.check.owner.end.605, %context.value.607
  %descriptor.offset.inside.609 = icmp ule i32 %local.check.offset.602, %local.check.owner.end.605
  %descriptor.extent.inside.611 = icmp ule i32 %local.check.extent.603, %stack.sub.610
  %descriptor.payload.inside.612 = icmp ule i32 %local.check.payload.604, %local.check.extent.603
  %descriptor.owner.offset.valid.613 = and i1 %descriptor.owner.inside.608, %descriptor.offset.inside.609
  %descriptor.range.inside.615 = and i1 %descriptor.owner.offset.valid.613, %descriptor.extent.inside.611
  %descriptor.range.valid.614 = and i1 %descriptor.range.inside.615, %descriptor.payload.inside.612
  br i1 %descriptor.range.valid.614, label %descriptor.valid.616, label %descriptor.invalid.617
descriptor.invalid.617:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.616:
  %descriptor.initialized.status.618 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.602, i32 %local.check.extent.603)
  %helper.ok.619 = icmp eq i32 %descriptor.initialized.status.618, 0
  br i1 %helper.ok.619, label %helper.continue.620, label %frame.failure.0
helper.continue.620:
  br label %local.descriptor.checked.601
local.descriptor.inactive.600:
  br label %local.descriptor.checked.601
local.descriptor.checked.601:
  %local.is.active.621 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.621, label %local.descriptor.active.622, label %local.descriptor.inactive.623
local.descriptor.active.622:
  %local.check.offset.625 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.626 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.627 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.628 = load i32, ptr %local.owner.end.12, align 4
  %context.field.629 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.630 = load i32, ptr %context.field.629, align 4
  %stack.sub.633 = sub i32 %local.check.owner.end.628, %local.check.offset.625
  %descriptor.owner.inside.631 = icmp ule i32 %local.check.owner.end.628, %context.value.630
  %descriptor.offset.inside.632 = icmp ule i32 %local.check.offset.625, %local.check.owner.end.628
  %descriptor.extent.inside.634 = icmp ule i32 %local.check.extent.626, %stack.sub.633
  %descriptor.payload.inside.635 = icmp ule i32 %local.check.payload.627, %local.check.extent.626
  %descriptor.owner.offset.valid.636 = and i1 %descriptor.owner.inside.631, %descriptor.offset.inside.632
  %descriptor.range.inside.638 = and i1 %descriptor.owner.offset.valid.636, %descriptor.extent.inside.634
  %descriptor.range.valid.637 = and i1 %descriptor.range.inside.638, %descriptor.payload.inside.635
  br i1 %descriptor.range.valid.637, label %descriptor.valid.639, label %descriptor.invalid.640
descriptor.invalid.640:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.639:
  %descriptor.initialized.status.641 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.625, i32 %local.check.extent.626)
  %helper.ok.642 = icmp eq i32 %descriptor.initialized.status.641, 0
  br i1 %helper.ok.642, label %helper.continue.643, label %frame.failure.0
helper.continue.643:
  br label %local.descriptor.checked.624
local.descriptor.inactive.623:
  br label %local.descriptor.checked.624
local.descriptor.checked.624:
  %local.is.active.644 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.644, label %local.descriptor.active.645, label %local.descriptor.inactive.646
local.descriptor.active.645:
  %local.check.offset.648 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.649 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.650 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.651 = load i32, ptr %local.owner.end.18, align 4
  %context.field.652 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.653 = load i32, ptr %context.field.652, align 4
  %stack.sub.656 = sub i32 %local.check.owner.end.651, %local.check.offset.648
  %descriptor.owner.inside.654 = icmp ule i32 %local.check.owner.end.651, %context.value.653
  %descriptor.offset.inside.655 = icmp ule i32 %local.check.offset.648, %local.check.owner.end.651
  %descriptor.extent.inside.657 = icmp ule i32 %local.check.extent.649, %stack.sub.656
  %descriptor.payload.inside.658 = icmp ule i32 %local.check.payload.650, %local.check.extent.649
  %descriptor.owner.offset.valid.659 = and i1 %descriptor.owner.inside.654, %descriptor.offset.inside.655
  %descriptor.range.inside.661 = and i1 %descriptor.owner.offset.valid.659, %descriptor.extent.inside.657
  %descriptor.range.valid.660 = and i1 %descriptor.range.inside.661, %descriptor.payload.inside.658
  br i1 %descriptor.range.valid.660, label %descriptor.valid.662, label %descriptor.invalid.663
descriptor.invalid.663:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.662:
  %descriptor.initialized.status.664 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.648, i32 %local.check.extent.649)
  %helper.ok.665 = icmp eq i32 %descriptor.initialized.status.664, 0
  br i1 %helper.ok.665, label %helper.continue.666, label %frame.failure.0
helper.continue.666:
  br label %local.descriptor.checked.647
local.descriptor.inactive.646:
  br label %local.descriptor.checked.647
local.descriptor.checked.647:
  %local.is.active.667 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.667, label %local.descriptor.active.668, label %local.descriptor.inactive.669
local.descriptor.active.668:
  %local.check.offset.671 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.672 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.673 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.674 = load i32, ptr %local.owner.end.24, align 4
  %context.field.675 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.676 = load i32, ptr %context.field.675, align 4
  %stack.sub.679 = sub i32 %local.check.owner.end.674, %local.check.offset.671
  %descriptor.owner.inside.677 = icmp ule i32 %local.check.owner.end.674, %context.value.676
  %descriptor.offset.inside.678 = icmp ule i32 %local.check.offset.671, %local.check.owner.end.674
  %descriptor.extent.inside.680 = icmp ule i32 %local.check.extent.672, %stack.sub.679
  %descriptor.payload.inside.681 = icmp ule i32 %local.check.payload.673, %local.check.extent.672
  %descriptor.owner.offset.valid.682 = and i1 %descriptor.owner.inside.677, %descriptor.offset.inside.678
  %descriptor.range.inside.684 = and i1 %descriptor.owner.offset.valid.682, %descriptor.extent.inside.680
  %descriptor.range.valid.683 = and i1 %descriptor.range.inside.684, %descriptor.payload.inside.681
  br i1 %descriptor.range.valid.683, label %descriptor.valid.685, label %descriptor.invalid.686
descriptor.invalid.686:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.685:
  %descriptor.initialized.status.687 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.671, i32 %local.check.extent.672)
  %helper.ok.688 = icmp eq i32 %descriptor.initialized.status.687, 0
  br i1 %helper.ok.688, label %helper.continue.689, label %frame.failure.0
helper.continue.689:
  br label %local.descriptor.checked.670
local.descriptor.inactive.669:
  br label %local.descriptor.checked.670
local.descriptor.checked.670:
  %step.status.690 = call i32 @al_owning_charge_step(ptr %ctx, i32 13)
  %helper.ok.691 = icmp eq i32 %step.status.690, 0
  br i1 %helper.ok.691, label %helper.continue.692, label %frame.failure.0
helper.continue.692:
  %context.field.693 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.694 = load i32, ptr %context.field.693, align 4
  %inline.target.depth.within.interpreter.limit.695 = icmp ule i32 %context.value.694, 65
  br i1 %inline.target.depth.within.interpreter.limit.695, label %inline.target.depth.ok.696, label %inline.target.depth.invalid.697
inline.target.depth.invalid.697:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 14, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.696:
  %stack.offset.698 = add i32 0, %local.resolved.payload.558
  %stack.offset.699 = add i32 0, %local.resolved.extent.557
  %context.field.700 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.701 = load i32, ptr %context.field.700, align 4
  %stack.offset.702 = add i32 %context.value.701, %stack.offset.699
  %reserve.status.703 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.702, i32 15)
  %reserve.ok.704 = icmp eq i32 %reserve.status.703, 0
  br i1 %reserve.ok.704, label %reserve.continue.705, label %frame.failure.0
reserve.continue.705:
  %stack.offset.706 = add i32 %context.value.701, 0
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.706, i32 %local.resolved.offset.556, i32 %local.resolved.extent.557, i32 %local.resolved.payload.558, i32 6, i32 6)
  %context.field.707 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.708 = load i32, ptr %context.field.707, align 4
  %runtime.ok.709 = icmp eq i32 %context.value.708, 0
  br i1 %runtime.ok.709, label %runtime.continue.710, label %frame.failure.0
runtime.continue.710:
  %stack.offset.711 = add i32 0, %local.resolved.extent.557
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 4, i32 %context.value.701, i32 %stack.offset.699, i32 %stack.offset.698, i32 0, i32 0)
  %context.field.712 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.713 = load i32, ptr %context.field.712, align 4
  %runtime.ok.714 = icmp eq i32 %context.value.713, 0
  br i1 %runtime.ok.714, label %runtime.continue.715, label %frame.failure.0
runtime.continue.715:
  %context.field.716 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.717 = load i32, ptr %context.field.716, align 4
  %stack.sub.720 = sub i32 %stack.offset.702, %context.value.701
  %descriptor.owner.inside.718 = icmp ule i32 %stack.offset.702, %context.value.717
  %descriptor.offset.inside.719 = icmp ule i32 %context.value.701, %stack.offset.702
  %descriptor.extent.inside.721 = icmp ule i32 %stack.offset.699, %stack.sub.720
  %descriptor.payload.inside.722 = icmp ule i32 %stack.offset.698, %stack.offset.699
  %descriptor.owner.offset.valid.723 = and i1 %descriptor.owner.inside.718, %descriptor.offset.inside.719
  %descriptor.range.inside.725 = and i1 %descriptor.owner.offset.valid.723, %descriptor.extent.inside.721
  %descriptor.range.valid.724 = and i1 %descriptor.range.inside.725, %descriptor.payload.inside.722
  %descriptor.type.valid.726 = icmp eq i32 4, 4
  %descriptor.valid.727 = and i1 %descriptor.range.valid.724, %descriptor.type.valid.726
  br i1 %descriptor.valid.727, label %descriptor.valid.728, label %descriptor.invalid.729
descriptor.invalid.729:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.728:
  %descriptor.initialized.status.730 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.701, i32 %stack.offset.699)
  %helper.ok.731 = icmp eq i32 %descriptor.initialized.status.730, 0
  br i1 %helper.ok.731, label %helper.continue.732, label %frame.failure.0
helper.continue.732:
  %local.is.active.733 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.733, label %local.descriptor.active.734, label %local.descriptor.inactive.735
local.descriptor.active.734:
  %local.check.offset.737 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.738 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.739 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.740 = load i32, ptr %local.owner.end.6, align 4
  %context.field.741 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.742 = load i32, ptr %context.field.741, align 4
  %stack.sub.745 = sub i32 %local.check.owner.end.740, %local.check.offset.737
  %descriptor.owner.inside.743 = icmp ule i32 %local.check.owner.end.740, %context.value.742
  %descriptor.offset.inside.744 = icmp ule i32 %local.check.offset.737, %local.check.owner.end.740
  %descriptor.extent.inside.746 = icmp ule i32 %local.check.extent.738, %stack.sub.745
  %descriptor.payload.inside.747 = icmp ule i32 %local.check.payload.739, %local.check.extent.738
  %descriptor.owner.offset.valid.748 = and i1 %descriptor.owner.inside.743, %descriptor.offset.inside.744
  %descriptor.range.inside.750 = and i1 %descriptor.owner.offset.valid.748, %descriptor.extent.inside.746
  %descriptor.range.valid.749 = and i1 %descriptor.range.inside.750, %descriptor.payload.inside.747
  br i1 %descriptor.range.valid.749, label %descriptor.valid.751, label %descriptor.invalid.752
descriptor.invalid.752:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.751:
  %descriptor.initialized.status.753 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.737, i32 %local.check.extent.738)
  %helper.ok.754 = icmp eq i32 %descriptor.initialized.status.753, 0
  br i1 %helper.ok.754, label %helper.continue.755, label %frame.failure.0
helper.continue.755:
  br label %local.descriptor.checked.736
local.descriptor.inactive.735:
  br label %local.descriptor.checked.736
local.descriptor.checked.736:
  %local.is.active.756 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.756, label %local.descriptor.active.757, label %local.descriptor.inactive.758
local.descriptor.active.757:
  %local.check.offset.760 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.761 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.762 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.763 = load i32, ptr %local.owner.end.12, align 4
  %context.field.764 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.765 = load i32, ptr %context.field.764, align 4
  %stack.sub.768 = sub i32 %local.check.owner.end.763, %local.check.offset.760
  %descriptor.owner.inside.766 = icmp ule i32 %local.check.owner.end.763, %context.value.765
  %descriptor.offset.inside.767 = icmp ule i32 %local.check.offset.760, %local.check.owner.end.763
  %descriptor.extent.inside.769 = icmp ule i32 %local.check.extent.761, %stack.sub.768
  %descriptor.payload.inside.770 = icmp ule i32 %local.check.payload.762, %local.check.extent.761
  %descriptor.owner.offset.valid.771 = and i1 %descriptor.owner.inside.766, %descriptor.offset.inside.767
  %descriptor.range.inside.773 = and i1 %descriptor.owner.offset.valid.771, %descriptor.extent.inside.769
  %descriptor.range.valid.772 = and i1 %descriptor.range.inside.773, %descriptor.payload.inside.770
  br i1 %descriptor.range.valid.772, label %descriptor.valid.774, label %descriptor.invalid.775
descriptor.invalid.775:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.774:
  %descriptor.initialized.status.776 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.760, i32 %local.check.extent.761)
  %helper.ok.777 = icmp eq i32 %descriptor.initialized.status.776, 0
  br i1 %helper.ok.777, label %helper.continue.778, label %frame.failure.0
helper.continue.778:
  br label %local.descriptor.checked.759
local.descriptor.inactive.758:
  br label %local.descriptor.checked.759
local.descriptor.checked.759:
  %local.is.active.779 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.779, label %local.descriptor.active.780, label %local.descriptor.inactive.781
local.descriptor.active.780:
  %local.check.offset.783 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.784 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.785 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.786 = load i32, ptr %local.owner.end.18, align 4
  %context.field.787 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.788 = load i32, ptr %context.field.787, align 4
  %stack.sub.791 = sub i32 %local.check.owner.end.786, %local.check.offset.783
  %descriptor.owner.inside.789 = icmp ule i32 %local.check.owner.end.786, %context.value.788
  %descriptor.offset.inside.790 = icmp ule i32 %local.check.offset.783, %local.check.owner.end.786
  %descriptor.extent.inside.792 = icmp ule i32 %local.check.extent.784, %stack.sub.791
  %descriptor.payload.inside.793 = icmp ule i32 %local.check.payload.785, %local.check.extent.784
  %descriptor.owner.offset.valid.794 = and i1 %descriptor.owner.inside.789, %descriptor.offset.inside.790
  %descriptor.range.inside.796 = and i1 %descriptor.owner.offset.valid.794, %descriptor.extent.inside.792
  %descriptor.range.valid.795 = and i1 %descriptor.range.inside.796, %descriptor.payload.inside.793
  br i1 %descriptor.range.valid.795, label %descriptor.valid.797, label %descriptor.invalid.798
descriptor.invalid.798:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.797:
  %descriptor.initialized.status.799 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.783, i32 %local.check.extent.784)
  %helper.ok.800 = icmp eq i32 %descriptor.initialized.status.799, 0
  br i1 %helper.ok.800, label %helper.continue.801, label %frame.failure.0
helper.continue.801:
  br label %local.descriptor.checked.782
local.descriptor.inactive.781:
  br label %local.descriptor.checked.782
local.descriptor.checked.782:
  %local.is.active.802 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.802, label %local.descriptor.active.803, label %local.descriptor.inactive.804
local.descriptor.active.803:
  %local.check.offset.806 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.807 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.808 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.809 = load i32, ptr %local.owner.end.24, align 4
  %context.field.810 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.811 = load i32, ptr %context.field.810, align 4
  %stack.sub.814 = sub i32 %local.check.owner.end.809, %local.check.offset.806
  %descriptor.owner.inside.812 = icmp ule i32 %local.check.owner.end.809, %context.value.811
  %descriptor.offset.inside.813 = icmp ule i32 %local.check.offset.806, %local.check.owner.end.809
  %descriptor.extent.inside.815 = icmp ule i32 %local.check.extent.807, %stack.sub.814
  %descriptor.payload.inside.816 = icmp ule i32 %local.check.payload.808, %local.check.extent.807
  %descriptor.owner.offset.valid.817 = and i1 %descriptor.owner.inside.812, %descriptor.offset.inside.813
  %descriptor.range.inside.819 = and i1 %descriptor.owner.offset.valid.817, %descriptor.extent.inside.815
  %descriptor.range.valid.818 = and i1 %descriptor.range.inside.819, %descriptor.payload.inside.816
  br i1 %descriptor.range.valid.818, label %descriptor.valid.820, label %descriptor.invalid.821
descriptor.invalid.821:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.820:
  %descriptor.initialized.status.822 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.806, i32 %local.check.extent.807)
  %helper.ok.823 = icmp eq i32 %descriptor.initialized.status.822, 0
  br i1 %helper.ok.823, label %helper.continue.824, label %frame.failure.0
helper.continue.824:
  br label %local.descriptor.checked.805
local.descriptor.inactive.804:
  br label %local.descriptor.checked.805
local.descriptor.checked.805:
  store i1 false, ptr %local.active.20, align 1
  store i32 0, ptr %local.offset.21, align 4
  store i32 0, ptr %local.extent.22, align 4
  store i32 0, ptr %local.payload.23, align 4
  store i32 0, ptr %local.owner.end.24, align 4
  store i32 0, ptr %local.type.25, align 4
  %context.field.825 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.826 = load i32, ptr %context.field.825, align 4
  %stack.sub.829 = sub i32 %stack.offset.702, %context.value.701
  %descriptor.owner.inside.827 = icmp ule i32 %stack.offset.702, %context.value.826
  %descriptor.offset.inside.828 = icmp ule i32 %context.value.701, %stack.offset.702
  %descriptor.extent.inside.830 = icmp ule i32 %stack.offset.699, %stack.sub.829
  %descriptor.payload.inside.831 = icmp ule i32 %stack.offset.698, %stack.offset.699
  %descriptor.owner.offset.valid.832 = and i1 %descriptor.owner.inside.827, %descriptor.offset.inside.828
  %descriptor.range.inside.834 = and i1 %descriptor.owner.offset.valid.832, %descriptor.extent.inside.830
  %descriptor.range.valid.833 = and i1 %descriptor.range.inside.834, %descriptor.payload.inside.831
  %descriptor.type.valid.835 = icmp eq i32 4, 4
  %descriptor.valid.836 = and i1 %descriptor.range.valid.833, %descriptor.type.valid.835
  br i1 %descriptor.valid.836, label %descriptor.valid.837, label %descriptor.invalid.838
descriptor.invalid.838:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.837:
  %descriptor.initialized.status.839 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.701, i32 %stack.offset.699)
  %helper.ok.840 = icmp eq i32 %descriptor.initialized.status.839, 0
  br i1 %helper.ok.840, label %helper.continue.841, label %frame.failure.0
helper.continue.841:
  %local.is.active.842 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.842, label %local.descriptor.active.843, label %local.descriptor.inactive.844
local.descriptor.active.843:
  %local.check.offset.846 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.847 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.848 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.849 = load i32, ptr %local.owner.end.6, align 4
  %context.field.850 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.851 = load i32, ptr %context.field.850, align 4
  %stack.sub.854 = sub i32 %local.check.owner.end.849, %local.check.offset.846
  %descriptor.owner.inside.852 = icmp ule i32 %local.check.owner.end.849, %context.value.851
  %descriptor.offset.inside.853 = icmp ule i32 %local.check.offset.846, %local.check.owner.end.849
  %descriptor.extent.inside.855 = icmp ule i32 %local.check.extent.847, %stack.sub.854
  %descriptor.payload.inside.856 = icmp ule i32 %local.check.payload.848, %local.check.extent.847
  %descriptor.owner.offset.valid.857 = and i1 %descriptor.owner.inside.852, %descriptor.offset.inside.853
  %descriptor.range.inside.859 = and i1 %descriptor.owner.offset.valid.857, %descriptor.extent.inside.855
  %descriptor.range.valid.858 = and i1 %descriptor.range.inside.859, %descriptor.payload.inside.856
  br i1 %descriptor.range.valid.858, label %descriptor.valid.860, label %descriptor.invalid.861
descriptor.invalid.861:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.860:
  %descriptor.initialized.status.862 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.846, i32 %local.check.extent.847)
  %helper.ok.863 = icmp eq i32 %descriptor.initialized.status.862, 0
  br i1 %helper.ok.863, label %helper.continue.864, label %frame.failure.0
helper.continue.864:
  br label %local.descriptor.checked.845
local.descriptor.inactive.844:
  br label %local.descriptor.checked.845
local.descriptor.checked.845:
  %local.is.active.865 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.865, label %local.descriptor.active.866, label %local.descriptor.inactive.867
local.descriptor.active.866:
  %local.check.offset.869 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.870 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.871 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.872 = load i32, ptr %local.owner.end.12, align 4
  %context.field.873 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.874 = load i32, ptr %context.field.873, align 4
  %stack.sub.877 = sub i32 %local.check.owner.end.872, %local.check.offset.869
  %descriptor.owner.inside.875 = icmp ule i32 %local.check.owner.end.872, %context.value.874
  %descriptor.offset.inside.876 = icmp ule i32 %local.check.offset.869, %local.check.owner.end.872
  %descriptor.extent.inside.878 = icmp ule i32 %local.check.extent.870, %stack.sub.877
  %descriptor.payload.inside.879 = icmp ule i32 %local.check.payload.871, %local.check.extent.870
  %descriptor.owner.offset.valid.880 = and i1 %descriptor.owner.inside.875, %descriptor.offset.inside.876
  %descriptor.range.inside.882 = and i1 %descriptor.owner.offset.valid.880, %descriptor.extent.inside.878
  %descriptor.range.valid.881 = and i1 %descriptor.range.inside.882, %descriptor.payload.inside.879
  br i1 %descriptor.range.valid.881, label %descriptor.valid.883, label %descriptor.invalid.884
descriptor.invalid.884:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.883:
  %descriptor.initialized.status.885 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.869, i32 %local.check.extent.870)
  %helper.ok.886 = icmp eq i32 %descriptor.initialized.status.885, 0
  br i1 %helper.ok.886, label %helper.continue.887, label %frame.failure.0
helper.continue.887:
  br label %local.descriptor.checked.868
local.descriptor.inactive.867:
  br label %local.descriptor.checked.868
local.descriptor.checked.868:
  %local.is.active.888 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.888, label %local.descriptor.active.889, label %local.descriptor.inactive.890
local.descriptor.active.889:
  %local.check.offset.892 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.893 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.894 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.895 = load i32, ptr %local.owner.end.18, align 4
  %context.field.896 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.897 = load i32, ptr %context.field.896, align 4
  %stack.sub.900 = sub i32 %local.check.owner.end.895, %local.check.offset.892
  %descriptor.owner.inside.898 = icmp ule i32 %local.check.owner.end.895, %context.value.897
  %descriptor.offset.inside.899 = icmp ule i32 %local.check.offset.892, %local.check.owner.end.895
  %descriptor.extent.inside.901 = icmp ule i32 %local.check.extent.893, %stack.sub.900
  %descriptor.payload.inside.902 = icmp ule i32 %local.check.payload.894, %local.check.extent.893
  %descriptor.owner.offset.valid.903 = and i1 %descriptor.owner.inside.898, %descriptor.offset.inside.899
  %descriptor.range.inside.905 = and i1 %descriptor.owner.offset.valid.903, %descriptor.extent.inside.901
  %descriptor.range.valid.904 = and i1 %descriptor.range.inside.905, %descriptor.payload.inside.902
  br i1 %descriptor.range.valid.904, label %descriptor.valid.906, label %descriptor.invalid.907
descriptor.invalid.907:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.906:
  %descriptor.initialized.status.908 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.892, i32 %local.check.extent.893)
  %helper.ok.909 = icmp eq i32 %descriptor.initialized.status.908, 0
  br i1 %helper.ok.909, label %helper.continue.910, label %frame.failure.0
helper.continue.910:
  br label %local.descriptor.checked.891
local.descriptor.inactive.890:
  br label %local.descriptor.checked.891
local.descriptor.checked.891:
  %local.is.active.911 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.911, label %local.descriptor.active.912, label %local.descriptor.inactive.913
local.descriptor.active.912:
  %local.check.offset.915 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.916 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.917 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.918 = load i32, ptr %local.owner.end.24, align 4
  %context.field.919 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.920 = load i32, ptr %context.field.919, align 4
  %stack.sub.923 = sub i32 %local.check.owner.end.918, %local.check.offset.915
  %descriptor.owner.inside.921 = icmp ule i32 %local.check.owner.end.918, %context.value.920
  %descriptor.offset.inside.922 = icmp ule i32 %local.check.offset.915, %local.check.owner.end.918
  %descriptor.extent.inside.924 = icmp ule i32 %local.check.extent.916, %stack.sub.923
  %descriptor.payload.inside.925 = icmp ule i32 %local.check.payload.917, %local.check.extent.916
  %descriptor.owner.offset.valid.926 = and i1 %descriptor.owner.inside.921, %descriptor.offset.inside.922
  %descriptor.range.inside.928 = and i1 %descriptor.owner.offset.valid.926, %descriptor.extent.inside.924
  %descriptor.range.valid.927 = and i1 %descriptor.range.inside.928, %descriptor.payload.inside.925
  br i1 %descriptor.range.valid.927, label %descriptor.valid.929, label %descriptor.invalid.930
descriptor.invalid.930:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.929:
  %descriptor.initialized.status.931 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.915, i32 %local.check.extent.916)
  %helper.ok.932 = icmp eq i32 %descriptor.initialized.status.931, 0
  br i1 %helper.ok.932, label %helper.continue.933, label %frame.failure.0
helper.continue.933:
  br label %local.descriptor.checked.914
local.descriptor.inactive.913:
  br label %local.descriptor.checked.914
local.descriptor.checked.914:
  %step.status.934 = call i32 @al_owning_charge_step(ptr %ctx, i32 16)
  %helper.ok.935 = icmp eq i32 %step.status.934, 0
  br i1 %helper.ok.935, label %helper.continue.936, label %frame.failure.0
helper.continue.936:
  store i1 true, ptr %local.active.14, align 1
  store i32 %context.value.701, ptr %local.offset.15, align 4
  store i32 %stack.offset.699, ptr %local.extent.16, align 4
  store i32 %stack.offset.698, ptr %local.payload.17, align 4
  store i32 %stack.offset.702, ptr %local.owner.end.18, align 4
  store i32 4, ptr %local.type.19, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %context.value.701, i32 20, i32 %stack.offset.698, i32 %stack.offset.702, i32 %stack.offset.699)
  %context.field.937 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.938 = load i32, ptr %context.field.937, align 4
  %runtime.ok.939 = icmp eq i32 %context.value.938, 0
  br i1 %runtime.ok.939, label %runtime.continue.940, label %frame.failure.0
runtime.continue.940:
  %local.is.active.941 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.941, label %local.descriptor.active.942, label %local.descriptor.inactive.943
local.descriptor.active.942:
  %local.check.offset.945 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.946 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.947 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.948 = load i32, ptr %local.owner.end.6, align 4
  %context.field.949 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.950 = load i32, ptr %context.field.949, align 4
  %stack.sub.953 = sub i32 %local.check.owner.end.948, %local.check.offset.945
  %descriptor.owner.inside.951 = icmp ule i32 %local.check.owner.end.948, %context.value.950
  %descriptor.offset.inside.952 = icmp ule i32 %local.check.offset.945, %local.check.owner.end.948
  %descriptor.extent.inside.954 = icmp ule i32 %local.check.extent.946, %stack.sub.953
  %descriptor.payload.inside.955 = icmp ule i32 %local.check.payload.947, %local.check.extent.946
  %descriptor.owner.offset.valid.956 = and i1 %descriptor.owner.inside.951, %descriptor.offset.inside.952
  %descriptor.range.inside.958 = and i1 %descriptor.owner.offset.valid.956, %descriptor.extent.inside.954
  %descriptor.range.valid.957 = and i1 %descriptor.range.inside.958, %descriptor.payload.inside.955
  br i1 %descriptor.range.valid.957, label %descriptor.valid.959, label %descriptor.invalid.960
descriptor.invalid.960:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.959:
  %descriptor.initialized.status.961 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.945, i32 %local.check.extent.946)
  %helper.ok.962 = icmp eq i32 %descriptor.initialized.status.961, 0
  br i1 %helper.ok.962, label %helper.continue.963, label %frame.failure.0
helper.continue.963:
  br label %local.descriptor.checked.944
local.descriptor.inactive.943:
  br label %local.descriptor.checked.944
local.descriptor.checked.944:
  %local.is.active.964 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.964, label %local.descriptor.active.965, label %local.descriptor.inactive.966
local.descriptor.active.965:
  %local.check.offset.968 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.969 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.970 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.971 = load i32, ptr %local.owner.end.12, align 4
  %context.field.972 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.973 = load i32, ptr %context.field.972, align 4
  %stack.sub.976 = sub i32 %local.check.owner.end.971, %local.check.offset.968
  %descriptor.owner.inside.974 = icmp ule i32 %local.check.owner.end.971, %context.value.973
  %descriptor.offset.inside.975 = icmp ule i32 %local.check.offset.968, %local.check.owner.end.971
  %descriptor.extent.inside.977 = icmp ule i32 %local.check.extent.969, %stack.sub.976
  %descriptor.payload.inside.978 = icmp ule i32 %local.check.payload.970, %local.check.extent.969
  %descriptor.owner.offset.valid.979 = and i1 %descriptor.owner.inside.974, %descriptor.offset.inside.975
  %descriptor.range.inside.981 = and i1 %descriptor.owner.offset.valid.979, %descriptor.extent.inside.977
  %descriptor.range.valid.980 = and i1 %descriptor.range.inside.981, %descriptor.payload.inside.978
  br i1 %descriptor.range.valid.980, label %descriptor.valid.982, label %descriptor.invalid.983
descriptor.invalid.983:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.982:
  %descriptor.initialized.status.984 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.968, i32 %local.check.extent.969)
  %helper.ok.985 = icmp eq i32 %descriptor.initialized.status.984, 0
  br i1 %helper.ok.985, label %helper.continue.986, label %frame.failure.0
helper.continue.986:
  br label %local.descriptor.checked.967
local.descriptor.inactive.966:
  br label %local.descriptor.checked.967
local.descriptor.checked.967:
  %local.is.active.987 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.987, label %local.descriptor.active.988, label %local.descriptor.inactive.989
local.descriptor.active.988:
  %local.check.offset.991 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.992 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.993 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.994 = load i32, ptr %local.owner.end.18, align 4
  %context.field.995 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.996 = load i32, ptr %context.field.995, align 4
  %stack.sub.999 = sub i32 %local.check.owner.end.994, %local.check.offset.991
  %descriptor.owner.inside.997 = icmp ule i32 %local.check.owner.end.994, %context.value.996
  %descriptor.offset.inside.998 = icmp ule i32 %local.check.offset.991, %local.check.owner.end.994
  %descriptor.extent.inside.1000 = icmp ule i32 %local.check.extent.992, %stack.sub.999
  %descriptor.payload.inside.1001 = icmp ule i32 %local.check.payload.993, %local.check.extent.992
  %descriptor.owner.offset.valid.1002 = and i1 %descriptor.owner.inside.997, %descriptor.offset.inside.998
  %descriptor.range.inside.1004 = and i1 %descriptor.owner.offset.valid.1002, %descriptor.extent.inside.1000
  %descriptor.range.valid.1003 = and i1 %descriptor.range.inside.1004, %descriptor.payload.inside.1001
  br i1 %descriptor.range.valid.1003, label %descriptor.valid.1005, label %descriptor.invalid.1006
descriptor.invalid.1006:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1005:
  %descriptor.initialized.status.1007 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.991, i32 %local.check.extent.992)
  %helper.ok.1008 = icmp eq i32 %descriptor.initialized.status.1007, 0
  br i1 %helper.ok.1008, label %helper.continue.1009, label %frame.failure.0
helper.continue.1009:
  br label %local.descriptor.checked.990
local.descriptor.inactive.989:
  br label %local.descriptor.checked.990
local.descriptor.checked.990:
  %local.is.active.1010 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1010, label %local.descriptor.active.1011, label %local.descriptor.inactive.1012
local.descriptor.active.1011:
  %local.check.offset.1014 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1015 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1016 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1017 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1018 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1019 = load i32, ptr %context.field.1018, align 4
  %stack.sub.1022 = sub i32 %local.check.owner.end.1017, %local.check.offset.1014
  %descriptor.owner.inside.1020 = icmp ule i32 %local.check.owner.end.1017, %context.value.1019
  %descriptor.offset.inside.1021 = icmp ule i32 %local.check.offset.1014, %local.check.owner.end.1017
  %descriptor.extent.inside.1023 = icmp ule i32 %local.check.extent.1015, %stack.sub.1022
  %descriptor.payload.inside.1024 = icmp ule i32 %local.check.payload.1016, %local.check.extent.1015
  %descriptor.owner.offset.valid.1025 = and i1 %descriptor.owner.inside.1020, %descriptor.offset.inside.1021
  %descriptor.range.inside.1027 = and i1 %descriptor.owner.offset.valid.1025, %descriptor.extent.inside.1023
  %descriptor.range.valid.1026 = and i1 %descriptor.range.inside.1027, %descriptor.payload.inside.1024
  br i1 %descriptor.range.valid.1026, label %descriptor.valid.1028, label %descriptor.invalid.1029
descriptor.invalid.1029:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1028:
  %descriptor.initialized.status.1030 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1014, i32 %local.check.extent.1015)
  %helper.ok.1031 = icmp eq i32 %descriptor.initialized.status.1030, 0
  br i1 %helper.ok.1031, label %helper.continue.1032, label %frame.failure.0
helper.continue.1032:
  br label %local.descriptor.checked.1013
local.descriptor.inactive.1012:
  br label %local.descriptor.checked.1013
local.descriptor.checked.1013:
  %step.status.1033 = call i32 @al_owning_charge_step(ptr %ctx, i32 17)
  %helper.ok.1034 = icmp eq i32 %step.status.1033, 0
  br i1 %helper.ok.1034, label %helper.continue.1035, label %frame.failure.0
helper.continue.1035:
  %local.resolved.offset.1036 = load i32, ptr %local.offset.9, align 4
  %local.resolved.extent.1037 = load i32, ptr %local.extent.10, align 4
  %local.resolved.payload.1038 = load i32, ptr %local.payload.11, align 4
  %local.resolved.owner.end.1039 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1040 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1041 = load i32, ptr %context.field.1040, align 4
  %stack.sub.1044 = sub i32 %local.resolved.owner.end.1039, %local.resolved.offset.1036
  %descriptor.owner.inside.1042 = icmp ule i32 %local.resolved.owner.end.1039, %context.value.1041
  %descriptor.offset.inside.1043 = icmp ule i32 %local.resolved.offset.1036, %local.resolved.owner.end.1039
  %descriptor.extent.inside.1045 = icmp ule i32 %local.resolved.extent.1037, %stack.sub.1044
  %descriptor.payload.inside.1046 = icmp ule i32 %local.resolved.payload.1038, %local.resolved.extent.1037
  %descriptor.owner.offset.valid.1047 = and i1 %descriptor.owner.inside.1042, %descriptor.offset.inside.1043
  %descriptor.range.inside.1049 = and i1 %descriptor.owner.offset.valid.1047, %descriptor.extent.inside.1045
  %descriptor.range.valid.1048 = and i1 %descriptor.range.inside.1049, %descriptor.payload.inside.1046
  %descriptor.type.valid.1050 = icmp eq i32 5, 5
  %descriptor.valid.1051 = and i1 %descriptor.range.valid.1048, %descriptor.type.valid.1050
  br i1 %descriptor.valid.1051, label %descriptor.valid.1052, label %descriptor.invalid.1053
descriptor.invalid.1053:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1052:
  %descriptor.initialized.status.1054 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1036, i32 %local.resolved.extent.1037)
  %helper.ok.1055 = icmp eq i32 %descriptor.initialized.status.1054, 0
  br i1 %helper.ok.1055, label %helper.continue.1056, label %frame.failure.0
helper.continue.1056:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %local.resolved.offset.1036, i32 20, i32 %local.resolved.payload.1038, i32 %local.resolved.owner.end.1039, i32 %local.resolved.extent.1037)
  %context.field.1057 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1058 = load i32, ptr %context.field.1057, align 4
  %runtime.ok.1059 = icmp eq i32 %context.value.1058, 0
  br i1 %runtime.ok.1059, label %runtime.continue.1060, label %frame.failure.0
runtime.continue.1060:
  %context.field.1061 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1062 = load i32, ptr %context.field.1061, align 4
  %stack.sub.1065 = sub i32 %local.resolved.owner.end.1039, %local.resolved.offset.1036
  %descriptor.owner.inside.1063 = icmp ule i32 %local.resolved.owner.end.1039, %context.value.1062
  %descriptor.offset.inside.1064 = icmp ule i32 %local.resolved.offset.1036, %local.resolved.owner.end.1039
  %descriptor.extent.inside.1066 = icmp ule i32 %local.resolved.extent.1037, %stack.sub.1065
  %descriptor.payload.inside.1067 = icmp ule i32 %local.resolved.payload.1038, %local.resolved.extent.1037
  %descriptor.owner.offset.valid.1068 = and i1 %descriptor.owner.inside.1063, %descriptor.offset.inside.1064
  %descriptor.range.inside.1070 = and i1 %descriptor.owner.offset.valid.1068, %descriptor.extent.inside.1066
  %descriptor.range.valid.1069 = and i1 %descriptor.range.inside.1070, %descriptor.payload.inside.1067
  %descriptor.type.valid.1071 = icmp eq i32 5, 5
  %descriptor.valid.1072 = and i1 %descriptor.range.valid.1069, %descriptor.type.valid.1071
  br i1 %descriptor.valid.1072, label %descriptor.valid.1073, label %descriptor.invalid.1074
descriptor.invalid.1074:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1073:
  %descriptor.initialized.status.1075 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1036, i32 %local.resolved.extent.1037)
  %helper.ok.1076 = icmp eq i32 %descriptor.initialized.status.1075, 0
  br i1 %helper.ok.1076, label %helper.continue.1077, label %frame.failure.0
helper.continue.1077:
  %local.is.active.1078 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1078, label %local.descriptor.active.1079, label %local.descriptor.inactive.1080
local.descriptor.active.1079:
  %local.check.offset.1082 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1083 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1084 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1085 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1086 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1087 = load i32, ptr %context.field.1086, align 4
  %stack.sub.1090 = sub i32 %local.check.owner.end.1085, %local.check.offset.1082
  %descriptor.owner.inside.1088 = icmp ule i32 %local.check.owner.end.1085, %context.value.1087
  %descriptor.offset.inside.1089 = icmp ule i32 %local.check.offset.1082, %local.check.owner.end.1085
  %descriptor.extent.inside.1091 = icmp ule i32 %local.check.extent.1083, %stack.sub.1090
  %descriptor.payload.inside.1092 = icmp ule i32 %local.check.payload.1084, %local.check.extent.1083
  %descriptor.owner.offset.valid.1093 = and i1 %descriptor.owner.inside.1088, %descriptor.offset.inside.1089
  %descriptor.range.inside.1095 = and i1 %descriptor.owner.offset.valid.1093, %descriptor.extent.inside.1091
  %descriptor.range.valid.1094 = and i1 %descriptor.range.inside.1095, %descriptor.payload.inside.1092
  br i1 %descriptor.range.valid.1094, label %descriptor.valid.1096, label %descriptor.invalid.1097
descriptor.invalid.1097:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1096:
  %descriptor.initialized.status.1098 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1082, i32 %local.check.extent.1083)
  %helper.ok.1099 = icmp eq i32 %descriptor.initialized.status.1098, 0
  br i1 %helper.ok.1099, label %helper.continue.1100, label %frame.failure.0
helper.continue.1100:
  br label %local.descriptor.checked.1081
local.descriptor.inactive.1080:
  br label %local.descriptor.checked.1081
local.descriptor.checked.1081:
  %local.is.active.1101 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1101, label %local.descriptor.active.1102, label %local.descriptor.inactive.1103
local.descriptor.active.1102:
  %local.check.offset.1105 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1106 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1107 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1108 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1109 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1110 = load i32, ptr %context.field.1109, align 4
  %stack.sub.1113 = sub i32 %local.check.owner.end.1108, %local.check.offset.1105
  %descriptor.owner.inside.1111 = icmp ule i32 %local.check.owner.end.1108, %context.value.1110
  %descriptor.offset.inside.1112 = icmp ule i32 %local.check.offset.1105, %local.check.owner.end.1108
  %descriptor.extent.inside.1114 = icmp ule i32 %local.check.extent.1106, %stack.sub.1113
  %descriptor.payload.inside.1115 = icmp ule i32 %local.check.payload.1107, %local.check.extent.1106
  %descriptor.owner.offset.valid.1116 = and i1 %descriptor.owner.inside.1111, %descriptor.offset.inside.1112
  %descriptor.range.inside.1118 = and i1 %descriptor.owner.offset.valid.1116, %descriptor.extent.inside.1114
  %descriptor.range.valid.1117 = and i1 %descriptor.range.inside.1118, %descriptor.payload.inside.1115
  br i1 %descriptor.range.valid.1117, label %descriptor.valid.1119, label %descriptor.invalid.1120
descriptor.invalid.1120:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1119:
  %descriptor.initialized.status.1121 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1105, i32 %local.check.extent.1106)
  %helper.ok.1122 = icmp eq i32 %descriptor.initialized.status.1121, 0
  br i1 %helper.ok.1122, label %helper.continue.1123, label %frame.failure.0
helper.continue.1123:
  br label %local.descriptor.checked.1104
local.descriptor.inactive.1103:
  br label %local.descriptor.checked.1104
local.descriptor.checked.1104:
  %local.is.active.1124 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1124, label %local.descriptor.active.1125, label %local.descriptor.inactive.1126
local.descriptor.active.1125:
  %local.check.offset.1128 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1129 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1130 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1131 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1132 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1133 = load i32, ptr %context.field.1132, align 4
  %stack.sub.1136 = sub i32 %local.check.owner.end.1131, %local.check.offset.1128
  %descriptor.owner.inside.1134 = icmp ule i32 %local.check.owner.end.1131, %context.value.1133
  %descriptor.offset.inside.1135 = icmp ule i32 %local.check.offset.1128, %local.check.owner.end.1131
  %descriptor.extent.inside.1137 = icmp ule i32 %local.check.extent.1129, %stack.sub.1136
  %descriptor.payload.inside.1138 = icmp ule i32 %local.check.payload.1130, %local.check.extent.1129
  %descriptor.owner.offset.valid.1139 = and i1 %descriptor.owner.inside.1134, %descriptor.offset.inside.1135
  %descriptor.range.inside.1141 = and i1 %descriptor.owner.offset.valid.1139, %descriptor.extent.inside.1137
  %descriptor.range.valid.1140 = and i1 %descriptor.range.inside.1141, %descriptor.payload.inside.1138
  br i1 %descriptor.range.valid.1140, label %descriptor.valid.1142, label %descriptor.invalid.1143
descriptor.invalid.1143:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1142:
  %descriptor.initialized.status.1144 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1128, i32 %local.check.extent.1129)
  %helper.ok.1145 = icmp eq i32 %descriptor.initialized.status.1144, 0
  br i1 %helper.ok.1145, label %helper.continue.1146, label %frame.failure.0
helper.continue.1146:
  br label %local.descriptor.checked.1127
local.descriptor.inactive.1126:
  br label %local.descriptor.checked.1127
local.descriptor.checked.1127:
  %local.is.active.1147 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1147, label %local.descriptor.active.1148, label %local.descriptor.inactive.1149
local.descriptor.active.1148:
  %local.check.offset.1151 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1152 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1153 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1154 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1155 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1156 = load i32, ptr %context.field.1155, align 4
  %stack.sub.1159 = sub i32 %local.check.owner.end.1154, %local.check.offset.1151
  %descriptor.owner.inside.1157 = icmp ule i32 %local.check.owner.end.1154, %context.value.1156
  %descriptor.offset.inside.1158 = icmp ule i32 %local.check.offset.1151, %local.check.owner.end.1154
  %descriptor.extent.inside.1160 = icmp ule i32 %local.check.extent.1152, %stack.sub.1159
  %descriptor.payload.inside.1161 = icmp ule i32 %local.check.payload.1153, %local.check.extent.1152
  %descriptor.owner.offset.valid.1162 = and i1 %descriptor.owner.inside.1157, %descriptor.offset.inside.1158
  %descriptor.range.inside.1164 = and i1 %descriptor.owner.offset.valid.1162, %descriptor.extent.inside.1160
  %descriptor.range.valid.1163 = and i1 %descriptor.range.inside.1164, %descriptor.payload.inside.1161
  br i1 %descriptor.range.valid.1163, label %descriptor.valid.1165, label %descriptor.invalid.1166
descriptor.invalid.1166:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1165:
  %descriptor.initialized.status.1167 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1151, i32 %local.check.extent.1152)
  %helper.ok.1168 = icmp eq i32 %descriptor.initialized.status.1167, 0
  br i1 %helper.ok.1168, label %helper.continue.1169, label %frame.failure.0
helper.continue.1169:
  br label %local.descriptor.checked.1150
local.descriptor.inactive.1149:
  br label %local.descriptor.checked.1150
local.descriptor.checked.1150:
  %step.status.1170 = call i32 @al_owning_charge_step(ptr %ctx, i32 18)
  %helper.ok.1171 = icmp eq i32 %step.status.1170, 0
  br i1 %helper.ok.1171, label %helper.continue.1172, label %frame.failure.0
helper.continue.1172:
  %local.resolved.offset.1173 = load i32, ptr %local.offset.15, align 4
  %local.resolved.extent.1174 = load i32, ptr %local.extent.16, align 4
  %local.resolved.payload.1175 = load i32, ptr %local.payload.17, align 4
  %local.resolved.owner.end.1176 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1177 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1178 = load i32, ptr %context.field.1177, align 4
  %stack.sub.1181 = sub i32 %local.resolved.owner.end.1176, %local.resolved.offset.1173
  %descriptor.owner.inside.1179 = icmp ule i32 %local.resolved.owner.end.1176, %context.value.1178
  %descriptor.offset.inside.1180 = icmp ule i32 %local.resolved.offset.1173, %local.resolved.owner.end.1176
  %descriptor.extent.inside.1182 = icmp ule i32 %local.resolved.extent.1174, %stack.sub.1181
  %descriptor.payload.inside.1183 = icmp ule i32 %local.resolved.payload.1175, %local.resolved.extent.1174
  %descriptor.owner.offset.valid.1184 = and i1 %descriptor.owner.inside.1179, %descriptor.offset.inside.1180
  %descriptor.range.inside.1186 = and i1 %descriptor.owner.offset.valid.1184, %descriptor.extent.inside.1182
  %descriptor.range.valid.1185 = and i1 %descriptor.range.inside.1186, %descriptor.payload.inside.1183
  %descriptor.type.valid.1187 = icmp eq i32 4, 4
  %descriptor.valid.1188 = and i1 %descriptor.range.valid.1185, %descriptor.type.valid.1187
  br i1 %descriptor.valid.1188, label %descriptor.valid.1189, label %descriptor.invalid.1190
descriptor.invalid.1190:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1189:
  %descriptor.initialized.status.1191 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1173, i32 %local.resolved.extent.1174)
  %helper.ok.1192 = icmp eq i32 %descriptor.initialized.status.1191, 0
  br i1 %helper.ok.1192, label %helper.continue.1193, label %frame.failure.0
helper.continue.1193:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %local.resolved.offset.1173, i32 20, i32 %local.resolved.payload.1175, i32 %local.resolved.owner.end.1176, i32 %local.resolved.extent.1174)
  %context.field.1194 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1195 = load i32, ptr %context.field.1194, align 4
  %runtime.ok.1196 = icmp eq i32 %context.value.1195, 0
  br i1 %runtime.ok.1196, label %runtime.continue.1197, label %frame.failure.0
runtime.continue.1197:
  %context.field.1198 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1199 = load i32, ptr %context.field.1198, align 4
  %stack.sub.1202 = sub i32 %local.resolved.owner.end.1039, %local.resolved.offset.1036
  %descriptor.owner.inside.1200 = icmp ule i32 %local.resolved.owner.end.1039, %context.value.1199
  %descriptor.offset.inside.1201 = icmp ule i32 %local.resolved.offset.1036, %local.resolved.owner.end.1039
  %descriptor.extent.inside.1203 = icmp ule i32 %local.resolved.extent.1037, %stack.sub.1202
  %descriptor.payload.inside.1204 = icmp ule i32 %local.resolved.payload.1038, %local.resolved.extent.1037
  %descriptor.owner.offset.valid.1205 = and i1 %descriptor.owner.inside.1200, %descriptor.offset.inside.1201
  %descriptor.range.inside.1207 = and i1 %descriptor.owner.offset.valid.1205, %descriptor.extent.inside.1203
  %descriptor.range.valid.1206 = and i1 %descriptor.range.inside.1207, %descriptor.payload.inside.1204
  %descriptor.type.valid.1208 = icmp eq i32 5, 5
  %descriptor.valid.1209 = and i1 %descriptor.range.valid.1206, %descriptor.type.valid.1208
  br i1 %descriptor.valid.1209, label %descriptor.valid.1210, label %descriptor.invalid.1211
descriptor.invalid.1211:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1210:
  %descriptor.initialized.status.1212 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1036, i32 %local.resolved.extent.1037)
  %helper.ok.1213 = icmp eq i32 %descriptor.initialized.status.1212, 0
  br i1 %helper.ok.1213, label %helper.continue.1214, label %frame.failure.0
helper.continue.1214:
  %context.field.1215 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1216 = load i32, ptr %context.field.1215, align 4
  %stack.sub.1219 = sub i32 %local.resolved.owner.end.1176, %local.resolved.offset.1173
  %descriptor.owner.inside.1217 = icmp ule i32 %local.resolved.owner.end.1176, %context.value.1216
  %descriptor.offset.inside.1218 = icmp ule i32 %local.resolved.offset.1173, %local.resolved.owner.end.1176
  %descriptor.extent.inside.1220 = icmp ule i32 %local.resolved.extent.1174, %stack.sub.1219
  %descriptor.payload.inside.1221 = icmp ule i32 %local.resolved.payload.1175, %local.resolved.extent.1174
  %descriptor.owner.offset.valid.1222 = and i1 %descriptor.owner.inside.1217, %descriptor.offset.inside.1218
  %descriptor.range.inside.1224 = and i1 %descriptor.owner.offset.valid.1222, %descriptor.extent.inside.1220
  %descriptor.range.valid.1223 = and i1 %descriptor.range.inside.1224, %descriptor.payload.inside.1221
  %descriptor.type.valid.1225 = icmp eq i32 4, 4
  %descriptor.valid.1226 = and i1 %descriptor.range.valid.1223, %descriptor.type.valid.1225
  br i1 %descriptor.valid.1226, label %descriptor.valid.1227, label %descriptor.invalid.1228
descriptor.invalid.1228:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1227:
  %descriptor.initialized.status.1229 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1173, i32 %local.resolved.extent.1174)
  %helper.ok.1230 = icmp eq i32 %descriptor.initialized.status.1229, 0
  br i1 %helper.ok.1230, label %helper.continue.1231, label %frame.failure.0
helper.continue.1231:
  %local.is.active.1232 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1232, label %local.descriptor.active.1233, label %local.descriptor.inactive.1234
local.descriptor.active.1233:
  %local.check.offset.1236 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1237 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1238 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1239 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1240 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1241 = load i32, ptr %context.field.1240, align 4
  %stack.sub.1244 = sub i32 %local.check.owner.end.1239, %local.check.offset.1236
  %descriptor.owner.inside.1242 = icmp ule i32 %local.check.owner.end.1239, %context.value.1241
  %descriptor.offset.inside.1243 = icmp ule i32 %local.check.offset.1236, %local.check.owner.end.1239
  %descriptor.extent.inside.1245 = icmp ule i32 %local.check.extent.1237, %stack.sub.1244
  %descriptor.payload.inside.1246 = icmp ule i32 %local.check.payload.1238, %local.check.extent.1237
  %descriptor.owner.offset.valid.1247 = and i1 %descriptor.owner.inside.1242, %descriptor.offset.inside.1243
  %descriptor.range.inside.1249 = and i1 %descriptor.owner.offset.valid.1247, %descriptor.extent.inside.1245
  %descriptor.range.valid.1248 = and i1 %descriptor.range.inside.1249, %descriptor.payload.inside.1246
  br i1 %descriptor.range.valid.1248, label %descriptor.valid.1250, label %descriptor.invalid.1251
descriptor.invalid.1251:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1250:
  %descriptor.initialized.status.1252 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1236, i32 %local.check.extent.1237)
  %helper.ok.1253 = icmp eq i32 %descriptor.initialized.status.1252, 0
  br i1 %helper.ok.1253, label %helper.continue.1254, label %frame.failure.0
helper.continue.1254:
  br label %local.descriptor.checked.1235
local.descriptor.inactive.1234:
  br label %local.descriptor.checked.1235
local.descriptor.checked.1235:
  %local.is.active.1255 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1255, label %local.descriptor.active.1256, label %local.descriptor.inactive.1257
local.descriptor.active.1256:
  %local.check.offset.1259 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1260 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1261 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1262 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1263 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1264 = load i32, ptr %context.field.1263, align 4
  %stack.sub.1267 = sub i32 %local.check.owner.end.1262, %local.check.offset.1259
  %descriptor.owner.inside.1265 = icmp ule i32 %local.check.owner.end.1262, %context.value.1264
  %descriptor.offset.inside.1266 = icmp ule i32 %local.check.offset.1259, %local.check.owner.end.1262
  %descriptor.extent.inside.1268 = icmp ule i32 %local.check.extent.1260, %stack.sub.1267
  %descriptor.payload.inside.1269 = icmp ule i32 %local.check.payload.1261, %local.check.extent.1260
  %descriptor.owner.offset.valid.1270 = and i1 %descriptor.owner.inside.1265, %descriptor.offset.inside.1266
  %descriptor.range.inside.1272 = and i1 %descriptor.owner.offset.valid.1270, %descriptor.extent.inside.1268
  %descriptor.range.valid.1271 = and i1 %descriptor.range.inside.1272, %descriptor.payload.inside.1269
  br i1 %descriptor.range.valid.1271, label %descriptor.valid.1273, label %descriptor.invalid.1274
descriptor.invalid.1274:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1273:
  %descriptor.initialized.status.1275 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1259, i32 %local.check.extent.1260)
  %helper.ok.1276 = icmp eq i32 %descriptor.initialized.status.1275, 0
  br i1 %helper.ok.1276, label %helper.continue.1277, label %frame.failure.0
helper.continue.1277:
  br label %local.descriptor.checked.1258
local.descriptor.inactive.1257:
  br label %local.descriptor.checked.1258
local.descriptor.checked.1258:
  %local.is.active.1278 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1278, label %local.descriptor.active.1279, label %local.descriptor.inactive.1280
local.descriptor.active.1279:
  %local.check.offset.1282 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1283 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1284 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1285 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1286 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1287 = load i32, ptr %context.field.1286, align 4
  %stack.sub.1290 = sub i32 %local.check.owner.end.1285, %local.check.offset.1282
  %descriptor.owner.inside.1288 = icmp ule i32 %local.check.owner.end.1285, %context.value.1287
  %descriptor.offset.inside.1289 = icmp ule i32 %local.check.offset.1282, %local.check.owner.end.1285
  %descriptor.extent.inside.1291 = icmp ule i32 %local.check.extent.1283, %stack.sub.1290
  %descriptor.payload.inside.1292 = icmp ule i32 %local.check.payload.1284, %local.check.extent.1283
  %descriptor.owner.offset.valid.1293 = and i1 %descriptor.owner.inside.1288, %descriptor.offset.inside.1289
  %descriptor.range.inside.1295 = and i1 %descriptor.owner.offset.valid.1293, %descriptor.extent.inside.1291
  %descriptor.range.valid.1294 = and i1 %descriptor.range.inside.1295, %descriptor.payload.inside.1292
  br i1 %descriptor.range.valid.1294, label %descriptor.valid.1296, label %descriptor.invalid.1297
descriptor.invalid.1297:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1296:
  %descriptor.initialized.status.1298 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1282, i32 %local.check.extent.1283)
  %helper.ok.1299 = icmp eq i32 %descriptor.initialized.status.1298, 0
  br i1 %helper.ok.1299, label %helper.continue.1300, label %frame.failure.0
helper.continue.1300:
  br label %local.descriptor.checked.1281
local.descriptor.inactive.1280:
  br label %local.descriptor.checked.1281
local.descriptor.checked.1281:
  %local.is.active.1301 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1301, label %local.descriptor.active.1302, label %local.descriptor.inactive.1303
local.descriptor.active.1302:
  %local.check.offset.1305 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1306 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1307 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1308 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1309 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1310 = load i32, ptr %context.field.1309, align 4
  %stack.sub.1313 = sub i32 %local.check.owner.end.1308, %local.check.offset.1305
  %descriptor.owner.inside.1311 = icmp ule i32 %local.check.owner.end.1308, %context.value.1310
  %descriptor.offset.inside.1312 = icmp ule i32 %local.check.offset.1305, %local.check.owner.end.1308
  %descriptor.extent.inside.1314 = icmp ule i32 %local.check.extent.1306, %stack.sub.1313
  %descriptor.payload.inside.1315 = icmp ule i32 %local.check.payload.1307, %local.check.extent.1306
  %descriptor.owner.offset.valid.1316 = and i1 %descriptor.owner.inside.1311, %descriptor.offset.inside.1312
  %descriptor.range.inside.1318 = and i1 %descriptor.owner.offset.valid.1316, %descriptor.extent.inside.1314
  %descriptor.range.valid.1317 = and i1 %descriptor.range.inside.1318, %descriptor.payload.inside.1315
  br i1 %descriptor.range.valid.1317, label %descriptor.valid.1319, label %descriptor.invalid.1320
descriptor.invalid.1320:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1319:
  %descriptor.initialized.status.1321 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1305, i32 %local.check.extent.1306)
  %helper.ok.1322 = icmp eq i32 %descriptor.initialized.status.1321, 0
  br i1 %helper.ok.1322, label %helper.continue.1323, label %frame.failure.0
helper.continue.1323:
  br label %local.descriptor.checked.1304
local.descriptor.inactive.1303:
  br label %local.descriptor.checked.1304
local.descriptor.checked.1304:
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %descriptor.element.1324 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.1325 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1324, i32 0, i32 0
  store i32 5, ptr %descriptor.field.1325, align 4
  %descriptor.field.1326 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1324, i32 0, i32 1
  store i32 %local.resolved.offset.1036, ptr %descriptor.field.1326, align 4
  %descriptor.field.1327 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1324, i32 0, i32 2
  store i32 %local.resolved.extent.1037, ptr %descriptor.field.1327, align 4
  %descriptor.field.1328 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1324, i32 0, i32 3
  store i32 %local.resolved.payload.1038, ptr %descriptor.field.1328, align 4
  %descriptor.field.1329 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1324, i32 0, i32 4
  store i32 %local.resolved.owner.end.1039, ptr %descriptor.field.1329, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %local.resolved.offset.1036, i32 20, i32 %local.resolved.payload.1038, i32 %local.resolved.owner.end.1039, i32 %local.resolved.extent.1037)
  %context.field.1330 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1331 = load i32, ptr %context.field.1330, align 4
  %runtime.ok.1332 = icmp eq i32 %context.value.1331, 0
  br i1 %runtime.ok.1332, label %runtime.continue.1333, label %frame.failure.0
runtime.continue.1333:
  %descriptor.element.1334 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 1
  %descriptor.field.1335 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1334, i32 0, i32 0
  store i32 4, ptr %descriptor.field.1335, align 4
  %descriptor.field.1336 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1334, i32 0, i32 1
  store i32 %local.resolved.offset.1173, ptr %descriptor.field.1336, align 4
  %descriptor.field.1337 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1334, i32 0, i32 2
  store i32 %local.resolved.extent.1174, ptr %descriptor.field.1337, align 4
  %descriptor.field.1338 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1334, i32 0, i32 3
  store i32 %local.resolved.payload.1175, ptr %descriptor.field.1338, align 4
  %descriptor.field.1339 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1334, i32 0, i32 4
  store i32 %local.resolved.owner.end.1176, ptr %descriptor.field.1339, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %local.resolved.offset.1173, i32 20, i32 %local.resolved.payload.1175, i32 %local.resolved.owner.end.1176, i32 %local.resolved.extent.1174)
  %context.field.1340 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1341 = load i32, ptr %context.field.1340, align 4
  %runtime.ok.1342 = icmp eq i32 %context.value.1341, 0
  br i1 %runtime.ok.1342, label %runtime.continue.1343, label %frame.failure.0
runtime.continue.1343:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.27, i32 0, i32 0, i32 0)
  %context.field.1344 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.1345 = load i32, ptr %context.field.1344, align 4
  %context.field.1346 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.1347 = load i32, ptr %context.field.1346, align 4
  %context.field.1348 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.1349 = load i32, ptr %context.field.1348, align 4
  %stack.offset.1350 = add i32 %context.value.29, %context.value.31
  %stack.offset.1351 = add i32 %context.value.1345, %context.value.1347
  %stack.sub.1352 = sub i32 %stack.offset.1350, %stack.offset.1351
  %stack.sub.1353 = sub i32 %context.value.31, %context.value.1347
  %stack.sub.1354 = sub i32 %context.value.1349, %context.value.33
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1352, i32 %stack.sub.1353)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.1354)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0001(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %local.active.2 = alloca i1, align 1
  %local.offset.3 = alloca i32, align 4
  %local.extent.4 = alloca i32, align 4
  %local.payload.5 = alloca i32, align 4
  %local.owner.end.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  %local.active.8 = alloca i1, align 1
  %local.offset.9 = alloca i32, align 4
  %local.extent.10 = alloca i32, align 4
  %local.payload.11 = alloca i32, align 4
  %local.owner.end.12 = alloca i32, align 4
  %local.type.13 = alloca i32, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  %context.field.14 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.15 = load i32, ptr %context.field.14, align 4
  %context.field.16 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.17 = load i32, ptr %context.field.16, align 4
  %context.field.18 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.19 = load i32, ptr %context.field.18, align 4
  %context.field.20 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.21 = load i32, ptr %context.field.20, align 4
  %frame.entered.22 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.23 = icmp eq i32 %frame.entered.22, 0
  br i1 %frame.enter.ok.23, label %frame.enter.continue.24, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.24:
  %descriptor.element.25 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.26 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 0
  %descriptor.value.27 = load i32, ptr %descriptor.field.26, align 4
  %descriptor.field.28 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 1
  %descriptor.value.29 = load i32, ptr %descriptor.field.28, align 4
  %descriptor.field.30 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 2
  %descriptor.value.31 = load i32, ptr %descriptor.field.30, align 4
  %descriptor.field.32 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 3
  %descriptor.value.33 = load i32, ptr %descriptor.field.32, align 4
  %descriptor.field.34 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 4
  %descriptor.value.35 = load i32, ptr %descriptor.field.34, align 4
  %argument.type.valid.36 = icmp eq i32 %descriptor.value.27, 6
  br i1 %argument.type.valid.36, label %argument.type.ok.37, label %frame.failure.0
argument.type.ok.37:
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %stack.sub.42 = sub i32 %descriptor.value.35, %descriptor.value.29
  %descriptor.owner.inside.40 = icmp ule i32 %descriptor.value.35, %context.value.39
  %descriptor.offset.inside.41 = icmp ule i32 %descriptor.value.29, %descriptor.value.35
  %descriptor.extent.inside.43 = icmp ule i32 %descriptor.value.31, %stack.sub.42
  %descriptor.payload.inside.44 = icmp ule i32 %descriptor.value.33, %descriptor.value.31
  %descriptor.owner.offset.valid.45 = and i1 %descriptor.owner.inside.40, %descriptor.offset.inside.41
  %descriptor.range.inside.47 = and i1 %descriptor.owner.offset.valid.45, %descriptor.extent.inside.43
  %descriptor.range.valid.46 = and i1 %descriptor.range.inside.47, %descriptor.payload.inside.44
  %descriptor.type.valid.48 = icmp eq i32 6, 6
  %descriptor.valid.49 = and i1 %descriptor.range.valid.46, %descriptor.type.valid.48
  br i1 %descriptor.valid.49, label %descriptor.valid.50, label %descriptor.invalid.51
descriptor.invalid.51:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.50:
  %descriptor.initialized.status.52 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.29, i32 %descriptor.value.31)
  %helper.ok.53 = icmp eq i32 %descriptor.initialized.status.52, 0
  br i1 %helper.ok.53, label %helper.continue.54, label %frame.failure.0
helper.continue.54:
  %step.status.55 = call i32 @al_owning_charge_step(ptr %ctx, i32 19)
  %helper.ok.56 = icmp eq i32 %step.status.55, 0
  br i1 %helper.ok.56, label %helper.continue.57, label %frame.failure.0
helper.continue.57:
  store i1 true, ptr %local.active.2, align 1
  store i32 %descriptor.value.29, ptr %local.offset.3, align 4
  store i32 %descriptor.value.31, ptr %local.extent.4, align 4
  store i32 %descriptor.value.33, ptr %local.payload.5, align 4
  store i32 %descriptor.value.35, ptr %local.owner.end.6, align 4
  store i32 6, ptr %local.type.7, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %descriptor.value.29, i32 20, i32 %descriptor.value.33, i32 %descriptor.value.35, i32 %descriptor.value.31)
  %context.field.58 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.59 = load i32, ptr %context.field.58, align 4
  %runtime.ok.60 = icmp eq i32 %context.value.59, 0
  br i1 %runtime.ok.60, label %runtime.continue.61, label %frame.failure.0
runtime.continue.61:
  %local.is.active.62 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.62, label %local.descriptor.active.63, label %local.descriptor.inactive.64
local.descriptor.active.63:
  %local.check.offset.66 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.67 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.68 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.69 = load i32, ptr %local.owner.end.6, align 4
  %context.field.70 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.71 = load i32, ptr %context.field.70, align 4
  %stack.sub.74 = sub i32 %local.check.owner.end.69, %local.check.offset.66
  %descriptor.owner.inside.72 = icmp ule i32 %local.check.owner.end.69, %context.value.71
  %descriptor.offset.inside.73 = icmp ule i32 %local.check.offset.66, %local.check.owner.end.69
  %descriptor.extent.inside.75 = icmp ule i32 %local.check.extent.67, %stack.sub.74
  %descriptor.payload.inside.76 = icmp ule i32 %local.check.payload.68, %local.check.extent.67
  %descriptor.owner.offset.valid.77 = and i1 %descriptor.owner.inside.72, %descriptor.offset.inside.73
  %descriptor.range.inside.79 = and i1 %descriptor.owner.offset.valid.77, %descriptor.extent.inside.75
  %descriptor.range.valid.78 = and i1 %descriptor.range.inside.79, %descriptor.payload.inside.76
  br i1 %descriptor.range.valid.78, label %descriptor.valid.80, label %descriptor.invalid.81
descriptor.invalid.81:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.80:
  %descriptor.initialized.status.82 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.66, i32 %local.check.extent.67)
  %helper.ok.83 = icmp eq i32 %descriptor.initialized.status.82, 0
  br i1 %helper.ok.83, label %helper.continue.84, label %frame.failure.0
helper.continue.84:
  br label %local.descriptor.checked.65
local.descriptor.inactive.64:
  br label %local.descriptor.checked.65
local.descriptor.checked.65:
  %local.is.active.85 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.85, label %local.descriptor.active.86, label %local.descriptor.inactive.87
local.descriptor.active.86:
  %local.check.offset.89 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.90 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.91 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.92 = load i32, ptr %local.owner.end.12, align 4
  %context.field.93 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.94 = load i32, ptr %context.field.93, align 4
  %stack.sub.97 = sub i32 %local.check.owner.end.92, %local.check.offset.89
  %descriptor.owner.inside.95 = icmp ule i32 %local.check.owner.end.92, %context.value.94
  %descriptor.offset.inside.96 = icmp ule i32 %local.check.offset.89, %local.check.owner.end.92
  %descriptor.extent.inside.98 = icmp ule i32 %local.check.extent.90, %stack.sub.97
  %descriptor.payload.inside.99 = icmp ule i32 %local.check.payload.91, %local.check.extent.90
  %descriptor.owner.offset.valid.100 = and i1 %descriptor.owner.inside.95, %descriptor.offset.inside.96
  %descriptor.range.inside.102 = and i1 %descriptor.owner.offset.valid.100, %descriptor.extent.inside.98
  %descriptor.range.valid.101 = and i1 %descriptor.range.inside.102, %descriptor.payload.inside.99
  br i1 %descriptor.range.valid.101, label %descriptor.valid.103, label %descriptor.invalid.104
descriptor.invalid.104:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.103:
  %descriptor.initialized.status.105 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.89, i32 %local.check.extent.90)
  %helper.ok.106 = icmp eq i32 %descriptor.initialized.status.105, 0
  br i1 %helper.ok.106, label %helper.continue.107, label %frame.failure.0
helper.continue.107:
  br label %local.descriptor.checked.88
local.descriptor.inactive.87:
  br label %local.descriptor.checked.88
local.descriptor.checked.88:
  %step.status.108 = call i32 @al_owning_charge_step(ptr %ctx, i32 20)
  %helper.ok.109 = icmp eq i32 %step.status.108, 0
  br i1 %helper.ok.109, label %helper.continue.110, label %frame.failure.0
helper.continue.110:
  %context.field.111 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.112 = load i32, ptr %context.field.111, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  %step.status.113 = call i32 @al_owning_charge_step(ptr %ctx, i32 21)
  %helper.ok.114 = icmp eq i32 %step.status.113, 0
  br i1 %helper.ok.114, label %helper.continue.115, label %frame.failure.0
helper.continue.115:
  %local.resolved.offset.116 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.117 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.118 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.119 = load i32, ptr %local.owner.end.6, align 4
  %context.field.120 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.121 = load i32, ptr %context.field.120, align 4
  %stack.sub.124 = sub i32 %local.resolved.owner.end.119, %local.resolved.offset.116
  %descriptor.owner.inside.122 = icmp ule i32 %local.resolved.owner.end.119, %context.value.121
  %descriptor.offset.inside.123 = icmp ule i32 %local.resolved.offset.116, %local.resolved.owner.end.119
  %descriptor.extent.inside.125 = icmp ule i32 %local.resolved.extent.117, %stack.sub.124
  %descriptor.payload.inside.126 = icmp ule i32 %local.resolved.payload.118, %local.resolved.extent.117
  %descriptor.owner.offset.valid.127 = and i1 %descriptor.owner.inside.122, %descriptor.offset.inside.123
  %descriptor.range.inside.129 = and i1 %descriptor.owner.offset.valid.127, %descriptor.extent.inside.125
  %descriptor.range.valid.128 = and i1 %descriptor.range.inside.129, %descriptor.payload.inside.126
  %descriptor.type.valid.130 = icmp eq i32 6, 6
  %descriptor.valid.131 = and i1 %descriptor.range.valid.128, %descriptor.type.valid.130
  br i1 %descriptor.valid.131, label %descriptor.valid.132, label %descriptor.invalid.133
descriptor.invalid.133:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.132:
  %descriptor.initialized.status.134 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.116, i32 %local.resolved.extent.117)
  %helper.ok.135 = icmp eq i32 %descriptor.initialized.status.134, 0
  br i1 %helper.ok.135, label %helper.continue.136, label %frame.failure.0
helper.continue.136:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %local.resolved.offset.116, i32 20, i32 %local.resolved.payload.118, i32 %local.resolved.owner.end.119, i32 %local.resolved.extent.117)
  %context.field.137 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.138 = load i32, ptr %context.field.137, align 4
  %runtime.ok.139 = icmp eq i32 %context.value.138, 0
  br i1 %runtime.ok.139, label %runtime.continue.140, label %frame.failure.0
runtime.continue.140:
  %context.field.141 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.142 = load i32, ptr %context.field.141, align 4
  %stack.sub.145 = sub i32 %local.resolved.owner.end.119, %local.resolved.offset.116
  %descriptor.owner.inside.143 = icmp ule i32 %local.resolved.owner.end.119, %context.value.142
  %descriptor.offset.inside.144 = icmp ule i32 %local.resolved.offset.116, %local.resolved.owner.end.119
  %descriptor.extent.inside.146 = icmp ule i32 %local.resolved.extent.117, %stack.sub.145
  %descriptor.payload.inside.147 = icmp ule i32 %local.resolved.payload.118, %local.resolved.extent.117
  %descriptor.owner.offset.valid.148 = and i1 %descriptor.owner.inside.143, %descriptor.offset.inside.144
  %descriptor.range.inside.150 = and i1 %descriptor.owner.offset.valid.148, %descriptor.extent.inside.146
  %descriptor.range.valid.149 = and i1 %descriptor.range.inside.150, %descriptor.payload.inside.147
  %descriptor.type.valid.151 = icmp eq i32 6, 6
  %descriptor.valid.152 = and i1 %descriptor.range.valid.149, %descriptor.type.valid.151
  br i1 %descriptor.valid.152, label %descriptor.valid.153, label %descriptor.invalid.154
descriptor.invalid.154:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.153:
  %descriptor.initialized.status.155 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.116, i32 %local.resolved.extent.117)
  %helper.ok.156 = icmp eq i32 %descriptor.initialized.status.155, 0
  br i1 %helper.ok.156, label %helper.continue.157, label %frame.failure.0
helper.continue.157:
  %local.is.active.158 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.158, label %local.descriptor.active.159, label %local.descriptor.inactive.160
local.descriptor.active.159:
  %local.check.offset.162 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.163 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.164 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.165 = load i32, ptr %local.owner.end.6, align 4
  %context.field.166 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.167 = load i32, ptr %context.field.166, align 4
  %stack.sub.170 = sub i32 %local.check.owner.end.165, %local.check.offset.162
  %descriptor.owner.inside.168 = icmp ule i32 %local.check.owner.end.165, %context.value.167
  %descriptor.offset.inside.169 = icmp ule i32 %local.check.offset.162, %local.check.owner.end.165
  %descriptor.extent.inside.171 = icmp ule i32 %local.check.extent.163, %stack.sub.170
  %descriptor.payload.inside.172 = icmp ule i32 %local.check.payload.164, %local.check.extent.163
  %descriptor.owner.offset.valid.173 = and i1 %descriptor.owner.inside.168, %descriptor.offset.inside.169
  %descriptor.range.inside.175 = and i1 %descriptor.owner.offset.valid.173, %descriptor.extent.inside.171
  %descriptor.range.valid.174 = and i1 %descriptor.range.inside.175, %descriptor.payload.inside.172
  br i1 %descriptor.range.valid.174, label %descriptor.valid.176, label %descriptor.invalid.177
descriptor.invalid.177:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.176:
  %descriptor.initialized.status.178 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.162, i32 %local.check.extent.163)
  %helper.ok.179 = icmp eq i32 %descriptor.initialized.status.178, 0
  br i1 %helper.ok.179, label %helper.continue.180, label %frame.failure.0
helper.continue.180:
  br label %local.descriptor.checked.161
local.descriptor.inactive.160:
  br label %local.descriptor.checked.161
local.descriptor.checked.161:
  %local.is.active.181 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.181, label %local.descriptor.active.182, label %local.descriptor.inactive.183
local.descriptor.active.182:
  %local.check.offset.185 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.186 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.187 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.188 = load i32, ptr %local.owner.end.12, align 4
  %context.field.189 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.190 = load i32, ptr %context.field.189, align 4
  %stack.sub.193 = sub i32 %local.check.owner.end.188, %local.check.offset.185
  %descriptor.owner.inside.191 = icmp ule i32 %local.check.owner.end.188, %context.value.190
  %descriptor.offset.inside.192 = icmp ule i32 %local.check.offset.185, %local.check.owner.end.188
  %descriptor.extent.inside.194 = icmp ule i32 %local.check.extent.186, %stack.sub.193
  %descriptor.payload.inside.195 = icmp ule i32 %local.check.payload.187, %local.check.extent.186
  %descriptor.owner.offset.valid.196 = and i1 %descriptor.owner.inside.191, %descriptor.offset.inside.192
  %descriptor.range.inside.198 = and i1 %descriptor.owner.offset.valid.196, %descriptor.extent.inside.194
  %descriptor.range.valid.197 = and i1 %descriptor.range.inside.198, %descriptor.payload.inside.195
  br i1 %descriptor.range.valid.197, label %descriptor.valid.199, label %descriptor.invalid.200
descriptor.invalid.200:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.199:
  %descriptor.initialized.status.201 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.185, i32 %local.check.extent.186)
  %helper.ok.202 = icmp eq i32 %descriptor.initialized.status.201, 0
  br i1 %helper.ok.202, label %helper.continue.203, label %frame.failure.0
helper.continue.203:
  br label %local.descriptor.checked.184
local.descriptor.inactive.183:
  br label %local.descriptor.checked.184
local.descriptor.checked.184:
  %step.status.204 = call i32 @al_owning_charge_step(ptr %ctx, i32 22)
  %helper.ok.205 = icmp eq i32 %step.status.204, 0
  br i1 %helper.ok.205, label %helper.continue.206, label %frame.failure.0
helper.continue.206:
  store i1 true, ptr %local.active.8, align 1
  store i32 %local.resolved.offset.116, ptr %local.offset.9, align 4
  store i32 %local.resolved.extent.117, ptr %local.extent.10, align 4
  store i32 %local.resolved.payload.118, ptr %local.payload.11, align 4
  store i32 %local.resolved.owner.end.119, ptr %local.owner.end.12, align 4
  store i32 6, ptr %local.type.13, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %local.resolved.offset.116, i32 20, i32 %local.resolved.payload.118, i32 %local.resolved.owner.end.119, i32 %local.resolved.extent.117)
  %context.field.207 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.208 = load i32, ptr %context.field.207, align 4
  %runtime.ok.209 = icmp eq i32 %context.value.208, 0
  br i1 %runtime.ok.209, label %runtime.continue.210, label %frame.failure.0
runtime.continue.210:
  %local.is.active.211 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.211, label %local.descriptor.active.212, label %local.descriptor.inactive.213
local.descriptor.active.212:
  %local.check.offset.215 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.216 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.217 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.218 = load i32, ptr %local.owner.end.6, align 4
  %context.field.219 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.220 = load i32, ptr %context.field.219, align 4
  %stack.sub.223 = sub i32 %local.check.owner.end.218, %local.check.offset.215
  %descriptor.owner.inside.221 = icmp ule i32 %local.check.owner.end.218, %context.value.220
  %descriptor.offset.inside.222 = icmp ule i32 %local.check.offset.215, %local.check.owner.end.218
  %descriptor.extent.inside.224 = icmp ule i32 %local.check.extent.216, %stack.sub.223
  %descriptor.payload.inside.225 = icmp ule i32 %local.check.payload.217, %local.check.extent.216
  %descriptor.owner.offset.valid.226 = and i1 %descriptor.owner.inside.221, %descriptor.offset.inside.222
  %descriptor.range.inside.228 = and i1 %descriptor.owner.offset.valid.226, %descriptor.extent.inside.224
  %descriptor.range.valid.227 = and i1 %descriptor.range.inside.228, %descriptor.payload.inside.225
  br i1 %descriptor.range.valid.227, label %descriptor.valid.229, label %descriptor.invalid.230
descriptor.invalid.230:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.229:
  %descriptor.initialized.status.231 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.215, i32 %local.check.extent.216)
  %helper.ok.232 = icmp eq i32 %descriptor.initialized.status.231, 0
  br i1 %helper.ok.232, label %helper.continue.233, label %frame.failure.0
helper.continue.233:
  br label %local.descriptor.checked.214
local.descriptor.inactive.213:
  br label %local.descriptor.checked.214
local.descriptor.checked.214:
  %local.is.active.234 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.234, label %local.descriptor.active.235, label %local.descriptor.inactive.236
local.descriptor.active.235:
  %local.check.offset.238 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.239 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.240 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.241 = load i32, ptr %local.owner.end.12, align 4
  %context.field.242 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.243 = load i32, ptr %context.field.242, align 4
  %stack.sub.246 = sub i32 %local.check.owner.end.241, %local.check.offset.238
  %descriptor.owner.inside.244 = icmp ule i32 %local.check.owner.end.241, %context.value.243
  %descriptor.offset.inside.245 = icmp ule i32 %local.check.offset.238, %local.check.owner.end.241
  %descriptor.extent.inside.247 = icmp ule i32 %local.check.extent.239, %stack.sub.246
  %descriptor.payload.inside.248 = icmp ule i32 %local.check.payload.240, %local.check.extent.239
  %descriptor.owner.offset.valid.249 = and i1 %descriptor.owner.inside.244, %descriptor.offset.inside.245
  %descriptor.range.inside.251 = and i1 %descriptor.owner.offset.valid.249, %descriptor.extent.inside.247
  %descriptor.range.valid.250 = and i1 %descriptor.range.inside.251, %descriptor.payload.inside.248
  br i1 %descriptor.range.valid.250, label %descriptor.valid.252, label %descriptor.invalid.253
descriptor.invalid.253:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.252:
  %descriptor.initialized.status.254 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.238, i32 %local.check.extent.239)
  %helper.ok.255 = icmp eq i32 %descriptor.initialized.status.254, 0
  br i1 %helper.ok.255, label %helper.continue.256, label %frame.failure.0
helper.continue.256:
  br label %local.descriptor.checked.237
local.descriptor.inactive.236:
  br label %local.descriptor.checked.237
local.descriptor.checked.237:
  %step.status.257 = call i32 @al_owning_charge_step(ptr %ctx, i32 23)
  %helper.ok.258 = icmp eq i32 %step.status.257, 0
  br i1 %helper.ok.258, label %helper.continue.259, label %frame.failure.0
helper.continue.259:
  %local.resolved.offset.260 = load i32, ptr %local.offset.9, align 4
  %local.resolved.extent.261 = load i32, ptr %local.extent.10, align 4
  %local.resolved.payload.262 = load i32, ptr %local.payload.11, align 4
  %local.resolved.owner.end.263 = load i32, ptr %local.owner.end.12, align 4
  %context.field.264 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.265 = load i32, ptr %context.field.264, align 4
  %stack.sub.268 = sub i32 %local.resolved.owner.end.263, %local.resolved.offset.260
  %descriptor.owner.inside.266 = icmp ule i32 %local.resolved.owner.end.263, %context.value.265
  %descriptor.offset.inside.267 = icmp ule i32 %local.resolved.offset.260, %local.resolved.owner.end.263
  %descriptor.extent.inside.269 = icmp ule i32 %local.resolved.extent.261, %stack.sub.268
  %descriptor.payload.inside.270 = icmp ule i32 %local.resolved.payload.262, %local.resolved.extent.261
  %descriptor.owner.offset.valid.271 = and i1 %descriptor.owner.inside.266, %descriptor.offset.inside.267
  %descriptor.range.inside.273 = and i1 %descriptor.owner.offset.valid.271, %descriptor.extent.inside.269
  %descriptor.range.valid.272 = and i1 %descriptor.range.inside.273, %descriptor.payload.inside.270
  %descriptor.type.valid.274 = icmp eq i32 6, 6
  %descriptor.valid.275 = and i1 %descriptor.range.valid.272, %descriptor.type.valid.274
  br i1 %descriptor.valid.275, label %descriptor.valid.276, label %descriptor.invalid.277
descriptor.invalid.277:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.276:
  %descriptor.initialized.status.278 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.260, i32 %local.resolved.extent.261)
  %helper.ok.279 = icmp eq i32 %descriptor.initialized.status.278, 0
  br i1 %helper.ok.279, label %helper.continue.280, label %frame.failure.0
helper.continue.280:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %local.resolved.offset.260, i32 20, i32 %local.resolved.payload.262, i32 %local.resolved.owner.end.263, i32 %local.resolved.extent.261)
  %context.field.281 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.282 = load i32, ptr %context.field.281, align 4
  %runtime.ok.283 = icmp eq i32 %context.value.282, 0
  br i1 %runtime.ok.283, label %runtime.continue.284, label %frame.failure.0
runtime.continue.284:
  %context.field.285 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.286 = load i32, ptr %context.field.285, align 4
  %stack.sub.289 = sub i32 %local.resolved.owner.end.263, %local.resolved.offset.260
  %descriptor.owner.inside.287 = icmp ule i32 %local.resolved.owner.end.263, %context.value.286
  %descriptor.offset.inside.288 = icmp ule i32 %local.resolved.offset.260, %local.resolved.owner.end.263
  %descriptor.extent.inside.290 = icmp ule i32 %local.resolved.extent.261, %stack.sub.289
  %descriptor.payload.inside.291 = icmp ule i32 %local.resolved.payload.262, %local.resolved.extent.261
  %descriptor.owner.offset.valid.292 = and i1 %descriptor.owner.inside.287, %descriptor.offset.inside.288
  %descriptor.range.inside.294 = and i1 %descriptor.owner.offset.valid.292, %descriptor.extent.inside.290
  %descriptor.range.valid.293 = and i1 %descriptor.range.inside.294, %descriptor.payload.inside.291
  %descriptor.type.valid.295 = icmp eq i32 6, 6
  %descriptor.valid.296 = and i1 %descriptor.range.valid.293, %descriptor.type.valid.295
  br i1 %descriptor.valid.296, label %descriptor.valid.297, label %descriptor.invalid.298
descriptor.invalid.298:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.297:
  %descriptor.initialized.status.299 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.260, i32 %local.resolved.extent.261)
  %helper.ok.300 = icmp eq i32 %descriptor.initialized.status.299, 0
  br i1 %helper.ok.300, label %helper.continue.301, label %frame.failure.0
helper.continue.301:
  %local.is.active.302 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.302, label %local.descriptor.active.303, label %local.descriptor.inactive.304
local.descriptor.active.303:
  %local.check.offset.306 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.307 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.308 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.309 = load i32, ptr %local.owner.end.6, align 4
  %context.field.310 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.311 = load i32, ptr %context.field.310, align 4
  %stack.sub.314 = sub i32 %local.check.owner.end.309, %local.check.offset.306
  %descriptor.owner.inside.312 = icmp ule i32 %local.check.owner.end.309, %context.value.311
  %descriptor.offset.inside.313 = icmp ule i32 %local.check.offset.306, %local.check.owner.end.309
  %descriptor.extent.inside.315 = icmp ule i32 %local.check.extent.307, %stack.sub.314
  %descriptor.payload.inside.316 = icmp ule i32 %local.check.payload.308, %local.check.extent.307
  %descriptor.owner.offset.valid.317 = and i1 %descriptor.owner.inside.312, %descriptor.offset.inside.313
  %descriptor.range.inside.319 = and i1 %descriptor.owner.offset.valid.317, %descriptor.extent.inside.315
  %descriptor.range.valid.318 = and i1 %descriptor.range.inside.319, %descriptor.payload.inside.316
  br i1 %descriptor.range.valid.318, label %descriptor.valid.320, label %descriptor.invalid.321
descriptor.invalid.321:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.320:
  %descriptor.initialized.status.322 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.306, i32 %local.check.extent.307)
  %helper.ok.323 = icmp eq i32 %descriptor.initialized.status.322, 0
  br i1 %helper.ok.323, label %helper.continue.324, label %frame.failure.0
helper.continue.324:
  br label %local.descriptor.checked.305
local.descriptor.inactive.304:
  br label %local.descriptor.checked.305
local.descriptor.checked.305:
  %local.is.active.325 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.325, label %local.descriptor.active.326, label %local.descriptor.inactive.327
local.descriptor.active.326:
  %local.check.offset.329 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.330 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.331 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.332 = load i32, ptr %local.owner.end.12, align 4
  %context.field.333 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.334 = load i32, ptr %context.field.333, align 4
  %stack.sub.337 = sub i32 %local.check.owner.end.332, %local.check.offset.329
  %descriptor.owner.inside.335 = icmp ule i32 %local.check.owner.end.332, %context.value.334
  %descriptor.offset.inside.336 = icmp ule i32 %local.check.offset.329, %local.check.owner.end.332
  %descriptor.extent.inside.338 = icmp ule i32 %local.check.extent.330, %stack.sub.337
  %descriptor.payload.inside.339 = icmp ule i32 %local.check.payload.331, %local.check.extent.330
  %descriptor.owner.offset.valid.340 = and i1 %descriptor.owner.inside.335, %descriptor.offset.inside.336
  %descriptor.range.inside.342 = and i1 %descriptor.owner.offset.valid.340, %descriptor.extent.inside.338
  %descriptor.range.valid.341 = and i1 %descriptor.range.inside.342, %descriptor.payload.inside.339
  br i1 %descriptor.range.valid.341, label %descriptor.valid.343, label %descriptor.invalid.344
descriptor.invalid.344:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.343:
  %descriptor.initialized.status.345 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.329, i32 %local.check.extent.330)
  %helper.ok.346 = icmp eq i32 %descriptor.initialized.status.345, 0
  br i1 %helper.ok.346, label %helper.continue.347, label %frame.failure.0
helper.continue.347:
  br label %local.descriptor.checked.328
local.descriptor.inactive.327:
  br label %local.descriptor.checked.328
local.descriptor.checked.328:
  %step.status.348 = call i32 @al_owning_charge_step(ptr %ctx, i32 24)
  %helper.ok.349 = icmp eq i32 %step.status.348, 0
  br i1 %helper.ok.349, label %helper.continue.350, label %frame.failure.0
helper.continue.350:
  %context.field.351 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.352 = load i32, ptr %context.field.351, align 4
  %inline.target.depth.within.interpreter.limit.353 = icmp ule i32 %context.value.352, 65
  br i1 %inline.target.depth.within.interpreter.limit.353, label %inline.target.depth.ok.354, label %inline.target.depth.invalid.355
inline.target.depth.invalid.355:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 25, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.354:
  %stack.offset.356 = add i32 0, %local.resolved.payload.262
  %stack.offset.357 = add i32 0, %local.resolved.extent.261
  %context.field.358 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.359 = load i32, ptr %context.field.358, align 4
  %stack.offset.360 = add i32 %context.value.359, %stack.offset.357
  %reserve.status.361 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.360, i32 26)
  %reserve.ok.362 = icmp eq i32 %reserve.status.361, 0
  br i1 %reserve.ok.362, label %reserve.continue.363, label %frame.failure.0
reserve.continue.363:
  %stack.offset.364 = add i32 %context.value.359, 0
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.364, i32 %local.resolved.offset.260, i32 %local.resolved.extent.261, i32 %local.resolved.payload.262, i32 6, i32 6)
  %context.field.365 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.366 = load i32, ptr %context.field.365, align 4
  %runtime.ok.367 = icmp eq i32 %context.value.366, 0
  br i1 %runtime.ok.367, label %runtime.continue.368, label %frame.failure.0
runtime.continue.368:
  %stack.offset.369 = add i32 0, %local.resolved.extent.261
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 5, i32 %context.value.359, i32 %stack.offset.357, i32 %stack.offset.356, i32 0, i32 0)
  %context.field.370 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.371 = load i32, ptr %context.field.370, align 4
  %runtime.ok.372 = icmp eq i32 %context.value.371, 0
  br i1 %runtime.ok.372, label %runtime.continue.373, label %frame.failure.0
runtime.continue.373:
  %context.field.374 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.375 = load i32, ptr %context.field.374, align 4
  %stack.sub.378 = sub i32 %stack.offset.360, %context.value.359
  %descriptor.owner.inside.376 = icmp ule i32 %stack.offset.360, %context.value.375
  %descriptor.offset.inside.377 = icmp ule i32 %context.value.359, %stack.offset.360
  %descriptor.extent.inside.379 = icmp ule i32 %stack.offset.357, %stack.sub.378
  %descriptor.payload.inside.380 = icmp ule i32 %stack.offset.356, %stack.offset.357
  %descriptor.owner.offset.valid.381 = and i1 %descriptor.owner.inside.376, %descriptor.offset.inside.377
  %descriptor.range.inside.383 = and i1 %descriptor.owner.offset.valid.381, %descriptor.extent.inside.379
  %descriptor.range.valid.382 = and i1 %descriptor.range.inside.383, %descriptor.payload.inside.380
  %descriptor.type.valid.384 = icmp eq i32 5, 5
  %descriptor.valid.385 = and i1 %descriptor.range.valid.382, %descriptor.type.valid.384
  br i1 %descriptor.valid.385, label %descriptor.valid.386, label %descriptor.invalid.387
descriptor.invalid.387:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.386:
  %descriptor.initialized.status.388 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.359, i32 %stack.offset.357)
  %helper.ok.389 = icmp eq i32 %descriptor.initialized.status.388, 0
  br i1 %helper.ok.389, label %helper.continue.390, label %frame.failure.0
helper.continue.390:
  %local.is.active.391 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.391, label %local.descriptor.active.392, label %local.descriptor.inactive.393
local.descriptor.active.392:
  %local.check.offset.395 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.396 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.397 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.398 = load i32, ptr %local.owner.end.6, align 4
  %context.field.399 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.400 = load i32, ptr %context.field.399, align 4
  %stack.sub.403 = sub i32 %local.check.owner.end.398, %local.check.offset.395
  %descriptor.owner.inside.401 = icmp ule i32 %local.check.owner.end.398, %context.value.400
  %descriptor.offset.inside.402 = icmp ule i32 %local.check.offset.395, %local.check.owner.end.398
  %descriptor.extent.inside.404 = icmp ule i32 %local.check.extent.396, %stack.sub.403
  %descriptor.payload.inside.405 = icmp ule i32 %local.check.payload.397, %local.check.extent.396
  %descriptor.owner.offset.valid.406 = and i1 %descriptor.owner.inside.401, %descriptor.offset.inside.402
  %descriptor.range.inside.408 = and i1 %descriptor.owner.offset.valid.406, %descriptor.extent.inside.404
  %descriptor.range.valid.407 = and i1 %descriptor.range.inside.408, %descriptor.payload.inside.405
  br i1 %descriptor.range.valid.407, label %descriptor.valid.409, label %descriptor.invalid.410
descriptor.invalid.410:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.409:
  %descriptor.initialized.status.411 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.395, i32 %local.check.extent.396)
  %helper.ok.412 = icmp eq i32 %descriptor.initialized.status.411, 0
  br i1 %helper.ok.412, label %helper.continue.413, label %frame.failure.0
helper.continue.413:
  br label %local.descriptor.checked.394
local.descriptor.inactive.393:
  br label %local.descriptor.checked.394
local.descriptor.checked.394:
  %local.is.active.414 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.414, label %local.descriptor.active.415, label %local.descriptor.inactive.416
local.descriptor.active.415:
  %local.check.offset.418 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.419 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.420 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.421 = load i32, ptr %local.owner.end.12, align 4
  %context.field.422 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.423 = load i32, ptr %context.field.422, align 4
  %stack.sub.426 = sub i32 %local.check.owner.end.421, %local.check.offset.418
  %descriptor.owner.inside.424 = icmp ule i32 %local.check.owner.end.421, %context.value.423
  %descriptor.offset.inside.425 = icmp ule i32 %local.check.offset.418, %local.check.owner.end.421
  %descriptor.extent.inside.427 = icmp ule i32 %local.check.extent.419, %stack.sub.426
  %descriptor.payload.inside.428 = icmp ule i32 %local.check.payload.420, %local.check.extent.419
  %descriptor.owner.offset.valid.429 = and i1 %descriptor.owner.inside.424, %descriptor.offset.inside.425
  %descriptor.range.inside.431 = and i1 %descriptor.owner.offset.valid.429, %descriptor.extent.inside.427
  %descriptor.range.valid.430 = and i1 %descriptor.range.inside.431, %descriptor.payload.inside.428
  br i1 %descriptor.range.valid.430, label %descriptor.valid.432, label %descriptor.invalid.433
descriptor.invalid.433:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.432:
  %descriptor.initialized.status.434 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.418, i32 %local.check.extent.419)
  %helper.ok.435 = icmp eq i32 %descriptor.initialized.status.434, 0
  br i1 %helper.ok.435, label %helper.continue.436, label %frame.failure.0
helper.continue.436:
  br label %local.descriptor.checked.417
local.descriptor.inactive.416:
  br label %local.descriptor.checked.417
local.descriptor.checked.417:
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  %context.field.437 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.438 = load i32, ptr %context.field.437, align 4
  %stack.sub.441 = sub i32 %stack.offset.360, %context.value.359
  %descriptor.owner.inside.439 = icmp ule i32 %stack.offset.360, %context.value.438
  %descriptor.offset.inside.440 = icmp ule i32 %context.value.359, %stack.offset.360
  %descriptor.extent.inside.442 = icmp ule i32 %stack.offset.357, %stack.sub.441
  %descriptor.payload.inside.443 = icmp ule i32 %stack.offset.356, %stack.offset.357
  %descriptor.owner.offset.valid.444 = and i1 %descriptor.owner.inside.439, %descriptor.offset.inside.440
  %descriptor.range.inside.446 = and i1 %descriptor.owner.offset.valid.444, %descriptor.extent.inside.442
  %descriptor.range.valid.445 = and i1 %descriptor.range.inside.446, %descriptor.payload.inside.443
  %descriptor.type.valid.447 = icmp eq i32 5, 5
  %descriptor.valid.448 = and i1 %descriptor.range.valid.445, %descriptor.type.valid.447
  br i1 %descriptor.valid.448, label %descriptor.valid.449, label %descriptor.invalid.450
descriptor.invalid.450:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.449:
  %descriptor.initialized.status.451 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.359, i32 %stack.offset.357)
  %helper.ok.452 = icmp eq i32 %descriptor.initialized.status.451, 0
  br i1 %helper.ok.452, label %helper.continue.453, label %frame.failure.0
helper.continue.453:
  %local.is.active.454 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.454, label %local.descriptor.active.455, label %local.descriptor.inactive.456
local.descriptor.active.455:
  %local.check.offset.458 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.459 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.460 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.461 = load i32, ptr %local.owner.end.6, align 4
  %context.field.462 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.463 = load i32, ptr %context.field.462, align 4
  %stack.sub.466 = sub i32 %local.check.owner.end.461, %local.check.offset.458
  %descriptor.owner.inside.464 = icmp ule i32 %local.check.owner.end.461, %context.value.463
  %descriptor.offset.inside.465 = icmp ule i32 %local.check.offset.458, %local.check.owner.end.461
  %descriptor.extent.inside.467 = icmp ule i32 %local.check.extent.459, %stack.sub.466
  %descriptor.payload.inside.468 = icmp ule i32 %local.check.payload.460, %local.check.extent.459
  %descriptor.owner.offset.valid.469 = and i1 %descriptor.owner.inside.464, %descriptor.offset.inside.465
  %descriptor.range.inside.471 = and i1 %descriptor.owner.offset.valid.469, %descriptor.extent.inside.467
  %descriptor.range.valid.470 = and i1 %descriptor.range.inside.471, %descriptor.payload.inside.468
  br i1 %descriptor.range.valid.470, label %descriptor.valid.472, label %descriptor.invalid.473
descriptor.invalid.473:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.472:
  %descriptor.initialized.status.474 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.458, i32 %local.check.extent.459)
  %helper.ok.475 = icmp eq i32 %descriptor.initialized.status.474, 0
  br i1 %helper.ok.475, label %helper.continue.476, label %frame.failure.0
helper.continue.476:
  br label %local.descriptor.checked.457
local.descriptor.inactive.456:
  br label %local.descriptor.checked.457
local.descriptor.checked.457:
  %local.is.active.477 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.477, label %local.descriptor.active.478, label %local.descriptor.inactive.479
local.descriptor.active.478:
  %local.check.offset.481 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.482 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.483 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.484 = load i32, ptr %local.owner.end.12, align 4
  %context.field.485 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.486 = load i32, ptr %context.field.485, align 4
  %stack.sub.489 = sub i32 %local.check.owner.end.484, %local.check.offset.481
  %descriptor.owner.inside.487 = icmp ule i32 %local.check.owner.end.484, %context.value.486
  %descriptor.offset.inside.488 = icmp ule i32 %local.check.offset.481, %local.check.owner.end.484
  %descriptor.extent.inside.490 = icmp ule i32 %local.check.extent.482, %stack.sub.489
  %descriptor.payload.inside.491 = icmp ule i32 %local.check.payload.483, %local.check.extent.482
  %descriptor.owner.offset.valid.492 = and i1 %descriptor.owner.inside.487, %descriptor.offset.inside.488
  %descriptor.range.inside.494 = and i1 %descriptor.owner.offset.valid.492, %descriptor.extent.inside.490
  %descriptor.range.valid.493 = and i1 %descriptor.range.inside.494, %descriptor.payload.inside.491
  br i1 %descriptor.range.valid.493, label %descriptor.valid.495, label %descriptor.invalid.496
descriptor.invalid.496:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.495:
  %descriptor.initialized.status.497 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.481, i32 %local.check.extent.482)
  %helper.ok.498 = icmp eq i32 %descriptor.initialized.status.497, 0
  br i1 %helper.ok.498, label %helper.continue.499, label %frame.failure.0
helper.continue.499:
  br label %local.descriptor.checked.480
local.descriptor.inactive.479:
  br label %local.descriptor.checked.480
local.descriptor.checked.480:
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %descriptor.element.500 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.501 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.500, i32 0, i32 0
  store i32 5, ptr %descriptor.field.501, align 4
  %descriptor.field.502 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.500, i32 0, i32 1
  store i32 %context.value.359, ptr %descriptor.field.502, align 4
  %descriptor.field.503 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.500, i32 0, i32 2
  store i32 %stack.offset.357, ptr %descriptor.field.503, align 4
  %descriptor.field.504 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.500, i32 0, i32 3
  store i32 %stack.offset.356, ptr %descriptor.field.504, align 4
  %descriptor.field.505 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.500, i32 0, i32 4
  store i32 %stack.offset.360, ptr %descriptor.field.505, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %context.value.359, i32 20, i32 %stack.offset.356, i32 %stack.offset.360, i32 %stack.offset.357)
  %context.field.506 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.507 = load i32, ptr %context.field.506, align 4
  %runtime.ok.508 = icmp eq i32 %context.value.507, 0
  br i1 %runtime.ok.508, label %runtime.continue.509, label %frame.failure.0
runtime.continue.509:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.15, i32 0, i32 0, i32 0)
  %context.field.510 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.511 = load i32, ptr %context.field.510, align 4
  %context.field.512 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.513 = load i32, ptr %context.field.512, align 4
  %context.field.514 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.515 = load i32, ptr %context.field.514, align 4
  %stack.offset.516 = add i32 %context.value.17, %context.value.19
  %stack.offset.517 = add i32 %context.value.511, %context.value.513
  %stack.sub.518 = sub i32 %stack.offset.516, %stack.offset.517
  %stack.sub.519 = sub i32 %context.value.19, %context.value.513
  %stack.sub.520 = sub i32 %context.value.515, %context.value.21
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.518, i32 %stack.sub.519)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.520)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0002(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %local.active.2 = alloca i1, align 1
  %local.offset.3 = alloca i32, align 4
  %local.extent.4 = alloca i32, align 4
  %local.payload.5 = alloca i32, align 4
  %local.owner.end.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  %local.active.8 = alloca i1, align 1
  %local.offset.9 = alloca i32, align 4
  %local.extent.10 = alloca i32, align 4
  %local.payload.11 = alloca i32, align 4
  %local.owner.end.12 = alloca i32, align 4
  %local.type.13 = alloca i32, align 4
  %local.active.14 = alloca i1, align 1
  %local.offset.15 = alloca i32, align 4
  %local.extent.16 = alloca i32, align 4
  %local.payload.17 = alloca i32, align 4
  %local.owner.end.18 = alloca i32, align 4
  %local.type.19 = alloca i32, align 4
  %local.active.20 = alloca i1, align 1
  %local.offset.21 = alloca i32, align 4
  %local.extent.22 = alloca i32, align 4
  %local.payload.23 = alloca i32, align 4
  %local.owner.end.24 = alloca i32, align 4
  %local.type.25 = alloca i32, align 4
  %local.active.26 = alloca i1, align 1
  %local.offset.27 = alloca i32, align 4
  %local.extent.28 = alloca i32, align 4
  %local.payload.29 = alloca i32, align 4
  %local.owner.end.30 = alloca i32, align 4
  %local.type.31 = alloca i32, align 4
  %local.active.32 = alloca i1, align 1
  %local.offset.33 = alloca i32, align 4
  %local.extent.34 = alloca i32, align 4
  %local.payload.35 = alloca i32, align 4
  %local.owner.end.36 = alloca i32, align 4
  %local.type.37 = alloca i32, align 4
  %local.active.38 = alloca i1, align 1
  %local.offset.39 = alloca i32, align 4
  %local.extent.40 = alloca i32, align 4
  %local.payload.41 = alloca i32, align 4
  %local.owner.end.42 = alloca i32, align 4
  %local.type.43 = alloca i32, align 4
  %field.location.3105 = alloca %AlOwningFieldLocation, align 4
  %field.location.3528 = alloca %AlOwningFieldLocation, align 4
  %string.concat.units.3747 = alloca i32, align 4
  %string.concat.payload.pointer.3748 = alloca i32, align 4
  %string.concat.extent.pointer.3749 = alloca i32, align 4
  %string.concat.units.4551 = alloca i32, align 4
  %string.concat.payload.pointer.4552 = alloca i32, align 4
  %string.concat.extent.pointer.4553 = alloca i32, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  store i1 false, ptr %local.active.20, align 1
  store i32 0, ptr %local.offset.21, align 4
  store i32 0, ptr %local.extent.22, align 4
  store i32 0, ptr %local.payload.23, align 4
  store i32 0, ptr %local.owner.end.24, align 4
  store i32 0, ptr %local.type.25, align 4
  store i1 false, ptr %local.active.26, align 1
  store i32 0, ptr %local.offset.27, align 4
  store i32 0, ptr %local.extent.28, align 4
  store i32 0, ptr %local.payload.29, align 4
  store i32 0, ptr %local.owner.end.30, align 4
  store i32 0, ptr %local.type.31, align 4
  store i1 false, ptr %local.active.32, align 1
  store i32 0, ptr %local.offset.33, align 4
  store i32 0, ptr %local.extent.34, align 4
  store i32 0, ptr %local.payload.35, align 4
  store i32 0, ptr %local.owner.end.36, align 4
  store i32 0, ptr %local.type.37, align 4
  store i1 false, ptr %local.active.38, align 1
  store i32 0, ptr %local.offset.39, align 4
  store i32 0, ptr %local.extent.40, align 4
  store i32 0, ptr %local.payload.41, align 4
  store i32 0, ptr %local.owner.end.42, align 4
  store i32 0, ptr %local.type.43, align 4
  %context.field.44 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.45 = load i32, ptr %context.field.44, align 4
  %context.field.46 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.47 = load i32, ptr %context.field.46, align 4
  %context.field.48 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.49 = load i32, ptr %context.field.48, align 4
  %context.field.50 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.51 = load i32, ptr %context.field.50, align 4
  %frame.entered.52 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.53 = icmp eq i32 %frame.entered.52, 0
  br i1 %frame.enter.ok.53, label %frame.enter.continue.54, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.54:
  %descriptor.element.55 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.56 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.55, i32 0, i32 0
  %descriptor.value.57 = load i32, ptr %descriptor.field.56, align 4
  %descriptor.field.58 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.55, i32 0, i32 1
  %descriptor.value.59 = load i32, ptr %descriptor.field.58, align 4
  %descriptor.field.60 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.55, i32 0, i32 2
  %descriptor.value.61 = load i32, ptr %descriptor.field.60, align 4
  %descriptor.field.62 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.55, i32 0, i32 3
  %descriptor.value.63 = load i32, ptr %descriptor.field.62, align 4
  %descriptor.field.64 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.55, i32 0, i32 4
  %descriptor.value.65 = load i32, ptr %descriptor.field.64, align 4
  %argument.type.valid.66 = icmp eq i32 %descriptor.value.57, 5
  br i1 %argument.type.valid.66, label %argument.type.ok.67, label %frame.failure.0
argument.type.ok.67:
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %stack.sub.72 = sub i32 %descriptor.value.65, %descriptor.value.59
  %descriptor.owner.inside.70 = icmp ule i32 %descriptor.value.65, %context.value.69
  %descriptor.offset.inside.71 = icmp ule i32 %descriptor.value.59, %descriptor.value.65
  %descriptor.extent.inside.73 = icmp ule i32 %descriptor.value.61, %stack.sub.72
  %descriptor.payload.inside.74 = icmp ule i32 %descriptor.value.63, %descriptor.value.61
  %descriptor.owner.offset.valid.75 = and i1 %descriptor.owner.inside.70, %descriptor.offset.inside.71
  %descriptor.range.inside.77 = and i1 %descriptor.owner.offset.valid.75, %descriptor.extent.inside.73
  %descriptor.range.valid.76 = and i1 %descriptor.range.inside.77, %descriptor.payload.inside.74
  %descriptor.type.valid.78 = icmp eq i32 5, 5
  %descriptor.valid.79 = and i1 %descriptor.range.valid.76, %descriptor.type.valid.78
  br i1 %descriptor.valid.79, label %descriptor.valid.80, label %descriptor.invalid.81
descriptor.invalid.81:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.80:
  %descriptor.initialized.status.82 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.59, i32 %descriptor.value.61)
  %helper.ok.83 = icmp eq i32 %descriptor.initialized.status.82, 0
  br i1 %helper.ok.83, label %helper.continue.84, label %frame.failure.0
helper.continue.84:
  %descriptor.element.85 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.86 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.85, i32 0, i32 0
  %descriptor.value.87 = load i32, ptr %descriptor.field.86, align 4
  %descriptor.field.88 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.85, i32 0, i32 1
  %descriptor.value.89 = load i32, ptr %descriptor.field.88, align 4
  %descriptor.field.90 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.85, i32 0, i32 2
  %descriptor.value.91 = load i32, ptr %descriptor.field.90, align 4
  %descriptor.field.92 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.85, i32 0, i32 3
  %descriptor.value.93 = load i32, ptr %descriptor.field.92, align 4
  %descriptor.field.94 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.85, i32 0, i32 4
  %descriptor.value.95 = load i32, ptr %descriptor.field.94, align 4
  %argument.type.valid.96 = icmp eq i32 %descriptor.value.87, 4
  br i1 %argument.type.valid.96, label %argument.type.ok.97, label %frame.failure.0
argument.type.ok.97:
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %stack.sub.102 = sub i32 %descriptor.value.95, %descriptor.value.89
  %descriptor.owner.inside.100 = icmp ule i32 %descriptor.value.95, %context.value.99
  %descriptor.offset.inside.101 = icmp ule i32 %descriptor.value.89, %descriptor.value.95
  %descriptor.extent.inside.103 = icmp ule i32 %descriptor.value.91, %stack.sub.102
  %descriptor.payload.inside.104 = icmp ule i32 %descriptor.value.93, %descriptor.value.91
  %descriptor.owner.offset.valid.105 = and i1 %descriptor.owner.inside.100, %descriptor.offset.inside.101
  %descriptor.range.inside.107 = and i1 %descriptor.owner.offset.valid.105, %descriptor.extent.inside.103
  %descriptor.range.valid.106 = and i1 %descriptor.range.inside.107, %descriptor.payload.inside.104
  %descriptor.type.valid.108 = icmp eq i32 4, 4
  %descriptor.valid.109 = and i1 %descriptor.range.valid.106, %descriptor.type.valid.108
  br i1 %descriptor.valid.109, label %descriptor.valid.110, label %descriptor.invalid.111
descriptor.invalid.111:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.110:
  %descriptor.initialized.status.112 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.89, i32 %descriptor.value.91)
  %helper.ok.113 = icmp eq i32 %descriptor.initialized.status.112, 0
  br i1 %helper.ok.113, label %helper.continue.114, label %frame.failure.0
helper.continue.114:
  %descriptor.element.115 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 2
  %descriptor.field.116 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.115, i32 0, i32 0
  %descriptor.value.117 = load i32, ptr %descriptor.field.116, align 4
  %descriptor.field.118 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.115, i32 0, i32 1
  %descriptor.value.119 = load i32, ptr %descriptor.field.118, align 4
  %descriptor.field.120 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.115, i32 0, i32 2
  %descriptor.value.121 = load i32, ptr %descriptor.field.120, align 4
  %descriptor.field.122 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.115, i32 0, i32 3
  %descriptor.value.123 = load i32, ptr %descriptor.field.122, align 4
  %descriptor.field.124 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.115, i32 0, i32 4
  %descriptor.value.125 = load i32, ptr %descriptor.field.124, align 4
  %argument.type.valid.126 = icmp eq i32 %descriptor.value.117, 6
  br i1 %argument.type.valid.126, label %argument.type.ok.127, label %frame.failure.0
argument.type.ok.127:
  %context.field.128 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.129 = load i32, ptr %context.field.128, align 4
  %stack.sub.132 = sub i32 %descriptor.value.125, %descriptor.value.119
  %descriptor.owner.inside.130 = icmp ule i32 %descriptor.value.125, %context.value.129
  %descriptor.offset.inside.131 = icmp ule i32 %descriptor.value.119, %descriptor.value.125
  %descriptor.extent.inside.133 = icmp ule i32 %descriptor.value.121, %stack.sub.132
  %descriptor.payload.inside.134 = icmp ule i32 %descriptor.value.123, %descriptor.value.121
  %descriptor.owner.offset.valid.135 = and i1 %descriptor.owner.inside.130, %descriptor.offset.inside.131
  %descriptor.range.inside.137 = and i1 %descriptor.owner.offset.valid.135, %descriptor.extent.inside.133
  %descriptor.range.valid.136 = and i1 %descriptor.range.inside.137, %descriptor.payload.inside.134
  %descriptor.type.valid.138 = icmp eq i32 6, 6
  %descriptor.valid.139 = and i1 %descriptor.range.valid.136, %descriptor.type.valid.138
  br i1 %descriptor.valid.139, label %descriptor.valid.140, label %descriptor.invalid.141
descriptor.invalid.141:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.140:
  %descriptor.initialized.status.142 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.119, i32 %descriptor.value.121)
  %helper.ok.143 = icmp eq i32 %descriptor.initialized.status.142, 0
  br i1 %helper.ok.143, label %helper.continue.144, label %frame.failure.0
helper.continue.144:
  %step.status.145 = call i32 @al_owning_charge_step(ptr %ctx, i32 27)
  %helper.ok.146 = icmp eq i32 %step.status.145, 0
  br i1 %helper.ok.146, label %helper.continue.147, label %frame.failure.0
helper.continue.147:
  store i1 true, ptr %local.active.2, align 1
  store i32 %descriptor.value.119, ptr %local.offset.3, align 4
  store i32 %descriptor.value.121, ptr %local.extent.4, align 4
  store i32 %descriptor.value.123, ptr %local.payload.5, align 4
  store i32 %descriptor.value.125, ptr %local.owner.end.6, align 4
  store i32 6, ptr %local.type.7, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %descriptor.value.119, i32 20, i32 %descriptor.value.123, i32 %descriptor.value.125, i32 %descriptor.value.121)
  %context.field.148 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.149 = load i32, ptr %context.field.148, align 4
  %runtime.ok.150 = icmp eq i32 %context.value.149, 0
  br i1 %runtime.ok.150, label %runtime.continue.151, label %frame.failure.0
runtime.continue.151:
  %context.field.152 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.153 = load i32, ptr %context.field.152, align 4
  %stack.sub.156 = sub i32 %descriptor.value.65, %descriptor.value.59
  %descriptor.owner.inside.154 = icmp ule i32 %descriptor.value.65, %context.value.153
  %descriptor.offset.inside.155 = icmp ule i32 %descriptor.value.59, %descriptor.value.65
  %descriptor.extent.inside.157 = icmp ule i32 %descriptor.value.61, %stack.sub.156
  %descriptor.payload.inside.158 = icmp ule i32 %descriptor.value.63, %descriptor.value.61
  %descriptor.owner.offset.valid.159 = and i1 %descriptor.owner.inside.154, %descriptor.offset.inside.155
  %descriptor.range.inside.161 = and i1 %descriptor.owner.offset.valid.159, %descriptor.extent.inside.157
  %descriptor.range.valid.160 = and i1 %descriptor.range.inside.161, %descriptor.payload.inside.158
  %descriptor.type.valid.162 = icmp eq i32 5, 5
  %descriptor.valid.163 = and i1 %descriptor.range.valid.160, %descriptor.type.valid.162
  br i1 %descriptor.valid.163, label %descriptor.valid.164, label %descriptor.invalid.165
descriptor.invalid.165:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.164:
  %descriptor.initialized.status.166 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.59, i32 %descriptor.value.61)
  %helper.ok.167 = icmp eq i32 %descriptor.initialized.status.166, 0
  br i1 %helper.ok.167, label %helper.continue.168, label %frame.failure.0
helper.continue.168:
  %context.field.169 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.170 = load i32, ptr %context.field.169, align 4
  %stack.sub.173 = sub i32 %descriptor.value.95, %descriptor.value.89
  %descriptor.owner.inside.171 = icmp ule i32 %descriptor.value.95, %context.value.170
  %descriptor.offset.inside.172 = icmp ule i32 %descriptor.value.89, %descriptor.value.95
  %descriptor.extent.inside.174 = icmp ule i32 %descriptor.value.91, %stack.sub.173
  %descriptor.payload.inside.175 = icmp ule i32 %descriptor.value.93, %descriptor.value.91
  %descriptor.owner.offset.valid.176 = and i1 %descriptor.owner.inside.171, %descriptor.offset.inside.172
  %descriptor.range.inside.178 = and i1 %descriptor.owner.offset.valid.176, %descriptor.extent.inside.174
  %descriptor.range.valid.177 = and i1 %descriptor.range.inside.178, %descriptor.payload.inside.175
  %descriptor.type.valid.179 = icmp eq i32 4, 4
  %descriptor.valid.180 = and i1 %descriptor.range.valid.177, %descriptor.type.valid.179
  br i1 %descriptor.valid.180, label %descriptor.valid.181, label %descriptor.invalid.182
descriptor.invalid.182:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.181:
  %descriptor.initialized.status.183 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.89, i32 %descriptor.value.91)
  %helper.ok.184 = icmp eq i32 %descriptor.initialized.status.183, 0
  br i1 %helper.ok.184, label %helper.continue.185, label %frame.failure.0
helper.continue.185:
  %local.is.active.186 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.186, label %local.descriptor.active.187, label %local.descriptor.inactive.188
local.descriptor.active.187:
  %local.check.offset.190 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.191 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.192 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.193 = load i32, ptr %local.owner.end.6, align 4
  %context.field.194 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.195 = load i32, ptr %context.field.194, align 4
  %stack.sub.198 = sub i32 %local.check.owner.end.193, %local.check.offset.190
  %descriptor.owner.inside.196 = icmp ule i32 %local.check.owner.end.193, %context.value.195
  %descriptor.offset.inside.197 = icmp ule i32 %local.check.offset.190, %local.check.owner.end.193
  %descriptor.extent.inside.199 = icmp ule i32 %local.check.extent.191, %stack.sub.198
  %descriptor.payload.inside.200 = icmp ule i32 %local.check.payload.192, %local.check.extent.191
  %descriptor.owner.offset.valid.201 = and i1 %descriptor.owner.inside.196, %descriptor.offset.inside.197
  %descriptor.range.inside.203 = and i1 %descriptor.owner.offset.valid.201, %descriptor.extent.inside.199
  %descriptor.range.valid.202 = and i1 %descriptor.range.inside.203, %descriptor.payload.inside.200
  br i1 %descriptor.range.valid.202, label %descriptor.valid.204, label %descriptor.invalid.205
descriptor.invalid.205:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.204:
  %descriptor.initialized.status.206 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.190, i32 %local.check.extent.191)
  %helper.ok.207 = icmp eq i32 %descriptor.initialized.status.206, 0
  br i1 %helper.ok.207, label %helper.continue.208, label %frame.failure.0
helper.continue.208:
  br label %local.descriptor.checked.189
local.descriptor.inactive.188:
  br label %local.descriptor.checked.189
local.descriptor.checked.189:
  %local.is.active.209 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.209, label %local.descriptor.active.210, label %local.descriptor.inactive.211
local.descriptor.active.210:
  %local.check.offset.213 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.214 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.215 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.216 = load i32, ptr %local.owner.end.12, align 4
  %context.field.217 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.218 = load i32, ptr %context.field.217, align 4
  %stack.sub.221 = sub i32 %local.check.owner.end.216, %local.check.offset.213
  %descriptor.owner.inside.219 = icmp ule i32 %local.check.owner.end.216, %context.value.218
  %descriptor.offset.inside.220 = icmp ule i32 %local.check.offset.213, %local.check.owner.end.216
  %descriptor.extent.inside.222 = icmp ule i32 %local.check.extent.214, %stack.sub.221
  %descriptor.payload.inside.223 = icmp ule i32 %local.check.payload.215, %local.check.extent.214
  %descriptor.owner.offset.valid.224 = and i1 %descriptor.owner.inside.219, %descriptor.offset.inside.220
  %descriptor.range.inside.226 = and i1 %descriptor.owner.offset.valid.224, %descriptor.extent.inside.222
  %descriptor.range.valid.225 = and i1 %descriptor.range.inside.226, %descriptor.payload.inside.223
  br i1 %descriptor.range.valid.225, label %descriptor.valid.227, label %descriptor.invalid.228
descriptor.invalid.228:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.227:
  %descriptor.initialized.status.229 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.213, i32 %local.check.extent.214)
  %helper.ok.230 = icmp eq i32 %descriptor.initialized.status.229, 0
  br i1 %helper.ok.230, label %helper.continue.231, label %frame.failure.0
helper.continue.231:
  br label %local.descriptor.checked.212
local.descriptor.inactive.211:
  br label %local.descriptor.checked.212
local.descriptor.checked.212:
  %local.is.active.232 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.232, label %local.descriptor.active.233, label %local.descriptor.inactive.234
local.descriptor.active.233:
  %local.check.offset.236 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.237 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.238 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.239 = load i32, ptr %local.owner.end.18, align 4
  %context.field.240 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.241 = load i32, ptr %context.field.240, align 4
  %stack.sub.244 = sub i32 %local.check.owner.end.239, %local.check.offset.236
  %descriptor.owner.inside.242 = icmp ule i32 %local.check.owner.end.239, %context.value.241
  %descriptor.offset.inside.243 = icmp ule i32 %local.check.offset.236, %local.check.owner.end.239
  %descriptor.extent.inside.245 = icmp ule i32 %local.check.extent.237, %stack.sub.244
  %descriptor.payload.inside.246 = icmp ule i32 %local.check.payload.238, %local.check.extent.237
  %descriptor.owner.offset.valid.247 = and i1 %descriptor.owner.inside.242, %descriptor.offset.inside.243
  %descriptor.range.inside.249 = and i1 %descriptor.owner.offset.valid.247, %descriptor.extent.inside.245
  %descriptor.range.valid.248 = and i1 %descriptor.range.inside.249, %descriptor.payload.inside.246
  br i1 %descriptor.range.valid.248, label %descriptor.valid.250, label %descriptor.invalid.251
descriptor.invalid.251:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.250:
  %descriptor.initialized.status.252 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.236, i32 %local.check.extent.237)
  %helper.ok.253 = icmp eq i32 %descriptor.initialized.status.252, 0
  br i1 %helper.ok.253, label %helper.continue.254, label %frame.failure.0
helper.continue.254:
  br label %local.descriptor.checked.235
local.descriptor.inactive.234:
  br label %local.descriptor.checked.235
local.descriptor.checked.235:
  %local.is.active.255 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.255, label %local.descriptor.active.256, label %local.descriptor.inactive.257
local.descriptor.active.256:
  %local.check.offset.259 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.260 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.261 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.262 = load i32, ptr %local.owner.end.24, align 4
  %context.field.263 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.264 = load i32, ptr %context.field.263, align 4
  %stack.sub.267 = sub i32 %local.check.owner.end.262, %local.check.offset.259
  %descriptor.owner.inside.265 = icmp ule i32 %local.check.owner.end.262, %context.value.264
  %descriptor.offset.inside.266 = icmp ule i32 %local.check.offset.259, %local.check.owner.end.262
  %descriptor.extent.inside.268 = icmp ule i32 %local.check.extent.260, %stack.sub.267
  %descriptor.payload.inside.269 = icmp ule i32 %local.check.payload.261, %local.check.extent.260
  %descriptor.owner.offset.valid.270 = and i1 %descriptor.owner.inside.265, %descriptor.offset.inside.266
  %descriptor.range.inside.272 = and i1 %descriptor.owner.offset.valid.270, %descriptor.extent.inside.268
  %descriptor.range.valid.271 = and i1 %descriptor.range.inside.272, %descriptor.payload.inside.269
  br i1 %descriptor.range.valid.271, label %descriptor.valid.273, label %descriptor.invalid.274
descriptor.invalid.274:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.273:
  %descriptor.initialized.status.275 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.259, i32 %local.check.extent.260)
  %helper.ok.276 = icmp eq i32 %descriptor.initialized.status.275, 0
  br i1 %helper.ok.276, label %helper.continue.277, label %frame.failure.0
helper.continue.277:
  br label %local.descriptor.checked.258
local.descriptor.inactive.257:
  br label %local.descriptor.checked.258
local.descriptor.checked.258:
  %local.is.active.278 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.278, label %local.descriptor.active.279, label %local.descriptor.inactive.280
local.descriptor.active.279:
  %local.check.offset.282 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.283 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.284 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.285 = load i32, ptr %local.owner.end.30, align 4
  %context.field.286 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.287 = load i32, ptr %context.field.286, align 4
  %stack.sub.290 = sub i32 %local.check.owner.end.285, %local.check.offset.282
  %descriptor.owner.inside.288 = icmp ule i32 %local.check.owner.end.285, %context.value.287
  %descriptor.offset.inside.289 = icmp ule i32 %local.check.offset.282, %local.check.owner.end.285
  %descriptor.extent.inside.291 = icmp ule i32 %local.check.extent.283, %stack.sub.290
  %descriptor.payload.inside.292 = icmp ule i32 %local.check.payload.284, %local.check.extent.283
  %descriptor.owner.offset.valid.293 = and i1 %descriptor.owner.inside.288, %descriptor.offset.inside.289
  %descriptor.range.inside.295 = and i1 %descriptor.owner.offset.valid.293, %descriptor.extent.inside.291
  %descriptor.range.valid.294 = and i1 %descriptor.range.inside.295, %descriptor.payload.inside.292
  br i1 %descriptor.range.valid.294, label %descriptor.valid.296, label %descriptor.invalid.297
descriptor.invalid.297:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.296:
  %descriptor.initialized.status.298 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.282, i32 %local.check.extent.283)
  %helper.ok.299 = icmp eq i32 %descriptor.initialized.status.298, 0
  br i1 %helper.ok.299, label %helper.continue.300, label %frame.failure.0
helper.continue.300:
  br label %local.descriptor.checked.281
local.descriptor.inactive.280:
  br label %local.descriptor.checked.281
local.descriptor.checked.281:
  %local.is.active.301 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.301, label %local.descriptor.active.302, label %local.descriptor.inactive.303
local.descriptor.active.302:
  %local.check.offset.305 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.306 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.307 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.308 = load i32, ptr %local.owner.end.36, align 4
  %context.field.309 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.310 = load i32, ptr %context.field.309, align 4
  %stack.sub.313 = sub i32 %local.check.owner.end.308, %local.check.offset.305
  %descriptor.owner.inside.311 = icmp ule i32 %local.check.owner.end.308, %context.value.310
  %descriptor.offset.inside.312 = icmp ule i32 %local.check.offset.305, %local.check.owner.end.308
  %descriptor.extent.inside.314 = icmp ule i32 %local.check.extent.306, %stack.sub.313
  %descriptor.payload.inside.315 = icmp ule i32 %local.check.payload.307, %local.check.extent.306
  %descriptor.owner.offset.valid.316 = and i1 %descriptor.owner.inside.311, %descriptor.offset.inside.312
  %descriptor.range.inside.318 = and i1 %descriptor.owner.offset.valid.316, %descriptor.extent.inside.314
  %descriptor.range.valid.317 = and i1 %descriptor.range.inside.318, %descriptor.payload.inside.315
  br i1 %descriptor.range.valid.317, label %descriptor.valid.319, label %descriptor.invalid.320
descriptor.invalid.320:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.319:
  %descriptor.initialized.status.321 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.305, i32 %local.check.extent.306)
  %helper.ok.322 = icmp eq i32 %descriptor.initialized.status.321, 0
  br i1 %helper.ok.322, label %helper.continue.323, label %frame.failure.0
helper.continue.323:
  br label %local.descriptor.checked.304
local.descriptor.inactive.303:
  br label %local.descriptor.checked.304
local.descriptor.checked.304:
  %local.is.active.324 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.324, label %local.descriptor.active.325, label %local.descriptor.inactive.326
local.descriptor.active.325:
  %local.check.offset.328 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.329 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.330 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.331 = load i32, ptr %local.owner.end.42, align 4
  %context.field.332 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.333 = load i32, ptr %context.field.332, align 4
  %stack.sub.336 = sub i32 %local.check.owner.end.331, %local.check.offset.328
  %descriptor.owner.inside.334 = icmp ule i32 %local.check.owner.end.331, %context.value.333
  %descriptor.offset.inside.335 = icmp ule i32 %local.check.offset.328, %local.check.owner.end.331
  %descriptor.extent.inside.337 = icmp ule i32 %local.check.extent.329, %stack.sub.336
  %descriptor.payload.inside.338 = icmp ule i32 %local.check.payload.330, %local.check.extent.329
  %descriptor.owner.offset.valid.339 = and i1 %descriptor.owner.inside.334, %descriptor.offset.inside.335
  %descriptor.range.inside.341 = and i1 %descriptor.owner.offset.valid.339, %descriptor.extent.inside.337
  %descriptor.range.valid.340 = and i1 %descriptor.range.inside.341, %descriptor.payload.inside.338
  br i1 %descriptor.range.valid.340, label %descriptor.valid.342, label %descriptor.invalid.343
descriptor.invalid.343:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.342:
  %descriptor.initialized.status.344 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.328, i32 %local.check.extent.329)
  %helper.ok.345 = icmp eq i32 %descriptor.initialized.status.344, 0
  br i1 %helper.ok.345, label %helper.continue.346, label %frame.failure.0
helper.continue.346:
  br label %local.descriptor.checked.327
local.descriptor.inactive.326:
  br label %local.descriptor.checked.327
local.descriptor.checked.327:
  %step.status.347 = call i32 @al_owning_charge_step(ptr %ctx, i32 28)
  %helper.ok.348 = icmp eq i32 %step.status.347, 0
  br i1 %helper.ok.348, label %helper.continue.349, label %frame.failure.0
helper.continue.349:
  store i1 true, ptr %local.active.8, align 1
  store i32 %descriptor.value.89, ptr %local.offset.9, align 4
  store i32 %descriptor.value.91, ptr %local.extent.10, align 4
  store i32 %descriptor.value.93, ptr %local.payload.11, align 4
  store i32 %descriptor.value.95, ptr %local.owner.end.12, align 4
  store i32 4, ptr %local.type.13, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %descriptor.value.89, i32 20, i32 %descriptor.value.93, i32 %descriptor.value.95, i32 %descriptor.value.91)
  %context.field.350 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.351 = load i32, ptr %context.field.350, align 4
  %runtime.ok.352 = icmp eq i32 %context.value.351, 0
  br i1 %runtime.ok.352, label %runtime.continue.353, label %frame.failure.0
runtime.continue.353:
  %context.field.354 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.355 = load i32, ptr %context.field.354, align 4
  %stack.sub.358 = sub i32 %descriptor.value.65, %descriptor.value.59
  %descriptor.owner.inside.356 = icmp ule i32 %descriptor.value.65, %context.value.355
  %descriptor.offset.inside.357 = icmp ule i32 %descriptor.value.59, %descriptor.value.65
  %descriptor.extent.inside.359 = icmp ule i32 %descriptor.value.61, %stack.sub.358
  %descriptor.payload.inside.360 = icmp ule i32 %descriptor.value.63, %descriptor.value.61
  %descriptor.owner.offset.valid.361 = and i1 %descriptor.owner.inside.356, %descriptor.offset.inside.357
  %descriptor.range.inside.363 = and i1 %descriptor.owner.offset.valid.361, %descriptor.extent.inside.359
  %descriptor.range.valid.362 = and i1 %descriptor.range.inside.363, %descriptor.payload.inside.360
  %descriptor.type.valid.364 = icmp eq i32 5, 5
  %descriptor.valid.365 = and i1 %descriptor.range.valid.362, %descriptor.type.valid.364
  br i1 %descriptor.valid.365, label %descriptor.valid.366, label %descriptor.invalid.367
descriptor.invalid.367:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.366:
  %descriptor.initialized.status.368 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.59, i32 %descriptor.value.61)
  %helper.ok.369 = icmp eq i32 %descriptor.initialized.status.368, 0
  br i1 %helper.ok.369, label %helper.continue.370, label %frame.failure.0
helper.continue.370:
  %local.is.active.371 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.371, label %local.descriptor.active.372, label %local.descriptor.inactive.373
local.descriptor.active.372:
  %local.check.offset.375 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.376 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.377 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.378 = load i32, ptr %local.owner.end.6, align 4
  %context.field.379 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.380 = load i32, ptr %context.field.379, align 4
  %stack.sub.383 = sub i32 %local.check.owner.end.378, %local.check.offset.375
  %descriptor.owner.inside.381 = icmp ule i32 %local.check.owner.end.378, %context.value.380
  %descriptor.offset.inside.382 = icmp ule i32 %local.check.offset.375, %local.check.owner.end.378
  %descriptor.extent.inside.384 = icmp ule i32 %local.check.extent.376, %stack.sub.383
  %descriptor.payload.inside.385 = icmp ule i32 %local.check.payload.377, %local.check.extent.376
  %descriptor.owner.offset.valid.386 = and i1 %descriptor.owner.inside.381, %descriptor.offset.inside.382
  %descriptor.range.inside.388 = and i1 %descriptor.owner.offset.valid.386, %descriptor.extent.inside.384
  %descriptor.range.valid.387 = and i1 %descriptor.range.inside.388, %descriptor.payload.inside.385
  br i1 %descriptor.range.valid.387, label %descriptor.valid.389, label %descriptor.invalid.390
descriptor.invalid.390:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.389:
  %descriptor.initialized.status.391 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.375, i32 %local.check.extent.376)
  %helper.ok.392 = icmp eq i32 %descriptor.initialized.status.391, 0
  br i1 %helper.ok.392, label %helper.continue.393, label %frame.failure.0
helper.continue.393:
  br label %local.descriptor.checked.374
local.descriptor.inactive.373:
  br label %local.descriptor.checked.374
local.descriptor.checked.374:
  %local.is.active.394 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.394, label %local.descriptor.active.395, label %local.descriptor.inactive.396
local.descriptor.active.395:
  %local.check.offset.398 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.399 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.400 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.401 = load i32, ptr %local.owner.end.12, align 4
  %context.field.402 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.403 = load i32, ptr %context.field.402, align 4
  %stack.sub.406 = sub i32 %local.check.owner.end.401, %local.check.offset.398
  %descriptor.owner.inside.404 = icmp ule i32 %local.check.owner.end.401, %context.value.403
  %descriptor.offset.inside.405 = icmp ule i32 %local.check.offset.398, %local.check.owner.end.401
  %descriptor.extent.inside.407 = icmp ule i32 %local.check.extent.399, %stack.sub.406
  %descriptor.payload.inside.408 = icmp ule i32 %local.check.payload.400, %local.check.extent.399
  %descriptor.owner.offset.valid.409 = and i1 %descriptor.owner.inside.404, %descriptor.offset.inside.405
  %descriptor.range.inside.411 = and i1 %descriptor.owner.offset.valid.409, %descriptor.extent.inside.407
  %descriptor.range.valid.410 = and i1 %descriptor.range.inside.411, %descriptor.payload.inside.408
  br i1 %descriptor.range.valid.410, label %descriptor.valid.412, label %descriptor.invalid.413
descriptor.invalid.413:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.412:
  %descriptor.initialized.status.414 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.398, i32 %local.check.extent.399)
  %helper.ok.415 = icmp eq i32 %descriptor.initialized.status.414, 0
  br i1 %helper.ok.415, label %helper.continue.416, label %frame.failure.0
helper.continue.416:
  br label %local.descriptor.checked.397
local.descriptor.inactive.396:
  br label %local.descriptor.checked.397
local.descriptor.checked.397:
  %local.is.active.417 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.417, label %local.descriptor.active.418, label %local.descriptor.inactive.419
local.descriptor.active.418:
  %local.check.offset.421 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.422 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.423 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.424 = load i32, ptr %local.owner.end.18, align 4
  %context.field.425 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.426 = load i32, ptr %context.field.425, align 4
  %stack.sub.429 = sub i32 %local.check.owner.end.424, %local.check.offset.421
  %descriptor.owner.inside.427 = icmp ule i32 %local.check.owner.end.424, %context.value.426
  %descriptor.offset.inside.428 = icmp ule i32 %local.check.offset.421, %local.check.owner.end.424
  %descriptor.extent.inside.430 = icmp ule i32 %local.check.extent.422, %stack.sub.429
  %descriptor.payload.inside.431 = icmp ule i32 %local.check.payload.423, %local.check.extent.422
  %descriptor.owner.offset.valid.432 = and i1 %descriptor.owner.inside.427, %descriptor.offset.inside.428
  %descriptor.range.inside.434 = and i1 %descriptor.owner.offset.valid.432, %descriptor.extent.inside.430
  %descriptor.range.valid.433 = and i1 %descriptor.range.inside.434, %descriptor.payload.inside.431
  br i1 %descriptor.range.valid.433, label %descriptor.valid.435, label %descriptor.invalid.436
descriptor.invalid.436:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.435:
  %descriptor.initialized.status.437 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.421, i32 %local.check.extent.422)
  %helper.ok.438 = icmp eq i32 %descriptor.initialized.status.437, 0
  br i1 %helper.ok.438, label %helper.continue.439, label %frame.failure.0
helper.continue.439:
  br label %local.descriptor.checked.420
local.descriptor.inactive.419:
  br label %local.descriptor.checked.420
local.descriptor.checked.420:
  %local.is.active.440 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.440, label %local.descriptor.active.441, label %local.descriptor.inactive.442
local.descriptor.active.441:
  %local.check.offset.444 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.445 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.446 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.447 = load i32, ptr %local.owner.end.24, align 4
  %context.field.448 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.449 = load i32, ptr %context.field.448, align 4
  %stack.sub.452 = sub i32 %local.check.owner.end.447, %local.check.offset.444
  %descriptor.owner.inside.450 = icmp ule i32 %local.check.owner.end.447, %context.value.449
  %descriptor.offset.inside.451 = icmp ule i32 %local.check.offset.444, %local.check.owner.end.447
  %descriptor.extent.inside.453 = icmp ule i32 %local.check.extent.445, %stack.sub.452
  %descriptor.payload.inside.454 = icmp ule i32 %local.check.payload.446, %local.check.extent.445
  %descriptor.owner.offset.valid.455 = and i1 %descriptor.owner.inside.450, %descriptor.offset.inside.451
  %descriptor.range.inside.457 = and i1 %descriptor.owner.offset.valid.455, %descriptor.extent.inside.453
  %descriptor.range.valid.456 = and i1 %descriptor.range.inside.457, %descriptor.payload.inside.454
  br i1 %descriptor.range.valid.456, label %descriptor.valid.458, label %descriptor.invalid.459
descriptor.invalid.459:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.458:
  %descriptor.initialized.status.460 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.444, i32 %local.check.extent.445)
  %helper.ok.461 = icmp eq i32 %descriptor.initialized.status.460, 0
  br i1 %helper.ok.461, label %helper.continue.462, label %frame.failure.0
helper.continue.462:
  br label %local.descriptor.checked.443
local.descriptor.inactive.442:
  br label %local.descriptor.checked.443
local.descriptor.checked.443:
  %local.is.active.463 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.463, label %local.descriptor.active.464, label %local.descriptor.inactive.465
local.descriptor.active.464:
  %local.check.offset.467 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.468 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.469 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.470 = load i32, ptr %local.owner.end.30, align 4
  %context.field.471 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.472 = load i32, ptr %context.field.471, align 4
  %stack.sub.475 = sub i32 %local.check.owner.end.470, %local.check.offset.467
  %descriptor.owner.inside.473 = icmp ule i32 %local.check.owner.end.470, %context.value.472
  %descriptor.offset.inside.474 = icmp ule i32 %local.check.offset.467, %local.check.owner.end.470
  %descriptor.extent.inside.476 = icmp ule i32 %local.check.extent.468, %stack.sub.475
  %descriptor.payload.inside.477 = icmp ule i32 %local.check.payload.469, %local.check.extent.468
  %descriptor.owner.offset.valid.478 = and i1 %descriptor.owner.inside.473, %descriptor.offset.inside.474
  %descriptor.range.inside.480 = and i1 %descriptor.owner.offset.valid.478, %descriptor.extent.inside.476
  %descriptor.range.valid.479 = and i1 %descriptor.range.inside.480, %descriptor.payload.inside.477
  br i1 %descriptor.range.valid.479, label %descriptor.valid.481, label %descriptor.invalid.482
descriptor.invalid.482:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.481:
  %descriptor.initialized.status.483 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.467, i32 %local.check.extent.468)
  %helper.ok.484 = icmp eq i32 %descriptor.initialized.status.483, 0
  br i1 %helper.ok.484, label %helper.continue.485, label %frame.failure.0
helper.continue.485:
  br label %local.descriptor.checked.466
local.descriptor.inactive.465:
  br label %local.descriptor.checked.466
local.descriptor.checked.466:
  %local.is.active.486 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.486, label %local.descriptor.active.487, label %local.descriptor.inactive.488
local.descriptor.active.487:
  %local.check.offset.490 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.491 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.492 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.493 = load i32, ptr %local.owner.end.36, align 4
  %context.field.494 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.495 = load i32, ptr %context.field.494, align 4
  %stack.sub.498 = sub i32 %local.check.owner.end.493, %local.check.offset.490
  %descriptor.owner.inside.496 = icmp ule i32 %local.check.owner.end.493, %context.value.495
  %descriptor.offset.inside.497 = icmp ule i32 %local.check.offset.490, %local.check.owner.end.493
  %descriptor.extent.inside.499 = icmp ule i32 %local.check.extent.491, %stack.sub.498
  %descriptor.payload.inside.500 = icmp ule i32 %local.check.payload.492, %local.check.extent.491
  %descriptor.owner.offset.valid.501 = and i1 %descriptor.owner.inside.496, %descriptor.offset.inside.497
  %descriptor.range.inside.503 = and i1 %descriptor.owner.offset.valid.501, %descriptor.extent.inside.499
  %descriptor.range.valid.502 = and i1 %descriptor.range.inside.503, %descriptor.payload.inside.500
  br i1 %descriptor.range.valid.502, label %descriptor.valid.504, label %descriptor.invalid.505
descriptor.invalid.505:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.504:
  %descriptor.initialized.status.506 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.490, i32 %local.check.extent.491)
  %helper.ok.507 = icmp eq i32 %descriptor.initialized.status.506, 0
  br i1 %helper.ok.507, label %helper.continue.508, label %frame.failure.0
helper.continue.508:
  br label %local.descriptor.checked.489
local.descriptor.inactive.488:
  br label %local.descriptor.checked.489
local.descriptor.checked.489:
  %local.is.active.509 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.509, label %local.descriptor.active.510, label %local.descriptor.inactive.511
local.descriptor.active.510:
  %local.check.offset.513 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.514 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.515 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.516 = load i32, ptr %local.owner.end.42, align 4
  %context.field.517 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.518 = load i32, ptr %context.field.517, align 4
  %stack.sub.521 = sub i32 %local.check.owner.end.516, %local.check.offset.513
  %descriptor.owner.inside.519 = icmp ule i32 %local.check.owner.end.516, %context.value.518
  %descriptor.offset.inside.520 = icmp ule i32 %local.check.offset.513, %local.check.owner.end.516
  %descriptor.extent.inside.522 = icmp ule i32 %local.check.extent.514, %stack.sub.521
  %descriptor.payload.inside.523 = icmp ule i32 %local.check.payload.515, %local.check.extent.514
  %descriptor.owner.offset.valid.524 = and i1 %descriptor.owner.inside.519, %descriptor.offset.inside.520
  %descriptor.range.inside.526 = and i1 %descriptor.owner.offset.valid.524, %descriptor.extent.inside.522
  %descriptor.range.valid.525 = and i1 %descriptor.range.inside.526, %descriptor.payload.inside.523
  br i1 %descriptor.range.valid.525, label %descriptor.valid.527, label %descriptor.invalid.528
descriptor.invalid.528:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.527:
  %descriptor.initialized.status.529 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.513, i32 %local.check.extent.514)
  %helper.ok.530 = icmp eq i32 %descriptor.initialized.status.529, 0
  br i1 %helper.ok.530, label %helper.continue.531, label %frame.failure.0
helper.continue.531:
  br label %local.descriptor.checked.512
local.descriptor.inactive.511:
  br label %local.descriptor.checked.512
local.descriptor.checked.512:
  %step.status.532 = call i32 @al_owning_charge_step(ptr %ctx, i32 29)
  %helper.ok.533 = icmp eq i32 %step.status.532, 0
  br i1 %helper.ok.533, label %helper.continue.534, label %frame.failure.0
helper.continue.534:
  store i1 true, ptr %local.active.14, align 1
  store i32 %descriptor.value.59, ptr %local.offset.15, align 4
  store i32 %descriptor.value.61, ptr %local.extent.16, align 4
  store i32 %descriptor.value.63, ptr %local.payload.17, align 4
  store i32 %descriptor.value.65, ptr %local.owner.end.18, align 4
  store i32 5, ptr %local.type.19, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.59, i32 20, i32 %descriptor.value.63, i32 %descriptor.value.65, i32 %descriptor.value.61)
  %context.field.535 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.536 = load i32, ptr %context.field.535, align 4
  %runtime.ok.537 = icmp eq i32 %context.value.536, 0
  br i1 %runtime.ok.537, label %runtime.continue.538, label %frame.failure.0
runtime.continue.538:
  %local.is.active.539 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.539, label %local.descriptor.active.540, label %local.descriptor.inactive.541
local.descriptor.active.540:
  %local.check.offset.543 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.544 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.545 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.546 = load i32, ptr %local.owner.end.6, align 4
  %context.field.547 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.548 = load i32, ptr %context.field.547, align 4
  %stack.sub.551 = sub i32 %local.check.owner.end.546, %local.check.offset.543
  %descriptor.owner.inside.549 = icmp ule i32 %local.check.owner.end.546, %context.value.548
  %descriptor.offset.inside.550 = icmp ule i32 %local.check.offset.543, %local.check.owner.end.546
  %descriptor.extent.inside.552 = icmp ule i32 %local.check.extent.544, %stack.sub.551
  %descriptor.payload.inside.553 = icmp ule i32 %local.check.payload.545, %local.check.extent.544
  %descriptor.owner.offset.valid.554 = and i1 %descriptor.owner.inside.549, %descriptor.offset.inside.550
  %descriptor.range.inside.556 = and i1 %descriptor.owner.offset.valid.554, %descriptor.extent.inside.552
  %descriptor.range.valid.555 = and i1 %descriptor.range.inside.556, %descriptor.payload.inside.553
  br i1 %descriptor.range.valid.555, label %descriptor.valid.557, label %descriptor.invalid.558
descriptor.invalid.558:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.557:
  %descriptor.initialized.status.559 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.543, i32 %local.check.extent.544)
  %helper.ok.560 = icmp eq i32 %descriptor.initialized.status.559, 0
  br i1 %helper.ok.560, label %helper.continue.561, label %frame.failure.0
helper.continue.561:
  br label %local.descriptor.checked.542
local.descriptor.inactive.541:
  br label %local.descriptor.checked.542
local.descriptor.checked.542:
  %local.is.active.562 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.562, label %local.descriptor.active.563, label %local.descriptor.inactive.564
local.descriptor.active.563:
  %local.check.offset.566 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.567 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.568 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.569 = load i32, ptr %local.owner.end.12, align 4
  %context.field.570 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.571 = load i32, ptr %context.field.570, align 4
  %stack.sub.574 = sub i32 %local.check.owner.end.569, %local.check.offset.566
  %descriptor.owner.inside.572 = icmp ule i32 %local.check.owner.end.569, %context.value.571
  %descriptor.offset.inside.573 = icmp ule i32 %local.check.offset.566, %local.check.owner.end.569
  %descriptor.extent.inside.575 = icmp ule i32 %local.check.extent.567, %stack.sub.574
  %descriptor.payload.inside.576 = icmp ule i32 %local.check.payload.568, %local.check.extent.567
  %descriptor.owner.offset.valid.577 = and i1 %descriptor.owner.inside.572, %descriptor.offset.inside.573
  %descriptor.range.inside.579 = and i1 %descriptor.owner.offset.valid.577, %descriptor.extent.inside.575
  %descriptor.range.valid.578 = and i1 %descriptor.range.inside.579, %descriptor.payload.inside.576
  br i1 %descriptor.range.valid.578, label %descriptor.valid.580, label %descriptor.invalid.581
descriptor.invalid.581:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.580:
  %descriptor.initialized.status.582 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.566, i32 %local.check.extent.567)
  %helper.ok.583 = icmp eq i32 %descriptor.initialized.status.582, 0
  br i1 %helper.ok.583, label %helper.continue.584, label %frame.failure.0
helper.continue.584:
  br label %local.descriptor.checked.565
local.descriptor.inactive.564:
  br label %local.descriptor.checked.565
local.descriptor.checked.565:
  %local.is.active.585 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.585, label %local.descriptor.active.586, label %local.descriptor.inactive.587
local.descriptor.active.586:
  %local.check.offset.589 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.590 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.591 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.592 = load i32, ptr %local.owner.end.18, align 4
  %context.field.593 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.594 = load i32, ptr %context.field.593, align 4
  %stack.sub.597 = sub i32 %local.check.owner.end.592, %local.check.offset.589
  %descriptor.owner.inside.595 = icmp ule i32 %local.check.owner.end.592, %context.value.594
  %descriptor.offset.inside.596 = icmp ule i32 %local.check.offset.589, %local.check.owner.end.592
  %descriptor.extent.inside.598 = icmp ule i32 %local.check.extent.590, %stack.sub.597
  %descriptor.payload.inside.599 = icmp ule i32 %local.check.payload.591, %local.check.extent.590
  %descriptor.owner.offset.valid.600 = and i1 %descriptor.owner.inside.595, %descriptor.offset.inside.596
  %descriptor.range.inside.602 = and i1 %descriptor.owner.offset.valid.600, %descriptor.extent.inside.598
  %descriptor.range.valid.601 = and i1 %descriptor.range.inside.602, %descriptor.payload.inside.599
  br i1 %descriptor.range.valid.601, label %descriptor.valid.603, label %descriptor.invalid.604
descriptor.invalid.604:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.603:
  %descriptor.initialized.status.605 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.589, i32 %local.check.extent.590)
  %helper.ok.606 = icmp eq i32 %descriptor.initialized.status.605, 0
  br i1 %helper.ok.606, label %helper.continue.607, label %frame.failure.0
helper.continue.607:
  br label %local.descriptor.checked.588
local.descriptor.inactive.587:
  br label %local.descriptor.checked.588
local.descriptor.checked.588:
  %local.is.active.608 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.608, label %local.descriptor.active.609, label %local.descriptor.inactive.610
local.descriptor.active.609:
  %local.check.offset.612 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.613 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.614 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.615 = load i32, ptr %local.owner.end.24, align 4
  %context.field.616 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.617 = load i32, ptr %context.field.616, align 4
  %stack.sub.620 = sub i32 %local.check.owner.end.615, %local.check.offset.612
  %descriptor.owner.inside.618 = icmp ule i32 %local.check.owner.end.615, %context.value.617
  %descriptor.offset.inside.619 = icmp ule i32 %local.check.offset.612, %local.check.owner.end.615
  %descriptor.extent.inside.621 = icmp ule i32 %local.check.extent.613, %stack.sub.620
  %descriptor.payload.inside.622 = icmp ule i32 %local.check.payload.614, %local.check.extent.613
  %descriptor.owner.offset.valid.623 = and i1 %descriptor.owner.inside.618, %descriptor.offset.inside.619
  %descriptor.range.inside.625 = and i1 %descriptor.owner.offset.valid.623, %descriptor.extent.inside.621
  %descriptor.range.valid.624 = and i1 %descriptor.range.inside.625, %descriptor.payload.inside.622
  br i1 %descriptor.range.valid.624, label %descriptor.valid.626, label %descriptor.invalid.627
descriptor.invalid.627:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.626:
  %descriptor.initialized.status.628 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.612, i32 %local.check.extent.613)
  %helper.ok.629 = icmp eq i32 %descriptor.initialized.status.628, 0
  br i1 %helper.ok.629, label %helper.continue.630, label %frame.failure.0
helper.continue.630:
  br label %local.descriptor.checked.611
local.descriptor.inactive.610:
  br label %local.descriptor.checked.611
local.descriptor.checked.611:
  %local.is.active.631 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.631, label %local.descriptor.active.632, label %local.descriptor.inactive.633
local.descriptor.active.632:
  %local.check.offset.635 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.636 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.637 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.638 = load i32, ptr %local.owner.end.30, align 4
  %context.field.639 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.640 = load i32, ptr %context.field.639, align 4
  %stack.sub.643 = sub i32 %local.check.owner.end.638, %local.check.offset.635
  %descriptor.owner.inside.641 = icmp ule i32 %local.check.owner.end.638, %context.value.640
  %descriptor.offset.inside.642 = icmp ule i32 %local.check.offset.635, %local.check.owner.end.638
  %descriptor.extent.inside.644 = icmp ule i32 %local.check.extent.636, %stack.sub.643
  %descriptor.payload.inside.645 = icmp ule i32 %local.check.payload.637, %local.check.extent.636
  %descriptor.owner.offset.valid.646 = and i1 %descriptor.owner.inside.641, %descriptor.offset.inside.642
  %descriptor.range.inside.648 = and i1 %descriptor.owner.offset.valid.646, %descriptor.extent.inside.644
  %descriptor.range.valid.647 = and i1 %descriptor.range.inside.648, %descriptor.payload.inside.645
  br i1 %descriptor.range.valid.647, label %descriptor.valid.649, label %descriptor.invalid.650
descriptor.invalid.650:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.649:
  %descriptor.initialized.status.651 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.635, i32 %local.check.extent.636)
  %helper.ok.652 = icmp eq i32 %descriptor.initialized.status.651, 0
  br i1 %helper.ok.652, label %helper.continue.653, label %frame.failure.0
helper.continue.653:
  br label %local.descriptor.checked.634
local.descriptor.inactive.633:
  br label %local.descriptor.checked.634
local.descriptor.checked.634:
  %local.is.active.654 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.654, label %local.descriptor.active.655, label %local.descriptor.inactive.656
local.descriptor.active.655:
  %local.check.offset.658 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.659 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.660 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.661 = load i32, ptr %local.owner.end.36, align 4
  %context.field.662 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.663 = load i32, ptr %context.field.662, align 4
  %stack.sub.666 = sub i32 %local.check.owner.end.661, %local.check.offset.658
  %descriptor.owner.inside.664 = icmp ule i32 %local.check.owner.end.661, %context.value.663
  %descriptor.offset.inside.665 = icmp ule i32 %local.check.offset.658, %local.check.owner.end.661
  %descriptor.extent.inside.667 = icmp ule i32 %local.check.extent.659, %stack.sub.666
  %descriptor.payload.inside.668 = icmp ule i32 %local.check.payload.660, %local.check.extent.659
  %descriptor.owner.offset.valid.669 = and i1 %descriptor.owner.inside.664, %descriptor.offset.inside.665
  %descriptor.range.inside.671 = and i1 %descriptor.owner.offset.valid.669, %descriptor.extent.inside.667
  %descriptor.range.valid.670 = and i1 %descriptor.range.inside.671, %descriptor.payload.inside.668
  br i1 %descriptor.range.valid.670, label %descriptor.valid.672, label %descriptor.invalid.673
descriptor.invalid.673:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.672:
  %descriptor.initialized.status.674 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.658, i32 %local.check.extent.659)
  %helper.ok.675 = icmp eq i32 %descriptor.initialized.status.674, 0
  br i1 %helper.ok.675, label %helper.continue.676, label %frame.failure.0
helper.continue.676:
  br label %local.descriptor.checked.657
local.descriptor.inactive.656:
  br label %local.descriptor.checked.657
local.descriptor.checked.657:
  %local.is.active.677 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.677, label %local.descriptor.active.678, label %local.descriptor.inactive.679
local.descriptor.active.678:
  %local.check.offset.681 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.682 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.683 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.684 = load i32, ptr %local.owner.end.42, align 4
  %context.field.685 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.686 = load i32, ptr %context.field.685, align 4
  %stack.sub.689 = sub i32 %local.check.owner.end.684, %local.check.offset.681
  %descriptor.owner.inside.687 = icmp ule i32 %local.check.owner.end.684, %context.value.686
  %descriptor.offset.inside.688 = icmp ule i32 %local.check.offset.681, %local.check.owner.end.684
  %descriptor.extent.inside.690 = icmp ule i32 %local.check.extent.682, %stack.sub.689
  %descriptor.payload.inside.691 = icmp ule i32 %local.check.payload.683, %local.check.extent.682
  %descriptor.owner.offset.valid.692 = and i1 %descriptor.owner.inside.687, %descriptor.offset.inside.688
  %descriptor.range.inside.694 = and i1 %descriptor.owner.offset.valid.692, %descriptor.extent.inside.690
  %descriptor.range.valid.693 = and i1 %descriptor.range.inside.694, %descriptor.payload.inside.691
  br i1 %descriptor.range.valid.693, label %descriptor.valid.695, label %descriptor.invalid.696
descriptor.invalid.696:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.695:
  %descriptor.initialized.status.697 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.681, i32 %local.check.extent.682)
  %helper.ok.698 = icmp eq i32 %descriptor.initialized.status.697, 0
  br i1 %helper.ok.698, label %helper.continue.699, label %frame.failure.0
helper.continue.699:
  br label %local.descriptor.checked.680
local.descriptor.inactive.679:
  br label %local.descriptor.checked.680
local.descriptor.checked.680:
  %step.status.700 = call i32 @al_owning_charge_step(ptr %ctx, i32 30)
  %helper.ok.701 = icmp eq i32 %step.status.700, 0
  br i1 %helper.ok.701, label %helper.continue.702, label %frame.failure.0
helper.continue.702:
  %local.resolved.offset.703 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.704 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.705 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.706 = load i32, ptr %local.owner.end.6, align 4
  %context.field.707 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.708 = load i32, ptr %context.field.707, align 4
  %stack.sub.711 = sub i32 %local.resolved.owner.end.706, %local.resolved.offset.703
  %descriptor.owner.inside.709 = icmp ule i32 %local.resolved.owner.end.706, %context.value.708
  %descriptor.offset.inside.710 = icmp ule i32 %local.resolved.offset.703, %local.resolved.owner.end.706
  %descriptor.extent.inside.712 = icmp ule i32 %local.resolved.extent.704, %stack.sub.711
  %descriptor.payload.inside.713 = icmp ule i32 %local.resolved.payload.705, %local.resolved.extent.704
  %descriptor.owner.offset.valid.714 = and i1 %descriptor.owner.inside.709, %descriptor.offset.inside.710
  %descriptor.range.inside.716 = and i1 %descriptor.owner.offset.valid.714, %descriptor.extent.inside.712
  %descriptor.range.valid.715 = and i1 %descriptor.range.inside.716, %descriptor.payload.inside.713
  %descriptor.type.valid.717 = icmp eq i32 6, 6
  %descriptor.valid.718 = and i1 %descriptor.range.valid.715, %descriptor.type.valid.717
  br i1 %descriptor.valid.718, label %descriptor.valid.719, label %descriptor.invalid.720
descriptor.invalid.720:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.719:
  %descriptor.initialized.status.721 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.703, i32 %local.resolved.extent.704)
  %helper.ok.722 = icmp eq i32 %descriptor.initialized.status.721, 0
  br i1 %helper.ok.722, label %helper.continue.723, label %frame.failure.0
helper.continue.723:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %local.resolved.offset.703, i32 20, i32 %local.resolved.payload.705, i32 %local.resolved.owner.end.706, i32 %local.resolved.extent.704)
  %context.field.724 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.725 = load i32, ptr %context.field.724, align 4
  %runtime.ok.726 = icmp eq i32 %context.value.725, 0
  br i1 %runtime.ok.726, label %runtime.continue.727, label %frame.failure.0
runtime.continue.727:
  %context.field.728 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.729 = load i32, ptr %context.field.728, align 4
  %stack.sub.732 = sub i32 %local.resolved.owner.end.706, %local.resolved.offset.703
  %descriptor.owner.inside.730 = icmp ule i32 %local.resolved.owner.end.706, %context.value.729
  %descriptor.offset.inside.731 = icmp ule i32 %local.resolved.offset.703, %local.resolved.owner.end.706
  %descriptor.extent.inside.733 = icmp ule i32 %local.resolved.extent.704, %stack.sub.732
  %descriptor.payload.inside.734 = icmp ule i32 %local.resolved.payload.705, %local.resolved.extent.704
  %descriptor.owner.offset.valid.735 = and i1 %descriptor.owner.inside.730, %descriptor.offset.inside.731
  %descriptor.range.inside.737 = and i1 %descriptor.owner.offset.valid.735, %descriptor.extent.inside.733
  %descriptor.range.valid.736 = and i1 %descriptor.range.inside.737, %descriptor.payload.inside.734
  %descriptor.type.valid.738 = icmp eq i32 6, 6
  %descriptor.valid.739 = and i1 %descriptor.range.valid.736, %descriptor.type.valid.738
  br i1 %descriptor.valid.739, label %descriptor.valid.740, label %descriptor.invalid.741
descriptor.invalid.741:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.740:
  %descriptor.initialized.status.742 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.703, i32 %local.resolved.extent.704)
  %helper.ok.743 = icmp eq i32 %descriptor.initialized.status.742, 0
  br i1 %helper.ok.743, label %helper.continue.744, label %frame.failure.0
helper.continue.744:
  %local.is.active.745 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.745, label %local.descriptor.active.746, label %local.descriptor.inactive.747
local.descriptor.active.746:
  %local.check.offset.749 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.750 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.751 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.752 = load i32, ptr %local.owner.end.6, align 4
  %context.field.753 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.754 = load i32, ptr %context.field.753, align 4
  %stack.sub.757 = sub i32 %local.check.owner.end.752, %local.check.offset.749
  %descriptor.owner.inside.755 = icmp ule i32 %local.check.owner.end.752, %context.value.754
  %descriptor.offset.inside.756 = icmp ule i32 %local.check.offset.749, %local.check.owner.end.752
  %descriptor.extent.inside.758 = icmp ule i32 %local.check.extent.750, %stack.sub.757
  %descriptor.payload.inside.759 = icmp ule i32 %local.check.payload.751, %local.check.extent.750
  %descriptor.owner.offset.valid.760 = and i1 %descriptor.owner.inside.755, %descriptor.offset.inside.756
  %descriptor.range.inside.762 = and i1 %descriptor.owner.offset.valid.760, %descriptor.extent.inside.758
  %descriptor.range.valid.761 = and i1 %descriptor.range.inside.762, %descriptor.payload.inside.759
  br i1 %descriptor.range.valid.761, label %descriptor.valid.763, label %descriptor.invalid.764
descriptor.invalid.764:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.763:
  %descriptor.initialized.status.765 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.749, i32 %local.check.extent.750)
  %helper.ok.766 = icmp eq i32 %descriptor.initialized.status.765, 0
  br i1 %helper.ok.766, label %helper.continue.767, label %frame.failure.0
helper.continue.767:
  br label %local.descriptor.checked.748
local.descriptor.inactive.747:
  br label %local.descriptor.checked.748
local.descriptor.checked.748:
  %local.is.active.768 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.768, label %local.descriptor.active.769, label %local.descriptor.inactive.770
local.descriptor.active.769:
  %local.check.offset.772 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.773 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.774 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.775 = load i32, ptr %local.owner.end.12, align 4
  %context.field.776 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.777 = load i32, ptr %context.field.776, align 4
  %stack.sub.780 = sub i32 %local.check.owner.end.775, %local.check.offset.772
  %descriptor.owner.inside.778 = icmp ule i32 %local.check.owner.end.775, %context.value.777
  %descriptor.offset.inside.779 = icmp ule i32 %local.check.offset.772, %local.check.owner.end.775
  %descriptor.extent.inside.781 = icmp ule i32 %local.check.extent.773, %stack.sub.780
  %descriptor.payload.inside.782 = icmp ule i32 %local.check.payload.774, %local.check.extent.773
  %descriptor.owner.offset.valid.783 = and i1 %descriptor.owner.inside.778, %descriptor.offset.inside.779
  %descriptor.range.inside.785 = and i1 %descriptor.owner.offset.valid.783, %descriptor.extent.inside.781
  %descriptor.range.valid.784 = and i1 %descriptor.range.inside.785, %descriptor.payload.inside.782
  br i1 %descriptor.range.valid.784, label %descriptor.valid.786, label %descriptor.invalid.787
descriptor.invalid.787:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.786:
  %descriptor.initialized.status.788 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.772, i32 %local.check.extent.773)
  %helper.ok.789 = icmp eq i32 %descriptor.initialized.status.788, 0
  br i1 %helper.ok.789, label %helper.continue.790, label %frame.failure.0
helper.continue.790:
  br label %local.descriptor.checked.771
local.descriptor.inactive.770:
  br label %local.descriptor.checked.771
local.descriptor.checked.771:
  %local.is.active.791 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.791, label %local.descriptor.active.792, label %local.descriptor.inactive.793
local.descriptor.active.792:
  %local.check.offset.795 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.796 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.797 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.798 = load i32, ptr %local.owner.end.18, align 4
  %context.field.799 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.800 = load i32, ptr %context.field.799, align 4
  %stack.sub.803 = sub i32 %local.check.owner.end.798, %local.check.offset.795
  %descriptor.owner.inside.801 = icmp ule i32 %local.check.owner.end.798, %context.value.800
  %descriptor.offset.inside.802 = icmp ule i32 %local.check.offset.795, %local.check.owner.end.798
  %descriptor.extent.inside.804 = icmp ule i32 %local.check.extent.796, %stack.sub.803
  %descriptor.payload.inside.805 = icmp ule i32 %local.check.payload.797, %local.check.extent.796
  %descriptor.owner.offset.valid.806 = and i1 %descriptor.owner.inside.801, %descriptor.offset.inside.802
  %descriptor.range.inside.808 = and i1 %descriptor.owner.offset.valid.806, %descriptor.extent.inside.804
  %descriptor.range.valid.807 = and i1 %descriptor.range.inside.808, %descriptor.payload.inside.805
  br i1 %descriptor.range.valid.807, label %descriptor.valid.809, label %descriptor.invalid.810
descriptor.invalid.810:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.809:
  %descriptor.initialized.status.811 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.795, i32 %local.check.extent.796)
  %helper.ok.812 = icmp eq i32 %descriptor.initialized.status.811, 0
  br i1 %helper.ok.812, label %helper.continue.813, label %frame.failure.0
helper.continue.813:
  br label %local.descriptor.checked.794
local.descriptor.inactive.793:
  br label %local.descriptor.checked.794
local.descriptor.checked.794:
  %local.is.active.814 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.814, label %local.descriptor.active.815, label %local.descriptor.inactive.816
local.descriptor.active.815:
  %local.check.offset.818 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.819 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.820 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.821 = load i32, ptr %local.owner.end.24, align 4
  %context.field.822 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.823 = load i32, ptr %context.field.822, align 4
  %stack.sub.826 = sub i32 %local.check.owner.end.821, %local.check.offset.818
  %descriptor.owner.inside.824 = icmp ule i32 %local.check.owner.end.821, %context.value.823
  %descriptor.offset.inside.825 = icmp ule i32 %local.check.offset.818, %local.check.owner.end.821
  %descriptor.extent.inside.827 = icmp ule i32 %local.check.extent.819, %stack.sub.826
  %descriptor.payload.inside.828 = icmp ule i32 %local.check.payload.820, %local.check.extent.819
  %descriptor.owner.offset.valid.829 = and i1 %descriptor.owner.inside.824, %descriptor.offset.inside.825
  %descriptor.range.inside.831 = and i1 %descriptor.owner.offset.valid.829, %descriptor.extent.inside.827
  %descriptor.range.valid.830 = and i1 %descriptor.range.inside.831, %descriptor.payload.inside.828
  br i1 %descriptor.range.valid.830, label %descriptor.valid.832, label %descriptor.invalid.833
descriptor.invalid.833:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.832:
  %descriptor.initialized.status.834 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.818, i32 %local.check.extent.819)
  %helper.ok.835 = icmp eq i32 %descriptor.initialized.status.834, 0
  br i1 %helper.ok.835, label %helper.continue.836, label %frame.failure.0
helper.continue.836:
  br label %local.descriptor.checked.817
local.descriptor.inactive.816:
  br label %local.descriptor.checked.817
local.descriptor.checked.817:
  %local.is.active.837 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.837, label %local.descriptor.active.838, label %local.descriptor.inactive.839
local.descriptor.active.838:
  %local.check.offset.841 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.842 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.843 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.844 = load i32, ptr %local.owner.end.30, align 4
  %context.field.845 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.846 = load i32, ptr %context.field.845, align 4
  %stack.sub.849 = sub i32 %local.check.owner.end.844, %local.check.offset.841
  %descriptor.owner.inside.847 = icmp ule i32 %local.check.owner.end.844, %context.value.846
  %descriptor.offset.inside.848 = icmp ule i32 %local.check.offset.841, %local.check.owner.end.844
  %descriptor.extent.inside.850 = icmp ule i32 %local.check.extent.842, %stack.sub.849
  %descriptor.payload.inside.851 = icmp ule i32 %local.check.payload.843, %local.check.extent.842
  %descriptor.owner.offset.valid.852 = and i1 %descriptor.owner.inside.847, %descriptor.offset.inside.848
  %descriptor.range.inside.854 = and i1 %descriptor.owner.offset.valid.852, %descriptor.extent.inside.850
  %descriptor.range.valid.853 = and i1 %descriptor.range.inside.854, %descriptor.payload.inside.851
  br i1 %descriptor.range.valid.853, label %descriptor.valid.855, label %descriptor.invalid.856
descriptor.invalid.856:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.855:
  %descriptor.initialized.status.857 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.841, i32 %local.check.extent.842)
  %helper.ok.858 = icmp eq i32 %descriptor.initialized.status.857, 0
  br i1 %helper.ok.858, label %helper.continue.859, label %frame.failure.0
helper.continue.859:
  br label %local.descriptor.checked.840
local.descriptor.inactive.839:
  br label %local.descriptor.checked.840
local.descriptor.checked.840:
  %local.is.active.860 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.860, label %local.descriptor.active.861, label %local.descriptor.inactive.862
local.descriptor.active.861:
  %local.check.offset.864 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.865 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.866 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.867 = load i32, ptr %local.owner.end.36, align 4
  %context.field.868 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.869 = load i32, ptr %context.field.868, align 4
  %stack.sub.872 = sub i32 %local.check.owner.end.867, %local.check.offset.864
  %descriptor.owner.inside.870 = icmp ule i32 %local.check.owner.end.867, %context.value.869
  %descriptor.offset.inside.871 = icmp ule i32 %local.check.offset.864, %local.check.owner.end.867
  %descriptor.extent.inside.873 = icmp ule i32 %local.check.extent.865, %stack.sub.872
  %descriptor.payload.inside.874 = icmp ule i32 %local.check.payload.866, %local.check.extent.865
  %descriptor.owner.offset.valid.875 = and i1 %descriptor.owner.inside.870, %descriptor.offset.inside.871
  %descriptor.range.inside.877 = and i1 %descriptor.owner.offset.valid.875, %descriptor.extent.inside.873
  %descriptor.range.valid.876 = and i1 %descriptor.range.inside.877, %descriptor.payload.inside.874
  br i1 %descriptor.range.valid.876, label %descriptor.valid.878, label %descriptor.invalid.879
descriptor.invalid.879:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.878:
  %descriptor.initialized.status.880 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.864, i32 %local.check.extent.865)
  %helper.ok.881 = icmp eq i32 %descriptor.initialized.status.880, 0
  br i1 %helper.ok.881, label %helper.continue.882, label %frame.failure.0
helper.continue.882:
  br label %local.descriptor.checked.863
local.descriptor.inactive.862:
  br label %local.descriptor.checked.863
local.descriptor.checked.863:
  %local.is.active.883 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.883, label %local.descriptor.active.884, label %local.descriptor.inactive.885
local.descriptor.active.884:
  %local.check.offset.887 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.888 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.889 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.890 = load i32, ptr %local.owner.end.42, align 4
  %context.field.891 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.892 = load i32, ptr %context.field.891, align 4
  %stack.sub.895 = sub i32 %local.check.owner.end.890, %local.check.offset.887
  %descriptor.owner.inside.893 = icmp ule i32 %local.check.owner.end.890, %context.value.892
  %descriptor.offset.inside.894 = icmp ule i32 %local.check.offset.887, %local.check.owner.end.890
  %descriptor.extent.inside.896 = icmp ule i32 %local.check.extent.888, %stack.sub.895
  %descriptor.payload.inside.897 = icmp ule i32 %local.check.payload.889, %local.check.extent.888
  %descriptor.owner.offset.valid.898 = and i1 %descriptor.owner.inside.893, %descriptor.offset.inside.894
  %descriptor.range.inside.900 = and i1 %descriptor.owner.offset.valid.898, %descriptor.extent.inside.896
  %descriptor.range.valid.899 = and i1 %descriptor.range.inside.900, %descriptor.payload.inside.897
  br i1 %descriptor.range.valid.899, label %descriptor.valid.901, label %descriptor.invalid.902
descriptor.invalid.902:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.901:
  %descriptor.initialized.status.903 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.887, i32 %local.check.extent.888)
  %helper.ok.904 = icmp eq i32 %descriptor.initialized.status.903, 0
  br i1 %helper.ok.904, label %helper.continue.905, label %frame.failure.0
helper.continue.905:
  br label %local.descriptor.checked.886
local.descriptor.inactive.885:
  br label %local.descriptor.checked.886
local.descriptor.checked.886:
  %step.status.906 = call i32 @al_owning_charge_step(ptr %ctx, i32 31)
  %helper.ok.907 = icmp eq i32 %step.status.906, 0
  br i1 %helper.ok.907, label %helper.continue.908, label %frame.failure.0
helper.continue.908:
  %context.field.909 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.910 = load i32, ptr %context.field.909, align 4
  %stack.offset.911 = add i32 %context.value.910, 16
  %reserve.status.912 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.911, i32 32)
  %reserve.ok.913 = icmp eq i32 %reserve.status.912, 0
  br i1 %reserve.ok.913, label %reserve.continue.914, label %frame.failure.0
reserve.continue.914:
  %literal.status.915 = call i32 @al_owning_copy_constant(ptr %ctx, i32 %context.value.910, ptr getelementptr inbounds ([16 x i8], ptr @al_owning_string_literal_0, i64 0, i64 0), i32 16, i32 16, i32 16, i32 6, i32 33)
  %helper.ok.916 = icmp eq i32 %literal.status.915, 0
  br i1 %helper.ok.916, label %helper.continue.917, label %frame.failure.0
helper.continue.917:
  %context.field.918 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.919 = load i32, ptr %context.field.918, align 4
  %stack.sub.922 = sub i32 %local.resolved.owner.end.706, %local.resolved.offset.703
  %descriptor.owner.inside.920 = icmp ule i32 %local.resolved.owner.end.706, %context.value.919
  %descriptor.offset.inside.921 = icmp ule i32 %local.resolved.offset.703, %local.resolved.owner.end.706
  %descriptor.extent.inside.923 = icmp ule i32 %local.resolved.extent.704, %stack.sub.922
  %descriptor.payload.inside.924 = icmp ule i32 %local.resolved.payload.705, %local.resolved.extent.704
  %descriptor.owner.offset.valid.925 = and i1 %descriptor.owner.inside.920, %descriptor.offset.inside.921
  %descriptor.range.inside.927 = and i1 %descriptor.owner.offset.valid.925, %descriptor.extent.inside.923
  %descriptor.range.valid.926 = and i1 %descriptor.range.inside.927, %descriptor.payload.inside.924
  %descriptor.type.valid.928 = icmp eq i32 6, 6
  %descriptor.valid.929 = and i1 %descriptor.range.valid.926, %descriptor.type.valid.928
  br i1 %descriptor.valid.929, label %descriptor.valid.930, label %descriptor.invalid.931
descriptor.invalid.931:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.930:
  %descriptor.initialized.status.932 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.703, i32 %local.resolved.extent.704)
  %helper.ok.933 = icmp eq i32 %descriptor.initialized.status.932, 0
  br i1 %helper.ok.933, label %helper.continue.934, label %frame.failure.0
helper.continue.934:
  %context.field.935 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.936 = load i32, ptr %context.field.935, align 4
  %stack.sub.939 = sub i32 %stack.offset.911, %context.value.910
  %descriptor.owner.inside.937 = icmp ule i32 %stack.offset.911, %context.value.936
  %descriptor.offset.inside.938 = icmp ule i32 %context.value.910, %stack.offset.911
  %descriptor.extent.inside.940 = icmp ule i32 16, %stack.sub.939
  %descriptor.payload.inside.941 = icmp ule i32 16, 16
  %descriptor.owner.offset.valid.942 = and i1 %descriptor.owner.inside.937, %descriptor.offset.inside.938
  %descriptor.range.inside.944 = and i1 %descriptor.owner.offset.valid.942, %descriptor.extent.inside.940
  %descriptor.range.valid.943 = and i1 %descriptor.range.inside.944, %descriptor.payload.inside.941
  %descriptor.type.valid.945 = icmp eq i32 6, 6
  %descriptor.valid.946 = and i1 %descriptor.range.valid.943, %descriptor.type.valid.945
  br i1 %descriptor.valid.946, label %descriptor.valid.947, label %descriptor.invalid.948
descriptor.invalid.948:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.947:
  %descriptor.initialized.status.949 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.910, i32 16)
  %helper.ok.950 = icmp eq i32 %descriptor.initialized.status.949, 0
  br i1 %helper.ok.950, label %helper.continue.951, label %frame.failure.0
helper.continue.951:
  %local.is.active.952 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.952, label %local.descriptor.active.953, label %local.descriptor.inactive.954
local.descriptor.active.953:
  %local.check.offset.956 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.957 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.958 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.959 = load i32, ptr %local.owner.end.6, align 4
  %context.field.960 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.961 = load i32, ptr %context.field.960, align 4
  %stack.sub.964 = sub i32 %local.check.owner.end.959, %local.check.offset.956
  %descriptor.owner.inside.962 = icmp ule i32 %local.check.owner.end.959, %context.value.961
  %descriptor.offset.inside.963 = icmp ule i32 %local.check.offset.956, %local.check.owner.end.959
  %descriptor.extent.inside.965 = icmp ule i32 %local.check.extent.957, %stack.sub.964
  %descriptor.payload.inside.966 = icmp ule i32 %local.check.payload.958, %local.check.extent.957
  %descriptor.owner.offset.valid.967 = and i1 %descriptor.owner.inside.962, %descriptor.offset.inside.963
  %descriptor.range.inside.969 = and i1 %descriptor.owner.offset.valid.967, %descriptor.extent.inside.965
  %descriptor.range.valid.968 = and i1 %descriptor.range.inside.969, %descriptor.payload.inside.966
  br i1 %descriptor.range.valid.968, label %descriptor.valid.970, label %descriptor.invalid.971
descriptor.invalid.971:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.970:
  %descriptor.initialized.status.972 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.956, i32 %local.check.extent.957)
  %helper.ok.973 = icmp eq i32 %descriptor.initialized.status.972, 0
  br i1 %helper.ok.973, label %helper.continue.974, label %frame.failure.0
helper.continue.974:
  br label %local.descriptor.checked.955
local.descriptor.inactive.954:
  br label %local.descriptor.checked.955
local.descriptor.checked.955:
  %local.is.active.975 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.975, label %local.descriptor.active.976, label %local.descriptor.inactive.977
local.descriptor.active.976:
  %local.check.offset.979 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.980 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.981 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.982 = load i32, ptr %local.owner.end.12, align 4
  %context.field.983 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.984 = load i32, ptr %context.field.983, align 4
  %stack.sub.987 = sub i32 %local.check.owner.end.982, %local.check.offset.979
  %descriptor.owner.inside.985 = icmp ule i32 %local.check.owner.end.982, %context.value.984
  %descriptor.offset.inside.986 = icmp ule i32 %local.check.offset.979, %local.check.owner.end.982
  %descriptor.extent.inside.988 = icmp ule i32 %local.check.extent.980, %stack.sub.987
  %descriptor.payload.inside.989 = icmp ule i32 %local.check.payload.981, %local.check.extent.980
  %descriptor.owner.offset.valid.990 = and i1 %descriptor.owner.inside.985, %descriptor.offset.inside.986
  %descriptor.range.inside.992 = and i1 %descriptor.owner.offset.valid.990, %descriptor.extent.inside.988
  %descriptor.range.valid.991 = and i1 %descriptor.range.inside.992, %descriptor.payload.inside.989
  br i1 %descriptor.range.valid.991, label %descriptor.valid.993, label %descriptor.invalid.994
descriptor.invalid.994:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.993:
  %descriptor.initialized.status.995 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.979, i32 %local.check.extent.980)
  %helper.ok.996 = icmp eq i32 %descriptor.initialized.status.995, 0
  br i1 %helper.ok.996, label %helper.continue.997, label %frame.failure.0
helper.continue.997:
  br label %local.descriptor.checked.978
local.descriptor.inactive.977:
  br label %local.descriptor.checked.978
local.descriptor.checked.978:
  %local.is.active.998 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.998, label %local.descriptor.active.999, label %local.descriptor.inactive.1000
local.descriptor.active.999:
  %local.check.offset.1002 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1003 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1004 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1005 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1006 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1007 = load i32, ptr %context.field.1006, align 4
  %stack.sub.1010 = sub i32 %local.check.owner.end.1005, %local.check.offset.1002
  %descriptor.owner.inside.1008 = icmp ule i32 %local.check.owner.end.1005, %context.value.1007
  %descriptor.offset.inside.1009 = icmp ule i32 %local.check.offset.1002, %local.check.owner.end.1005
  %descriptor.extent.inside.1011 = icmp ule i32 %local.check.extent.1003, %stack.sub.1010
  %descriptor.payload.inside.1012 = icmp ule i32 %local.check.payload.1004, %local.check.extent.1003
  %descriptor.owner.offset.valid.1013 = and i1 %descriptor.owner.inside.1008, %descriptor.offset.inside.1009
  %descriptor.range.inside.1015 = and i1 %descriptor.owner.offset.valid.1013, %descriptor.extent.inside.1011
  %descriptor.range.valid.1014 = and i1 %descriptor.range.inside.1015, %descriptor.payload.inside.1012
  br i1 %descriptor.range.valid.1014, label %descriptor.valid.1016, label %descriptor.invalid.1017
descriptor.invalid.1017:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1016:
  %descriptor.initialized.status.1018 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1002, i32 %local.check.extent.1003)
  %helper.ok.1019 = icmp eq i32 %descriptor.initialized.status.1018, 0
  br i1 %helper.ok.1019, label %helper.continue.1020, label %frame.failure.0
helper.continue.1020:
  br label %local.descriptor.checked.1001
local.descriptor.inactive.1000:
  br label %local.descriptor.checked.1001
local.descriptor.checked.1001:
  %local.is.active.1021 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1021, label %local.descriptor.active.1022, label %local.descriptor.inactive.1023
local.descriptor.active.1022:
  %local.check.offset.1025 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1026 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1027 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1028 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1029 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1030 = load i32, ptr %context.field.1029, align 4
  %stack.sub.1033 = sub i32 %local.check.owner.end.1028, %local.check.offset.1025
  %descriptor.owner.inside.1031 = icmp ule i32 %local.check.owner.end.1028, %context.value.1030
  %descriptor.offset.inside.1032 = icmp ule i32 %local.check.offset.1025, %local.check.owner.end.1028
  %descriptor.extent.inside.1034 = icmp ule i32 %local.check.extent.1026, %stack.sub.1033
  %descriptor.payload.inside.1035 = icmp ule i32 %local.check.payload.1027, %local.check.extent.1026
  %descriptor.owner.offset.valid.1036 = and i1 %descriptor.owner.inside.1031, %descriptor.offset.inside.1032
  %descriptor.range.inside.1038 = and i1 %descriptor.owner.offset.valid.1036, %descriptor.extent.inside.1034
  %descriptor.range.valid.1037 = and i1 %descriptor.range.inside.1038, %descriptor.payload.inside.1035
  br i1 %descriptor.range.valid.1037, label %descriptor.valid.1039, label %descriptor.invalid.1040
descriptor.invalid.1040:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1039:
  %descriptor.initialized.status.1041 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1025, i32 %local.check.extent.1026)
  %helper.ok.1042 = icmp eq i32 %descriptor.initialized.status.1041, 0
  br i1 %helper.ok.1042, label %helper.continue.1043, label %frame.failure.0
helper.continue.1043:
  br label %local.descriptor.checked.1024
local.descriptor.inactive.1023:
  br label %local.descriptor.checked.1024
local.descriptor.checked.1024:
  %local.is.active.1044 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1044, label %local.descriptor.active.1045, label %local.descriptor.inactive.1046
local.descriptor.active.1045:
  %local.check.offset.1048 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1049 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1050 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1051 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1052 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1053 = load i32, ptr %context.field.1052, align 4
  %stack.sub.1056 = sub i32 %local.check.owner.end.1051, %local.check.offset.1048
  %descriptor.owner.inside.1054 = icmp ule i32 %local.check.owner.end.1051, %context.value.1053
  %descriptor.offset.inside.1055 = icmp ule i32 %local.check.offset.1048, %local.check.owner.end.1051
  %descriptor.extent.inside.1057 = icmp ule i32 %local.check.extent.1049, %stack.sub.1056
  %descriptor.payload.inside.1058 = icmp ule i32 %local.check.payload.1050, %local.check.extent.1049
  %descriptor.owner.offset.valid.1059 = and i1 %descriptor.owner.inside.1054, %descriptor.offset.inside.1055
  %descriptor.range.inside.1061 = and i1 %descriptor.owner.offset.valid.1059, %descriptor.extent.inside.1057
  %descriptor.range.valid.1060 = and i1 %descriptor.range.inside.1061, %descriptor.payload.inside.1058
  br i1 %descriptor.range.valid.1060, label %descriptor.valid.1062, label %descriptor.invalid.1063
descriptor.invalid.1063:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1062:
  %descriptor.initialized.status.1064 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1048, i32 %local.check.extent.1049)
  %helper.ok.1065 = icmp eq i32 %descriptor.initialized.status.1064, 0
  br i1 %helper.ok.1065, label %helper.continue.1066, label %frame.failure.0
helper.continue.1066:
  br label %local.descriptor.checked.1047
local.descriptor.inactive.1046:
  br label %local.descriptor.checked.1047
local.descriptor.checked.1047:
  %local.is.active.1067 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1067, label %local.descriptor.active.1068, label %local.descriptor.inactive.1069
local.descriptor.active.1068:
  %local.check.offset.1071 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1072 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1073 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1074 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1075 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1076 = load i32, ptr %context.field.1075, align 4
  %stack.sub.1079 = sub i32 %local.check.owner.end.1074, %local.check.offset.1071
  %descriptor.owner.inside.1077 = icmp ule i32 %local.check.owner.end.1074, %context.value.1076
  %descriptor.offset.inside.1078 = icmp ule i32 %local.check.offset.1071, %local.check.owner.end.1074
  %descriptor.extent.inside.1080 = icmp ule i32 %local.check.extent.1072, %stack.sub.1079
  %descriptor.payload.inside.1081 = icmp ule i32 %local.check.payload.1073, %local.check.extent.1072
  %descriptor.owner.offset.valid.1082 = and i1 %descriptor.owner.inside.1077, %descriptor.offset.inside.1078
  %descriptor.range.inside.1084 = and i1 %descriptor.owner.offset.valid.1082, %descriptor.extent.inside.1080
  %descriptor.range.valid.1083 = and i1 %descriptor.range.inside.1084, %descriptor.payload.inside.1081
  br i1 %descriptor.range.valid.1083, label %descriptor.valid.1085, label %descriptor.invalid.1086
descriptor.invalid.1086:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1085:
  %descriptor.initialized.status.1087 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1071, i32 %local.check.extent.1072)
  %helper.ok.1088 = icmp eq i32 %descriptor.initialized.status.1087, 0
  br i1 %helper.ok.1088, label %helper.continue.1089, label %frame.failure.0
helper.continue.1089:
  br label %local.descriptor.checked.1070
local.descriptor.inactive.1069:
  br label %local.descriptor.checked.1070
local.descriptor.checked.1070:
  %local.is.active.1090 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.1090, label %local.descriptor.active.1091, label %local.descriptor.inactive.1092
local.descriptor.active.1091:
  %local.check.offset.1094 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.1095 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.1096 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.1097 = load i32, ptr %local.owner.end.42, align 4
  %context.field.1098 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1099 = load i32, ptr %context.field.1098, align 4
  %stack.sub.1102 = sub i32 %local.check.owner.end.1097, %local.check.offset.1094
  %descriptor.owner.inside.1100 = icmp ule i32 %local.check.owner.end.1097, %context.value.1099
  %descriptor.offset.inside.1101 = icmp ule i32 %local.check.offset.1094, %local.check.owner.end.1097
  %descriptor.extent.inside.1103 = icmp ule i32 %local.check.extent.1095, %stack.sub.1102
  %descriptor.payload.inside.1104 = icmp ule i32 %local.check.payload.1096, %local.check.extent.1095
  %descriptor.owner.offset.valid.1105 = and i1 %descriptor.owner.inside.1100, %descriptor.offset.inside.1101
  %descriptor.range.inside.1107 = and i1 %descriptor.owner.offset.valid.1105, %descriptor.extent.inside.1103
  %descriptor.range.valid.1106 = and i1 %descriptor.range.inside.1107, %descriptor.payload.inside.1104
  br i1 %descriptor.range.valid.1106, label %descriptor.valid.1108, label %descriptor.invalid.1109
descriptor.invalid.1109:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1108:
  %descriptor.initialized.status.1110 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1094, i32 %local.check.extent.1095)
  %helper.ok.1111 = icmp eq i32 %descriptor.initialized.status.1110, 0
  br i1 %helper.ok.1111, label %helper.continue.1112, label %frame.failure.0
helper.continue.1112:
  br label %local.descriptor.checked.1093
local.descriptor.inactive.1092:
  br label %local.descriptor.checked.1093
local.descriptor.checked.1093:
  %step.status.1113 = call i32 @al_owning_charge_step(ptr %ctx, i32 34)
  %helper.ok.1114 = icmp eq i32 %step.status.1113, 0
  br i1 %helper.ok.1114, label %helper.continue.1115, label %frame.failure.0
helper.continue.1115:
  %context.field.1116 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.1117 = load i32, ptr %context.field.1116, align 4
  %inline.target.depth.within.interpreter.limit.1118 = icmp ule i32 %context.value.1117, 65
  br i1 %inline.target.depth.within.interpreter.limit.1118, label %inline.target.depth.ok.1119, label %inline.target.depth.invalid.1120
inline.target.depth.invalid.1120:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 35, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.1119:
  %equals.result.1121 = call i32 @al_owning_equal_typed(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 4, i32 %local.resolved.offset.703, i32 %local.resolved.extent.704, i32 %context.value.910, i32 16, i32 36)
  %context.field.1122 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1123 = load i32, ptr %context.field.1122, align 4
  %runtime.ok.1124 = icmp eq i32 %context.value.1123, 0
  br i1 %runtime.ok.1124, label %runtime.continue.1125, label %frame.failure.0
runtime.continue.1125:
  %equals.bool.1126 = icmp ne i32 %equals.result.1121, 0
  %equals.i64.1127 = zext i1 %equals.bool.1126 to i64
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 6, i32 %context.value.910, i32 16, i32 16, i32 0, i32 0)
  %context.field.1128 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1129 = load i32, ptr %context.field.1128, align 4
  %runtime.ok.1130 = icmp eq i32 %context.value.1129, 0
  br i1 %runtime.ok.1130, label %runtime.continue.1131, label %frame.failure.0
runtime.continue.1131:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 6, i32 %local.resolved.offset.703, i32 %local.resolved.extent.704, i32 %local.resolved.payload.705, i32 0, i32 0)
  %context.field.1132 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1133 = load i32, ptr %context.field.1132, align 4
  %runtime.ok.1134 = icmp eq i32 %context.value.1133, 0
  br i1 %runtime.ok.1134, label %runtime.continue.1135, label %frame.failure.0
runtime.continue.1135:
  %context.field.1136 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1137 = load i32, ptr %context.field.1136, align 4
  %stack.offset.1138 = add i32 %context.value.1137, 8
  %reserve.status.1139 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1138, i32 37)
  %reserve.ok.1140 = icmp eq i32 %reserve.status.1139, 0
  br i1 %reserve.ok.1140, label %reserve.continue.1141, label %frame.failure.0
reserve.continue.1141:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.1137, i64 %equals.i64.1127, i32 2)
  %context.field.1142 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1143 = load i32, ptr %context.field.1142, align 4
  %runtime.ok.1144 = icmp eq i32 %context.value.1143, 0
  br i1 %runtime.ok.1144, label %runtime.continue.1145, label %frame.failure.0
runtime.continue.1145:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.1146 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1147 = load i32, ptr %context.field.1146, align 4
  %runtime.ok.1148 = icmp eq i32 %context.value.1147, 0
  br i1 %runtime.ok.1148, label %runtime.continue.1149, label %frame.failure.0
runtime.continue.1149:
  %stack.offset.1150 = add i32 %context.value.1137, 8
  %context.field.1151 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1152 = load i32, ptr %context.field.1151, align 4
  %stack.sub.1155 = sub i32 %stack.offset.1150, %context.value.1137
  %descriptor.owner.inside.1153 = icmp ule i32 %stack.offset.1150, %context.value.1152
  %descriptor.offset.inside.1154 = icmp ule i32 %context.value.1137, %stack.offset.1150
  %descriptor.extent.inside.1156 = icmp ule i32 8, %stack.sub.1155
  %descriptor.payload.inside.1157 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.1158 = and i1 %descriptor.owner.inside.1153, %descriptor.offset.inside.1154
  %descriptor.range.inside.1160 = and i1 %descriptor.owner.offset.valid.1158, %descriptor.extent.inside.1156
  %descriptor.range.valid.1159 = and i1 %descriptor.range.inside.1160, %descriptor.payload.inside.1157
  %descriptor.type.valid.1161 = icmp eq i32 2, 2
  %descriptor.valid.1162 = and i1 %descriptor.range.valid.1159, %descriptor.type.valid.1161
  br i1 %descriptor.valid.1162, label %descriptor.valid.1163, label %descriptor.invalid.1164
descriptor.invalid.1164:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1163:
  %descriptor.initialized.status.1165 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.1137, i32 8)
  %helper.ok.1166 = icmp eq i32 %descriptor.initialized.status.1165, 0
  br i1 %helper.ok.1166, label %helper.continue.1167, label %frame.failure.0
helper.continue.1167:
  %local.is.active.1168 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1168, label %local.descriptor.active.1169, label %local.descriptor.inactive.1170
local.descriptor.active.1169:
  %local.check.offset.1172 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1173 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1174 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1175 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1176 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1177 = load i32, ptr %context.field.1176, align 4
  %stack.sub.1180 = sub i32 %local.check.owner.end.1175, %local.check.offset.1172
  %descriptor.owner.inside.1178 = icmp ule i32 %local.check.owner.end.1175, %context.value.1177
  %descriptor.offset.inside.1179 = icmp ule i32 %local.check.offset.1172, %local.check.owner.end.1175
  %descriptor.extent.inside.1181 = icmp ule i32 %local.check.extent.1173, %stack.sub.1180
  %descriptor.payload.inside.1182 = icmp ule i32 %local.check.payload.1174, %local.check.extent.1173
  %descriptor.owner.offset.valid.1183 = and i1 %descriptor.owner.inside.1178, %descriptor.offset.inside.1179
  %descriptor.range.inside.1185 = and i1 %descriptor.owner.offset.valid.1183, %descriptor.extent.inside.1181
  %descriptor.range.valid.1184 = and i1 %descriptor.range.inside.1185, %descriptor.payload.inside.1182
  br i1 %descriptor.range.valid.1184, label %descriptor.valid.1186, label %descriptor.invalid.1187
descriptor.invalid.1187:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1186:
  %descriptor.initialized.status.1188 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1172, i32 %local.check.extent.1173)
  %helper.ok.1189 = icmp eq i32 %descriptor.initialized.status.1188, 0
  br i1 %helper.ok.1189, label %helper.continue.1190, label %frame.failure.0
helper.continue.1190:
  br label %local.descriptor.checked.1171
local.descriptor.inactive.1170:
  br label %local.descriptor.checked.1171
local.descriptor.checked.1171:
  %local.is.active.1191 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1191, label %local.descriptor.active.1192, label %local.descriptor.inactive.1193
local.descriptor.active.1192:
  %local.check.offset.1195 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1196 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1197 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1198 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1199 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1200 = load i32, ptr %context.field.1199, align 4
  %stack.sub.1203 = sub i32 %local.check.owner.end.1198, %local.check.offset.1195
  %descriptor.owner.inside.1201 = icmp ule i32 %local.check.owner.end.1198, %context.value.1200
  %descriptor.offset.inside.1202 = icmp ule i32 %local.check.offset.1195, %local.check.owner.end.1198
  %descriptor.extent.inside.1204 = icmp ule i32 %local.check.extent.1196, %stack.sub.1203
  %descriptor.payload.inside.1205 = icmp ule i32 %local.check.payload.1197, %local.check.extent.1196
  %descriptor.owner.offset.valid.1206 = and i1 %descriptor.owner.inside.1201, %descriptor.offset.inside.1202
  %descriptor.range.inside.1208 = and i1 %descriptor.owner.offset.valid.1206, %descriptor.extent.inside.1204
  %descriptor.range.valid.1207 = and i1 %descriptor.range.inside.1208, %descriptor.payload.inside.1205
  br i1 %descriptor.range.valid.1207, label %descriptor.valid.1209, label %descriptor.invalid.1210
descriptor.invalid.1210:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1209:
  %descriptor.initialized.status.1211 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1195, i32 %local.check.extent.1196)
  %helper.ok.1212 = icmp eq i32 %descriptor.initialized.status.1211, 0
  br i1 %helper.ok.1212, label %helper.continue.1213, label %frame.failure.0
helper.continue.1213:
  br label %local.descriptor.checked.1194
local.descriptor.inactive.1193:
  br label %local.descriptor.checked.1194
local.descriptor.checked.1194:
  %local.is.active.1214 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1214, label %local.descriptor.active.1215, label %local.descriptor.inactive.1216
local.descriptor.active.1215:
  %local.check.offset.1218 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1219 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1220 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1221 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1222 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1223 = load i32, ptr %context.field.1222, align 4
  %stack.sub.1226 = sub i32 %local.check.owner.end.1221, %local.check.offset.1218
  %descriptor.owner.inside.1224 = icmp ule i32 %local.check.owner.end.1221, %context.value.1223
  %descriptor.offset.inside.1225 = icmp ule i32 %local.check.offset.1218, %local.check.owner.end.1221
  %descriptor.extent.inside.1227 = icmp ule i32 %local.check.extent.1219, %stack.sub.1226
  %descriptor.payload.inside.1228 = icmp ule i32 %local.check.payload.1220, %local.check.extent.1219
  %descriptor.owner.offset.valid.1229 = and i1 %descriptor.owner.inside.1224, %descriptor.offset.inside.1225
  %descriptor.range.inside.1231 = and i1 %descriptor.owner.offset.valid.1229, %descriptor.extent.inside.1227
  %descriptor.range.valid.1230 = and i1 %descriptor.range.inside.1231, %descriptor.payload.inside.1228
  br i1 %descriptor.range.valid.1230, label %descriptor.valid.1232, label %descriptor.invalid.1233
descriptor.invalid.1233:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1232:
  %descriptor.initialized.status.1234 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1218, i32 %local.check.extent.1219)
  %helper.ok.1235 = icmp eq i32 %descriptor.initialized.status.1234, 0
  br i1 %helper.ok.1235, label %helper.continue.1236, label %frame.failure.0
helper.continue.1236:
  br label %local.descriptor.checked.1217
local.descriptor.inactive.1216:
  br label %local.descriptor.checked.1217
local.descriptor.checked.1217:
  %local.is.active.1237 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1237, label %local.descriptor.active.1238, label %local.descriptor.inactive.1239
local.descriptor.active.1238:
  %local.check.offset.1241 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1242 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1243 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1244 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1245 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1246 = load i32, ptr %context.field.1245, align 4
  %stack.sub.1249 = sub i32 %local.check.owner.end.1244, %local.check.offset.1241
  %descriptor.owner.inside.1247 = icmp ule i32 %local.check.owner.end.1244, %context.value.1246
  %descriptor.offset.inside.1248 = icmp ule i32 %local.check.offset.1241, %local.check.owner.end.1244
  %descriptor.extent.inside.1250 = icmp ule i32 %local.check.extent.1242, %stack.sub.1249
  %descriptor.payload.inside.1251 = icmp ule i32 %local.check.payload.1243, %local.check.extent.1242
  %descriptor.owner.offset.valid.1252 = and i1 %descriptor.owner.inside.1247, %descriptor.offset.inside.1248
  %descriptor.range.inside.1254 = and i1 %descriptor.owner.offset.valid.1252, %descriptor.extent.inside.1250
  %descriptor.range.valid.1253 = and i1 %descriptor.range.inside.1254, %descriptor.payload.inside.1251
  br i1 %descriptor.range.valid.1253, label %descriptor.valid.1255, label %descriptor.invalid.1256
descriptor.invalid.1256:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1255:
  %descriptor.initialized.status.1257 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1241, i32 %local.check.extent.1242)
  %helper.ok.1258 = icmp eq i32 %descriptor.initialized.status.1257, 0
  br i1 %helper.ok.1258, label %helper.continue.1259, label %frame.failure.0
helper.continue.1259:
  br label %local.descriptor.checked.1240
local.descriptor.inactive.1239:
  br label %local.descriptor.checked.1240
local.descriptor.checked.1240:
  %local.is.active.1260 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1260, label %local.descriptor.active.1261, label %local.descriptor.inactive.1262
local.descriptor.active.1261:
  %local.check.offset.1264 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1265 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1266 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1267 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1268 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1269 = load i32, ptr %context.field.1268, align 4
  %stack.sub.1272 = sub i32 %local.check.owner.end.1267, %local.check.offset.1264
  %descriptor.owner.inside.1270 = icmp ule i32 %local.check.owner.end.1267, %context.value.1269
  %descriptor.offset.inside.1271 = icmp ule i32 %local.check.offset.1264, %local.check.owner.end.1267
  %descriptor.extent.inside.1273 = icmp ule i32 %local.check.extent.1265, %stack.sub.1272
  %descriptor.payload.inside.1274 = icmp ule i32 %local.check.payload.1266, %local.check.extent.1265
  %descriptor.owner.offset.valid.1275 = and i1 %descriptor.owner.inside.1270, %descriptor.offset.inside.1271
  %descriptor.range.inside.1277 = and i1 %descriptor.owner.offset.valid.1275, %descriptor.extent.inside.1273
  %descriptor.range.valid.1276 = and i1 %descriptor.range.inside.1277, %descriptor.payload.inside.1274
  br i1 %descriptor.range.valid.1276, label %descriptor.valid.1278, label %descriptor.invalid.1279
descriptor.invalid.1279:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1278:
  %descriptor.initialized.status.1280 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1264, i32 %local.check.extent.1265)
  %helper.ok.1281 = icmp eq i32 %descriptor.initialized.status.1280, 0
  br i1 %helper.ok.1281, label %helper.continue.1282, label %frame.failure.0
helper.continue.1282:
  br label %local.descriptor.checked.1263
local.descriptor.inactive.1262:
  br label %local.descriptor.checked.1263
local.descriptor.checked.1263:
  %local.is.active.1283 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1283, label %local.descriptor.active.1284, label %local.descriptor.inactive.1285
local.descriptor.active.1284:
  %local.check.offset.1287 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1288 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1289 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1290 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1291 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1292 = load i32, ptr %context.field.1291, align 4
  %stack.sub.1295 = sub i32 %local.check.owner.end.1290, %local.check.offset.1287
  %descriptor.owner.inside.1293 = icmp ule i32 %local.check.owner.end.1290, %context.value.1292
  %descriptor.offset.inside.1294 = icmp ule i32 %local.check.offset.1287, %local.check.owner.end.1290
  %descriptor.extent.inside.1296 = icmp ule i32 %local.check.extent.1288, %stack.sub.1295
  %descriptor.payload.inside.1297 = icmp ule i32 %local.check.payload.1289, %local.check.extent.1288
  %descriptor.owner.offset.valid.1298 = and i1 %descriptor.owner.inside.1293, %descriptor.offset.inside.1294
  %descriptor.range.inside.1300 = and i1 %descriptor.owner.offset.valid.1298, %descriptor.extent.inside.1296
  %descriptor.range.valid.1299 = and i1 %descriptor.range.inside.1300, %descriptor.payload.inside.1297
  br i1 %descriptor.range.valid.1299, label %descriptor.valid.1301, label %descriptor.invalid.1302
descriptor.invalid.1302:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1301:
  %descriptor.initialized.status.1303 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1287, i32 %local.check.extent.1288)
  %helper.ok.1304 = icmp eq i32 %descriptor.initialized.status.1303, 0
  br i1 %helper.ok.1304, label %helper.continue.1305, label %frame.failure.0
helper.continue.1305:
  br label %local.descriptor.checked.1286
local.descriptor.inactive.1285:
  br label %local.descriptor.checked.1286
local.descriptor.checked.1286:
  %local.is.active.1306 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.1306, label %local.descriptor.active.1307, label %local.descriptor.inactive.1308
local.descriptor.active.1307:
  %local.check.offset.1310 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.1311 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.1312 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.1313 = load i32, ptr %local.owner.end.42, align 4
  %context.field.1314 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1315 = load i32, ptr %context.field.1314, align 4
  %stack.sub.1318 = sub i32 %local.check.owner.end.1313, %local.check.offset.1310
  %descriptor.owner.inside.1316 = icmp ule i32 %local.check.owner.end.1313, %context.value.1315
  %descriptor.offset.inside.1317 = icmp ule i32 %local.check.offset.1310, %local.check.owner.end.1313
  %descriptor.extent.inside.1319 = icmp ule i32 %local.check.extent.1311, %stack.sub.1318
  %descriptor.payload.inside.1320 = icmp ule i32 %local.check.payload.1312, %local.check.extent.1311
  %descriptor.owner.offset.valid.1321 = and i1 %descriptor.owner.inside.1316, %descriptor.offset.inside.1317
  %descriptor.range.inside.1323 = and i1 %descriptor.owner.offset.valid.1321, %descriptor.extent.inside.1319
  %descriptor.range.valid.1322 = and i1 %descriptor.range.inside.1323, %descriptor.payload.inside.1320
  br i1 %descriptor.range.valid.1322, label %descriptor.valid.1324, label %descriptor.invalid.1325
descriptor.invalid.1325:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1324:
  %descriptor.initialized.status.1326 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1310, i32 %local.check.extent.1311)
  %helper.ok.1327 = icmp eq i32 %descriptor.initialized.status.1326, 0
  br i1 %helper.ok.1327, label %helper.continue.1328, label %frame.failure.0
helper.continue.1328:
  br label %local.descriptor.checked.1309
local.descriptor.inactive.1308:
  br label %local.descriptor.checked.1309
local.descriptor.checked.1309:
  %step.status.1329 = call i32 @al_owning_charge_step(ptr %ctx, i32 38)
  %helper.ok.1330 = icmp eq i32 %step.status.1329, 0
  br i1 %helper.ok.1330, label %helper.continue.1331, label %frame.failure.0
helper.continue.1331:
  %if.condition.raw.1332 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.1137)
  %context.field.1333 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1334 = load i32, ptr %context.field.1333, align 4
  %runtime.ok.1335 = icmp eq i32 %context.value.1334, 0
  br i1 %runtime.ok.1335, label %runtime.continue.1336, label %frame.failure.0
runtime.continue.1336:
  %if.condition.1337 = icmp ne i64 %if.condition.raw.1332, 0
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 2, i32 %context.value.1137, i32 8, i32 8, i32 0, i32 0)
  %context.field.1338 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1339 = load i32, ptr %context.field.1338, align 4
  %runtime.ok.1340 = icmp eq i32 %context.value.1339, 0
  br i1 %runtime.ok.1340, label %runtime.continue.1341, label %frame.failure.0
runtime.continue.1341:
  br i1 %if.condition.1337, label %if.then.1342, label %if.else.1343
if.then.1342:
  %step.status.1345 = call i32 @al_owning_charge_step(ptr %ctx, i32 39)
  %helper.ok.1346 = icmp eq i32 %step.status.1345, 0
  br i1 %helper.ok.1346, label %helper.continue.1347, label %frame.failure.0
helper.continue.1347:
  %context.field.1348 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1349 = load i32, ptr %context.field.1348, align 4
  %step.status.1350 = call i32 @al_owning_charge_step(ptr %ctx, i32 40)
  %helper.ok.1351 = icmp eq i32 %step.status.1350, 0
  br i1 %helper.ok.1351, label %helper.continue.1352, label %frame.failure.0
helper.continue.1352:
  %context.field.1353 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1354 = load i32, ptr %context.field.1353, align 4
  %stack.offset.1355 = add i32 %context.value.1354, 8
  %reserve.status.1356 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1355, i32 41)
  %reserve.ok.1357 = icmp eq i32 %reserve.status.1356, 0
  br i1 %reserve.ok.1357, label %reserve.continue.1358, label %frame.failure.0
reserve.continue.1358:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.1354, i64 1, i32 1)
  %context.field.1359 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1360 = load i32, ptr %context.field.1359, align 4
  %runtime.ok.1361 = icmp eq i32 %context.value.1360, 0
  br i1 %runtime.ok.1361, label %runtime.continue.1362, label %frame.failure.0
runtime.continue.1362:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.1363 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1364 = load i32, ptr %context.field.1363, align 4
  %runtime.ok.1365 = icmp eq i32 %context.value.1364, 0
  br i1 %runtime.ok.1365, label %runtime.continue.1366, label %frame.failure.0
runtime.continue.1366:
  %context.field.1367 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1368 = load i32, ptr %context.field.1367, align 4
  %stack.sub.1371 = sub i32 %stack.offset.1355, %context.value.1354
  %descriptor.owner.inside.1369 = icmp ule i32 %stack.offset.1355, %context.value.1368
  %descriptor.offset.inside.1370 = icmp ule i32 %context.value.1354, %stack.offset.1355
  %descriptor.extent.inside.1372 = icmp ule i32 8, %stack.sub.1371
  %descriptor.payload.inside.1373 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.1374 = and i1 %descriptor.owner.inside.1369, %descriptor.offset.inside.1370
  %descriptor.range.inside.1376 = and i1 %descriptor.owner.offset.valid.1374, %descriptor.extent.inside.1372
  %descriptor.range.valid.1375 = and i1 %descriptor.range.inside.1376, %descriptor.payload.inside.1373
  %descriptor.type.valid.1377 = icmp eq i32 1, 1
  %descriptor.valid.1378 = and i1 %descriptor.range.valid.1375, %descriptor.type.valid.1377
  br i1 %descriptor.valid.1378, label %descriptor.valid.1379, label %descriptor.invalid.1380
descriptor.invalid.1380:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1379:
  %descriptor.initialized.status.1381 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.1354, i32 8)
  %helper.ok.1382 = icmp eq i32 %descriptor.initialized.status.1381, 0
  br i1 %helper.ok.1382, label %helper.continue.1383, label %frame.failure.0
helper.continue.1383:
  %local.is.active.1384 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1384, label %local.descriptor.active.1385, label %local.descriptor.inactive.1386
local.descriptor.active.1385:
  %local.check.offset.1388 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1389 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1390 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1391 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1392 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1393 = load i32, ptr %context.field.1392, align 4
  %stack.sub.1396 = sub i32 %local.check.owner.end.1391, %local.check.offset.1388
  %descriptor.owner.inside.1394 = icmp ule i32 %local.check.owner.end.1391, %context.value.1393
  %descriptor.offset.inside.1395 = icmp ule i32 %local.check.offset.1388, %local.check.owner.end.1391
  %descriptor.extent.inside.1397 = icmp ule i32 %local.check.extent.1389, %stack.sub.1396
  %descriptor.payload.inside.1398 = icmp ule i32 %local.check.payload.1390, %local.check.extent.1389
  %descriptor.owner.offset.valid.1399 = and i1 %descriptor.owner.inside.1394, %descriptor.offset.inside.1395
  %descriptor.range.inside.1401 = and i1 %descriptor.owner.offset.valid.1399, %descriptor.extent.inside.1397
  %descriptor.range.valid.1400 = and i1 %descriptor.range.inside.1401, %descriptor.payload.inside.1398
  br i1 %descriptor.range.valid.1400, label %descriptor.valid.1402, label %descriptor.invalid.1403
descriptor.invalid.1403:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1402:
  %descriptor.initialized.status.1404 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1388, i32 %local.check.extent.1389)
  %helper.ok.1405 = icmp eq i32 %descriptor.initialized.status.1404, 0
  br i1 %helper.ok.1405, label %helper.continue.1406, label %frame.failure.0
helper.continue.1406:
  br label %local.descriptor.checked.1387
local.descriptor.inactive.1386:
  br label %local.descriptor.checked.1387
local.descriptor.checked.1387:
  %local.is.active.1407 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1407, label %local.descriptor.active.1408, label %local.descriptor.inactive.1409
local.descriptor.active.1408:
  %local.check.offset.1411 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1412 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1413 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1414 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1415 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1416 = load i32, ptr %context.field.1415, align 4
  %stack.sub.1419 = sub i32 %local.check.owner.end.1414, %local.check.offset.1411
  %descriptor.owner.inside.1417 = icmp ule i32 %local.check.owner.end.1414, %context.value.1416
  %descriptor.offset.inside.1418 = icmp ule i32 %local.check.offset.1411, %local.check.owner.end.1414
  %descriptor.extent.inside.1420 = icmp ule i32 %local.check.extent.1412, %stack.sub.1419
  %descriptor.payload.inside.1421 = icmp ule i32 %local.check.payload.1413, %local.check.extent.1412
  %descriptor.owner.offset.valid.1422 = and i1 %descriptor.owner.inside.1417, %descriptor.offset.inside.1418
  %descriptor.range.inside.1424 = and i1 %descriptor.owner.offset.valid.1422, %descriptor.extent.inside.1420
  %descriptor.range.valid.1423 = and i1 %descriptor.range.inside.1424, %descriptor.payload.inside.1421
  br i1 %descriptor.range.valid.1423, label %descriptor.valid.1425, label %descriptor.invalid.1426
descriptor.invalid.1426:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1425:
  %descriptor.initialized.status.1427 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1411, i32 %local.check.extent.1412)
  %helper.ok.1428 = icmp eq i32 %descriptor.initialized.status.1427, 0
  br i1 %helper.ok.1428, label %helper.continue.1429, label %frame.failure.0
helper.continue.1429:
  br label %local.descriptor.checked.1410
local.descriptor.inactive.1409:
  br label %local.descriptor.checked.1410
local.descriptor.checked.1410:
  %local.is.active.1430 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1430, label %local.descriptor.active.1431, label %local.descriptor.inactive.1432
local.descriptor.active.1431:
  %local.check.offset.1434 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1435 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1436 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1437 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1438 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1439 = load i32, ptr %context.field.1438, align 4
  %stack.sub.1442 = sub i32 %local.check.owner.end.1437, %local.check.offset.1434
  %descriptor.owner.inside.1440 = icmp ule i32 %local.check.owner.end.1437, %context.value.1439
  %descriptor.offset.inside.1441 = icmp ule i32 %local.check.offset.1434, %local.check.owner.end.1437
  %descriptor.extent.inside.1443 = icmp ule i32 %local.check.extent.1435, %stack.sub.1442
  %descriptor.payload.inside.1444 = icmp ule i32 %local.check.payload.1436, %local.check.extent.1435
  %descriptor.owner.offset.valid.1445 = and i1 %descriptor.owner.inside.1440, %descriptor.offset.inside.1441
  %descriptor.range.inside.1447 = and i1 %descriptor.owner.offset.valid.1445, %descriptor.extent.inside.1443
  %descriptor.range.valid.1446 = and i1 %descriptor.range.inside.1447, %descriptor.payload.inside.1444
  br i1 %descriptor.range.valid.1446, label %descriptor.valid.1448, label %descriptor.invalid.1449
descriptor.invalid.1449:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1448:
  %descriptor.initialized.status.1450 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1434, i32 %local.check.extent.1435)
  %helper.ok.1451 = icmp eq i32 %descriptor.initialized.status.1450, 0
  br i1 %helper.ok.1451, label %helper.continue.1452, label %frame.failure.0
helper.continue.1452:
  br label %local.descriptor.checked.1433
local.descriptor.inactive.1432:
  br label %local.descriptor.checked.1433
local.descriptor.checked.1433:
  %local.is.active.1453 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1453, label %local.descriptor.active.1454, label %local.descriptor.inactive.1455
local.descriptor.active.1454:
  %local.check.offset.1457 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1458 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1459 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1460 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1461 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1462 = load i32, ptr %context.field.1461, align 4
  %stack.sub.1465 = sub i32 %local.check.owner.end.1460, %local.check.offset.1457
  %descriptor.owner.inside.1463 = icmp ule i32 %local.check.owner.end.1460, %context.value.1462
  %descriptor.offset.inside.1464 = icmp ule i32 %local.check.offset.1457, %local.check.owner.end.1460
  %descriptor.extent.inside.1466 = icmp ule i32 %local.check.extent.1458, %stack.sub.1465
  %descriptor.payload.inside.1467 = icmp ule i32 %local.check.payload.1459, %local.check.extent.1458
  %descriptor.owner.offset.valid.1468 = and i1 %descriptor.owner.inside.1463, %descriptor.offset.inside.1464
  %descriptor.range.inside.1470 = and i1 %descriptor.owner.offset.valid.1468, %descriptor.extent.inside.1466
  %descriptor.range.valid.1469 = and i1 %descriptor.range.inside.1470, %descriptor.payload.inside.1467
  br i1 %descriptor.range.valid.1469, label %descriptor.valid.1471, label %descriptor.invalid.1472
descriptor.invalid.1472:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1471:
  %descriptor.initialized.status.1473 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1457, i32 %local.check.extent.1458)
  %helper.ok.1474 = icmp eq i32 %descriptor.initialized.status.1473, 0
  br i1 %helper.ok.1474, label %helper.continue.1475, label %frame.failure.0
helper.continue.1475:
  br label %local.descriptor.checked.1456
local.descriptor.inactive.1455:
  br label %local.descriptor.checked.1456
local.descriptor.checked.1456:
  %local.is.active.1476 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1476, label %local.descriptor.active.1477, label %local.descriptor.inactive.1478
local.descriptor.active.1477:
  %local.check.offset.1480 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1481 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1482 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1483 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1484 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1485 = load i32, ptr %context.field.1484, align 4
  %stack.sub.1488 = sub i32 %local.check.owner.end.1483, %local.check.offset.1480
  %descriptor.owner.inside.1486 = icmp ule i32 %local.check.owner.end.1483, %context.value.1485
  %descriptor.offset.inside.1487 = icmp ule i32 %local.check.offset.1480, %local.check.owner.end.1483
  %descriptor.extent.inside.1489 = icmp ule i32 %local.check.extent.1481, %stack.sub.1488
  %descriptor.payload.inside.1490 = icmp ule i32 %local.check.payload.1482, %local.check.extent.1481
  %descriptor.owner.offset.valid.1491 = and i1 %descriptor.owner.inside.1486, %descriptor.offset.inside.1487
  %descriptor.range.inside.1493 = and i1 %descriptor.owner.offset.valid.1491, %descriptor.extent.inside.1489
  %descriptor.range.valid.1492 = and i1 %descriptor.range.inside.1493, %descriptor.payload.inside.1490
  br i1 %descriptor.range.valid.1492, label %descriptor.valid.1494, label %descriptor.invalid.1495
descriptor.invalid.1495:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1494:
  %descriptor.initialized.status.1496 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1480, i32 %local.check.extent.1481)
  %helper.ok.1497 = icmp eq i32 %descriptor.initialized.status.1496, 0
  br i1 %helper.ok.1497, label %helper.continue.1498, label %frame.failure.0
helper.continue.1498:
  br label %local.descriptor.checked.1479
local.descriptor.inactive.1478:
  br label %local.descriptor.checked.1479
local.descriptor.checked.1479:
  %local.is.active.1499 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1499, label %local.descriptor.active.1500, label %local.descriptor.inactive.1501
local.descriptor.active.1500:
  %local.check.offset.1503 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1504 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1505 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1506 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1507 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1508 = load i32, ptr %context.field.1507, align 4
  %stack.sub.1511 = sub i32 %local.check.owner.end.1506, %local.check.offset.1503
  %descriptor.owner.inside.1509 = icmp ule i32 %local.check.owner.end.1506, %context.value.1508
  %descriptor.offset.inside.1510 = icmp ule i32 %local.check.offset.1503, %local.check.owner.end.1506
  %descriptor.extent.inside.1512 = icmp ule i32 %local.check.extent.1504, %stack.sub.1511
  %descriptor.payload.inside.1513 = icmp ule i32 %local.check.payload.1505, %local.check.extent.1504
  %descriptor.owner.offset.valid.1514 = and i1 %descriptor.owner.inside.1509, %descriptor.offset.inside.1510
  %descriptor.range.inside.1516 = and i1 %descriptor.owner.offset.valid.1514, %descriptor.extent.inside.1512
  %descriptor.range.valid.1515 = and i1 %descriptor.range.inside.1516, %descriptor.payload.inside.1513
  br i1 %descriptor.range.valid.1515, label %descriptor.valid.1517, label %descriptor.invalid.1518
descriptor.invalid.1518:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1517:
  %descriptor.initialized.status.1519 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1503, i32 %local.check.extent.1504)
  %helper.ok.1520 = icmp eq i32 %descriptor.initialized.status.1519, 0
  br i1 %helper.ok.1520, label %helper.continue.1521, label %frame.failure.0
helper.continue.1521:
  br label %local.descriptor.checked.1502
local.descriptor.inactive.1501:
  br label %local.descriptor.checked.1502
local.descriptor.checked.1502:
  %local.is.active.1522 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.1522, label %local.descriptor.active.1523, label %local.descriptor.inactive.1524
local.descriptor.active.1523:
  %local.check.offset.1526 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.1527 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.1528 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.1529 = load i32, ptr %local.owner.end.42, align 4
  %context.field.1530 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1531 = load i32, ptr %context.field.1530, align 4
  %stack.sub.1534 = sub i32 %local.check.owner.end.1529, %local.check.offset.1526
  %descriptor.owner.inside.1532 = icmp ule i32 %local.check.owner.end.1529, %context.value.1531
  %descriptor.offset.inside.1533 = icmp ule i32 %local.check.offset.1526, %local.check.owner.end.1529
  %descriptor.extent.inside.1535 = icmp ule i32 %local.check.extent.1527, %stack.sub.1534
  %descriptor.payload.inside.1536 = icmp ule i32 %local.check.payload.1528, %local.check.extent.1527
  %descriptor.owner.offset.valid.1537 = and i1 %descriptor.owner.inside.1532, %descriptor.offset.inside.1533
  %descriptor.range.inside.1539 = and i1 %descriptor.owner.offset.valid.1537, %descriptor.extent.inside.1535
  %descriptor.range.valid.1538 = and i1 %descriptor.range.inside.1539, %descriptor.payload.inside.1536
  br i1 %descriptor.range.valid.1538, label %descriptor.valid.1540, label %descriptor.invalid.1541
descriptor.invalid.1541:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1540:
  %descriptor.initialized.status.1542 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1526, i32 %local.check.extent.1527)
  %helper.ok.1543 = icmp eq i32 %descriptor.initialized.status.1542, 0
  br i1 %helper.ok.1543, label %helper.continue.1544, label %frame.failure.0
helper.continue.1544:
  br label %local.descriptor.checked.1525
local.descriptor.inactive.1524:
  br label %local.descriptor.checked.1525
local.descriptor.checked.1525:
  %step.status.1545 = call i32 @al_owning_charge_step(ptr %ctx, i32 42)
  %helper.ok.1546 = icmp eq i32 %step.status.1545, 0
  br i1 %helper.ok.1546, label %helper.continue.1547, label %frame.failure.0
helper.continue.1547:
  %context.field.1548 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1549 = load i32, ptr %context.field.1548, align 4
  %stack.offset.1550 = add i32 %context.value.1549, 8
  %reserve.status.1551 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1550, i32 43)
  %reserve.ok.1552 = icmp eq i32 %reserve.status.1551, 0
  br i1 %reserve.ok.1552, label %reserve.continue.1553, label %frame.failure.0
reserve.continue.1553:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.1549, i64 0, i32 1)
  %context.field.1554 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1555 = load i32, ptr %context.field.1554, align 4
  %runtime.ok.1556 = icmp eq i32 %context.value.1555, 0
  br i1 %runtime.ok.1556, label %runtime.continue.1557, label %frame.failure.0
runtime.continue.1557:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.1558 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1559 = load i32, ptr %context.field.1558, align 4
  %runtime.ok.1560 = icmp eq i32 %context.value.1559, 0
  br i1 %runtime.ok.1560, label %runtime.continue.1561, label %frame.failure.0
runtime.continue.1561:
  %context.field.1562 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1563 = load i32, ptr %context.field.1562, align 4
  %stack.sub.1566 = sub i32 %stack.offset.1355, %context.value.1354
  %descriptor.owner.inside.1564 = icmp ule i32 %stack.offset.1355, %context.value.1563
  %descriptor.offset.inside.1565 = icmp ule i32 %context.value.1354, %stack.offset.1355
  %descriptor.extent.inside.1567 = icmp ule i32 8, %stack.sub.1566
  %descriptor.payload.inside.1568 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.1569 = and i1 %descriptor.owner.inside.1564, %descriptor.offset.inside.1565
  %descriptor.range.inside.1571 = and i1 %descriptor.owner.offset.valid.1569, %descriptor.extent.inside.1567
  %descriptor.range.valid.1570 = and i1 %descriptor.range.inside.1571, %descriptor.payload.inside.1568
  %descriptor.type.valid.1572 = icmp eq i32 1, 1
  %descriptor.valid.1573 = and i1 %descriptor.range.valid.1570, %descriptor.type.valid.1572
  br i1 %descriptor.valid.1573, label %descriptor.valid.1574, label %descriptor.invalid.1575
descriptor.invalid.1575:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1574:
  %descriptor.initialized.status.1576 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.1354, i32 8)
  %helper.ok.1577 = icmp eq i32 %descriptor.initialized.status.1576, 0
  br i1 %helper.ok.1577, label %helper.continue.1578, label %frame.failure.0
helper.continue.1578:
  %context.field.1579 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1580 = load i32, ptr %context.field.1579, align 4
  %stack.sub.1583 = sub i32 %stack.offset.1550, %context.value.1549
  %descriptor.owner.inside.1581 = icmp ule i32 %stack.offset.1550, %context.value.1580
  %descriptor.offset.inside.1582 = icmp ule i32 %context.value.1549, %stack.offset.1550
  %descriptor.extent.inside.1584 = icmp ule i32 8, %stack.sub.1583
  %descriptor.payload.inside.1585 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.1586 = and i1 %descriptor.owner.inside.1581, %descriptor.offset.inside.1582
  %descriptor.range.inside.1588 = and i1 %descriptor.owner.offset.valid.1586, %descriptor.extent.inside.1584
  %descriptor.range.valid.1587 = and i1 %descriptor.range.inside.1588, %descriptor.payload.inside.1585
  %descriptor.type.valid.1589 = icmp eq i32 1, 1
  %descriptor.valid.1590 = and i1 %descriptor.range.valid.1587, %descriptor.type.valid.1589
  br i1 %descriptor.valid.1590, label %descriptor.valid.1591, label %descriptor.invalid.1592
descriptor.invalid.1592:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1591:
  %descriptor.initialized.status.1593 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.1549, i32 8)
  %helper.ok.1594 = icmp eq i32 %descriptor.initialized.status.1593, 0
  br i1 %helper.ok.1594, label %helper.continue.1595, label %frame.failure.0
helper.continue.1595:
  %local.is.active.1596 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1596, label %local.descriptor.active.1597, label %local.descriptor.inactive.1598
local.descriptor.active.1597:
  %local.check.offset.1600 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1601 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1602 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1603 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1604 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1605 = load i32, ptr %context.field.1604, align 4
  %stack.sub.1608 = sub i32 %local.check.owner.end.1603, %local.check.offset.1600
  %descriptor.owner.inside.1606 = icmp ule i32 %local.check.owner.end.1603, %context.value.1605
  %descriptor.offset.inside.1607 = icmp ule i32 %local.check.offset.1600, %local.check.owner.end.1603
  %descriptor.extent.inside.1609 = icmp ule i32 %local.check.extent.1601, %stack.sub.1608
  %descriptor.payload.inside.1610 = icmp ule i32 %local.check.payload.1602, %local.check.extent.1601
  %descriptor.owner.offset.valid.1611 = and i1 %descriptor.owner.inside.1606, %descriptor.offset.inside.1607
  %descriptor.range.inside.1613 = and i1 %descriptor.owner.offset.valid.1611, %descriptor.extent.inside.1609
  %descriptor.range.valid.1612 = and i1 %descriptor.range.inside.1613, %descriptor.payload.inside.1610
  br i1 %descriptor.range.valid.1612, label %descriptor.valid.1614, label %descriptor.invalid.1615
descriptor.invalid.1615:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1614:
  %descriptor.initialized.status.1616 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1600, i32 %local.check.extent.1601)
  %helper.ok.1617 = icmp eq i32 %descriptor.initialized.status.1616, 0
  br i1 %helper.ok.1617, label %helper.continue.1618, label %frame.failure.0
helper.continue.1618:
  br label %local.descriptor.checked.1599
local.descriptor.inactive.1598:
  br label %local.descriptor.checked.1599
local.descriptor.checked.1599:
  %local.is.active.1619 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1619, label %local.descriptor.active.1620, label %local.descriptor.inactive.1621
local.descriptor.active.1620:
  %local.check.offset.1623 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1624 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1625 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1626 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1627 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1628 = load i32, ptr %context.field.1627, align 4
  %stack.sub.1631 = sub i32 %local.check.owner.end.1626, %local.check.offset.1623
  %descriptor.owner.inside.1629 = icmp ule i32 %local.check.owner.end.1626, %context.value.1628
  %descriptor.offset.inside.1630 = icmp ule i32 %local.check.offset.1623, %local.check.owner.end.1626
  %descriptor.extent.inside.1632 = icmp ule i32 %local.check.extent.1624, %stack.sub.1631
  %descriptor.payload.inside.1633 = icmp ule i32 %local.check.payload.1625, %local.check.extent.1624
  %descriptor.owner.offset.valid.1634 = and i1 %descriptor.owner.inside.1629, %descriptor.offset.inside.1630
  %descriptor.range.inside.1636 = and i1 %descriptor.owner.offset.valid.1634, %descriptor.extent.inside.1632
  %descriptor.range.valid.1635 = and i1 %descriptor.range.inside.1636, %descriptor.payload.inside.1633
  br i1 %descriptor.range.valid.1635, label %descriptor.valid.1637, label %descriptor.invalid.1638
descriptor.invalid.1638:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1637:
  %descriptor.initialized.status.1639 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1623, i32 %local.check.extent.1624)
  %helper.ok.1640 = icmp eq i32 %descriptor.initialized.status.1639, 0
  br i1 %helper.ok.1640, label %helper.continue.1641, label %frame.failure.0
helper.continue.1641:
  br label %local.descriptor.checked.1622
local.descriptor.inactive.1621:
  br label %local.descriptor.checked.1622
local.descriptor.checked.1622:
  %local.is.active.1642 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1642, label %local.descriptor.active.1643, label %local.descriptor.inactive.1644
local.descriptor.active.1643:
  %local.check.offset.1646 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1647 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1648 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1649 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1650 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1651 = load i32, ptr %context.field.1650, align 4
  %stack.sub.1654 = sub i32 %local.check.owner.end.1649, %local.check.offset.1646
  %descriptor.owner.inside.1652 = icmp ule i32 %local.check.owner.end.1649, %context.value.1651
  %descriptor.offset.inside.1653 = icmp ule i32 %local.check.offset.1646, %local.check.owner.end.1649
  %descriptor.extent.inside.1655 = icmp ule i32 %local.check.extent.1647, %stack.sub.1654
  %descriptor.payload.inside.1656 = icmp ule i32 %local.check.payload.1648, %local.check.extent.1647
  %descriptor.owner.offset.valid.1657 = and i1 %descriptor.owner.inside.1652, %descriptor.offset.inside.1653
  %descriptor.range.inside.1659 = and i1 %descriptor.owner.offset.valid.1657, %descriptor.extent.inside.1655
  %descriptor.range.valid.1658 = and i1 %descriptor.range.inside.1659, %descriptor.payload.inside.1656
  br i1 %descriptor.range.valid.1658, label %descriptor.valid.1660, label %descriptor.invalid.1661
descriptor.invalid.1661:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1660:
  %descriptor.initialized.status.1662 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1646, i32 %local.check.extent.1647)
  %helper.ok.1663 = icmp eq i32 %descriptor.initialized.status.1662, 0
  br i1 %helper.ok.1663, label %helper.continue.1664, label %frame.failure.0
helper.continue.1664:
  br label %local.descriptor.checked.1645
local.descriptor.inactive.1644:
  br label %local.descriptor.checked.1645
local.descriptor.checked.1645:
  %local.is.active.1665 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1665, label %local.descriptor.active.1666, label %local.descriptor.inactive.1667
local.descriptor.active.1666:
  %local.check.offset.1669 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1670 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1671 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1672 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1673 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1674 = load i32, ptr %context.field.1673, align 4
  %stack.sub.1677 = sub i32 %local.check.owner.end.1672, %local.check.offset.1669
  %descriptor.owner.inside.1675 = icmp ule i32 %local.check.owner.end.1672, %context.value.1674
  %descriptor.offset.inside.1676 = icmp ule i32 %local.check.offset.1669, %local.check.owner.end.1672
  %descriptor.extent.inside.1678 = icmp ule i32 %local.check.extent.1670, %stack.sub.1677
  %descriptor.payload.inside.1679 = icmp ule i32 %local.check.payload.1671, %local.check.extent.1670
  %descriptor.owner.offset.valid.1680 = and i1 %descriptor.owner.inside.1675, %descriptor.offset.inside.1676
  %descriptor.range.inside.1682 = and i1 %descriptor.owner.offset.valid.1680, %descriptor.extent.inside.1678
  %descriptor.range.valid.1681 = and i1 %descriptor.range.inside.1682, %descriptor.payload.inside.1679
  br i1 %descriptor.range.valid.1681, label %descriptor.valid.1683, label %descriptor.invalid.1684
descriptor.invalid.1684:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1683:
  %descriptor.initialized.status.1685 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1669, i32 %local.check.extent.1670)
  %helper.ok.1686 = icmp eq i32 %descriptor.initialized.status.1685, 0
  br i1 %helper.ok.1686, label %helper.continue.1687, label %frame.failure.0
helper.continue.1687:
  br label %local.descriptor.checked.1668
local.descriptor.inactive.1667:
  br label %local.descriptor.checked.1668
local.descriptor.checked.1668:
  %local.is.active.1688 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1688, label %local.descriptor.active.1689, label %local.descriptor.inactive.1690
local.descriptor.active.1689:
  %local.check.offset.1692 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1693 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1694 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1695 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1696 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1697 = load i32, ptr %context.field.1696, align 4
  %stack.sub.1700 = sub i32 %local.check.owner.end.1695, %local.check.offset.1692
  %descriptor.owner.inside.1698 = icmp ule i32 %local.check.owner.end.1695, %context.value.1697
  %descriptor.offset.inside.1699 = icmp ule i32 %local.check.offset.1692, %local.check.owner.end.1695
  %descriptor.extent.inside.1701 = icmp ule i32 %local.check.extent.1693, %stack.sub.1700
  %descriptor.payload.inside.1702 = icmp ule i32 %local.check.payload.1694, %local.check.extent.1693
  %descriptor.owner.offset.valid.1703 = and i1 %descriptor.owner.inside.1698, %descriptor.offset.inside.1699
  %descriptor.range.inside.1705 = and i1 %descriptor.owner.offset.valid.1703, %descriptor.extent.inside.1701
  %descriptor.range.valid.1704 = and i1 %descriptor.range.inside.1705, %descriptor.payload.inside.1702
  br i1 %descriptor.range.valid.1704, label %descriptor.valid.1706, label %descriptor.invalid.1707
descriptor.invalid.1707:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1706:
  %descriptor.initialized.status.1708 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1692, i32 %local.check.extent.1693)
  %helper.ok.1709 = icmp eq i32 %descriptor.initialized.status.1708, 0
  br i1 %helper.ok.1709, label %helper.continue.1710, label %frame.failure.0
helper.continue.1710:
  br label %local.descriptor.checked.1691
local.descriptor.inactive.1690:
  br label %local.descriptor.checked.1691
local.descriptor.checked.1691:
  %local.is.active.1711 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1711, label %local.descriptor.active.1712, label %local.descriptor.inactive.1713
local.descriptor.active.1712:
  %local.check.offset.1715 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1716 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1717 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1718 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1719 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1720 = load i32, ptr %context.field.1719, align 4
  %stack.sub.1723 = sub i32 %local.check.owner.end.1718, %local.check.offset.1715
  %descriptor.owner.inside.1721 = icmp ule i32 %local.check.owner.end.1718, %context.value.1720
  %descriptor.offset.inside.1722 = icmp ule i32 %local.check.offset.1715, %local.check.owner.end.1718
  %descriptor.extent.inside.1724 = icmp ule i32 %local.check.extent.1716, %stack.sub.1723
  %descriptor.payload.inside.1725 = icmp ule i32 %local.check.payload.1717, %local.check.extent.1716
  %descriptor.owner.offset.valid.1726 = and i1 %descriptor.owner.inside.1721, %descriptor.offset.inside.1722
  %descriptor.range.inside.1728 = and i1 %descriptor.owner.offset.valid.1726, %descriptor.extent.inside.1724
  %descriptor.range.valid.1727 = and i1 %descriptor.range.inside.1728, %descriptor.payload.inside.1725
  br i1 %descriptor.range.valid.1727, label %descriptor.valid.1729, label %descriptor.invalid.1730
descriptor.invalid.1730:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1729:
  %descriptor.initialized.status.1731 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1715, i32 %local.check.extent.1716)
  %helper.ok.1732 = icmp eq i32 %descriptor.initialized.status.1731, 0
  br i1 %helper.ok.1732, label %helper.continue.1733, label %frame.failure.0
helper.continue.1733:
  br label %local.descriptor.checked.1714
local.descriptor.inactive.1713:
  br label %local.descriptor.checked.1714
local.descriptor.checked.1714:
  %local.is.active.1734 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.1734, label %local.descriptor.active.1735, label %local.descriptor.inactive.1736
local.descriptor.active.1735:
  %local.check.offset.1738 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.1739 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.1740 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.1741 = load i32, ptr %local.owner.end.42, align 4
  %context.field.1742 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1743 = load i32, ptr %context.field.1742, align 4
  %stack.sub.1746 = sub i32 %local.check.owner.end.1741, %local.check.offset.1738
  %descriptor.owner.inside.1744 = icmp ule i32 %local.check.owner.end.1741, %context.value.1743
  %descriptor.offset.inside.1745 = icmp ule i32 %local.check.offset.1738, %local.check.owner.end.1741
  %descriptor.extent.inside.1747 = icmp ule i32 %local.check.extent.1739, %stack.sub.1746
  %descriptor.payload.inside.1748 = icmp ule i32 %local.check.payload.1740, %local.check.extent.1739
  %descriptor.owner.offset.valid.1749 = and i1 %descriptor.owner.inside.1744, %descriptor.offset.inside.1745
  %descriptor.range.inside.1751 = and i1 %descriptor.owner.offset.valid.1749, %descriptor.extent.inside.1747
  %descriptor.range.valid.1750 = and i1 %descriptor.range.inside.1751, %descriptor.payload.inside.1748
  br i1 %descriptor.range.valid.1750, label %descriptor.valid.1752, label %descriptor.invalid.1753
descriptor.invalid.1753:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1752:
  %descriptor.initialized.status.1754 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1738, i32 %local.check.extent.1739)
  %helper.ok.1755 = icmp eq i32 %descriptor.initialized.status.1754, 0
  br i1 %helper.ok.1755, label %helper.continue.1756, label %frame.failure.0
helper.continue.1756:
  br label %local.descriptor.checked.1737
local.descriptor.inactive.1736:
  br label %local.descriptor.checked.1737
local.descriptor.checked.1737:
  %step.status.1757 = call i32 @al_owning_charge_step(ptr %ctx, i32 44)
  %helper.ok.1758 = icmp eq i32 %step.status.1757, 0
  br i1 %helper.ok.1758, label %helper.continue.1759, label %frame.failure.0
helper.continue.1759:
  %context.field.1760 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.1761 = load i32, ptr %context.field.1760, align 4
  %inline.target.depth.within.interpreter.limit.1762 = icmp ule i32 %context.value.1761, 65
  br i1 %inline.target.depth.within.interpreter.limit.1762, label %inline.target.depth.ok.1763, label %inline.target.depth.invalid.1764
inline.target.depth.invalid.1764:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 45, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.1763:
  %integer.left.1765 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.1354)
  %context.field.1767 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1768 = load i32, ptr %context.field.1767, align 4
  %runtime.ok.1769 = icmp eq i32 %context.value.1768, 0
  br i1 %runtime.ok.1769, label %runtime.continue.1770, label %frame.failure.0
runtime.continue.1770:
  %integer.right.1766 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.1549)
  %context.field.1771 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1772 = load i32, ptr %context.field.1771, align 4
  %runtime.ok.1773 = icmp eq i32 %context.value.1772, 0
  br i1 %runtime.ok.1773, label %runtime.continue.1774, label %frame.failure.0
runtime.continue.1774:
  %divide.zero.1775 = icmp eq i64 %integer.right.1766, 0
  br i1 %divide.zero.1775, label %divide.zero.1776, label %divide.nonzero.1777
divide.zero.1776:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 46, i32 0, i32 0)
  br label %frame.failure.0
divide.nonzero.1777:
  %divide.min.1778 = icmp eq i64 %integer.left.1765, -9223372036854775808
  %divide.minusone.1779 = icmp eq i64 %integer.right.1766, -1
  %divide.overflow.1780 = and i1 %divide.min.1778, %divide.minusone.1779
  br i1 %divide.overflow.1780, label %divide.overflow.1781, label %divide.valid.1782
divide.overflow.1781:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 47, i32 0, i32 0)
  br label %frame.failure.0
divide.valid.1782:
  %divide.result.1783 = sdiv i64 %integer.left.1765, %integer.right.1766
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.1549, i32 8, i32 8, i32 0, i32 0)
  %context.field.1784 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1785 = load i32, ptr %context.field.1784, align 4
  %runtime.ok.1786 = icmp eq i32 %context.value.1785, 0
  br i1 %runtime.ok.1786, label %runtime.continue.1787, label %frame.failure.0
runtime.continue.1787:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.1354, i32 8, i32 8, i32 0, i32 0)
  %context.field.1788 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1789 = load i32, ptr %context.field.1788, align 4
  %runtime.ok.1790 = icmp eq i32 %context.value.1789, 0
  br i1 %runtime.ok.1790, label %runtime.continue.1791, label %frame.failure.0
runtime.continue.1791:
  %context.field.1792 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1793 = load i32, ptr %context.field.1792, align 4
  %stack.offset.1794 = add i32 %context.value.1793, 8
  %reserve.status.1795 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1794, i32 48)
  %reserve.ok.1796 = icmp eq i32 %reserve.status.1795, 0
  br i1 %reserve.ok.1796, label %reserve.continue.1797, label %frame.failure.0
reserve.continue.1797:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.1793, i64 %divide.result.1783, i32 1)
  %context.field.1798 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1799 = load i32, ptr %context.field.1798, align 4
  %runtime.ok.1800 = icmp eq i32 %context.value.1799, 0
  br i1 %runtime.ok.1800, label %runtime.continue.1801, label %frame.failure.0
runtime.continue.1801:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.1802 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1803 = load i32, ptr %context.field.1802, align 4
  %runtime.ok.1804 = icmp eq i32 %context.value.1803, 0
  br i1 %runtime.ok.1804, label %runtime.continue.1805, label %frame.failure.0
runtime.continue.1805:
  %stack.offset.1806 = add i32 %context.value.1793, 8
  %context.field.1807 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1808 = load i32, ptr %context.field.1807, align 4
  %stack.sub.1811 = sub i32 %stack.offset.1806, %context.value.1793
  %descriptor.owner.inside.1809 = icmp ule i32 %stack.offset.1806, %context.value.1808
  %descriptor.offset.inside.1810 = icmp ule i32 %context.value.1793, %stack.offset.1806
  %descriptor.extent.inside.1812 = icmp ule i32 8, %stack.sub.1811
  %descriptor.payload.inside.1813 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.1814 = and i1 %descriptor.owner.inside.1809, %descriptor.offset.inside.1810
  %descriptor.range.inside.1816 = and i1 %descriptor.owner.offset.valid.1814, %descriptor.extent.inside.1812
  %descriptor.range.valid.1815 = and i1 %descriptor.range.inside.1816, %descriptor.payload.inside.1813
  %descriptor.type.valid.1817 = icmp eq i32 1, 1
  %descriptor.valid.1818 = and i1 %descriptor.range.valid.1815, %descriptor.type.valid.1817
  br i1 %descriptor.valid.1818, label %descriptor.valid.1819, label %descriptor.invalid.1820
descriptor.invalid.1820:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1819:
  %descriptor.initialized.status.1821 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.1793, i32 8)
  %helper.ok.1822 = icmp eq i32 %descriptor.initialized.status.1821, 0
  br i1 %helper.ok.1822, label %helper.continue.1823, label %frame.failure.0
helper.continue.1823:
  %local.is.active.1824 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1824, label %local.descriptor.active.1825, label %local.descriptor.inactive.1826
local.descriptor.active.1825:
  %local.check.offset.1828 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1829 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1830 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1831 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1832 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1833 = load i32, ptr %context.field.1832, align 4
  %stack.sub.1836 = sub i32 %local.check.owner.end.1831, %local.check.offset.1828
  %descriptor.owner.inside.1834 = icmp ule i32 %local.check.owner.end.1831, %context.value.1833
  %descriptor.offset.inside.1835 = icmp ule i32 %local.check.offset.1828, %local.check.owner.end.1831
  %descriptor.extent.inside.1837 = icmp ule i32 %local.check.extent.1829, %stack.sub.1836
  %descriptor.payload.inside.1838 = icmp ule i32 %local.check.payload.1830, %local.check.extent.1829
  %descriptor.owner.offset.valid.1839 = and i1 %descriptor.owner.inside.1834, %descriptor.offset.inside.1835
  %descriptor.range.inside.1841 = and i1 %descriptor.owner.offset.valid.1839, %descriptor.extent.inside.1837
  %descriptor.range.valid.1840 = and i1 %descriptor.range.inside.1841, %descriptor.payload.inside.1838
  br i1 %descriptor.range.valid.1840, label %descriptor.valid.1842, label %descriptor.invalid.1843
descriptor.invalid.1843:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1842:
  %descriptor.initialized.status.1844 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1828, i32 %local.check.extent.1829)
  %helper.ok.1845 = icmp eq i32 %descriptor.initialized.status.1844, 0
  br i1 %helper.ok.1845, label %helper.continue.1846, label %frame.failure.0
helper.continue.1846:
  br label %local.descriptor.checked.1827
local.descriptor.inactive.1826:
  br label %local.descriptor.checked.1827
local.descriptor.checked.1827:
  %local.is.active.1847 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1847, label %local.descriptor.active.1848, label %local.descriptor.inactive.1849
local.descriptor.active.1848:
  %local.check.offset.1851 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1852 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1853 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1854 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1855 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1856 = load i32, ptr %context.field.1855, align 4
  %stack.sub.1859 = sub i32 %local.check.owner.end.1854, %local.check.offset.1851
  %descriptor.owner.inside.1857 = icmp ule i32 %local.check.owner.end.1854, %context.value.1856
  %descriptor.offset.inside.1858 = icmp ule i32 %local.check.offset.1851, %local.check.owner.end.1854
  %descriptor.extent.inside.1860 = icmp ule i32 %local.check.extent.1852, %stack.sub.1859
  %descriptor.payload.inside.1861 = icmp ule i32 %local.check.payload.1853, %local.check.extent.1852
  %descriptor.owner.offset.valid.1862 = and i1 %descriptor.owner.inside.1857, %descriptor.offset.inside.1858
  %descriptor.range.inside.1864 = and i1 %descriptor.owner.offset.valid.1862, %descriptor.extent.inside.1860
  %descriptor.range.valid.1863 = and i1 %descriptor.range.inside.1864, %descriptor.payload.inside.1861
  br i1 %descriptor.range.valid.1863, label %descriptor.valid.1865, label %descriptor.invalid.1866
descriptor.invalid.1866:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1865:
  %descriptor.initialized.status.1867 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1851, i32 %local.check.extent.1852)
  %helper.ok.1868 = icmp eq i32 %descriptor.initialized.status.1867, 0
  br i1 %helper.ok.1868, label %helper.continue.1869, label %frame.failure.0
helper.continue.1869:
  br label %local.descriptor.checked.1850
local.descriptor.inactive.1849:
  br label %local.descriptor.checked.1850
local.descriptor.checked.1850:
  %local.is.active.1870 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1870, label %local.descriptor.active.1871, label %local.descriptor.inactive.1872
local.descriptor.active.1871:
  %local.check.offset.1874 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1875 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1876 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1877 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1878 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1879 = load i32, ptr %context.field.1878, align 4
  %stack.sub.1882 = sub i32 %local.check.owner.end.1877, %local.check.offset.1874
  %descriptor.owner.inside.1880 = icmp ule i32 %local.check.owner.end.1877, %context.value.1879
  %descriptor.offset.inside.1881 = icmp ule i32 %local.check.offset.1874, %local.check.owner.end.1877
  %descriptor.extent.inside.1883 = icmp ule i32 %local.check.extent.1875, %stack.sub.1882
  %descriptor.payload.inside.1884 = icmp ule i32 %local.check.payload.1876, %local.check.extent.1875
  %descriptor.owner.offset.valid.1885 = and i1 %descriptor.owner.inside.1880, %descriptor.offset.inside.1881
  %descriptor.range.inside.1887 = and i1 %descriptor.owner.offset.valid.1885, %descriptor.extent.inside.1883
  %descriptor.range.valid.1886 = and i1 %descriptor.range.inside.1887, %descriptor.payload.inside.1884
  br i1 %descriptor.range.valid.1886, label %descriptor.valid.1888, label %descriptor.invalid.1889
descriptor.invalid.1889:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1888:
  %descriptor.initialized.status.1890 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1874, i32 %local.check.extent.1875)
  %helper.ok.1891 = icmp eq i32 %descriptor.initialized.status.1890, 0
  br i1 %helper.ok.1891, label %helper.continue.1892, label %frame.failure.0
helper.continue.1892:
  br label %local.descriptor.checked.1873
local.descriptor.inactive.1872:
  br label %local.descriptor.checked.1873
local.descriptor.checked.1873:
  %local.is.active.1893 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1893, label %local.descriptor.active.1894, label %local.descriptor.inactive.1895
local.descriptor.active.1894:
  %local.check.offset.1897 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1898 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1899 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1900 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1901 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1902 = load i32, ptr %context.field.1901, align 4
  %stack.sub.1905 = sub i32 %local.check.owner.end.1900, %local.check.offset.1897
  %descriptor.owner.inside.1903 = icmp ule i32 %local.check.owner.end.1900, %context.value.1902
  %descriptor.offset.inside.1904 = icmp ule i32 %local.check.offset.1897, %local.check.owner.end.1900
  %descriptor.extent.inside.1906 = icmp ule i32 %local.check.extent.1898, %stack.sub.1905
  %descriptor.payload.inside.1907 = icmp ule i32 %local.check.payload.1899, %local.check.extent.1898
  %descriptor.owner.offset.valid.1908 = and i1 %descriptor.owner.inside.1903, %descriptor.offset.inside.1904
  %descriptor.range.inside.1910 = and i1 %descriptor.owner.offset.valid.1908, %descriptor.extent.inside.1906
  %descriptor.range.valid.1909 = and i1 %descriptor.range.inside.1910, %descriptor.payload.inside.1907
  br i1 %descriptor.range.valid.1909, label %descriptor.valid.1911, label %descriptor.invalid.1912
descriptor.invalid.1912:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1911:
  %descriptor.initialized.status.1913 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1897, i32 %local.check.extent.1898)
  %helper.ok.1914 = icmp eq i32 %descriptor.initialized.status.1913, 0
  br i1 %helper.ok.1914, label %helper.continue.1915, label %frame.failure.0
helper.continue.1915:
  br label %local.descriptor.checked.1896
local.descriptor.inactive.1895:
  br label %local.descriptor.checked.1896
local.descriptor.checked.1896:
  %local.is.active.1916 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1916, label %local.descriptor.active.1917, label %local.descriptor.inactive.1918
local.descriptor.active.1917:
  %local.check.offset.1920 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1921 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1922 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1923 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1924 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1925 = load i32, ptr %context.field.1924, align 4
  %stack.sub.1928 = sub i32 %local.check.owner.end.1923, %local.check.offset.1920
  %descriptor.owner.inside.1926 = icmp ule i32 %local.check.owner.end.1923, %context.value.1925
  %descriptor.offset.inside.1927 = icmp ule i32 %local.check.offset.1920, %local.check.owner.end.1923
  %descriptor.extent.inside.1929 = icmp ule i32 %local.check.extent.1921, %stack.sub.1928
  %descriptor.payload.inside.1930 = icmp ule i32 %local.check.payload.1922, %local.check.extent.1921
  %descriptor.owner.offset.valid.1931 = and i1 %descriptor.owner.inside.1926, %descriptor.offset.inside.1927
  %descriptor.range.inside.1933 = and i1 %descriptor.owner.offset.valid.1931, %descriptor.extent.inside.1929
  %descriptor.range.valid.1932 = and i1 %descriptor.range.inside.1933, %descriptor.payload.inside.1930
  br i1 %descriptor.range.valid.1932, label %descriptor.valid.1934, label %descriptor.invalid.1935
descriptor.invalid.1935:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1934:
  %descriptor.initialized.status.1936 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1920, i32 %local.check.extent.1921)
  %helper.ok.1937 = icmp eq i32 %descriptor.initialized.status.1936, 0
  br i1 %helper.ok.1937, label %helper.continue.1938, label %frame.failure.0
helper.continue.1938:
  br label %local.descriptor.checked.1919
local.descriptor.inactive.1918:
  br label %local.descriptor.checked.1919
local.descriptor.checked.1919:
  %local.is.active.1939 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1939, label %local.descriptor.active.1940, label %local.descriptor.inactive.1941
local.descriptor.active.1940:
  %local.check.offset.1943 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1944 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1945 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1946 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1947 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1948 = load i32, ptr %context.field.1947, align 4
  %stack.sub.1951 = sub i32 %local.check.owner.end.1946, %local.check.offset.1943
  %descriptor.owner.inside.1949 = icmp ule i32 %local.check.owner.end.1946, %context.value.1948
  %descriptor.offset.inside.1950 = icmp ule i32 %local.check.offset.1943, %local.check.owner.end.1946
  %descriptor.extent.inside.1952 = icmp ule i32 %local.check.extent.1944, %stack.sub.1951
  %descriptor.payload.inside.1953 = icmp ule i32 %local.check.payload.1945, %local.check.extent.1944
  %descriptor.owner.offset.valid.1954 = and i1 %descriptor.owner.inside.1949, %descriptor.offset.inside.1950
  %descriptor.range.inside.1956 = and i1 %descriptor.owner.offset.valid.1954, %descriptor.extent.inside.1952
  %descriptor.range.valid.1955 = and i1 %descriptor.range.inside.1956, %descriptor.payload.inside.1953
  br i1 %descriptor.range.valid.1955, label %descriptor.valid.1957, label %descriptor.invalid.1958
descriptor.invalid.1958:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1957:
  %descriptor.initialized.status.1959 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1943, i32 %local.check.extent.1944)
  %helper.ok.1960 = icmp eq i32 %descriptor.initialized.status.1959, 0
  br i1 %helper.ok.1960, label %helper.continue.1961, label %frame.failure.0
helper.continue.1961:
  br label %local.descriptor.checked.1942
local.descriptor.inactive.1941:
  br label %local.descriptor.checked.1942
local.descriptor.checked.1942:
  %local.is.active.1962 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.1962, label %local.descriptor.active.1963, label %local.descriptor.inactive.1964
local.descriptor.active.1963:
  %local.check.offset.1966 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.1967 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.1968 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.1969 = load i32, ptr %local.owner.end.42, align 4
  %context.field.1970 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1971 = load i32, ptr %context.field.1970, align 4
  %stack.sub.1974 = sub i32 %local.check.owner.end.1969, %local.check.offset.1966
  %descriptor.owner.inside.1972 = icmp ule i32 %local.check.owner.end.1969, %context.value.1971
  %descriptor.offset.inside.1973 = icmp ule i32 %local.check.offset.1966, %local.check.owner.end.1969
  %descriptor.extent.inside.1975 = icmp ule i32 %local.check.extent.1967, %stack.sub.1974
  %descriptor.payload.inside.1976 = icmp ule i32 %local.check.payload.1968, %local.check.extent.1967
  %descriptor.owner.offset.valid.1977 = and i1 %descriptor.owner.inside.1972, %descriptor.offset.inside.1973
  %descriptor.range.inside.1979 = and i1 %descriptor.owner.offset.valid.1977, %descriptor.extent.inside.1975
  %descriptor.range.valid.1978 = and i1 %descriptor.range.inside.1979, %descriptor.payload.inside.1976
  br i1 %descriptor.range.valid.1978, label %descriptor.valid.1980, label %descriptor.invalid.1981
descriptor.invalid.1981:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1980:
  %descriptor.initialized.status.1982 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1966, i32 %local.check.extent.1967)
  %helper.ok.1983 = icmp eq i32 %descriptor.initialized.status.1982, 0
  br i1 %helper.ok.1983, label %helper.continue.1984, label %frame.failure.0
helper.continue.1984:
  br label %local.descriptor.checked.1965
local.descriptor.inactive.1964:
  br label %local.descriptor.checked.1965
local.descriptor.checked.1965:
  %context.field.1985 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1986 = load i32, ptr %context.field.1985, align 4
  %stack.sub.1989 = sub i32 %stack.offset.1806, %context.value.1793
  %descriptor.owner.inside.1987 = icmp ule i32 %stack.offset.1806, %context.value.1986
  %descriptor.offset.inside.1988 = icmp ule i32 %context.value.1793, %stack.offset.1806
  %descriptor.extent.inside.1990 = icmp ule i32 8, %stack.sub.1989
  %descriptor.payload.inside.1991 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.1992 = and i1 %descriptor.owner.inside.1987, %descriptor.offset.inside.1988
  %descriptor.range.inside.1994 = and i1 %descriptor.owner.offset.valid.1992, %descriptor.extent.inside.1990
  %descriptor.range.valid.1993 = and i1 %descriptor.range.inside.1994, %descriptor.payload.inside.1991
  %descriptor.type.valid.1995 = icmp eq i32 1, 1
  %descriptor.valid.1996 = and i1 %descriptor.range.valid.1993, %descriptor.type.valid.1995
  br i1 %descriptor.valid.1996, label %descriptor.valid.1997, label %descriptor.invalid.1998
descriptor.invalid.1998:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1997:
  %descriptor.initialized.status.1999 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.1793, i32 8)
  %helper.ok.2000 = icmp eq i32 %descriptor.initialized.status.1999, 0
  br i1 %helper.ok.2000, label %helper.continue.2001, label %frame.failure.0
helper.continue.2001:
  %local.is.active.2002 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2002, label %local.descriptor.active.2003, label %local.descriptor.inactive.2004
local.descriptor.active.2003:
  %local.check.offset.2006 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2007 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2008 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2009 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2010 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2011 = load i32, ptr %context.field.2010, align 4
  %stack.sub.2014 = sub i32 %local.check.owner.end.2009, %local.check.offset.2006
  %descriptor.owner.inside.2012 = icmp ule i32 %local.check.owner.end.2009, %context.value.2011
  %descriptor.offset.inside.2013 = icmp ule i32 %local.check.offset.2006, %local.check.owner.end.2009
  %descriptor.extent.inside.2015 = icmp ule i32 %local.check.extent.2007, %stack.sub.2014
  %descriptor.payload.inside.2016 = icmp ule i32 %local.check.payload.2008, %local.check.extent.2007
  %descriptor.owner.offset.valid.2017 = and i1 %descriptor.owner.inside.2012, %descriptor.offset.inside.2013
  %descriptor.range.inside.2019 = and i1 %descriptor.owner.offset.valid.2017, %descriptor.extent.inside.2015
  %descriptor.range.valid.2018 = and i1 %descriptor.range.inside.2019, %descriptor.payload.inside.2016
  br i1 %descriptor.range.valid.2018, label %descriptor.valid.2020, label %descriptor.invalid.2021
descriptor.invalid.2021:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2020:
  %descriptor.initialized.status.2022 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2006, i32 %local.check.extent.2007)
  %helper.ok.2023 = icmp eq i32 %descriptor.initialized.status.2022, 0
  br i1 %helper.ok.2023, label %helper.continue.2024, label %frame.failure.0
helper.continue.2024:
  br label %local.descriptor.checked.2005
local.descriptor.inactive.2004:
  br label %local.descriptor.checked.2005
local.descriptor.checked.2005:
  %local.is.active.2025 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2025, label %local.descriptor.active.2026, label %local.descriptor.inactive.2027
local.descriptor.active.2026:
  %local.check.offset.2029 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2030 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2031 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2032 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2033 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2034 = load i32, ptr %context.field.2033, align 4
  %stack.sub.2037 = sub i32 %local.check.owner.end.2032, %local.check.offset.2029
  %descriptor.owner.inside.2035 = icmp ule i32 %local.check.owner.end.2032, %context.value.2034
  %descriptor.offset.inside.2036 = icmp ule i32 %local.check.offset.2029, %local.check.owner.end.2032
  %descriptor.extent.inside.2038 = icmp ule i32 %local.check.extent.2030, %stack.sub.2037
  %descriptor.payload.inside.2039 = icmp ule i32 %local.check.payload.2031, %local.check.extent.2030
  %descriptor.owner.offset.valid.2040 = and i1 %descriptor.owner.inside.2035, %descriptor.offset.inside.2036
  %descriptor.range.inside.2042 = and i1 %descriptor.owner.offset.valid.2040, %descriptor.extent.inside.2038
  %descriptor.range.valid.2041 = and i1 %descriptor.range.inside.2042, %descriptor.payload.inside.2039
  br i1 %descriptor.range.valid.2041, label %descriptor.valid.2043, label %descriptor.invalid.2044
descriptor.invalid.2044:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2043:
  %descriptor.initialized.status.2045 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2029, i32 %local.check.extent.2030)
  %helper.ok.2046 = icmp eq i32 %descriptor.initialized.status.2045, 0
  br i1 %helper.ok.2046, label %helper.continue.2047, label %frame.failure.0
helper.continue.2047:
  br label %local.descriptor.checked.2028
local.descriptor.inactive.2027:
  br label %local.descriptor.checked.2028
local.descriptor.checked.2028:
  %local.is.active.2048 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2048, label %local.descriptor.active.2049, label %local.descriptor.inactive.2050
local.descriptor.active.2049:
  %local.check.offset.2052 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2053 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2054 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2055 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2056 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2057 = load i32, ptr %context.field.2056, align 4
  %stack.sub.2060 = sub i32 %local.check.owner.end.2055, %local.check.offset.2052
  %descriptor.owner.inside.2058 = icmp ule i32 %local.check.owner.end.2055, %context.value.2057
  %descriptor.offset.inside.2059 = icmp ule i32 %local.check.offset.2052, %local.check.owner.end.2055
  %descriptor.extent.inside.2061 = icmp ule i32 %local.check.extent.2053, %stack.sub.2060
  %descriptor.payload.inside.2062 = icmp ule i32 %local.check.payload.2054, %local.check.extent.2053
  %descriptor.owner.offset.valid.2063 = and i1 %descriptor.owner.inside.2058, %descriptor.offset.inside.2059
  %descriptor.range.inside.2065 = and i1 %descriptor.owner.offset.valid.2063, %descriptor.extent.inside.2061
  %descriptor.range.valid.2064 = and i1 %descriptor.range.inside.2065, %descriptor.payload.inside.2062
  br i1 %descriptor.range.valid.2064, label %descriptor.valid.2066, label %descriptor.invalid.2067
descriptor.invalid.2067:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2066:
  %descriptor.initialized.status.2068 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2052, i32 %local.check.extent.2053)
  %helper.ok.2069 = icmp eq i32 %descriptor.initialized.status.2068, 0
  br i1 %helper.ok.2069, label %helper.continue.2070, label %frame.failure.0
helper.continue.2070:
  br label %local.descriptor.checked.2051
local.descriptor.inactive.2050:
  br label %local.descriptor.checked.2051
local.descriptor.checked.2051:
  %local.is.active.2071 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2071, label %local.descriptor.active.2072, label %local.descriptor.inactive.2073
local.descriptor.active.2072:
  %local.check.offset.2075 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2076 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2077 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2078 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2079 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2080 = load i32, ptr %context.field.2079, align 4
  %stack.sub.2083 = sub i32 %local.check.owner.end.2078, %local.check.offset.2075
  %descriptor.owner.inside.2081 = icmp ule i32 %local.check.owner.end.2078, %context.value.2080
  %descriptor.offset.inside.2082 = icmp ule i32 %local.check.offset.2075, %local.check.owner.end.2078
  %descriptor.extent.inside.2084 = icmp ule i32 %local.check.extent.2076, %stack.sub.2083
  %descriptor.payload.inside.2085 = icmp ule i32 %local.check.payload.2077, %local.check.extent.2076
  %descriptor.owner.offset.valid.2086 = and i1 %descriptor.owner.inside.2081, %descriptor.offset.inside.2082
  %descriptor.range.inside.2088 = and i1 %descriptor.owner.offset.valid.2086, %descriptor.extent.inside.2084
  %descriptor.range.valid.2087 = and i1 %descriptor.range.inside.2088, %descriptor.payload.inside.2085
  br i1 %descriptor.range.valid.2087, label %descriptor.valid.2089, label %descriptor.invalid.2090
descriptor.invalid.2090:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2089:
  %descriptor.initialized.status.2091 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2075, i32 %local.check.extent.2076)
  %helper.ok.2092 = icmp eq i32 %descriptor.initialized.status.2091, 0
  br i1 %helper.ok.2092, label %helper.continue.2093, label %frame.failure.0
helper.continue.2093:
  br label %local.descriptor.checked.2074
local.descriptor.inactive.2073:
  br label %local.descriptor.checked.2074
local.descriptor.checked.2074:
  %local.is.active.2094 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2094, label %local.descriptor.active.2095, label %local.descriptor.inactive.2096
local.descriptor.active.2095:
  %local.check.offset.2098 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2099 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2100 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2101 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2103 = load i32, ptr %context.field.2102, align 4
  %stack.sub.2106 = sub i32 %local.check.owner.end.2101, %local.check.offset.2098
  %descriptor.owner.inside.2104 = icmp ule i32 %local.check.owner.end.2101, %context.value.2103
  %descriptor.offset.inside.2105 = icmp ule i32 %local.check.offset.2098, %local.check.owner.end.2101
  %descriptor.extent.inside.2107 = icmp ule i32 %local.check.extent.2099, %stack.sub.2106
  %descriptor.payload.inside.2108 = icmp ule i32 %local.check.payload.2100, %local.check.extent.2099
  %descriptor.owner.offset.valid.2109 = and i1 %descriptor.owner.inside.2104, %descriptor.offset.inside.2105
  %descriptor.range.inside.2111 = and i1 %descriptor.owner.offset.valid.2109, %descriptor.extent.inside.2107
  %descriptor.range.valid.2110 = and i1 %descriptor.range.inside.2111, %descriptor.payload.inside.2108
  br i1 %descriptor.range.valid.2110, label %descriptor.valid.2112, label %descriptor.invalid.2113
descriptor.invalid.2113:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2112:
  %descriptor.initialized.status.2114 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2098, i32 %local.check.extent.2099)
  %helper.ok.2115 = icmp eq i32 %descriptor.initialized.status.2114, 0
  br i1 %helper.ok.2115, label %helper.continue.2116, label %frame.failure.0
helper.continue.2116:
  br label %local.descriptor.checked.2097
local.descriptor.inactive.2096:
  br label %local.descriptor.checked.2097
local.descriptor.checked.2097:
  %local.is.active.2117 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2117, label %local.descriptor.active.2118, label %local.descriptor.inactive.2119
local.descriptor.active.2118:
  %local.check.offset.2121 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2122 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2123 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2124 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2125 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2126 = load i32, ptr %context.field.2125, align 4
  %stack.sub.2129 = sub i32 %local.check.owner.end.2124, %local.check.offset.2121
  %descriptor.owner.inside.2127 = icmp ule i32 %local.check.owner.end.2124, %context.value.2126
  %descriptor.offset.inside.2128 = icmp ule i32 %local.check.offset.2121, %local.check.owner.end.2124
  %descriptor.extent.inside.2130 = icmp ule i32 %local.check.extent.2122, %stack.sub.2129
  %descriptor.payload.inside.2131 = icmp ule i32 %local.check.payload.2123, %local.check.extent.2122
  %descriptor.owner.offset.valid.2132 = and i1 %descriptor.owner.inside.2127, %descriptor.offset.inside.2128
  %descriptor.range.inside.2134 = and i1 %descriptor.owner.offset.valid.2132, %descriptor.extent.inside.2130
  %descriptor.range.valid.2133 = and i1 %descriptor.range.inside.2134, %descriptor.payload.inside.2131
  br i1 %descriptor.range.valid.2133, label %descriptor.valid.2135, label %descriptor.invalid.2136
descriptor.invalid.2136:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2135:
  %descriptor.initialized.status.2137 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2121, i32 %local.check.extent.2122)
  %helper.ok.2138 = icmp eq i32 %descriptor.initialized.status.2137, 0
  br i1 %helper.ok.2138, label %helper.continue.2139, label %frame.failure.0
helper.continue.2139:
  br label %local.descriptor.checked.2120
local.descriptor.inactive.2119:
  br label %local.descriptor.checked.2120
local.descriptor.checked.2120:
  %local.is.active.2140 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.2140, label %local.descriptor.active.2141, label %local.descriptor.inactive.2142
local.descriptor.active.2141:
  %local.check.offset.2144 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.2145 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.2146 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.2147 = load i32, ptr %local.owner.end.42, align 4
  %context.field.2148 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2149 = load i32, ptr %context.field.2148, align 4
  %stack.sub.2152 = sub i32 %local.check.owner.end.2147, %local.check.offset.2144
  %descriptor.owner.inside.2150 = icmp ule i32 %local.check.owner.end.2147, %context.value.2149
  %descriptor.offset.inside.2151 = icmp ule i32 %local.check.offset.2144, %local.check.owner.end.2147
  %descriptor.extent.inside.2153 = icmp ule i32 %local.check.extent.2145, %stack.sub.2152
  %descriptor.payload.inside.2154 = icmp ule i32 %local.check.payload.2146, %local.check.extent.2145
  %descriptor.owner.offset.valid.2155 = and i1 %descriptor.owner.inside.2150, %descriptor.offset.inside.2151
  %descriptor.range.inside.2157 = and i1 %descriptor.owner.offset.valid.2155, %descriptor.extent.inside.2153
  %descriptor.range.valid.2156 = and i1 %descriptor.range.inside.2157, %descriptor.payload.inside.2154
  br i1 %descriptor.range.valid.2156, label %descriptor.valid.2158, label %descriptor.invalid.2159
descriptor.invalid.2159:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2158:
  %descriptor.initialized.status.2160 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2144, i32 %local.check.extent.2145)
  %helper.ok.2161 = icmp eq i32 %descriptor.initialized.status.2160, 0
  br i1 %helper.ok.2161, label %helper.continue.2162, label %frame.failure.0
helper.continue.2162:
  br label %local.descriptor.checked.2143
local.descriptor.inactive.2142:
  br label %local.descriptor.checked.2143
local.descriptor.checked.2143:
  br label %if.join.1344
if.else.1343:
  %step.status.2163 = call i32 @al_owning_charge_step(ptr %ctx, i32 49)
  %helper.ok.2164 = icmp eq i32 %step.status.2163, 0
  br i1 %helper.ok.2164, label %helper.continue.2165, label %frame.failure.0
helper.continue.2165:
  %context.field.2166 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2167 = load i32, ptr %context.field.2166, align 4
  %step.status.2168 = call i32 @al_owning_charge_step(ptr %ctx, i32 50)
  %helper.ok.2169 = icmp eq i32 %step.status.2168, 0
  br i1 %helper.ok.2169, label %helper.continue.2170, label %frame.failure.0
helper.continue.2170:
  %context.field.2171 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2172 = load i32, ptr %context.field.2171, align 4
  %stack.offset.2173 = add i32 %context.value.2172, 8
  %reserve.status.2174 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.2173, i32 51)
  %reserve.ok.2175 = icmp eq i32 %reserve.status.2174, 0
  br i1 %reserve.ok.2175, label %reserve.continue.2176, label %frame.failure.0
reserve.continue.2176:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.2172, i64 0, i32 1)
  %context.field.2177 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2178 = load i32, ptr %context.field.2177, align 4
  %runtime.ok.2179 = icmp eq i32 %context.value.2178, 0
  br i1 %runtime.ok.2179, label %runtime.continue.2180, label %frame.failure.0
runtime.continue.2180:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.2181 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2182 = load i32, ptr %context.field.2181, align 4
  %runtime.ok.2183 = icmp eq i32 %context.value.2182, 0
  br i1 %runtime.ok.2183, label %runtime.continue.2184, label %frame.failure.0
runtime.continue.2184:
  %context.field.2185 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2186 = load i32, ptr %context.field.2185, align 4
  %stack.sub.2189 = sub i32 %stack.offset.2173, %context.value.2172
  %descriptor.owner.inside.2187 = icmp ule i32 %stack.offset.2173, %context.value.2186
  %descriptor.offset.inside.2188 = icmp ule i32 %context.value.2172, %stack.offset.2173
  %descriptor.extent.inside.2190 = icmp ule i32 8, %stack.sub.2189
  %descriptor.payload.inside.2191 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.2192 = and i1 %descriptor.owner.inside.2187, %descriptor.offset.inside.2188
  %descriptor.range.inside.2194 = and i1 %descriptor.owner.offset.valid.2192, %descriptor.extent.inside.2190
  %descriptor.range.valid.2193 = and i1 %descriptor.range.inside.2194, %descriptor.payload.inside.2191
  %descriptor.type.valid.2195 = icmp eq i32 1, 1
  %descriptor.valid.2196 = and i1 %descriptor.range.valid.2193, %descriptor.type.valid.2195
  br i1 %descriptor.valid.2196, label %descriptor.valid.2197, label %descriptor.invalid.2198
descriptor.invalid.2198:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2197:
  %descriptor.initialized.status.2199 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.2172, i32 8)
  %helper.ok.2200 = icmp eq i32 %descriptor.initialized.status.2199, 0
  br i1 %helper.ok.2200, label %helper.continue.2201, label %frame.failure.0
helper.continue.2201:
  %local.is.active.2202 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2202, label %local.descriptor.active.2203, label %local.descriptor.inactive.2204
local.descriptor.active.2203:
  %local.check.offset.2206 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2207 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2208 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2209 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2210 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2211 = load i32, ptr %context.field.2210, align 4
  %stack.sub.2214 = sub i32 %local.check.owner.end.2209, %local.check.offset.2206
  %descriptor.owner.inside.2212 = icmp ule i32 %local.check.owner.end.2209, %context.value.2211
  %descriptor.offset.inside.2213 = icmp ule i32 %local.check.offset.2206, %local.check.owner.end.2209
  %descriptor.extent.inside.2215 = icmp ule i32 %local.check.extent.2207, %stack.sub.2214
  %descriptor.payload.inside.2216 = icmp ule i32 %local.check.payload.2208, %local.check.extent.2207
  %descriptor.owner.offset.valid.2217 = and i1 %descriptor.owner.inside.2212, %descriptor.offset.inside.2213
  %descriptor.range.inside.2219 = and i1 %descriptor.owner.offset.valid.2217, %descriptor.extent.inside.2215
  %descriptor.range.valid.2218 = and i1 %descriptor.range.inside.2219, %descriptor.payload.inside.2216
  br i1 %descriptor.range.valid.2218, label %descriptor.valid.2220, label %descriptor.invalid.2221
descriptor.invalid.2221:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2220:
  %descriptor.initialized.status.2222 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2206, i32 %local.check.extent.2207)
  %helper.ok.2223 = icmp eq i32 %descriptor.initialized.status.2222, 0
  br i1 %helper.ok.2223, label %helper.continue.2224, label %frame.failure.0
helper.continue.2224:
  br label %local.descriptor.checked.2205
local.descriptor.inactive.2204:
  br label %local.descriptor.checked.2205
local.descriptor.checked.2205:
  %local.is.active.2225 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2225, label %local.descriptor.active.2226, label %local.descriptor.inactive.2227
local.descriptor.active.2226:
  %local.check.offset.2229 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2230 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2231 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2232 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2233 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2234 = load i32, ptr %context.field.2233, align 4
  %stack.sub.2237 = sub i32 %local.check.owner.end.2232, %local.check.offset.2229
  %descriptor.owner.inside.2235 = icmp ule i32 %local.check.owner.end.2232, %context.value.2234
  %descriptor.offset.inside.2236 = icmp ule i32 %local.check.offset.2229, %local.check.owner.end.2232
  %descriptor.extent.inside.2238 = icmp ule i32 %local.check.extent.2230, %stack.sub.2237
  %descriptor.payload.inside.2239 = icmp ule i32 %local.check.payload.2231, %local.check.extent.2230
  %descriptor.owner.offset.valid.2240 = and i1 %descriptor.owner.inside.2235, %descriptor.offset.inside.2236
  %descriptor.range.inside.2242 = and i1 %descriptor.owner.offset.valid.2240, %descriptor.extent.inside.2238
  %descriptor.range.valid.2241 = and i1 %descriptor.range.inside.2242, %descriptor.payload.inside.2239
  br i1 %descriptor.range.valid.2241, label %descriptor.valid.2243, label %descriptor.invalid.2244
descriptor.invalid.2244:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2243:
  %descriptor.initialized.status.2245 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2229, i32 %local.check.extent.2230)
  %helper.ok.2246 = icmp eq i32 %descriptor.initialized.status.2245, 0
  br i1 %helper.ok.2246, label %helper.continue.2247, label %frame.failure.0
helper.continue.2247:
  br label %local.descriptor.checked.2228
local.descriptor.inactive.2227:
  br label %local.descriptor.checked.2228
local.descriptor.checked.2228:
  %local.is.active.2248 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2248, label %local.descriptor.active.2249, label %local.descriptor.inactive.2250
local.descriptor.active.2249:
  %local.check.offset.2252 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2253 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2254 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2255 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2256 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2257 = load i32, ptr %context.field.2256, align 4
  %stack.sub.2260 = sub i32 %local.check.owner.end.2255, %local.check.offset.2252
  %descriptor.owner.inside.2258 = icmp ule i32 %local.check.owner.end.2255, %context.value.2257
  %descriptor.offset.inside.2259 = icmp ule i32 %local.check.offset.2252, %local.check.owner.end.2255
  %descriptor.extent.inside.2261 = icmp ule i32 %local.check.extent.2253, %stack.sub.2260
  %descriptor.payload.inside.2262 = icmp ule i32 %local.check.payload.2254, %local.check.extent.2253
  %descriptor.owner.offset.valid.2263 = and i1 %descriptor.owner.inside.2258, %descriptor.offset.inside.2259
  %descriptor.range.inside.2265 = and i1 %descriptor.owner.offset.valid.2263, %descriptor.extent.inside.2261
  %descriptor.range.valid.2264 = and i1 %descriptor.range.inside.2265, %descriptor.payload.inside.2262
  br i1 %descriptor.range.valid.2264, label %descriptor.valid.2266, label %descriptor.invalid.2267
descriptor.invalid.2267:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2266:
  %descriptor.initialized.status.2268 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2252, i32 %local.check.extent.2253)
  %helper.ok.2269 = icmp eq i32 %descriptor.initialized.status.2268, 0
  br i1 %helper.ok.2269, label %helper.continue.2270, label %frame.failure.0
helper.continue.2270:
  br label %local.descriptor.checked.2251
local.descriptor.inactive.2250:
  br label %local.descriptor.checked.2251
local.descriptor.checked.2251:
  %local.is.active.2271 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2271, label %local.descriptor.active.2272, label %local.descriptor.inactive.2273
local.descriptor.active.2272:
  %local.check.offset.2275 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2276 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2277 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2278 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2279 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2280 = load i32, ptr %context.field.2279, align 4
  %stack.sub.2283 = sub i32 %local.check.owner.end.2278, %local.check.offset.2275
  %descriptor.owner.inside.2281 = icmp ule i32 %local.check.owner.end.2278, %context.value.2280
  %descriptor.offset.inside.2282 = icmp ule i32 %local.check.offset.2275, %local.check.owner.end.2278
  %descriptor.extent.inside.2284 = icmp ule i32 %local.check.extent.2276, %stack.sub.2283
  %descriptor.payload.inside.2285 = icmp ule i32 %local.check.payload.2277, %local.check.extent.2276
  %descriptor.owner.offset.valid.2286 = and i1 %descriptor.owner.inside.2281, %descriptor.offset.inside.2282
  %descriptor.range.inside.2288 = and i1 %descriptor.owner.offset.valid.2286, %descriptor.extent.inside.2284
  %descriptor.range.valid.2287 = and i1 %descriptor.range.inside.2288, %descriptor.payload.inside.2285
  br i1 %descriptor.range.valid.2287, label %descriptor.valid.2289, label %descriptor.invalid.2290
descriptor.invalid.2290:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2289:
  %descriptor.initialized.status.2291 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2275, i32 %local.check.extent.2276)
  %helper.ok.2292 = icmp eq i32 %descriptor.initialized.status.2291, 0
  br i1 %helper.ok.2292, label %helper.continue.2293, label %frame.failure.0
helper.continue.2293:
  br label %local.descriptor.checked.2274
local.descriptor.inactive.2273:
  br label %local.descriptor.checked.2274
local.descriptor.checked.2274:
  %local.is.active.2294 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2294, label %local.descriptor.active.2295, label %local.descriptor.inactive.2296
local.descriptor.active.2295:
  %local.check.offset.2298 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2299 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2300 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2301 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2302 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2303 = load i32, ptr %context.field.2302, align 4
  %stack.sub.2306 = sub i32 %local.check.owner.end.2301, %local.check.offset.2298
  %descriptor.owner.inside.2304 = icmp ule i32 %local.check.owner.end.2301, %context.value.2303
  %descriptor.offset.inside.2305 = icmp ule i32 %local.check.offset.2298, %local.check.owner.end.2301
  %descriptor.extent.inside.2307 = icmp ule i32 %local.check.extent.2299, %stack.sub.2306
  %descriptor.payload.inside.2308 = icmp ule i32 %local.check.payload.2300, %local.check.extent.2299
  %descriptor.owner.offset.valid.2309 = and i1 %descriptor.owner.inside.2304, %descriptor.offset.inside.2305
  %descriptor.range.inside.2311 = and i1 %descriptor.owner.offset.valid.2309, %descriptor.extent.inside.2307
  %descriptor.range.valid.2310 = and i1 %descriptor.range.inside.2311, %descriptor.payload.inside.2308
  br i1 %descriptor.range.valid.2310, label %descriptor.valid.2312, label %descriptor.invalid.2313
descriptor.invalid.2313:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2312:
  %descriptor.initialized.status.2314 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2298, i32 %local.check.extent.2299)
  %helper.ok.2315 = icmp eq i32 %descriptor.initialized.status.2314, 0
  br i1 %helper.ok.2315, label %helper.continue.2316, label %frame.failure.0
helper.continue.2316:
  br label %local.descriptor.checked.2297
local.descriptor.inactive.2296:
  br label %local.descriptor.checked.2297
local.descriptor.checked.2297:
  %local.is.active.2317 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2317, label %local.descriptor.active.2318, label %local.descriptor.inactive.2319
local.descriptor.active.2318:
  %local.check.offset.2321 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2322 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2323 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2324 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2325 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2326 = load i32, ptr %context.field.2325, align 4
  %stack.sub.2329 = sub i32 %local.check.owner.end.2324, %local.check.offset.2321
  %descriptor.owner.inside.2327 = icmp ule i32 %local.check.owner.end.2324, %context.value.2326
  %descriptor.offset.inside.2328 = icmp ule i32 %local.check.offset.2321, %local.check.owner.end.2324
  %descriptor.extent.inside.2330 = icmp ule i32 %local.check.extent.2322, %stack.sub.2329
  %descriptor.payload.inside.2331 = icmp ule i32 %local.check.payload.2323, %local.check.extent.2322
  %descriptor.owner.offset.valid.2332 = and i1 %descriptor.owner.inside.2327, %descriptor.offset.inside.2328
  %descriptor.range.inside.2334 = and i1 %descriptor.owner.offset.valid.2332, %descriptor.extent.inside.2330
  %descriptor.range.valid.2333 = and i1 %descriptor.range.inside.2334, %descriptor.payload.inside.2331
  br i1 %descriptor.range.valid.2333, label %descriptor.valid.2335, label %descriptor.invalid.2336
descriptor.invalid.2336:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2335:
  %descriptor.initialized.status.2337 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2321, i32 %local.check.extent.2322)
  %helper.ok.2338 = icmp eq i32 %descriptor.initialized.status.2337, 0
  br i1 %helper.ok.2338, label %helper.continue.2339, label %frame.failure.0
helper.continue.2339:
  br label %local.descriptor.checked.2320
local.descriptor.inactive.2319:
  br label %local.descriptor.checked.2320
local.descriptor.checked.2320:
  %local.is.active.2340 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.2340, label %local.descriptor.active.2341, label %local.descriptor.inactive.2342
local.descriptor.active.2341:
  %local.check.offset.2344 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.2345 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.2346 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.2347 = load i32, ptr %local.owner.end.42, align 4
  %context.field.2348 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2349 = load i32, ptr %context.field.2348, align 4
  %stack.sub.2352 = sub i32 %local.check.owner.end.2347, %local.check.offset.2344
  %descriptor.owner.inside.2350 = icmp ule i32 %local.check.owner.end.2347, %context.value.2349
  %descriptor.offset.inside.2351 = icmp ule i32 %local.check.offset.2344, %local.check.owner.end.2347
  %descriptor.extent.inside.2353 = icmp ule i32 %local.check.extent.2345, %stack.sub.2352
  %descriptor.payload.inside.2354 = icmp ule i32 %local.check.payload.2346, %local.check.extent.2345
  %descriptor.owner.offset.valid.2355 = and i1 %descriptor.owner.inside.2350, %descriptor.offset.inside.2351
  %descriptor.range.inside.2357 = and i1 %descriptor.owner.offset.valid.2355, %descriptor.extent.inside.2353
  %descriptor.range.valid.2356 = and i1 %descriptor.range.inside.2357, %descriptor.payload.inside.2354
  br i1 %descriptor.range.valid.2356, label %descriptor.valid.2358, label %descriptor.invalid.2359
descriptor.invalid.2359:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2358:
  %descriptor.initialized.status.2360 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2344, i32 %local.check.extent.2345)
  %helper.ok.2361 = icmp eq i32 %descriptor.initialized.status.2360, 0
  br i1 %helper.ok.2361, label %helper.continue.2362, label %frame.failure.0
helper.continue.2362:
  br label %local.descriptor.checked.2343
local.descriptor.inactive.2342:
  br label %local.descriptor.checked.2343
local.descriptor.checked.2343:
  %context.field.2363 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2364 = load i32, ptr %context.field.2363, align 4
  %stack.sub.2367 = sub i32 %stack.offset.2173, %context.value.2172
  %descriptor.owner.inside.2365 = icmp ule i32 %stack.offset.2173, %context.value.2364
  %descriptor.offset.inside.2366 = icmp ule i32 %context.value.2172, %stack.offset.2173
  %descriptor.extent.inside.2368 = icmp ule i32 8, %stack.sub.2367
  %descriptor.payload.inside.2369 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.2370 = and i1 %descriptor.owner.inside.2365, %descriptor.offset.inside.2366
  %descriptor.range.inside.2372 = and i1 %descriptor.owner.offset.valid.2370, %descriptor.extent.inside.2368
  %descriptor.range.valid.2371 = and i1 %descriptor.range.inside.2372, %descriptor.payload.inside.2369
  %descriptor.type.valid.2373 = icmp eq i32 1, 1
  %descriptor.valid.2374 = and i1 %descriptor.range.valid.2371, %descriptor.type.valid.2373
  br i1 %descriptor.valid.2374, label %descriptor.valid.2375, label %descriptor.invalid.2376
descriptor.invalid.2376:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2375:
  %descriptor.initialized.status.2377 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.2172, i32 8)
  %helper.ok.2378 = icmp eq i32 %descriptor.initialized.status.2377, 0
  br i1 %helper.ok.2378, label %helper.continue.2379, label %frame.failure.0
helper.continue.2379:
  %local.is.active.2380 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2380, label %local.descriptor.active.2381, label %local.descriptor.inactive.2382
local.descriptor.active.2381:
  %local.check.offset.2384 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2385 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2386 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2387 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2388 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2389 = load i32, ptr %context.field.2388, align 4
  %stack.sub.2392 = sub i32 %local.check.owner.end.2387, %local.check.offset.2384
  %descriptor.owner.inside.2390 = icmp ule i32 %local.check.owner.end.2387, %context.value.2389
  %descriptor.offset.inside.2391 = icmp ule i32 %local.check.offset.2384, %local.check.owner.end.2387
  %descriptor.extent.inside.2393 = icmp ule i32 %local.check.extent.2385, %stack.sub.2392
  %descriptor.payload.inside.2394 = icmp ule i32 %local.check.payload.2386, %local.check.extent.2385
  %descriptor.owner.offset.valid.2395 = and i1 %descriptor.owner.inside.2390, %descriptor.offset.inside.2391
  %descriptor.range.inside.2397 = and i1 %descriptor.owner.offset.valid.2395, %descriptor.extent.inside.2393
  %descriptor.range.valid.2396 = and i1 %descriptor.range.inside.2397, %descriptor.payload.inside.2394
  br i1 %descriptor.range.valid.2396, label %descriptor.valid.2398, label %descriptor.invalid.2399
descriptor.invalid.2399:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2398:
  %descriptor.initialized.status.2400 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2384, i32 %local.check.extent.2385)
  %helper.ok.2401 = icmp eq i32 %descriptor.initialized.status.2400, 0
  br i1 %helper.ok.2401, label %helper.continue.2402, label %frame.failure.0
helper.continue.2402:
  br label %local.descriptor.checked.2383
local.descriptor.inactive.2382:
  br label %local.descriptor.checked.2383
local.descriptor.checked.2383:
  %local.is.active.2403 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2403, label %local.descriptor.active.2404, label %local.descriptor.inactive.2405
local.descriptor.active.2404:
  %local.check.offset.2407 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2408 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2409 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2410 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2411 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2412 = load i32, ptr %context.field.2411, align 4
  %stack.sub.2415 = sub i32 %local.check.owner.end.2410, %local.check.offset.2407
  %descriptor.owner.inside.2413 = icmp ule i32 %local.check.owner.end.2410, %context.value.2412
  %descriptor.offset.inside.2414 = icmp ule i32 %local.check.offset.2407, %local.check.owner.end.2410
  %descriptor.extent.inside.2416 = icmp ule i32 %local.check.extent.2408, %stack.sub.2415
  %descriptor.payload.inside.2417 = icmp ule i32 %local.check.payload.2409, %local.check.extent.2408
  %descriptor.owner.offset.valid.2418 = and i1 %descriptor.owner.inside.2413, %descriptor.offset.inside.2414
  %descriptor.range.inside.2420 = and i1 %descriptor.owner.offset.valid.2418, %descriptor.extent.inside.2416
  %descriptor.range.valid.2419 = and i1 %descriptor.range.inside.2420, %descriptor.payload.inside.2417
  br i1 %descriptor.range.valid.2419, label %descriptor.valid.2421, label %descriptor.invalid.2422
descriptor.invalid.2422:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2421:
  %descriptor.initialized.status.2423 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2407, i32 %local.check.extent.2408)
  %helper.ok.2424 = icmp eq i32 %descriptor.initialized.status.2423, 0
  br i1 %helper.ok.2424, label %helper.continue.2425, label %frame.failure.0
helper.continue.2425:
  br label %local.descriptor.checked.2406
local.descriptor.inactive.2405:
  br label %local.descriptor.checked.2406
local.descriptor.checked.2406:
  %local.is.active.2426 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2426, label %local.descriptor.active.2427, label %local.descriptor.inactive.2428
local.descriptor.active.2427:
  %local.check.offset.2430 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2431 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2432 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2433 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2434 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2435 = load i32, ptr %context.field.2434, align 4
  %stack.sub.2438 = sub i32 %local.check.owner.end.2433, %local.check.offset.2430
  %descriptor.owner.inside.2436 = icmp ule i32 %local.check.owner.end.2433, %context.value.2435
  %descriptor.offset.inside.2437 = icmp ule i32 %local.check.offset.2430, %local.check.owner.end.2433
  %descriptor.extent.inside.2439 = icmp ule i32 %local.check.extent.2431, %stack.sub.2438
  %descriptor.payload.inside.2440 = icmp ule i32 %local.check.payload.2432, %local.check.extent.2431
  %descriptor.owner.offset.valid.2441 = and i1 %descriptor.owner.inside.2436, %descriptor.offset.inside.2437
  %descriptor.range.inside.2443 = and i1 %descriptor.owner.offset.valid.2441, %descriptor.extent.inside.2439
  %descriptor.range.valid.2442 = and i1 %descriptor.range.inside.2443, %descriptor.payload.inside.2440
  br i1 %descriptor.range.valid.2442, label %descriptor.valid.2444, label %descriptor.invalid.2445
descriptor.invalid.2445:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2444:
  %descriptor.initialized.status.2446 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2430, i32 %local.check.extent.2431)
  %helper.ok.2447 = icmp eq i32 %descriptor.initialized.status.2446, 0
  br i1 %helper.ok.2447, label %helper.continue.2448, label %frame.failure.0
helper.continue.2448:
  br label %local.descriptor.checked.2429
local.descriptor.inactive.2428:
  br label %local.descriptor.checked.2429
local.descriptor.checked.2429:
  %local.is.active.2449 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2449, label %local.descriptor.active.2450, label %local.descriptor.inactive.2451
local.descriptor.active.2450:
  %local.check.offset.2453 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2454 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2455 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2456 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2457 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2458 = load i32, ptr %context.field.2457, align 4
  %stack.sub.2461 = sub i32 %local.check.owner.end.2456, %local.check.offset.2453
  %descriptor.owner.inside.2459 = icmp ule i32 %local.check.owner.end.2456, %context.value.2458
  %descriptor.offset.inside.2460 = icmp ule i32 %local.check.offset.2453, %local.check.owner.end.2456
  %descriptor.extent.inside.2462 = icmp ule i32 %local.check.extent.2454, %stack.sub.2461
  %descriptor.payload.inside.2463 = icmp ule i32 %local.check.payload.2455, %local.check.extent.2454
  %descriptor.owner.offset.valid.2464 = and i1 %descriptor.owner.inside.2459, %descriptor.offset.inside.2460
  %descriptor.range.inside.2466 = and i1 %descriptor.owner.offset.valid.2464, %descriptor.extent.inside.2462
  %descriptor.range.valid.2465 = and i1 %descriptor.range.inside.2466, %descriptor.payload.inside.2463
  br i1 %descriptor.range.valid.2465, label %descriptor.valid.2467, label %descriptor.invalid.2468
descriptor.invalid.2468:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2467:
  %descriptor.initialized.status.2469 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2453, i32 %local.check.extent.2454)
  %helper.ok.2470 = icmp eq i32 %descriptor.initialized.status.2469, 0
  br i1 %helper.ok.2470, label %helper.continue.2471, label %frame.failure.0
helper.continue.2471:
  br label %local.descriptor.checked.2452
local.descriptor.inactive.2451:
  br label %local.descriptor.checked.2452
local.descriptor.checked.2452:
  %local.is.active.2472 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2472, label %local.descriptor.active.2473, label %local.descriptor.inactive.2474
local.descriptor.active.2473:
  %local.check.offset.2476 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2477 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2478 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2479 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2480 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2481 = load i32, ptr %context.field.2480, align 4
  %stack.sub.2484 = sub i32 %local.check.owner.end.2479, %local.check.offset.2476
  %descriptor.owner.inside.2482 = icmp ule i32 %local.check.owner.end.2479, %context.value.2481
  %descriptor.offset.inside.2483 = icmp ule i32 %local.check.offset.2476, %local.check.owner.end.2479
  %descriptor.extent.inside.2485 = icmp ule i32 %local.check.extent.2477, %stack.sub.2484
  %descriptor.payload.inside.2486 = icmp ule i32 %local.check.payload.2478, %local.check.extent.2477
  %descriptor.owner.offset.valid.2487 = and i1 %descriptor.owner.inside.2482, %descriptor.offset.inside.2483
  %descriptor.range.inside.2489 = and i1 %descriptor.owner.offset.valid.2487, %descriptor.extent.inside.2485
  %descriptor.range.valid.2488 = and i1 %descriptor.range.inside.2489, %descriptor.payload.inside.2486
  br i1 %descriptor.range.valid.2488, label %descriptor.valid.2490, label %descriptor.invalid.2491
descriptor.invalid.2491:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2490:
  %descriptor.initialized.status.2492 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2476, i32 %local.check.extent.2477)
  %helper.ok.2493 = icmp eq i32 %descriptor.initialized.status.2492, 0
  br i1 %helper.ok.2493, label %helper.continue.2494, label %frame.failure.0
helper.continue.2494:
  br label %local.descriptor.checked.2475
local.descriptor.inactive.2474:
  br label %local.descriptor.checked.2475
local.descriptor.checked.2475:
  %local.is.active.2495 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2495, label %local.descriptor.active.2496, label %local.descriptor.inactive.2497
local.descriptor.active.2496:
  %local.check.offset.2499 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2500 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2501 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2502 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2503 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2504 = load i32, ptr %context.field.2503, align 4
  %stack.sub.2507 = sub i32 %local.check.owner.end.2502, %local.check.offset.2499
  %descriptor.owner.inside.2505 = icmp ule i32 %local.check.owner.end.2502, %context.value.2504
  %descriptor.offset.inside.2506 = icmp ule i32 %local.check.offset.2499, %local.check.owner.end.2502
  %descriptor.extent.inside.2508 = icmp ule i32 %local.check.extent.2500, %stack.sub.2507
  %descriptor.payload.inside.2509 = icmp ule i32 %local.check.payload.2501, %local.check.extent.2500
  %descriptor.owner.offset.valid.2510 = and i1 %descriptor.owner.inside.2505, %descriptor.offset.inside.2506
  %descriptor.range.inside.2512 = and i1 %descriptor.owner.offset.valid.2510, %descriptor.extent.inside.2508
  %descriptor.range.valid.2511 = and i1 %descriptor.range.inside.2512, %descriptor.payload.inside.2509
  br i1 %descriptor.range.valid.2511, label %descriptor.valid.2513, label %descriptor.invalid.2514
descriptor.invalid.2514:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2513:
  %descriptor.initialized.status.2515 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2499, i32 %local.check.extent.2500)
  %helper.ok.2516 = icmp eq i32 %descriptor.initialized.status.2515, 0
  br i1 %helper.ok.2516, label %helper.continue.2517, label %frame.failure.0
helper.continue.2517:
  br label %local.descriptor.checked.2498
local.descriptor.inactive.2497:
  br label %local.descriptor.checked.2498
local.descriptor.checked.2498:
  %local.is.active.2518 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.2518, label %local.descriptor.active.2519, label %local.descriptor.inactive.2520
local.descriptor.active.2519:
  %local.check.offset.2522 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.2523 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.2524 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.2525 = load i32, ptr %local.owner.end.42, align 4
  %context.field.2526 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2527 = load i32, ptr %context.field.2526, align 4
  %stack.sub.2530 = sub i32 %local.check.owner.end.2525, %local.check.offset.2522
  %descriptor.owner.inside.2528 = icmp ule i32 %local.check.owner.end.2525, %context.value.2527
  %descriptor.offset.inside.2529 = icmp ule i32 %local.check.offset.2522, %local.check.owner.end.2525
  %descriptor.extent.inside.2531 = icmp ule i32 %local.check.extent.2523, %stack.sub.2530
  %descriptor.payload.inside.2532 = icmp ule i32 %local.check.payload.2524, %local.check.extent.2523
  %descriptor.owner.offset.valid.2533 = and i1 %descriptor.owner.inside.2528, %descriptor.offset.inside.2529
  %descriptor.range.inside.2535 = and i1 %descriptor.owner.offset.valid.2533, %descriptor.extent.inside.2531
  %descriptor.range.valid.2534 = and i1 %descriptor.range.inside.2535, %descriptor.payload.inside.2532
  br i1 %descriptor.range.valid.2534, label %descriptor.valid.2536, label %descriptor.invalid.2537
descriptor.invalid.2537:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2536:
  %descriptor.initialized.status.2538 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2522, i32 %local.check.extent.2523)
  %helper.ok.2539 = icmp eq i32 %descriptor.initialized.status.2538, 0
  br i1 %helper.ok.2539, label %helper.continue.2540, label %frame.failure.0
helper.continue.2540:
  br label %local.descriptor.checked.2521
local.descriptor.inactive.2520:
  br label %local.descriptor.checked.2521
local.descriptor.checked.2521:
  br label %if.join.1344
if.join.1344:
  %if.value.offset.2541 = phi i32 [ %context.value.1793, %local.descriptor.checked.2143 ], [ %context.value.2172, %local.descriptor.checked.2521 ]
  %if.value.extent.2542 = phi i32 [ 8, %local.descriptor.checked.2143 ], [ 8, %local.descriptor.checked.2521 ]
  %if.value.payload.2543 = phi i32 [ 8, %local.descriptor.checked.2143 ], [ 8, %local.descriptor.checked.2521 ]
  %if.value.owner.end.2544 = phi i32 [ %stack.offset.1806, %local.descriptor.checked.2143 ], [ %stack.offset.2173, %local.descriptor.checked.2521 ]
  %context.field.2545 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2546 = load i32, ptr %context.field.2545, align 4
  %stack.sub.2549 = sub i32 %if.value.owner.end.2544, %if.value.offset.2541
  %descriptor.owner.inside.2547 = icmp ule i32 %if.value.owner.end.2544, %context.value.2546
  %descriptor.offset.inside.2548 = icmp ule i32 %if.value.offset.2541, %if.value.owner.end.2544
  %descriptor.extent.inside.2550 = icmp ule i32 %if.value.extent.2542, %stack.sub.2549
  %descriptor.payload.inside.2551 = icmp ule i32 %if.value.payload.2543, %if.value.extent.2542
  %descriptor.owner.offset.valid.2552 = and i1 %descriptor.owner.inside.2547, %descriptor.offset.inside.2548
  %descriptor.range.inside.2554 = and i1 %descriptor.owner.offset.valid.2552, %descriptor.extent.inside.2550
  %descriptor.range.valid.2553 = and i1 %descriptor.range.inside.2554, %descriptor.payload.inside.2551
  %descriptor.type.valid.2555 = icmp eq i32 1, 1
  %descriptor.valid.2556 = and i1 %descriptor.range.valid.2553, %descriptor.type.valid.2555
  br i1 %descriptor.valid.2556, label %descriptor.valid.2557, label %descriptor.invalid.2558
descriptor.invalid.2558:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2557:
  %descriptor.initialized.status.2559 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %if.value.offset.2541, i32 %if.value.extent.2542)
  %helper.ok.2560 = icmp eq i32 %descriptor.initialized.status.2559, 0
  br i1 %helper.ok.2560, label %helper.continue.2561, label %frame.failure.0
helper.continue.2561:
  %local.is.active.2562 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2562, label %local.descriptor.active.2563, label %local.descriptor.inactive.2564
local.descriptor.active.2563:
  %local.check.offset.2566 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2567 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2568 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2569 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2570 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2571 = load i32, ptr %context.field.2570, align 4
  %stack.sub.2574 = sub i32 %local.check.owner.end.2569, %local.check.offset.2566
  %descriptor.owner.inside.2572 = icmp ule i32 %local.check.owner.end.2569, %context.value.2571
  %descriptor.offset.inside.2573 = icmp ule i32 %local.check.offset.2566, %local.check.owner.end.2569
  %descriptor.extent.inside.2575 = icmp ule i32 %local.check.extent.2567, %stack.sub.2574
  %descriptor.payload.inside.2576 = icmp ule i32 %local.check.payload.2568, %local.check.extent.2567
  %descriptor.owner.offset.valid.2577 = and i1 %descriptor.owner.inside.2572, %descriptor.offset.inside.2573
  %descriptor.range.inside.2579 = and i1 %descriptor.owner.offset.valid.2577, %descriptor.extent.inside.2575
  %descriptor.range.valid.2578 = and i1 %descriptor.range.inside.2579, %descriptor.payload.inside.2576
  br i1 %descriptor.range.valid.2578, label %descriptor.valid.2580, label %descriptor.invalid.2581
descriptor.invalid.2581:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2580:
  %descriptor.initialized.status.2582 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2566, i32 %local.check.extent.2567)
  %helper.ok.2583 = icmp eq i32 %descriptor.initialized.status.2582, 0
  br i1 %helper.ok.2583, label %helper.continue.2584, label %frame.failure.0
helper.continue.2584:
  br label %local.descriptor.checked.2565
local.descriptor.inactive.2564:
  br label %local.descriptor.checked.2565
local.descriptor.checked.2565:
  %local.is.active.2585 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2585, label %local.descriptor.active.2586, label %local.descriptor.inactive.2587
local.descriptor.active.2586:
  %local.check.offset.2589 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2590 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2591 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2592 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2593 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2594 = load i32, ptr %context.field.2593, align 4
  %stack.sub.2597 = sub i32 %local.check.owner.end.2592, %local.check.offset.2589
  %descriptor.owner.inside.2595 = icmp ule i32 %local.check.owner.end.2592, %context.value.2594
  %descriptor.offset.inside.2596 = icmp ule i32 %local.check.offset.2589, %local.check.owner.end.2592
  %descriptor.extent.inside.2598 = icmp ule i32 %local.check.extent.2590, %stack.sub.2597
  %descriptor.payload.inside.2599 = icmp ule i32 %local.check.payload.2591, %local.check.extent.2590
  %descriptor.owner.offset.valid.2600 = and i1 %descriptor.owner.inside.2595, %descriptor.offset.inside.2596
  %descriptor.range.inside.2602 = and i1 %descriptor.owner.offset.valid.2600, %descriptor.extent.inside.2598
  %descriptor.range.valid.2601 = and i1 %descriptor.range.inside.2602, %descriptor.payload.inside.2599
  br i1 %descriptor.range.valid.2601, label %descriptor.valid.2603, label %descriptor.invalid.2604
descriptor.invalid.2604:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2603:
  %descriptor.initialized.status.2605 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2589, i32 %local.check.extent.2590)
  %helper.ok.2606 = icmp eq i32 %descriptor.initialized.status.2605, 0
  br i1 %helper.ok.2606, label %helper.continue.2607, label %frame.failure.0
helper.continue.2607:
  br label %local.descriptor.checked.2588
local.descriptor.inactive.2587:
  br label %local.descriptor.checked.2588
local.descriptor.checked.2588:
  %local.is.active.2608 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2608, label %local.descriptor.active.2609, label %local.descriptor.inactive.2610
local.descriptor.active.2609:
  %local.check.offset.2612 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2613 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2614 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2615 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2616 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2617 = load i32, ptr %context.field.2616, align 4
  %stack.sub.2620 = sub i32 %local.check.owner.end.2615, %local.check.offset.2612
  %descriptor.owner.inside.2618 = icmp ule i32 %local.check.owner.end.2615, %context.value.2617
  %descriptor.offset.inside.2619 = icmp ule i32 %local.check.offset.2612, %local.check.owner.end.2615
  %descriptor.extent.inside.2621 = icmp ule i32 %local.check.extent.2613, %stack.sub.2620
  %descriptor.payload.inside.2622 = icmp ule i32 %local.check.payload.2614, %local.check.extent.2613
  %descriptor.owner.offset.valid.2623 = and i1 %descriptor.owner.inside.2618, %descriptor.offset.inside.2619
  %descriptor.range.inside.2625 = and i1 %descriptor.owner.offset.valid.2623, %descriptor.extent.inside.2621
  %descriptor.range.valid.2624 = and i1 %descriptor.range.inside.2625, %descriptor.payload.inside.2622
  br i1 %descriptor.range.valid.2624, label %descriptor.valid.2626, label %descriptor.invalid.2627
descriptor.invalid.2627:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2626:
  %descriptor.initialized.status.2628 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2612, i32 %local.check.extent.2613)
  %helper.ok.2629 = icmp eq i32 %descriptor.initialized.status.2628, 0
  br i1 %helper.ok.2629, label %helper.continue.2630, label %frame.failure.0
helper.continue.2630:
  br label %local.descriptor.checked.2611
local.descriptor.inactive.2610:
  br label %local.descriptor.checked.2611
local.descriptor.checked.2611:
  %local.is.active.2631 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2631, label %local.descriptor.active.2632, label %local.descriptor.inactive.2633
local.descriptor.active.2632:
  %local.check.offset.2635 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2636 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2637 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2638 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2639 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2640 = load i32, ptr %context.field.2639, align 4
  %stack.sub.2643 = sub i32 %local.check.owner.end.2638, %local.check.offset.2635
  %descriptor.owner.inside.2641 = icmp ule i32 %local.check.owner.end.2638, %context.value.2640
  %descriptor.offset.inside.2642 = icmp ule i32 %local.check.offset.2635, %local.check.owner.end.2638
  %descriptor.extent.inside.2644 = icmp ule i32 %local.check.extent.2636, %stack.sub.2643
  %descriptor.payload.inside.2645 = icmp ule i32 %local.check.payload.2637, %local.check.extent.2636
  %descriptor.owner.offset.valid.2646 = and i1 %descriptor.owner.inside.2641, %descriptor.offset.inside.2642
  %descriptor.range.inside.2648 = and i1 %descriptor.owner.offset.valid.2646, %descriptor.extent.inside.2644
  %descriptor.range.valid.2647 = and i1 %descriptor.range.inside.2648, %descriptor.payload.inside.2645
  br i1 %descriptor.range.valid.2647, label %descriptor.valid.2649, label %descriptor.invalid.2650
descriptor.invalid.2650:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2649:
  %descriptor.initialized.status.2651 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2635, i32 %local.check.extent.2636)
  %helper.ok.2652 = icmp eq i32 %descriptor.initialized.status.2651, 0
  br i1 %helper.ok.2652, label %helper.continue.2653, label %frame.failure.0
helper.continue.2653:
  br label %local.descriptor.checked.2634
local.descriptor.inactive.2633:
  br label %local.descriptor.checked.2634
local.descriptor.checked.2634:
  %local.is.active.2654 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2654, label %local.descriptor.active.2655, label %local.descriptor.inactive.2656
local.descriptor.active.2655:
  %local.check.offset.2658 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2659 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2660 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2661 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2662 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2663 = load i32, ptr %context.field.2662, align 4
  %stack.sub.2666 = sub i32 %local.check.owner.end.2661, %local.check.offset.2658
  %descriptor.owner.inside.2664 = icmp ule i32 %local.check.owner.end.2661, %context.value.2663
  %descriptor.offset.inside.2665 = icmp ule i32 %local.check.offset.2658, %local.check.owner.end.2661
  %descriptor.extent.inside.2667 = icmp ule i32 %local.check.extent.2659, %stack.sub.2666
  %descriptor.payload.inside.2668 = icmp ule i32 %local.check.payload.2660, %local.check.extent.2659
  %descriptor.owner.offset.valid.2669 = and i1 %descriptor.owner.inside.2664, %descriptor.offset.inside.2665
  %descriptor.range.inside.2671 = and i1 %descriptor.owner.offset.valid.2669, %descriptor.extent.inside.2667
  %descriptor.range.valid.2670 = and i1 %descriptor.range.inside.2671, %descriptor.payload.inside.2668
  br i1 %descriptor.range.valid.2670, label %descriptor.valid.2672, label %descriptor.invalid.2673
descriptor.invalid.2673:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2672:
  %descriptor.initialized.status.2674 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2658, i32 %local.check.extent.2659)
  %helper.ok.2675 = icmp eq i32 %descriptor.initialized.status.2674, 0
  br i1 %helper.ok.2675, label %helper.continue.2676, label %frame.failure.0
helper.continue.2676:
  br label %local.descriptor.checked.2657
local.descriptor.inactive.2656:
  br label %local.descriptor.checked.2657
local.descriptor.checked.2657:
  %local.is.active.2677 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2677, label %local.descriptor.active.2678, label %local.descriptor.inactive.2679
local.descriptor.active.2678:
  %local.check.offset.2681 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2682 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2683 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2684 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2685 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2686 = load i32, ptr %context.field.2685, align 4
  %stack.sub.2689 = sub i32 %local.check.owner.end.2684, %local.check.offset.2681
  %descriptor.owner.inside.2687 = icmp ule i32 %local.check.owner.end.2684, %context.value.2686
  %descriptor.offset.inside.2688 = icmp ule i32 %local.check.offset.2681, %local.check.owner.end.2684
  %descriptor.extent.inside.2690 = icmp ule i32 %local.check.extent.2682, %stack.sub.2689
  %descriptor.payload.inside.2691 = icmp ule i32 %local.check.payload.2683, %local.check.extent.2682
  %descriptor.owner.offset.valid.2692 = and i1 %descriptor.owner.inside.2687, %descriptor.offset.inside.2688
  %descriptor.range.inside.2694 = and i1 %descriptor.owner.offset.valid.2692, %descriptor.extent.inside.2690
  %descriptor.range.valid.2693 = and i1 %descriptor.range.inside.2694, %descriptor.payload.inside.2691
  br i1 %descriptor.range.valid.2693, label %descriptor.valid.2695, label %descriptor.invalid.2696
descriptor.invalid.2696:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2695:
  %descriptor.initialized.status.2697 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2681, i32 %local.check.extent.2682)
  %helper.ok.2698 = icmp eq i32 %descriptor.initialized.status.2697, 0
  br i1 %helper.ok.2698, label %helper.continue.2699, label %frame.failure.0
helper.continue.2699:
  br label %local.descriptor.checked.2680
local.descriptor.inactive.2679:
  br label %local.descriptor.checked.2680
local.descriptor.checked.2680:
  %local.is.active.2700 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.2700, label %local.descriptor.active.2701, label %local.descriptor.inactive.2702
local.descriptor.active.2701:
  %local.check.offset.2704 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.2705 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.2706 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.2707 = load i32, ptr %local.owner.end.42, align 4
  %context.field.2708 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2709 = load i32, ptr %context.field.2708, align 4
  %stack.sub.2712 = sub i32 %local.check.owner.end.2707, %local.check.offset.2704
  %descriptor.owner.inside.2710 = icmp ule i32 %local.check.owner.end.2707, %context.value.2709
  %descriptor.offset.inside.2711 = icmp ule i32 %local.check.offset.2704, %local.check.owner.end.2707
  %descriptor.extent.inside.2713 = icmp ule i32 %local.check.extent.2705, %stack.sub.2712
  %descriptor.payload.inside.2714 = icmp ule i32 %local.check.payload.2706, %local.check.extent.2705
  %descriptor.owner.offset.valid.2715 = and i1 %descriptor.owner.inside.2710, %descriptor.offset.inside.2711
  %descriptor.range.inside.2717 = and i1 %descriptor.owner.offset.valid.2715, %descriptor.extent.inside.2713
  %descriptor.range.valid.2716 = and i1 %descriptor.range.inside.2717, %descriptor.payload.inside.2714
  br i1 %descriptor.range.valid.2716, label %descriptor.valid.2718, label %descriptor.invalid.2719
descriptor.invalid.2719:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2718:
  %descriptor.initialized.status.2720 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2704, i32 %local.check.extent.2705)
  %helper.ok.2721 = icmp eq i32 %descriptor.initialized.status.2720, 0
  br i1 %helper.ok.2721, label %helper.continue.2722, label %frame.failure.0
helper.continue.2722:
  br label %local.descriptor.checked.2703
local.descriptor.inactive.2702:
  br label %local.descriptor.checked.2703
local.descriptor.checked.2703:
  %step.status.2723 = call i32 @al_owning_charge_step(ptr %ctx, i32 52)
  %helper.ok.2724 = icmp eq i32 %step.status.2723, 0
  br i1 %helper.ok.2724, label %helper.continue.2725, label %frame.failure.0
helper.continue.2725:
  store i1 true, ptr %local.active.20, align 1
  store i32 %if.value.offset.2541, ptr %local.offset.21, align 4
  store i32 %if.value.extent.2542, ptr %local.extent.22, align 4
  store i32 %if.value.payload.2543, ptr %local.payload.23, align 4
  store i32 %if.value.owner.end.2544, ptr %local.owner.end.24, align 4
  store i32 1, ptr %local.type.25, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %if.value.offset.2541, i32 20, i32 %if.value.payload.2543, i32 %if.value.owner.end.2544, i32 %if.value.extent.2542)
  %context.field.2726 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2727 = load i32, ptr %context.field.2726, align 4
  %runtime.ok.2728 = icmp eq i32 %context.value.2727, 0
  br i1 %runtime.ok.2728, label %runtime.continue.2729, label %frame.failure.0
runtime.continue.2729:
  %local.is.active.2730 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2730, label %local.descriptor.active.2731, label %local.descriptor.inactive.2732
local.descriptor.active.2731:
  %local.check.offset.2734 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2735 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2736 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2737 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2738 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2739 = load i32, ptr %context.field.2738, align 4
  %stack.sub.2742 = sub i32 %local.check.owner.end.2737, %local.check.offset.2734
  %descriptor.owner.inside.2740 = icmp ule i32 %local.check.owner.end.2737, %context.value.2739
  %descriptor.offset.inside.2741 = icmp ule i32 %local.check.offset.2734, %local.check.owner.end.2737
  %descriptor.extent.inside.2743 = icmp ule i32 %local.check.extent.2735, %stack.sub.2742
  %descriptor.payload.inside.2744 = icmp ule i32 %local.check.payload.2736, %local.check.extent.2735
  %descriptor.owner.offset.valid.2745 = and i1 %descriptor.owner.inside.2740, %descriptor.offset.inside.2741
  %descriptor.range.inside.2747 = and i1 %descriptor.owner.offset.valid.2745, %descriptor.extent.inside.2743
  %descriptor.range.valid.2746 = and i1 %descriptor.range.inside.2747, %descriptor.payload.inside.2744
  br i1 %descriptor.range.valid.2746, label %descriptor.valid.2748, label %descriptor.invalid.2749
descriptor.invalid.2749:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2748:
  %descriptor.initialized.status.2750 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2734, i32 %local.check.extent.2735)
  %helper.ok.2751 = icmp eq i32 %descriptor.initialized.status.2750, 0
  br i1 %helper.ok.2751, label %helper.continue.2752, label %frame.failure.0
helper.continue.2752:
  br label %local.descriptor.checked.2733
local.descriptor.inactive.2732:
  br label %local.descriptor.checked.2733
local.descriptor.checked.2733:
  %local.is.active.2753 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2753, label %local.descriptor.active.2754, label %local.descriptor.inactive.2755
local.descriptor.active.2754:
  %local.check.offset.2757 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2758 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2759 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2760 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2761 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2762 = load i32, ptr %context.field.2761, align 4
  %stack.sub.2765 = sub i32 %local.check.owner.end.2760, %local.check.offset.2757
  %descriptor.owner.inside.2763 = icmp ule i32 %local.check.owner.end.2760, %context.value.2762
  %descriptor.offset.inside.2764 = icmp ule i32 %local.check.offset.2757, %local.check.owner.end.2760
  %descriptor.extent.inside.2766 = icmp ule i32 %local.check.extent.2758, %stack.sub.2765
  %descriptor.payload.inside.2767 = icmp ule i32 %local.check.payload.2759, %local.check.extent.2758
  %descriptor.owner.offset.valid.2768 = and i1 %descriptor.owner.inside.2763, %descriptor.offset.inside.2764
  %descriptor.range.inside.2770 = and i1 %descriptor.owner.offset.valid.2768, %descriptor.extent.inside.2766
  %descriptor.range.valid.2769 = and i1 %descriptor.range.inside.2770, %descriptor.payload.inside.2767
  br i1 %descriptor.range.valid.2769, label %descriptor.valid.2771, label %descriptor.invalid.2772
descriptor.invalid.2772:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2771:
  %descriptor.initialized.status.2773 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2757, i32 %local.check.extent.2758)
  %helper.ok.2774 = icmp eq i32 %descriptor.initialized.status.2773, 0
  br i1 %helper.ok.2774, label %helper.continue.2775, label %frame.failure.0
helper.continue.2775:
  br label %local.descriptor.checked.2756
local.descriptor.inactive.2755:
  br label %local.descriptor.checked.2756
local.descriptor.checked.2756:
  %local.is.active.2776 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2776, label %local.descriptor.active.2777, label %local.descriptor.inactive.2778
local.descriptor.active.2777:
  %local.check.offset.2780 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2781 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2782 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2783 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2784 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2785 = load i32, ptr %context.field.2784, align 4
  %stack.sub.2788 = sub i32 %local.check.owner.end.2783, %local.check.offset.2780
  %descriptor.owner.inside.2786 = icmp ule i32 %local.check.owner.end.2783, %context.value.2785
  %descriptor.offset.inside.2787 = icmp ule i32 %local.check.offset.2780, %local.check.owner.end.2783
  %descriptor.extent.inside.2789 = icmp ule i32 %local.check.extent.2781, %stack.sub.2788
  %descriptor.payload.inside.2790 = icmp ule i32 %local.check.payload.2782, %local.check.extent.2781
  %descriptor.owner.offset.valid.2791 = and i1 %descriptor.owner.inside.2786, %descriptor.offset.inside.2787
  %descriptor.range.inside.2793 = and i1 %descriptor.owner.offset.valid.2791, %descriptor.extent.inside.2789
  %descriptor.range.valid.2792 = and i1 %descriptor.range.inside.2793, %descriptor.payload.inside.2790
  br i1 %descriptor.range.valid.2792, label %descriptor.valid.2794, label %descriptor.invalid.2795
descriptor.invalid.2795:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2794:
  %descriptor.initialized.status.2796 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2780, i32 %local.check.extent.2781)
  %helper.ok.2797 = icmp eq i32 %descriptor.initialized.status.2796, 0
  br i1 %helper.ok.2797, label %helper.continue.2798, label %frame.failure.0
helper.continue.2798:
  br label %local.descriptor.checked.2779
local.descriptor.inactive.2778:
  br label %local.descriptor.checked.2779
local.descriptor.checked.2779:
  %local.is.active.2799 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2799, label %local.descriptor.active.2800, label %local.descriptor.inactive.2801
local.descriptor.active.2800:
  %local.check.offset.2803 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2804 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2805 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2806 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2807 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2808 = load i32, ptr %context.field.2807, align 4
  %stack.sub.2811 = sub i32 %local.check.owner.end.2806, %local.check.offset.2803
  %descriptor.owner.inside.2809 = icmp ule i32 %local.check.owner.end.2806, %context.value.2808
  %descriptor.offset.inside.2810 = icmp ule i32 %local.check.offset.2803, %local.check.owner.end.2806
  %descriptor.extent.inside.2812 = icmp ule i32 %local.check.extent.2804, %stack.sub.2811
  %descriptor.payload.inside.2813 = icmp ule i32 %local.check.payload.2805, %local.check.extent.2804
  %descriptor.owner.offset.valid.2814 = and i1 %descriptor.owner.inside.2809, %descriptor.offset.inside.2810
  %descriptor.range.inside.2816 = and i1 %descriptor.owner.offset.valid.2814, %descriptor.extent.inside.2812
  %descriptor.range.valid.2815 = and i1 %descriptor.range.inside.2816, %descriptor.payload.inside.2813
  br i1 %descriptor.range.valid.2815, label %descriptor.valid.2817, label %descriptor.invalid.2818
descriptor.invalid.2818:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2817:
  %descriptor.initialized.status.2819 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2803, i32 %local.check.extent.2804)
  %helper.ok.2820 = icmp eq i32 %descriptor.initialized.status.2819, 0
  br i1 %helper.ok.2820, label %helper.continue.2821, label %frame.failure.0
helper.continue.2821:
  br label %local.descriptor.checked.2802
local.descriptor.inactive.2801:
  br label %local.descriptor.checked.2802
local.descriptor.checked.2802:
  %local.is.active.2822 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2822, label %local.descriptor.active.2823, label %local.descriptor.inactive.2824
local.descriptor.active.2823:
  %local.check.offset.2826 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2827 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2828 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2829 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2830 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2831 = load i32, ptr %context.field.2830, align 4
  %stack.sub.2834 = sub i32 %local.check.owner.end.2829, %local.check.offset.2826
  %descriptor.owner.inside.2832 = icmp ule i32 %local.check.owner.end.2829, %context.value.2831
  %descriptor.offset.inside.2833 = icmp ule i32 %local.check.offset.2826, %local.check.owner.end.2829
  %descriptor.extent.inside.2835 = icmp ule i32 %local.check.extent.2827, %stack.sub.2834
  %descriptor.payload.inside.2836 = icmp ule i32 %local.check.payload.2828, %local.check.extent.2827
  %descriptor.owner.offset.valid.2837 = and i1 %descriptor.owner.inside.2832, %descriptor.offset.inside.2833
  %descriptor.range.inside.2839 = and i1 %descriptor.owner.offset.valid.2837, %descriptor.extent.inside.2835
  %descriptor.range.valid.2838 = and i1 %descriptor.range.inside.2839, %descriptor.payload.inside.2836
  br i1 %descriptor.range.valid.2838, label %descriptor.valid.2840, label %descriptor.invalid.2841
descriptor.invalid.2841:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2840:
  %descriptor.initialized.status.2842 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2826, i32 %local.check.extent.2827)
  %helper.ok.2843 = icmp eq i32 %descriptor.initialized.status.2842, 0
  br i1 %helper.ok.2843, label %helper.continue.2844, label %frame.failure.0
helper.continue.2844:
  br label %local.descriptor.checked.2825
local.descriptor.inactive.2824:
  br label %local.descriptor.checked.2825
local.descriptor.checked.2825:
  %local.is.active.2845 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2845, label %local.descriptor.active.2846, label %local.descriptor.inactive.2847
local.descriptor.active.2846:
  %local.check.offset.2849 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2850 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2851 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2852 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2853 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2854 = load i32, ptr %context.field.2853, align 4
  %stack.sub.2857 = sub i32 %local.check.owner.end.2852, %local.check.offset.2849
  %descriptor.owner.inside.2855 = icmp ule i32 %local.check.owner.end.2852, %context.value.2854
  %descriptor.offset.inside.2856 = icmp ule i32 %local.check.offset.2849, %local.check.owner.end.2852
  %descriptor.extent.inside.2858 = icmp ule i32 %local.check.extent.2850, %stack.sub.2857
  %descriptor.payload.inside.2859 = icmp ule i32 %local.check.payload.2851, %local.check.extent.2850
  %descriptor.owner.offset.valid.2860 = and i1 %descriptor.owner.inside.2855, %descriptor.offset.inside.2856
  %descriptor.range.inside.2862 = and i1 %descriptor.owner.offset.valid.2860, %descriptor.extent.inside.2858
  %descriptor.range.valid.2861 = and i1 %descriptor.range.inside.2862, %descriptor.payload.inside.2859
  br i1 %descriptor.range.valid.2861, label %descriptor.valid.2863, label %descriptor.invalid.2864
descriptor.invalid.2864:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2863:
  %descriptor.initialized.status.2865 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2849, i32 %local.check.extent.2850)
  %helper.ok.2866 = icmp eq i32 %descriptor.initialized.status.2865, 0
  br i1 %helper.ok.2866, label %helper.continue.2867, label %frame.failure.0
helper.continue.2867:
  br label %local.descriptor.checked.2848
local.descriptor.inactive.2847:
  br label %local.descriptor.checked.2848
local.descriptor.checked.2848:
  %local.is.active.2868 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.2868, label %local.descriptor.active.2869, label %local.descriptor.inactive.2870
local.descriptor.active.2869:
  %local.check.offset.2872 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.2873 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.2874 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.2875 = load i32, ptr %local.owner.end.42, align 4
  %context.field.2876 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2877 = load i32, ptr %context.field.2876, align 4
  %stack.sub.2880 = sub i32 %local.check.owner.end.2875, %local.check.offset.2872
  %descriptor.owner.inside.2878 = icmp ule i32 %local.check.owner.end.2875, %context.value.2877
  %descriptor.offset.inside.2879 = icmp ule i32 %local.check.offset.2872, %local.check.owner.end.2875
  %descriptor.extent.inside.2881 = icmp ule i32 %local.check.extent.2873, %stack.sub.2880
  %descriptor.payload.inside.2882 = icmp ule i32 %local.check.payload.2874, %local.check.extent.2873
  %descriptor.owner.offset.valid.2883 = and i1 %descriptor.owner.inside.2878, %descriptor.offset.inside.2879
  %descriptor.range.inside.2885 = and i1 %descriptor.owner.offset.valid.2883, %descriptor.extent.inside.2881
  %descriptor.range.valid.2884 = and i1 %descriptor.range.inside.2885, %descriptor.payload.inside.2882
  br i1 %descriptor.range.valid.2884, label %descriptor.valid.2886, label %descriptor.invalid.2887
descriptor.invalid.2887:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2886:
  %descriptor.initialized.status.2888 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2872, i32 %local.check.extent.2873)
  %helper.ok.2889 = icmp eq i32 %descriptor.initialized.status.2888, 0
  br i1 %helper.ok.2889, label %helper.continue.2890, label %frame.failure.0
helper.continue.2890:
  br label %local.descriptor.checked.2871
local.descriptor.inactive.2870:
  br label %local.descriptor.checked.2871
local.descriptor.checked.2871:
  %step.status.2891 = call i32 @al_owning_charge_step(ptr %ctx, i32 53)
  %helper.ok.2892 = icmp eq i32 %step.status.2891, 0
  br i1 %helper.ok.2892, label %helper.continue.2893, label %frame.failure.0
helper.continue.2893:
  %local.resolved.offset.2894 = load i32, ptr %local.offset.15, align 4
  %local.resolved.extent.2895 = load i32, ptr %local.extent.16, align 4
  %local.resolved.payload.2896 = load i32, ptr %local.payload.17, align 4
  %local.resolved.owner.end.2897 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2898 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2899 = load i32, ptr %context.field.2898, align 4
  %stack.sub.2902 = sub i32 %local.resolved.owner.end.2897, %local.resolved.offset.2894
  %descriptor.owner.inside.2900 = icmp ule i32 %local.resolved.owner.end.2897, %context.value.2899
  %descriptor.offset.inside.2901 = icmp ule i32 %local.resolved.offset.2894, %local.resolved.owner.end.2897
  %descriptor.extent.inside.2903 = icmp ule i32 %local.resolved.extent.2895, %stack.sub.2902
  %descriptor.payload.inside.2904 = icmp ule i32 %local.resolved.payload.2896, %local.resolved.extent.2895
  %descriptor.owner.offset.valid.2905 = and i1 %descriptor.owner.inside.2900, %descriptor.offset.inside.2901
  %descriptor.range.inside.2907 = and i1 %descriptor.owner.offset.valid.2905, %descriptor.extent.inside.2903
  %descriptor.range.valid.2906 = and i1 %descriptor.range.inside.2907, %descriptor.payload.inside.2904
  %descriptor.type.valid.2908 = icmp eq i32 5, 5
  %descriptor.valid.2909 = and i1 %descriptor.range.valid.2906, %descriptor.type.valid.2908
  br i1 %descriptor.valid.2909, label %descriptor.valid.2910, label %descriptor.invalid.2911
descriptor.invalid.2911:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2910:
  %descriptor.initialized.status.2912 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.2894, i32 %local.resolved.extent.2895)
  %helper.ok.2913 = icmp eq i32 %descriptor.initialized.status.2912, 0
  br i1 %helper.ok.2913, label %helper.continue.2914, label %frame.failure.0
helper.continue.2914:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %local.resolved.offset.2894, i32 20, i32 %local.resolved.payload.2896, i32 %local.resolved.owner.end.2897, i32 %local.resolved.extent.2895)
  %context.field.2915 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2916 = load i32, ptr %context.field.2915, align 4
  %runtime.ok.2917 = icmp eq i32 %context.value.2916, 0
  br i1 %runtime.ok.2917, label %runtime.continue.2918, label %frame.failure.0
runtime.continue.2918:
  %context.field.2919 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2920 = load i32, ptr %context.field.2919, align 4
  %stack.sub.2923 = sub i32 %local.resolved.owner.end.2897, %local.resolved.offset.2894
  %descriptor.owner.inside.2921 = icmp ule i32 %local.resolved.owner.end.2897, %context.value.2920
  %descriptor.offset.inside.2922 = icmp ule i32 %local.resolved.offset.2894, %local.resolved.owner.end.2897
  %descriptor.extent.inside.2924 = icmp ule i32 %local.resolved.extent.2895, %stack.sub.2923
  %descriptor.payload.inside.2925 = icmp ule i32 %local.resolved.payload.2896, %local.resolved.extent.2895
  %descriptor.owner.offset.valid.2926 = and i1 %descriptor.owner.inside.2921, %descriptor.offset.inside.2922
  %descriptor.range.inside.2928 = and i1 %descriptor.owner.offset.valid.2926, %descriptor.extent.inside.2924
  %descriptor.range.valid.2927 = and i1 %descriptor.range.inside.2928, %descriptor.payload.inside.2925
  %descriptor.type.valid.2929 = icmp eq i32 5, 5
  %descriptor.valid.2930 = and i1 %descriptor.range.valid.2927, %descriptor.type.valid.2929
  br i1 %descriptor.valid.2930, label %descriptor.valid.2931, label %descriptor.invalid.2932
descriptor.invalid.2932:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2931:
  %descriptor.initialized.status.2933 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.2894, i32 %local.resolved.extent.2895)
  %helper.ok.2934 = icmp eq i32 %descriptor.initialized.status.2933, 0
  br i1 %helper.ok.2934, label %helper.continue.2935, label %frame.failure.0
helper.continue.2935:
  %local.is.active.2936 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2936, label %local.descriptor.active.2937, label %local.descriptor.inactive.2938
local.descriptor.active.2937:
  %local.check.offset.2940 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2941 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2942 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2943 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2944 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2945 = load i32, ptr %context.field.2944, align 4
  %stack.sub.2948 = sub i32 %local.check.owner.end.2943, %local.check.offset.2940
  %descriptor.owner.inside.2946 = icmp ule i32 %local.check.owner.end.2943, %context.value.2945
  %descriptor.offset.inside.2947 = icmp ule i32 %local.check.offset.2940, %local.check.owner.end.2943
  %descriptor.extent.inside.2949 = icmp ule i32 %local.check.extent.2941, %stack.sub.2948
  %descriptor.payload.inside.2950 = icmp ule i32 %local.check.payload.2942, %local.check.extent.2941
  %descriptor.owner.offset.valid.2951 = and i1 %descriptor.owner.inside.2946, %descriptor.offset.inside.2947
  %descriptor.range.inside.2953 = and i1 %descriptor.owner.offset.valid.2951, %descriptor.extent.inside.2949
  %descriptor.range.valid.2952 = and i1 %descriptor.range.inside.2953, %descriptor.payload.inside.2950
  br i1 %descriptor.range.valid.2952, label %descriptor.valid.2954, label %descriptor.invalid.2955
descriptor.invalid.2955:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2954:
  %descriptor.initialized.status.2956 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2940, i32 %local.check.extent.2941)
  %helper.ok.2957 = icmp eq i32 %descriptor.initialized.status.2956, 0
  br i1 %helper.ok.2957, label %helper.continue.2958, label %frame.failure.0
helper.continue.2958:
  br label %local.descriptor.checked.2939
local.descriptor.inactive.2938:
  br label %local.descriptor.checked.2939
local.descriptor.checked.2939:
  %local.is.active.2959 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2959, label %local.descriptor.active.2960, label %local.descriptor.inactive.2961
local.descriptor.active.2960:
  %local.check.offset.2963 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2964 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2965 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2966 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2967 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2968 = load i32, ptr %context.field.2967, align 4
  %stack.sub.2971 = sub i32 %local.check.owner.end.2966, %local.check.offset.2963
  %descriptor.owner.inside.2969 = icmp ule i32 %local.check.owner.end.2966, %context.value.2968
  %descriptor.offset.inside.2970 = icmp ule i32 %local.check.offset.2963, %local.check.owner.end.2966
  %descriptor.extent.inside.2972 = icmp ule i32 %local.check.extent.2964, %stack.sub.2971
  %descriptor.payload.inside.2973 = icmp ule i32 %local.check.payload.2965, %local.check.extent.2964
  %descriptor.owner.offset.valid.2974 = and i1 %descriptor.owner.inside.2969, %descriptor.offset.inside.2970
  %descriptor.range.inside.2976 = and i1 %descriptor.owner.offset.valid.2974, %descriptor.extent.inside.2972
  %descriptor.range.valid.2975 = and i1 %descriptor.range.inside.2976, %descriptor.payload.inside.2973
  br i1 %descriptor.range.valid.2975, label %descriptor.valid.2977, label %descriptor.invalid.2978
descriptor.invalid.2978:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2977:
  %descriptor.initialized.status.2979 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2963, i32 %local.check.extent.2964)
  %helper.ok.2980 = icmp eq i32 %descriptor.initialized.status.2979, 0
  br i1 %helper.ok.2980, label %helper.continue.2981, label %frame.failure.0
helper.continue.2981:
  br label %local.descriptor.checked.2962
local.descriptor.inactive.2961:
  br label %local.descriptor.checked.2962
local.descriptor.checked.2962:
  %local.is.active.2982 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2982, label %local.descriptor.active.2983, label %local.descriptor.inactive.2984
local.descriptor.active.2983:
  %local.check.offset.2986 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2987 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2988 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2989 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2990 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2991 = load i32, ptr %context.field.2990, align 4
  %stack.sub.2994 = sub i32 %local.check.owner.end.2989, %local.check.offset.2986
  %descriptor.owner.inside.2992 = icmp ule i32 %local.check.owner.end.2989, %context.value.2991
  %descriptor.offset.inside.2993 = icmp ule i32 %local.check.offset.2986, %local.check.owner.end.2989
  %descriptor.extent.inside.2995 = icmp ule i32 %local.check.extent.2987, %stack.sub.2994
  %descriptor.payload.inside.2996 = icmp ule i32 %local.check.payload.2988, %local.check.extent.2987
  %descriptor.owner.offset.valid.2997 = and i1 %descriptor.owner.inside.2992, %descriptor.offset.inside.2993
  %descriptor.range.inside.2999 = and i1 %descriptor.owner.offset.valid.2997, %descriptor.extent.inside.2995
  %descriptor.range.valid.2998 = and i1 %descriptor.range.inside.2999, %descriptor.payload.inside.2996
  br i1 %descriptor.range.valid.2998, label %descriptor.valid.3000, label %descriptor.invalid.3001
descriptor.invalid.3001:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3000:
  %descriptor.initialized.status.3002 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2986, i32 %local.check.extent.2987)
  %helper.ok.3003 = icmp eq i32 %descriptor.initialized.status.3002, 0
  br i1 %helper.ok.3003, label %helper.continue.3004, label %frame.failure.0
helper.continue.3004:
  br label %local.descriptor.checked.2985
local.descriptor.inactive.2984:
  br label %local.descriptor.checked.2985
local.descriptor.checked.2985:
  %local.is.active.3005 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.3005, label %local.descriptor.active.3006, label %local.descriptor.inactive.3007
local.descriptor.active.3006:
  %local.check.offset.3009 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.3010 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.3011 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.3012 = load i32, ptr %local.owner.end.24, align 4
  %context.field.3013 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3014 = load i32, ptr %context.field.3013, align 4
  %stack.sub.3017 = sub i32 %local.check.owner.end.3012, %local.check.offset.3009
  %descriptor.owner.inside.3015 = icmp ule i32 %local.check.owner.end.3012, %context.value.3014
  %descriptor.offset.inside.3016 = icmp ule i32 %local.check.offset.3009, %local.check.owner.end.3012
  %descriptor.extent.inside.3018 = icmp ule i32 %local.check.extent.3010, %stack.sub.3017
  %descriptor.payload.inside.3019 = icmp ule i32 %local.check.payload.3011, %local.check.extent.3010
  %descriptor.owner.offset.valid.3020 = and i1 %descriptor.owner.inside.3015, %descriptor.offset.inside.3016
  %descriptor.range.inside.3022 = and i1 %descriptor.owner.offset.valid.3020, %descriptor.extent.inside.3018
  %descriptor.range.valid.3021 = and i1 %descriptor.range.inside.3022, %descriptor.payload.inside.3019
  br i1 %descriptor.range.valid.3021, label %descriptor.valid.3023, label %descriptor.invalid.3024
descriptor.invalid.3024:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3023:
  %descriptor.initialized.status.3025 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3009, i32 %local.check.extent.3010)
  %helper.ok.3026 = icmp eq i32 %descriptor.initialized.status.3025, 0
  br i1 %helper.ok.3026, label %helper.continue.3027, label %frame.failure.0
helper.continue.3027:
  br label %local.descriptor.checked.3008
local.descriptor.inactive.3007:
  br label %local.descriptor.checked.3008
local.descriptor.checked.3008:
  %local.is.active.3028 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.3028, label %local.descriptor.active.3029, label %local.descriptor.inactive.3030
local.descriptor.active.3029:
  %local.check.offset.3032 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.3033 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.3034 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.3035 = load i32, ptr %local.owner.end.30, align 4
  %context.field.3036 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3037 = load i32, ptr %context.field.3036, align 4
  %stack.sub.3040 = sub i32 %local.check.owner.end.3035, %local.check.offset.3032
  %descriptor.owner.inside.3038 = icmp ule i32 %local.check.owner.end.3035, %context.value.3037
  %descriptor.offset.inside.3039 = icmp ule i32 %local.check.offset.3032, %local.check.owner.end.3035
  %descriptor.extent.inside.3041 = icmp ule i32 %local.check.extent.3033, %stack.sub.3040
  %descriptor.payload.inside.3042 = icmp ule i32 %local.check.payload.3034, %local.check.extent.3033
  %descriptor.owner.offset.valid.3043 = and i1 %descriptor.owner.inside.3038, %descriptor.offset.inside.3039
  %descriptor.range.inside.3045 = and i1 %descriptor.owner.offset.valid.3043, %descriptor.extent.inside.3041
  %descriptor.range.valid.3044 = and i1 %descriptor.range.inside.3045, %descriptor.payload.inside.3042
  br i1 %descriptor.range.valid.3044, label %descriptor.valid.3046, label %descriptor.invalid.3047
descriptor.invalid.3047:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3046:
  %descriptor.initialized.status.3048 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3032, i32 %local.check.extent.3033)
  %helper.ok.3049 = icmp eq i32 %descriptor.initialized.status.3048, 0
  br i1 %helper.ok.3049, label %helper.continue.3050, label %frame.failure.0
helper.continue.3050:
  br label %local.descriptor.checked.3031
local.descriptor.inactive.3030:
  br label %local.descriptor.checked.3031
local.descriptor.checked.3031:
  %local.is.active.3051 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.3051, label %local.descriptor.active.3052, label %local.descriptor.inactive.3053
local.descriptor.active.3052:
  %local.check.offset.3055 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.3056 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.3057 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.3058 = load i32, ptr %local.owner.end.36, align 4
  %context.field.3059 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3060 = load i32, ptr %context.field.3059, align 4
  %stack.sub.3063 = sub i32 %local.check.owner.end.3058, %local.check.offset.3055
  %descriptor.owner.inside.3061 = icmp ule i32 %local.check.owner.end.3058, %context.value.3060
  %descriptor.offset.inside.3062 = icmp ule i32 %local.check.offset.3055, %local.check.owner.end.3058
  %descriptor.extent.inside.3064 = icmp ule i32 %local.check.extent.3056, %stack.sub.3063
  %descriptor.payload.inside.3065 = icmp ule i32 %local.check.payload.3057, %local.check.extent.3056
  %descriptor.owner.offset.valid.3066 = and i1 %descriptor.owner.inside.3061, %descriptor.offset.inside.3062
  %descriptor.range.inside.3068 = and i1 %descriptor.owner.offset.valid.3066, %descriptor.extent.inside.3064
  %descriptor.range.valid.3067 = and i1 %descriptor.range.inside.3068, %descriptor.payload.inside.3065
  br i1 %descriptor.range.valid.3067, label %descriptor.valid.3069, label %descriptor.invalid.3070
descriptor.invalid.3070:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3069:
  %descriptor.initialized.status.3071 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3055, i32 %local.check.extent.3056)
  %helper.ok.3072 = icmp eq i32 %descriptor.initialized.status.3071, 0
  br i1 %helper.ok.3072, label %helper.continue.3073, label %frame.failure.0
helper.continue.3073:
  br label %local.descriptor.checked.3054
local.descriptor.inactive.3053:
  br label %local.descriptor.checked.3054
local.descriptor.checked.3054:
  %local.is.active.3074 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.3074, label %local.descriptor.active.3075, label %local.descriptor.inactive.3076
local.descriptor.active.3075:
  %local.check.offset.3078 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.3079 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.3080 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.3081 = load i32, ptr %local.owner.end.42, align 4
  %context.field.3082 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3083 = load i32, ptr %context.field.3082, align 4
  %stack.sub.3086 = sub i32 %local.check.owner.end.3081, %local.check.offset.3078
  %descriptor.owner.inside.3084 = icmp ule i32 %local.check.owner.end.3081, %context.value.3083
  %descriptor.offset.inside.3085 = icmp ule i32 %local.check.offset.3078, %local.check.owner.end.3081
  %descriptor.extent.inside.3087 = icmp ule i32 %local.check.extent.3079, %stack.sub.3086
  %descriptor.payload.inside.3088 = icmp ule i32 %local.check.payload.3080, %local.check.extent.3079
  %descriptor.owner.offset.valid.3089 = and i1 %descriptor.owner.inside.3084, %descriptor.offset.inside.3085
  %descriptor.range.inside.3091 = and i1 %descriptor.owner.offset.valid.3089, %descriptor.extent.inside.3087
  %descriptor.range.valid.3090 = and i1 %descriptor.range.inside.3091, %descriptor.payload.inside.3088
  br i1 %descriptor.range.valid.3090, label %descriptor.valid.3092, label %descriptor.invalid.3093
descriptor.invalid.3093:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3092:
  %descriptor.initialized.status.3094 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3078, i32 %local.check.extent.3079)
  %helper.ok.3095 = icmp eq i32 %descriptor.initialized.status.3094, 0
  br i1 %helper.ok.3095, label %helper.continue.3096, label %frame.failure.0
helper.continue.3096:
  br label %local.descriptor.checked.3077
local.descriptor.inactive.3076:
  br label %local.descriptor.checked.3077
local.descriptor.checked.3077:
  %step.status.3097 = call i32 @al_owning_charge_step(ptr %ctx, i32 54)
  %helper.ok.3098 = icmp eq i32 %step.status.3097, 0
  br i1 %helper.ok.3098, label %helper.continue.3099, label %frame.failure.0
helper.continue.3099:
  %context.field.3100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.3101 = load i32, ptr %context.field.3100, align 4
  %inline.target.depth.within.interpreter.limit.3102 = icmp ule i32 %context.value.3101, 65
  br i1 %inline.target.depth.within.interpreter.limit.3102, label %inline.target.depth.ok.3103, label %inline.target.depth.invalid.3104
inline.target.depth.invalid.3104:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 55, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.3103:
  %field.location.status.3106 = call i32 @al_owning_locate_field(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 3, i32 %local.resolved.offset.2894, i32 %local.resolved.extent.2895, i32 0, i32 56, ptr %field.location.3105)
  %helper.ok.3107 = icmp eq i32 %field.location.status.3106, 0
  br i1 %helper.ok.3107, label %helper.continue.3108, label %frame.failure.0
helper.continue.3108:
  %field.offset.pointer.3109 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.3105, i32 0, i32 0
  %field.offset.3110 = load i32, ptr %field.offset.pointer.3109, align 4
  %field.payload.pointer.3111 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.3105, i32 0, i32 1
  %field.payload.3112 = load i32, ptr %field.payload.pointer.3111, align 4
  %field.extent.pointer.3113 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.3105, i32 0, i32 2
  %field.extent.3114 = load i32, ptr %field.extent.pointer.3113, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 7, i32 6, i32 %local.resolved.offset.2894, i32 %field.extent.3114, i32 %field.payload.3112, i32 %field.offset.3110, i32 %field.extent.3114)
  %context.field.3115 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3116 = load i32, ptr %context.field.3115, align 4
  %runtime.ok.3117 = icmp eq i32 %context.value.3116, 0
  br i1 %runtime.ok.3117, label %runtime.continue.3118, label %frame.failure.0
runtime.continue.3118:
  %context.field.3119 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3120 = load i32, ptr %context.field.3119, align 4
  %stack.sub.3123 = sub i32 %local.resolved.owner.end.2897, %field.offset.3110
  %descriptor.owner.inside.3121 = icmp ule i32 %local.resolved.owner.end.2897, %context.value.3120
  %descriptor.offset.inside.3122 = icmp ule i32 %field.offset.3110, %local.resolved.owner.end.2897
  %descriptor.extent.inside.3124 = icmp ule i32 %field.extent.3114, %stack.sub.3123
  %descriptor.payload.inside.3125 = icmp ule i32 %field.payload.3112, %field.extent.3114
  %descriptor.owner.offset.valid.3126 = and i1 %descriptor.owner.inside.3121, %descriptor.offset.inside.3122
  %descriptor.range.inside.3128 = and i1 %descriptor.owner.offset.valid.3126, %descriptor.extent.inside.3124
  %descriptor.range.valid.3127 = and i1 %descriptor.range.inside.3128, %descriptor.payload.inside.3125
  %descriptor.type.valid.3129 = icmp eq i32 6, 6
  %descriptor.valid.3130 = and i1 %descriptor.range.valid.3127, %descriptor.type.valid.3129
  br i1 %descriptor.valid.3130, label %descriptor.valid.3131, label %descriptor.invalid.3132
descriptor.invalid.3132:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3131:
  %descriptor.initialized.status.3133 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %field.offset.3110, i32 %field.extent.3114)
  %helper.ok.3134 = icmp eq i32 %descriptor.initialized.status.3133, 0
  br i1 %helper.ok.3134, label %helper.continue.3135, label %frame.failure.0
helper.continue.3135:
  %local.is.active.3136 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.3136, label %local.descriptor.active.3137, label %local.descriptor.inactive.3138
local.descriptor.active.3137:
  %local.check.offset.3140 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.3141 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.3142 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.3143 = load i32, ptr %local.owner.end.6, align 4
  %context.field.3144 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3145 = load i32, ptr %context.field.3144, align 4
  %stack.sub.3148 = sub i32 %local.check.owner.end.3143, %local.check.offset.3140
  %descriptor.owner.inside.3146 = icmp ule i32 %local.check.owner.end.3143, %context.value.3145
  %descriptor.offset.inside.3147 = icmp ule i32 %local.check.offset.3140, %local.check.owner.end.3143
  %descriptor.extent.inside.3149 = icmp ule i32 %local.check.extent.3141, %stack.sub.3148
  %descriptor.payload.inside.3150 = icmp ule i32 %local.check.payload.3142, %local.check.extent.3141
  %descriptor.owner.offset.valid.3151 = and i1 %descriptor.owner.inside.3146, %descriptor.offset.inside.3147
  %descriptor.range.inside.3153 = and i1 %descriptor.owner.offset.valid.3151, %descriptor.extent.inside.3149
  %descriptor.range.valid.3152 = and i1 %descriptor.range.inside.3153, %descriptor.payload.inside.3150
  br i1 %descriptor.range.valid.3152, label %descriptor.valid.3154, label %descriptor.invalid.3155
descriptor.invalid.3155:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3154:
  %descriptor.initialized.status.3156 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3140, i32 %local.check.extent.3141)
  %helper.ok.3157 = icmp eq i32 %descriptor.initialized.status.3156, 0
  br i1 %helper.ok.3157, label %helper.continue.3158, label %frame.failure.0
helper.continue.3158:
  br label %local.descriptor.checked.3139
local.descriptor.inactive.3138:
  br label %local.descriptor.checked.3139
local.descriptor.checked.3139:
  %local.is.active.3159 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.3159, label %local.descriptor.active.3160, label %local.descriptor.inactive.3161
local.descriptor.active.3160:
  %local.check.offset.3163 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.3164 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.3165 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.3166 = load i32, ptr %local.owner.end.12, align 4
  %context.field.3167 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3168 = load i32, ptr %context.field.3167, align 4
  %stack.sub.3171 = sub i32 %local.check.owner.end.3166, %local.check.offset.3163
  %descriptor.owner.inside.3169 = icmp ule i32 %local.check.owner.end.3166, %context.value.3168
  %descriptor.offset.inside.3170 = icmp ule i32 %local.check.offset.3163, %local.check.owner.end.3166
  %descriptor.extent.inside.3172 = icmp ule i32 %local.check.extent.3164, %stack.sub.3171
  %descriptor.payload.inside.3173 = icmp ule i32 %local.check.payload.3165, %local.check.extent.3164
  %descriptor.owner.offset.valid.3174 = and i1 %descriptor.owner.inside.3169, %descriptor.offset.inside.3170
  %descriptor.range.inside.3176 = and i1 %descriptor.owner.offset.valid.3174, %descriptor.extent.inside.3172
  %descriptor.range.valid.3175 = and i1 %descriptor.range.inside.3176, %descriptor.payload.inside.3173
  br i1 %descriptor.range.valid.3175, label %descriptor.valid.3177, label %descriptor.invalid.3178
descriptor.invalid.3178:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3177:
  %descriptor.initialized.status.3179 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3163, i32 %local.check.extent.3164)
  %helper.ok.3180 = icmp eq i32 %descriptor.initialized.status.3179, 0
  br i1 %helper.ok.3180, label %helper.continue.3181, label %frame.failure.0
helper.continue.3181:
  br label %local.descriptor.checked.3162
local.descriptor.inactive.3161:
  br label %local.descriptor.checked.3162
local.descriptor.checked.3162:
  %local.is.active.3182 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.3182, label %local.descriptor.active.3183, label %local.descriptor.inactive.3184
local.descriptor.active.3183:
  %local.check.offset.3186 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.3187 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.3188 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.3189 = load i32, ptr %local.owner.end.18, align 4
  %context.field.3190 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3191 = load i32, ptr %context.field.3190, align 4
  %stack.sub.3194 = sub i32 %local.check.owner.end.3189, %local.check.offset.3186
  %descriptor.owner.inside.3192 = icmp ule i32 %local.check.owner.end.3189, %context.value.3191
  %descriptor.offset.inside.3193 = icmp ule i32 %local.check.offset.3186, %local.check.owner.end.3189
  %descriptor.extent.inside.3195 = icmp ule i32 %local.check.extent.3187, %stack.sub.3194
  %descriptor.payload.inside.3196 = icmp ule i32 %local.check.payload.3188, %local.check.extent.3187
  %descriptor.owner.offset.valid.3197 = and i1 %descriptor.owner.inside.3192, %descriptor.offset.inside.3193
  %descriptor.range.inside.3199 = and i1 %descriptor.owner.offset.valid.3197, %descriptor.extent.inside.3195
  %descriptor.range.valid.3198 = and i1 %descriptor.range.inside.3199, %descriptor.payload.inside.3196
  br i1 %descriptor.range.valid.3198, label %descriptor.valid.3200, label %descriptor.invalid.3201
descriptor.invalid.3201:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3200:
  %descriptor.initialized.status.3202 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3186, i32 %local.check.extent.3187)
  %helper.ok.3203 = icmp eq i32 %descriptor.initialized.status.3202, 0
  br i1 %helper.ok.3203, label %helper.continue.3204, label %frame.failure.0
helper.continue.3204:
  br label %local.descriptor.checked.3185
local.descriptor.inactive.3184:
  br label %local.descriptor.checked.3185
local.descriptor.checked.3185:
  %local.is.active.3205 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.3205, label %local.descriptor.active.3206, label %local.descriptor.inactive.3207
local.descriptor.active.3206:
  %local.check.offset.3209 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.3210 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.3211 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.3212 = load i32, ptr %local.owner.end.24, align 4
  %context.field.3213 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3214 = load i32, ptr %context.field.3213, align 4
  %stack.sub.3217 = sub i32 %local.check.owner.end.3212, %local.check.offset.3209
  %descriptor.owner.inside.3215 = icmp ule i32 %local.check.owner.end.3212, %context.value.3214
  %descriptor.offset.inside.3216 = icmp ule i32 %local.check.offset.3209, %local.check.owner.end.3212
  %descriptor.extent.inside.3218 = icmp ule i32 %local.check.extent.3210, %stack.sub.3217
  %descriptor.payload.inside.3219 = icmp ule i32 %local.check.payload.3211, %local.check.extent.3210
  %descriptor.owner.offset.valid.3220 = and i1 %descriptor.owner.inside.3215, %descriptor.offset.inside.3216
  %descriptor.range.inside.3222 = and i1 %descriptor.owner.offset.valid.3220, %descriptor.extent.inside.3218
  %descriptor.range.valid.3221 = and i1 %descriptor.range.inside.3222, %descriptor.payload.inside.3219
  br i1 %descriptor.range.valid.3221, label %descriptor.valid.3223, label %descriptor.invalid.3224
descriptor.invalid.3224:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3223:
  %descriptor.initialized.status.3225 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3209, i32 %local.check.extent.3210)
  %helper.ok.3226 = icmp eq i32 %descriptor.initialized.status.3225, 0
  br i1 %helper.ok.3226, label %helper.continue.3227, label %frame.failure.0
helper.continue.3227:
  br label %local.descriptor.checked.3208
local.descriptor.inactive.3207:
  br label %local.descriptor.checked.3208
local.descriptor.checked.3208:
  %local.is.active.3228 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.3228, label %local.descriptor.active.3229, label %local.descriptor.inactive.3230
local.descriptor.active.3229:
  %local.check.offset.3232 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.3233 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.3234 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.3235 = load i32, ptr %local.owner.end.30, align 4
  %context.field.3236 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3237 = load i32, ptr %context.field.3236, align 4
  %stack.sub.3240 = sub i32 %local.check.owner.end.3235, %local.check.offset.3232
  %descriptor.owner.inside.3238 = icmp ule i32 %local.check.owner.end.3235, %context.value.3237
  %descriptor.offset.inside.3239 = icmp ule i32 %local.check.offset.3232, %local.check.owner.end.3235
  %descriptor.extent.inside.3241 = icmp ule i32 %local.check.extent.3233, %stack.sub.3240
  %descriptor.payload.inside.3242 = icmp ule i32 %local.check.payload.3234, %local.check.extent.3233
  %descriptor.owner.offset.valid.3243 = and i1 %descriptor.owner.inside.3238, %descriptor.offset.inside.3239
  %descriptor.range.inside.3245 = and i1 %descriptor.owner.offset.valid.3243, %descriptor.extent.inside.3241
  %descriptor.range.valid.3244 = and i1 %descriptor.range.inside.3245, %descriptor.payload.inside.3242
  br i1 %descriptor.range.valid.3244, label %descriptor.valid.3246, label %descriptor.invalid.3247
descriptor.invalid.3247:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3246:
  %descriptor.initialized.status.3248 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3232, i32 %local.check.extent.3233)
  %helper.ok.3249 = icmp eq i32 %descriptor.initialized.status.3248, 0
  br i1 %helper.ok.3249, label %helper.continue.3250, label %frame.failure.0
helper.continue.3250:
  br label %local.descriptor.checked.3231
local.descriptor.inactive.3230:
  br label %local.descriptor.checked.3231
local.descriptor.checked.3231:
  %local.is.active.3251 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.3251, label %local.descriptor.active.3252, label %local.descriptor.inactive.3253
local.descriptor.active.3252:
  %local.check.offset.3255 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.3256 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.3257 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.3258 = load i32, ptr %local.owner.end.36, align 4
  %context.field.3259 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3260 = load i32, ptr %context.field.3259, align 4
  %stack.sub.3263 = sub i32 %local.check.owner.end.3258, %local.check.offset.3255
  %descriptor.owner.inside.3261 = icmp ule i32 %local.check.owner.end.3258, %context.value.3260
  %descriptor.offset.inside.3262 = icmp ule i32 %local.check.offset.3255, %local.check.owner.end.3258
  %descriptor.extent.inside.3264 = icmp ule i32 %local.check.extent.3256, %stack.sub.3263
  %descriptor.payload.inside.3265 = icmp ule i32 %local.check.payload.3257, %local.check.extent.3256
  %descriptor.owner.offset.valid.3266 = and i1 %descriptor.owner.inside.3261, %descriptor.offset.inside.3262
  %descriptor.range.inside.3268 = and i1 %descriptor.owner.offset.valid.3266, %descriptor.extent.inside.3264
  %descriptor.range.valid.3267 = and i1 %descriptor.range.inside.3268, %descriptor.payload.inside.3265
  br i1 %descriptor.range.valid.3267, label %descriptor.valid.3269, label %descriptor.invalid.3270
descriptor.invalid.3270:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3269:
  %descriptor.initialized.status.3271 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3255, i32 %local.check.extent.3256)
  %helper.ok.3272 = icmp eq i32 %descriptor.initialized.status.3271, 0
  br i1 %helper.ok.3272, label %helper.continue.3273, label %frame.failure.0
helper.continue.3273:
  br label %local.descriptor.checked.3254
local.descriptor.inactive.3253:
  br label %local.descriptor.checked.3254
local.descriptor.checked.3254:
  %local.is.active.3274 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.3274, label %local.descriptor.active.3275, label %local.descriptor.inactive.3276
local.descriptor.active.3275:
  %local.check.offset.3278 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.3279 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.3280 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.3281 = load i32, ptr %local.owner.end.42, align 4
  %context.field.3282 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3283 = load i32, ptr %context.field.3282, align 4
  %stack.sub.3286 = sub i32 %local.check.owner.end.3281, %local.check.offset.3278
  %descriptor.owner.inside.3284 = icmp ule i32 %local.check.owner.end.3281, %context.value.3283
  %descriptor.offset.inside.3285 = icmp ule i32 %local.check.offset.3278, %local.check.owner.end.3281
  %descriptor.extent.inside.3287 = icmp ule i32 %local.check.extent.3279, %stack.sub.3286
  %descriptor.payload.inside.3288 = icmp ule i32 %local.check.payload.3280, %local.check.extent.3279
  %descriptor.owner.offset.valid.3289 = and i1 %descriptor.owner.inside.3284, %descriptor.offset.inside.3285
  %descriptor.range.inside.3291 = and i1 %descriptor.owner.offset.valid.3289, %descriptor.extent.inside.3287
  %descriptor.range.valid.3290 = and i1 %descriptor.range.inside.3291, %descriptor.payload.inside.3288
  br i1 %descriptor.range.valid.3290, label %descriptor.valid.3292, label %descriptor.invalid.3293
descriptor.invalid.3293:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3292:
  %descriptor.initialized.status.3294 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3278, i32 %local.check.extent.3279)
  %helper.ok.3295 = icmp eq i32 %descriptor.initialized.status.3294, 0
  br i1 %helper.ok.3295, label %helper.continue.3296, label %frame.failure.0
helper.continue.3296:
  br label %local.descriptor.checked.3277
local.descriptor.inactive.3276:
  br label %local.descriptor.checked.3277
local.descriptor.checked.3277:
  %step.status.3297 = call i32 @al_owning_charge_step(ptr %ctx, i32 57)
  %helper.ok.3298 = icmp eq i32 %step.status.3297, 0
  br i1 %helper.ok.3298, label %helper.continue.3299, label %frame.failure.0
helper.continue.3299:
  %local.resolved.offset.3300 = load i32, ptr %local.offset.9, align 4
  %local.resolved.extent.3301 = load i32, ptr %local.extent.10, align 4
  %local.resolved.payload.3302 = load i32, ptr %local.payload.11, align 4
  %local.resolved.owner.end.3303 = load i32, ptr %local.owner.end.12, align 4
  %context.field.3304 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3305 = load i32, ptr %context.field.3304, align 4
  %stack.sub.3308 = sub i32 %local.resolved.owner.end.3303, %local.resolved.offset.3300
  %descriptor.owner.inside.3306 = icmp ule i32 %local.resolved.owner.end.3303, %context.value.3305
  %descriptor.offset.inside.3307 = icmp ule i32 %local.resolved.offset.3300, %local.resolved.owner.end.3303
  %descriptor.extent.inside.3309 = icmp ule i32 %local.resolved.extent.3301, %stack.sub.3308
  %descriptor.payload.inside.3310 = icmp ule i32 %local.resolved.payload.3302, %local.resolved.extent.3301
  %descriptor.owner.offset.valid.3311 = and i1 %descriptor.owner.inside.3306, %descriptor.offset.inside.3307
  %descriptor.range.inside.3313 = and i1 %descriptor.owner.offset.valid.3311, %descriptor.extent.inside.3309
  %descriptor.range.valid.3312 = and i1 %descriptor.range.inside.3313, %descriptor.payload.inside.3310
  %descriptor.type.valid.3314 = icmp eq i32 4, 4
  %descriptor.valid.3315 = and i1 %descriptor.range.valid.3312, %descriptor.type.valid.3314
  br i1 %descriptor.valid.3315, label %descriptor.valid.3316, label %descriptor.invalid.3317
descriptor.invalid.3317:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3316:
  %descriptor.initialized.status.3318 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.3300, i32 %local.resolved.extent.3301)
  %helper.ok.3319 = icmp eq i32 %descriptor.initialized.status.3318, 0
  br i1 %helper.ok.3319, label %helper.continue.3320, label %frame.failure.0
helper.continue.3320:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %local.resolved.offset.3300, i32 20, i32 %local.resolved.payload.3302, i32 %local.resolved.owner.end.3303, i32 %local.resolved.extent.3301)
  %context.field.3321 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3322 = load i32, ptr %context.field.3321, align 4
  %runtime.ok.3323 = icmp eq i32 %context.value.3322, 0
  br i1 %runtime.ok.3323, label %runtime.continue.3324, label %frame.failure.0
runtime.continue.3324:
  %context.field.3325 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3326 = load i32, ptr %context.field.3325, align 4
  %stack.sub.3329 = sub i32 %local.resolved.owner.end.2897, %field.offset.3110
  %descriptor.owner.inside.3327 = icmp ule i32 %local.resolved.owner.end.2897, %context.value.3326
  %descriptor.offset.inside.3328 = icmp ule i32 %field.offset.3110, %local.resolved.owner.end.2897
  %descriptor.extent.inside.3330 = icmp ule i32 %field.extent.3114, %stack.sub.3329
  %descriptor.payload.inside.3331 = icmp ule i32 %field.payload.3112, %field.extent.3114
  %descriptor.owner.offset.valid.3332 = and i1 %descriptor.owner.inside.3327, %descriptor.offset.inside.3328
  %descriptor.range.inside.3334 = and i1 %descriptor.owner.offset.valid.3332, %descriptor.extent.inside.3330
  %descriptor.range.valid.3333 = and i1 %descriptor.range.inside.3334, %descriptor.payload.inside.3331
  %descriptor.type.valid.3335 = icmp eq i32 6, 6
  %descriptor.valid.3336 = and i1 %descriptor.range.valid.3333, %descriptor.type.valid.3335
  br i1 %descriptor.valid.3336, label %descriptor.valid.3337, label %descriptor.invalid.3338
descriptor.invalid.3338:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3337:
  %descriptor.initialized.status.3339 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %field.offset.3110, i32 %field.extent.3114)
  %helper.ok.3340 = icmp eq i32 %descriptor.initialized.status.3339, 0
  br i1 %helper.ok.3340, label %helper.continue.3341, label %frame.failure.0
helper.continue.3341:
  %context.field.3342 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3343 = load i32, ptr %context.field.3342, align 4
  %stack.sub.3346 = sub i32 %local.resolved.owner.end.3303, %local.resolved.offset.3300
  %descriptor.owner.inside.3344 = icmp ule i32 %local.resolved.owner.end.3303, %context.value.3343
  %descriptor.offset.inside.3345 = icmp ule i32 %local.resolved.offset.3300, %local.resolved.owner.end.3303
  %descriptor.extent.inside.3347 = icmp ule i32 %local.resolved.extent.3301, %stack.sub.3346
  %descriptor.payload.inside.3348 = icmp ule i32 %local.resolved.payload.3302, %local.resolved.extent.3301
  %descriptor.owner.offset.valid.3349 = and i1 %descriptor.owner.inside.3344, %descriptor.offset.inside.3345
  %descriptor.range.inside.3351 = and i1 %descriptor.owner.offset.valid.3349, %descriptor.extent.inside.3347
  %descriptor.range.valid.3350 = and i1 %descriptor.range.inside.3351, %descriptor.payload.inside.3348
  %descriptor.type.valid.3352 = icmp eq i32 4, 4
  %descriptor.valid.3353 = and i1 %descriptor.range.valid.3350, %descriptor.type.valid.3352
  br i1 %descriptor.valid.3353, label %descriptor.valid.3354, label %descriptor.invalid.3355
descriptor.invalid.3355:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3354:
  %descriptor.initialized.status.3356 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.3300, i32 %local.resolved.extent.3301)
  %helper.ok.3357 = icmp eq i32 %descriptor.initialized.status.3356, 0
  br i1 %helper.ok.3357, label %helper.continue.3358, label %frame.failure.0
helper.continue.3358:
  %local.is.active.3359 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.3359, label %local.descriptor.active.3360, label %local.descriptor.inactive.3361
local.descriptor.active.3360:
  %local.check.offset.3363 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.3364 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.3365 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.3366 = load i32, ptr %local.owner.end.6, align 4
  %context.field.3367 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3368 = load i32, ptr %context.field.3367, align 4
  %stack.sub.3371 = sub i32 %local.check.owner.end.3366, %local.check.offset.3363
  %descriptor.owner.inside.3369 = icmp ule i32 %local.check.owner.end.3366, %context.value.3368
  %descriptor.offset.inside.3370 = icmp ule i32 %local.check.offset.3363, %local.check.owner.end.3366
  %descriptor.extent.inside.3372 = icmp ule i32 %local.check.extent.3364, %stack.sub.3371
  %descriptor.payload.inside.3373 = icmp ule i32 %local.check.payload.3365, %local.check.extent.3364
  %descriptor.owner.offset.valid.3374 = and i1 %descriptor.owner.inside.3369, %descriptor.offset.inside.3370
  %descriptor.range.inside.3376 = and i1 %descriptor.owner.offset.valid.3374, %descriptor.extent.inside.3372
  %descriptor.range.valid.3375 = and i1 %descriptor.range.inside.3376, %descriptor.payload.inside.3373
  br i1 %descriptor.range.valid.3375, label %descriptor.valid.3377, label %descriptor.invalid.3378
descriptor.invalid.3378:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3377:
  %descriptor.initialized.status.3379 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3363, i32 %local.check.extent.3364)
  %helper.ok.3380 = icmp eq i32 %descriptor.initialized.status.3379, 0
  br i1 %helper.ok.3380, label %helper.continue.3381, label %frame.failure.0
helper.continue.3381:
  br label %local.descriptor.checked.3362
local.descriptor.inactive.3361:
  br label %local.descriptor.checked.3362
local.descriptor.checked.3362:
  %local.is.active.3382 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.3382, label %local.descriptor.active.3383, label %local.descriptor.inactive.3384
local.descriptor.active.3383:
  %local.check.offset.3386 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.3387 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.3388 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.3389 = load i32, ptr %local.owner.end.12, align 4
  %context.field.3390 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3391 = load i32, ptr %context.field.3390, align 4
  %stack.sub.3394 = sub i32 %local.check.owner.end.3389, %local.check.offset.3386
  %descriptor.owner.inside.3392 = icmp ule i32 %local.check.owner.end.3389, %context.value.3391
  %descriptor.offset.inside.3393 = icmp ule i32 %local.check.offset.3386, %local.check.owner.end.3389
  %descriptor.extent.inside.3395 = icmp ule i32 %local.check.extent.3387, %stack.sub.3394
  %descriptor.payload.inside.3396 = icmp ule i32 %local.check.payload.3388, %local.check.extent.3387
  %descriptor.owner.offset.valid.3397 = and i1 %descriptor.owner.inside.3392, %descriptor.offset.inside.3393
  %descriptor.range.inside.3399 = and i1 %descriptor.owner.offset.valid.3397, %descriptor.extent.inside.3395
  %descriptor.range.valid.3398 = and i1 %descriptor.range.inside.3399, %descriptor.payload.inside.3396
  br i1 %descriptor.range.valid.3398, label %descriptor.valid.3400, label %descriptor.invalid.3401
descriptor.invalid.3401:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3400:
  %descriptor.initialized.status.3402 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3386, i32 %local.check.extent.3387)
  %helper.ok.3403 = icmp eq i32 %descriptor.initialized.status.3402, 0
  br i1 %helper.ok.3403, label %helper.continue.3404, label %frame.failure.0
helper.continue.3404:
  br label %local.descriptor.checked.3385
local.descriptor.inactive.3384:
  br label %local.descriptor.checked.3385
local.descriptor.checked.3385:
  %local.is.active.3405 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.3405, label %local.descriptor.active.3406, label %local.descriptor.inactive.3407
local.descriptor.active.3406:
  %local.check.offset.3409 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.3410 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.3411 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.3412 = load i32, ptr %local.owner.end.18, align 4
  %context.field.3413 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3414 = load i32, ptr %context.field.3413, align 4
  %stack.sub.3417 = sub i32 %local.check.owner.end.3412, %local.check.offset.3409
  %descriptor.owner.inside.3415 = icmp ule i32 %local.check.owner.end.3412, %context.value.3414
  %descriptor.offset.inside.3416 = icmp ule i32 %local.check.offset.3409, %local.check.owner.end.3412
  %descriptor.extent.inside.3418 = icmp ule i32 %local.check.extent.3410, %stack.sub.3417
  %descriptor.payload.inside.3419 = icmp ule i32 %local.check.payload.3411, %local.check.extent.3410
  %descriptor.owner.offset.valid.3420 = and i1 %descriptor.owner.inside.3415, %descriptor.offset.inside.3416
  %descriptor.range.inside.3422 = and i1 %descriptor.owner.offset.valid.3420, %descriptor.extent.inside.3418
  %descriptor.range.valid.3421 = and i1 %descriptor.range.inside.3422, %descriptor.payload.inside.3419
  br i1 %descriptor.range.valid.3421, label %descriptor.valid.3423, label %descriptor.invalid.3424
descriptor.invalid.3424:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3423:
  %descriptor.initialized.status.3425 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3409, i32 %local.check.extent.3410)
  %helper.ok.3426 = icmp eq i32 %descriptor.initialized.status.3425, 0
  br i1 %helper.ok.3426, label %helper.continue.3427, label %frame.failure.0
helper.continue.3427:
  br label %local.descriptor.checked.3408
local.descriptor.inactive.3407:
  br label %local.descriptor.checked.3408
local.descriptor.checked.3408:
  %local.is.active.3428 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.3428, label %local.descriptor.active.3429, label %local.descriptor.inactive.3430
local.descriptor.active.3429:
  %local.check.offset.3432 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.3433 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.3434 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.3435 = load i32, ptr %local.owner.end.24, align 4
  %context.field.3436 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3437 = load i32, ptr %context.field.3436, align 4
  %stack.sub.3440 = sub i32 %local.check.owner.end.3435, %local.check.offset.3432
  %descriptor.owner.inside.3438 = icmp ule i32 %local.check.owner.end.3435, %context.value.3437
  %descriptor.offset.inside.3439 = icmp ule i32 %local.check.offset.3432, %local.check.owner.end.3435
  %descriptor.extent.inside.3441 = icmp ule i32 %local.check.extent.3433, %stack.sub.3440
  %descriptor.payload.inside.3442 = icmp ule i32 %local.check.payload.3434, %local.check.extent.3433
  %descriptor.owner.offset.valid.3443 = and i1 %descriptor.owner.inside.3438, %descriptor.offset.inside.3439
  %descriptor.range.inside.3445 = and i1 %descriptor.owner.offset.valid.3443, %descriptor.extent.inside.3441
  %descriptor.range.valid.3444 = and i1 %descriptor.range.inside.3445, %descriptor.payload.inside.3442
  br i1 %descriptor.range.valid.3444, label %descriptor.valid.3446, label %descriptor.invalid.3447
descriptor.invalid.3447:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3446:
  %descriptor.initialized.status.3448 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3432, i32 %local.check.extent.3433)
  %helper.ok.3449 = icmp eq i32 %descriptor.initialized.status.3448, 0
  br i1 %helper.ok.3449, label %helper.continue.3450, label %frame.failure.0
helper.continue.3450:
  br label %local.descriptor.checked.3431
local.descriptor.inactive.3430:
  br label %local.descriptor.checked.3431
local.descriptor.checked.3431:
  %local.is.active.3451 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.3451, label %local.descriptor.active.3452, label %local.descriptor.inactive.3453
local.descriptor.active.3452:
  %local.check.offset.3455 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.3456 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.3457 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.3458 = load i32, ptr %local.owner.end.30, align 4
  %context.field.3459 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3460 = load i32, ptr %context.field.3459, align 4
  %stack.sub.3463 = sub i32 %local.check.owner.end.3458, %local.check.offset.3455
  %descriptor.owner.inside.3461 = icmp ule i32 %local.check.owner.end.3458, %context.value.3460
  %descriptor.offset.inside.3462 = icmp ule i32 %local.check.offset.3455, %local.check.owner.end.3458
  %descriptor.extent.inside.3464 = icmp ule i32 %local.check.extent.3456, %stack.sub.3463
  %descriptor.payload.inside.3465 = icmp ule i32 %local.check.payload.3457, %local.check.extent.3456
  %descriptor.owner.offset.valid.3466 = and i1 %descriptor.owner.inside.3461, %descriptor.offset.inside.3462
  %descriptor.range.inside.3468 = and i1 %descriptor.owner.offset.valid.3466, %descriptor.extent.inside.3464
  %descriptor.range.valid.3467 = and i1 %descriptor.range.inside.3468, %descriptor.payload.inside.3465
  br i1 %descriptor.range.valid.3467, label %descriptor.valid.3469, label %descriptor.invalid.3470
descriptor.invalid.3470:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3469:
  %descriptor.initialized.status.3471 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3455, i32 %local.check.extent.3456)
  %helper.ok.3472 = icmp eq i32 %descriptor.initialized.status.3471, 0
  br i1 %helper.ok.3472, label %helper.continue.3473, label %frame.failure.0
helper.continue.3473:
  br label %local.descriptor.checked.3454
local.descriptor.inactive.3453:
  br label %local.descriptor.checked.3454
local.descriptor.checked.3454:
  %local.is.active.3474 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.3474, label %local.descriptor.active.3475, label %local.descriptor.inactive.3476
local.descriptor.active.3475:
  %local.check.offset.3478 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.3479 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.3480 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.3481 = load i32, ptr %local.owner.end.36, align 4
  %context.field.3482 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3483 = load i32, ptr %context.field.3482, align 4
  %stack.sub.3486 = sub i32 %local.check.owner.end.3481, %local.check.offset.3478
  %descriptor.owner.inside.3484 = icmp ule i32 %local.check.owner.end.3481, %context.value.3483
  %descriptor.offset.inside.3485 = icmp ule i32 %local.check.offset.3478, %local.check.owner.end.3481
  %descriptor.extent.inside.3487 = icmp ule i32 %local.check.extent.3479, %stack.sub.3486
  %descriptor.payload.inside.3488 = icmp ule i32 %local.check.payload.3480, %local.check.extent.3479
  %descriptor.owner.offset.valid.3489 = and i1 %descriptor.owner.inside.3484, %descriptor.offset.inside.3485
  %descriptor.range.inside.3491 = and i1 %descriptor.owner.offset.valid.3489, %descriptor.extent.inside.3487
  %descriptor.range.valid.3490 = and i1 %descriptor.range.inside.3491, %descriptor.payload.inside.3488
  br i1 %descriptor.range.valid.3490, label %descriptor.valid.3492, label %descriptor.invalid.3493
descriptor.invalid.3493:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3492:
  %descriptor.initialized.status.3494 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3478, i32 %local.check.extent.3479)
  %helper.ok.3495 = icmp eq i32 %descriptor.initialized.status.3494, 0
  br i1 %helper.ok.3495, label %helper.continue.3496, label %frame.failure.0
helper.continue.3496:
  br label %local.descriptor.checked.3477
local.descriptor.inactive.3476:
  br label %local.descriptor.checked.3477
local.descriptor.checked.3477:
  %local.is.active.3497 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.3497, label %local.descriptor.active.3498, label %local.descriptor.inactive.3499
local.descriptor.active.3498:
  %local.check.offset.3501 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.3502 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.3503 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.3504 = load i32, ptr %local.owner.end.42, align 4
  %context.field.3505 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3506 = load i32, ptr %context.field.3505, align 4
  %stack.sub.3509 = sub i32 %local.check.owner.end.3504, %local.check.offset.3501
  %descriptor.owner.inside.3507 = icmp ule i32 %local.check.owner.end.3504, %context.value.3506
  %descriptor.offset.inside.3508 = icmp ule i32 %local.check.offset.3501, %local.check.owner.end.3504
  %descriptor.extent.inside.3510 = icmp ule i32 %local.check.extent.3502, %stack.sub.3509
  %descriptor.payload.inside.3511 = icmp ule i32 %local.check.payload.3503, %local.check.extent.3502
  %descriptor.owner.offset.valid.3512 = and i1 %descriptor.owner.inside.3507, %descriptor.offset.inside.3508
  %descriptor.range.inside.3514 = and i1 %descriptor.owner.offset.valid.3512, %descriptor.extent.inside.3510
  %descriptor.range.valid.3513 = and i1 %descriptor.range.inside.3514, %descriptor.payload.inside.3511
  br i1 %descriptor.range.valid.3513, label %descriptor.valid.3515, label %descriptor.invalid.3516
descriptor.invalid.3516:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3515:
  %descriptor.initialized.status.3517 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3501, i32 %local.check.extent.3502)
  %helper.ok.3518 = icmp eq i32 %descriptor.initialized.status.3517, 0
  br i1 %helper.ok.3518, label %helper.continue.3519, label %frame.failure.0
helper.continue.3519:
  br label %local.descriptor.checked.3500
local.descriptor.inactive.3499:
  br label %local.descriptor.checked.3500
local.descriptor.checked.3500:
  %step.status.3520 = call i32 @al_owning_charge_step(ptr %ctx, i32 58)
  %helper.ok.3521 = icmp eq i32 %step.status.3520, 0
  br i1 %helper.ok.3521, label %helper.continue.3522, label %frame.failure.0
helper.continue.3522:
  %context.field.3523 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.3524 = load i32, ptr %context.field.3523, align 4
  %inline.target.depth.within.interpreter.limit.3525 = icmp ule i32 %context.value.3524, 65
  br i1 %inline.target.depth.within.interpreter.limit.3525, label %inline.target.depth.ok.3526, label %inline.target.depth.invalid.3527
inline.target.depth.invalid.3527:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 59, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.3526:
  %field.location.status.3529 = call i32 @al_owning_locate_field(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 2, i32 %local.resolved.offset.3300, i32 %local.resolved.extent.3301, i32 0, i32 60, ptr %field.location.3528)
  %helper.ok.3530 = icmp eq i32 %field.location.status.3529, 0
  br i1 %helper.ok.3530, label %helper.continue.3531, label %frame.failure.0
helper.continue.3531:
  %field.offset.pointer.3532 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.3528, i32 0, i32 0
  %field.offset.3533 = load i32, ptr %field.offset.pointer.3532, align 4
  %field.payload.pointer.3534 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.3528, i32 0, i32 1
  %field.payload.3535 = load i32, ptr %field.payload.pointer.3534, align 4
  %field.extent.pointer.3536 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.3528, i32 0, i32 2
  %field.extent.3537 = load i32, ptr %field.extent.pointer.3536, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 7, i32 6, i32 %local.resolved.offset.3300, i32 %field.extent.3537, i32 %field.payload.3535, i32 %field.offset.3533, i32 %field.extent.3537)
  %context.field.3538 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3539 = load i32, ptr %context.field.3538, align 4
  %runtime.ok.3540 = icmp eq i32 %context.value.3539, 0
  br i1 %runtime.ok.3540, label %runtime.continue.3541, label %frame.failure.0
runtime.continue.3541:
  %context.field.3542 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3543 = load i32, ptr %context.field.3542, align 4
  %stack.sub.3546 = sub i32 %local.resolved.owner.end.2897, %field.offset.3110
  %descriptor.owner.inside.3544 = icmp ule i32 %local.resolved.owner.end.2897, %context.value.3543
  %descriptor.offset.inside.3545 = icmp ule i32 %field.offset.3110, %local.resolved.owner.end.2897
  %descriptor.extent.inside.3547 = icmp ule i32 %field.extent.3114, %stack.sub.3546
  %descriptor.payload.inside.3548 = icmp ule i32 %field.payload.3112, %field.extent.3114
  %descriptor.owner.offset.valid.3549 = and i1 %descriptor.owner.inside.3544, %descriptor.offset.inside.3545
  %descriptor.range.inside.3551 = and i1 %descriptor.owner.offset.valid.3549, %descriptor.extent.inside.3547
  %descriptor.range.valid.3550 = and i1 %descriptor.range.inside.3551, %descriptor.payload.inside.3548
  %descriptor.type.valid.3552 = icmp eq i32 6, 6
  %descriptor.valid.3553 = and i1 %descriptor.range.valid.3550, %descriptor.type.valid.3552
  br i1 %descriptor.valid.3553, label %descriptor.valid.3554, label %descriptor.invalid.3555
descriptor.invalid.3555:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3554:
  %descriptor.initialized.status.3556 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %field.offset.3110, i32 %field.extent.3114)
  %helper.ok.3557 = icmp eq i32 %descriptor.initialized.status.3556, 0
  br i1 %helper.ok.3557, label %helper.continue.3558, label %frame.failure.0
helper.continue.3558:
  %context.field.3559 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3560 = load i32, ptr %context.field.3559, align 4
  %stack.sub.3563 = sub i32 %local.resolved.owner.end.3303, %field.offset.3533
  %descriptor.owner.inside.3561 = icmp ule i32 %local.resolved.owner.end.3303, %context.value.3560
  %descriptor.offset.inside.3562 = icmp ule i32 %field.offset.3533, %local.resolved.owner.end.3303
  %descriptor.extent.inside.3564 = icmp ule i32 %field.extent.3537, %stack.sub.3563
  %descriptor.payload.inside.3565 = icmp ule i32 %field.payload.3535, %field.extent.3537
  %descriptor.owner.offset.valid.3566 = and i1 %descriptor.owner.inside.3561, %descriptor.offset.inside.3562
  %descriptor.range.inside.3568 = and i1 %descriptor.owner.offset.valid.3566, %descriptor.extent.inside.3564
  %descriptor.range.valid.3567 = and i1 %descriptor.range.inside.3568, %descriptor.payload.inside.3565
  %descriptor.type.valid.3569 = icmp eq i32 6, 6
  %descriptor.valid.3570 = and i1 %descriptor.range.valid.3567, %descriptor.type.valid.3569
  br i1 %descriptor.valid.3570, label %descriptor.valid.3571, label %descriptor.invalid.3572
descriptor.invalid.3572:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3571:
  %descriptor.initialized.status.3573 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %field.offset.3533, i32 %field.extent.3537)
  %helper.ok.3574 = icmp eq i32 %descriptor.initialized.status.3573, 0
  br i1 %helper.ok.3574, label %helper.continue.3575, label %frame.failure.0
helper.continue.3575:
  %local.is.active.3576 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.3576, label %local.descriptor.active.3577, label %local.descriptor.inactive.3578
local.descriptor.active.3577:
  %local.check.offset.3580 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.3581 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.3582 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.3583 = load i32, ptr %local.owner.end.6, align 4
  %context.field.3584 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3585 = load i32, ptr %context.field.3584, align 4
  %stack.sub.3588 = sub i32 %local.check.owner.end.3583, %local.check.offset.3580
  %descriptor.owner.inside.3586 = icmp ule i32 %local.check.owner.end.3583, %context.value.3585
  %descriptor.offset.inside.3587 = icmp ule i32 %local.check.offset.3580, %local.check.owner.end.3583
  %descriptor.extent.inside.3589 = icmp ule i32 %local.check.extent.3581, %stack.sub.3588
  %descriptor.payload.inside.3590 = icmp ule i32 %local.check.payload.3582, %local.check.extent.3581
  %descriptor.owner.offset.valid.3591 = and i1 %descriptor.owner.inside.3586, %descriptor.offset.inside.3587
  %descriptor.range.inside.3593 = and i1 %descriptor.owner.offset.valid.3591, %descriptor.extent.inside.3589
  %descriptor.range.valid.3592 = and i1 %descriptor.range.inside.3593, %descriptor.payload.inside.3590
  br i1 %descriptor.range.valid.3592, label %descriptor.valid.3594, label %descriptor.invalid.3595
descriptor.invalid.3595:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3594:
  %descriptor.initialized.status.3596 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3580, i32 %local.check.extent.3581)
  %helper.ok.3597 = icmp eq i32 %descriptor.initialized.status.3596, 0
  br i1 %helper.ok.3597, label %helper.continue.3598, label %frame.failure.0
helper.continue.3598:
  br label %local.descriptor.checked.3579
local.descriptor.inactive.3578:
  br label %local.descriptor.checked.3579
local.descriptor.checked.3579:
  %local.is.active.3599 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.3599, label %local.descriptor.active.3600, label %local.descriptor.inactive.3601
local.descriptor.active.3600:
  %local.check.offset.3603 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.3604 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.3605 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.3606 = load i32, ptr %local.owner.end.12, align 4
  %context.field.3607 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3608 = load i32, ptr %context.field.3607, align 4
  %stack.sub.3611 = sub i32 %local.check.owner.end.3606, %local.check.offset.3603
  %descriptor.owner.inside.3609 = icmp ule i32 %local.check.owner.end.3606, %context.value.3608
  %descriptor.offset.inside.3610 = icmp ule i32 %local.check.offset.3603, %local.check.owner.end.3606
  %descriptor.extent.inside.3612 = icmp ule i32 %local.check.extent.3604, %stack.sub.3611
  %descriptor.payload.inside.3613 = icmp ule i32 %local.check.payload.3605, %local.check.extent.3604
  %descriptor.owner.offset.valid.3614 = and i1 %descriptor.owner.inside.3609, %descriptor.offset.inside.3610
  %descriptor.range.inside.3616 = and i1 %descriptor.owner.offset.valid.3614, %descriptor.extent.inside.3612
  %descriptor.range.valid.3615 = and i1 %descriptor.range.inside.3616, %descriptor.payload.inside.3613
  br i1 %descriptor.range.valid.3615, label %descriptor.valid.3617, label %descriptor.invalid.3618
descriptor.invalid.3618:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3617:
  %descriptor.initialized.status.3619 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3603, i32 %local.check.extent.3604)
  %helper.ok.3620 = icmp eq i32 %descriptor.initialized.status.3619, 0
  br i1 %helper.ok.3620, label %helper.continue.3621, label %frame.failure.0
helper.continue.3621:
  br label %local.descriptor.checked.3602
local.descriptor.inactive.3601:
  br label %local.descriptor.checked.3602
local.descriptor.checked.3602:
  %local.is.active.3622 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.3622, label %local.descriptor.active.3623, label %local.descriptor.inactive.3624
local.descriptor.active.3623:
  %local.check.offset.3626 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.3627 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.3628 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.3629 = load i32, ptr %local.owner.end.18, align 4
  %context.field.3630 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3631 = load i32, ptr %context.field.3630, align 4
  %stack.sub.3634 = sub i32 %local.check.owner.end.3629, %local.check.offset.3626
  %descriptor.owner.inside.3632 = icmp ule i32 %local.check.owner.end.3629, %context.value.3631
  %descriptor.offset.inside.3633 = icmp ule i32 %local.check.offset.3626, %local.check.owner.end.3629
  %descriptor.extent.inside.3635 = icmp ule i32 %local.check.extent.3627, %stack.sub.3634
  %descriptor.payload.inside.3636 = icmp ule i32 %local.check.payload.3628, %local.check.extent.3627
  %descriptor.owner.offset.valid.3637 = and i1 %descriptor.owner.inside.3632, %descriptor.offset.inside.3633
  %descriptor.range.inside.3639 = and i1 %descriptor.owner.offset.valid.3637, %descriptor.extent.inside.3635
  %descriptor.range.valid.3638 = and i1 %descriptor.range.inside.3639, %descriptor.payload.inside.3636
  br i1 %descriptor.range.valid.3638, label %descriptor.valid.3640, label %descriptor.invalid.3641
descriptor.invalid.3641:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3640:
  %descriptor.initialized.status.3642 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3626, i32 %local.check.extent.3627)
  %helper.ok.3643 = icmp eq i32 %descriptor.initialized.status.3642, 0
  br i1 %helper.ok.3643, label %helper.continue.3644, label %frame.failure.0
helper.continue.3644:
  br label %local.descriptor.checked.3625
local.descriptor.inactive.3624:
  br label %local.descriptor.checked.3625
local.descriptor.checked.3625:
  %local.is.active.3645 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.3645, label %local.descriptor.active.3646, label %local.descriptor.inactive.3647
local.descriptor.active.3646:
  %local.check.offset.3649 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.3650 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.3651 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.3652 = load i32, ptr %local.owner.end.24, align 4
  %context.field.3653 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3654 = load i32, ptr %context.field.3653, align 4
  %stack.sub.3657 = sub i32 %local.check.owner.end.3652, %local.check.offset.3649
  %descriptor.owner.inside.3655 = icmp ule i32 %local.check.owner.end.3652, %context.value.3654
  %descriptor.offset.inside.3656 = icmp ule i32 %local.check.offset.3649, %local.check.owner.end.3652
  %descriptor.extent.inside.3658 = icmp ule i32 %local.check.extent.3650, %stack.sub.3657
  %descriptor.payload.inside.3659 = icmp ule i32 %local.check.payload.3651, %local.check.extent.3650
  %descriptor.owner.offset.valid.3660 = and i1 %descriptor.owner.inside.3655, %descriptor.offset.inside.3656
  %descriptor.range.inside.3662 = and i1 %descriptor.owner.offset.valid.3660, %descriptor.extent.inside.3658
  %descriptor.range.valid.3661 = and i1 %descriptor.range.inside.3662, %descriptor.payload.inside.3659
  br i1 %descriptor.range.valid.3661, label %descriptor.valid.3663, label %descriptor.invalid.3664
descriptor.invalid.3664:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3663:
  %descriptor.initialized.status.3665 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3649, i32 %local.check.extent.3650)
  %helper.ok.3666 = icmp eq i32 %descriptor.initialized.status.3665, 0
  br i1 %helper.ok.3666, label %helper.continue.3667, label %frame.failure.0
helper.continue.3667:
  br label %local.descriptor.checked.3648
local.descriptor.inactive.3647:
  br label %local.descriptor.checked.3648
local.descriptor.checked.3648:
  %local.is.active.3668 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.3668, label %local.descriptor.active.3669, label %local.descriptor.inactive.3670
local.descriptor.active.3669:
  %local.check.offset.3672 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.3673 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.3674 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.3675 = load i32, ptr %local.owner.end.30, align 4
  %context.field.3676 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3677 = load i32, ptr %context.field.3676, align 4
  %stack.sub.3680 = sub i32 %local.check.owner.end.3675, %local.check.offset.3672
  %descriptor.owner.inside.3678 = icmp ule i32 %local.check.owner.end.3675, %context.value.3677
  %descriptor.offset.inside.3679 = icmp ule i32 %local.check.offset.3672, %local.check.owner.end.3675
  %descriptor.extent.inside.3681 = icmp ule i32 %local.check.extent.3673, %stack.sub.3680
  %descriptor.payload.inside.3682 = icmp ule i32 %local.check.payload.3674, %local.check.extent.3673
  %descriptor.owner.offset.valid.3683 = and i1 %descriptor.owner.inside.3678, %descriptor.offset.inside.3679
  %descriptor.range.inside.3685 = and i1 %descriptor.owner.offset.valid.3683, %descriptor.extent.inside.3681
  %descriptor.range.valid.3684 = and i1 %descriptor.range.inside.3685, %descriptor.payload.inside.3682
  br i1 %descriptor.range.valid.3684, label %descriptor.valid.3686, label %descriptor.invalid.3687
descriptor.invalid.3687:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3686:
  %descriptor.initialized.status.3688 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3672, i32 %local.check.extent.3673)
  %helper.ok.3689 = icmp eq i32 %descriptor.initialized.status.3688, 0
  br i1 %helper.ok.3689, label %helper.continue.3690, label %frame.failure.0
helper.continue.3690:
  br label %local.descriptor.checked.3671
local.descriptor.inactive.3670:
  br label %local.descriptor.checked.3671
local.descriptor.checked.3671:
  %local.is.active.3691 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.3691, label %local.descriptor.active.3692, label %local.descriptor.inactive.3693
local.descriptor.active.3692:
  %local.check.offset.3695 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.3696 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.3697 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.3698 = load i32, ptr %local.owner.end.36, align 4
  %context.field.3699 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3700 = load i32, ptr %context.field.3699, align 4
  %stack.sub.3703 = sub i32 %local.check.owner.end.3698, %local.check.offset.3695
  %descriptor.owner.inside.3701 = icmp ule i32 %local.check.owner.end.3698, %context.value.3700
  %descriptor.offset.inside.3702 = icmp ule i32 %local.check.offset.3695, %local.check.owner.end.3698
  %descriptor.extent.inside.3704 = icmp ule i32 %local.check.extent.3696, %stack.sub.3703
  %descriptor.payload.inside.3705 = icmp ule i32 %local.check.payload.3697, %local.check.extent.3696
  %descriptor.owner.offset.valid.3706 = and i1 %descriptor.owner.inside.3701, %descriptor.offset.inside.3702
  %descriptor.range.inside.3708 = and i1 %descriptor.owner.offset.valid.3706, %descriptor.extent.inside.3704
  %descriptor.range.valid.3707 = and i1 %descriptor.range.inside.3708, %descriptor.payload.inside.3705
  br i1 %descriptor.range.valid.3707, label %descriptor.valid.3709, label %descriptor.invalid.3710
descriptor.invalid.3710:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3709:
  %descriptor.initialized.status.3711 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3695, i32 %local.check.extent.3696)
  %helper.ok.3712 = icmp eq i32 %descriptor.initialized.status.3711, 0
  br i1 %helper.ok.3712, label %helper.continue.3713, label %frame.failure.0
helper.continue.3713:
  br label %local.descriptor.checked.3694
local.descriptor.inactive.3693:
  br label %local.descriptor.checked.3694
local.descriptor.checked.3694:
  %local.is.active.3714 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.3714, label %local.descriptor.active.3715, label %local.descriptor.inactive.3716
local.descriptor.active.3715:
  %local.check.offset.3718 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.3719 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.3720 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.3721 = load i32, ptr %local.owner.end.42, align 4
  %context.field.3722 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3723 = load i32, ptr %context.field.3722, align 4
  %stack.sub.3726 = sub i32 %local.check.owner.end.3721, %local.check.offset.3718
  %descriptor.owner.inside.3724 = icmp ule i32 %local.check.owner.end.3721, %context.value.3723
  %descriptor.offset.inside.3725 = icmp ule i32 %local.check.offset.3718, %local.check.owner.end.3721
  %descriptor.extent.inside.3727 = icmp ule i32 %local.check.extent.3719, %stack.sub.3726
  %descriptor.payload.inside.3728 = icmp ule i32 %local.check.payload.3720, %local.check.extent.3719
  %descriptor.owner.offset.valid.3729 = and i1 %descriptor.owner.inside.3724, %descriptor.offset.inside.3725
  %descriptor.range.inside.3731 = and i1 %descriptor.owner.offset.valid.3729, %descriptor.extent.inside.3727
  %descriptor.range.valid.3730 = and i1 %descriptor.range.inside.3731, %descriptor.payload.inside.3728
  br i1 %descriptor.range.valid.3730, label %descriptor.valid.3732, label %descriptor.invalid.3733
descriptor.invalid.3733:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3732:
  %descriptor.initialized.status.3734 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3718, i32 %local.check.extent.3719)
  %helper.ok.3735 = icmp eq i32 %descriptor.initialized.status.3734, 0
  br i1 %helper.ok.3735, label %helper.continue.3736, label %frame.failure.0
helper.continue.3736:
  br label %local.descriptor.checked.3717
local.descriptor.inactive.3716:
  br label %local.descriptor.checked.3717
local.descriptor.checked.3717:
  %step.status.3737 = call i32 @al_owning_charge_step(ptr %ctx, i32 61)
  %helper.ok.3738 = icmp eq i32 %step.status.3737, 0
  br i1 %helper.ok.3738, label %helper.continue.3739, label %frame.failure.0
helper.continue.3739:
  %context.field.3740 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.3741 = load i32, ptr %context.field.3740, align 4
  %inline.target.depth.within.interpreter.limit.3742 = icmp ule i32 %context.value.3741, 65
  br i1 %inline.target.depth.within.interpreter.limit.3742, label %inline.target.depth.ok.3743, label %inline.target.depth.invalid.3744
inline.target.depth.invalid.3744:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 62, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.3743:
  %context.field.3745 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3746 = load i32, ptr %context.field.3745, align 4
  %string.concat.plan.status.3750 = call i32 @al_owning_string_concat_plan(ptr %ctx, i32 %field.offset.3110, i32 %field.extent.3114, i32 %field.offset.3533, i32 %field.extent.3537, i32 63, ptr %string.concat.units.3747, ptr %string.concat.payload.pointer.3748, ptr %string.concat.extent.pointer.3749)
  %helper.ok.3751 = icmp eq i32 %string.concat.plan.status.3750, 0
  br i1 %helper.ok.3751, label %helper.continue.3752, label %frame.failure.0
helper.continue.3752:
  %string.concat.payload.3753 = load i32, ptr %string.concat.payload.pointer.3748, align 4
  %string.concat.extent.3754 = load i32, ptr %string.concat.extent.pointer.3749, align 4
  %stack.offset.3755 = add i32 %context.value.3746, %string.concat.extent.3754
  %reserve.status.3756 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.3755, i32 64)
  %reserve.ok.3757 = icmp eq i32 %reserve.status.3756, 0
  br i1 %reserve.ok.3757, label %reserve.continue.3758, label %frame.failure.0
reserve.continue.3758:
  %string.concat.write.status.3759 = call i32 @al_owning_string_concat_write(ptr %ctx, i32 %context.value.3746, i32 %string.concat.extent.3754, i32 %field.offset.3110, i32 %field.extent.3114, i32 %field.offset.3533, i32 %field.extent.3537, i32 6, i32 63)
  %helper.ok.3760 = icmp eq i32 %string.concat.write.status.3759, 0
  br i1 %helper.ok.3760, label %helper.continue.3761, label %frame.failure.0
helper.continue.3761:
  call void @al_owning_update_live(ptr %ctx, i32 %string.concat.payload.3753, i32 0)
  %context.field.3762 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3763 = load i32, ptr %context.field.3762, align 4
  %runtime.ok.3764 = icmp eq i32 %context.value.3763, 0
  br i1 %runtime.ok.3764, label %runtime.continue.3765, label %frame.failure.0
runtime.continue.3765:
  %context.field.3766 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3767 = load i32, ptr %context.field.3766, align 4
  %stack.sub.3770 = sub i32 %stack.offset.3755, %context.value.3746
  %descriptor.owner.inside.3768 = icmp ule i32 %stack.offset.3755, %context.value.3767
  %descriptor.offset.inside.3769 = icmp ule i32 %context.value.3746, %stack.offset.3755
  %descriptor.extent.inside.3771 = icmp ule i32 %string.concat.extent.3754, %stack.sub.3770
  %descriptor.payload.inside.3772 = icmp ule i32 %string.concat.payload.3753, %string.concat.extent.3754
  %descriptor.owner.offset.valid.3773 = and i1 %descriptor.owner.inside.3768, %descriptor.offset.inside.3769
  %descriptor.range.inside.3775 = and i1 %descriptor.owner.offset.valid.3773, %descriptor.extent.inside.3771
  %descriptor.range.valid.3774 = and i1 %descriptor.range.inside.3775, %descriptor.payload.inside.3772
  %descriptor.type.valid.3776 = icmp eq i32 6, 6
  %descriptor.valid.3777 = and i1 %descriptor.range.valid.3774, %descriptor.type.valid.3776
  br i1 %descriptor.valid.3777, label %descriptor.valid.3778, label %descriptor.invalid.3779
descriptor.invalid.3779:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3778:
  %descriptor.initialized.status.3780 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.3746, i32 %string.concat.extent.3754)
  %helper.ok.3781 = icmp eq i32 %descriptor.initialized.status.3780, 0
  br i1 %helper.ok.3781, label %helper.continue.3782, label %frame.failure.0
helper.continue.3782:
  %local.is.active.3783 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.3783, label %local.descriptor.active.3784, label %local.descriptor.inactive.3785
local.descriptor.active.3784:
  %local.check.offset.3787 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.3788 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.3789 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.3790 = load i32, ptr %local.owner.end.6, align 4
  %context.field.3791 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3792 = load i32, ptr %context.field.3791, align 4
  %stack.sub.3795 = sub i32 %local.check.owner.end.3790, %local.check.offset.3787
  %descriptor.owner.inside.3793 = icmp ule i32 %local.check.owner.end.3790, %context.value.3792
  %descriptor.offset.inside.3794 = icmp ule i32 %local.check.offset.3787, %local.check.owner.end.3790
  %descriptor.extent.inside.3796 = icmp ule i32 %local.check.extent.3788, %stack.sub.3795
  %descriptor.payload.inside.3797 = icmp ule i32 %local.check.payload.3789, %local.check.extent.3788
  %descriptor.owner.offset.valid.3798 = and i1 %descriptor.owner.inside.3793, %descriptor.offset.inside.3794
  %descriptor.range.inside.3800 = and i1 %descriptor.owner.offset.valid.3798, %descriptor.extent.inside.3796
  %descriptor.range.valid.3799 = and i1 %descriptor.range.inside.3800, %descriptor.payload.inside.3797
  br i1 %descriptor.range.valid.3799, label %descriptor.valid.3801, label %descriptor.invalid.3802
descriptor.invalid.3802:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3801:
  %descriptor.initialized.status.3803 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3787, i32 %local.check.extent.3788)
  %helper.ok.3804 = icmp eq i32 %descriptor.initialized.status.3803, 0
  br i1 %helper.ok.3804, label %helper.continue.3805, label %frame.failure.0
helper.continue.3805:
  br label %local.descriptor.checked.3786
local.descriptor.inactive.3785:
  br label %local.descriptor.checked.3786
local.descriptor.checked.3786:
  %local.is.active.3806 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.3806, label %local.descriptor.active.3807, label %local.descriptor.inactive.3808
local.descriptor.active.3807:
  %local.check.offset.3810 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.3811 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.3812 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.3813 = load i32, ptr %local.owner.end.12, align 4
  %context.field.3814 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3815 = load i32, ptr %context.field.3814, align 4
  %stack.sub.3818 = sub i32 %local.check.owner.end.3813, %local.check.offset.3810
  %descriptor.owner.inside.3816 = icmp ule i32 %local.check.owner.end.3813, %context.value.3815
  %descriptor.offset.inside.3817 = icmp ule i32 %local.check.offset.3810, %local.check.owner.end.3813
  %descriptor.extent.inside.3819 = icmp ule i32 %local.check.extent.3811, %stack.sub.3818
  %descriptor.payload.inside.3820 = icmp ule i32 %local.check.payload.3812, %local.check.extent.3811
  %descriptor.owner.offset.valid.3821 = and i1 %descriptor.owner.inside.3816, %descriptor.offset.inside.3817
  %descriptor.range.inside.3823 = and i1 %descriptor.owner.offset.valid.3821, %descriptor.extent.inside.3819
  %descriptor.range.valid.3822 = and i1 %descriptor.range.inside.3823, %descriptor.payload.inside.3820
  br i1 %descriptor.range.valid.3822, label %descriptor.valid.3824, label %descriptor.invalid.3825
descriptor.invalid.3825:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3824:
  %descriptor.initialized.status.3826 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3810, i32 %local.check.extent.3811)
  %helper.ok.3827 = icmp eq i32 %descriptor.initialized.status.3826, 0
  br i1 %helper.ok.3827, label %helper.continue.3828, label %frame.failure.0
helper.continue.3828:
  br label %local.descriptor.checked.3809
local.descriptor.inactive.3808:
  br label %local.descriptor.checked.3809
local.descriptor.checked.3809:
  %local.is.active.3829 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.3829, label %local.descriptor.active.3830, label %local.descriptor.inactive.3831
local.descriptor.active.3830:
  %local.check.offset.3833 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.3834 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.3835 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.3836 = load i32, ptr %local.owner.end.18, align 4
  %context.field.3837 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3838 = load i32, ptr %context.field.3837, align 4
  %stack.sub.3841 = sub i32 %local.check.owner.end.3836, %local.check.offset.3833
  %descriptor.owner.inside.3839 = icmp ule i32 %local.check.owner.end.3836, %context.value.3838
  %descriptor.offset.inside.3840 = icmp ule i32 %local.check.offset.3833, %local.check.owner.end.3836
  %descriptor.extent.inside.3842 = icmp ule i32 %local.check.extent.3834, %stack.sub.3841
  %descriptor.payload.inside.3843 = icmp ule i32 %local.check.payload.3835, %local.check.extent.3834
  %descriptor.owner.offset.valid.3844 = and i1 %descriptor.owner.inside.3839, %descriptor.offset.inside.3840
  %descriptor.range.inside.3846 = and i1 %descriptor.owner.offset.valid.3844, %descriptor.extent.inside.3842
  %descriptor.range.valid.3845 = and i1 %descriptor.range.inside.3846, %descriptor.payload.inside.3843
  br i1 %descriptor.range.valid.3845, label %descriptor.valid.3847, label %descriptor.invalid.3848
descriptor.invalid.3848:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3847:
  %descriptor.initialized.status.3849 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3833, i32 %local.check.extent.3834)
  %helper.ok.3850 = icmp eq i32 %descriptor.initialized.status.3849, 0
  br i1 %helper.ok.3850, label %helper.continue.3851, label %frame.failure.0
helper.continue.3851:
  br label %local.descriptor.checked.3832
local.descriptor.inactive.3831:
  br label %local.descriptor.checked.3832
local.descriptor.checked.3832:
  %local.is.active.3852 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.3852, label %local.descriptor.active.3853, label %local.descriptor.inactive.3854
local.descriptor.active.3853:
  %local.check.offset.3856 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.3857 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.3858 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.3859 = load i32, ptr %local.owner.end.24, align 4
  %context.field.3860 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3861 = load i32, ptr %context.field.3860, align 4
  %stack.sub.3864 = sub i32 %local.check.owner.end.3859, %local.check.offset.3856
  %descriptor.owner.inside.3862 = icmp ule i32 %local.check.owner.end.3859, %context.value.3861
  %descriptor.offset.inside.3863 = icmp ule i32 %local.check.offset.3856, %local.check.owner.end.3859
  %descriptor.extent.inside.3865 = icmp ule i32 %local.check.extent.3857, %stack.sub.3864
  %descriptor.payload.inside.3866 = icmp ule i32 %local.check.payload.3858, %local.check.extent.3857
  %descriptor.owner.offset.valid.3867 = and i1 %descriptor.owner.inside.3862, %descriptor.offset.inside.3863
  %descriptor.range.inside.3869 = and i1 %descriptor.owner.offset.valid.3867, %descriptor.extent.inside.3865
  %descriptor.range.valid.3868 = and i1 %descriptor.range.inside.3869, %descriptor.payload.inside.3866
  br i1 %descriptor.range.valid.3868, label %descriptor.valid.3870, label %descriptor.invalid.3871
descriptor.invalid.3871:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3870:
  %descriptor.initialized.status.3872 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3856, i32 %local.check.extent.3857)
  %helper.ok.3873 = icmp eq i32 %descriptor.initialized.status.3872, 0
  br i1 %helper.ok.3873, label %helper.continue.3874, label %frame.failure.0
helper.continue.3874:
  br label %local.descriptor.checked.3855
local.descriptor.inactive.3854:
  br label %local.descriptor.checked.3855
local.descriptor.checked.3855:
  %local.is.active.3875 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.3875, label %local.descriptor.active.3876, label %local.descriptor.inactive.3877
local.descriptor.active.3876:
  %local.check.offset.3879 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.3880 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.3881 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.3882 = load i32, ptr %local.owner.end.30, align 4
  %context.field.3883 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3884 = load i32, ptr %context.field.3883, align 4
  %stack.sub.3887 = sub i32 %local.check.owner.end.3882, %local.check.offset.3879
  %descriptor.owner.inside.3885 = icmp ule i32 %local.check.owner.end.3882, %context.value.3884
  %descriptor.offset.inside.3886 = icmp ule i32 %local.check.offset.3879, %local.check.owner.end.3882
  %descriptor.extent.inside.3888 = icmp ule i32 %local.check.extent.3880, %stack.sub.3887
  %descriptor.payload.inside.3889 = icmp ule i32 %local.check.payload.3881, %local.check.extent.3880
  %descriptor.owner.offset.valid.3890 = and i1 %descriptor.owner.inside.3885, %descriptor.offset.inside.3886
  %descriptor.range.inside.3892 = and i1 %descriptor.owner.offset.valid.3890, %descriptor.extent.inside.3888
  %descriptor.range.valid.3891 = and i1 %descriptor.range.inside.3892, %descriptor.payload.inside.3889
  br i1 %descriptor.range.valid.3891, label %descriptor.valid.3893, label %descriptor.invalid.3894
descriptor.invalid.3894:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3893:
  %descriptor.initialized.status.3895 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3879, i32 %local.check.extent.3880)
  %helper.ok.3896 = icmp eq i32 %descriptor.initialized.status.3895, 0
  br i1 %helper.ok.3896, label %helper.continue.3897, label %frame.failure.0
helper.continue.3897:
  br label %local.descriptor.checked.3878
local.descriptor.inactive.3877:
  br label %local.descriptor.checked.3878
local.descriptor.checked.3878:
  %local.is.active.3898 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.3898, label %local.descriptor.active.3899, label %local.descriptor.inactive.3900
local.descriptor.active.3899:
  %local.check.offset.3902 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.3903 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.3904 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.3905 = load i32, ptr %local.owner.end.36, align 4
  %context.field.3906 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3907 = load i32, ptr %context.field.3906, align 4
  %stack.sub.3910 = sub i32 %local.check.owner.end.3905, %local.check.offset.3902
  %descriptor.owner.inside.3908 = icmp ule i32 %local.check.owner.end.3905, %context.value.3907
  %descriptor.offset.inside.3909 = icmp ule i32 %local.check.offset.3902, %local.check.owner.end.3905
  %descriptor.extent.inside.3911 = icmp ule i32 %local.check.extent.3903, %stack.sub.3910
  %descriptor.payload.inside.3912 = icmp ule i32 %local.check.payload.3904, %local.check.extent.3903
  %descriptor.owner.offset.valid.3913 = and i1 %descriptor.owner.inside.3908, %descriptor.offset.inside.3909
  %descriptor.range.inside.3915 = and i1 %descriptor.owner.offset.valid.3913, %descriptor.extent.inside.3911
  %descriptor.range.valid.3914 = and i1 %descriptor.range.inside.3915, %descriptor.payload.inside.3912
  br i1 %descriptor.range.valid.3914, label %descriptor.valid.3916, label %descriptor.invalid.3917
descriptor.invalid.3917:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3916:
  %descriptor.initialized.status.3918 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3902, i32 %local.check.extent.3903)
  %helper.ok.3919 = icmp eq i32 %descriptor.initialized.status.3918, 0
  br i1 %helper.ok.3919, label %helper.continue.3920, label %frame.failure.0
helper.continue.3920:
  br label %local.descriptor.checked.3901
local.descriptor.inactive.3900:
  br label %local.descriptor.checked.3901
local.descriptor.checked.3901:
  %local.is.active.3921 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.3921, label %local.descriptor.active.3922, label %local.descriptor.inactive.3923
local.descriptor.active.3922:
  %local.check.offset.3925 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.3926 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.3927 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.3928 = load i32, ptr %local.owner.end.42, align 4
  %context.field.3929 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3930 = load i32, ptr %context.field.3929, align 4
  %stack.sub.3933 = sub i32 %local.check.owner.end.3928, %local.check.offset.3925
  %descriptor.owner.inside.3931 = icmp ule i32 %local.check.owner.end.3928, %context.value.3930
  %descriptor.offset.inside.3932 = icmp ule i32 %local.check.offset.3925, %local.check.owner.end.3928
  %descriptor.extent.inside.3934 = icmp ule i32 %local.check.extent.3926, %stack.sub.3933
  %descriptor.payload.inside.3935 = icmp ule i32 %local.check.payload.3927, %local.check.extent.3926
  %descriptor.owner.offset.valid.3936 = and i1 %descriptor.owner.inside.3931, %descriptor.offset.inside.3932
  %descriptor.range.inside.3938 = and i1 %descriptor.owner.offset.valid.3936, %descriptor.extent.inside.3934
  %descriptor.range.valid.3937 = and i1 %descriptor.range.inside.3938, %descriptor.payload.inside.3935
  br i1 %descriptor.range.valid.3937, label %descriptor.valid.3939, label %descriptor.invalid.3940
descriptor.invalid.3940:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3939:
  %descriptor.initialized.status.3941 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3925, i32 %local.check.extent.3926)
  %helper.ok.3942 = icmp eq i32 %descriptor.initialized.status.3941, 0
  br i1 %helper.ok.3942, label %helper.continue.3943, label %frame.failure.0
helper.continue.3943:
  br label %local.descriptor.checked.3924
local.descriptor.inactive.3923:
  br label %local.descriptor.checked.3924
local.descriptor.checked.3924:
  %step.status.3944 = call i32 @al_owning_charge_step(ptr %ctx, i32 65)
  %helper.ok.3945 = icmp eq i32 %step.status.3944, 0
  br i1 %helper.ok.3945, label %helper.continue.3946, label %frame.failure.0
helper.continue.3946:
  store i1 true, ptr %local.active.26, align 1
  store i32 %context.value.3746, ptr %local.offset.27, align 4
  store i32 %string.concat.extent.3754, ptr %local.extent.28, align 4
  store i32 %string.concat.payload.3753, ptr %local.payload.29, align 4
  store i32 %stack.offset.3755, ptr %local.owner.end.30, align 4
  store i32 6, ptr %local.type.31, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %context.value.3746, i32 20, i32 %string.concat.payload.3753, i32 %stack.offset.3755, i32 %string.concat.extent.3754)
  %context.field.3947 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3948 = load i32, ptr %context.field.3947, align 4
  %runtime.ok.3949 = icmp eq i32 %context.value.3948, 0
  br i1 %runtime.ok.3949, label %runtime.continue.3950, label %frame.failure.0
runtime.continue.3950:
  %local.is.active.3951 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.3951, label %local.descriptor.active.3952, label %local.descriptor.inactive.3953
local.descriptor.active.3952:
  %local.check.offset.3955 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.3956 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.3957 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.3958 = load i32, ptr %local.owner.end.6, align 4
  %context.field.3959 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3960 = load i32, ptr %context.field.3959, align 4
  %stack.sub.3963 = sub i32 %local.check.owner.end.3958, %local.check.offset.3955
  %descriptor.owner.inside.3961 = icmp ule i32 %local.check.owner.end.3958, %context.value.3960
  %descriptor.offset.inside.3962 = icmp ule i32 %local.check.offset.3955, %local.check.owner.end.3958
  %descriptor.extent.inside.3964 = icmp ule i32 %local.check.extent.3956, %stack.sub.3963
  %descriptor.payload.inside.3965 = icmp ule i32 %local.check.payload.3957, %local.check.extent.3956
  %descriptor.owner.offset.valid.3966 = and i1 %descriptor.owner.inside.3961, %descriptor.offset.inside.3962
  %descriptor.range.inside.3968 = and i1 %descriptor.owner.offset.valid.3966, %descriptor.extent.inside.3964
  %descriptor.range.valid.3967 = and i1 %descriptor.range.inside.3968, %descriptor.payload.inside.3965
  br i1 %descriptor.range.valid.3967, label %descriptor.valid.3969, label %descriptor.invalid.3970
descriptor.invalid.3970:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3969:
  %descriptor.initialized.status.3971 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3955, i32 %local.check.extent.3956)
  %helper.ok.3972 = icmp eq i32 %descriptor.initialized.status.3971, 0
  br i1 %helper.ok.3972, label %helper.continue.3973, label %frame.failure.0
helper.continue.3973:
  br label %local.descriptor.checked.3954
local.descriptor.inactive.3953:
  br label %local.descriptor.checked.3954
local.descriptor.checked.3954:
  %local.is.active.3974 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.3974, label %local.descriptor.active.3975, label %local.descriptor.inactive.3976
local.descriptor.active.3975:
  %local.check.offset.3978 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.3979 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.3980 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.3981 = load i32, ptr %local.owner.end.12, align 4
  %context.field.3982 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3983 = load i32, ptr %context.field.3982, align 4
  %stack.sub.3986 = sub i32 %local.check.owner.end.3981, %local.check.offset.3978
  %descriptor.owner.inside.3984 = icmp ule i32 %local.check.owner.end.3981, %context.value.3983
  %descriptor.offset.inside.3985 = icmp ule i32 %local.check.offset.3978, %local.check.owner.end.3981
  %descriptor.extent.inside.3987 = icmp ule i32 %local.check.extent.3979, %stack.sub.3986
  %descriptor.payload.inside.3988 = icmp ule i32 %local.check.payload.3980, %local.check.extent.3979
  %descriptor.owner.offset.valid.3989 = and i1 %descriptor.owner.inside.3984, %descriptor.offset.inside.3985
  %descriptor.range.inside.3991 = and i1 %descriptor.owner.offset.valid.3989, %descriptor.extent.inside.3987
  %descriptor.range.valid.3990 = and i1 %descriptor.range.inside.3991, %descriptor.payload.inside.3988
  br i1 %descriptor.range.valid.3990, label %descriptor.valid.3992, label %descriptor.invalid.3993
descriptor.invalid.3993:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3992:
  %descriptor.initialized.status.3994 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3978, i32 %local.check.extent.3979)
  %helper.ok.3995 = icmp eq i32 %descriptor.initialized.status.3994, 0
  br i1 %helper.ok.3995, label %helper.continue.3996, label %frame.failure.0
helper.continue.3996:
  br label %local.descriptor.checked.3977
local.descriptor.inactive.3976:
  br label %local.descriptor.checked.3977
local.descriptor.checked.3977:
  %local.is.active.3997 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.3997, label %local.descriptor.active.3998, label %local.descriptor.inactive.3999
local.descriptor.active.3998:
  %local.check.offset.4001 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.4002 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.4003 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.4004 = load i32, ptr %local.owner.end.18, align 4
  %context.field.4005 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4006 = load i32, ptr %context.field.4005, align 4
  %stack.sub.4009 = sub i32 %local.check.owner.end.4004, %local.check.offset.4001
  %descriptor.owner.inside.4007 = icmp ule i32 %local.check.owner.end.4004, %context.value.4006
  %descriptor.offset.inside.4008 = icmp ule i32 %local.check.offset.4001, %local.check.owner.end.4004
  %descriptor.extent.inside.4010 = icmp ule i32 %local.check.extent.4002, %stack.sub.4009
  %descriptor.payload.inside.4011 = icmp ule i32 %local.check.payload.4003, %local.check.extent.4002
  %descriptor.owner.offset.valid.4012 = and i1 %descriptor.owner.inside.4007, %descriptor.offset.inside.4008
  %descriptor.range.inside.4014 = and i1 %descriptor.owner.offset.valid.4012, %descriptor.extent.inside.4010
  %descriptor.range.valid.4013 = and i1 %descriptor.range.inside.4014, %descriptor.payload.inside.4011
  br i1 %descriptor.range.valid.4013, label %descriptor.valid.4015, label %descriptor.invalid.4016
descriptor.invalid.4016:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4015:
  %descriptor.initialized.status.4017 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4001, i32 %local.check.extent.4002)
  %helper.ok.4018 = icmp eq i32 %descriptor.initialized.status.4017, 0
  br i1 %helper.ok.4018, label %helper.continue.4019, label %frame.failure.0
helper.continue.4019:
  br label %local.descriptor.checked.4000
local.descriptor.inactive.3999:
  br label %local.descriptor.checked.4000
local.descriptor.checked.4000:
  %local.is.active.4020 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.4020, label %local.descriptor.active.4021, label %local.descriptor.inactive.4022
local.descriptor.active.4021:
  %local.check.offset.4024 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.4025 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.4026 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.4027 = load i32, ptr %local.owner.end.24, align 4
  %context.field.4028 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4029 = load i32, ptr %context.field.4028, align 4
  %stack.sub.4032 = sub i32 %local.check.owner.end.4027, %local.check.offset.4024
  %descriptor.owner.inside.4030 = icmp ule i32 %local.check.owner.end.4027, %context.value.4029
  %descriptor.offset.inside.4031 = icmp ule i32 %local.check.offset.4024, %local.check.owner.end.4027
  %descriptor.extent.inside.4033 = icmp ule i32 %local.check.extent.4025, %stack.sub.4032
  %descriptor.payload.inside.4034 = icmp ule i32 %local.check.payload.4026, %local.check.extent.4025
  %descriptor.owner.offset.valid.4035 = and i1 %descriptor.owner.inside.4030, %descriptor.offset.inside.4031
  %descriptor.range.inside.4037 = and i1 %descriptor.owner.offset.valid.4035, %descriptor.extent.inside.4033
  %descriptor.range.valid.4036 = and i1 %descriptor.range.inside.4037, %descriptor.payload.inside.4034
  br i1 %descriptor.range.valid.4036, label %descriptor.valid.4038, label %descriptor.invalid.4039
descriptor.invalid.4039:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4038:
  %descriptor.initialized.status.4040 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4024, i32 %local.check.extent.4025)
  %helper.ok.4041 = icmp eq i32 %descriptor.initialized.status.4040, 0
  br i1 %helper.ok.4041, label %helper.continue.4042, label %frame.failure.0
helper.continue.4042:
  br label %local.descriptor.checked.4023
local.descriptor.inactive.4022:
  br label %local.descriptor.checked.4023
local.descriptor.checked.4023:
  %local.is.active.4043 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.4043, label %local.descriptor.active.4044, label %local.descriptor.inactive.4045
local.descriptor.active.4044:
  %local.check.offset.4047 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.4048 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.4049 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.4050 = load i32, ptr %local.owner.end.30, align 4
  %context.field.4051 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4052 = load i32, ptr %context.field.4051, align 4
  %stack.sub.4055 = sub i32 %local.check.owner.end.4050, %local.check.offset.4047
  %descriptor.owner.inside.4053 = icmp ule i32 %local.check.owner.end.4050, %context.value.4052
  %descriptor.offset.inside.4054 = icmp ule i32 %local.check.offset.4047, %local.check.owner.end.4050
  %descriptor.extent.inside.4056 = icmp ule i32 %local.check.extent.4048, %stack.sub.4055
  %descriptor.payload.inside.4057 = icmp ule i32 %local.check.payload.4049, %local.check.extent.4048
  %descriptor.owner.offset.valid.4058 = and i1 %descriptor.owner.inside.4053, %descriptor.offset.inside.4054
  %descriptor.range.inside.4060 = and i1 %descriptor.owner.offset.valid.4058, %descriptor.extent.inside.4056
  %descriptor.range.valid.4059 = and i1 %descriptor.range.inside.4060, %descriptor.payload.inside.4057
  br i1 %descriptor.range.valid.4059, label %descriptor.valid.4061, label %descriptor.invalid.4062
descriptor.invalid.4062:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4061:
  %descriptor.initialized.status.4063 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4047, i32 %local.check.extent.4048)
  %helper.ok.4064 = icmp eq i32 %descriptor.initialized.status.4063, 0
  br i1 %helper.ok.4064, label %helper.continue.4065, label %frame.failure.0
helper.continue.4065:
  br label %local.descriptor.checked.4046
local.descriptor.inactive.4045:
  br label %local.descriptor.checked.4046
local.descriptor.checked.4046:
  %local.is.active.4066 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.4066, label %local.descriptor.active.4067, label %local.descriptor.inactive.4068
local.descriptor.active.4067:
  %local.check.offset.4070 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.4071 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.4072 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.4073 = load i32, ptr %local.owner.end.36, align 4
  %context.field.4074 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4075 = load i32, ptr %context.field.4074, align 4
  %stack.sub.4078 = sub i32 %local.check.owner.end.4073, %local.check.offset.4070
  %descriptor.owner.inside.4076 = icmp ule i32 %local.check.owner.end.4073, %context.value.4075
  %descriptor.offset.inside.4077 = icmp ule i32 %local.check.offset.4070, %local.check.owner.end.4073
  %descriptor.extent.inside.4079 = icmp ule i32 %local.check.extent.4071, %stack.sub.4078
  %descriptor.payload.inside.4080 = icmp ule i32 %local.check.payload.4072, %local.check.extent.4071
  %descriptor.owner.offset.valid.4081 = and i1 %descriptor.owner.inside.4076, %descriptor.offset.inside.4077
  %descriptor.range.inside.4083 = and i1 %descriptor.owner.offset.valid.4081, %descriptor.extent.inside.4079
  %descriptor.range.valid.4082 = and i1 %descriptor.range.inside.4083, %descriptor.payload.inside.4080
  br i1 %descriptor.range.valid.4082, label %descriptor.valid.4084, label %descriptor.invalid.4085
descriptor.invalid.4085:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4084:
  %descriptor.initialized.status.4086 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4070, i32 %local.check.extent.4071)
  %helper.ok.4087 = icmp eq i32 %descriptor.initialized.status.4086, 0
  br i1 %helper.ok.4087, label %helper.continue.4088, label %frame.failure.0
helper.continue.4088:
  br label %local.descriptor.checked.4069
local.descriptor.inactive.4068:
  br label %local.descriptor.checked.4069
local.descriptor.checked.4069:
  %local.is.active.4089 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.4089, label %local.descriptor.active.4090, label %local.descriptor.inactive.4091
local.descriptor.active.4090:
  %local.check.offset.4093 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.4094 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.4095 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.4096 = load i32, ptr %local.owner.end.42, align 4
  %context.field.4097 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4098 = load i32, ptr %context.field.4097, align 4
  %stack.sub.4101 = sub i32 %local.check.owner.end.4096, %local.check.offset.4093
  %descriptor.owner.inside.4099 = icmp ule i32 %local.check.owner.end.4096, %context.value.4098
  %descriptor.offset.inside.4100 = icmp ule i32 %local.check.offset.4093, %local.check.owner.end.4096
  %descriptor.extent.inside.4102 = icmp ule i32 %local.check.extent.4094, %stack.sub.4101
  %descriptor.payload.inside.4103 = icmp ule i32 %local.check.payload.4095, %local.check.extent.4094
  %descriptor.owner.offset.valid.4104 = and i1 %descriptor.owner.inside.4099, %descriptor.offset.inside.4100
  %descriptor.range.inside.4106 = and i1 %descriptor.owner.offset.valid.4104, %descriptor.extent.inside.4102
  %descriptor.range.valid.4105 = and i1 %descriptor.range.inside.4106, %descriptor.payload.inside.4103
  br i1 %descriptor.range.valid.4105, label %descriptor.valid.4107, label %descriptor.invalid.4108
descriptor.invalid.4108:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4107:
  %descriptor.initialized.status.4109 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4093, i32 %local.check.extent.4094)
  %helper.ok.4110 = icmp eq i32 %descriptor.initialized.status.4109, 0
  br i1 %helper.ok.4110, label %helper.continue.4111, label %frame.failure.0
helper.continue.4111:
  br label %local.descriptor.checked.4092
local.descriptor.inactive.4091:
  br label %local.descriptor.checked.4092
local.descriptor.checked.4092:
  %step.status.4112 = call i32 @al_owning_charge_step(ptr %ctx, i32 66)
  %helper.ok.4113 = icmp eq i32 %step.status.4112, 0
  br i1 %helper.ok.4113, label %helper.continue.4114, label %frame.failure.0
helper.continue.4114:
  %local.resolved.offset.4115 = load i32, ptr %local.offset.27, align 4
  %local.resolved.extent.4116 = load i32, ptr %local.extent.28, align 4
  %local.resolved.payload.4117 = load i32, ptr %local.payload.29, align 4
  %local.resolved.owner.end.4118 = load i32, ptr %local.owner.end.30, align 4
  %context.field.4119 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4120 = load i32, ptr %context.field.4119, align 4
  %stack.sub.4123 = sub i32 %local.resolved.owner.end.4118, %local.resolved.offset.4115
  %descriptor.owner.inside.4121 = icmp ule i32 %local.resolved.owner.end.4118, %context.value.4120
  %descriptor.offset.inside.4122 = icmp ule i32 %local.resolved.offset.4115, %local.resolved.owner.end.4118
  %descriptor.extent.inside.4124 = icmp ule i32 %local.resolved.extent.4116, %stack.sub.4123
  %descriptor.payload.inside.4125 = icmp ule i32 %local.resolved.payload.4117, %local.resolved.extent.4116
  %descriptor.owner.offset.valid.4126 = and i1 %descriptor.owner.inside.4121, %descriptor.offset.inside.4122
  %descriptor.range.inside.4128 = and i1 %descriptor.owner.offset.valid.4126, %descriptor.extent.inside.4124
  %descriptor.range.valid.4127 = and i1 %descriptor.range.inside.4128, %descriptor.payload.inside.4125
  %descriptor.type.valid.4129 = icmp eq i32 6, 6
  %descriptor.valid.4130 = and i1 %descriptor.range.valid.4127, %descriptor.type.valid.4129
  br i1 %descriptor.valid.4130, label %descriptor.valid.4131, label %descriptor.invalid.4132
descriptor.invalid.4132:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4131:
  %descriptor.initialized.status.4133 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.4115, i32 %local.resolved.extent.4116)
  %helper.ok.4134 = icmp eq i32 %descriptor.initialized.status.4133, 0
  br i1 %helper.ok.4134, label %helper.continue.4135, label %frame.failure.0
helper.continue.4135:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %local.resolved.offset.4115, i32 20, i32 %local.resolved.payload.4117, i32 %local.resolved.owner.end.4118, i32 %local.resolved.extent.4116)
  %context.field.4136 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4137 = load i32, ptr %context.field.4136, align 4
  %runtime.ok.4138 = icmp eq i32 %context.value.4137, 0
  br i1 %runtime.ok.4138, label %runtime.continue.4139, label %frame.failure.0
runtime.continue.4139:
  %context.field.4140 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4141 = load i32, ptr %context.field.4140, align 4
  %stack.sub.4144 = sub i32 %local.resolved.owner.end.4118, %local.resolved.offset.4115
  %descriptor.owner.inside.4142 = icmp ule i32 %local.resolved.owner.end.4118, %context.value.4141
  %descriptor.offset.inside.4143 = icmp ule i32 %local.resolved.offset.4115, %local.resolved.owner.end.4118
  %descriptor.extent.inside.4145 = icmp ule i32 %local.resolved.extent.4116, %stack.sub.4144
  %descriptor.payload.inside.4146 = icmp ule i32 %local.resolved.payload.4117, %local.resolved.extent.4116
  %descriptor.owner.offset.valid.4147 = and i1 %descriptor.owner.inside.4142, %descriptor.offset.inside.4143
  %descriptor.range.inside.4149 = and i1 %descriptor.owner.offset.valid.4147, %descriptor.extent.inside.4145
  %descriptor.range.valid.4148 = and i1 %descriptor.range.inside.4149, %descriptor.payload.inside.4146
  %descriptor.type.valid.4150 = icmp eq i32 6, 6
  %descriptor.valid.4151 = and i1 %descriptor.range.valid.4148, %descriptor.type.valid.4150
  br i1 %descriptor.valid.4151, label %descriptor.valid.4152, label %descriptor.invalid.4153
descriptor.invalid.4153:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4152:
  %descriptor.initialized.status.4154 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.4115, i32 %local.resolved.extent.4116)
  %helper.ok.4155 = icmp eq i32 %descriptor.initialized.status.4154, 0
  br i1 %helper.ok.4155, label %helper.continue.4156, label %frame.failure.0
helper.continue.4156:
  %local.is.active.4157 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.4157, label %local.descriptor.active.4158, label %local.descriptor.inactive.4159
local.descriptor.active.4158:
  %local.check.offset.4161 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.4162 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.4163 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.4164 = load i32, ptr %local.owner.end.6, align 4
  %context.field.4165 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4166 = load i32, ptr %context.field.4165, align 4
  %stack.sub.4169 = sub i32 %local.check.owner.end.4164, %local.check.offset.4161
  %descriptor.owner.inside.4167 = icmp ule i32 %local.check.owner.end.4164, %context.value.4166
  %descriptor.offset.inside.4168 = icmp ule i32 %local.check.offset.4161, %local.check.owner.end.4164
  %descriptor.extent.inside.4170 = icmp ule i32 %local.check.extent.4162, %stack.sub.4169
  %descriptor.payload.inside.4171 = icmp ule i32 %local.check.payload.4163, %local.check.extent.4162
  %descriptor.owner.offset.valid.4172 = and i1 %descriptor.owner.inside.4167, %descriptor.offset.inside.4168
  %descriptor.range.inside.4174 = and i1 %descriptor.owner.offset.valid.4172, %descriptor.extent.inside.4170
  %descriptor.range.valid.4173 = and i1 %descriptor.range.inside.4174, %descriptor.payload.inside.4171
  br i1 %descriptor.range.valid.4173, label %descriptor.valid.4175, label %descriptor.invalid.4176
descriptor.invalid.4176:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4175:
  %descriptor.initialized.status.4177 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4161, i32 %local.check.extent.4162)
  %helper.ok.4178 = icmp eq i32 %descriptor.initialized.status.4177, 0
  br i1 %helper.ok.4178, label %helper.continue.4179, label %frame.failure.0
helper.continue.4179:
  br label %local.descriptor.checked.4160
local.descriptor.inactive.4159:
  br label %local.descriptor.checked.4160
local.descriptor.checked.4160:
  %local.is.active.4180 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.4180, label %local.descriptor.active.4181, label %local.descriptor.inactive.4182
local.descriptor.active.4181:
  %local.check.offset.4184 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.4185 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.4186 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.4187 = load i32, ptr %local.owner.end.12, align 4
  %context.field.4188 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4189 = load i32, ptr %context.field.4188, align 4
  %stack.sub.4192 = sub i32 %local.check.owner.end.4187, %local.check.offset.4184
  %descriptor.owner.inside.4190 = icmp ule i32 %local.check.owner.end.4187, %context.value.4189
  %descriptor.offset.inside.4191 = icmp ule i32 %local.check.offset.4184, %local.check.owner.end.4187
  %descriptor.extent.inside.4193 = icmp ule i32 %local.check.extent.4185, %stack.sub.4192
  %descriptor.payload.inside.4194 = icmp ule i32 %local.check.payload.4186, %local.check.extent.4185
  %descriptor.owner.offset.valid.4195 = and i1 %descriptor.owner.inside.4190, %descriptor.offset.inside.4191
  %descriptor.range.inside.4197 = and i1 %descriptor.owner.offset.valid.4195, %descriptor.extent.inside.4193
  %descriptor.range.valid.4196 = and i1 %descriptor.range.inside.4197, %descriptor.payload.inside.4194
  br i1 %descriptor.range.valid.4196, label %descriptor.valid.4198, label %descriptor.invalid.4199
descriptor.invalid.4199:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4198:
  %descriptor.initialized.status.4200 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4184, i32 %local.check.extent.4185)
  %helper.ok.4201 = icmp eq i32 %descriptor.initialized.status.4200, 0
  br i1 %helper.ok.4201, label %helper.continue.4202, label %frame.failure.0
helper.continue.4202:
  br label %local.descriptor.checked.4183
local.descriptor.inactive.4182:
  br label %local.descriptor.checked.4183
local.descriptor.checked.4183:
  %local.is.active.4203 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.4203, label %local.descriptor.active.4204, label %local.descriptor.inactive.4205
local.descriptor.active.4204:
  %local.check.offset.4207 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.4208 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.4209 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.4210 = load i32, ptr %local.owner.end.18, align 4
  %context.field.4211 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4212 = load i32, ptr %context.field.4211, align 4
  %stack.sub.4215 = sub i32 %local.check.owner.end.4210, %local.check.offset.4207
  %descriptor.owner.inside.4213 = icmp ule i32 %local.check.owner.end.4210, %context.value.4212
  %descriptor.offset.inside.4214 = icmp ule i32 %local.check.offset.4207, %local.check.owner.end.4210
  %descriptor.extent.inside.4216 = icmp ule i32 %local.check.extent.4208, %stack.sub.4215
  %descriptor.payload.inside.4217 = icmp ule i32 %local.check.payload.4209, %local.check.extent.4208
  %descriptor.owner.offset.valid.4218 = and i1 %descriptor.owner.inside.4213, %descriptor.offset.inside.4214
  %descriptor.range.inside.4220 = and i1 %descriptor.owner.offset.valid.4218, %descriptor.extent.inside.4216
  %descriptor.range.valid.4219 = and i1 %descriptor.range.inside.4220, %descriptor.payload.inside.4217
  br i1 %descriptor.range.valid.4219, label %descriptor.valid.4221, label %descriptor.invalid.4222
descriptor.invalid.4222:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4221:
  %descriptor.initialized.status.4223 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4207, i32 %local.check.extent.4208)
  %helper.ok.4224 = icmp eq i32 %descriptor.initialized.status.4223, 0
  br i1 %helper.ok.4224, label %helper.continue.4225, label %frame.failure.0
helper.continue.4225:
  br label %local.descriptor.checked.4206
local.descriptor.inactive.4205:
  br label %local.descriptor.checked.4206
local.descriptor.checked.4206:
  %local.is.active.4226 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.4226, label %local.descriptor.active.4227, label %local.descriptor.inactive.4228
local.descriptor.active.4227:
  %local.check.offset.4230 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.4231 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.4232 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.4233 = load i32, ptr %local.owner.end.24, align 4
  %context.field.4234 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4235 = load i32, ptr %context.field.4234, align 4
  %stack.sub.4238 = sub i32 %local.check.owner.end.4233, %local.check.offset.4230
  %descriptor.owner.inside.4236 = icmp ule i32 %local.check.owner.end.4233, %context.value.4235
  %descriptor.offset.inside.4237 = icmp ule i32 %local.check.offset.4230, %local.check.owner.end.4233
  %descriptor.extent.inside.4239 = icmp ule i32 %local.check.extent.4231, %stack.sub.4238
  %descriptor.payload.inside.4240 = icmp ule i32 %local.check.payload.4232, %local.check.extent.4231
  %descriptor.owner.offset.valid.4241 = and i1 %descriptor.owner.inside.4236, %descriptor.offset.inside.4237
  %descriptor.range.inside.4243 = and i1 %descriptor.owner.offset.valid.4241, %descriptor.extent.inside.4239
  %descriptor.range.valid.4242 = and i1 %descriptor.range.inside.4243, %descriptor.payload.inside.4240
  br i1 %descriptor.range.valid.4242, label %descriptor.valid.4244, label %descriptor.invalid.4245
descriptor.invalid.4245:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4244:
  %descriptor.initialized.status.4246 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4230, i32 %local.check.extent.4231)
  %helper.ok.4247 = icmp eq i32 %descriptor.initialized.status.4246, 0
  br i1 %helper.ok.4247, label %helper.continue.4248, label %frame.failure.0
helper.continue.4248:
  br label %local.descriptor.checked.4229
local.descriptor.inactive.4228:
  br label %local.descriptor.checked.4229
local.descriptor.checked.4229:
  %local.is.active.4249 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.4249, label %local.descriptor.active.4250, label %local.descriptor.inactive.4251
local.descriptor.active.4250:
  %local.check.offset.4253 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.4254 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.4255 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.4256 = load i32, ptr %local.owner.end.30, align 4
  %context.field.4257 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4258 = load i32, ptr %context.field.4257, align 4
  %stack.sub.4261 = sub i32 %local.check.owner.end.4256, %local.check.offset.4253
  %descriptor.owner.inside.4259 = icmp ule i32 %local.check.owner.end.4256, %context.value.4258
  %descriptor.offset.inside.4260 = icmp ule i32 %local.check.offset.4253, %local.check.owner.end.4256
  %descriptor.extent.inside.4262 = icmp ule i32 %local.check.extent.4254, %stack.sub.4261
  %descriptor.payload.inside.4263 = icmp ule i32 %local.check.payload.4255, %local.check.extent.4254
  %descriptor.owner.offset.valid.4264 = and i1 %descriptor.owner.inside.4259, %descriptor.offset.inside.4260
  %descriptor.range.inside.4266 = and i1 %descriptor.owner.offset.valid.4264, %descriptor.extent.inside.4262
  %descriptor.range.valid.4265 = and i1 %descriptor.range.inside.4266, %descriptor.payload.inside.4263
  br i1 %descriptor.range.valid.4265, label %descriptor.valid.4267, label %descriptor.invalid.4268
descriptor.invalid.4268:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4267:
  %descriptor.initialized.status.4269 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4253, i32 %local.check.extent.4254)
  %helper.ok.4270 = icmp eq i32 %descriptor.initialized.status.4269, 0
  br i1 %helper.ok.4270, label %helper.continue.4271, label %frame.failure.0
helper.continue.4271:
  br label %local.descriptor.checked.4252
local.descriptor.inactive.4251:
  br label %local.descriptor.checked.4252
local.descriptor.checked.4252:
  %local.is.active.4272 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.4272, label %local.descriptor.active.4273, label %local.descriptor.inactive.4274
local.descriptor.active.4273:
  %local.check.offset.4276 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.4277 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.4278 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.4279 = load i32, ptr %local.owner.end.36, align 4
  %context.field.4280 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4281 = load i32, ptr %context.field.4280, align 4
  %stack.sub.4284 = sub i32 %local.check.owner.end.4279, %local.check.offset.4276
  %descriptor.owner.inside.4282 = icmp ule i32 %local.check.owner.end.4279, %context.value.4281
  %descriptor.offset.inside.4283 = icmp ule i32 %local.check.offset.4276, %local.check.owner.end.4279
  %descriptor.extent.inside.4285 = icmp ule i32 %local.check.extent.4277, %stack.sub.4284
  %descriptor.payload.inside.4286 = icmp ule i32 %local.check.payload.4278, %local.check.extent.4277
  %descriptor.owner.offset.valid.4287 = and i1 %descriptor.owner.inside.4282, %descriptor.offset.inside.4283
  %descriptor.range.inside.4289 = and i1 %descriptor.owner.offset.valid.4287, %descriptor.extent.inside.4285
  %descriptor.range.valid.4288 = and i1 %descriptor.range.inside.4289, %descriptor.payload.inside.4286
  br i1 %descriptor.range.valid.4288, label %descriptor.valid.4290, label %descriptor.invalid.4291
descriptor.invalid.4291:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4290:
  %descriptor.initialized.status.4292 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4276, i32 %local.check.extent.4277)
  %helper.ok.4293 = icmp eq i32 %descriptor.initialized.status.4292, 0
  br i1 %helper.ok.4293, label %helper.continue.4294, label %frame.failure.0
helper.continue.4294:
  br label %local.descriptor.checked.4275
local.descriptor.inactive.4274:
  br label %local.descriptor.checked.4275
local.descriptor.checked.4275:
  %local.is.active.4295 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.4295, label %local.descriptor.active.4296, label %local.descriptor.inactive.4297
local.descriptor.active.4296:
  %local.check.offset.4299 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.4300 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.4301 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.4302 = load i32, ptr %local.owner.end.42, align 4
  %context.field.4303 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4304 = load i32, ptr %context.field.4303, align 4
  %stack.sub.4307 = sub i32 %local.check.owner.end.4302, %local.check.offset.4299
  %descriptor.owner.inside.4305 = icmp ule i32 %local.check.owner.end.4302, %context.value.4304
  %descriptor.offset.inside.4306 = icmp ule i32 %local.check.offset.4299, %local.check.owner.end.4302
  %descriptor.extent.inside.4308 = icmp ule i32 %local.check.extent.4300, %stack.sub.4307
  %descriptor.payload.inside.4309 = icmp ule i32 %local.check.payload.4301, %local.check.extent.4300
  %descriptor.owner.offset.valid.4310 = and i1 %descriptor.owner.inside.4305, %descriptor.offset.inside.4306
  %descriptor.range.inside.4312 = and i1 %descriptor.owner.offset.valid.4310, %descriptor.extent.inside.4308
  %descriptor.range.valid.4311 = and i1 %descriptor.range.inside.4312, %descriptor.payload.inside.4309
  br i1 %descriptor.range.valid.4311, label %descriptor.valid.4313, label %descriptor.invalid.4314
descriptor.invalid.4314:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4313:
  %descriptor.initialized.status.4315 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4299, i32 %local.check.extent.4300)
  %helper.ok.4316 = icmp eq i32 %descriptor.initialized.status.4315, 0
  br i1 %helper.ok.4316, label %helper.continue.4317, label %frame.failure.0
helper.continue.4317:
  br label %local.descriptor.checked.4298
local.descriptor.inactive.4297:
  br label %local.descriptor.checked.4298
local.descriptor.checked.4298:
  %step.status.4318 = call i32 @al_owning_charge_step(ptr %ctx, i32 67)
  %helper.ok.4319 = icmp eq i32 %step.status.4318, 0
  br i1 %helper.ok.4319, label %helper.continue.4320, label %frame.failure.0
helper.continue.4320:
  %local.resolved.offset.4321 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.4322 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.4323 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.4324 = load i32, ptr %local.owner.end.6, align 4
  %context.field.4325 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4326 = load i32, ptr %context.field.4325, align 4
  %stack.sub.4329 = sub i32 %local.resolved.owner.end.4324, %local.resolved.offset.4321
  %descriptor.owner.inside.4327 = icmp ule i32 %local.resolved.owner.end.4324, %context.value.4326
  %descriptor.offset.inside.4328 = icmp ule i32 %local.resolved.offset.4321, %local.resolved.owner.end.4324
  %descriptor.extent.inside.4330 = icmp ule i32 %local.resolved.extent.4322, %stack.sub.4329
  %descriptor.payload.inside.4331 = icmp ule i32 %local.resolved.payload.4323, %local.resolved.extent.4322
  %descriptor.owner.offset.valid.4332 = and i1 %descriptor.owner.inside.4327, %descriptor.offset.inside.4328
  %descriptor.range.inside.4334 = and i1 %descriptor.owner.offset.valid.4332, %descriptor.extent.inside.4330
  %descriptor.range.valid.4333 = and i1 %descriptor.range.inside.4334, %descriptor.payload.inside.4331
  %descriptor.type.valid.4335 = icmp eq i32 6, 6
  %descriptor.valid.4336 = and i1 %descriptor.range.valid.4333, %descriptor.type.valid.4335
  br i1 %descriptor.valid.4336, label %descriptor.valid.4337, label %descriptor.invalid.4338
descriptor.invalid.4338:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4337:
  %descriptor.initialized.status.4339 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.4321, i32 %local.resolved.extent.4322)
  %helper.ok.4340 = icmp eq i32 %descriptor.initialized.status.4339, 0
  br i1 %helper.ok.4340, label %helper.continue.4341, label %frame.failure.0
helper.continue.4341:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %local.resolved.offset.4321, i32 20, i32 %local.resolved.payload.4323, i32 %local.resolved.owner.end.4324, i32 %local.resolved.extent.4322)
  %context.field.4342 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4343 = load i32, ptr %context.field.4342, align 4
  %runtime.ok.4344 = icmp eq i32 %context.value.4343, 0
  br i1 %runtime.ok.4344, label %runtime.continue.4345, label %frame.failure.0
runtime.continue.4345:
  %context.field.4346 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4347 = load i32, ptr %context.field.4346, align 4
  %stack.sub.4350 = sub i32 %local.resolved.owner.end.4118, %local.resolved.offset.4115
  %descriptor.owner.inside.4348 = icmp ule i32 %local.resolved.owner.end.4118, %context.value.4347
  %descriptor.offset.inside.4349 = icmp ule i32 %local.resolved.offset.4115, %local.resolved.owner.end.4118
  %descriptor.extent.inside.4351 = icmp ule i32 %local.resolved.extent.4116, %stack.sub.4350
  %descriptor.payload.inside.4352 = icmp ule i32 %local.resolved.payload.4117, %local.resolved.extent.4116
  %descriptor.owner.offset.valid.4353 = and i1 %descriptor.owner.inside.4348, %descriptor.offset.inside.4349
  %descriptor.range.inside.4355 = and i1 %descriptor.owner.offset.valid.4353, %descriptor.extent.inside.4351
  %descriptor.range.valid.4354 = and i1 %descriptor.range.inside.4355, %descriptor.payload.inside.4352
  %descriptor.type.valid.4356 = icmp eq i32 6, 6
  %descriptor.valid.4357 = and i1 %descriptor.range.valid.4354, %descriptor.type.valid.4356
  br i1 %descriptor.valid.4357, label %descriptor.valid.4358, label %descriptor.invalid.4359
descriptor.invalid.4359:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4358:
  %descriptor.initialized.status.4360 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.4115, i32 %local.resolved.extent.4116)
  %helper.ok.4361 = icmp eq i32 %descriptor.initialized.status.4360, 0
  br i1 %helper.ok.4361, label %helper.continue.4362, label %frame.failure.0
helper.continue.4362:
  %context.field.4363 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4364 = load i32, ptr %context.field.4363, align 4
  %stack.sub.4367 = sub i32 %local.resolved.owner.end.4324, %local.resolved.offset.4321
  %descriptor.owner.inside.4365 = icmp ule i32 %local.resolved.owner.end.4324, %context.value.4364
  %descriptor.offset.inside.4366 = icmp ule i32 %local.resolved.offset.4321, %local.resolved.owner.end.4324
  %descriptor.extent.inside.4368 = icmp ule i32 %local.resolved.extent.4322, %stack.sub.4367
  %descriptor.payload.inside.4369 = icmp ule i32 %local.resolved.payload.4323, %local.resolved.extent.4322
  %descriptor.owner.offset.valid.4370 = and i1 %descriptor.owner.inside.4365, %descriptor.offset.inside.4366
  %descriptor.range.inside.4372 = and i1 %descriptor.owner.offset.valid.4370, %descriptor.extent.inside.4368
  %descriptor.range.valid.4371 = and i1 %descriptor.range.inside.4372, %descriptor.payload.inside.4369
  %descriptor.type.valid.4373 = icmp eq i32 6, 6
  %descriptor.valid.4374 = and i1 %descriptor.range.valid.4371, %descriptor.type.valid.4373
  br i1 %descriptor.valid.4374, label %descriptor.valid.4375, label %descriptor.invalid.4376
descriptor.invalid.4376:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4375:
  %descriptor.initialized.status.4377 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.4321, i32 %local.resolved.extent.4322)
  %helper.ok.4378 = icmp eq i32 %descriptor.initialized.status.4377, 0
  br i1 %helper.ok.4378, label %helper.continue.4379, label %frame.failure.0
helper.continue.4379:
  %local.is.active.4380 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.4380, label %local.descriptor.active.4381, label %local.descriptor.inactive.4382
local.descriptor.active.4381:
  %local.check.offset.4384 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.4385 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.4386 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.4387 = load i32, ptr %local.owner.end.6, align 4
  %context.field.4388 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4389 = load i32, ptr %context.field.4388, align 4
  %stack.sub.4392 = sub i32 %local.check.owner.end.4387, %local.check.offset.4384
  %descriptor.owner.inside.4390 = icmp ule i32 %local.check.owner.end.4387, %context.value.4389
  %descriptor.offset.inside.4391 = icmp ule i32 %local.check.offset.4384, %local.check.owner.end.4387
  %descriptor.extent.inside.4393 = icmp ule i32 %local.check.extent.4385, %stack.sub.4392
  %descriptor.payload.inside.4394 = icmp ule i32 %local.check.payload.4386, %local.check.extent.4385
  %descriptor.owner.offset.valid.4395 = and i1 %descriptor.owner.inside.4390, %descriptor.offset.inside.4391
  %descriptor.range.inside.4397 = and i1 %descriptor.owner.offset.valid.4395, %descriptor.extent.inside.4393
  %descriptor.range.valid.4396 = and i1 %descriptor.range.inside.4397, %descriptor.payload.inside.4394
  br i1 %descriptor.range.valid.4396, label %descriptor.valid.4398, label %descriptor.invalid.4399
descriptor.invalid.4399:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4398:
  %descriptor.initialized.status.4400 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4384, i32 %local.check.extent.4385)
  %helper.ok.4401 = icmp eq i32 %descriptor.initialized.status.4400, 0
  br i1 %helper.ok.4401, label %helper.continue.4402, label %frame.failure.0
helper.continue.4402:
  br label %local.descriptor.checked.4383
local.descriptor.inactive.4382:
  br label %local.descriptor.checked.4383
local.descriptor.checked.4383:
  %local.is.active.4403 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.4403, label %local.descriptor.active.4404, label %local.descriptor.inactive.4405
local.descriptor.active.4404:
  %local.check.offset.4407 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.4408 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.4409 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.4410 = load i32, ptr %local.owner.end.12, align 4
  %context.field.4411 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4412 = load i32, ptr %context.field.4411, align 4
  %stack.sub.4415 = sub i32 %local.check.owner.end.4410, %local.check.offset.4407
  %descriptor.owner.inside.4413 = icmp ule i32 %local.check.owner.end.4410, %context.value.4412
  %descriptor.offset.inside.4414 = icmp ule i32 %local.check.offset.4407, %local.check.owner.end.4410
  %descriptor.extent.inside.4416 = icmp ule i32 %local.check.extent.4408, %stack.sub.4415
  %descriptor.payload.inside.4417 = icmp ule i32 %local.check.payload.4409, %local.check.extent.4408
  %descriptor.owner.offset.valid.4418 = and i1 %descriptor.owner.inside.4413, %descriptor.offset.inside.4414
  %descriptor.range.inside.4420 = and i1 %descriptor.owner.offset.valid.4418, %descriptor.extent.inside.4416
  %descriptor.range.valid.4419 = and i1 %descriptor.range.inside.4420, %descriptor.payload.inside.4417
  br i1 %descriptor.range.valid.4419, label %descriptor.valid.4421, label %descriptor.invalid.4422
descriptor.invalid.4422:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4421:
  %descriptor.initialized.status.4423 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4407, i32 %local.check.extent.4408)
  %helper.ok.4424 = icmp eq i32 %descriptor.initialized.status.4423, 0
  br i1 %helper.ok.4424, label %helper.continue.4425, label %frame.failure.0
helper.continue.4425:
  br label %local.descriptor.checked.4406
local.descriptor.inactive.4405:
  br label %local.descriptor.checked.4406
local.descriptor.checked.4406:
  %local.is.active.4426 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.4426, label %local.descriptor.active.4427, label %local.descriptor.inactive.4428
local.descriptor.active.4427:
  %local.check.offset.4430 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.4431 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.4432 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.4433 = load i32, ptr %local.owner.end.18, align 4
  %context.field.4434 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4435 = load i32, ptr %context.field.4434, align 4
  %stack.sub.4438 = sub i32 %local.check.owner.end.4433, %local.check.offset.4430
  %descriptor.owner.inside.4436 = icmp ule i32 %local.check.owner.end.4433, %context.value.4435
  %descriptor.offset.inside.4437 = icmp ule i32 %local.check.offset.4430, %local.check.owner.end.4433
  %descriptor.extent.inside.4439 = icmp ule i32 %local.check.extent.4431, %stack.sub.4438
  %descriptor.payload.inside.4440 = icmp ule i32 %local.check.payload.4432, %local.check.extent.4431
  %descriptor.owner.offset.valid.4441 = and i1 %descriptor.owner.inside.4436, %descriptor.offset.inside.4437
  %descriptor.range.inside.4443 = and i1 %descriptor.owner.offset.valid.4441, %descriptor.extent.inside.4439
  %descriptor.range.valid.4442 = and i1 %descriptor.range.inside.4443, %descriptor.payload.inside.4440
  br i1 %descriptor.range.valid.4442, label %descriptor.valid.4444, label %descriptor.invalid.4445
descriptor.invalid.4445:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4444:
  %descriptor.initialized.status.4446 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4430, i32 %local.check.extent.4431)
  %helper.ok.4447 = icmp eq i32 %descriptor.initialized.status.4446, 0
  br i1 %helper.ok.4447, label %helper.continue.4448, label %frame.failure.0
helper.continue.4448:
  br label %local.descriptor.checked.4429
local.descriptor.inactive.4428:
  br label %local.descriptor.checked.4429
local.descriptor.checked.4429:
  %local.is.active.4449 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.4449, label %local.descriptor.active.4450, label %local.descriptor.inactive.4451
local.descriptor.active.4450:
  %local.check.offset.4453 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.4454 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.4455 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.4456 = load i32, ptr %local.owner.end.24, align 4
  %context.field.4457 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4458 = load i32, ptr %context.field.4457, align 4
  %stack.sub.4461 = sub i32 %local.check.owner.end.4456, %local.check.offset.4453
  %descriptor.owner.inside.4459 = icmp ule i32 %local.check.owner.end.4456, %context.value.4458
  %descriptor.offset.inside.4460 = icmp ule i32 %local.check.offset.4453, %local.check.owner.end.4456
  %descriptor.extent.inside.4462 = icmp ule i32 %local.check.extent.4454, %stack.sub.4461
  %descriptor.payload.inside.4463 = icmp ule i32 %local.check.payload.4455, %local.check.extent.4454
  %descriptor.owner.offset.valid.4464 = and i1 %descriptor.owner.inside.4459, %descriptor.offset.inside.4460
  %descriptor.range.inside.4466 = and i1 %descriptor.owner.offset.valid.4464, %descriptor.extent.inside.4462
  %descriptor.range.valid.4465 = and i1 %descriptor.range.inside.4466, %descriptor.payload.inside.4463
  br i1 %descriptor.range.valid.4465, label %descriptor.valid.4467, label %descriptor.invalid.4468
descriptor.invalid.4468:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4467:
  %descriptor.initialized.status.4469 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4453, i32 %local.check.extent.4454)
  %helper.ok.4470 = icmp eq i32 %descriptor.initialized.status.4469, 0
  br i1 %helper.ok.4470, label %helper.continue.4471, label %frame.failure.0
helper.continue.4471:
  br label %local.descriptor.checked.4452
local.descriptor.inactive.4451:
  br label %local.descriptor.checked.4452
local.descriptor.checked.4452:
  %local.is.active.4472 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.4472, label %local.descriptor.active.4473, label %local.descriptor.inactive.4474
local.descriptor.active.4473:
  %local.check.offset.4476 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.4477 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.4478 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.4479 = load i32, ptr %local.owner.end.30, align 4
  %context.field.4480 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4481 = load i32, ptr %context.field.4480, align 4
  %stack.sub.4484 = sub i32 %local.check.owner.end.4479, %local.check.offset.4476
  %descriptor.owner.inside.4482 = icmp ule i32 %local.check.owner.end.4479, %context.value.4481
  %descriptor.offset.inside.4483 = icmp ule i32 %local.check.offset.4476, %local.check.owner.end.4479
  %descriptor.extent.inside.4485 = icmp ule i32 %local.check.extent.4477, %stack.sub.4484
  %descriptor.payload.inside.4486 = icmp ule i32 %local.check.payload.4478, %local.check.extent.4477
  %descriptor.owner.offset.valid.4487 = and i1 %descriptor.owner.inside.4482, %descriptor.offset.inside.4483
  %descriptor.range.inside.4489 = and i1 %descriptor.owner.offset.valid.4487, %descriptor.extent.inside.4485
  %descriptor.range.valid.4488 = and i1 %descriptor.range.inside.4489, %descriptor.payload.inside.4486
  br i1 %descriptor.range.valid.4488, label %descriptor.valid.4490, label %descriptor.invalid.4491
descriptor.invalid.4491:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4490:
  %descriptor.initialized.status.4492 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4476, i32 %local.check.extent.4477)
  %helper.ok.4493 = icmp eq i32 %descriptor.initialized.status.4492, 0
  br i1 %helper.ok.4493, label %helper.continue.4494, label %frame.failure.0
helper.continue.4494:
  br label %local.descriptor.checked.4475
local.descriptor.inactive.4474:
  br label %local.descriptor.checked.4475
local.descriptor.checked.4475:
  %local.is.active.4495 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.4495, label %local.descriptor.active.4496, label %local.descriptor.inactive.4497
local.descriptor.active.4496:
  %local.check.offset.4499 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.4500 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.4501 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.4502 = load i32, ptr %local.owner.end.36, align 4
  %context.field.4503 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4504 = load i32, ptr %context.field.4503, align 4
  %stack.sub.4507 = sub i32 %local.check.owner.end.4502, %local.check.offset.4499
  %descriptor.owner.inside.4505 = icmp ule i32 %local.check.owner.end.4502, %context.value.4504
  %descriptor.offset.inside.4506 = icmp ule i32 %local.check.offset.4499, %local.check.owner.end.4502
  %descriptor.extent.inside.4508 = icmp ule i32 %local.check.extent.4500, %stack.sub.4507
  %descriptor.payload.inside.4509 = icmp ule i32 %local.check.payload.4501, %local.check.extent.4500
  %descriptor.owner.offset.valid.4510 = and i1 %descriptor.owner.inside.4505, %descriptor.offset.inside.4506
  %descriptor.range.inside.4512 = and i1 %descriptor.owner.offset.valid.4510, %descriptor.extent.inside.4508
  %descriptor.range.valid.4511 = and i1 %descriptor.range.inside.4512, %descriptor.payload.inside.4509
  br i1 %descriptor.range.valid.4511, label %descriptor.valid.4513, label %descriptor.invalid.4514
descriptor.invalid.4514:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4513:
  %descriptor.initialized.status.4515 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4499, i32 %local.check.extent.4500)
  %helper.ok.4516 = icmp eq i32 %descriptor.initialized.status.4515, 0
  br i1 %helper.ok.4516, label %helper.continue.4517, label %frame.failure.0
helper.continue.4517:
  br label %local.descriptor.checked.4498
local.descriptor.inactive.4497:
  br label %local.descriptor.checked.4498
local.descriptor.checked.4498:
  %local.is.active.4518 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.4518, label %local.descriptor.active.4519, label %local.descriptor.inactive.4520
local.descriptor.active.4519:
  %local.check.offset.4522 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.4523 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.4524 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.4525 = load i32, ptr %local.owner.end.42, align 4
  %context.field.4526 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4527 = load i32, ptr %context.field.4526, align 4
  %stack.sub.4530 = sub i32 %local.check.owner.end.4525, %local.check.offset.4522
  %descriptor.owner.inside.4528 = icmp ule i32 %local.check.owner.end.4525, %context.value.4527
  %descriptor.offset.inside.4529 = icmp ule i32 %local.check.offset.4522, %local.check.owner.end.4525
  %descriptor.extent.inside.4531 = icmp ule i32 %local.check.extent.4523, %stack.sub.4530
  %descriptor.payload.inside.4532 = icmp ule i32 %local.check.payload.4524, %local.check.extent.4523
  %descriptor.owner.offset.valid.4533 = and i1 %descriptor.owner.inside.4528, %descriptor.offset.inside.4529
  %descriptor.range.inside.4535 = and i1 %descriptor.owner.offset.valid.4533, %descriptor.extent.inside.4531
  %descriptor.range.valid.4534 = and i1 %descriptor.range.inside.4535, %descriptor.payload.inside.4532
  br i1 %descriptor.range.valid.4534, label %descriptor.valid.4536, label %descriptor.invalid.4537
descriptor.invalid.4537:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4536:
  %descriptor.initialized.status.4538 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4522, i32 %local.check.extent.4523)
  %helper.ok.4539 = icmp eq i32 %descriptor.initialized.status.4538, 0
  br i1 %helper.ok.4539, label %helper.continue.4540, label %frame.failure.0
helper.continue.4540:
  br label %local.descriptor.checked.4521
local.descriptor.inactive.4520:
  br label %local.descriptor.checked.4521
local.descriptor.checked.4521:
  %step.status.4541 = call i32 @al_owning_charge_step(ptr %ctx, i32 68)
  %helper.ok.4542 = icmp eq i32 %step.status.4541, 0
  br i1 %helper.ok.4542, label %helper.continue.4543, label %frame.failure.0
helper.continue.4543:
  %context.field.4544 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.4545 = load i32, ptr %context.field.4544, align 4
  %inline.target.depth.within.interpreter.limit.4546 = icmp ule i32 %context.value.4545, 65
  br i1 %inline.target.depth.within.interpreter.limit.4546, label %inline.target.depth.ok.4547, label %inline.target.depth.invalid.4548
inline.target.depth.invalid.4548:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 69, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.4547:
  %context.field.4549 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4550 = load i32, ptr %context.field.4549, align 4
  %string.concat.plan.status.4554 = call i32 @al_owning_string_concat_plan(ptr %ctx, i32 %local.resolved.offset.4115, i32 %local.resolved.extent.4116, i32 %local.resolved.offset.4321, i32 %local.resolved.extent.4322, i32 70, ptr %string.concat.units.4551, ptr %string.concat.payload.pointer.4552, ptr %string.concat.extent.pointer.4553)
  %helper.ok.4555 = icmp eq i32 %string.concat.plan.status.4554, 0
  br i1 %helper.ok.4555, label %helper.continue.4556, label %frame.failure.0
helper.continue.4556:
  %string.concat.payload.4557 = load i32, ptr %string.concat.payload.pointer.4552, align 4
  %string.concat.extent.4558 = load i32, ptr %string.concat.extent.pointer.4553, align 4
  %stack.offset.4559 = add i32 %context.value.4550, %string.concat.extent.4558
  %reserve.status.4560 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.4559, i32 71)
  %reserve.ok.4561 = icmp eq i32 %reserve.status.4560, 0
  br i1 %reserve.ok.4561, label %reserve.continue.4562, label %frame.failure.0
reserve.continue.4562:
  %string.concat.write.status.4563 = call i32 @al_owning_string_concat_write(ptr %ctx, i32 %context.value.4550, i32 %string.concat.extent.4558, i32 %local.resolved.offset.4115, i32 %local.resolved.extent.4116, i32 %local.resolved.offset.4321, i32 %local.resolved.extent.4322, i32 6, i32 70)
  %helper.ok.4564 = icmp eq i32 %string.concat.write.status.4563, 0
  br i1 %helper.ok.4564, label %helper.continue.4565, label %frame.failure.0
helper.continue.4565:
  call void @al_owning_update_live(ptr %ctx, i32 %string.concat.payload.4557, i32 0)
  %context.field.4566 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4567 = load i32, ptr %context.field.4566, align 4
  %runtime.ok.4568 = icmp eq i32 %context.value.4567, 0
  br i1 %runtime.ok.4568, label %runtime.continue.4569, label %frame.failure.0
runtime.continue.4569:
  %context.field.4570 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4571 = load i32, ptr %context.field.4570, align 4
  %stack.sub.4574 = sub i32 %stack.offset.4559, %context.value.4550
  %descriptor.owner.inside.4572 = icmp ule i32 %stack.offset.4559, %context.value.4571
  %descriptor.offset.inside.4573 = icmp ule i32 %context.value.4550, %stack.offset.4559
  %descriptor.extent.inside.4575 = icmp ule i32 %string.concat.extent.4558, %stack.sub.4574
  %descriptor.payload.inside.4576 = icmp ule i32 %string.concat.payload.4557, %string.concat.extent.4558
  %descriptor.owner.offset.valid.4577 = and i1 %descriptor.owner.inside.4572, %descriptor.offset.inside.4573
  %descriptor.range.inside.4579 = and i1 %descriptor.owner.offset.valid.4577, %descriptor.extent.inside.4575
  %descriptor.range.valid.4578 = and i1 %descriptor.range.inside.4579, %descriptor.payload.inside.4576
  %descriptor.type.valid.4580 = icmp eq i32 6, 6
  %descriptor.valid.4581 = and i1 %descriptor.range.valid.4578, %descriptor.type.valid.4580
  br i1 %descriptor.valid.4581, label %descriptor.valid.4582, label %descriptor.invalid.4583
descriptor.invalid.4583:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4582:
  %descriptor.initialized.status.4584 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.4550, i32 %string.concat.extent.4558)
  %helper.ok.4585 = icmp eq i32 %descriptor.initialized.status.4584, 0
  br i1 %helper.ok.4585, label %helper.continue.4586, label %frame.failure.0
helper.continue.4586:
  %local.is.active.4587 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.4587, label %local.descriptor.active.4588, label %local.descriptor.inactive.4589
local.descriptor.active.4588:
  %local.check.offset.4591 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.4592 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.4593 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.4594 = load i32, ptr %local.owner.end.6, align 4
  %context.field.4595 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4596 = load i32, ptr %context.field.4595, align 4
  %stack.sub.4599 = sub i32 %local.check.owner.end.4594, %local.check.offset.4591
  %descriptor.owner.inside.4597 = icmp ule i32 %local.check.owner.end.4594, %context.value.4596
  %descriptor.offset.inside.4598 = icmp ule i32 %local.check.offset.4591, %local.check.owner.end.4594
  %descriptor.extent.inside.4600 = icmp ule i32 %local.check.extent.4592, %stack.sub.4599
  %descriptor.payload.inside.4601 = icmp ule i32 %local.check.payload.4593, %local.check.extent.4592
  %descriptor.owner.offset.valid.4602 = and i1 %descriptor.owner.inside.4597, %descriptor.offset.inside.4598
  %descriptor.range.inside.4604 = and i1 %descriptor.owner.offset.valid.4602, %descriptor.extent.inside.4600
  %descriptor.range.valid.4603 = and i1 %descriptor.range.inside.4604, %descriptor.payload.inside.4601
  br i1 %descriptor.range.valid.4603, label %descriptor.valid.4605, label %descriptor.invalid.4606
descriptor.invalid.4606:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4605:
  %descriptor.initialized.status.4607 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4591, i32 %local.check.extent.4592)
  %helper.ok.4608 = icmp eq i32 %descriptor.initialized.status.4607, 0
  br i1 %helper.ok.4608, label %helper.continue.4609, label %frame.failure.0
helper.continue.4609:
  br label %local.descriptor.checked.4590
local.descriptor.inactive.4589:
  br label %local.descriptor.checked.4590
local.descriptor.checked.4590:
  %local.is.active.4610 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.4610, label %local.descriptor.active.4611, label %local.descriptor.inactive.4612
local.descriptor.active.4611:
  %local.check.offset.4614 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.4615 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.4616 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.4617 = load i32, ptr %local.owner.end.12, align 4
  %context.field.4618 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4619 = load i32, ptr %context.field.4618, align 4
  %stack.sub.4622 = sub i32 %local.check.owner.end.4617, %local.check.offset.4614
  %descriptor.owner.inside.4620 = icmp ule i32 %local.check.owner.end.4617, %context.value.4619
  %descriptor.offset.inside.4621 = icmp ule i32 %local.check.offset.4614, %local.check.owner.end.4617
  %descriptor.extent.inside.4623 = icmp ule i32 %local.check.extent.4615, %stack.sub.4622
  %descriptor.payload.inside.4624 = icmp ule i32 %local.check.payload.4616, %local.check.extent.4615
  %descriptor.owner.offset.valid.4625 = and i1 %descriptor.owner.inside.4620, %descriptor.offset.inside.4621
  %descriptor.range.inside.4627 = and i1 %descriptor.owner.offset.valid.4625, %descriptor.extent.inside.4623
  %descriptor.range.valid.4626 = and i1 %descriptor.range.inside.4627, %descriptor.payload.inside.4624
  br i1 %descriptor.range.valid.4626, label %descriptor.valid.4628, label %descriptor.invalid.4629
descriptor.invalid.4629:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4628:
  %descriptor.initialized.status.4630 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4614, i32 %local.check.extent.4615)
  %helper.ok.4631 = icmp eq i32 %descriptor.initialized.status.4630, 0
  br i1 %helper.ok.4631, label %helper.continue.4632, label %frame.failure.0
helper.continue.4632:
  br label %local.descriptor.checked.4613
local.descriptor.inactive.4612:
  br label %local.descriptor.checked.4613
local.descriptor.checked.4613:
  %local.is.active.4633 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.4633, label %local.descriptor.active.4634, label %local.descriptor.inactive.4635
local.descriptor.active.4634:
  %local.check.offset.4637 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.4638 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.4639 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.4640 = load i32, ptr %local.owner.end.18, align 4
  %context.field.4641 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4642 = load i32, ptr %context.field.4641, align 4
  %stack.sub.4645 = sub i32 %local.check.owner.end.4640, %local.check.offset.4637
  %descriptor.owner.inside.4643 = icmp ule i32 %local.check.owner.end.4640, %context.value.4642
  %descriptor.offset.inside.4644 = icmp ule i32 %local.check.offset.4637, %local.check.owner.end.4640
  %descriptor.extent.inside.4646 = icmp ule i32 %local.check.extent.4638, %stack.sub.4645
  %descriptor.payload.inside.4647 = icmp ule i32 %local.check.payload.4639, %local.check.extent.4638
  %descriptor.owner.offset.valid.4648 = and i1 %descriptor.owner.inside.4643, %descriptor.offset.inside.4644
  %descriptor.range.inside.4650 = and i1 %descriptor.owner.offset.valid.4648, %descriptor.extent.inside.4646
  %descriptor.range.valid.4649 = and i1 %descriptor.range.inside.4650, %descriptor.payload.inside.4647
  br i1 %descriptor.range.valid.4649, label %descriptor.valid.4651, label %descriptor.invalid.4652
descriptor.invalid.4652:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4651:
  %descriptor.initialized.status.4653 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4637, i32 %local.check.extent.4638)
  %helper.ok.4654 = icmp eq i32 %descriptor.initialized.status.4653, 0
  br i1 %helper.ok.4654, label %helper.continue.4655, label %frame.failure.0
helper.continue.4655:
  br label %local.descriptor.checked.4636
local.descriptor.inactive.4635:
  br label %local.descriptor.checked.4636
local.descriptor.checked.4636:
  %local.is.active.4656 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.4656, label %local.descriptor.active.4657, label %local.descriptor.inactive.4658
local.descriptor.active.4657:
  %local.check.offset.4660 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.4661 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.4662 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.4663 = load i32, ptr %local.owner.end.24, align 4
  %context.field.4664 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4665 = load i32, ptr %context.field.4664, align 4
  %stack.sub.4668 = sub i32 %local.check.owner.end.4663, %local.check.offset.4660
  %descriptor.owner.inside.4666 = icmp ule i32 %local.check.owner.end.4663, %context.value.4665
  %descriptor.offset.inside.4667 = icmp ule i32 %local.check.offset.4660, %local.check.owner.end.4663
  %descriptor.extent.inside.4669 = icmp ule i32 %local.check.extent.4661, %stack.sub.4668
  %descriptor.payload.inside.4670 = icmp ule i32 %local.check.payload.4662, %local.check.extent.4661
  %descriptor.owner.offset.valid.4671 = and i1 %descriptor.owner.inside.4666, %descriptor.offset.inside.4667
  %descriptor.range.inside.4673 = and i1 %descriptor.owner.offset.valid.4671, %descriptor.extent.inside.4669
  %descriptor.range.valid.4672 = and i1 %descriptor.range.inside.4673, %descriptor.payload.inside.4670
  br i1 %descriptor.range.valid.4672, label %descriptor.valid.4674, label %descriptor.invalid.4675
descriptor.invalid.4675:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4674:
  %descriptor.initialized.status.4676 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4660, i32 %local.check.extent.4661)
  %helper.ok.4677 = icmp eq i32 %descriptor.initialized.status.4676, 0
  br i1 %helper.ok.4677, label %helper.continue.4678, label %frame.failure.0
helper.continue.4678:
  br label %local.descriptor.checked.4659
local.descriptor.inactive.4658:
  br label %local.descriptor.checked.4659
local.descriptor.checked.4659:
  %local.is.active.4679 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.4679, label %local.descriptor.active.4680, label %local.descriptor.inactive.4681
local.descriptor.active.4680:
  %local.check.offset.4683 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.4684 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.4685 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.4686 = load i32, ptr %local.owner.end.30, align 4
  %context.field.4687 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4688 = load i32, ptr %context.field.4687, align 4
  %stack.sub.4691 = sub i32 %local.check.owner.end.4686, %local.check.offset.4683
  %descriptor.owner.inside.4689 = icmp ule i32 %local.check.owner.end.4686, %context.value.4688
  %descriptor.offset.inside.4690 = icmp ule i32 %local.check.offset.4683, %local.check.owner.end.4686
  %descriptor.extent.inside.4692 = icmp ule i32 %local.check.extent.4684, %stack.sub.4691
  %descriptor.payload.inside.4693 = icmp ule i32 %local.check.payload.4685, %local.check.extent.4684
  %descriptor.owner.offset.valid.4694 = and i1 %descriptor.owner.inside.4689, %descriptor.offset.inside.4690
  %descriptor.range.inside.4696 = and i1 %descriptor.owner.offset.valid.4694, %descriptor.extent.inside.4692
  %descriptor.range.valid.4695 = and i1 %descriptor.range.inside.4696, %descriptor.payload.inside.4693
  br i1 %descriptor.range.valid.4695, label %descriptor.valid.4697, label %descriptor.invalid.4698
descriptor.invalid.4698:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4697:
  %descriptor.initialized.status.4699 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4683, i32 %local.check.extent.4684)
  %helper.ok.4700 = icmp eq i32 %descriptor.initialized.status.4699, 0
  br i1 %helper.ok.4700, label %helper.continue.4701, label %frame.failure.0
helper.continue.4701:
  br label %local.descriptor.checked.4682
local.descriptor.inactive.4681:
  br label %local.descriptor.checked.4682
local.descriptor.checked.4682:
  %local.is.active.4702 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.4702, label %local.descriptor.active.4703, label %local.descriptor.inactive.4704
local.descriptor.active.4703:
  %local.check.offset.4706 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.4707 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.4708 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.4709 = load i32, ptr %local.owner.end.36, align 4
  %context.field.4710 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4711 = load i32, ptr %context.field.4710, align 4
  %stack.sub.4714 = sub i32 %local.check.owner.end.4709, %local.check.offset.4706
  %descriptor.owner.inside.4712 = icmp ule i32 %local.check.owner.end.4709, %context.value.4711
  %descriptor.offset.inside.4713 = icmp ule i32 %local.check.offset.4706, %local.check.owner.end.4709
  %descriptor.extent.inside.4715 = icmp ule i32 %local.check.extent.4707, %stack.sub.4714
  %descriptor.payload.inside.4716 = icmp ule i32 %local.check.payload.4708, %local.check.extent.4707
  %descriptor.owner.offset.valid.4717 = and i1 %descriptor.owner.inside.4712, %descriptor.offset.inside.4713
  %descriptor.range.inside.4719 = and i1 %descriptor.owner.offset.valid.4717, %descriptor.extent.inside.4715
  %descriptor.range.valid.4718 = and i1 %descriptor.range.inside.4719, %descriptor.payload.inside.4716
  br i1 %descriptor.range.valid.4718, label %descriptor.valid.4720, label %descriptor.invalid.4721
descriptor.invalid.4721:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4720:
  %descriptor.initialized.status.4722 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4706, i32 %local.check.extent.4707)
  %helper.ok.4723 = icmp eq i32 %descriptor.initialized.status.4722, 0
  br i1 %helper.ok.4723, label %helper.continue.4724, label %frame.failure.0
helper.continue.4724:
  br label %local.descriptor.checked.4705
local.descriptor.inactive.4704:
  br label %local.descriptor.checked.4705
local.descriptor.checked.4705:
  %local.is.active.4725 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.4725, label %local.descriptor.active.4726, label %local.descriptor.inactive.4727
local.descriptor.active.4726:
  %local.check.offset.4729 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.4730 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.4731 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.4732 = load i32, ptr %local.owner.end.42, align 4
  %context.field.4733 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4734 = load i32, ptr %context.field.4733, align 4
  %stack.sub.4737 = sub i32 %local.check.owner.end.4732, %local.check.offset.4729
  %descriptor.owner.inside.4735 = icmp ule i32 %local.check.owner.end.4732, %context.value.4734
  %descriptor.offset.inside.4736 = icmp ule i32 %local.check.offset.4729, %local.check.owner.end.4732
  %descriptor.extent.inside.4738 = icmp ule i32 %local.check.extent.4730, %stack.sub.4737
  %descriptor.payload.inside.4739 = icmp ule i32 %local.check.payload.4731, %local.check.extent.4730
  %descriptor.owner.offset.valid.4740 = and i1 %descriptor.owner.inside.4735, %descriptor.offset.inside.4736
  %descriptor.range.inside.4742 = and i1 %descriptor.owner.offset.valid.4740, %descriptor.extent.inside.4738
  %descriptor.range.valid.4741 = and i1 %descriptor.range.inside.4742, %descriptor.payload.inside.4739
  br i1 %descriptor.range.valid.4741, label %descriptor.valid.4743, label %descriptor.invalid.4744
descriptor.invalid.4744:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4743:
  %descriptor.initialized.status.4745 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4729, i32 %local.check.extent.4730)
  %helper.ok.4746 = icmp eq i32 %descriptor.initialized.status.4745, 0
  br i1 %helper.ok.4746, label %helper.continue.4747, label %frame.failure.0
helper.continue.4747:
  br label %local.descriptor.checked.4728
local.descriptor.inactive.4727:
  br label %local.descriptor.checked.4728
local.descriptor.checked.4728:
  %step.status.4748 = call i32 @al_owning_charge_step(ptr %ctx, i32 72)
  %helper.ok.4749 = icmp eq i32 %step.status.4748, 0
  br i1 %helper.ok.4749, label %helper.continue.4750, label %frame.failure.0
helper.continue.4750:
  store i1 true, ptr %local.active.32, align 1
  store i32 %context.value.4550, ptr %local.offset.33, align 4
  store i32 %string.concat.extent.4558, ptr %local.extent.34, align 4
  store i32 %string.concat.payload.4557, ptr %local.payload.35, align 4
  store i32 %stack.offset.4559, ptr %local.owner.end.36, align 4
  store i32 6, ptr %local.type.37, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %context.value.4550, i32 20, i32 %string.concat.payload.4557, i32 %stack.offset.4559, i32 %string.concat.extent.4558)
  %context.field.4751 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4752 = load i32, ptr %context.field.4751, align 4
  %runtime.ok.4753 = icmp eq i32 %context.value.4752, 0
  br i1 %runtime.ok.4753, label %runtime.continue.4754, label %frame.failure.0
runtime.continue.4754:
  %local.is.active.4755 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.4755, label %local.descriptor.active.4756, label %local.descriptor.inactive.4757
local.descriptor.active.4756:
  %local.check.offset.4759 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.4760 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.4761 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.4762 = load i32, ptr %local.owner.end.6, align 4
  %context.field.4763 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4764 = load i32, ptr %context.field.4763, align 4
  %stack.sub.4767 = sub i32 %local.check.owner.end.4762, %local.check.offset.4759
  %descriptor.owner.inside.4765 = icmp ule i32 %local.check.owner.end.4762, %context.value.4764
  %descriptor.offset.inside.4766 = icmp ule i32 %local.check.offset.4759, %local.check.owner.end.4762
  %descriptor.extent.inside.4768 = icmp ule i32 %local.check.extent.4760, %stack.sub.4767
  %descriptor.payload.inside.4769 = icmp ule i32 %local.check.payload.4761, %local.check.extent.4760
  %descriptor.owner.offset.valid.4770 = and i1 %descriptor.owner.inside.4765, %descriptor.offset.inside.4766
  %descriptor.range.inside.4772 = and i1 %descriptor.owner.offset.valid.4770, %descriptor.extent.inside.4768
  %descriptor.range.valid.4771 = and i1 %descriptor.range.inside.4772, %descriptor.payload.inside.4769
  br i1 %descriptor.range.valid.4771, label %descriptor.valid.4773, label %descriptor.invalid.4774
descriptor.invalid.4774:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4773:
  %descriptor.initialized.status.4775 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4759, i32 %local.check.extent.4760)
  %helper.ok.4776 = icmp eq i32 %descriptor.initialized.status.4775, 0
  br i1 %helper.ok.4776, label %helper.continue.4777, label %frame.failure.0
helper.continue.4777:
  br label %local.descriptor.checked.4758
local.descriptor.inactive.4757:
  br label %local.descriptor.checked.4758
local.descriptor.checked.4758:
  %local.is.active.4778 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.4778, label %local.descriptor.active.4779, label %local.descriptor.inactive.4780
local.descriptor.active.4779:
  %local.check.offset.4782 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.4783 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.4784 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.4785 = load i32, ptr %local.owner.end.12, align 4
  %context.field.4786 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4787 = load i32, ptr %context.field.4786, align 4
  %stack.sub.4790 = sub i32 %local.check.owner.end.4785, %local.check.offset.4782
  %descriptor.owner.inside.4788 = icmp ule i32 %local.check.owner.end.4785, %context.value.4787
  %descriptor.offset.inside.4789 = icmp ule i32 %local.check.offset.4782, %local.check.owner.end.4785
  %descriptor.extent.inside.4791 = icmp ule i32 %local.check.extent.4783, %stack.sub.4790
  %descriptor.payload.inside.4792 = icmp ule i32 %local.check.payload.4784, %local.check.extent.4783
  %descriptor.owner.offset.valid.4793 = and i1 %descriptor.owner.inside.4788, %descriptor.offset.inside.4789
  %descriptor.range.inside.4795 = and i1 %descriptor.owner.offset.valid.4793, %descriptor.extent.inside.4791
  %descriptor.range.valid.4794 = and i1 %descriptor.range.inside.4795, %descriptor.payload.inside.4792
  br i1 %descriptor.range.valid.4794, label %descriptor.valid.4796, label %descriptor.invalid.4797
descriptor.invalid.4797:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4796:
  %descriptor.initialized.status.4798 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4782, i32 %local.check.extent.4783)
  %helper.ok.4799 = icmp eq i32 %descriptor.initialized.status.4798, 0
  br i1 %helper.ok.4799, label %helper.continue.4800, label %frame.failure.0
helper.continue.4800:
  br label %local.descriptor.checked.4781
local.descriptor.inactive.4780:
  br label %local.descriptor.checked.4781
local.descriptor.checked.4781:
  %local.is.active.4801 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.4801, label %local.descriptor.active.4802, label %local.descriptor.inactive.4803
local.descriptor.active.4802:
  %local.check.offset.4805 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.4806 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.4807 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.4808 = load i32, ptr %local.owner.end.18, align 4
  %context.field.4809 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4810 = load i32, ptr %context.field.4809, align 4
  %stack.sub.4813 = sub i32 %local.check.owner.end.4808, %local.check.offset.4805
  %descriptor.owner.inside.4811 = icmp ule i32 %local.check.owner.end.4808, %context.value.4810
  %descriptor.offset.inside.4812 = icmp ule i32 %local.check.offset.4805, %local.check.owner.end.4808
  %descriptor.extent.inside.4814 = icmp ule i32 %local.check.extent.4806, %stack.sub.4813
  %descriptor.payload.inside.4815 = icmp ule i32 %local.check.payload.4807, %local.check.extent.4806
  %descriptor.owner.offset.valid.4816 = and i1 %descriptor.owner.inside.4811, %descriptor.offset.inside.4812
  %descriptor.range.inside.4818 = and i1 %descriptor.owner.offset.valid.4816, %descriptor.extent.inside.4814
  %descriptor.range.valid.4817 = and i1 %descriptor.range.inside.4818, %descriptor.payload.inside.4815
  br i1 %descriptor.range.valid.4817, label %descriptor.valid.4819, label %descriptor.invalid.4820
descriptor.invalid.4820:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4819:
  %descriptor.initialized.status.4821 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4805, i32 %local.check.extent.4806)
  %helper.ok.4822 = icmp eq i32 %descriptor.initialized.status.4821, 0
  br i1 %helper.ok.4822, label %helper.continue.4823, label %frame.failure.0
helper.continue.4823:
  br label %local.descriptor.checked.4804
local.descriptor.inactive.4803:
  br label %local.descriptor.checked.4804
local.descriptor.checked.4804:
  %local.is.active.4824 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.4824, label %local.descriptor.active.4825, label %local.descriptor.inactive.4826
local.descriptor.active.4825:
  %local.check.offset.4828 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.4829 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.4830 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.4831 = load i32, ptr %local.owner.end.24, align 4
  %context.field.4832 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4833 = load i32, ptr %context.field.4832, align 4
  %stack.sub.4836 = sub i32 %local.check.owner.end.4831, %local.check.offset.4828
  %descriptor.owner.inside.4834 = icmp ule i32 %local.check.owner.end.4831, %context.value.4833
  %descriptor.offset.inside.4835 = icmp ule i32 %local.check.offset.4828, %local.check.owner.end.4831
  %descriptor.extent.inside.4837 = icmp ule i32 %local.check.extent.4829, %stack.sub.4836
  %descriptor.payload.inside.4838 = icmp ule i32 %local.check.payload.4830, %local.check.extent.4829
  %descriptor.owner.offset.valid.4839 = and i1 %descriptor.owner.inside.4834, %descriptor.offset.inside.4835
  %descriptor.range.inside.4841 = and i1 %descriptor.owner.offset.valid.4839, %descriptor.extent.inside.4837
  %descriptor.range.valid.4840 = and i1 %descriptor.range.inside.4841, %descriptor.payload.inside.4838
  br i1 %descriptor.range.valid.4840, label %descriptor.valid.4842, label %descriptor.invalid.4843
descriptor.invalid.4843:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4842:
  %descriptor.initialized.status.4844 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4828, i32 %local.check.extent.4829)
  %helper.ok.4845 = icmp eq i32 %descriptor.initialized.status.4844, 0
  br i1 %helper.ok.4845, label %helper.continue.4846, label %frame.failure.0
helper.continue.4846:
  br label %local.descriptor.checked.4827
local.descriptor.inactive.4826:
  br label %local.descriptor.checked.4827
local.descriptor.checked.4827:
  %local.is.active.4847 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.4847, label %local.descriptor.active.4848, label %local.descriptor.inactive.4849
local.descriptor.active.4848:
  %local.check.offset.4851 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.4852 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.4853 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.4854 = load i32, ptr %local.owner.end.30, align 4
  %context.field.4855 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4856 = load i32, ptr %context.field.4855, align 4
  %stack.sub.4859 = sub i32 %local.check.owner.end.4854, %local.check.offset.4851
  %descriptor.owner.inside.4857 = icmp ule i32 %local.check.owner.end.4854, %context.value.4856
  %descriptor.offset.inside.4858 = icmp ule i32 %local.check.offset.4851, %local.check.owner.end.4854
  %descriptor.extent.inside.4860 = icmp ule i32 %local.check.extent.4852, %stack.sub.4859
  %descriptor.payload.inside.4861 = icmp ule i32 %local.check.payload.4853, %local.check.extent.4852
  %descriptor.owner.offset.valid.4862 = and i1 %descriptor.owner.inside.4857, %descriptor.offset.inside.4858
  %descriptor.range.inside.4864 = and i1 %descriptor.owner.offset.valid.4862, %descriptor.extent.inside.4860
  %descriptor.range.valid.4863 = and i1 %descriptor.range.inside.4864, %descriptor.payload.inside.4861
  br i1 %descriptor.range.valid.4863, label %descriptor.valid.4865, label %descriptor.invalid.4866
descriptor.invalid.4866:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4865:
  %descriptor.initialized.status.4867 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4851, i32 %local.check.extent.4852)
  %helper.ok.4868 = icmp eq i32 %descriptor.initialized.status.4867, 0
  br i1 %helper.ok.4868, label %helper.continue.4869, label %frame.failure.0
helper.continue.4869:
  br label %local.descriptor.checked.4850
local.descriptor.inactive.4849:
  br label %local.descriptor.checked.4850
local.descriptor.checked.4850:
  %local.is.active.4870 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.4870, label %local.descriptor.active.4871, label %local.descriptor.inactive.4872
local.descriptor.active.4871:
  %local.check.offset.4874 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.4875 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.4876 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.4877 = load i32, ptr %local.owner.end.36, align 4
  %context.field.4878 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4879 = load i32, ptr %context.field.4878, align 4
  %stack.sub.4882 = sub i32 %local.check.owner.end.4877, %local.check.offset.4874
  %descriptor.owner.inside.4880 = icmp ule i32 %local.check.owner.end.4877, %context.value.4879
  %descriptor.offset.inside.4881 = icmp ule i32 %local.check.offset.4874, %local.check.owner.end.4877
  %descriptor.extent.inside.4883 = icmp ule i32 %local.check.extent.4875, %stack.sub.4882
  %descriptor.payload.inside.4884 = icmp ule i32 %local.check.payload.4876, %local.check.extent.4875
  %descriptor.owner.offset.valid.4885 = and i1 %descriptor.owner.inside.4880, %descriptor.offset.inside.4881
  %descriptor.range.inside.4887 = and i1 %descriptor.owner.offset.valid.4885, %descriptor.extent.inside.4883
  %descriptor.range.valid.4886 = and i1 %descriptor.range.inside.4887, %descriptor.payload.inside.4884
  br i1 %descriptor.range.valid.4886, label %descriptor.valid.4888, label %descriptor.invalid.4889
descriptor.invalid.4889:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4888:
  %descriptor.initialized.status.4890 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4874, i32 %local.check.extent.4875)
  %helper.ok.4891 = icmp eq i32 %descriptor.initialized.status.4890, 0
  br i1 %helper.ok.4891, label %helper.continue.4892, label %frame.failure.0
helper.continue.4892:
  br label %local.descriptor.checked.4873
local.descriptor.inactive.4872:
  br label %local.descriptor.checked.4873
local.descriptor.checked.4873:
  %local.is.active.4893 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.4893, label %local.descriptor.active.4894, label %local.descriptor.inactive.4895
local.descriptor.active.4894:
  %local.check.offset.4897 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.4898 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.4899 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.4900 = load i32, ptr %local.owner.end.42, align 4
  %context.field.4901 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4902 = load i32, ptr %context.field.4901, align 4
  %stack.sub.4905 = sub i32 %local.check.owner.end.4900, %local.check.offset.4897
  %descriptor.owner.inside.4903 = icmp ule i32 %local.check.owner.end.4900, %context.value.4902
  %descriptor.offset.inside.4904 = icmp ule i32 %local.check.offset.4897, %local.check.owner.end.4900
  %descriptor.extent.inside.4906 = icmp ule i32 %local.check.extent.4898, %stack.sub.4905
  %descriptor.payload.inside.4907 = icmp ule i32 %local.check.payload.4899, %local.check.extent.4898
  %descriptor.owner.offset.valid.4908 = and i1 %descriptor.owner.inside.4903, %descriptor.offset.inside.4904
  %descriptor.range.inside.4910 = and i1 %descriptor.owner.offset.valid.4908, %descriptor.extent.inside.4906
  %descriptor.range.valid.4909 = and i1 %descriptor.range.inside.4910, %descriptor.payload.inside.4907
  br i1 %descriptor.range.valid.4909, label %descriptor.valid.4911, label %descriptor.invalid.4912
descriptor.invalid.4912:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4911:
  %descriptor.initialized.status.4913 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4897, i32 %local.check.extent.4898)
  %helper.ok.4914 = icmp eq i32 %descriptor.initialized.status.4913, 0
  br i1 %helper.ok.4914, label %helper.continue.4915, label %frame.failure.0
helper.continue.4915:
  br label %local.descriptor.checked.4896
local.descriptor.inactive.4895:
  br label %local.descriptor.checked.4896
local.descriptor.checked.4896:
  %step.status.4916 = call i32 @al_owning_charge_step(ptr %ctx, i32 73)
  %helper.ok.4917 = icmp eq i32 %step.status.4916, 0
  br i1 %helper.ok.4917, label %helper.continue.4918, label %frame.failure.0
helper.continue.4918:
  %context.field.4919 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4920 = load i32, ptr %context.field.4919, align 4
  store i1 false, ptr %local.active.38, align 1
  store i32 0, ptr %local.offset.39, align 4
  store i32 0, ptr %local.extent.40, align 4
  store i32 0, ptr %local.payload.41, align 4
  store i32 0, ptr %local.owner.end.42, align 4
  store i32 0, ptr %local.type.43, align 4
  %step.status.4921 = call i32 @al_owning_charge_step(ptr %ctx, i32 74)
  %helper.ok.4922 = icmp eq i32 %step.status.4921, 0
  br i1 %helper.ok.4922, label %helper.continue.4923, label %frame.failure.0
helper.continue.4923:
  %local.resolved.offset.4924 = load i32, ptr %local.offset.33, align 4
  %local.resolved.extent.4925 = load i32, ptr %local.extent.34, align 4
  %local.resolved.payload.4926 = load i32, ptr %local.payload.35, align 4
  %local.resolved.owner.end.4927 = load i32, ptr %local.owner.end.36, align 4
  %context.field.4928 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4929 = load i32, ptr %context.field.4928, align 4
  %stack.sub.4932 = sub i32 %local.resolved.owner.end.4927, %local.resolved.offset.4924
  %descriptor.owner.inside.4930 = icmp ule i32 %local.resolved.owner.end.4927, %context.value.4929
  %descriptor.offset.inside.4931 = icmp ule i32 %local.resolved.offset.4924, %local.resolved.owner.end.4927
  %descriptor.extent.inside.4933 = icmp ule i32 %local.resolved.extent.4925, %stack.sub.4932
  %descriptor.payload.inside.4934 = icmp ule i32 %local.resolved.payload.4926, %local.resolved.extent.4925
  %descriptor.owner.offset.valid.4935 = and i1 %descriptor.owner.inside.4930, %descriptor.offset.inside.4931
  %descriptor.range.inside.4937 = and i1 %descriptor.owner.offset.valid.4935, %descriptor.extent.inside.4933
  %descriptor.range.valid.4936 = and i1 %descriptor.range.inside.4937, %descriptor.payload.inside.4934
  %descriptor.type.valid.4938 = icmp eq i32 6, 6
  %descriptor.valid.4939 = and i1 %descriptor.range.valid.4936, %descriptor.type.valid.4938
  br i1 %descriptor.valid.4939, label %descriptor.valid.4940, label %descriptor.invalid.4941
descriptor.invalid.4941:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4940:
  %descriptor.initialized.status.4942 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.4924, i32 %local.resolved.extent.4925)
  %helper.ok.4943 = icmp eq i32 %descriptor.initialized.status.4942, 0
  br i1 %helper.ok.4943, label %helper.continue.4944, label %frame.failure.0
helper.continue.4944:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %local.resolved.offset.4924, i32 20, i32 %local.resolved.payload.4926, i32 %local.resolved.owner.end.4927, i32 %local.resolved.extent.4925)
  %context.field.4945 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4946 = load i32, ptr %context.field.4945, align 4
  %runtime.ok.4947 = icmp eq i32 %context.value.4946, 0
  br i1 %runtime.ok.4947, label %runtime.continue.4948, label %frame.failure.0
runtime.continue.4948:
  %context.field.4949 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4950 = load i32, ptr %context.field.4949, align 4
  %stack.sub.4953 = sub i32 %local.resolved.owner.end.4927, %local.resolved.offset.4924
  %descriptor.owner.inside.4951 = icmp ule i32 %local.resolved.owner.end.4927, %context.value.4950
  %descriptor.offset.inside.4952 = icmp ule i32 %local.resolved.offset.4924, %local.resolved.owner.end.4927
  %descriptor.extent.inside.4954 = icmp ule i32 %local.resolved.extent.4925, %stack.sub.4953
  %descriptor.payload.inside.4955 = icmp ule i32 %local.resolved.payload.4926, %local.resolved.extent.4925
  %descriptor.owner.offset.valid.4956 = and i1 %descriptor.owner.inside.4951, %descriptor.offset.inside.4952
  %descriptor.range.inside.4958 = and i1 %descriptor.owner.offset.valid.4956, %descriptor.extent.inside.4954
  %descriptor.range.valid.4957 = and i1 %descriptor.range.inside.4958, %descriptor.payload.inside.4955
  %descriptor.type.valid.4959 = icmp eq i32 6, 6
  %descriptor.valid.4960 = and i1 %descriptor.range.valid.4957, %descriptor.type.valid.4959
  br i1 %descriptor.valid.4960, label %descriptor.valid.4961, label %descriptor.invalid.4962
descriptor.invalid.4962:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4961:
  %descriptor.initialized.status.4963 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.4924, i32 %local.resolved.extent.4925)
  %helper.ok.4964 = icmp eq i32 %descriptor.initialized.status.4963, 0
  br i1 %helper.ok.4964, label %helper.continue.4965, label %frame.failure.0
helper.continue.4965:
  %local.is.active.4966 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.4966, label %local.descriptor.active.4967, label %local.descriptor.inactive.4968
local.descriptor.active.4967:
  %local.check.offset.4970 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.4971 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.4972 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.4973 = load i32, ptr %local.owner.end.6, align 4
  %context.field.4974 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4975 = load i32, ptr %context.field.4974, align 4
  %stack.sub.4978 = sub i32 %local.check.owner.end.4973, %local.check.offset.4970
  %descriptor.owner.inside.4976 = icmp ule i32 %local.check.owner.end.4973, %context.value.4975
  %descriptor.offset.inside.4977 = icmp ule i32 %local.check.offset.4970, %local.check.owner.end.4973
  %descriptor.extent.inside.4979 = icmp ule i32 %local.check.extent.4971, %stack.sub.4978
  %descriptor.payload.inside.4980 = icmp ule i32 %local.check.payload.4972, %local.check.extent.4971
  %descriptor.owner.offset.valid.4981 = and i1 %descriptor.owner.inside.4976, %descriptor.offset.inside.4977
  %descriptor.range.inside.4983 = and i1 %descriptor.owner.offset.valid.4981, %descriptor.extent.inside.4979
  %descriptor.range.valid.4982 = and i1 %descriptor.range.inside.4983, %descriptor.payload.inside.4980
  br i1 %descriptor.range.valid.4982, label %descriptor.valid.4984, label %descriptor.invalid.4985
descriptor.invalid.4985:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4984:
  %descriptor.initialized.status.4986 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4970, i32 %local.check.extent.4971)
  %helper.ok.4987 = icmp eq i32 %descriptor.initialized.status.4986, 0
  br i1 %helper.ok.4987, label %helper.continue.4988, label %frame.failure.0
helper.continue.4988:
  br label %local.descriptor.checked.4969
local.descriptor.inactive.4968:
  br label %local.descriptor.checked.4969
local.descriptor.checked.4969:
  %local.is.active.4989 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.4989, label %local.descriptor.active.4990, label %local.descriptor.inactive.4991
local.descriptor.active.4990:
  %local.check.offset.4993 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.4994 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.4995 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.4996 = load i32, ptr %local.owner.end.12, align 4
  %context.field.4997 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4998 = load i32, ptr %context.field.4997, align 4
  %stack.sub.5001 = sub i32 %local.check.owner.end.4996, %local.check.offset.4993
  %descriptor.owner.inside.4999 = icmp ule i32 %local.check.owner.end.4996, %context.value.4998
  %descriptor.offset.inside.5000 = icmp ule i32 %local.check.offset.4993, %local.check.owner.end.4996
  %descriptor.extent.inside.5002 = icmp ule i32 %local.check.extent.4994, %stack.sub.5001
  %descriptor.payload.inside.5003 = icmp ule i32 %local.check.payload.4995, %local.check.extent.4994
  %descriptor.owner.offset.valid.5004 = and i1 %descriptor.owner.inside.4999, %descriptor.offset.inside.5000
  %descriptor.range.inside.5006 = and i1 %descriptor.owner.offset.valid.5004, %descriptor.extent.inside.5002
  %descriptor.range.valid.5005 = and i1 %descriptor.range.inside.5006, %descriptor.payload.inside.5003
  br i1 %descriptor.range.valid.5005, label %descriptor.valid.5007, label %descriptor.invalid.5008
descriptor.invalid.5008:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5007:
  %descriptor.initialized.status.5009 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4993, i32 %local.check.extent.4994)
  %helper.ok.5010 = icmp eq i32 %descriptor.initialized.status.5009, 0
  br i1 %helper.ok.5010, label %helper.continue.5011, label %frame.failure.0
helper.continue.5011:
  br label %local.descriptor.checked.4992
local.descriptor.inactive.4991:
  br label %local.descriptor.checked.4992
local.descriptor.checked.4992:
  %local.is.active.5012 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.5012, label %local.descriptor.active.5013, label %local.descriptor.inactive.5014
local.descriptor.active.5013:
  %local.check.offset.5016 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.5017 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.5018 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.5019 = load i32, ptr %local.owner.end.18, align 4
  %context.field.5020 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5021 = load i32, ptr %context.field.5020, align 4
  %stack.sub.5024 = sub i32 %local.check.owner.end.5019, %local.check.offset.5016
  %descriptor.owner.inside.5022 = icmp ule i32 %local.check.owner.end.5019, %context.value.5021
  %descriptor.offset.inside.5023 = icmp ule i32 %local.check.offset.5016, %local.check.owner.end.5019
  %descriptor.extent.inside.5025 = icmp ule i32 %local.check.extent.5017, %stack.sub.5024
  %descriptor.payload.inside.5026 = icmp ule i32 %local.check.payload.5018, %local.check.extent.5017
  %descriptor.owner.offset.valid.5027 = and i1 %descriptor.owner.inside.5022, %descriptor.offset.inside.5023
  %descriptor.range.inside.5029 = and i1 %descriptor.owner.offset.valid.5027, %descriptor.extent.inside.5025
  %descriptor.range.valid.5028 = and i1 %descriptor.range.inside.5029, %descriptor.payload.inside.5026
  br i1 %descriptor.range.valid.5028, label %descriptor.valid.5030, label %descriptor.invalid.5031
descriptor.invalid.5031:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5030:
  %descriptor.initialized.status.5032 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5016, i32 %local.check.extent.5017)
  %helper.ok.5033 = icmp eq i32 %descriptor.initialized.status.5032, 0
  br i1 %helper.ok.5033, label %helper.continue.5034, label %frame.failure.0
helper.continue.5034:
  br label %local.descriptor.checked.5015
local.descriptor.inactive.5014:
  br label %local.descriptor.checked.5015
local.descriptor.checked.5015:
  %local.is.active.5035 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.5035, label %local.descriptor.active.5036, label %local.descriptor.inactive.5037
local.descriptor.active.5036:
  %local.check.offset.5039 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.5040 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.5041 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.5042 = load i32, ptr %local.owner.end.24, align 4
  %context.field.5043 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5044 = load i32, ptr %context.field.5043, align 4
  %stack.sub.5047 = sub i32 %local.check.owner.end.5042, %local.check.offset.5039
  %descriptor.owner.inside.5045 = icmp ule i32 %local.check.owner.end.5042, %context.value.5044
  %descriptor.offset.inside.5046 = icmp ule i32 %local.check.offset.5039, %local.check.owner.end.5042
  %descriptor.extent.inside.5048 = icmp ule i32 %local.check.extent.5040, %stack.sub.5047
  %descriptor.payload.inside.5049 = icmp ule i32 %local.check.payload.5041, %local.check.extent.5040
  %descriptor.owner.offset.valid.5050 = and i1 %descriptor.owner.inside.5045, %descriptor.offset.inside.5046
  %descriptor.range.inside.5052 = and i1 %descriptor.owner.offset.valid.5050, %descriptor.extent.inside.5048
  %descriptor.range.valid.5051 = and i1 %descriptor.range.inside.5052, %descriptor.payload.inside.5049
  br i1 %descriptor.range.valid.5051, label %descriptor.valid.5053, label %descriptor.invalid.5054
descriptor.invalid.5054:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5053:
  %descriptor.initialized.status.5055 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5039, i32 %local.check.extent.5040)
  %helper.ok.5056 = icmp eq i32 %descriptor.initialized.status.5055, 0
  br i1 %helper.ok.5056, label %helper.continue.5057, label %frame.failure.0
helper.continue.5057:
  br label %local.descriptor.checked.5038
local.descriptor.inactive.5037:
  br label %local.descriptor.checked.5038
local.descriptor.checked.5038:
  %local.is.active.5058 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.5058, label %local.descriptor.active.5059, label %local.descriptor.inactive.5060
local.descriptor.active.5059:
  %local.check.offset.5062 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.5063 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.5064 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.5065 = load i32, ptr %local.owner.end.30, align 4
  %context.field.5066 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5067 = load i32, ptr %context.field.5066, align 4
  %stack.sub.5070 = sub i32 %local.check.owner.end.5065, %local.check.offset.5062
  %descriptor.owner.inside.5068 = icmp ule i32 %local.check.owner.end.5065, %context.value.5067
  %descriptor.offset.inside.5069 = icmp ule i32 %local.check.offset.5062, %local.check.owner.end.5065
  %descriptor.extent.inside.5071 = icmp ule i32 %local.check.extent.5063, %stack.sub.5070
  %descriptor.payload.inside.5072 = icmp ule i32 %local.check.payload.5064, %local.check.extent.5063
  %descriptor.owner.offset.valid.5073 = and i1 %descriptor.owner.inside.5068, %descriptor.offset.inside.5069
  %descriptor.range.inside.5075 = and i1 %descriptor.owner.offset.valid.5073, %descriptor.extent.inside.5071
  %descriptor.range.valid.5074 = and i1 %descriptor.range.inside.5075, %descriptor.payload.inside.5072
  br i1 %descriptor.range.valid.5074, label %descriptor.valid.5076, label %descriptor.invalid.5077
descriptor.invalid.5077:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5076:
  %descriptor.initialized.status.5078 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5062, i32 %local.check.extent.5063)
  %helper.ok.5079 = icmp eq i32 %descriptor.initialized.status.5078, 0
  br i1 %helper.ok.5079, label %helper.continue.5080, label %frame.failure.0
helper.continue.5080:
  br label %local.descriptor.checked.5061
local.descriptor.inactive.5060:
  br label %local.descriptor.checked.5061
local.descriptor.checked.5061:
  %local.is.active.5081 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.5081, label %local.descriptor.active.5082, label %local.descriptor.inactive.5083
local.descriptor.active.5082:
  %local.check.offset.5085 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.5086 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.5087 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.5088 = load i32, ptr %local.owner.end.36, align 4
  %context.field.5089 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5090 = load i32, ptr %context.field.5089, align 4
  %stack.sub.5093 = sub i32 %local.check.owner.end.5088, %local.check.offset.5085
  %descriptor.owner.inside.5091 = icmp ule i32 %local.check.owner.end.5088, %context.value.5090
  %descriptor.offset.inside.5092 = icmp ule i32 %local.check.offset.5085, %local.check.owner.end.5088
  %descriptor.extent.inside.5094 = icmp ule i32 %local.check.extent.5086, %stack.sub.5093
  %descriptor.payload.inside.5095 = icmp ule i32 %local.check.payload.5087, %local.check.extent.5086
  %descriptor.owner.offset.valid.5096 = and i1 %descriptor.owner.inside.5091, %descriptor.offset.inside.5092
  %descriptor.range.inside.5098 = and i1 %descriptor.owner.offset.valid.5096, %descriptor.extent.inside.5094
  %descriptor.range.valid.5097 = and i1 %descriptor.range.inside.5098, %descriptor.payload.inside.5095
  br i1 %descriptor.range.valid.5097, label %descriptor.valid.5099, label %descriptor.invalid.5100
descriptor.invalid.5100:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5099:
  %descriptor.initialized.status.5101 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5085, i32 %local.check.extent.5086)
  %helper.ok.5102 = icmp eq i32 %descriptor.initialized.status.5101, 0
  br i1 %helper.ok.5102, label %helper.continue.5103, label %frame.failure.0
helper.continue.5103:
  br label %local.descriptor.checked.5084
local.descriptor.inactive.5083:
  br label %local.descriptor.checked.5084
local.descriptor.checked.5084:
  %local.is.active.5104 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.5104, label %local.descriptor.active.5105, label %local.descriptor.inactive.5106
local.descriptor.active.5105:
  %local.check.offset.5108 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.5109 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.5110 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.5111 = load i32, ptr %local.owner.end.42, align 4
  %context.field.5112 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5113 = load i32, ptr %context.field.5112, align 4
  %stack.sub.5116 = sub i32 %local.check.owner.end.5111, %local.check.offset.5108
  %descriptor.owner.inside.5114 = icmp ule i32 %local.check.owner.end.5111, %context.value.5113
  %descriptor.offset.inside.5115 = icmp ule i32 %local.check.offset.5108, %local.check.owner.end.5111
  %descriptor.extent.inside.5117 = icmp ule i32 %local.check.extent.5109, %stack.sub.5116
  %descriptor.payload.inside.5118 = icmp ule i32 %local.check.payload.5110, %local.check.extent.5109
  %descriptor.owner.offset.valid.5119 = and i1 %descriptor.owner.inside.5114, %descriptor.offset.inside.5115
  %descriptor.range.inside.5121 = and i1 %descriptor.owner.offset.valid.5119, %descriptor.extent.inside.5117
  %descriptor.range.valid.5120 = and i1 %descriptor.range.inside.5121, %descriptor.payload.inside.5118
  br i1 %descriptor.range.valid.5120, label %descriptor.valid.5122, label %descriptor.invalid.5123
descriptor.invalid.5123:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5122:
  %descriptor.initialized.status.5124 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5108, i32 %local.check.extent.5109)
  %helper.ok.5125 = icmp eq i32 %descriptor.initialized.status.5124, 0
  br i1 %helper.ok.5125, label %helper.continue.5126, label %frame.failure.0
helper.continue.5126:
  br label %local.descriptor.checked.5107
local.descriptor.inactive.5106:
  br label %local.descriptor.checked.5107
local.descriptor.checked.5107:
  %step.status.5127 = call i32 @al_owning_charge_step(ptr %ctx, i32 75)
  %helper.ok.5128 = icmp eq i32 %step.status.5127, 0
  br i1 %helper.ok.5128, label %helper.continue.5129, label %frame.failure.0
helper.continue.5129:
  store i1 true, ptr %local.active.38, align 1
  store i32 %local.resolved.offset.4924, ptr %local.offset.39, align 4
  store i32 %local.resolved.extent.4925, ptr %local.extent.40, align 4
  store i32 %local.resolved.payload.4926, ptr %local.payload.41, align 4
  store i32 %local.resolved.owner.end.4927, ptr %local.owner.end.42, align 4
  store i32 6, ptr %local.type.43, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %local.resolved.offset.4924, i32 20, i32 %local.resolved.payload.4926, i32 %local.resolved.owner.end.4927, i32 %local.resolved.extent.4925)
  %context.field.5130 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5131 = load i32, ptr %context.field.5130, align 4
  %runtime.ok.5132 = icmp eq i32 %context.value.5131, 0
  br i1 %runtime.ok.5132, label %runtime.continue.5133, label %frame.failure.0
runtime.continue.5133:
  %local.is.active.5134 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.5134, label %local.descriptor.active.5135, label %local.descriptor.inactive.5136
local.descriptor.active.5135:
  %local.check.offset.5138 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.5139 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.5140 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.5141 = load i32, ptr %local.owner.end.6, align 4
  %context.field.5142 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5143 = load i32, ptr %context.field.5142, align 4
  %stack.sub.5146 = sub i32 %local.check.owner.end.5141, %local.check.offset.5138
  %descriptor.owner.inside.5144 = icmp ule i32 %local.check.owner.end.5141, %context.value.5143
  %descriptor.offset.inside.5145 = icmp ule i32 %local.check.offset.5138, %local.check.owner.end.5141
  %descriptor.extent.inside.5147 = icmp ule i32 %local.check.extent.5139, %stack.sub.5146
  %descriptor.payload.inside.5148 = icmp ule i32 %local.check.payload.5140, %local.check.extent.5139
  %descriptor.owner.offset.valid.5149 = and i1 %descriptor.owner.inside.5144, %descriptor.offset.inside.5145
  %descriptor.range.inside.5151 = and i1 %descriptor.owner.offset.valid.5149, %descriptor.extent.inside.5147
  %descriptor.range.valid.5150 = and i1 %descriptor.range.inside.5151, %descriptor.payload.inside.5148
  br i1 %descriptor.range.valid.5150, label %descriptor.valid.5152, label %descriptor.invalid.5153
descriptor.invalid.5153:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5152:
  %descriptor.initialized.status.5154 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5138, i32 %local.check.extent.5139)
  %helper.ok.5155 = icmp eq i32 %descriptor.initialized.status.5154, 0
  br i1 %helper.ok.5155, label %helper.continue.5156, label %frame.failure.0
helper.continue.5156:
  br label %local.descriptor.checked.5137
local.descriptor.inactive.5136:
  br label %local.descriptor.checked.5137
local.descriptor.checked.5137:
  %local.is.active.5157 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.5157, label %local.descriptor.active.5158, label %local.descriptor.inactive.5159
local.descriptor.active.5158:
  %local.check.offset.5161 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.5162 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.5163 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.5164 = load i32, ptr %local.owner.end.12, align 4
  %context.field.5165 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5166 = load i32, ptr %context.field.5165, align 4
  %stack.sub.5169 = sub i32 %local.check.owner.end.5164, %local.check.offset.5161
  %descriptor.owner.inside.5167 = icmp ule i32 %local.check.owner.end.5164, %context.value.5166
  %descriptor.offset.inside.5168 = icmp ule i32 %local.check.offset.5161, %local.check.owner.end.5164
  %descriptor.extent.inside.5170 = icmp ule i32 %local.check.extent.5162, %stack.sub.5169
  %descriptor.payload.inside.5171 = icmp ule i32 %local.check.payload.5163, %local.check.extent.5162
  %descriptor.owner.offset.valid.5172 = and i1 %descriptor.owner.inside.5167, %descriptor.offset.inside.5168
  %descriptor.range.inside.5174 = and i1 %descriptor.owner.offset.valid.5172, %descriptor.extent.inside.5170
  %descriptor.range.valid.5173 = and i1 %descriptor.range.inside.5174, %descriptor.payload.inside.5171
  br i1 %descriptor.range.valid.5173, label %descriptor.valid.5175, label %descriptor.invalid.5176
descriptor.invalid.5176:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5175:
  %descriptor.initialized.status.5177 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5161, i32 %local.check.extent.5162)
  %helper.ok.5178 = icmp eq i32 %descriptor.initialized.status.5177, 0
  br i1 %helper.ok.5178, label %helper.continue.5179, label %frame.failure.0
helper.continue.5179:
  br label %local.descriptor.checked.5160
local.descriptor.inactive.5159:
  br label %local.descriptor.checked.5160
local.descriptor.checked.5160:
  %local.is.active.5180 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.5180, label %local.descriptor.active.5181, label %local.descriptor.inactive.5182
local.descriptor.active.5181:
  %local.check.offset.5184 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.5185 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.5186 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.5187 = load i32, ptr %local.owner.end.18, align 4
  %context.field.5188 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5189 = load i32, ptr %context.field.5188, align 4
  %stack.sub.5192 = sub i32 %local.check.owner.end.5187, %local.check.offset.5184
  %descriptor.owner.inside.5190 = icmp ule i32 %local.check.owner.end.5187, %context.value.5189
  %descriptor.offset.inside.5191 = icmp ule i32 %local.check.offset.5184, %local.check.owner.end.5187
  %descriptor.extent.inside.5193 = icmp ule i32 %local.check.extent.5185, %stack.sub.5192
  %descriptor.payload.inside.5194 = icmp ule i32 %local.check.payload.5186, %local.check.extent.5185
  %descriptor.owner.offset.valid.5195 = and i1 %descriptor.owner.inside.5190, %descriptor.offset.inside.5191
  %descriptor.range.inside.5197 = and i1 %descriptor.owner.offset.valid.5195, %descriptor.extent.inside.5193
  %descriptor.range.valid.5196 = and i1 %descriptor.range.inside.5197, %descriptor.payload.inside.5194
  br i1 %descriptor.range.valid.5196, label %descriptor.valid.5198, label %descriptor.invalid.5199
descriptor.invalid.5199:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5198:
  %descriptor.initialized.status.5200 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5184, i32 %local.check.extent.5185)
  %helper.ok.5201 = icmp eq i32 %descriptor.initialized.status.5200, 0
  br i1 %helper.ok.5201, label %helper.continue.5202, label %frame.failure.0
helper.continue.5202:
  br label %local.descriptor.checked.5183
local.descriptor.inactive.5182:
  br label %local.descriptor.checked.5183
local.descriptor.checked.5183:
  %local.is.active.5203 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.5203, label %local.descriptor.active.5204, label %local.descriptor.inactive.5205
local.descriptor.active.5204:
  %local.check.offset.5207 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.5208 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.5209 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.5210 = load i32, ptr %local.owner.end.24, align 4
  %context.field.5211 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5212 = load i32, ptr %context.field.5211, align 4
  %stack.sub.5215 = sub i32 %local.check.owner.end.5210, %local.check.offset.5207
  %descriptor.owner.inside.5213 = icmp ule i32 %local.check.owner.end.5210, %context.value.5212
  %descriptor.offset.inside.5214 = icmp ule i32 %local.check.offset.5207, %local.check.owner.end.5210
  %descriptor.extent.inside.5216 = icmp ule i32 %local.check.extent.5208, %stack.sub.5215
  %descriptor.payload.inside.5217 = icmp ule i32 %local.check.payload.5209, %local.check.extent.5208
  %descriptor.owner.offset.valid.5218 = and i1 %descriptor.owner.inside.5213, %descriptor.offset.inside.5214
  %descriptor.range.inside.5220 = and i1 %descriptor.owner.offset.valid.5218, %descriptor.extent.inside.5216
  %descriptor.range.valid.5219 = and i1 %descriptor.range.inside.5220, %descriptor.payload.inside.5217
  br i1 %descriptor.range.valid.5219, label %descriptor.valid.5221, label %descriptor.invalid.5222
descriptor.invalid.5222:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5221:
  %descriptor.initialized.status.5223 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5207, i32 %local.check.extent.5208)
  %helper.ok.5224 = icmp eq i32 %descriptor.initialized.status.5223, 0
  br i1 %helper.ok.5224, label %helper.continue.5225, label %frame.failure.0
helper.continue.5225:
  br label %local.descriptor.checked.5206
local.descriptor.inactive.5205:
  br label %local.descriptor.checked.5206
local.descriptor.checked.5206:
  %local.is.active.5226 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.5226, label %local.descriptor.active.5227, label %local.descriptor.inactive.5228
local.descriptor.active.5227:
  %local.check.offset.5230 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.5231 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.5232 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.5233 = load i32, ptr %local.owner.end.30, align 4
  %context.field.5234 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5235 = load i32, ptr %context.field.5234, align 4
  %stack.sub.5238 = sub i32 %local.check.owner.end.5233, %local.check.offset.5230
  %descriptor.owner.inside.5236 = icmp ule i32 %local.check.owner.end.5233, %context.value.5235
  %descriptor.offset.inside.5237 = icmp ule i32 %local.check.offset.5230, %local.check.owner.end.5233
  %descriptor.extent.inside.5239 = icmp ule i32 %local.check.extent.5231, %stack.sub.5238
  %descriptor.payload.inside.5240 = icmp ule i32 %local.check.payload.5232, %local.check.extent.5231
  %descriptor.owner.offset.valid.5241 = and i1 %descriptor.owner.inside.5236, %descriptor.offset.inside.5237
  %descriptor.range.inside.5243 = and i1 %descriptor.owner.offset.valid.5241, %descriptor.extent.inside.5239
  %descriptor.range.valid.5242 = and i1 %descriptor.range.inside.5243, %descriptor.payload.inside.5240
  br i1 %descriptor.range.valid.5242, label %descriptor.valid.5244, label %descriptor.invalid.5245
descriptor.invalid.5245:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5244:
  %descriptor.initialized.status.5246 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5230, i32 %local.check.extent.5231)
  %helper.ok.5247 = icmp eq i32 %descriptor.initialized.status.5246, 0
  br i1 %helper.ok.5247, label %helper.continue.5248, label %frame.failure.0
helper.continue.5248:
  br label %local.descriptor.checked.5229
local.descriptor.inactive.5228:
  br label %local.descriptor.checked.5229
local.descriptor.checked.5229:
  %local.is.active.5249 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.5249, label %local.descriptor.active.5250, label %local.descriptor.inactive.5251
local.descriptor.active.5250:
  %local.check.offset.5253 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.5254 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.5255 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.5256 = load i32, ptr %local.owner.end.36, align 4
  %context.field.5257 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5258 = load i32, ptr %context.field.5257, align 4
  %stack.sub.5261 = sub i32 %local.check.owner.end.5256, %local.check.offset.5253
  %descriptor.owner.inside.5259 = icmp ule i32 %local.check.owner.end.5256, %context.value.5258
  %descriptor.offset.inside.5260 = icmp ule i32 %local.check.offset.5253, %local.check.owner.end.5256
  %descriptor.extent.inside.5262 = icmp ule i32 %local.check.extent.5254, %stack.sub.5261
  %descriptor.payload.inside.5263 = icmp ule i32 %local.check.payload.5255, %local.check.extent.5254
  %descriptor.owner.offset.valid.5264 = and i1 %descriptor.owner.inside.5259, %descriptor.offset.inside.5260
  %descriptor.range.inside.5266 = and i1 %descriptor.owner.offset.valid.5264, %descriptor.extent.inside.5262
  %descriptor.range.valid.5265 = and i1 %descriptor.range.inside.5266, %descriptor.payload.inside.5263
  br i1 %descriptor.range.valid.5265, label %descriptor.valid.5267, label %descriptor.invalid.5268
descriptor.invalid.5268:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5267:
  %descriptor.initialized.status.5269 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5253, i32 %local.check.extent.5254)
  %helper.ok.5270 = icmp eq i32 %descriptor.initialized.status.5269, 0
  br i1 %helper.ok.5270, label %helper.continue.5271, label %frame.failure.0
helper.continue.5271:
  br label %local.descriptor.checked.5252
local.descriptor.inactive.5251:
  br label %local.descriptor.checked.5252
local.descriptor.checked.5252:
  %local.is.active.5272 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.5272, label %local.descriptor.active.5273, label %local.descriptor.inactive.5274
local.descriptor.active.5273:
  %local.check.offset.5276 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.5277 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.5278 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.5279 = load i32, ptr %local.owner.end.42, align 4
  %context.field.5280 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5281 = load i32, ptr %context.field.5280, align 4
  %stack.sub.5284 = sub i32 %local.check.owner.end.5279, %local.check.offset.5276
  %descriptor.owner.inside.5282 = icmp ule i32 %local.check.owner.end.5279, %context.value.5281
  %descriptor.offset.inside.5283 = icmp ule i32 %local.check.offset.5276, %local.check.owner.end.5279
  %descriptor.extent.inside.5285 = icmp ule i32 %local.check.extent.5277, %stack.sub.5284
  %descriptor.payload.inside.5286 = icmp ule i32 %local.check.payload.5278, %local.check.extent.5277
  %descriptor.owner.offset.valid.5287 = and i1 %descriptor.owner.inside.5282, %descriptor.offset.inside.5283
  %descriptor.range.inside.5289 = and i1 %descriptor.owner.offset.valid.5287, %descriptor.extent.inside.5285
  %descriptor.range.valid.5288 = and i1 %descriptor.range.inside.5289, %descriptor.payload.inside.5286
  br i1 %descriptor.range.valid.5288, label %descriptor.valid.5290, label %descriptor.invalid.5291
descriptor.invalid.5291:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5290:
  %descriptor.initialized.status.5292 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5276, i32 %local.check.extent.5277)
  %helper.ok.5293 = icmp eq i32 %descriptor.initialized.status.5292, 0
  br i1 %helper.ok.5293, label %helper.continue.5294, label %frame.failure.0
helper.continue.5294:
  br label %local.descriptor.checked.5275
local.descriptor.inactive.5274:
  br label %local.descriptor.checked.5275
local.descriptor.checked.5275:
  %step.status.5295 = call i32 @al_owning_charge_step(ptr %ctx, i32 76)
  %helper.ok.5296 = icmp eq i32 %step.status.5295, 0
  br i1 %helper.ok.5296, label %helper.continue.5297, label %frame.failure.0
helper.continue.5297:
  %local.resolved.offset.5298 = load i32, ptr %local.offset.39, align 4
  %local.resolved.extent.5299 = load i32, ptr %local.extent.40, align 4
  %local.resolved.payload.5300 = load i32, ptr %local.payload.41, align 4
  %local.resolved.owner.end.5301 = load i32, ptr %local.owner.end.42, align 4
  %context.field.5302 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5303 = load i32, ptr %context.field.5302, align 4
  %stack.sub.5306 = sub i32 %local.resolved.owner.end.5301, %local.resolved.offset.5298
  %descriptor.owner.inside.5304 = icmp ule i32 %local.resolved.owner.end.5301, %context.value.5303
  %descriptor.offset.inside.5305 = icmp ule i32 %local.resolved.offset.5298, %local.resolved.owner.end.5301
  %descriptor.extent.inside.5307 = icmp ule i32 %local.resolved.extent.5299, %stack.sub.5306
  %descriptor.payload.inside.5308 = icmp ule i32 %local.resolved.payload.5300, %local.resolved.extent.5299
  %descriptor.owner.offset.valid.5309 = and i1 %descriptor.owner.inside.5304, %descriptor.offset.inside.5305
  %descriptor.range.inside.5311 = and i1 %descriptor.owner.offset.valid.5309, %descriptor.extent.inside.5307
  %descriptor.range.valid.5310 = and i1 %descriptor.range.inside.5311, %descriptor.payload.inside.5308
  %descriptor.type.valid.5312 = icmp eq i32 6, 6
  %descriptor.valid.5313 = and i1 %descriptor.range.valid.5310, %descriptor.type.valid.5312
  br i1 %descriptor.valid.5313, label %descriptor.valid.5314, label %descriptor.invalid.5315
descriptor.invalid.5315:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5314:
  %descriptor.initialized.status.5316 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.5298, i32 %local.resolved.extent.5299)
  %helper.ok.5317 = icmp eq i32 %descriptor.initialized.status.5316, 0
  br i1 %helper.ok.5317, label %helper.continue.5318, label %frame.failure.0
helper.continue.5318:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %local.resolved.offset.5298, i32 20, i32 %local.resolved.payload.5300, i32 %local.resolved.owner.end.5301, i32 %local.resolved.extent.5299)
  %context.field.5319 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5320 = load i32, ptr %context.field.5319, align 4
  %runtime.ok.5321 = icmp eq i32 %context.value.5320, 0
  br i1 %runtime.ok.5321, label %runtime.continue.5322, label %frame.failure.0
runtime.continue.5322:
  %context.field.5323 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5324 = load i32, ptr %context.field.5323, align 4
  %stack.sub.5327 = sub i32 %local.resolved.owner.end.5301, %local.resolved.offset.5298
  %descriptor.owner.inside.5325 = icmp ule i32 %local.resolved.owner.end.5301, %context.value.5324
  %descriptor.offset.inside.5326 = icmp ule i32 %local.resolved.offset.5298, %local.resolved.owner.end.5301
  %descriptor.extent.inside.5328 = icmp ule i32 %local.resolved.extent.5299, %stack.sub.5327
  %descriptor.payload.inside.5329 = icmp ule i32 %local.resolved.payload.5300, %local.resolved.extent.5299
  %descriptor.owner.offset.valid.5330 = and i1 %descriptor.owner.inside.5325, %descriptor.offset.inside.5326
  %descriptor.range.inside.5332 = and i1 %descriptor.owner.offset.valid.5330, %descriptor.extent.inside.5328
  %descriptor.range.valid.5331 = and i1 %descriptor.range.inside.5332, %descriptor.payload.inside.5329
  %descriptor.type.valid.5333 = icmp eq i32 6, 6
  %descriptor.valid.5334 = and i1 %descriptor.range.valid.5331, %descriptor.type.valid.5333
  br i1 %descriptor.valid.5334, label %descriptor.valid.5335, label %descriptor.invalid.5336
descriptor.invalid.5336:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5335:
  %descriptor.initialized.status.5337 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.5298, i32 %local.resolved.extent.5299)
  %helper.ok.5338 = icmp eq i32 %descriptor.initialized.status.5337, 0
  br i1 %helper.ok.5338, label %helper.continue.5339, label %frame.failure.0
helper.continue.5339:
  %local.is.active.5340 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.5340, label %local.descriptor.active.5341, label %local.descriptor.inactive.5342
local.descriptor.active.5341:
  %local.check.offset.5344 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.5345 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.5346 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.5347 = load i32, ptr %local.owner.end.6, align 4
  %context.field.5348 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5349 = load i32, ptr %context.field.5348, align 4
  %stack.sub.5352 = sub i32 %local.check.owner.end.5347, %local.check.offset.5344
  %descriptor.owner.inside.5350 = icmp ule i32 %local.check.owner.end.5347, %context.value.5349
  %descriptor.offset.inside.5351 = icmp ule i32 %local.check.offset.5344, %local.check.owner.end.5347
  %descriptor.extent.inside.5353 = icmp ule i32 %local.check.extent.5345, %stack.sub.5352
  %descriptor.payload.inside.5354 = icmp ule i32 %local.check.payload.5346, %local.check.extent.5345
  %descriptor.owner.offset.valid.5355 = and i1 %descriptor.owner.inside.5350, %descriptor.offset.inside.5351
  %descriptor.range.inside.5357 = and i1 %descriptor.owner.offset.valid.5355, %descriptor.extent.inside.5353
  %descriptor.range.valid.5356 = and i1 %descriptor.range.inside.5357, %descriptor.payload.inside.5354
  br i1 %descriptor.range.valid.5356, label %descriptor.valid.5358, label %descriptor.invalid.5359
descriptor.invalid.5359:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5358:
  %descriptor.initialized.status.5360 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5344, i32 %local.check.extent.5345)
  %helper.ok.5361 = icmp eq i32 %descriptor.initialized.status.5360, 0
  br i1 %helper.ok.5361, label %helper.continue.5362, label %frame.failure.0
helper.continue.5362:
  br label %local.descriptor.checked.5343
local.descriptor.inactive.5342:
  br label %local.descriptor.checked.5343
local.descriptor.checked.5343:
  %local.is.active.5363 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.5363, label %local.descriptor.active.5364, label %local.descriptor.inactive.5365
local.descriptor.active.5364:
  %local.check.offset.5367 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.5368 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.5369 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.5370 = load i32, ptr %local.owner.end.12, align 4
  %context.field.5371 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5372 = load i32, ptr %context.field.5371, align 4
  %stack.sub.5375 = sub i32 %local.check.owner.end.5370, %local.check.offset.5367
  %descriptor.owner.inside.5373 = icmp ule i32 %local.check.owner.end.5370, %context.value.5372
  %descriptor.offset.inside.5374 = icmp ule i32 %local.check.offset.5367, %local.check.owner.end.5370
  %descriptor.extent.inside.5376 = icmp ule i32 %local.check.extent.5368, %stack.sub.5375
  %descriptor.payload.inside.5377 = icmp ule i32 %local.check.payload.5369, %local.check.extent.5368
  %descriptor.owner.offset.valid.5378 = and i1 %descriptor.owner.inside.5373, %descriptor.offset.inside.5374
  %descriptor.range.inside.5380 = and i1 %descriptor.owner.offset.valid.5378, %descriptor.extent.inside.5376
  %descriptor.range.valid.5379 = and i1 %descriptor.range.inside.5380, %descriptor.payload.inside.5377
  br i1 %descriptor.range.valid.5379, label %descriptor.valid.5381, label %descriptor.invalid.5382
descriptor.invalid.5382:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5381:
  %descriptor.initialized.status.5383 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5367, i32 %local.check.extent.5368)
  %helper.ok.5384 = icmp eq i32 %descriptor.initialized.status.5383, 0
  br i1 %helper.ok.5384, label %helper.continue.5385, label %frame.failure.0
helper.continue.5385:
  br label %local.descriptor.checked.5366
local.descriptor.inactive.5365:
  br label %local.descriptor.checked.5366
local.descriptor.checked.5366:
  %local.is.active.5386 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.5386, label %local.descriptor.active.5387, label %local.descriptor.inactive.5388
local.descriptor.active.5387:
  %local.check.offset.5390 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.5391 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.5392 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.5393 = load i32, ptr %local.owner.end.18, align 4
  %context.field.5394 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5395 = load i32, ptr %context.field.5394, align 4
  %stack.sub.5398 = sub i32 %local.check.owner.end.5393, %local.check.offset.5390
  %descriptor.owner.inside.5396 = icmp ule i32 %local.check.owner.end.5393, %context.value.5395
  %descriptor.offset.inside.5397 = icmp ule i32 %local.check.offset.5390, %local.check.owner.end.5393
  %descriptor.extent.inside.5399 = icmp ule i32 %local.check.extent.5391, %stack.sub.5398
  %descriptor.payload.inside.5400 = icmp ule i32 %local.check.payload.5392, %local.check.extent.5391
  %descriptor.owner.offset.valid.5401 = and i1 %descriptor.owner.inside.5396, %descriptor.offset.inside.5397
  %descriptor.range.inside.5403 = and i1 %descriptor.owner.offset.valid.5401, %descriptor.extent.inside.5399
  %descriptor.range.valid.5402 = and i1 %descriptor.range.inside.5403, %descriptor.payload.inside.5400
  br i1 %descriptor.range.valid.5402, label %descriptor.valid.5404, label %descriptor.invalid.5405
descriptor.invalid.5405:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5404:
  %descriptor.initialized.status.5406 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5390, i32 %local.check.extent.5391)
  %helper.ok.5407 = icmp eq i32 %descriptor.initialized.status.5406, 0
  br i1 %helper.ok.5407, label %helper.continue.5408, label %frame.failure.0
helper.continue.5408:
  br label %local.descriptor.checked.5389
local.descriptor.inactive.5388:
  br label %local.descriptor.checked.5389
local.descriptor.checked.5389:
  %local.is.active.5409 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.5409, label %local.descriptor.active.5410, label %local.descriptor.inactive.5411
local.descriptor.active.5410:
  %local.check.offset.5413 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.5414 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.5415 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.5416 = load i32, ptr %local.owner.end.24, align 4
  %context.field.5417 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5418 = load i32, ptr %context.field.5417, align 4
  %stack.sub.5421 = sub i32 %local.check.owner.end.5416, %local.check.offset.5413
  %descriptor.owner.inside.5419 = icmp ule i32 %local.check.owner.end.5416, %context.value.5418
  %descriptor.offset.inside.5420 = icmp ule i32 %local.check.offset.5413, %local.check.owner.end.5416
  %descriptor.extent.inside.5422 = icmp ule i32 %local.check.extent.5414, %stack.sub.5421
  %descriptor.payload.inside.5423 = icmp ule i32 %local.check.payload.5415, %local.check.extent.5414
  %descriptor.owner.offset.valid.5424 = and i1 %descriptor.owner.inside.5419, %descriptor.offset.inside.5420
  %descriptor.range.inside.5426 = and i1 %descriptor.owner.offset.valid.5424, %descriptor.extent.inside.5422
  %descriptor.range.valid.5425 = and i1 %descriptor.range.inside.5426, %descriptor.payload.inside.5423
  br i1 %descriptor.range.valid.5425, label %descriptor.valid.5427, label %descriptor.invalid.5428
descriptor.invalid.5428:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5427:
  %descriptor.initialized.status.5429 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5413, i32 %local.check.extent.5414)
  %helper.ok.5430 = icmp eq i32 %descriptor.initialized.status.5429, 0
  br i1 %helper.ok.5430, label %helper.continue.5431, label %frame.failure.0
helper.continue.5431:
  br label %local.descriptor.checked.5412
local.descriptor.inactive.5411:
  br label %local.descriptor.checked.5412
local.descriptor.checked.5412:
  %local.is.active.5432 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.5432, label %local.descriptor.active.5433, label %local.descriptor.inactive.5434
local.descriptor.active.5433:
  %local.check.offset.5436 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.5437 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.5438 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.5439 = load i32, ptr %local.owner.end.30, align 4
  %context.field.5440 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5441 = load i32, ptr %context.field.5440, align 4
  %stack.sub.5444 = sub i32 %local.check.owner.end.5439, %local.check.offset.5436
  %descriptor.owner.inside.5442 = icmp ule i32 %local.check.owner.end.5439, %context.value.5441
  %descriptor.offset.inside.5443 = icmp ule i32 %local.check.offset.5436, %local.check.owner.end.5439
  %descriptor.extent.inside.5445 = icmp ule i32 %local.check.extent.5437, %stack.sub.5444
  %descriptor.payload.inside.5446 = icmp ule i32 %local.check.payload.5438, %local.check.extent.5437
  %descriptor.owner.offset.valid.5447 = and i1 %descriptor.owner.inside.5442, %descriptor.offset.inside.5443
  %descriptor.range.inside.5449 = and i1 %descriptor.owner.offset.valid.5447, %descriptor.extent.inside.5445
  %descriptor.range.valid.5448 = and i1 %descriptor.range.inside.5449, %descriptor.payload.inside.5446
  br i1 %descriptor.range.valid.5448, label %descriptor.valid.5450, label %descriptor.invalid.5451
descriptor.invalid.5451:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5450:
  %descriptor.initialized.status.5452 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5436, i32 %local.check.extent.5437)
  %helper.ok.5453 = icmp eq i32 %descriptor.initialized.status.5452, 0
  br i1 %helper.ok.5453, label %helper.continue.5454, label %frame.failure.0
helper.continue.5454:
  br label %local.descriptor.checked.5435
local.descriptor.inactive.5434:
  br label %local.descriptor.checked.5435
local.descriptor.checked.5435:
  %local.is.active.5455 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.5455, label %local.descriptor.active.5456, label %local.descriptor.inactive.5457
local.descriptor.active.5456:
  %local.check.offset.5459 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.5460 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.5461 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.5462 = load i32, ptr %local.owner.end.36, align 4
  %context.field.5463 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5464 = load i32, ptr %context.field.5463, align 4
  %stack.sub.5467 = sub i32 %local.check.owner.end.5462, %local.check.offset.5459
  %descriptor.owner.inside.5465 = icmp ule i32 %local.check.owner.end.5462, %context.value.5464
  %descriptor.offset.inside.5466 = icmp ule i32 %local.check.offset.5459, %local.check.owner.end.5462
  %descriptor.extent.inside.5468 = icmp ule i32 %local.check.extent.5460, %stack.sub.5467
  %descriptor.payload.inside.5469 = icmp ule i32 %local.check.payload.5461, %local.check.extent.5460
  %descriptor.owner.offset.valid.5470 = and i1 %descriptor.owner.inside.5465, %descriptor.offset.inside.5466
  %descriptor.range.inside.5472 = and i1 %descriptor.owner.offset.valid.5470, %descriptor.extent.inside.5468
  %descriptor.range.valid.5471 = and i1 %descriptor.range.inside.5472, %descriptor.payload.inside.5469
  br i1 %descriptor.range.valid.5471, label %descriptor.valid.5473, label %descriptor.invalid.5474
descriptor.invalid.5474:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5473:
  %descriptor.initialized.status.5475 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5459, i32 %local.check.extent.5460)
  %helper.ok.5476 = icmp eq i32 %descriptor.initialized.status.5475, 0
  br i1 %helper.ok.5476, label %helper.continue.5477, label %frame.failure.0
helper.continue.5477:
  br label %local.descriptor.checked.5458
local.descriptor.inactive.5457:
  br label %local.descriptor.checked.5458
local.descriptor.checked.5458:
  %local.is.active.5478 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.5478, label %local.descriptor.active.5479, label %local.descriptor.inactive.5480
local.descriptor.active.5479:
  %local.check.offset.5482 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.5483 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.5484 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.5485 = load i32, ptr %local.owner.end.42, align 4
  %context.field.5486 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5487 = load i32, ptr %context.field.5486, align 4
  %stack.sub.5490 = sub i32 %local.check.owner.end.5485, %local.check.offset.5482
  %descriptor.owner.inside.5488 = icmp ule i32 %local.check.owner.end.5485, %context.value.5487
  %descriptor.offset.inside.5489 = icmp ule i32 %local.check.offset.5482, %local.check.owner.end.5485
  %descriptor.extent.inside.5491 = icmp ule i32 %local.check.extent.5483, %stack.sub.5490
  %descriptor.payload.inside.5492 = icmp ule i32 %local.check.payload.5484, %local.check.extent.5483
  %descriptor.owner.offset.valid.5493 = and i1 %descriptor.owner.inside.5488, %descriptor.offset.inside.5489
  %descriptor.range.inside.5495 = and i1 %descriptor.owner.offset.valid.5493, %descriptor.extent.inside.5491
  %descriptor.range.valid.5494 = and i1 %descriptor.range.inside.5495, %descriptor.payload.inside.5492
  br i1 %descriptor.range.valid.5494, label %descriptor.valid.5496, label %descriptor.invalid.5497
descriptor.invalid.5497:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5496:
  %descriptor.initialized.status.5498 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5482, i32 %local.check.extent.5483)
  %helper.ok.5499 = icmp eq i32 %descriptor.initialized.status.5498, 0
  br i1 %helper.ok.5499, label %helper.continue.5500, label %frame.failure.0
helper.continue.5500:
  br label %local.descriptor.checked.5481
local.descriptor.inactive.5480:
  br label %local.descriptor.checked.5481
local.descriptor.checked.5481:
  %step.status.5501 = call i32 @al_owning_charge_step(ptr %ctx, i32 77)
  %helper.ok.5502 = icmp eq i32 %step.status.5501, 0
  br i1 %helper.ok.5502, label %helper.continue.5503, label %frame.failure.0
helper.continue.5503:
  %context.field.5504 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.5505 = load i32, ptr %context.field.5504, align 4
  %inline.target.depth.within.interpreter.limit.5506 = icmp ule i32 %context.value.5505, 65
  br i1 %inline.target.depth.within.interpreter.limit.5506, label %inline.target.depth.ok.5507, label %inline.target.depth.invalid.5508
inline.target.depth.invalid.5508:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 78, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.5507:
  %stack.offset.5509 = add i32 0, %local.resolved.payload.5300
  %stack.offset.5510 = add i32 0, %local.resolved.extent.5299
  %context.field.5511 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5512 = load i32, ptr %context.field.5511, align 4
  %stack.offset.5513 = add i32 %context.value.5512, %stack.offset.5510
  %reserve.status.5514 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.5513, i32 79)
  %reserve.ok.5515 = icmp eq i32 %reserve.status.5514, 0
  br i1 %reserve.ok.5515, label %reserve.continue.5516, label %frame.failure.0
reserve.continue.5516:
  %stack.offset.5517 = add i32 %context.value.5512, 0
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.5517, i32 %local.resolved.offset.5298, i32 %local.resolved.extent.5299, i32 %local.resolved.payload.5300, i32 6, i32 6)
  %context.field.5518 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5519 = load i32, ptr %context.field.5518, align 4
  %runtime.ok.5520 = icmp eq i32 %context.value.5519, 0
  br i1 %runtime.ok.5520, label %runtime.continue.5521, label %frame.failure.0
runtime.continue.5521:
  %stack.offset.5522 = add i32 0, %local.resolved.extent.5299
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 5, i32 %context.value.5512, i32 %stack.offset.5510, i32 %stack.offset.5509, i32 0, i32 0)
  %context.field.5523 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5524 = load i32, ptr %context.field.5523, align 4
  %runtime.ok.5525 = icmp eq i32 %context.value.5524, 0
  br i1 %runtime.ok.5525, label %runtime.continue.5526, label %frame.failure.0
runtime.continue.5526:
  %context.field.5527 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5528 = load i32, ptr %context.field.5527, align 4
  %stack.sub.5531 = sub i32 %stack.offset.5513, %context.value.5512
  %descriptor.owner.inside.5529 = icmp ule i32 %stack.offset.5513, %context.value.5528
  %descriptor.offset.inside.5530 = icmp ule i32 %context.value.5512, %stack.offset.5513
  %descriptor.extent.inside.5532 = icmp ule i32 %stack.offset.5510, %stack.sub.5531
  %descriptor.payload.inside.5533 = icmp ule i32 %stack.offset.5509, %stack.offset.5510
  %descriptor.owner.offset.valid.5534 = and i1 %descriptor.owner.inside.5529, %descriptor.offset.inside.5530
  %descriptor.range.inside.5536 = and i1 %descriptor.owner.offset.valid.5534, %descriptor.extent.inside.5532
  %descriptor.range.valid.5535 = and i1 %descriptor.range.inside.5536, %descriptor.payload.inside.5533
  %descriptor.type.valid.5537 = icmp eq i32 5, 5
  %descriptor.valid.5538 = and i1 %descriptor.range.valid.5535, %descriptor.type.valid.5537
  br i1 %descriptor.valid.5538, label %descriptor.valid.5539, label %descriptor.invalid.5540
descriptor.invalid.5540:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5539:
  %descriptor.initialized.status.5541 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.5512, i32 %stack.offset.5510)
  %helper.ok.5542 = icmp eq i32 %descriptor.initialized.status.5541, 0
  br i1 %helper.ok.5542, label %helper.continue.5543, label %frame.failure.0
helper.continue.5543:
  %local.is.active.5544 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.5544, label %local.descriptor.active.5545, label %local.descriptor.inactive.5546
local.descriptor.active.5545:
  %local.check.offset.5548 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.5549 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.5550 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.5551 = load i32, ptr %local.owner.end.6, align 4
  %context.field.5552 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5553 = load i32, ptr %context.field.5552, align 4
  %stack.sub.5556 = sub i32 %local.check.owner.end.5551, %local.check.offset.5548
  %descriptor.owner.inside.5554 = icmp ule i32 %local.check.owner.end.5551, %context.value.5553
  %descriptor.offset.inside.5555 = icmp ule i32 %local.check.offset.5548, %local.check.owner.end.5551
  %descriptor.extent.inside.5557 = icmp ule i32 %local.check.extent.5549, %stack.sub.5556
  %descriptor.payload.inside.5558 = icmp ule i32 %local.check.payload.5550, %local.check.extent.5549
  %descriptor.owner.offset.valid.5559 = and i1 %descriptor.owner.inside.5554, %descriptor.offset.inside.5555
  %descriptor.range.inside.5561 = and i1 %descriptor.owner.offset.valid.5559, %descriptor.extent.inside.5557
  %descriptor.range.valid.5560 = and i1 %descriptor.range.inside.5561, %descriptor.payload.inside.5558
  br i1 %descriptor.range.valid.5560, label %descriptor.valid.5562, label %descriptor.invalid.5563
descriptor.invalid.5563:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5562:
  %descriptor.initialized.status.5564 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5548, i32 %local.check.extent.5549)
  %helper.ok.5565 = icmp eq i32 %descriptor.initialized.status.5564, 0
  br i1 %helper.ok.5565, label %helper.continue.5566, label %frame.failure.0
helper.continue.5566:
  br label %local.descriptor.checked.5547
local.descriptor.inactive.5546:
  br label %local.descriptor.checked.5547
local.descriptor.checked.5547:
  %local.is.active.5567 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.5567, label %local.descriptor.active.5568, label %local.descriptor.inactive.5569
local.descriptor.active.5568:
  %local.check.offset.5571 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.5572 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.5573 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.5574 = load i32, ptr %local.owner.end.12, align 4
  %context.field.5575 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5576 = load i32, ptr %context.field.5575, align 4
  %stack.sub.5579 = sub i32 %local.check.owner.end.5574, %local.check.offset.5571
  %descriptor.owner.inside.5577 = icmp ule i32 %local.check.owner.end.5574, %context.value.5576
  %descriptor.offset.inside.5578 = icmp ule i32 %local.check.offset.5571, %local.check.owner.end.5574
  %descriptor.extent.inside.5580 = icmp ule i32 %local.check.extent.5572, %stack.sub.5579
  %descriptor.payload.inside.5581 = icmp ule i32 %local.check.payload.5573, %local.check.extent.5572
  %descriptor.owner.offset.valid.5582 = and i1 %descriptor.owner.inside.5577, %descriptor.offset.inside.5578
  %descriptor.range.inside.5584 = and i1 %descriptor.owner.offset.valid.5582, %descriptor.extent.inside.5580
  %descriptor.range.valid.5583 = and i1 %descriptor.range.inside.5584, %descriptor.payload.inside.5581
  br i1 %descriptor.range.valid.5583, label %descriptor.valid.5585, label %descriptor.invalid.5586
descriptor.invalid.5586:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5585:
  %descriptor.initialized.status.5587 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5571, i32 %local.check.extent.5572)
  %helper.ok.5588 = icmp eq i32 %descriptor.initialized.status.5587, 0
  br i1 %helper.ok.5588, label %helper.continue.5589, label %frame.failure.0
helper.continue.5589:
  br label %local.descriptor.checked.5570
local.descriptor.inactive.5569:
  br label %local.descriptor.checked.5570
local.descriptor.checked.5570:
  %local.is.active.5590 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.5590, label %local.descriptor.active.5591, label %local.descriptor.inactive.5592
local.descriptor.active.5591:
  %local.check.offset.5594 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.5595 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.5596 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.5597 = load i32, ptr %local.owner.end.18, align 4
  %context.field.5598 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5599 = load i32, ptr %context.field.5598, align 4
  %stack.sub.5602 = sub i32 %local.check.owner.end.5597, %local.check.offset.5594
  %descriptor.owner.inside.5600 = icmp ule i32 %local.check.owner.end.5597, %context.value.5599
  %descriptor.offset.inside.5601 = icmp ule i32 %local.check.offset.5594, %local.check.owner.end.5597
  %descriptor.extent.inside.5603 = icmp ule i32 %local.check.extent.5595, %stack.sub.5602
  %descriptor.payload.inside.5604 = icmp ule i32 %local.check.payload.5596, %local.check.extent.5595
  %descriptor.owner.offset.valid.5605 = and i1 %descriptor.owner.inside.5600, %descriptor.offset.inside.5601
  %descriptor.range.inside.5607 = and i1 %descriptor.owner.offset.valid.5605, %descriptor.extent.inside.5603
  %descriptor.range.valid.5606 = and i1 %descriptor.range.inside.5607, %descriptor.payload.inside.5604
  br i1 %descriptor.range.valid.5606, label %descriptor.valid.5608, label %descriptor.invalid.5609
descriptor.invalid.5609:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5608:
  %descriptor.initialized.status.5610 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5594, i32 %local.check.extent.5595)
  %helper.ok.5611 = icmp eq i32 %descriptor.initialized.status.5610, 0
  br i1 %helper.ok.5611, label %helper.continue.5612, label %frame.failure.0
helper.continue.5612:
  br label %local.descriptor.checked.5593
local.descriptor.inactive.5592:
  br label %local.descriptor.checked.5593
local.descriptor.checked.5593:
  %local.is.active.5613 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.5613, label %local.descriptor.active.5614, label %local.descriptor.inactive.5615
local.descriptor.active.5614:
  %local.check.offset.5617 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.5618 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.5619 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.5620 = load i32, ptr %local.owner.end.24, align 4
  %context.field.5621 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5622 = load i32, ptr %context.field.5621, align 4
  %stack.sub.5625 = sub i32 %local.check.owner.end.5620, %local.check.offset.5617
  %descriptor.owner.inside.5623 = icmp ule i32 %local.check.owner.end.5620, %context.value.5622
  %descriptor.offset.inside.5624 = icmp ule i32 %local.check.offset.5617, %local.check.owner.end.5620
  %descriptor.extent.inside.5626 = icmp ule i32 %local.check.extent.5618, %stack.sub.5625
  %descriptor.payload.inside.5627 = icmp ule i32 %local.check.payload.5619, %local.check.extent.5618
  %descriptor.owner.offset.valid.5628 = and i1 %descriptor.owner.inside.5623, %descriptor.offset.inside.5624
  %descriptor.range.inside.5630 = and i1 %descriptor.owner.offset.valid.5628, %descriptor.extent.inside.5626
  %descriptor.range.valid.5629 = and i1 %descriptor.range.inside.5630, %descriptor.payload.inside.5627
  br i1 %descriptor.range.valid.5629, label %descriptor.valid.5631, label %descriptor.invalid.5632
descriptor.invalid.5632:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5631:
  %descriptor.initialized.status.5633 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5617, i32 %local.check.extent.5618)
  %helper.ok.5634 = icmp eq i32 %descriptor.initialized.status.5633, 0
  br i1 %helper.ok.5634, label %helper.continue.5635, label %frame.failure.0
helper.continue.5635:
  br label %local.descriptor.checked.5616
local.descriptor.inactive.5615:
  br label %local.descriptor.checked.5616
local.descriptor.checked.5616:
  %local.is.active.5636 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.5636, label %local.descriptor.active.5637, label %local.descriptor.inactive.5638
local.descriptor.active.5637:
  %local.check.offset.5640 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.5641 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.5642 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.5643 = load i32, ptr %local.owner.end.30, align 4
  %context.field.5644 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5645 = load i32, ptr %context.field.5644, align 4
  %stack.sub.5648 = sub i32 %local.check.owner.end.5643, %local.check.offset.5640
  %descriptor.owner.inside.5646 = icmp ule i32 %local.check.owner.end.5643, %context.value.5645
  %descriptor.offset.inside.5647 = icmp ule i32 %local.check.offset.5640, %local.check.owner.end.5643
  %descriptor.extent.inside.5649 = icmp ule i32 %local.check.extent.5641, %stack.sub.5648
  %descriptor.payload.inside.5650 = icmp ule i32 %local.check.payload.5642, %local.check.extent.5641
  %descriptor.owner.offset.valid.5651 = and i1 %descriptor.owner.inside.5646, %descriptor.offset.inside.5647
  %descriptor.range.inside.5653 = and i1 %descriptor.owner.offset.valid.5651, %descriptor.extent.inside.5649
  %descriptor.range.valid.5652 = and i1 %descriptor.range.inside.5653, %descriptor.payload.inside.5650
  br i1 %descriptor.range.valid.5652, label %descriptor.valid.5654, label %descriptor.invalid.5655
descriptor.invalid.5655:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5654:
  %descriptor.initialized.status.5656 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5640, i32 %local.check.extent.5641)
  %helper.ok.5657 = icmp eq i32 %descriptor.initialized.status.5656, 0
  br i1 %helper.ok.5657, label %helper.continue.5658, label %frame.failure.0
helper.continue.5658:
  br label %local.descriptor.checked.5639
local.descriptor.inactive.5638:
  br label %local.descriptor.checked.5639
local.descriptor.checked.5639:
  %local.is.active.5659 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.5659, label %local.descriptor.active.5660, label %local.descriptor.inactive.5661
local.descriptor.active.5660:
  %local.check.offset.5663 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.5664 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.5665 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.5666 = load i32, ptr %local.owner.end.36, align 4
  %context.field.5667 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5668 = load i32, ptr %context.field.5667, align 4
  %stack.sub.5671 = sub i32 %local.check.owner.end.5666, %local.check.offset.5663
  %descriptor.owner.inside.5669 = icmp ule i32 %local.check.owner.end.5666, %context.value.5668
  %descriptor.offset.inside.5670 = icmp ule i32 %local.check.offset.5663, %local.check.owner.end.5666
  %descriptor.extent.inside.5672 = icmp ule i32 %local.check.extent.5664, %stack.sub.5671
  %descriptor.payload.inside.5673 = icmp ule i32 %local.check.payload.5665, %local.check.extent.5664
  %descriptor.owner.offset.valid.5674 = and i1 %descriptor.owner.inside.5669, %descriptor.offset.inside.5670
  %descriptor.range.inside.5676 = and i1 %descriptor.owner.offset.valid.5674, %descriptor.extent.inside.5672
  %descriptor.range.valid.5675 = and i1 %descriptor.range.inside.5676, %descriptor.payload.inside.5673
  br i1 %descriptor.range.valid.5675, label %descriptor.valid.5677, label %descriptor.invalid.5678
descriptor.invalid.5678:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5677:
  %descriptor.initialized.status.5679 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5663, i32 %local.check.extent.5664)
  %helper.ok.5680 = icmp eq i32 %descriptor.initialized.status.5679, 0
  br i1 %helper.ok.5680, label %helper.continue.5681, label %frame.failure.0
helper.continue.5681:
  br label %local.descriptor.checked.5662
local.descriptor.inactive.5661:
  br label %local.descriptor.checked.5662
local.descriptor.checked.5662:
  %local.is.active.5682 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.5682, label %local.descriptor.active.5683, label %local.descriptor.inactive.5684
local.descriptor.active.5683:
  %local.check.offset.5686 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.5687 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.5688 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.5689 = load i32, ptr %local.owner.end.42, align 4
  %context.field.5690 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5691 = load i32, ptr %context.field.5690, align 4
  %stack.sub.5694 = sub i32 %local.check.owner.end.5689, %local.check.offset.5686
  %descriptor.owner.inside.5692 = icmp ule i32 %local.check.owner.end.5689, %context.value.5691
  %descriptor.offset.inside.5693 = icmp ule i32 %local.check.offset.5686, %local.check.owner.end.5689
  %descriptor.extent.inside.5695 = icmp ule i32 %local.check.extent.5687, %stack.sub.5694
  %descriptor.payload.inside.5696 = icmp ule i32 %local.check.payload.5688, %local.check.extent.5687
  %descriptor.owner.offset.valid.5697 = and i1 %descriptor.owner.inside.5692, %descriptor.offset.inside.5693
  %descriptor.range.inside.5699 = and i1 %descriptor.owner.offset.valid.5697, %descriptor.extent.inside.5695
  %descriptor.range.valid.5698 = and i1 %descriptor.range.inside.5699, %descriptor.payload.inside.5696
  br i1 %descriptor.range.valid.5698, label %descriptor.valid.5700, label %descriptor.invalid.5701
descriptor.invalid.5701:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5700:
  %descriptor.initialized.status.5702 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5686, i32 %local.check.extent.5687)
  %helper.ok.5703 = icmp eq i32 %descriptor.initialized.status.5702, 0
  br i1 %helper.ok.5703, label %helper.continue.5704, label %frame.failure.0
helper.continue.5704:
  br label %local.descriptor.checked.5685
local.descriptor.inactive.5684:
  br label %local.descriptor.checked.5685
local.descriptor.checked.5685:
  store i1 false, ptr %local.active.38, align 1
  store i32 0, ptr %local.offset.39, align 4
  store i32 0, ptr %local.extent.40, align 4
  store i32 0, ptr %local.payload.41, align 4
  store i32 0, ptr %local.owner.end.42, align 4
  store i32 0, ptr %local.type.43, align 4
  %context.field.5705 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5706 = load i32, ptr %context.field.5705, align 4
  %stack.sub.5709 = sub i32 %stack.offset.5513, %context.value.5512
  %descriptor.owner.inside.5707 = icmp ule i32 %stack.offset.5513, %context.value.5706
  %descriptor.offset.inside.5708 = icmp ule i32 %context.value.5512, %stack.offset.5513
  %descriptor.extent.inside.5710 = icmp ule i32 %stack.offset.5510, %stack.sub.5709
  %descriptor.payload.inside.5711 = icmp ule i32 %stack.offset.5509, %stack.offset.5510
  %descriptor.owner.offset.valid.5712 = and i1 %descriptor.owner.inside.5707, %descriptor.offset.inside.5708
  %descriptor.range.inside.5714 = and i1 %descriptor.owner.offset.valid.5712, %descriptor.extent.inside.5710
  %descriptor.range.valid.5713 = and i1 %descriptor.range.inside.5714, %descriptor.payload.inside.5711
  %descriptor.type.valid.5715 = icmp eq i32 5, 5
  %descriptor.valid.5716 = and i1 %descriptor.range.valid.5713, %descriptor.type.valid.5715
  br i1 %descriptor.valid.5716, label %descriptor.valid.5717, label %descriptor.invalid.5718
descriptor.invalid.5718:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5717:
  %descriptor.initialized.status.5719 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.5512, i32 %stack.offset.5510)
  %helper.ok.5720 = icmp eq i32 %descriptor.initialized.status.5719, 0
  br i1 %helper.ok.5720, label %helper.continue.5721, label %frame.failure.0
helper.continue.5721:
  %local.is.active.5722 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.5722, label %local.descriptor.active.5723, label %local.descriptor.inactive.5724
local.descriptor.active.5723:
  %local.check.offset.5726 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.5727 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.5728 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.5729 = load i32, ptr %local.owner.end.6, align 4
  %context.field.5730 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5731 = load i32, ptr %context.field.5730, align 4
  %stack.sub.5734 = sub i32 %local.check.owner.end.5729, %local.check.offset.5726
  %descriptor.owner.inside.5732 = icmp ule i32 %local.check.owner.end.5729, %context.value.5731
  %descriptor.offset.inside.5733 = icmp ule i32 %local.check.offset.5726, %local.check.owner.end.5729
  %descriptor.extent.inside.5735 = icmp ule i32 %local.check.extent.5727, %stack.sub.5734
  %descriptor.payload.inside.5736 = icmp ule i32 %local.check.payload.5728, %local.check.extent.5727
  %descriptor.owner.offset.valid.5737 = and i1 %descriptor.owner.inside.5732, %descriptor.offset.inside.5733
  %descriptor.range.inside.5739 = and i1 %descriptor.owner.offset.valid.5737, %descriptor.extent.inside.5735
  %descriptor.range.valid.5738 = and i1 %descriptor.range.inside.5739, %descriptor.payload.inside.5736
  br i1 %descriptor.range.valid.5738, label %descriptor.valid.5740, label %descriptor.invalid.5741
descriptor.invalid.5741:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5740:
  %descriptor.initialized.status.5742 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5726, i32 %local.check.extent.5727)
  %helper.ok.5743 = icmp eq i32 %descriptor.initialized.status.5742, 0
  br i1 %helper.ok.5743, label %helper.continue.5744, label %frame.failure.0
helper.continue.5744:
  br label %local.descriptor.checked.5725
local.descriptor.inactive.5724:
  br label %local.descriptor.checked.5725
local.descriptor.checked.5725:
  %local.is.active.5745 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.5745, label %local.descriptor.active.5746, label %local.descriptor.inactive.5747
local.descriptor.active.5746:
  %local.check.offset.5749 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.5750 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.5751 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.5752 = load i32, ptr %local.owner.end.12, align 4
  %context.field.5753 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5754 = load i32, ptr %context.field.5753, align 4
  %stack.sub.5757 = sub i32 %local.check.owner.end.5752, %local.check.offset.5749
  %descriptor.owner.inside.5755 = icmp ule i32 %local.check.owner.end.5752, %context.value.5754
  %descriptor.offset.inside.5756 = icmp ule i32 %local.check.offset.5749, %local.check.owner.end.5752
  %descriptor.extent.inside.5758 = icmp ule i32 %local.check.extent.5750, %stack.sub.5757
  %descriptor.payload.inside.5759 = icmp ule i32 %local.check.payload.5751, %local.check.extent.5750
  %descriptor.owner.offset.valid.5760 = and i1 %descriptor.owner.inside.5755, %descriptor.offset.inside.5756
  %descriptor.range.inside.5762 = and i1 %descriptor.owner.offset.valid.5760, %descriptor.extent.inside.5758
  %descriptor.range.valid.5761 = and i1 %descriptor.range.inside.5762, %descriptor.payload.inside.5759
  br i1 %descriptor.range.valid.5761, label %descriptor.valid.5763, label %descriptor.invalid.5764
descriptor.invalid.5764:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5763:
  %descriptor.initialized.status.5765 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5749, i32 %local.check.extent.5750)
  %helper.ok.5766 = icmp eq i32 %descriptor.initialized.status.5765, 0
  br i1 %helper.ok.5766, label %helper.continue.5767, label %frame.failure.0
helper.continue.5767:
  br label %local.descriptor.checked.5748
local.descriptor.inactive.5747:
  br label %local.descriptor.checked.5748
local.descriptor.checked.5748:
  %local.is.active.5768 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.5768, label %local.descriptor.active.5769, label %local.descriptor.inactive.5770
local.descriptor.active.5769:
  %local.check.offset.5772 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.5773 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.5774 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.5775 = load i32, ptr %local.owner.end.18, align 4
  %context.field.5776 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5777 = load i32, ptr %context.field.5776, align 4
  %stack.sub.5780 = sub i32 %local.check.owner.end.5775, %local.check.offset.5772
  %descriptor.owner.inside.5778 = icmp ule i32 %local.check.owner.end.5775, %context.value.5777
  %descriptor.offset.inside.5779 = icmp ule i32 %local.check.offset.5772, %local.check.owner.end.5775
  %descriptor.extent.inside.5781 = icmp ule i32 %local.check.extent.5773, %stack.sub.5780
  %descriptor.payload.inside.5782 = icmp ule i32 %local.check.payload.5774, %local.check.extent.5773
  %descriptor.owner.offset.valid.5783 = and i1 %descriptor.owner.inside.5778, %descriptor.offset.inside.5779
  %descriptor.range.inside.5785 = and i1 %descriptor.owner.offset.valid.5783, %descriptor.extent.inside.5781
  %descriptor.range.valid.5784 = and i1 %descriptor.range.inside.5785, %descriptor.payload.inside.5782
  br i1 %descriptor.range.valid.5784, label %descriptor.valid.5786, label %descriptor.invalid.5787
descriptor.invalid.5787:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5786:
  %descriptor.initialized.status.5788 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5772, i32 %local.check.extent.5773)
  %helper.ok.5789 = icmp eq i32 %descriptor.initialized.status.5788, 0
  br i1 %helper.ok.5789, label %helper.continue.5790, label %frame.failure.0
helper.continue.5790:
  br label %local.descriptor.checked.5771
local.descriptor.inactive.5770:
  br label %local.descriptor.checked.5771
local.descriptor.checked.5771:
  %local.is.active.5791 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.5791, label %local.descriptor.active.5792, label %local.descriptor.inactive.5793
local.descriptor.active.5792:
  %local.check.offset.5795 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.5796 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.5797 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.5798 = load i32, ptr %local.owner.end.24, align 4
  %context.field.5799 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5800 = load i32, ptr %context.field.5799, align 4
  %stack.sub.5803 = sub i32 %local.check.owner.end.5798, %local.check.offset.5795
  %descriptor.owner.inside.5801 = icmp ule i32 %local.check.owner.end.5798, %context.value.5800
  %descriptor.offset.inside.5802 = icmp ule i32 %local.check.offset.5795, %local.check.owner.end.5798
  %descriptor.extent.inside.5804 = icmp ule i32 %local.check.extent.5796, %stack.sub.5803
  %descriptor.payload.inside.5805 = icmp ule i32 %local.check.payload.5797, %local.check.extent.5796
  %descriptor.owner.offset.valid.5806 = and i1 %descriptor.owner.inside.5801, %descriptor.offset.inside.5802
  %descriptor.range.inside.5808 = and i1 %descriptor.owner.offset.valid.5806, %descriptor.extent.inside.5804
  %descriptor.range.valid.5807 = and i1 %descriptor.range.inside.5808, %descriptor.payload.inside.5805
  br i1 %descriptor.range.valid.5807, label %descriptor.valid.5809, label %descriptor.invalid.5810
descriptor.invalid.5810:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5809:
  %descriptor.initialized.status.5811 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5795, i32 %local.check.extent.5796)
  %helper.ok.5812 = icmp eq i32 %descriptor.initialized.status.5811, 0
  br i1 %helper.ok.5812, label %helper.continue.5813, label %frame.failure.0
helper.continue.5813:
  br label %local.descriptor.checked.5794
local.descriptor.inactive.5793:
  br label %local.descriptor.checked.5794
local.descriptor.checked.5794:
  %local.is.active.5814 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.5814, label %local.descriptor.active.5815, label %local.descriptor.inactive.5816
local.descriptor.active.5815:
  %local.check.offset.5818 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.5819 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.5820 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.5821 = load i32, ptr %local.owner.end.30, align 4
  %context.field.5822 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5823 = load i32, ptr %context.field.5822, align 4
  %stack.sub.5826 = sub i32 %local.check.owner.end.5821, %local.check.offset.5818
  %descriptor.owner.inside.5824 = icmp ule i32 %local.check.owner.end.5821, %context.value.5823
  %descriptor.offset.inside.5825 = icmp ule i32 %local.check.offset.5818, %local.check.owner.end.5821
  %descriptor.extent.inside.5827 = icmp ule i32 %local.check.extent.5819, %stack.sub.5826
  %descriptor.payload.inside.5828 = icmp ule i32 %local.check.payload.5820, %local.check.extent.5819
  %descriptor.owner.offset.valid.5829 = and i1 %descriptor.owner.inside.5824, %descriptor.offset.inside.5825
  %descriptor.range.inside.5831 = and i1 %descriptor.owner.offset.valid.5829, %descriptor.extent.inside.5827
  %descriptor.range.valid.5830 = and i1 %descriptor.range.inside.5831, %descriptor.payload.inside.5828
  br i1 %descriptor.range.valid.5830, label %descriptor.valid.5832, label %descriptor.invalid.5833
descriptor.invalid.5833:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5832:
  %descriptor.initialized.status.5834 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5818, i32 %local.check.extent.5819)
  %helper.ok.5835 = icmp eq i32 %descriptor.initialized.status.5834, 0
  br i1 %helper.ok.5835, label %helper.continue.5836, label %frame.failure.0
helper.continue.5836:
  br label %local.descriptor.checked.5817
local.descriptor.inactive.5816:
  br label %local.descriptor.checked.5817
local.descriptor.checked.5817:
  %local.is.active.5837 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.5837, label %local.descriptor.active.5838, label %local.descriptor.inactive.5839
local.descriptor.active.5838:
  %local.check.offset.5841 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.5842 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.5843 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.5844 = load i32, ptr %local.owner.end.36, align 4
  %context.field.5845 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5846 = load i32, ptr %context.field.5845, align 4
  %stack.sub.5849 = sub i32 %local.check.owner.end.5844, %local.check.offset.5841
  %descriptor.owner.inside.5847 = icmp ule i32 %local.check.owner.end.5844, %context.value.5846
  %descriptor.offset.inside.5848 = icmp ule i32 %local.check.offset.5841, %local.check.owner.end.5844
  %descriptor.extent.inside.5850 = icmp ule i32 %local.check.extent.5842, %stack.sub.5849
  %descriptor.payload.inside.5851 = icmp ule i32 %local.check.payload.5843, %local.check.extent.5842
  %descriptor.owner.offset.valid.5852 = and i1 %descriptor.owner.inside.5847, %descriptor.offset.inside.5848
  %descriptor.range.inside.5854 = and i1 %descriptor.owner.offset.valid.5852, %descriptor.extent.inside.5850
  %descriptor.range.valid.5853 = and i1 %descriptor.range.inside.5854, %descriptor.payload.inside.5851
  br i1 %descriptor.range.valid.5853, label %descriptor.valid.5855, label %descriptor.invalid.5856
descriptor.invalid.5856:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5855:
  %descriptor.initialized.status.5857 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5841, i32 %local.check.extent.5842)
  %helper.ok.5858 = icmp eq i32 %descriptor.initialized.status.5857, 0
  br i1 %helper.ok.5858, label %helper.continue.5859, label %frame.failure.0
helper.continue.5859:
  br label %local.descriptor.checked.5840
local.descriptor.inactive.5839:
  br label %local.descriptor.checked.5840
local.descriptor.checked.5840:
  %local.is.active.5860 = load i1, ptr %local.active.38, align 1
  br i1 %local.is.active.5860, label %local.descriptor.active.5861, label %local.descriptor.inactive.5862
local.descriptor.active.5861:
  %local.check.offset.5864 = load i32, ptr %local.offset.39, align 4
  %local.check.extent.5865 = load i32, ptr %local.extent.40, align 4
  %local.check.payload.5866 = load i32, ptr %local.payload.41, align 4
  %local.check.owner.end.5867 = load i32, ptr %local.owner.end.42, align 4
  %context.field.5868 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.5869 = load i32, ptr %context.field.5868, align 4
  %stack.sub.5872 = sub i32 %local.check.owner.end.5867, %local.check.offset.5864
  %descriptor.owner.inside.5870 = icmp ule i32 %local.check.owner.end.5867, %context.value.5869
  %descriptor.offset.inside.5871 = icmp ule i32 %local.check.offset.5864, %local.check.owner.end.5867
  %descriptor.extent.inside.5873 = icmp ule i32 %local.check.extent.5865, %stack.sub.5872
  %descriptor.payload.inside.5874 = icmp ule i32 %local.check.payload.5866, %local.check.extent.5865
  %descriptor.owner.offset.valid.5875 = and i1 %descriptor.owner.inside.5870, %descriptor.offset.inside.5871
  %descriptor.range.inside.5877 = and i1 %descriptor.owner.offset.valid.5875, %descriptor.extent.inside.5873
  %descriptor.range.valid.5876 = and i1 %descriptor.range.inside.5877, %descriptor.payload.inside.5874
  br i1 %descriptor.range.valid.5876, label %descriptor.valid.5878, label %descriptor.invalid.5879
descriptor.invalid.5879:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.5878:
  %descriptor.initialized.status.5880 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.5864, i32 %local.check.extent.5865)
  %helper.ok.5881 = icmp eq i32 %descriptor.initialized.status.5880, 0
  br i1 %helper.ok.5881, label %helper.continue.5882, label %frame.failure.0
helper.continue.5882:
  br label %local.descriptor.checked.5863
local.descriptor.inactive.5862:
  br label %local.descriptor.checked.5863
local.descriptor.checked.5863:
  store i1 false, ptr %local.active.32, align 1
  store i32 0, ptr %local.offset.33, align 4
  store i32 0, ptr %local.extent.34, align 4
  store i32 0, ptr %local.payload.35, align 4
  store i32 0, ptr %local.owner.end.36, align 4
  store i32 0, ptr %local.type.37, align 4
  store i1 false, ptr %local.active.26, align 1
  store i32 0, ptr %local.offset.27, align 4
  store i32 0, ptr %local.extent.28, align 4
  store i32 0, ptr %local.payload.29, align 4
  store i32 0, ptr %local.owner.end.30, align 4
  store i32 0, ptr %local.type.31, align 4
  store i1 false, ptr %local.active.20, align 1
  store i32 0, ptr %local.offset.21, align 4
  store i32 0, ptr %local.extent.22, align 4
  store i32 0, ptr %local.payload.23, align 4
  store i32 0, ptr %local.owner.end.24, align 4
  store i32 0, ptr %local.type.25, align 4
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %descriptor.element.5883 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.5884 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.5883, i32 0, i32 0
  store i32 5, ptr %descriptor.field.5884, align 4
  %descriptor.field.5885 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.5883, i32 0, i32 1
  store i32 %context.value.5512, ptr %descriptor.field.5885, align 4
  %descriptor.field.5886 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.5883, i32 0, i32 2
  store i32 %stack.offset.5510, ptr %descriptor.field.5886, align 4
  %descriptor.field.5887 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.5883, i32 0, i32 3
  store i32 %stack.offset.5509, ptr %descriptor.field.5887, align 4
  %descriptor.field.5888 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.5883, i32 0, i32 4
  store i32 %stack.offset.5513, ptr %descriptor.field.5888, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %context.value.5512, i32 20, i32 %stack.offset.5509, i32 %stack.offset.5513, i32 %stack.offset.5510)
  %context.field.5889 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.5890 = load i32, ptr %context.field.5889, align 4
  %runtime.ok.5891 = icmp eq i32 %context.value.5890, 0
  br i1 %runtime.ok.5891, label %runtime.continue.5892, label %frame.failure.0
runtime.continue.5892:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.45, i32 0, i32 0, i32 0)
  %context.field.5893 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5894 = load i32, ptr %context.field.5893, align 4
  %context.field.5895 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.5896 = load i32, ptr %context.field.5895, align 4
  %context.field.5897 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.5898 = load i32, ptr %context.field.5897, align 4
  %stack.offset.5899 = add i32 %context.value.47, %context.value.49
  %stack.offset.5900 = add i32 %context.value.5894, %context.value.5896
  %stack.sub.5901 = sub i32 %stack.offset.5899, %stack.offset.5900
  %stack.sub.5902 = sub i32 %context.value.49, %context.value.5896
  %stack.sub.5903 = sub i32 %context.value.5898, %context.value.51
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.5901, i32 %stack.sub.5902)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.5903)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  %entry.input.descriptors.15 = alloca [1 x %AlOwningDescriptor], align 4
  %input.payload.pointer.25 = alloca i32, align 4
  %input.measured.extent.pointer.26 = alloca i32, align 4
  %entry.output.descriptors.57 = alloca [1 x %AlOwningDescriptor], align 4
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 1
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %entry.input.extents.present.10 = icmp ne ptr %input.extents, null
  %entry.input.bytes.present.11 = icmp ne ptr %input, null
  %entry.input.pointers.present.12 = and i1 %entry.input.extents.present.10, %entry.input.bytes.present.11
  br i1 %entry.input.pointers.present.12, label %entry.input.pointers.ok.13, label %entry.input.pointers.invalid.14
entry.input.pointers.invalid.14:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 0)
  br label %entry.failure.0
entry.input.pointers.ok.13:
  %input.extent.pointer.16 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.17 = load i32, ptr %input.extent.pointer.16, align 4
  %stack.sub.18 = sub i32 %input.bytes, 0
  %input.offset.within.bytes.19 = icmp ule i32 0, %input.bytes
  %input.extent.within.bytes.20 = icmp ule i32 %input.host.extent.17, %stack.sub.18
  %input.slice.within.bytes.21 = and i1 %input.offset.within.bytes.19, %input.extent.within.bytes.20
  br i1 %input.slice.within.bytes.21, label %input.slice.ready.22, label %input.slice.invalid.23
input.slice.invalid.23:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 80, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.22:
  %host.pointer.24 = getelementptr inbounds i8, ptr %input, i32 0
  %input.measure.status.27 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 4, ptr %host.pointer.24, i32 %input.host.extent.17, i32 0, i32 80, ptr %input.payload.pointer.25, ptr %input.measured.extent.pointer.26)
  %helper.ok.28 = icmp eq i32 %input.measure.status.27, 0
  br i1 %helper.ok.28, label %helper.continue.29, label %entry.failure.0
helper.continue.29:
  %input.measured.payload.30 = load i32, ptr %input.payload.pointer.25, align 4
  %input.measured.extent.31 = load i32, ptr %input.measured.extent.pointer.26, align 4
  %input.extent.exact.32 = icmp eq i32 %input.measured.extent.31, %input.host.extent.17
  br i1 %input.extent.exact.32, label %input.extent.exact.33, label %input.extent.invalid.34
input.extent.invalid.34:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 80, i32 %input.measured.extent.31, i32 %input.host.extent.17)
  br label %entry.failure.0
input.extent.exact.33:
  %stack.offset.35 = add i32 0, %input.host.extent.17
  %input.total.exact.36 = icmp eq i32 %stack.offset.35, %input.bytes
  br i1 %input.total.exact.36, label %input.valid.37, label %input.invalid.38
input.invalid.38:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.35, i32 %input.bytes)
  br label %entry.failure.0
input.valid.37:
  %reserve.status.39 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.35, i32 81)
  %reserve.ok.40 = icmp eq i32 %reserve.status.39, 0
  br i1 %reserve.ok.40, label %reserve.continue.41, label %entry.failure.0
reserve.continue.41:
  %host.pointer.42 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.43 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.42, i32 %input.host.extent.17, i32 0, i32 %input.measured.payload.30, i32 %input.host.extent.17, i32 6, i32 82)
  %helper.ok.44 = icmp eq i32 %input.copy.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %entry.failure.0
helper.continue.45:
  %stack.offset.46 = add i32 0, %input.host.extent.17
  %descriptor.element.47 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.15, i32 0
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 0
  store i32 6, ptr %descriptor.field.48, align 4
  %descriptor.field.49 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 1
  store i32 0, ptr %descriptor.field.49, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 2
  store i32 %input.host.extent.17, ptr %descriptor.field.50, align 4
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 3
  store i32 %input.measured.payload.30, ptr %descriptor.field.51, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 4
  store i32 %stack.offset.46, ptr %descriptor.field.52, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 0, i32 20, i32 %input.measured.payload.30, i32 %stack.offset.46, i32 %input.host.extent.17)
  %context.field.53 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.54 = load i32, ptr %context.field.53, align 4
  %runtime.ok.55 = icmp eq i32 %context.value.54, 0
  br i1 %runtime.ok.55, label %runtime.continue.56, label %entry.failure.0
runtime.continue.56:
  %entry.body.status.58 = call i32 @agentlang_mailbox_initialize_frame(ptr %ctx, ptr %entry.input.descriptors.15, ptr %entry.output.descriptors.57, i32 83)
  %entry.body.ok.59 = icmp eq i32 %entry.body.status.58, 0
  br i1 %entry.body.ok.59, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.60 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.57, i32 0
  %descriptor.field.61 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 0
  %descriptor.value.62 = load i32, ptr %descriptor.field.61, align 4
  %descriptor.field.63 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 1
  %descriptor.value.64 = load i32, ptr %descriptor.field.63, align 4
  %descriptor.field.65 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 2
  %descriptor.value.66 = load i32, ptr %descriptor.field.65, align 4
  %descriptor.field.67 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 3
  %descriptor.value.68 = load i32, ptr %descriptor.field.67, align 4
  %descriptor.field.69 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 4
  %descriptor.value.70 = load i32, ptr %descriptor.field.69, align 4
  %entry.output.type.valid.71 = icmp eq i32 %descriptor.value.62, 5
  br i1 %entry.output.type.valid.71, label %entry.output.type.ok.72, label %entry.output.type.invalid.73
entry.output.type.invalid.73:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.72:
  %context.field.74 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.75 = load i32, ptr %context.field.74, align 4
  %stack.sub.78 = sub i32 %descriptor.value.70, %descriptor.value.64
  %descriptor.owner.inside.76 = icmp ule i32 %descriptor.value.70, %context.value.75
  %descriptor.offset.inside.77 = icmp ule i32 %descriptor.value.64, %descriptor.value.70
  %descriptor.extent.inside.79 = icmp ule i32 %descriptor.value.66, %stack.sub.78
  %descriptor.payload.inside.80 = icmp ule i32 %descriptor.value.68, %descriptor.value.66
  %descriptor.owner.offset.valid.81 = and i1 %descriptor.owner.inside.76, %descriptor.offset.inside.77
  %descriptor.range.inside.83 = and i1 %descriptor.owner.offset.valid.81, %descriptor.extent.inside.79
  %descriptor.range.valid.82 = and i1 %descriptor.range.inside.83, %descriptor.payload.inside.80
  %descriptor.type.valid.84 = icmp eq i32 5, 5
  %descriptor.valid.85 = and i1 %descriptor.range.valid.82, %descriptor.type.valid.84
  br i1 %descriptor.valid.85, label %descriptor.valid.86, label %descriptor.invalid.87
descriptor.invalid.87:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.86:
  %descriptor.initialized.status.88 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.64, i32 %descriptor.value.66)
  %helper.ok.89 = icmp eq i32 %descriptor.initialized.status.88, 0
  br i1 %helper.ok.89, label %helper.continue.90, label %entry.failure.0
helper.continue.90:
  %entry.output.size.i64.91 = zext i32 %descriptor.value.66 to i64
  %entry.output.total.i64.92 = add i64 0, %entry.output.size.i64.91
  %entry.retained.capacity.i64.93 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.94 = icmp ule i64 %entry.output.total.i64.92, 4294967295
  %entry.retained.required.truncated.95 = trunc i64 %entry.output.total.i64.92 to i32
  %entry.retained.required.96 = select i1 %entry.retained.required.fits.u32.94, i32 %entry.retained.required.truncated.95, i32 4294967295
  %entry.retained.capacity.ok.97 = icmp ule i64 %entry.output.total.i64.92, %entry.retained.capacity.i64.93
  br i1 %entry.retained.capacity.ok.97, label %entry.retained.capacity.ready.98, label %entry.retained.capacity.failure.99
entry.retained.capacity.failure.99:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.96, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.98:
  %host.pointer.100 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.101 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.100, i32 %stack.sub.101, i32 %descriptor.value.64, i32 %descriptor.value.66, i32 5)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %entry.failure.0
runtime.continue.105:
  %stack.offset.106 = add i32 0, %descriptor.value.66
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.107 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.108 = load i32, ptr %context.field.107, align 4
  %context.field.109 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.110 = load i32, ptr %context.field.109, align 4
  %stack.sub.111 = sub i32 0, %context.value.108
  %stack.sub.112 = sub i32 0, %context.value.110
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.111, i32 %stack.sub.112)
  %context.field.113 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.114 = load i32, ptr %context.field.113, align 4
  %runtime.ok.115 = icmp eq i32 %context.value.114, 0
  br i1 %runtime.ok.115, label %runtime.continue.116, label %entry.failure.0
runtime.continue.116:
  br label %entry.return.status
entry.failure.0:
  %context.field.117 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.118 = load i32, ptr %context.field.117, align 4
  %context.field.119 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.120 = load i32, ptr %context.field.119, align 4
  %context.field.121 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.122 = load i32, ptr %context.field.121, align 4
  %stack.offset.123 = add i32 %context.value.118, %context.value.120
  %stack.sub.124 = sub i32 0, %stack.offset.123
  %stack.sub.125 = sub i32 0, %context.value.120
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.124, i32 %stack.sub.125)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.122)
  br label %entry.return.status
entry.return.status:
  %context.field.126 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.127 = load i32, ptr %context.field.126, align 4
  ret i32 %context.value.127
}

define i32 @agentlang_mailbox_initialize(ptr %ctx, ptr %inputs, i32 %input.count, ptr %outputs, i32 %output.capacity) {
entry:
  %mailbox.input.total.pointer.4 = alloca i32, align 4
  %mailbox.input.descriptors.12 = alloca [1 x %AlOwningDescriptor], align 4
  %mailbox.input.payload.pointer.18 = alloca i32, align 4
  %mailbox.input.measured.extent.pointer.19 = alloca i32, align 4
  %mailbox.output.descriptors.46 = alloca [1 x %AlOwningDescriptor], align 4
  %mailbox.context.nonnull.3 = icmp ne ptr %ctx, null
  br i1 %mailbox.context.nonnull.3, label %mailbox.initialize.context.valid.1, label %mailbox.initialize.failure.0
mailbox.initialize.context.valid.1:
  %mailbox.preflight.status.5 = call i32 @agentlang_owning_mailbox_preflight(ptr %ctx, ptr %inputs, i32 %input.count, ptr %outputs, i32 %output.capacity, i32 0, i32 84, i32 85, i32 86, ptr %mailbox.input.total.pointer.4)
  %mailbox.preflight.ok.6 = icmp eq i32 %mailbox.preflight.status.5, 0
  br i1 %mailbox.preflight.ok.6, label %mailbox.initialize.preflight.ready.2, label %mailbox.initialize.failure.0
mailbox.initialize.preflight.ready.2:
  %mailbox.output.descriptor.7 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 0
  %mailbox.output.field.8 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 0
  store i32 4294967295, ptr %mailbox.output.field.8, align 4
  %mailbox.output.field.9 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 1
  store i32 0, ptr %mailbox.output.field.9, align 4
  %mailbox.output.field.10 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 2
  store i32 0, ptr %mailbox.output.field.10, align 4
  %mailbox.output.field.11 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 3
  store i32 0, ptr %mailbox.output.field.11, align 4
  %mailbox.input.slice.13 = getelementptr inbounds %AlOwningExternalSlice, ptr %inputs, i32 0
  %mailbox.input.bytes.field.14 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.13, i32 0, i32 0
  %mailbox.input.bytes.15 = load ptr, ptr %mailbox.input.bytes.field.14, align 8
  %mailbox.input.extent.field.16 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.13, i32 0, i32 1
  %mailbox.input.extent.17 = load i32, ptr %mailbox.input.extent.field.16, align 4
  %mailbox.input.measure.status.20 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 4, ptr %mailbox.input.bytes.15, i32 %mailbox.input.extent.17, i32 0, i32 87, ptr %mailbox.input.payload.pointer.18, ptr %mailbox.input.measured.extent.pointer.19)
  %helper.ok.21 = icmp eq i32 %mailbox.input.measure.status.20, 0
  br i1 %helper.ok.21, label %helper.continue.22, label %mailbox.initialize.failure.0
helper.continue.22:
  %mailbox.input.payload.23 = load i32, ptr %mailbox.input.payload.pointer.18, align 4
  %mailbox.input.measured.extent.24 = load i32, ptr %mailbox.input.measured.extent.pointer.19, align 4
  %mailbox.input.extent.exact.25 = icmp eq i32 %mailbox.input.measured.extent.24, %mailbox.input.extent.17
  br i1 %mailbox.input.extent.exact.25, label %mailbox.input.extent.ok.26, label %mailbox.input.extent.invalid.27
mailbox.input.extent.invalid.27:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 87, i32 %mailbox.input.measured.extent.24, i32 %mailbox.input.extent.17)
  br label %mailbox.initialize.failure.0
mailbox.input.extent.ok.26:
  %stack.offset.28 = add i32 0, %mailbox.input.extent.17
  %descriptor.element.29 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.input.descriptors.12, i32 0
  %descriptor.field.30 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 0
  store i32 6, ptr %descriptor.field.30, align 4
  %descriptor.field.31 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 1
  store i32 0, ptr %descriptor.field.31, align 4
  %descriptor.field.32 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 2
  store i32 %mailbox.input.extent.17, ptr %descriptor.field.32, align 4
  %descriptor.field.33 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 3
  store i32 %mailbox.input.payload.23, ptr %descriptor.field.33, align 4
  %descriptor.field.34 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 4
  store i32 %stack.offset.28, ptr %descriptor.field.34, align 4
  %mailbox.input.total.35 = load i32, ptr %mailbox.input.total.pointer.4, align 4
  %mailbox.input.reserve.status.36 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %mailbox.input.total.35, i32 88)
  %helper.ok.37 = icmp eq i32 %mailbox.input.reserve.status.36, 0
  br i1 %helper.ok.37, label %helper.continue.38, label %mailbox.initialize.failure.0
helper.continue.38:
  %mailbox.input.copy.status.39 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %mailbox.input.bytes.15, i32 %mailbox.input.extent.17, i32 0, i32 %mailbox.input.payload.23, i32 %mailbox.input.extent.17, i32 6, i32 88)
  %helper.ok.40 = icmp eq i32 %mailbox.input.copy.status.39, 0
  br i1 %helper.ok.40, label %helper.continue.41, label %mailbox.initialize.failure.0
helper.continue.41:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 0, i32 20, i32 %mailbox.input.payload.23, i32 %stack.offset.28, i32 %mailbox.input.extent.17)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %mailbox.initialize.failure.0
runtime.continue.45:
  %mailbox.frame.status.47 = call i32 @agentlang_mailbox_initialize_frame(ptr %ctx, ptr %mailbox.input.descriptors.12, ptr %mailbox.output.descriptors.46, i32 89)
  %helper.ok.48 = icmp eq i32 %mailbox.frame.status.47, 0
  br i1 %helper.ok.48, label %helper.continue.49, label %mailbox.initialize.failure.0
helper.continue.49:
  %descriptor.element.50 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.output.descriptors.46, i32 0
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 0
  %descriptor.value.52 = load i32, ptr %descriptor.field.51, align 4
  %descriptor.field.53 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 1
  %descriptor.value.54 = load i32, ptr %descriptor.field.53, align 4
  %descriptor.field.55 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 2
  %descriptor.value.56 = load i32, ptr %descriptor.field.55, align 4
  %descriptor.field.57 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 3
  %descriptor.value.58 = load i32, ptr %descriptor.field.57, align 4
  %descriptor.field.59 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 4
  %descriptor.value.60 = load i32, ptr %descriptor.field.59, align 4
  %mailbox.output.type.matches.61 = icmp eq i32 %descriptor.value.52, 5
  br i1 %mailbox.output.type.matches.61, label %mailbox.output.type.ok.62, label %mailbox.output.type.invalid.63
mailbox.output.type.invalid.63:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.initialize.failure.0
mailbox.output.type.ok.62:
  %context.field.64 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.65 = load i32, ptr %context.field.64, align 4
  %stack.sub.68 = sub i32 %descriptor.value.60, %descriptor.value.54
  %descriptor.owner.inside.66 = icmp ule i32 %descriptor.value.60, %context.value.65
  %descriptor.offset.inside.67 = icmp ule i32 %descriptor.value.54, %descriptor.value.60
  %descriptor.extent.inside.69 = icmp ule i32 %descriptor.value.56, %stack.sub.68
  %descriptor.payload.inside.70 = icmp ule i32 %descriptor.value.58, %descriptor.value.56
  %descriptor.owner.offset.valid.71 = and i1 %descriptor.owner.inside.66, %descriptor.offset.inside.67
  %descriptor.range.inside.73 = and i1 %descriptor.owner.offset.valid.71, %descriptor.extent.inside.69
  %descriptor.range.valid.72 = and i1 %descriptor.range.inside.73, %descriptor.payload.inside.70
  %descriptor.type.valid.74 = icmp eq i32 5, 5
  %descriptor.valid.75 = and i1 %descriptor.range.valid.72, %descriptor.type.valid.74
  br i1 %descriptor.valid.75, label %descriptor.valid.76, label %descriptor.invalid.77
descriptor.invalid.77:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.initialize.failure.0
descriptor.valid.76:
  %descriptor.initialized.status.78 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.54, i32 %descriptor.value.56)
  %helper.ok.79 = icmp eq i32 %descriptor.initialized.status.78, 0
  br i1 %helper.ok.79, label %helper.continue.80, label %mailbox.initialize.failure.0
helper.continue.80:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.54, i32 20, i32 %descriptor.value.58, i32 %descriptor.value.60, i32 %descriptor.value.56)
  %context.field.81 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.82 = load i32, ptr %context.field.81, align 4
  %runtime.ok.83 = icmp eq i32 %context.value.82, 0
  br i1 %runtime.ok.83, label %runtime.continue.84, label %mailbox.initialize.failure.0
runtime.continue.84:
  %mailbox.output.descriptor.85 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 0
  %mailbox.output.field.86 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.85, i32 0, i32 0
  store i32 3, ptr %mailbox.output.field.86, align 4
  %mailbox.output.field.87 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.85, i32 0, i32 1
  store i32 %descriptor.value.54, ptr %mailbox.output.field.87, align 4
  %mailbox.output.field.88 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.85, i32 0, i32 2
  store i32 %descriptor.value.60, ptr %mailbox.output.field.88, align 4
  %mailbox.output.field.89 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.85, i32 0, i32 3
  store i32 0, ptr %mailbox.output.field.89, align 4
  ret i32 0
mailbox.initialize.failure.0:
  %mailbox.failure.context.null.90 = icmp eq ptr %ctx, null
  br i1 %mailbox.failure.context.null.90, label %mailbox.failure.null.context.92, label %mailbox.failure.has.context.91
mailbox.failure.null.context.92:
  ret i32 4
mailbox.failure.has.context.91:
  %context.field.94 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.95 = load i32, ptr %context.field.94, align 4
  %mailbox.failure.status.set.96 = icmp ne i32 %context.value.95, 0
  br i1 %mailbox.failure.status.set.96, label %mailbox.failure.status.ready.93, label %mailbox.failure.set.fallback.97
mailbox.failure.set.fallback.97:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 84, i32 0, i32 0)
  br label %mailbox.failure.status.ready.93
mailbox.failure.status.ready.93:
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.99 = load i32, ptr %context.field.98, align 4
  ret i32 %context.value.99
}


define i32 @agentlang_mailbox_begin(ptr %ctx, ptr %inputs, i32 %input.count, ptr %outputs, i32 %output.capacity) {
entry:
  %mailbox.input.total.pointer.4 = alloca i32, align 4
  %mailbox.input.descriptors.17 = alloca [2 x %AlOwningDescriptor], align 4
  %mailbox.input.payload.pointer.23 = alloca i32, align 4
  %mailbox.input.measured.extent.pointer.24 = alloca i32, align 4
  %mailbox.input.payload.pointer.45 = alloca i32, align 4
  %mailbox.input.measured.extent.pointer.46 = alloca i32, align 4
  %mailbox.output.descriptors.80 = alloca [2 x %AlOwningDescriptor], align 4
  %mailbox.context.nonnull.3 = icmp ne ptr %ctx, null
  br i1 %mailbox.context.nonnull.3, label %mailbox.begin.context.valid.1, label %mailbox.begin.failure.0
mailbox.begin.context.valid.1:
  %mailbox.preflight.status.5 = call i32 @agentlang_owning_mailbox_preflight(ptr %ctx, ptr %inputs, i32 %input.count, ptr %outputs, i32 %output.capacity, i32 1, i32 90, i32 91, i32 92, ptr %mailbox.input.total.pointer.4)
  %mailbox.preflight.ok.6 = icmp eq i32 %mailbox.preflight.status.5, 0
  br i1 %mailbox.preflight.ok.6, label %mailbox.begin.preflight.ready.2, label %mailbox.begin.failure.0
mailbox.begin.preflight.ready.2:
  %mailbox.output.descriptor.7 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 0
  %mailbox.output.field.8 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 0
  store i32 4294967295, ptr %mailbox.output.field.8, align 4
  %mailbox.output.field.9 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 1
  store i32 0, ptr %mailbox.output.field.9, align 4
  %mailbox.output.field.10 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 2
  store i32 0, ptr %mailbox.output.field.10, align 4
  %mailbox.output.field.11 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 3
  store i32 0, ptr %mailbox.output.field.11, align 4
  %mailbox.output.descriptor.12 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 1
  %mailbox.output.field.13 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.12, i32 0, i32 0
  store i32 4294967295, ptr %mailbox.output.field.13, align 4
  %mailbox.output.field.14 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.12, i32 0, i32 1
  store i32 0, ptr %mailbox.output.field.14, align 4
  %mailbox.output.field.15 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.12, i32 0, i32 2
  store i32 0, ptr %mailbox.output.field.15, align 4
  %mailbox.output.field.16 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.12, i32 0, i32 3
  store i32 0, ptr %mailbox.output.field.16, align 4
  %mailbox.input.slice.18 = getelementptr inbounds %AlOwningExternalSlice, ptr %inputs, i32 0
  %mailbox.input.bytes.field.19 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.18, i32 0, i32 0
  %mailbox.input.bytes.20 = load ptr, ptr %mailbox.input.bytes.field.19, align 8
  %mailbox.input.extent.field.21 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.18, i32 0, i32 1
  %mailbox.input.extent.22 = load i32, ptr %mailbox.input.extent.field.21, align 4
  %mailbox.input.measure.status.25 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 3, ptr %mailbox.input.bytes.20, i32 %mailbox.input.extent.22, i32 0, i32 93, ptr %mailbox.input.payload.pointer.23, ptr %mailbox.input.measured.extent.pointer.24)
  %helper.ok.26 = icmp eq i32 %mailbox.input.measure.status.25, 0
  br i1 %helper.ok.26, label %helper.continue.27, label %mailbox.begin.failure.0
helper.continue.27:
  %mailbox.input.payload.28 = load i32, ptr %mailbox.input.payload.pointer.23, align 4
  %mailbox.input.measured.extent.29 = load i32, ptr %mailbox.input.measured.extent.pointer.24, align 4
  %mailbox.input.extent.exact.30 = icmp eq i32 %mailbox.input.measured.extent.29, %mailbox.input.extent.22
  br i1 %mailbox.input.extent.exact.30, label %mailbox.input.extent.ok.31, label %mailbox.input.extent.invalid.32
mailbox.input.extent.invalid.32:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 93, i32 %mailbox.input.measured.extent.29, i32 %mailbox.input.extent.22)
  br label %mailbox.begin.failure.0
mailbox.input.extent.ok.31:
  %stack.offset.33 = add i32 0, %mailbox.input.extent.22
  %descriptor.element.34 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.input.descriptors.17, i32 0
  %descriptor.field.35 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.34, i32 0, i32 0
  store i32 5, ptr %descriptor.field.35, align 4
  %descriptor.field.36 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.34, i32 0, i32 1
  store i32 0, ptr %descriptor.field.36, align 4
  %descriptor.field.37 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.34, i32 0, i32 2
  store i32 %mailbox.input.extent.22, ptr %descriptor.field.37, align 4
  %descriptor.field.38 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.34, i32 0, i32 3
  store i32 %mailbox.input.payload.28, ptr %descriptor.field.38, align 4
  %descriptor.field.39 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.34, i32 0, i32 4
  store i32 %stack.offset.33, ptr %descriptor.field.39, align 4
  %mailbox.input.slice.40 = getelementptr inbounds %AlOwningExternalSlice, ptr %inputs, i32 1
  %mailbox.input.bytes.field.41 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.40, i32 0, i32 0
  %mailbox.input.bytes.42 = load ptr, ptr %mailbox.input.bytes.field.41, align 8
  %mailbox.input.extent.field.43 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.40, i32 0, i32 1
  %mailbox.input.extent.44 = load i32, ptr %mailbox.input.extent.field.43, align 4
  %mailbox.input.measure.status.47 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 4, ptr %mailbox.input.bytes.42, i32 %mailbox.input.extent.44, i32 0, i32 93, ptr %mailbox.input.payload.pointer.45, ptr %mailbox.input.measured.extent.pointer.46)
  %helper.ok.48 = icmp eq i32 %mailbox.input.measure.status.47, 0
  br i1 %helper.ok.48, label %helper.continue.49, label %mailbox.begin.failure.0
helper.continue.49:
  %mailbox.input.payload.50 = load i32, ptr %mailbox.input.payload.pointer.45, align 4
  %mailbox.input.measured.extent.51 = load i32, ptr %mailbox.input.measured.extent.pointer.46, align 4
  %mailbox.input.extent.exact.52 = icmp eq i32 %mailbox.input.measured.extent.51, %mailbox.input.extent.44
  br i1 %mailbox.input.extent.exact.52, label %mailbox.input.extent.ok.53, label %mailbox.input.extent.invalid.54
mailbox.input.extent.invalid.54:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 93, i32 %mailbox.input.measured.extent.51, i32 %mailbox.input.extent.44)
  br label %mailbox.begin.failure.0
mailbox.input.extent.ok.53:
  %stack.offset.55 = add i32 %stack.offset.33, %mailbox.input.extent.44
  %descriptor.element.56 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.input.descriptors.17, i32 1
  %descriptor.field.57 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.56, i32 0, i32 0
  store i32 6, ptr %descriptor.field.57, align 4
  %descriptor.field.58 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.56, i32 0, i32 1
  store i32 %stack.offset.33, ptr %descriptor.field.58, align 4
  %descriptor.field.59 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.56, i32 0, i32 2
  store i32 %mailbox.input.extent.44, ptr %descriptor.field.59, align 4
  %descriptor.field.60 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.56, i32 0, i32 3
  store i32 %mailbox.input.payload.50, ptr %descriptor.field.60, align 4
  %descriptor.field.61 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.56, i32 0, i32 4
  store i32 %stack.offset.55, ptr %descriptor.field.61, align 4
  %mailbox.input.total.62 = load i32, ptr %mailbox.input.total.pointer.4, align 4
  %mailbox.input.reserve.status.63 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %mailbox.input.total.62, i32 94)
  %helper.ok.64 = icmp eq i32 %mailbox.input.reserve.status.63, 0
  br i1 %helper.ok.64, label %helper.continue.65, label %mailbox.begin.failure.0
helper.continue.65:
  %mailbox.input.copy.status.66 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %mailbox.input.bytes.20, i32 %mailbox.input.extent.22, i32 0, i32 %mailbox.input.payload.28, i32 %mailbox.input.extent.22, i32 5, i32 94)
  %helper.ok.67 = icmp eq i32 %mailbox.input.copy.status.66, 0
  br i1 %helper.ok.67, label %helper.continue.68, label %mailbox.begin.failure.0
helper.continue.68:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 0, i32 20, i32 %mailbox.input.payload.28, i32 %stack.offset.33, i32 %mailbox.input.extent.22)
  %context.field.69 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.70 = load i32, ptr %context.field.69, align 4
  %runtime.ok.71 = icmp eq i32 %context.value.70, 0
  br i1 %runtime.ok.71, label %runtime.continue.72, label %mailbox.begin.failure.0
runtime.continue.72:
  %mailbox.input.copy.status.73 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.33, ptr %mailbox.input.bytes.42, i32 %mailbox.input.extent.44, i32 0, i32 %mailbox.input.payload.50, i32 %mailbox.input.extent.44, i32 6, i32 94)
  %helper.ok.74 = icmp eq i32 %mailbox.input.copy.status.73, 0
  br i1 %helper.ok.74, label %helper.continue.75, label %mailbox.begin.failure.0
helper.continue.75:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %stack.offset.33, i32 20, i32 %mailbox.input.payload.50, i32 %stack.offset.55, i32 %mailbox.input.extent.44)
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %runtime.ok.78 = icmp eq i32 %context.value.77, 0
  br i1 %runtime.ok.78, label %runtime.continue.79, label %mailbox.begin.failure.0
runtime.continue.79:
  %mailbox.frame.status.81 = call i32 @agentlang_mailbox_begin_frame(ptr %ctx, ptr %mailbox.input.descriptors.17, ptr %mailbox.output.descriptors.80, i32 95)
  %helper.ok.82 = icmp eq i32 %mailbox.frame.status.81, 0
  br i1 %helper.ok.82, label %helper.continue.83, label %mailbox.begin.failure.0
helper.continue.83:
  %descriptor.element.84 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.output.descriptors.80, i32 0
  %descriptor.field.85 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.84, i32 0, i32 0
  %descriptor.value.86 = load i32, ptr %descriptor.field.85, align 4
  %descriptor.field.87 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.84, i32 0, i32 1
  %descriptor.value.88 = load i32, ptr %descriptor.field.87, align 4
  %descriptor.field.89 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.84, i32 0, i32 2
  %descriptor.value.90 = load i32, ptr %descriptor.field.89, align 4
  %descriptor.field.91 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.84, i32 0, i32 3
  %descriptor.value.92 = load i32, ptr %descriptor.field.91, align 4
  %descriptor.field.93 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.84, i32 0, i32 4
  %descriptor.value.94 = load i32, ptr %descriptor.field.93, align 4
  %mailbox.output.type.matches.95 = icmp eq i32 %descriptor.value.86, 5
  br i1 %mailbox.output.type.matches.95, label %mailbox.output.type.ok.96, label %mailbox.output.type.invalid.97
mailbox.output.type.invalid.97:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.begin.failure.0
mailbox.output.type.ok.96:
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %stack.sub.102 = sub i32 %descriptor.value.94, %descriptor.value.88
  %descriptor.owner.inside.100 = icmp ule i32 %descriptor.value.94, %context.value.99
  %descriptor.offset.inside.101 = icmp ule i32 %descriptor.value.88, %descriptor.value.94
  %descriptor.extent.inside.103 = icmp ule i32 %descriptor.value.90, %stack.sub.102
  %descriptor.payload.inside.104 = icmp ule i32 %descriptor.value.92, %descriptor.value.90
  %descriptor.owner.offset.valid.105 = and i1 %descriptor.owner.inside.100, %descriptor.offset.inside.101
  %descriptor.range.inside.107 = and i1 %descriptor.owner.offset.valid.105, %descriptor.extent.inside.103
  %descriptor.range.valid.106 = and i1 %descriptor.range.inside.107, %descriptor.payload.inside.104
  %descriptor.type.valid.108 = icmp eq i32 5, 5
  %descriptor.valid.109 = and i1 %descriptor.range.valid.106, %descriptor.type.valid.108
  br i1 %descriptor.valid.109, label %descriptor.valid.110, label %descriptor.invalid.111
descriptor.invalid.111:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.begin.failure.0
descriptor.valid.110:
  %descriptor.initialized.status.112 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.88, i32 %descriptor.value.90)
  %helper.ok.113 = icmp eq i32 %descriptor.initialized.status.112, 0
  br i1 %helper.ok.113, label %helper.continue.114, label %mailbox.begin.failure.0
helper.continue.114:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.88, i32 20, i32 %descriptor.value.92, i32 %descriptor.value.94, i32 %descriptor.value.90)
  %context.field.115 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.116 = load i32, ptr %context.field.115, align 4
  %runtime.ok.117 = icmp eq i32 %context.value.116, 0
  br i1 %runtime.ok.117, label %runtime.continue.118, label %mailbox.begin.failure.0
runtime.continue.118:
  %descriptor.element.119 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.output.descriptors.80, i32 1
  %descriptor.field.120 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.119, i32 0, i32 0
  %descriptor.value.121 = load i32, ptr %descriptor.field.120, align 4
  %descriptor.field.122 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.119, i32 0, i32 1
  %descriptor.value.123 = load i32, ptr %descriptor.field.122, align 4
  %descriptor.field.124 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.119, i32 0, i32 2
  %descriptor.value.125 = load i32, ptr %descriptor.field.124, align 4
  %descriptor.field.126 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.119, i32 0, i32 3
  %descriptor.value.127 = load i32, ptr %descriptor.field.126, align 4
  %descriptor.field.128 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.119, i32 0, i32 4
  %descriptor.value.129 = load i32, ptr %descriptor.field.128, align 4
  %mailbox.output.type.matches.130 = icmp eq i32 %descriptor.value.121, 4
  br i1 %mailbox.output.type.matches.130, label %mailbox.output.type.ok.131, label %mailbox.output.type.invalid.132
mailbox.output.type.invalid.132:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.begin.failure.0
mailbox.output.type.ok.131:
  %context.field.133 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.134 = load i32, ptr %context.field.133, align 4
  %stack.sub.137 = sub i32 %descriptor.value.129, %descriptor.value.123
  %descriptor.owner.inside.135 = icmp ule i32 %descriptor.value.129, %context.value.134
  %descriptor.offset.inside.136 = icmp ule i32 %descriptor.value.123, %descriptor.value.129
  %descriptor.extent.inside.138 = icmp ule i32 %descriptor.value.125, %stack.sub.137
  %descriptor.payload.inside.139 = icmp ule i32 %descriptor.value.127, %descriptor.value.125
  %descriptor.owner.offset.valid.140 = and i1 %descriptor.owner.inside.135, %descriptor.offset.inside.136
  %descriptor.range.inside.142 = and i1 %descriptor.owner.offset.valid.140, %descriptor.extent.inside.138
  %descriptor.range.valid.141 = and i1 %descriptor.range.inside.142, %descriptor.payload.inside.139
  %descriptor.type.valid.143 = icmp eq i32 4, 4
  %descriptor.valid.144 = and i1 %descriptor.range.valid.141, %descriptor.type.valid.143
  br i1 %descriptor.valid.144, label %descriptor.valid.145, label %descriptor.invalid.146
descriptor.invalid.146:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.begin.failure.0
descriptor.valid.145:
  %descriptor.initialized.status.147 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.123, i32 %descriptor.value.125)
  %helper.ok.148 = icmp eq i32 %descriptor.initialized.status.147, 0
  br i1 %helper.ok.148, label %helper.continue.149, label %mailbox.begin.failure.0
helper.continue.149:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %descriptor.value.123, i32 20, i32 %descriptor.value.127, i32 %descriptor.value.129, i32 %descriptor.value.125)
  %context.field.150 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.151 = load i32, ptr %context.field.150, align 4
  %runtime.ok.152 = icmp eq i32 %context.value.151, 0
  br i1 %runtime.ok.152, label %runtime.continue.153, label %mailbox.begin.failure.0
runtime.continue.153:
  %mailbox.output.descriptor.154 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 0
  %mailbox.output.field.155 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.154, i32 0, i32 0
  store i32 3, ptr %mailbox.output.field.155, align 4
  %mailbox.output.field.156 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.154, i32 0, i32 1
  store i32 %descriptor.value.88, ptr %mailbox.output.field.156, align 4
  %mailbox.output.field.157 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.154, i32 0, i32 2
  store i32 %descriptor.value.94, ptr %mailbox.output.field.157, align 4
  %mailbox.output.field.158 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.154, i32 0, i32 3
  store i32 0, ptr %mailbox.output.field.158, align 4
  %mailbox.output.descriptor.159 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 1
  %mailbox.output.field.160 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.159, i32 0, i32 0
  store i32 2, ptr %mailbox.output.field.160, align 4
  %mailbox.output.field.161 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.159, i32 0, i32 1
  store i32 %descriptor.value.123, ptr %mailbox.output.field.161, align 4
  %mailbox.output.field.162 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.159, i32 0, i32 2
  store i32 %descriptor.value.129, ptr %mailbox.output.field.162, align 4
  %mailbox.output.field.163 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.159, i32 0, i32 3
  store i32 0, ptr %mailbox.output.field.163, align 4
  ret i32 0
mailbox.begin.failure.0:
  %mailbox.failure.context.null.164 = icmp eq ptr %ctx, null
  br i1 %mailbox.failure.context.null.164, label %mailbox.failure.null.context.166, label %mailbox.failure.has.context.165
mailbox.failure.null.context.166:
  ret i32 4
mailbox.failure.has.context.165:
  %context.field.168 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.169 = load i32, ptr %context.field.168, align 4
  %mailbox.failure.status.set.170 = icmp ne i32 %context.value.169, 0
  br i1 %mailbox.failure.status.set.170, label %mailbox.failure.status.ready.167, label %mailbox.failure.set.fallback.171
mailbox.failure.set.fallback.171:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 90, i32 0, i32 0)
  br label %mailbox.failure.status.ready.167
mailbox.failure.status.ready.167:
  %context.field.172 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.173 = load i32, ptr %context.field.172, align 4
  ret i32 %context.value.173
}


define i32 @agentlang_mailbox_resume(ptr %ctx, ptr %inputs, i32 %input.count, ptr %outputs, i32 %output.capacity) {
entry:
  %mailbox.input.total.pointer.4 = alloca i32, align 4
  %mailbox.input.descriptors.12 = alloca [3 x %AlOwningDescriptor], align 4
  %mailbox.input.payload.pointer.18 = alloca i32, align 4
  %mailbox.input.measured.extent.pointer.19 = alloca i32, align 4
  %mailbox.input.payload.pointer.40 = alloca i32, align 4
  %mailbox.input.measured.extent.pointer.41 = alloca i32, align 4
  %mailbox.input.payload.pointer.62 = alloca i32, align 4
  %mailbox.input.measured.extent.pointer.63 = alloca i32, align 4
  %mailbox.output.descriptors.104 = alloca [1 x %AlOwningDescriptor], align 4
  %mailbox.context.nonnull.3 = icmp ne ptr %ctx, null
  br i1 %mailbox.context.nonnull.3, label %mailbox.resume.context.valid.1, label %mailbox.resume.failure.0
mailbox.resume.context.valid.1:
  %mailbox.preflight.status.5 = call i32 @agentlang_owning_mailbox_preflight(ptr %ctx, ptr %inputs, i32 %input.count, ptr %outputs, i32 %output.capacity, i32 2, i32 96, i32 97, i32 98, ptr %mailbox.input.total.pointer.4)
  %mailbox.preflight.ok.6 = icmp eq i32 %mailbox.preflight.status.5, 0
  br i1 %mailbox.preflight.ok.6, label %mailbox.resume.preflight.ready.2, label %mailbox.resume.failure.0
mailbox.resume.preflight.ready.2:
  %mailbox.output.descriptor.7 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 0
  %mailbox.output.field.8 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 0
  store i32 4294967295, ptr %mailbox.output.field.8, align 4
  %mailbox.output.field.9 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 1
  store i32 0, ptr %mailbox.output.field.9, align 4
  %mailbox.output.field.10 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 2
  store i32 0, ptr %mailbox.output.field.10, align 4
  %mailbox.output.field.11 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.7, i32 0, i32 3
  store i32 0, ptr %mailbox.output.field.11, align 4
  %mailbox.input.slice.13 = getelementptr inbounds %AlOwningExternalSlice, ptr %inputs, i32 0
  %mailbox.input.bytes.field.14 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.13, i32 0, i32 0
  %mailbox.input.bytes.15 = load ptr, ptr %mailbox.input.bytes.field.14, align 8
  %mailbox.input.extent.field.16 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.13, i32 0, i32 1
  %mailbox.input.extent.17 = load i32, ptr %mailbox.input.extent.field.16, align 4
  %mailbox.input.measure.status.20 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 3, ptr %mailbox.input.bytes.15, i32 %mailbox.input.extent.17, i32 0, i32 99, ptr %mailbox.input.payload.pointer.18, ptr %mailbox.input.measured.extent.pointer.19)
  %helper.ok.21 = icmp eq i32 %mailbox.input.measure.status.20, 0
  br i1 %helper.ok.21, label %helper.continue.22, label %mailbox.resume.failure.0
helper.continue.22:
  %mailbox.input.payload.23 = load i32, ptr %mailbox.input.payload.pointer.18, align 4
  %mailbox.input.measured.extent.24 = load i32, ptr %mailbox.input.measured.extent.pointer.19, align 4
  %mailbox.input.extent.exact.25 = icmp eq i32 %mailbox.input.measured.extent.24, %mailbox.input.extent.17
  br i1 %mailbox.input.extent.exact.25, label %mailbox.input.extent.ok.26, label %mailbox.input.extent.invalid.27
mailbox.input.extent.invalid.27:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 99, i32 %mailbox.input.measured.extent.24, i32 %mailbox.input.extent.17)
  br label %mailbox.resume.failure.0
mailbox.input.extent.ok.26:
  %stack.offset.28 = add i32 0, %mailbox.input.extent.17
  %descriptor.element.29 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.input.descriptors.12, i32 0
  %descriptor.field.30 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 0
  store i32 5, ptr %descriptor.field.30, align 4
  %descriptor.field.31 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 1
  store i32 0, ptr %descriptor.field.31, align 4
  %descriptor.field.32 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 2
  store i32 %mailbox.input.extent.17, ptr %descriptor.field.32, align 4
  %descriptor.field.33 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 3
  store i32 %mailbox.input.payload.23, ptr %descriptor.field.33, align 4
  %descriptor.field.34 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.29, i32 0, i32 4
  store i32 %stack.offset.28, ptr %descriptor.field.34, align 4
  %mailbox.input.slice.35 = getelementptr inbounds %AlOwningExternalSlice, ptr %inputs, i32 1
  %mailbox.input.bytes.field.36 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.35, i32 0, i32 0
  %mailbox.input.bytes.37 = load ptr, ptr %mailbox.input.bytes.field.36, align 8
  %mailbox.input.extent.field.38 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.35, i32 0, i32 1
  %mailbox.input.extent.39 = load i32, ptr %mailbox.input.extent.field.38, align 4
  %mailbox.input.measure.status.42 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 2, ptr %mailbox.input.bytes.37, i32 %mailbox.input.extent.39, i32 0, i32 99, ptr %mailbox.input.payload.pointer.40, ptr %mailbox.input.measured.extent.pointer.41)
  %helper.ok.43 = icmp eq i32 %mailbox.input.measure.status.42, 0
  br i1 %helper.ok.43, label %helper.continue.44, label %mailbox.resume.failure.0
helper.continue.44:
  %mailbox.input.payload.45 = load i32, ptr %mailbox.input.payload.pointer.40, align 4
  %mailbox.input.measured.extent.46 = load i32, ptr %mailbox.input.measured.extent.pointer.41, align 4
  %mailbox.input.extent.exact.47 = icmp eq i32 %mailbox.input.measured.extent.46, %mailbox.input.extent.39
  br i1 %mailbox.input.extent.exact.47, label %mailbox.input.extent.ok.48, label %mailbox.input.extent.invalid.49
mailbox.input.extent.invalid.49:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 99, i32 %mailbox.input.measured.extent.46, i32 %mailbox.input.extent.39)
  br label %mailbox.resume.failure.0
mailbox.input.extent.ok.48:
  %stack.offset.50 = add i32 %stack.offset.28, %mailbox.input.extent.39
  %descriptor.element.51 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.input.descriptors.12, i32 1
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.51, i32 0, i32 0
  store i32 4, ptr %descriptor.field.52, align 4
  %descriptor.field.53 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.51, i32 0, i32 1
  store i32 %stack.offset.28, ptr %descriptor.field.53, align 4
  %descriptor.field.54 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.51, i32 0, i32 2
  store i32 %mailbox.input.extent.39, ptr %descriptor.field.54, align 4
  %descriptor.field.55 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.51, i32 0, i32 3
  store i32 %mailbox.input.payload.45, ptr %descriptor.field.55, align 4
  %descriptor.field.56 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.51, i32 0, i32 4
  store i32 %stack.offset.50, ptr %descriptor.field.56, align 4
  %mailbox.input.slice.57 = getelementptr inbounds %AlOwningExternalSlice, ptr %inputs, i32 2
  %mailbox.input.bytes.field.58 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.57, i32 0, i32 0
  %mailbox.input.bytes.59 = load ptr, ptr %mailbox.input.bytes.field.58, align 8
  %mailbox.input.extent.field.60 = getelementptr inbounds %AlOwningExternalSlice, ptr %mailbox.input.slice.57, i32 0, i32 1
  %mailbox.input.extent.61 = load i32, ptr %mailbox.input.extent.field.60, align 4
  %mailbox.input.measure.status.64 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 4, ptr %mailbox.input.bytes.59, i32 %mailbox.input.extent.61, i32 0, i32 99, ptr %mailbox.input.payload.pointer.62, ptr %mailbox.input.measured.extent.pointer.63)
  %helper.ok.65 = icmp eq i32 %mailbox.input.measure.status.64, 0
  br i1 %helper.ok.65, label %helper.continue.66, label %mailbox.resume.failure.0
helper.continue.66:
  %mailbox.input.payload.67 = load i32, ptr %mailbox.input.payload.pointer.62, align 4
  %mailbox.input.measured.extent.68 = load i32, ptr %mailbox.input.measured.extent.pointer.63, align 4
  %mailbox.input.extent.exact.69 = icmp eq i32 %mailbox.input.measured.extent.68, %mailbox.input.extent.61
  br i1 %mailbox.input.extent.exact.69, label %mailbox.input.extent.ok.70, label %mailbox.input.extent.invalid.71
mailbox.input.extent.invalid.71:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 99, i32 %mailbox.input.measured.extent.68, i32 %mailbox.input.extent.61)
  br label %mailbox.resume.failure.0
mailbox.input.extent.ok.70:
  %stack.offset.72 = add i32 %stack.offset.50, %mailbox.input.extent.61
  %descriptor.element.73 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.input.descriptors.12, i32 2
  %descriptor.field.74 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 0
  store i32 6, ptr %descriptor.field.74, align 4
  %descriptor.field.75 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 1
  store i32 %stack.offset.50, ptr %descriptor.field.75, align 4
  %descriptor.field.76 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 2
  store i32 %mailbox.input.extent.61, ptr %descriptor.field.76, align 4
  %descriptor.field.77 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 3
  store i32 %mailbox.input.payload.67, ptr %descriptor.field.77, align 4
  %descriptor.field.78 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 4
  store i32 %stack.offset.72, ptr %descriptor.field.78, align 4
  %mailbox.input.total.79 = load i32, ptr %mailbox.input.total.pointer.4, align 4
  %mailbox.input.reserve.status.80 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %mailbox.input.total.79, i32 100)
  %helper.ok.81 = icmp eq i32 %mailbox.input.reserve.status.80, 0
  br i1 %helper.ok.81, label %helper.continue.82, label %mailbox.resume.failure.0
helper.continue.82:
  %mailbox.input.copy.status.83 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %mailbox.input.bytes.15, i32 %mailbox.input.extent.17, i32 0, i32 %mailbox.input.payload.23, i32 %mailbox.input.extent.17, i32 5, i32 100)
  %helper.ok.84 = icmp eq i32 %mailbox.input.copy.status.83, 0
  br i1 %helper.ok.84, label %helper.continue.85, label %mailbox.resume.failure.0
helper.continue.85:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 0, i32 20, i32 %mailbox.input.payload.23, i32 %stack.offset.28, i32 %mailbox.input.extent.17)
  %context.field.86 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.87 = load i32, ptr %context.field.86, align 4
  %runtime.ok.88 = icmp eq i32 %context.value.87, 0
  br i1 %runtime.ok.88, label %runtime.continue.89, label %mailbox.resume.failure.0
runtime.continue.89:
  %mailbox.input.copy.status.90 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.28, ptr %mailbox.input.bytes.37, i32 %mailbox.input.extent.39, i32 0, i32 %mailbox.input.payload.45, i32 %mailbox.input.extent.39, i32 4, i32 100)
  %helper.ok.91 = icmp eq i32 %mailbox.input.copy.status.90, 0
  br i1 %helper.ok.91, label %helper.continue.92, label %mailbox.resume.failure.0
helper.continue.92:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %stack.offset.28, i32 20, i32 %mailbox.input.payload.45, i32 %stack.offset.50, i32 %mailbox.input.extent.39)
  %context.field.93 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.94 = load i32, ptr %context.field.93, align 4
  %runtime.ok.95 = icmp eq i32 %context.value.94, 0
  br i1 %runtime.ok.95, label %runtime.continue.96, label %mailbox.resume.failure.0
runtime.continue.96:
  %mailbox.input.copy.status.97 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.50, ptr %mailbox.input.bytes.59, i32 %mailbox.input.extent.61, i32 0, i32 %mailbox.input.payload.67, i32 %mailbox.input.extent.61, i32 6, i32 100)
  %helper.ok.98 = icmp eq i32 %mailbox.input.copy.status.97, 0
  br i1 %helper.ok.98, label %helper.continue.99, label %mailbox.resume.failure.0
helper.continue.99:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %stack.offset.50, i32 20, i32 %mailbox.input.payload.67, i32 %stack.offset.72, i32 %mailbox.input.extent.61)
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %runtime.ok.102 = icmp eq i32 %context.value.101, 0
  br i1 %runtime.ok.102, label %runtime.continue.103, label %mailbox.resume.failure.0
runtime.continue.103:
  %mailbox.frame.status.105 = call i32 @agentlang_mailbox_resume_frame(ptr %ctx, ptr %mailbox.input.descriptors.12, ptr %mailbox.output.descriptors.104, i32 101)
  %helper.ok.106 = icmp eq i32 %mailbox.frame.status.105, 0
  br i1 %helper.ok.106, label %helper.continue.107, label %mailbox.resume.failure.0
helper.continue.107:
  %descriptor.element.108 = getelementptr inbounds %AlOwningDescriptor, ptr %mailbox.output.descriptors.104, i32 0
  %descriptor.field.109 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.108, i32 0, i32 0
  %descriptor.value.110 = load i32, ptr %descriptor.field.109, align 4
  %descriptor.field.111 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.108, i32 0, i32 1
  %descriptor.value.112 = load i32, ptr %descriptor.field.111, align 4
  %descriptor.field.113 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.108, i32 0, i32 2
  %descriptor.value.114 = load i32, ptr %descriptor.field.113, align 4
  %descriptor.field.115 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.108, i32 0, i32 3
  %descriptor.value.116 = load i32, ptr %descriptor.field.115, align 4
  %descriptor.field.117 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.108, i32 0, i32 4
  %descriptor.value.118 = load i32, ptr %descriptor.field.117, align 4
  %mailbox.output.type.matches.119 = icmp eq i32 %descriptor.value.110, 5
  br i1 %mailbox.output.type.matches.119, label %mailbox.output.type.ok.120, label %mailbox.output.type.invalid.121
mailbox.output.type.invalid.121:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.resume.failure.0
mailbox.output.type.ok.120:
  %context.field.122 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.123 = load i32, ptr %context.field.122, align 4
  %stack.sub.126 = sub i32 %descriptor.value.118, %descriptor.value.112
  %descriptor.owner.inside.124 = icmp ule i32 %descriptor.value.118, %context.value.123
  %descriptor.offset.inside.125 = icmp ule i32 %descriptor.value.112, %descriptor.value.118
  %descriptor.extent.inside.127 = icmp ule i32 %descriptor.value.114, %stack.sub.126
  %descriptor.payload.inside.128 = icmp ule i32 %descriptor.value.116, %descriptor.value.114
  %descriptor.owner.offset.valid.129 = and i1 %descriptor.owner.inside.124, %descriptor.offset.inside.125
  %descriptor.range.inside.131 = and i1 %descriptor.owner.offset.valid.129, %descriptor.extent.inside.127
  %descriptor.range.valid.130 = and i1 %descriptor.range.inside.131, %descriptor.payload.inside.128
  %descriptor.type.valid.132 = icmp eq i32 5, 5
  %descriptor.valid.133 = and i1 %descriptor.range.valid.130, %descriptor.type.valid.132
  br i1 %descriptor.valid.133, label %descriptor.valid.134, label %descriptor.invalid.135
descriptor.invalid.135:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %mailbox.resume.failure.0
descriptor.valid.134:
  %descriptor.initialized.status.136 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.112, i32 %descriptor.value.114)
  %helper.ok.137 = icmp eq i32 %descriptor.initialized.status.136, 0
  br i1 %helper.ok.137, label %helper.continue.138, label %mailbox.resume.failure.0
helper.continue.138:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.112, i32 20, i32 %descriptor.value.116, i32 %descriptor.value.118, i32 %descriptor.value.114)
  %context.field.139 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.140 = load i32, ptr %context.field.139, align 4
  %runtime.ok.141 = icmp eq i32 %context.value.140, 0
  br i1 %runtime.ok.141, label %runtime.continue.142, label %mailbox.resume.failure.0
runtime.continue.142:
  %mailbox.output.descriptor.143 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 0
  %mailbox.output.field.144 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.143, i32 0, i32 0
  store i32 3, ptr %mailbox.output.field.144, align 4
  %mailbox.output.field.145 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.143, i32 0, i32 1
  store i32 %descriptor.value.112, ptr %mailbox.output.field.145, align 4
  %mailbox.output.field.146 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.143, i32 0, i32 2
  store i32 %descriptor.value.118, ptr %mailbox.output.field.146, align 4
  %mailbox.output.field.147 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %mailbox.output.descriptor.143, i32 0, i32 3
  store i32 0, ptr %mailbox.output.field.147, align 4
  ret i32 0
mailbox.resume.failure.0:
  %mailbox.failure.context.null.148 = icmp eq ptr %ctx, null
  br i1 %mailbox.failure.context.null.148, label %mailbox.failure.null.context.150, label %mailbox.failure.has.context.149
mailbox.failure.null.context.150:
  ret i32 4
mailbox.failure.has.context.149:
  %context.field.152 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.153 = load i32, ptr %context.field.152, align 4
  %mailbox.failure.status.set.154 = icmp ne i32 %context.value.153, 0
  br i1 %mailbox.failure.status.set.154, label %mailbox.failure.status.ready.151, label %mailbox.failure.set.fallback.155
mailbox.failure.set.fallback.155:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 96, i32 0, i32 0)
  br label %mailbox.failure.status.ready.151
mailbox.failure.status.ready.151:
  %context.field.156 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.157 = load i32, ptr %context.field.156, align 4
  ret i32 %context.value.157
}


define i32 @agentlang_mailbox_resume_associated(ptr %ctx, ptr %retained.inputs, i32 %retained.count, ptr %completion, i32 %protected.cursor, ptr %outputs, i32 %output.capacity) {
entry:
  %associated.resume.input.descriptors.12 = alloca [3 x %AlOwningDescriptor], align 4
  %associated.resume.retained.value.size.18 = alloca %AlOwningValueSize, align 4
  %associated.resume.retained.value.size.41 = alloca %AlOwningValueSize, align 4
  %associated.resume.completion.payload.pointer.63 = alloca i32, align 4
  %associated.resume.completion.measured.extent.pointer.64 = alloca i32, align 4
  %associated.resume.output.descriptors.92 = alloca [1 x %AlOwningDescriptor], align 4
  %associated.resume.context.nonnull.3 = icmp ne ptr %ctx, null
  br i1 %associated.resume.context.nonnull.3, label %associated.resume.context.valid.1, label %associated.resume.failure.0
associated.resume.context.valid.1:
  %associated.resume.preflight.status.4 = call i32 @agentlang_owning_mailbox_associated_preflight(ptr %ctx, ptr %retained.inputs, i32 %retained.count, ptr %completion, i32 %protected.cursor, ptr %outputs, i32 %output.capacity, i32 102, i32 103, i32 104)
  %associated.resume.preflight.ok.5 = icmp eq i32 %associated.resume.preflight.status.4, 0
  br i1 %associated.resume.preflight.ok.5, label %associated.resume.preflight.ready.2, label %associated.resume.failure.0
associated.resume.preflight.ready.2:
  %associated.resume.output.descriptor.6 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %outputs, i32 0
  %associated.resume.output.field.7 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.output.descriptor.6, i32 0, i32 0
  store i32 4294967295, ptr %associated.resume.output.field.7, align 4
  %associated.resume.output.field.8 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.output.descriptor.6, i32 0, i32 1
  store i32 0, ptr %associated.resume.output.field.8, align 4
  %associated.resume.output.field.9 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.output.descriptor.6, i32 0, i32 2
  store i32 0, ptr %associated.resume.output.field.9, align 4
  %associated.resume.output.field.10 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.output.descriptor.6, i32 0, i32 3
  store i32 0, ptr %associated.resume.output.field.10, align 4
  %context.field.11 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 10
  store i32 0, ptr %context.field.11, align 4
  %associated.resume.retained.slice.13 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %retained.inputs, i32 0
  %associated.resume.retained.offset.pointer.14 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.retained.slice.13, i32 0, i32 1
  %associated.resume.retained.offset.pointer.value.15 = load i32, ptr %associated.resume.retained.offset.pointer.14, align 4
  %associated.resume.retained.owner.end.pointer.16 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.retained.slice.13, i32 0, i32 2
  %associated.resume.retained.owner.end.pointer.value.17 = load i32, ptr %associated.resume.retained.owner.end.pointer.16, align 4
  %associated.resume.retained.measure.status.19 = call i32 @al_owning_measure_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 3, i32 %associated.resume.retained.offset.pointer.value.15, i32 %associated.resume.retained.owner.end.pointer.value.17, i32 105, ptr %associated.resume.retained.value.size.18)
  %helper.ok.20 = icmp eq i32 %associated.resume.retained.measure.status.19, 0
  br i1 %helper.ok.20, label %helper.continue.21, label %associated.resume.failure.0
helper.continue.21:
  %associated.resume.retained.payload.pointer.22 = getelementptr inbounds %AlOwningValueSize, ptr %associated.resume.retained.value.size.18, i32 0, i32 0
  %associated.resume.retained.extent.pointer.23 = getelementptr inbounds %AlOwningValueSize, ptr %associated.resume.retained.value.size.18, i32 0, i32 1
  %associated.resume.retained.payload.24 = load i32, ptr %associated.resume.retained.payload.pointer.22, align 4
  %associated.resume.retained.extent.25 = load i32, ptr %associated.resume.retained.extent.pointer.23, align 4
  %descriptor.element.26 = getelementptr inbounds %AlOwningDescriptor, ptr %associated.resume.input.descriptors.12, i32 0
  %descriptor.field.27 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.26, i32 0, i32 0
  store i32 5, ptr %descriptor.field.27, align 4
  %descriptor.field.28 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.26, i32 0, i32 1
  store i32 %associated.resume.retained.offset.pointer.value.15, ptr %descriptor.field.28, align 4
  %descriptor.field.29 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.26, i32 0, i32 2
  store i32 %associated.resume.retained.extent.25, ptr %descriptor.field.29, align 4
  %descriptor.field.30 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.26, i32 0, i32 3
  store i32 %associated.resume.retained.payload.24, ptr %descriptor.field.30, align 4
  %descriptor.field.31 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.26, i32 0, i32 4
  store i32 %associated.resume.retained.owner.end.pointer.value.17, ptr %descriptor.field.31, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %associated.resume.retained.offset.pointer.value.15, i32 20, i32 %associated.resume.retained.payload.24, i32 %associated.resume.retained.owner.end.pointer.value.17, i32 %associated.resume.retained.extent.25)
  %context.field.32 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.33 = load i32, ptr %context.field.32, align 4
  %runtime.ok.34 = icmp eq i32 %context.value.33, 0
  br i1 %runtime.ok.34, label %runtime.continue.35, label %associated.resume.failure.0
runtime.continue.35:
  %associated.resume.retained.slice.36 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %retained.inputs, i32 1
  %associated.resume.retained.offset.pointer.37 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.retained.slice.36, i32 0, i32 1
  %associated.resume.retained.offset.pointer.value.38 = load i32, ptr %associated.resume.retained.offset.pointer.37, align 4
  %associated.resume.retained.owner.end.pointer.39 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.retained.slice.36, i32 0, i32 2
  %associated.resume.retained.owner.end.pointer.value.40 = load i32, ptr %associated.resume.retained.owner.end.pointer.39, align 4
  %associated.resume.retained.measure.status.42 = call i32 @al_owning_measure_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 2, i32 %associated.resume.retained.offset.pointer.value.38, i32 %associated.resume.retained.owner.end.pointer.value.40, i32 105, ptr %associated.resume.retained.value.size.41)
  %helper.ok.43 = icmp eq i32 %associated.resume.retained.measure.status.42, 0
  br i1 %helper.ok.43, label %helper.continue.44, label %associated.resume.failure.0
helper.continue.44:
  %associated.resume.retained.payload.pointer.45 = getelementptr inbounds %AlOwningValueSize, ptr %associated.resume.retained.value.size.41, i32 0, i32 0
  %associated.resume.retained.extent.pointer.46 = getelementptr inbounds %AlOwningValueSize, ptr %associated.resume.retained.value.size.41, i32 0, i32 1
  %associated.resume.retained.payload.47 = load i32, ptr %associated.resume.retained.payload.pointer.45, align 4
  %associated.resume.retained.extent.48 = load i32, ptr %associated.resume.retained.extent.pointer.46, align 4
  %descriptor.element.49 = getelementptr inbounds %AlOwningDescriptor, ptr %associated.resume.input.descriptors.12, i32 1
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 0
  store i32 4, ptr %descriptor.field.50, align 4
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 1
  store i32 %associated.resume.retained.offset.pointer.value.38, ptr %descriptor.field.51, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 2
  store i32 %associated.resume.retained.extent.48, ptr %descriptor.field.52, align 4
  %descriptor.field.53 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 3
  store i32 %associated.resume.retained.payload.47, ptr %descriptor.field.53, align 4
  %descriptor.field.54 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 4
  store i32 %associated.resume.retained.owner.end.pointer.value.40, ptr %descriptor.field.54, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %associated.resume.retained.offset.pointer.value.38, i32 20, i32 %associated.resume.retained.payload.47, i32 %associated.resume.retained.owner.end.pointer.value.40, i32 %associated.resume.retained.extent.48)
  %context.field.55 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.56 = load i32, ptr %context.field.55, align 4
  %runtime.ok.57 = icmp eq i32 %context.value.56, 0
  br i1 %runtime.ok.57, label %runtime.continue.58, label %associated.resume.failure.0
runtime.continue.58:
  %associated.resume.completion.bytes.pointer.59 = getelementptr inbounds %AlOwningExternalSlice, ptr %completion, i32 0, i32 0
  %associated.resume.completion.bytes.60 = load ptr, ptr %associated.resume.completion.bytes.pointer.59, align 8
  %associated.resume.completion.extent.pointer.61 = getelementptr inbounds %AlOwningExternalSlice, ptr %completion, i32 0, i32 1
  %associated.resume.completion.extent.62 = load i32, ptr %associated.resume.completion.extent.pointer.61, align 4
  %associated.resume.completion.measure.status.65 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @agentlang_owning_mailbox_layout, i32 4, ptr %associated.resume.completion.bytes.60, i32 %associated.resume.completion.extent.62, i32 0, i32 105, ptr %associated.resume.completion.payload.pointer.63, ptr %associated.resume.completion.measured.extent.pointer.64)
  %helper.ok.66 = icmp eq i32 %associated.resume.completion.measure.status.65, 0
  br i1 %helper.ok.66, label %helper.continue.67, label %associated.resume.failure.0
helper.continue.67:
  %associated.resume.completion.payload.68 = load i32, ptr %associated.resume.completion.payload.pointer.63, align 4
  %associated.resume.completion.measured.extent.69 = load i32, ptr %associated.resume.completion.measured.extent.pointer.64, align 4
  %associated.resume.completion.extent.matches.70 = icmp eq i32 %associated.resume.completion.measured.extent.69, %associated.resume.completion.extent.62
  br i1 %associated.resume.completion.extent.matches.70, label %associated.resume.completion.extent.ok.71, label %associated.resume.failure.0
associated.resume.completion.extent.ok.71:
  %context.field.72 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.73 = load i32, ptr %context.field.72, align 4
  %stack.offset.74 = add i32 %context.value.73, %associated.resume.completion.extent.62
  %reserve.status.75 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.74, i32 106)
  %reserve.ok.76 = icmp eq i32 %reserve.status.75, 0
  br i1 %reserve.ok.76, label %reserve.continue.77, label %associated.resume.failure.0
reserve.continue.77:
  %associated.resume.completion.copy.status.78 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %context.value.73, ptr %associated.resume.completion.bytes.60, i32 %associated.resume.completion.extent.62, i32 0, i32 %associated.resume.completion.payload.68, i32 %associated.resume.completion.extent.62, i32 6, i32 106)
  %helper.ok.79 = icmp eq i32 %associated.resume.completion.copy.status.78, 0
  br i1 %helper.ok.79, label %helper.continue.80, label %associated.resume.failure.0
helper.continue.80:
  %stack.offset.81 = add i32 %context.value.73, %associated.resume.completion.extent.62
  %descriptor.element.82 = getelementptr inbounds %AlOwningDescriptor, ptr %associated.resume.input.descriptors.12, i32 2
  %descriptor.field.83 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.82, i32 0, i32 0
  store i32 6, ptr %descriptor.field.83, align 4
  %descriptor.field.84 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.82, i32 0, i32 1
  store i32 %context.value.73, ptr %descriptor.field.84, align 4
  %descriptor.field.85 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.82, i32 0, i32 2
  store i32 %associated.resume.completion.extent.62, ptr %descriptor.field.85, align 4
  %descriptor.field.86 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.82, i32 0, i32 3
  store i32 %associated.resume.completion.payload.68, ptr %descriptor.field.86, align 4
  %descriptor.field.87 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.82, i32 0, i32 4
  store i32 %stack.offset.81, ptr %descriptor.field.87, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %context.value.73, i32 20, i32 %associated.resume.completion.payload.68, i32 %stack.offset.81, i32 %associated.resume.completion.extent.62)
  %context.field.88 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.89 = load i32, ptr %context.field.88, align 4
  %runtime.ok.90 = icmp eq i32 %context.value.89, 0
  br i1 %runtime.ok.90, label %runtime.continue.91, label %associated.resume.failure.0
runtime.continue.91:
  %associated.resume.frame.status.93 = call i32 @agentlang_mailbox_resume_frame(ptr %ctx, ptr %associated.resume.input.descriptors.12, ptr %associated.resume.output.descriptors.92, i32 107)
  %helper.ok.94 = icmp eq i32 %associated.resume.frame.status.93, 0
  br i1 %helper.ok.94, label %helper.continue.95, label %associated.resume.failure.0
helper.continue.95:
  %descriptor.element.96 = getelementptr inbounds %AlOwningDescriptor, ptr %associated.resume.output.descriptors.92, i32 0
  %descriptor.field.97 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.96, i32 0, i32 0
  %descriptor.value.98 = load i32, ptr %descriptor.field.97, align 4
  %descriptor.field.99 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.96, i32 0, i32 1
  %descriptor.value.100 = load i32, ptr %descriptor.field.99, align 4
  %descriptor.field.101 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.96, i32 0, i32 2
  %descriptor.value.102 = load i32, ptr %descriptor.field.101, align 4
  %descriptor.field.103 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.96, i32 0, i32 3
  %descriptor.value.104 = load i32, ptr %descriptor.field.103, align 4
  %descriptor.field.105 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.96, i32 0, i32 4
  %descriptor.value.106 = load i32, ptr %descriptor.field.105, align 4
  %associated.resume.output.type.matches.107 = icmp eq i32 %descriptor.value.98, 5
  br i1 %associated.resume.output.type.matches.107, label %associated.resume.output.type.ok.108, label %associated.resume.failure.0
associated.resume.output.type.ok.108:
  %context.field.109 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.110 = load i32, ptr %context.field.109, align 4
  %stack.sub.113 = sub i32 %descriptor.value.106, %descriptor.value.100
  %descriptor.owner.inside.111 = icmp ule i32 %descriptor.value.106, %context.value.110
  %descriptor.offset.inside.112 = icmp ule i32 %descriptor.value.100, %descriptor.value.106
  %descriptor.extent.inside.114 = icmp ule i32 %descriptor.value.102, %stack.sub.113
  %descriptor.payload.inside.115 = icmp ule i32 %descriptor.value.104, %descriptor.value.102
  %descriptor.owner.offset.valid.116 = and i1 %descriptor.owner.inside.111, %descriptor.offset.inside.112
  %descriptor.range.inside.118 = and i1 %descriptor.owner.offset.valid.116, %descriptor.extent.inside.114
  %descriptor.range.valid.117 = and i1 %descriptor.range.inside.118, %descriptor.payload.inside.115
  %descriptor.type.valid.119 = icmp eq i32 5, 5
  %descriptor.valid.120 = and i1 %descriptor.range.valid.117, %descriptor.type.valid.119
  br i1 %descriptor.valid.120, label %descriptor.valid.121, label %descriptor.invalid.122
descriptor.invalid.122:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %associated.resume.failure.0
descriptor.valid.121:
  %descriptor.initialized.status.123 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.100, i32 %descriptor.value.102)
  %helper.ok.124 = icmp eq i32 %descriptor.initialized.status.123, 0
  br i1 %helper.ok.124, label %helper.continue.125, label %associated.resume.failure.0
helper.continue.125:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.100, i32 20, i32 %descriptor.value.104, i32 %descriptor.value.106, i32 %descriptor.value.102)
  %context.field.126 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.127 = load i32, ptr %context.field.126, align 4
  %runtime.ok.128 = icmp eq i32 %context.value.127, 0
  br i1 %runtime.ok.128, label %runtime.continue.129, label %associated.resume.failure.0
runtime.continue.129:
  %associated.resume.output.field.130 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.output.descriptor.6, i32 0, i32 0
  store i32 3, ptr %associated.resume.output.field.130, align 4
  %associated.resume.output.field.131 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.output.descriptor.6, i32 0, i32 1
  store i32 %descriptor.value.100, ptr %associated.resume.output.field.131, align 4
  %associated.resume.output.field.132 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.output.descriptor.6, i32 0, i32 2
  store i32 %descriptor.value.106, ptr %associated.resume.output.field.132, align 4
  %associated.resume.output.field.133 = getelementptr inbounds %AlOwningMailboxOutputSlice, ptr %associated.resume.output.descriptor.6, i32 0, i32 3
  store i32 0, ptr %associated.resume.output.field.133, align 4
  ret i32 0
associated.resume.failure.0:
  %associated.resume.failure.context.null.134 = icmp eq ptr %ctx, null
  br i1 %associated.resume.failure.context.null.134, label %associated.resume.failure.null.context.136, label %associated.resume.failure.has.context.135
associated.resume.failure.null.context.136:
  ret i32 4
associated.resume.failure.has.context.135:
  %context.field.138 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.139 = load i32, ptr %context.field.138, align 4
  %associated.resume.failure.status.set.140 = icmp ne i32 %context.value.139, 0
  br i1 %associated.resume.failure.status.set.140, label %associated.resume.failure.status.ready.137, label %associated.resume.failure.set.fallback.141
associated.resume.failure.set.fallback.141:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 102, i32 0, i32 0)
  br label %associated.resume.failure.status.ready.137
associated.resume.failure.status.ready.137:
  %context.field.142 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.143 = load i32, ptr %context.field.142, align 4
  ret i32 %context.value.143
}



# Next native room-read milestone

Independent read-only planning by Luna/max, 2026-10-12.

Add a closed `CampfireRoomReadV1` host profile for the compiler-minted
`campfire.http.room-read` entry. Preserve the existing room-find-only profile and
adapter. Pin the exact entry signature, nine reachable operations, their effects,
and nominal boundary schemas. Use compile-time operation tags with typed input
descriptors and one statically linked trusted dispatcher; request data cannot
select arbitrary host operations.

Implement cookie verification, session lookup/conditional refresh, user lookup/bot
authentication, browser comparison, room membership lookup, membership existence,
and the last-message page. Keep language policy in the existing shared helpers.
SQL uses a worker-owned connection and reusable prepared statements, with no SQL
mailbox hop. The last page is at most 40 rows, newest selected then oldest-first
returned. Set and test a separate output byte bound; reject oversized output
atomically, without truncating a valid page silently.

Cookie parity requires the existing PBKDF2-SHA256/HMAC-SHA1 Rails envelope,
purpose/expiry handling and legacy fallback. Browser parity requires the existing
RubyVersion comparison behavior. Use narrow established native/OS crypto APIs.

Affected files: OwningStackAot.fs; new native campfire_room_read_host_abi.h;
new applications/campfire/Native/room_read_adapter.c/.h; profile tests in
NativeHostTests.fs; integration in RoomReadEntryTests.fs and NativeSqliteTests.fs;
standalone native C smoke harness; dedicated local verification script.

Acceptance: O0/O2 full typed request/response execution; exact-profile admission
and rejection tests; old-profile gates unchanged; parity for cookies/session
refresh/bot fallback/browser/member and nonmember rooms; empty/Unicode/40-row
message lists; over-cap/malformed output rollback; statement recovery and thread
ownership; standalone no-CLR executable.

Then connect the entry to native HTTP parsing/rendering, response cookie signing,
GET/HEAD parity and loopback endpoint tests. Only then measure single worker and
one-of-X worker request throughput and memory under the required workloads.

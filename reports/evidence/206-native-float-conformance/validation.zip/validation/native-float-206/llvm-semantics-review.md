# Native Float 206 LLVM semantics review

Status: source-only review; no blocking source mismatch found.

Reviewed against `reports/205-native-float-implementation-plan.md`. The two
managed source files match `.agentlang/native-float-206/llvm/source-freeze.json`:

- `OwningStackAot.fs`: `2ab39b893343b7a698ab145cf4815b8b113e85b2a3641c4bed51e6b79f3f6d0a`
- `LlvmAot.fs`: `efaf238d55167d2870c5eebd2b67a77759224fdd69bacbac0d0a266765ce9c80`

The native runtime files also match the candidate snapshot hashes supplied by
the native worker. This review ran no build or test commands, as requested.

## Findings

- Fixed and dynamic lowering use the same strict operation choices: `fadd`,
  `fsub`, `fmul`, and `fdiv` have no fast-math flags; the comparisons use
  ordered predicates. Division checks the denominator with ordered equality to
  zero before `fdiv`, which catches both signed zeros and gives `0.0 / 0.0` the
  interpreter's divide-by-zero result. Successful values are stored by their
  bit pattern, preserving signed zero.
- Both arithmetic paths inspect the result exponent bits and reject exponent
  all-ones results, while accepting finite subnormals and underflowed zero.
  Their `RUNTIME_NONFINITE_FLOAT` entries use the operation name, no source
  span, and the dynamic-Actual marker. `diagnosticForError` reconstructs Actual
  by converting those bits back to `double` and using the same F# `string`
  formatting path as the interpreter.
- Both `float.to-int` paths branch on ordered comparisons for the half-open
  interval `[-2^63, 2^63)` before executing `fptosi`. NaN fails those ordered
  comparisons, and external/non-native Float data is independently rejected
  by the finite scanner. The `float.round` paths use `llvm.round.f64` (ties
  away from zero), check the rounded value against the same interval, and only
  then execute `fptosi`. On every conversion failure they save the original
  input bits, matching the interpreter's Actual value. `int.to-float` uses
  signed `sitofp`.
- The appended diagnostic field is consistent across the managed struct, the
  generated `%AlOwningContext`, and the native context struct: indices 0–24
  are 25 `i32` fields, indices 25–28 are pointers, and indices 29–33 are
  `i64`; field 33 is `DiagnosticFloatBits` / `diagnostic_float_bits` at byte
  offset 168. The resulting context size is 176 bytes with the declared
  packing. `al_owning_begin` clears it, and `al_owning_set_failure` clears it
  only while recording the first failure. Generated Float diagnostic paths
  write the payload after recording that failure; cleanup/unwind failures
  cannot replace the first status or erase the payload. Mailbox scratch
  checkout also initializes the field.
- Fixed and dynamic `equals` call `al_owning_equal_typed` with the verified
  type index and exact operand offsets/extents, then check context status
  immediately before consuming its Boolean result. The helper bounds and
  pre-scans both operands, rejects malformed descriptor/sum data through the
  supplied error ID, checks recursion depth and offset/extent arithmetic, and
  compares Float values numerically with an explicit signed-zero case. Empty
  records are accepted only at their scanned eight-byte token extent and
  compare equal; active sum payloads and record fields are compared by declared
  child types. The status check in both emitters prevents a malformed-data
  failure from being mistaken for `false`.
- `LlvmAot.fs` rejects any `FloatArgument` with the structured
  `IR_BACKEND_ENTRY_ARGUMENT_UNSUPPORTED` diagnostic before converting entry
  arguments or entering native execution. This keeps the shared-graph ABI-v3
  backend outside the Float implementation scope.

## Validation limits

This is a source review, not runtime evidence. The planned LLVM/native build,
O0/O2 parity tests, diagnostic/fuel checks, and independent verifier scripts
remain necessary before claiming milestone acceptance.

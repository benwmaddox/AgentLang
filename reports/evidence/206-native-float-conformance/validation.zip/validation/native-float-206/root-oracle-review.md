# Native Float root-oracle source review

Review date: 2026-10-11  
Scope: source-only review of the native value-stack runner, verifier, fixtures, and the two mailbox C runners. No build or native execution was performed. This review is not a freeze; the integration work is still changing in parallel.

## Findings

- The appended `diagnostic_float_bits` context field is represented consistently in the runner and fixture: it is at byte offset 168, follows the old fields unchanged, and yields a 176-byte context. The owning layout and stack ABI expectations are 4 and 2. The mailbox header and both mailbox fixture families now agree on module ABI 2; the manifest emitter and refined-mailbox runner also expect 2/4.
- The fixed storage-runtime baseline remains 16 cases and 189 checks. The current dynamic oracle is 38 cases and 562 checks, for 54 cases and 751 checks total. This is a delta of two cases and 47 checks from the earlier 36/515 dynamic, 52/704 total values. The current fixture reflects the two additional diagnostic-clear checks.
- The Float transition is represented as an admission check: the old nominal `FloatTag` unsupported case is removed, `unsupportedDefinitionCount` is expected to be zero, and the refined-string runner has a successful FloatTag construction check. The runner's direct-entry description now includes Float. Legacy sharedgraph ABI 3 remains explicitly a separate fixed-only control.
- Reviewed hardcoded IDs are nominal or String IDs and remain stable with Float assigned after String. The C refinements check for IDs 4 through 8, which are its four nominal types plus String. The sums fixture records only its nominal IDs and String. No reviewed source hardcodes an Option/Result TypeId. The refinements fixture's values 7 through 9 are named dense descriptor layout indexes, not TypeIds; for this Float-unreachable program the reachable descriptor list does not add a Float row, so those indices remain stable even though compound TypeIds begin one higher.
- The requested `FloatContainsString` record/inspect-generator case is not present in the reviewed files yet, so there is no source-derived ID oracle for that case to audit in this snapshot. When added, the nominal record and String IDs should retain their assigned IDs; Float is after String and any compound IDs are after Float.

## Resolved finding

The earlier review found a stale PowerShell report label and details value (`schema 3` / `expectedSchemaVersion = 3`) despite the predicate checking schema 4. Root corrected both to 4. Current source at `scripts/Verify-NativeValueStack.ps1` around line 491 is consistent.

## Status

No blocking ABI, counter, or reviewed compound-ID expectation mismatch was found. Source review only; the native typed-equality changes are not included in this review and await the native source freeze. No build was run.

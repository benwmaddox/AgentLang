# Owning mailbox ABI oracle review

Status: source-only review; no build or acceptance script was run.

Reviewed the current diff for
`tests/fixtures/native-conformance/owning-mailbox-refinements.json` and
`scripts/Verify-OwningMailbox.ps1`.

## Findings

- The fixture diff changes only `moduleAbiVersion` 1 to 2,
  `stackAbiVersion` 1 to 2, `layoutAbiVersion` 3 to 4, and the corresponding
  acceptance label to describe layout ABI 4 / stack ABI 2. After normalization
  to the repository's LF text convention, its current SHA256 is
  `6965d1f3684bb2b94c4e40b390ca1b0ecdc9c50efb1e01af30874126ae4d92e9`.
- In the verifier, the prior final fixture hash
  `A22BB448EE864713903D5EE7946C785CD7C8978CF54DA02E0F2E0B86911CBBB1` is
  retained explicitly as historical metadata. The interim CRLF-derived
  fixture hash `540C9D05D61C2EAC879BA8669BB92548102695910DCB2F6BEAAFB09E7CCD541C`
  has been superseded by the final LF pin
  `6965D1F3684BB2B94C4E40B390CA1B0ECDC9C50EFB1E01AF30874126AE4D92E9`.
  The emitted ABI-transition label states that the value, step, and copy
  oracles remain unchanged.
- The provenance predicates and correction-chain checks remain intact,
  including the required initial freeze and execution evidence, correction
  kinds, prior-hash links, value/step freeze flags, and post-execution copy
  correction flag. The source diff does not weaken or bypass those checks.
- The original gate-01 failure is still recorded in
  `.agentlang/native-float-206/mailbox-gate-01.log` and its receipt records
  `exitCode: 1`. The failure names only the four refined-fixture provenance
  hash checks (O0/O2, diagnostic/trusted-generated). This review confirms the
  source pin correction; it does not claim that the mailbox gate passed.

The JSON fixture parsed successfully and its bytes hash to the updated pin.
The original gate-01 run remains a failure record; this source review does not
infer that the later gate passed. No runtime validation was performed as part
of this review.

## Native value-stack verifier refresh

Source-only review of the current diff in
`scripts/Verify-NativeValueStack.ps1`; no acceptance script was run.

- Removing the obsolete Float unsupported-case expectation reduces the
  nominal case inventory from 44 to 43 suffixes per optimization. The verifier
  now checks for exactly 86 nominal evidence entries in addition to requiring
  each of the 86 expected O0/O2 names exactly once and rejecting failed names.
  The retained evidence snapshot contains 86 unique nominal check names, no
  duplicates or failed checks, and O0/O2 run summaries both report zero
  unsupported definitions.
- The first review found emitted metadata still claiming
  `expectedUnsupportedDefinitionCount = 1`, even though the predicate required
  zero and the saved O0/O2 evidence reported zero. The coordinating agent
  corrected the metadata to 0; the current script now agrees across predicate,
  emitted metadata, and retained evidence. The nominal check label now refers
  to the type-rejection cases without implying a non-Int unsupported case.
- The recorded value-stack gate-01 receipt remains `exitCode: 1`. This review
  covers the source correction and saved evidence only; it does not claim a
  later gate passed.

The current verifier source SHA256 is
`37cc5ab2cbd6c3844ef0d017b4f0cf6ae31e7d5b7a89ba8e74a6f969ba9a63a`. This
final pin includes the correction to emit
`expectedUnsupportedDefinitionCount = 0`. No build or gate was run as part of
this review.

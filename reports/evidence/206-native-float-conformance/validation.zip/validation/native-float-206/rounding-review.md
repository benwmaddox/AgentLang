# Native Float 206 round-away lowering review

Status: source-only review of the frozen LLVM lowering; no blocking source
mismatch found.

Reviewed `src/AgentLang.Llvm/OwningStackAot.fs` against the Float conversion
contract in `reports/205-native-float-implementation-plan.md`. The source hash
matches `.agentlang/native-float-206/llvm/source-freeze.json`:

- `OwningStackAot.fs`: `7dafc3aa039333b145a3327e71c058d4c5712fd0edc8153c0ad4cdc7a0dc98f5`
- `LlvmAot.fs`: `efaf238d55167d2870c5eebd2b67a77759224fdd69bacbac0d0a266765ce9c80`

No build or tests were run by this review.

## Findings

- `OwningLlvmWriter.EmitFloatRoundAwayFromZero` (around line 343) operates on
  the input's `i64` bits. It takes the magnitude, extracts the biased exponent,
  and rounds only the interval with exponent fields 1022 through 1074. This
  corresponds to magnitudes `[0.5, 2^52)`. Values below 0.5 become signed zero;
  values with exponent at least 1075 are already integral and retain their
  original magnitude bits. The sign is restored independently, so negative
  ties round away from zero.
- For the fractional interval, `shift = 1075 - exponent` is always in `[1,53]`;
  the fallback exponent is 1074, so all other finite exponent values also
  produce shift 1. The other shifts are `shift - 1`, in `[0,52]`. Thus neither
  `lshr` nor either `shl` can receive a shift of 64 or more. This remains true
  even if the helper were reached with an exponent outside the finite range,
  though both call sites branch around it for non-finite inputs.
- The helper separates quotient and remainder at the exact binary point and
  increments when the remainder is greater than or equal to the half bit. This
  implements nearest with ties away from zero without an inexact `+/- 0.5`
  operation. The rounded magnitude is at most `2^52` in the fractional path,
  so `uitofp` is exact; the already-integral path preserves the original bits.
- Both fixed and dynamic `float.round` call sites check the input exponent for
  non-finite values before invoking the helper, then compare the rounded
  `double` against the interpreter's half-open `[-2^63, 2^63)` range before
  `fptosi`. The failure branch stores the original input bits for `Actual`;
  the non-finite failure branch does the same. The status branches ensure no
  out-of-range conversion is executed. No `llvm.round` or platform math call
  remains in the lowering.
- The final pinned interpreter regression body checks just-below/above positive
  and negative halves, least-subnormal input, exact large integral doubles,
  `-2^63`, and the predecessor of `2^63`, under O0 and O2. The expected values
  are sourced from the interpreter and compared against exact result bits.

This is source evidence only. The coordinating agent's fresh O0/O2 build and
runtime tests remain the evidence for executable behavior.

# Native Float mailbox test review

Status: source frozen and reviewed. The original mailbox wiring review was
refreshed after the conversion-boundary additions and raw-output capacity fix.
The current source pins match `.agentlang/native-float-206/tests/source-freeze-final.json`.

Source-only review of `tests/AgentLang.Llvm.Tests/native_float_mailbox_test.c`
and the Float mailbox section of `tests/AgentLang.Llvm.Tests/Program.fs`. No
build or test command was run by this review.

- `Program.fs` (initial mailbox review, retained as history): `72ad4fd0afca147bd16da90dc47f8dca6c02312cde4d1a07a56329469faaa2fa`
- `Program.fs` (conversion and output-capacity revision): `1c71b25d0e0d7dde91f7061bd6cd91138ab786a788ddad229812485b0dc93f50`
- `Program.fs` (pre-count-control snapshot, retained as history): `7f0bde6688cc24401243707766078f9af68d520d1a7107acb4a02695ea924671`
- `Program.fs` (pre-final harness snapshot, retained as history): `c4c394df9471a41dc88306d6ee5442ddabf5c36887251b6c33eac33c13747768`
- `Program.fs` (current final freeze): `44826d92d990a732d8f9e2be5be85f55cda142d90c9e47dc13fb490f48857e13`
- `native_float_mailbox_test.c`: `86f8336343d5ee879604f806b83d7f0bda6e6bde5b8507736c633abb844a0d49`
- The freeze manifest records `--owning-float` as the focused argument and
  inclusion in the full run.

## Findings

- The test uses a checked-in C helper at
  `tests/AgentLang.Llvm.Tests/native_float_mailbox_test.c`. The managed test
  compiles it fresh for each optimization into the artifact directory, deletes
  old object/DLL outputs first, and links it with the actual mailbox, owning
  stack, bank, arena, and platform runtime sources. This is a durable source
  path, rather than generated inline test code or a stale prebuilt helper.
- The helper performs real `al_mailbox_runtime_init_owning`,
  `al_mailbox_init_text`, `al_mailbox_begin_text`, and
  `al_mailbox_resume_text` calls. It sets `config.suspension_policy` from the
  requested policy and reads back `stats.suspension_policy`, pending count,
  pinned scratch slots, and outstanding leases after each stage. The test does
  not rely on the separate raw callback tests to establish lifecycle policy
  behavior.
- The test loops over O0 and O2 and, for each, both `RETURN` (0) and
  `KEEP_ASSOCIATED` (1). Assertions expect pending counts `[0,1,0]`, lease and
  pin counts `[0,0,0]` for RETURN and `[0,1,0]` for KEEP_ASSOCIATED, successful
  API/callback statuses, positive body fuel, and the exact `-0.0` bits at all
  three stages. The Float state is created by the initialize callback, carried
  through begin, and returned through resume.
- The state read is length-bounded before the eight-byte copy. RETURN validates
  the root against the committed bank's used bytes. KEEP_ASSOCIATED verifies
  `cursor_bytes <= stack_capacity_bytes`, validates the requested eight bytes
  against the owner end using subtraction, and requires
  `source_owner_end_bytes <= cursor_bytes` before reading. This also excludes
  stale slices into unused stack capacity.

The earlier review flagged the missing associated-cursor check; the final
frozen helper resolves it. The test worker reported no policy/control-flow
changes after wiring was frozen. Runtime validation remains the coordinating
agent's responsibility.

## Final test-source refresh

The later Program.fs revision adds conversion regressions for values immediately
below/above positive and negative half-way points, a least subnormal, and large
exact integral doubles. Its expected list has 19 eight-byte outputs; output
capacity now derives from that list (152 bytes), and the test checks the
reported retained-byte count plus the raw output/fuel path. The mailbox helper
hash is unchanged, including the resolved `cursor_bytes <= stack_capacity_bytes`
and `source_owner_end_bytes <= cursor_bytes` guards. This revision supersedes
the initial Program.fs pin above; the initial pin is retained only to identify
the snapshot reviewed before the conversion additions.

## Final harness diagnostic-source review

The final `Program.fs` and C helper hashes above match
`.agentlang/native-float-206/tests/source-freeze-final.json`. No build or test
was run by this source review.

- The Float constructor-failure oracle obtains `NativeDiagnosticSources` from
  the same `refinedContext` used to create the verified program and body. Its
  interpreter host routes `WordDefinitionSpan` and `PrimitiveDefinitionSpan`
  through those frozen source maps, so the expected diagnostic includes the
  compiler snapshot's definition locations rather than an unrelated empty
  host context.
- The `interpreterFailure` helper returns both the complete `Diagnostic` and
  its instruction-charge count. For the rejected `PositiveFloat.construct`
  input, each O0/O2 native diagnostic is compared to that full interpreter
  diagnostic; a separate assertion keeps the expected code and constructor
  word explicit. The surrounding checks separately retain cursor/commit
  expectations, unchanged sentinel output, raw-entry instruction fuel parity,
  and raw retained-output preservation.
- The source diff therefore preserves diagnostic detail and independently
  checks fuel and output behavior instead of allowing a diagnostic-only match
  to stand in for those execution properties. The coordinating agent owns
  build and runtime validation.

## Pre-final focused-harness refresh (historical)

At that review stage, the manifest pinned `Program.fs` to
`c4c394df9471a41dc88306d6ee5442ddabf5c36887251b6c33eac33c13747768`; the C
helper remained `86f8336343d5ee879604f806b83d7f0bda6e6bde5b8507736c633abb844a0d49`.
Those historical pins matched the sources before the changes recorded in the
following section. The focused harness at that stage separated raw
input-count rejection from invalid-root validation:

- The raw count-mismatch case now passes one Float root to the two-root entry,
  and asserts invalid-request status 4, zero instruction fuel, and untouched
  output. The raw invalid-root case passes both roots (bad `PositiveFloat`,
  valid peer root) and asserts diagnostic status 1, validator fuel, and
  untouched output. These numeric statuses match the owning-stack ABI enum.
- The two-root setup ensures the invalid-root assertion actually reaches
  preflight validation instead of being masked by an earlier count mismatch.
  The typed `ExecuteInto` invalid-root assertion also checks the constructor
  diagnostic, zero cursor/retained commit, and unchanged sentinel bytes.

No production semantic change was part of this harness refresh. No build or
test was run by this source review.

## Final equality, profile, and helper-link review

The latest source-freeze manifest pins `Program.fs` to
`44826d92d990a732d8f9e2be5be85f55cda142d90c9e47dc13fb490f48857e13` and the
unchanged C helper to
`86f8336343d5ee879604f806b83d7f0bda6e6bde5b8507736c633abb844a0d49`. Both
pins match the current files. No build or test was run for this review.

- Equality now exercises canonical `Option.None` owners with exactly eight
  bytes and verifies equality plus the expected one-step body fuel. Separate
  16-byte `None` owners containing inactive NaN and infinity backing bytes are
  rejected as noncanonical with invalid-request status 4, zero fuel, and
  untouched output. This keeps the valid fixed-width None case distinct from
  the malformed-owner negative controls.
- The raw mailbox-entry helper now configures initialization bitmaps from the
  compiled module's runtime profile: Diagnostic gets its bitmap storage and
  pointers; TrustedGenerated gets zero bitmap bytes and null bitmap pointers.
  The two-profile callback test still invokes the generated module entries,
  while the malformed non-finite state checks remain before-fuel and do not
  publish outputs.
- Lifecycle helper objects are still compiled from the checked-in helper and
  actual mailbox/arena/owning runtime sources. The final link now uses the
  Clang driver with the Windows target and `-shared`, allowing the full C
  controller's normal CRT/system libraries to resolve; it no longer forces
  the minimal no-entry/no-default-library AOT link. The test still calls the
  real owning mailbox init, begin, resume, and stats APIs for both policies
  and O0/O2, with no callback substitution or mocked lifecycle hooks.

The coordinator owns the pending fresh build and runtime gates. This review
records source behavior only.

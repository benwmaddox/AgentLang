# Native owning Float acceptance inventory

The managed native Float acceptance slice lives in `tests/AgentLang.Llvm.Tests/Program.fs` as `--owning-float` and is also called by the full suite. Its independent finite bit vectors are positive/negative zero, least/largest subnormal, least normal, and positive/negative largest finite.

The focused cases cover O0/O2 literal and direct-input/result transport, locals, user calls, branches, numeric operators, Int64 conversion boundaries, half-way round-away-from-zero, complete interpreter diagnostics and fuel, staging atomicity, finite host codecs, bounded output decode, nominal Float wrapper identity, frozen validator pass/fail paths, and typed equality for direct, nominal, fixed-record, String-bearing dynamic-record, Option, Result, and empty-record values.

Raw owning entry tests cover non-finite Float scanner rejection and source extents 0 through 7. Raw mailbox callback tests cover both runtime profiles. Separately, `tests/AgentLang.Llvm.Tests/native_float_mailbox_test.c` drives the actual owning mailbox controller through initialize, begin, and resume at O0/O2 with both `RETURN` and `KEEP_ASSOCIATED`; it checks pending state, Float bits, and scratch lease release/retention.

The legacy shared-graph backend remains excluded from Float values and now has a structured entry-rejection check. `float.to-string` remains explicitly unsupported and must fail before invoking native tools.

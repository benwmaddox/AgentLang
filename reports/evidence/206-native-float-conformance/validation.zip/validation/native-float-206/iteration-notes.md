# 206 — Native Float conformance

Status: implementation in progress. Owning AOT Float support is not accepted.

Implement the [reviewed plan](205-native-float-implementation-plan.md) against
the current owning backend. Finite numeric Float transport, arithmetic,
comparisons, conversions, nominal refinements and typed aggregate equality are
the intended scope. The legacy shared-graph backend and native float.to-string
remain outside this milestone. Typed semantic IR remains authoritative.

The direct interpreter input prerequisite is implemented: Float arguments are
type checked and non-finite values are rejected before execution effects, hooks
or fuel. Entry owner, count and root validation retain precedence. Tests verify
exact signed-zero, subnormal and maximum-finite bits, structured non-finite
diagnostics and hook behavior. A fresh serial Release build of the interpreter
test project passed with zero warnings/errors, and its produced DLL passed
155 assertions. Package auditing was explicitly disabled; no package was added.
This focused result does not establish native conformance.

The owning ABI expectations are frozen before native execution: context size
176 with diagnostic_float_bits at offset 168, owning stack ABI 2, layout
ABI/schema 4, mailbox module ABI 2 and F64 descriptor kind 9. Descriptor shapes
and the separate mailbox controller structures remain unchanged. Existing
primitive, nominal and String IDs are preserved where specified; compound IDs
may shift. The independent fixed C baseline remains 16 cases/189 checks; the
planned scanner and typed equality cases add 2 cases/47 checks for dynamic
38/562 and total 54/751. The original 45-check inventory was amended before C
execution with two diagnostic-payload clearing checks. These counts come from
the source test inventory.

Pending acceptance: O0/O2 complete value and diagnostic parity, guarded numeric
operations, finite owner-bounded scanner negatives, typed equality through
fixed and dynamic aggregates, host admission, mailbox state under both arena
policies, and coordinated fixture/direct release ABI checks. Failed attempts
and environment adjustments will be retained. No native performance benefit is
claimed from these semantic tests.

Agent efficacy remains at [report 203](203-efficacy-decision-after-organic-creation.md):
bounded discovery/composition is observed; a comparative reliability advantage
and downstream benefit from organic vocabulary accumulation remain unproven.
This milestone develops the secondary backend track without changing those
research results or their pinned runtimes.

The first fresh managed LLVM project build failed before native execution:
five generated-string interpolation errors and four incomplete legacy entry
matches were found. The original build log and receipt are retained. The
legacy change is limited to explicit rejection of the new Float argument
variant, rather than enabling that backend. Native resources and conformance
tests still require validation before this milestone can be accepted.

After correcting those source errors, the fresh managed LLVM project build
passed with zero warnings/errors. The frozen native C stack suite passes
54 cases/751 checks at O0, O2 and UBSan trap mode. Independent source-only
review found no blocking typed-equality issue. Direct owning mailbox tests pass
at O0/O2/trap; mailbox runtime, owning bank and owning release tests pass at
O0/O2. These are intermediate gates; complete Float behavior and real mailbox
suspension-policy acceptance are still pending. The initial C compile failed
to rename an object in the system temporary directory before compilation;
retrying with a repository-local TEMP/TMP succeeded. The failed preparation is
recorded retrospectively because its original raw log and exact temporary
filename were not saved; successful command logs and the receipt are retained.

The first fresh LLVM test-project build failed in the new harness (60 errors,
8 warnings), including value-versus-list inference and incorrect assumptions
about existing interpreter helper returns and native metric fields. Its full
log and receipt are retained. This is a test compilation failure, not a
completed semantic test result; no Float runtime parity is inferred from it.

The second fresh LLVM test-project build passed with zero warnings/errors.
The first focused native execution then failed linking Float conversions at
O0: LLVM lowered rounding to an external `round` symbol absent from the current
minimal Windows link. The original log is retained. This is a native link
failure; conversion and mailbox acceptance remain pending.

The replacement rounding lowering uses exact binary64 significand/remainder
operations with bounded shifts; independent source review found no unsafe shift
or conversion path. Fresh test build 03 passed with zero warnings/errors.
Focused run 02 passed its earlier conversion/link boundary but stopped while
compiling a new aggregate test: the test pushed an Int before constructing an
Ok<Float, Int>, which the compiler correctly rejected. The original run log is
retained; the harness must be corrected before claiming full conformance.

Focused run 03 reached nominal Float refinements and failed its combined O0
constructor diagnostic/fuel/atomic-output parity assertion. No acceptance is
claimed. Investigation must distinguish a runtime mismatch from a harness
expectation error; the failed log remains retained.

Mailbox gate 01 failed only four refined-fixture provenance byte-pin checks.
The source diff changes three ABI versions and an acceptance label, leaving
value, step, copy and historical correction oracles unchanged. The verifier's
current pin is updated for canonical LF bytes, with the previous pin retained
as history. Independent source review confirmed this bounded ABI transition.
The complete mailbox gate must pass again before acceptance.

Source investigation of focused run 03 identifies a harness source-metadata
mismatch: its interpreter failure helper supplied no definition spans, while
the native refinement diagnostic includes the compiled constructor's source
span. The fix will provide the same lowering-context metadata to both sides;
full Diagnostic equality remains required. This finding still requires a
passing rerun and does not by itself establish conformance.

Value-stack gate 01 failed an obsolete 44-case nominal-count predicate after
removing the old Float-unsupported case: all 86 named O0/O2 checks passed,
matching the new 43-case inventory, with no missing/duplicate/failing names.
The verifier now pins 43 cases and also checks the exact total evidence count.
The original failing evidence remains; a complete fresh gate is required.
Mailbox gate 02 passes after the independently reviewed ABI byte-pin update.

Focused run 04 passed the corrected constructor diagnostic checks, then caught
another raw harness setup error: a two-input refined identity function was
given one raw argument, so argument-count validation correctly ran before
refinement. The test will supply both inputs and retain a separate wrong-count
precedence control. Value-stack gate 02 started before this correction; it is
not eligible for final acceptance if its source-stability check is invalidated.
The final broad rerun will follow a passing focused suite.

Focused run 05 passed raw refinement admission but exposed another harness
layout assumption: None<Float> is a canonical eight-byte tag-only value, not a
sixteen-byte owner with an inactive payload. The positive equality case now
uses canonical owners, and the old extra-payload bytes remain as a status-4,
zero-fuel, atomic-output negative control. C scanner tests independently retain
inactive backing-byte coverage. The successful solution build audits production
consumers of the new Float entry variant with zero warnings/errors; final
focused and full native suites are still required.

Focused run 06 passed typed aggregate and inactive-case checks, then failed the
trusted-generated raw callback setup. The shared harness supplied diagnostic
bitmaps, while that profile's existing ABI requires null bitmaps and zero
bitmap bytes. The harness must follow the selected profile; runtime admission
checks remain unchanged. The final rerun will also exercise the actual
controller under RETURN and KEEP_ASSOCIATED policies.
Value-stack gate 02 finished with all behavioral checks passing but failed the
source-stability check after the disclosed harness edits; it is retained as a
failed gate and will not be cited as final acceptance.

Focused run 07 passed numeric, aggregate, refinement and both raw callback
profile checks, then failed linking the new lifecycle helper: its full C
controller needs CRT memory/string routines and GetCurrentThreadId. The helper
now links through the configured Clang Windows driver, as native controller
executables do; the production language module's minimal link is unchanged.
Canonical LF normalization was applied to touched source/fixture files before
the final fresh dependency build, so committed checkout bytes follow the
repository attributes. Original raw pins and attempts remain historical;
final-source-pins.json identifies the final acceptance bytes.

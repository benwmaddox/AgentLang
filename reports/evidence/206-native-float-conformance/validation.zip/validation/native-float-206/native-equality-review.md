# Native Float typed-equality source review

Review date: 2026-10-11  
Scope: source-only review of `owning_stack_runtime.h/.c`, the fixed and dynamic equality call sites in `OwningStackAot.fs`, and the current direct C equality assertions. The native worker is holding runtime sources stable during this review. The worker reports its O0/O2/trap runtime suite passed; I did not run a build or test.

## Findings

No blocking typed-equality safety issue was found in the reviewed snapshot.

- `al_owning_equal_typed` validates the layout header before graph or value access. The header caps types at 4096 and fields at 65536; descriptor checks verify kind, field ranges, and scalar/sum shape. Graph validation detects cycles and enforces the 64-level depth bound before recursive scanning or equality.
- It checks offset-plus-extent overflow and both root ends against cursor and stack capacity. It then scans both complete operand slices, each bounded by its own root end, and requires measured extents to equal the supplied extents before comparing. The scanner checks active F64 bytes for finiteness, so the comparator's bit-based numeric equality is equivalent to IEEE equality over admitted values: identical finite bits compare equal, and opposite signed-zero encodings compare equal. NaNs and infinities fail during pre-scan.
- Record traversal uses checked cursor/offset arithmetic and verifies each measured child extent fits the remaining root extent. The helper compares values using the generated type index, not raw type inference. Both fixed and dynamic owning AOT equality call sites invoke `al_owning_equal_typed`; the old bytewise `al_owning_equal` remains only as a legacy runtime helper used by the release-runtime test, not by generated owning IR equality.
- String leaves are scanned first, which validates the bounded UTF-16 header, length, reserved bytes, padding, and complete extent; byte comparison of those canonical encodings matches code-unit string equality. Option/Result tags must match and only the selected case is scanned and recursed into, so inactive payload bytes are not read. The direct C tests cover dynamic String-plus-Float records and active Option/Result Float payloads.
- Empty records are validated by the scanner as an eight-byte zero token before equality. The equality walker treats a record with no payload-bearing fields as equal only at extent 8. The direct C tests cover both the Empty descriptor and an Empty wrapper with a zero-width field.

The runtime relies on generated, readable descriptor pointers supplied through the native ABI; it can bound descriptor counts and indexes but cannot validate the process address range backing those pointers. This is the existing ABI trust boundary, not a new equality-specific read path.

## Verification status

Reviewed implementation files: `src/AgentLang.Llvm/native/owning_stack_runtime.h`, `src/AgentLang.Llvm/native/owning_stack_runtime.c`, and both equality call sites in `src/AgentLang.Llvm/OwningStackAot.fs`. Source review only; no commands that build or execute the runtime were run by this reviewer.

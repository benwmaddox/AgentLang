# Native Float 206 acceptance contract

Status: implementation in progress; no owning Float acceptance claimed.
Base: 1d04bb1, canonical checkout, feat/native-float-206.

Scope: report 205, current owning AOT only. Legacy shared-graph AOT and
float.to-string remain unsupported. Semantic IR and interpreter are the oracle.

Before native execution, root pinned these expectations from architecture and
the native worker's static test inventory, rather than from runtime output:

- Owning stack ABI 2; context 176 bytes, appended diagnostic_float_bits at 168.
- Owning layout ABI/schema 4; descriptor sizes/offsets unchanged; F64 kind 9.
- Owning mailbox module ABI 2; mailbox controller structure ABI unchanged.
- C fixed baseline 16 cases/189 checks; dynamic 38/560; total 54/749.
  Added scanner case 29 checks and typed equality case 16 checks. If source
  changes invalidate this inventory, rederive the oracle before execution and
  retain the original and reason; do not tune expectations to observed output.
- Typed equality ABI: al_owning_equal_typed(ctx, layout, type_index, left_offset,
  left_extent_bytes, right_offset, right_extent_bytes, error_id). Bounded owners,
  1/0 result, context status on invalid inputs, active sum payloads only.

Acceptance: complete report205 numeric/transport/refinement/equality/finite
boundary contract at O0/O2, complete diagnostic parity and charged fuel,
atomic output failures, owner-safe direct C scanner negatives including lengths
0–7 and inactive sums. Mailbox Float state initializes/begins/resumes under both
arena policies. Host code rejects nonfinite input/output. No LLVM fastmath;
never execute out-of-range fptosi. Explicit native float.to-string rejection.

Validation is serial and freshly built: interpreter project/DLL, focused
--owning-float, Verify-NativeValueStack.ps1, complete native conformance,
Verify-OwningMailbox.ps1 and relevant ABI fixture/direct release checks.
Known unavailable package audit/normal UBSan linker limits must be reported;
UBSan trap and other available gates must still run. Preserve failed attempts
and distinguish command/environment corrections from semantic fixes.

Ownership: Core worker interpreter source/tests; native worker owning native
C/h/tests; LLVM worker managed backend; tests worker LLVM Program.fs; root
fixtures/scripts/experiment runner/reports and validation. No shared builds while
workers mutate dependency source. Source-only reviews may run concurrently.

Agent efficacy remains report203's checkpoint: bounded discovery/composition
works, comparative reliability and organic accumulation benefits are unproven.
Native conformance is engineering evidence, not an efficacy result.

Pre-execution inventory amendment: two checks were added for diagnostic payload
clearing on begin and first failure. Dynamic becomes 38/562; total54/751; fixed
16/189 unchanged. The initial38/560,54/749 prediction above is retained for history.
No C execution result was used to choose either count.

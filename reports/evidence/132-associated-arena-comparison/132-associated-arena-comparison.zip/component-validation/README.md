# Controller direct C validation

This folder records the focused native checks for the associated-scratch controller change. The runs below used the frozen controller/test source set after the final ABI-offset assertions were added. SHA-256 manifests were written immediately before and after the rerun; both files match byte-for-byte, so the tested source set stayed unchanged during the run. Hashes were captured around this rerun, not retrospectively.

Compiler: `clang version 19.1.5` from `C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\Llvm\bin\clang.exe`. The compiler reports an i686 default target; every C build explicitly selected `--target=x86_64-pc-windows-msvc`. The exact command line and compile exit code are in each `.build.log`; the executable invocation, output and run exit code are in each `.run.log`.

| Case | Result |
| --- | --- |
| `owning-O0` | Build 0; `owning_mailbox_test: passed`; run 0 |
| `owning-O2` | Build 0; `owning_mailbox_test: passed`; run 0 |
| `owning-ubsan-trap` | Build 0; `owning_mailbox_test: passed`; run 0 |
| `abi3-O0` | Build 0; `mailbox-unit-summary` passed with zero failures; run 0 |
| `abi3-O2` | Build 0; `mailbox-unit-summary` passed with zero failures; run 0 |

The owning test uses two slots, a 72-byte scratch arena, and 37 bytes of text staging. It checks aligned second-slot backing despite uneven bitmap and staging lengths, two concurrently attached mailboxes, rejection when both slots are pinned without token or conversion/import counter changes, failure rollback to the protected prefix with the same roots/token, retry, and release. The ABI3 graph regression remains green under both optimization levels.

`initial-attempt-failed.txt` preserves the first compile attempt, which failed before execution due to two issues subsequently fixed and a shared clang temporary-object collision. It is retained as history and is not a final validation result.

`source-hashes-before.txt` and `source-hashes-after.txt` list every C source/header used by the checks, including the controller, test programs, arena/stack/bank runtime and mailbox ABI header. The manifests are identical.

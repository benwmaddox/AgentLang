$ErrorActionPreference = 'Stop'
Set-Location 'D:\code\AgentLang'
$outputDirectory = Join-Path (Get-Location) '.agentlang/owning-mailbox-002/regression-validation'
[IO.Directory]::CreateDirectory($outputDirectory) | Out-Null
$env:TEMP = Join-Path $outputDirectory 'tmp'
$env:TMP = $env:TEMP
[IO.Directory]::CreateDirectory($env:TEMP) | Out-Null
$checks = [Collections.Generic.List[object]]::new()
$steps = @(
    @{ name = 'owning-stack'; executable = 'pwsh'; arguments = @('-NoProfile', '-File', 'scripts/Verify-NativeValueStack.ps1') },
    @{ name = 'native-dispatch'; executable = 'pwsh'; arguments = @('-NoProfile', '-File', 'scripts/Verify-NativeDispatch.ps1', '-SerialBuild', '-SkipPackageAudit') },
    @{ name = 'full-release'; executable = 'pwsh'; arguments = @('-NoProfile', '-File', 'scripts/Validate.ps1', '-SerialBuild', '-SkipPackageAudit', '-ReportPath', '.agentlang/owning-mailbox-002/regression-validation/validation.json') },
    @{ name = 'llvm-regression'; executable = 'dotnet'; arguments = @('run', '--no-build', '-c', 'Release', '--project', 'tests/AgentLang.Llvm.Tests') }
)
foreach ($step in $steps) {
    $started = [DateTimeOffset]::UtcNow
    $log = Join-Path $outputDirectory ($step.name + '.log')
    & $step.executable @($step.arguments) *> $log
    $code = $LASTEXITCODE
    $checks.Add([ordered]@{ name = $step.name; executable = $step.executable; arguments = $step.arguments; startedUtc = $started.ToString('o'); completedUtc = [DateTimeOffset]::UtcNow.ToString('o'); exitCode = $code; log = $log })
    $checks | ConvertTo-Json -Depth 6 | Set-Content (Join-Path $outputDirectory 'checks.json')
    Write-Output "$($step.name): exit $code; $log"
    if ($code -ne 0) { exit $code }
}

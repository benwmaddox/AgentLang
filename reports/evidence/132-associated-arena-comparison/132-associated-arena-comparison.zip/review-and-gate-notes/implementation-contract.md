# Keep-associated owning mailbox implementation contract

Planning agreement for parallel emitter, controller and acceptance work.
Milestone 131's return-at-suspension path stays a regression control. This
updates the current prototype ABI as one unit; no compatibility shim or
version-migration scaffold. No product source is changed by this note.

## Exact generated callback and module layout

Add one callback type and one pointer at the **end** of
`al_owning_mailbox_module` in `owning_mailbox_abi.h`:

```c
typedef int32_t (*al_owning_mailbox_associated_resume_fn)(
    al_owning_stack_context *context,
    const al_owning_bank_stack_slice *retained_inputs,
    uint32_t retained_count,
    const al_owning_external_slice *completion,
    uint32_t protected_cursor_bytes,
    al_owning_bank_stack_slice *outputs,
    uint32_t output_capacity);

typedef struct al_owning_mailbox_module {
  uint32_t abi_version, struct_size;
  const al_owning_layout *layout;
  al_owning_mailbox_entry entries[3];
  al_owning_mailbox_associated_resume_fn associated_resume;
} al_owning_mailbox_module;
```

Use one generated symbol `agentlang_mailbox_resume_associated` in the same
DLL. On x64 the existing entry table remains at offset 16; the new function
pointer is at offset **136**, module size **144**. Keep the current prototype
ABI version value `1`; update `struct_size`, static assertions, generated C
metadata and module validation together. The three normal entry callbacks and
one shared type/layout index universe stay as in milestone 131. The fourth
callback invokes the **same** generated resume entry frame, not a second
lowering of the source body.

At entry, `context->cursor_bytes == protected_cursor_bytes > 0`, status OK,
call depth zero, `retained_count == 2`, output capacity at least one, and
retained type indexes equal resume input indexes 0/1. `completion` is one
complete String with resume input index 2. Preflight all pointer spans,
layout/module metadata, descriptor arrays, bitmaps, trace and completion
extent/capacity before reading payload or writing output metadata. Reject
overlap of writable output with these regions. Check each retained slice is
within the protected cursor and measure it **in the existing stack** with
the shared layout and its `source_owner_end_bytes`; construct the 20-byte
frame descriptors from measured payload/extent and type IDs. Measure the
completion externally, reserve at `protected_cursor_bytes`, copy only that
serialized String once, and call the existing resume frame. Return one live
State source slice. Do not call `al_owning_begin`, publish bytes, reset the
cursor or import State/Continuation. Output slices are invalid on any
post-preflight failure; controller records status before rollback.

The active `emitDynamicModule` is source-preserving: local load/store/drop
transfer metadata, constructors append, and saved frame/scope marks are at
or above callback entry cursor. Existing `ArenaLifetime` decisions therefore
govern suffix rewinds. Check the emitted associated callback plus reachable
resume callees for no write/release below the protected cursor. Historical
fixed-emitter move/drop calls are not a reason to add root scans, reference
counts or backup copies.

## Controller config, scratch pool and state

Use the existing `al_mailbox_init_text`, `begin_text`, `resume_text` API and
one token/slot lifecycle. Replace the two `reserved` words of
`al_mailbox_owning_config` with:

```c
uint32_t scratch_slot_capacity;  /* offset 24; 1..mailbox_capacity */
uint32_t suspension_policy;      /* offset 28; 0=RETURN, 1=KEEP */
```

Config remains **32 bytes**. Expose named policy constants. No policy switch
after runtime initialization. For equal-reservation comparison, both policies
use the same caller-owned `scratch_slot_capacity` (two slots for the focused
two-mailbox gate). `scratch_byte_capacity` is **per slot**. Storage layout
allocates each slot's owning context, arena bytes and two bitmaps with checked
arithmetic; `scratch_reserved_bytes = slot_count * (stack_bytes + 2 *
bitmap_bytes)`, with context/pool metadata in `controller_reserved_bytes`.
The existing two retained banks per mailbox and one UTF-16 staging region
remain. Free/attached slot indexes are caller-owned metadata, never payload
copies. Keep one executing turn at a time under `busy`; parked keep leases do
not make unrelated mailbox APIs busy. `outstanding_scratch_leases` counts
checked-out physical slots, including parked keep slots; record acquisitions
on checkout and returns on release, not on every synchronous callback.

Allocate a separate owning attachment table indexed by mailbox to avoid
changing the ABI3 slot payload: `{slot_index, protected_cursor_bytes,
root_count=2, State slice, Continuation slice}` with `UINT32_MAX` as no slot.
The retained bank continues to own persistent State between operation groups.
Initialize and return-mode turns use a free scratch slot and publish/reset as
today. Keep begin imports bank State and the external String into a free slot,
calls the ordinary begin callback, validates its two output slices, and
attaches the **actual** context/bytes/bitmaps and slices without staging to
the bank or resetting. Mint the token only in the nonfailing final tail.
Keep resume validates token and attachment first, converts only completion
text, calls `associated_resume` on that slot, stages the final State into
the inactive bank, commits, then resets/releases the slot and completes the
token. The active bank may still hold pre-begin State while keep is pending;
the attached slices, not that bank, are the current pending roots.

`al_owning_stage_text_input` and active-bank root validation currently call
`al_owning_begin` on the runtime context. They must never do so on a parked
slot: external-value scanning uses a separate temporary/scanner context
(metadata only, with independent status) and cannot clear pinned bitmaps.
Likewise, associated resume resets only per-invocation step/error counters;
it preserves cursor, live accounting, bitmaps, and accumulated arena bytes.
Compute per-turn copy deltas from counter snapshots. The callback's context
fields and pending roots are snapshotted as **metadata** before resume. On
handler or publication failure, record the error, release only bytes above
`protected_cursor_bytes`, restore scalar context/accounting/status from the
snapshot, abort the inactive bank, and preserve the attachment and token for
retry. This works because the emitted dynamic path never writes below the
saved mark. No payload backup or runtime liveness decision is allowed.
Token exhaustion/free-slot rejection happens before handler execution and
must not consume a sequence or change the pending owner. Disposal releases
attached slots once; future provider borrowing will delay that release until
acknowledged cancellation/completion.

## Observable state and accounting

Extend `al_mailbox_owning_state_view` after its current 32-byte prefix with
`associated_context` pointer at **32**, `associated_roots` pointer at **40**,
`associated_root_count` at **48**, and `scratch_slot_index` at **52**; size
**56**. When pending under KEEP, the associated roots (State,
Continuation) are authoritative; `bank` still exposes the previous
committed persistent State and must be labeled as such. Under RETURN or when
not pending, associated pointers are null, count zero and slot index
`UINT32_MAX`. Views are borrowed until the next mutation/disposal. This
exposes actual in-arena offsets and bytes for the focused oracle without
copying them into a report buffer first.

Append to `al_mailbox_owning_stats` after its current 184-byte prefix:
four `uint32_t` at offsets **184/188/192/196** for
`scratch_slot_capacity`, `pinned_scratch_slots`, `suspension_policy`,
`reserved1`; then `uint64_t` at **200/208/216** for
`pinned_scratch_bytes`, `begin_publication_copy_bytes`,
`resume_root_import_bytes`. New size **224**. Existing aggregate
`publication_copy_bytes` and `input_import_bytes` remain, with the added
metrics isolating the two mid-suspension copies under comparison.
`pinned_scratch_bytes` is the sum of capacities of attached slots, not live
payload. At keep suspension, begin publication and resume-root import must
both be zero; external completion String import and final State publication
remain counted. Full-capacity poison `memset` at turn boundaries is currently
instrumentation traffic and must be reported separately before any throughput
claim; retain its correctness role for this gate.

## Ownership and validation handoff

- Emitter owner: `OwningStackAot.fs`, generated metadata C, and
  `owning_mailbox_abi.h`; implement the associated callback, shared frame
  call and static ABI offsets. No compiler-only lifetime rule moves into C.
- Controller owner: `mailbox_runtime.[ch]` and its pool/storage implementation;
  keep existing token commit helpers and bank transaction ordering, add
  return/keep payload dispatch and metadata-only retry checkpoint.
- Acceptance owner: new focused policy runner/fixture/script plus necessary
  updates to the milestone 131 runner for explicit slot_count=1,
  policy=RETURN. Preserve its frozen Unicode/empty/failure byte and copy
  oracles. Put new two-policy expectations in
  `tests/fixtures/native-conformance/owning-mailbox-policy.json`; do not
  weaken the milestone 131 fixture to accommodate KEEP.

Audit the x64 offsets above, the existing `al_owning_bank_stack_slice` size
16 and `al_owning_external_slice` size 16, config/requirements/stats/state
view sizes, generated module manifest `moduleAbiVersion` and callback symbol,
both bank root arrays, per-slot bitmaps, all fixture storage formulas and
copy counters. No ABI3 graph signature or fixture should change. Validation
commands after fresh dependency/runtime builds:

```powershell
pwsh -NoProfile -File scripts/Verify-OwningMailbox.ps1
pwsh -NoProfile -File scripts/Verify-OwningMailboxPolicy.ps1
pwsh -NoProfile -File scripts/Validate.ps1 -Configuration Release
```

The policy verifier must build O0/O2 modules and native controller fresh,
run two mailboxes pending/interleaved, compare exact State bytes/types after
resume, show attached offsets stable and no free-slot admission before token
consumption, force a suffix-producing failure and bank-capacity failure then
retry the same token, and assert the keep path avoids begin promotion and
resume State/Continuation imports. It reports equal reserved pool storage,
pinned slots/bytes and all boundary copies. This establishes a bounded
mechanism comparison, not real-I/O performance or a policy winner.

# Protected pending-prefix review

Scope: current supported owning mailbox values (Int, Bool, Unit, String and
nominal records) and the active `emitDynamicModule` path in
`OwningStackAot.fs`. This is a read-only source review of the associated
callback and native controller draft.

## Current emitter/runtime conclusion

No below-prefix payload write is reachable from the present dynamic resume
frame or its user callees when the associated callback enters with
`cursor_bytes == protected_cursor_bytes` and keeps that cursor live. The
dynamic emitter is selected unconditionally by `compileMailbox`
(`OwningStackAot.fs:4059`). Its local store/load, operand drop, field
projection and call/return paths transfer descriptors or read existing
values; the destructive `al_owning_move_range` and `al_owning_drop` calls at
lines 1438/1517 are in the unused fixed emitter. They are declared in the
dynamic module but not called by its generated frames.

In the active frame, entry `baselineCursor` is loaded at line 2419. Every
nested scope mark is taken from the current cursor at line 2611, so marks are
at or above the associated entry cursor. Compiler-approved scope/function
rewinds (lines 2620 and 2954) return to those marks. A failed nested frame
releases to its own baseline (line 2963), also at or above the protected
cursor. A caller failure unwinds through saved marks; it cannot legally
rewind below its entry baseline. The existing `ArenaLifetime` proof controls
whether successful rewinds happen; the runtime only executes the mark.

Scalar/String literals, scalar primitive results, duplication, record
construction and String concat reserve from the current cursor and write
only into the new suffix (roughly lines 2569-2585, 2684-2697,
2737-2754 and 2792-2796). `al_owning_copy_range` validates source and
destination disjointness; record construction's destination is its newly
reserved extent. `al_owning_string_concat_write` similarly writes a newly
reserved result and reads the source Strings. `GetRecordField` produces a
view into its parent; it does not move or clear parent bytes. Dynamic drop
records a logical event only. Nested user calls pass/return descriptors and
use the same append/saved-mark rules.

The runtime `al_owning_check_initialized` can clear a poison **bitmap** bit
on a read, so a read is not literally metadata-write-free. This does not
change payload bytes. Begin output descriptor validation checks full output
extents before parking, and initialized live roots have clean poison bits;
therefore the retained State/Continuation prefix should already be clean.
Require both retained values to be initialized with clean poison bits before
attachment; keep that as the pending-prefix invariant. The associated
callback then reads an already-clean prefix, so no bitmap snapshot or
backup is needed. `al_owning_release_to` updates per-byte bits only in the
suffix above its mark, including when the mark is not byte aligned. Do not
mistake this debug bitmap behavior for a need to copy retained payloads.

## Current associated path

The generated `agentlang_owning_mailbox_associated_preflight`
(`OwningStackAot.fs:3909-3988`) checks the parked cursor, root type indexes
and owner bounds, completion extent/capacity, and disjoint module/layout,
context, arena, bitmap, trace, descriptor, and payload spans before any
host-payload scan. `agentlang_mailbox_resume_associated`
(`OwningStackAot.fs:3244-3433`) measures the retained values without copying
them, measures the completion String, reserves and copies it at the current
cursor, then invokes the same generated resume frame. Its only direct
payload write is the completion suffix (and possible standalone Empty token
after the frame). A retained descriptor's owner end may legitimately be an
enclosing record boundary; measuring the value within it is the right check,
not requiring owner end to equal the root's measured end.

The native controller validates begin outputs before attachment
(`mailbox_runtime.c:2316`, `:2758-2767`). Associated resume saves scalar
context metadata, revalidates attached roots, and on execution/publication
failure releases the suffix back to `protected_cursor` and restores that
metadata (`mailbox_runtime.c:2453-2565`). The attached slot and pending
token are retained for retry. On success it commits the new State bank and
releases the scratch slot before committing the completed token. This is
consistent with the compiler-only prefix proof; no prefix backup is needed.

## Remaining watchpoints

- Do not call `al_owning_begin` on an attached context: it resets cursor,
  counters and **both bitmaps**. Current text staging uses an independent
  local scanner status (`mailbox_runtime.c:2586-2611`).
- Keep the clean-root attachment invariant and the controller's scalar
  context rollback. A root may be a projection with a containing owner end
  beyond its measured extent, but that owner end must remain within the
  protected prefix.
- `al_owning_release_to` poisons released bytes, and `al_owning_reserve_to`
  poisons new bytes. Both are safe only at/above the protected cursor. The
  historical fixed emitter's move/drop helpers would be unsafe for this
  no-copy retry contract if ever selected; future primitives require a fresh
  compiler-side review, not runtime root scanning or backup copies.

No new ownership machinery is indicated for the current dynamic emitter;
the associated callback and controller must preserve the existing saved-mark
premise and prove it with focused O0/O2 failure-and-retry tests.

## Pool layout and lifecycle follow-up

**Layout defect found and corrected by the controller owner:** The original
`mailbox_runtime.c` took `scratch_backing_offset` directly after the
arbitrary-length text staging region. A staging capacity of 9 bytes can
misalign even slot 0's `stack_data`, despite aligned caller storage. Also,
the original code set `scratch_slot_stride` to the unpadded end of the
poison bitmap. With scratch capacity 72 bytes, bitmap size 9, the per-slot
offsets are data 0, init 80, poison 96, and stride 105; slot 1's data is
misaligned. Both the backing start and completed slot stride require checked
8-byte alignment. Current `mailbox_runtime.c:668-687` performs both checked
alignments before multiplying the slot count. This resolves the source issue;
the controller owner is running direct tests.

The no-slot begin path finds or checks out a free slot before token creation
and `al_execute_owning_entry`, so it leaves the pending flag, token sequence,
and generation pair unchanged (`mailbox_runtime.c:2724-2753`). Failed
associated resume retains the attached slot and pending token; generation
pairs may be consumed by attempted execution, consistent with the existing
entry path, but token state commits only after successful bank publication
(`:2464-2583`, `:2839-2845`). `al_runtime_access` checks owner thread and
`busy` before public operations (`:971-990`). Disposal rejects wrong thread
and active execution, then clears banks and releases all parked slots on the
owner thread (`:3122-3183`). No separate lifecycle defect found in these
paths on source review.

%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [4 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8 }, %AlOwningTypeDescriptor { i32 4, i32 4, i32 0, i32 0, i32 0, i32 8, i32 0, i32 8 }, %AlOwningTypeDescriptor { i32 4, i32 10, i32 0, i32 3, i32 4294967295, i32 4294967295, i32 16, i32 16 }, %AlOwningTypeDescriptor { i32 5, i32 12, i32 3, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8 }], align 4
@al_owning_fields = private constant [3 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 1, i32 0, i32 1, i32 0 }, %AlOwningFieldDescriptor { i32 3, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 4294967295, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 1, ptr @al_owning_types, i32 4, ptr @al_owning_fields, i32 3 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 12
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 12, 12
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %descriptor.element.43 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.44 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 0
  %descriptor.value.45 = load i32, ptr %descriptor.field.44, align 4
  %descriptor.field.46 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 1
  %descriptor.value.47 = load i32, ptr %descriptor.field.46, align 4
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 2
  %descriptor.value.49 = load i32, ptr %descriptor.field.48, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 3
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 4
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %argument.type.valid.54 = icmp eq i32 %descriptor.value.45, 1
  br i1 %argument.type.valid.54, label %argument.type.ok.55, label %frame.failure.0
argument.type.ok.55:
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %stack.sub.60 = sub i32 %descriptor.value.53, %descriptor.value.47
  %descriptor.owner.inside.58 = icmp ule i32 %descriptor.value.53, %context.value.57
  %descriptor.offset.inside.59 = icmp ule i32 %descriptor.value.47, %descriptor.value.53
  %descriptor.extent.inside.61 = icmp ule i32 %descriptor.value.49, %stack.sub.60
  %descriptor.payload.inside.62 = icmp ule i32 %descriptor.value.51, %descriptor.value.49
  %descriptor.owner.offset.valid.63 = and i1 %descriptor.owner.inside.58, %descriptor.offset.inside.59
  %descriptor.range.inside.65 = and i1 %descriptor.owner.offset.valid.63, %descriptor.extent.inside.61
  %descriptor.range.valid.64 = and i1 %descriptor.range.inside.65, %descriptor.payload.inside.62
  %descriptor.type.valid.66 = icmp eq i32 1, 1
  %descriptor.valid.67 = and i1 %descriptor.range.valid.64, %descriptor.type.valid.66
  br i1 %descriptor.valid.67, label %descriptor.valid.68, label %descriptor.invalid.69
descriptor.invalid.69:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.68:
  %descriptor.initialized.status.70 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.47, i32 %descriptor.value.49)
  %helper.ok.71 = icmp eq i32 %descriptor.initialized.status.70, 0
  br i1 %helper.ok.71, label %helper.continue.72, label %frame.failure.0
helper.continue.72:
  %step.status.73 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.74 = icmp eq i32 %step.status.73, 0
  br i1 %helper.ok.74, label %helper.continue.75, label %frame.failure.0
helper.continue.75:
  %call.arguments.76 = alloca [2 x %AlOwningDescriptor], align 4
  %descriptor.element.77 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.76, i32 0
  %descriptor.field.78 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 0
  store i32 12, ptr %descriptor.field.78, align 4
  %descriptor.field.79 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.79, align 4
  %descriptor.field.80 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.80, align 4
  %descriptor.field.81 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.81, align 4
  %descriptor.field.82 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.82, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %descriptor.element.87 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.76, i32 1
  %descriptor.field.88 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 0
  store i32 1, ptr %descriptor.field.88, align 4
  %descriptor.field.89 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 1
  store i32 %descriptor.value.47, ptr %descriptor.field.89, align 4
  %descriptor.field.90 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 2
  store i32 %descriptor.value.49, ptr %descriptor.field.90, align 4
  %descriptor.field.91 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 3
  store i32 %descriptor.value.51, ptr %descriptor.field.91, align 4
  %descriptor.field.92 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 4
  store i32 %descriptor.value.53, ptr %descriptor.field.92, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %descriptor.value.47, i32 20, i32 %descriptor.value.51, i32 %descriptor.value.53, i32 %descriptor.value.49)
  %context.field.93 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.94 = load i32, ptr %context.field.93, align 4
  %runtime.ok.95 = icmp eq i32 %context.value.94, 0
  br i1 %runtime.ok.95, label %runtime.continue.96, label %frame.failure.0
runtime.continue.96:
  %call.results.97 = alloca [1 x %AlOwningDescriptor], align 4
  %callee.status.98 = call i32 @agentlang_word_0000(ptr %ctx, ptr %call.arguments.76, ptr %call.results.97, i32 2)
  %helper.ok.99 = icmp eq i32 %callee.status.98, 0
  br i1 %helper.ok.99, label %helper.continue.100, label %frame.failure.0
helper.continue.100:
  %descriptor.element.101 = getelementptr inbounds %AlOwningDescriptor, ptr %call.results.97, i32 0
  %descriptor.field.102 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.101, i32 0, i32 0
  %descriptor.value.103 = load i32, ptr %descriptor.field.102, align 4
  %descriptor.field.104 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.101, i32 0, i32 1
  %descriptor.value.105 = load i32, ptr %descriptor.field.104, align 4
  %descriptor.field.106 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.101, i32 0, i32 2
  %descriptor.value.107 = load i32, ptr %descriptor.field.106, align 4
  %descriptor.field.108 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.101, i32 0, i32 3
  %descriptor.value.109 = load i32, ptr %descriptor.field.108, align 4
  %descriptor.field.110 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.101, i32 0, i32 4
  %descriptor.value.111 = load i32, ptr %descriptor.field.110, align 4
  %callee.result.type.valid.112 = icmp eq i32 %descriptor.value.103, 10
  br i1 %callee.result.type.valid.112, label %callee.result.type.ok.113, label %frame.failure.0
callee.result.type.ok.113:
  %context.field.114 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.115 = load i32, ptr %context.field.114, align 4
  %stack.sub.118 = sub i32 %descriptor.value.111, %descriptor.value.105
  %descriptor.owner.inside.116 = icmp ule i32 %descriptor.value.111, %context.value.115
  %descriptor.offset.inside.117 = icmp ule i32 %descriptor.value.105, %descriptor.value.111
  %descriptor.extent.inside.119 = icmp ule i32 %descriptor.value.107, %stack.sub.118
  %descriptor.payload.inside.120 = icmp ule i32 %descriptor.value.109, %descriptor.value.107
  %descriptor.owner.offset.valid.121 = and i1 %descriptor.owner.inside.116, %descriptor.offset.inside.117
  %descriptor.range.inside.123 = and i1 %descriptor.owner.offset.valid.121, %descriptor.extent.inside.119
  %descriptor.range.valid.122 = and i1 %descriptor.range.inside.123, %descriptor.payload.inside.120
  %descriptor.type.valid.124 = icmp eq i32 10, 10
  %descriptor.valid.125 = and i1 %descriptor.range.valid.122, %descriptor.type.valid.124
  br i1 %descriptor.valid.125, label %descriptor.valid.126, label %descriptor.invalid.127
descriptor.invalid.127:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.126:
  %descriptor.initialized.status.128 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.105, i32 %descriptor.value.107)
  %helper.ok.129 = icmp eq i32 %descriptor.initialized.status.128, 0
  br i1 %helper.ok.129, label %helper.continue.130, label %frame.failure.0
helper.continue.130:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 10, i32 %descriptor.value.105, i32 20, i32 %descriptor.value.109, i32 %descriptor.value.111, i32 %descriptor.value.107)
  %context.field.131 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.132 = load i32, ptr %context.field.131, align 4
  %runtime.ok.133 = icmp eq i32 %context.value.132, 0
  br i1 %runtime.ok.133, label %runtime.continue.134, label %frame.failure.0
runtime.continue.134:
  %context.field.135 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.136 = load i32, ptr %context.field.135, align 4
  %stack.sub.139 = sub i32 %descriptor.value.111, %descriptor.value.105
  %descriptor.owner.inside.137 = icmp ule i32 %descriptor.value.111, %context.value.136
  %descriptor.offset.inside.138 = icmp ule i32 %descriptor.value.105, %descriptor.value.111
  %descriptor.extent.inside.140 = icmp ule i32 %descriptor.value.107, %stack.sub.139
  %descriptor.payload.inside.141 = icmp ule i32 %descriptor.value.109, %descriptor.value.107
  %descriptor.owner.offset.valid.142 = and i1 %descriptor.owner.inside.137, %descriptor.offset.inside.138
  %descriptor.range.inside.144 = and i1 %descriptor.owner.offset.valid.142, %descriptor.extent.inside.140
  %descriptor.range.valid.143 = and i1 %descriptor.range.inside.144, %descriptor.payload.inside.141
  %descriptor.type.valid.145 = icmp eq i32 10, 10
  %descriptor.valid.146 = and i1 %descriptor.range.valid.143, %descriptor.type.valid.145
  br i1 %descriptor.valid.146, label %descriptor.valid.147, label %descriptor.invalid.148
descriptor.invalid.148:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.147:
  %descriptor.initialized.status.149 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.105, i32 %descriptor.value.107)
  %helper.ok.150 = icmp eq i32 %descriptor.initialized.status.149, 0
  br i1 %helper.ok.150, label %helper.continue.151, label %frame.failure.0
helper.continue.151:
  %descriptor.element.152 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.153 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.152, i32 0, i32 0
  store i32 10, ptr %descriptor.field.153, align 4
  %descriptor.field.154 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.152, i32 0, i32 1
  store i32 %descriptor.value.105, ptr %descriptor.field.154, align 4
  %descriptor.field.155 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.152, i32 0, i32 2
  store i32 %descriptor.value.107, ptr %descriptor.field.155, align 4
  %descriptor.field.156 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.152, i32 0, i32 3
  store i32 %descriptor.value.109, ptr %descriptor.field.156, align 4
  %descriptor.field.157 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.152, i32 0, i32 4
  store i32 %descriptor.value.111, ptr %descriptor.field.157, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 10, i32 %descriptor.value.105, i32 20, i32 %descriptor.value.109, i32 %descriptor.value.111, i32 %descriptor.value.107)
  %context.field.158 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.159 = load i32, ptr %context.field.158, align 4
  %runtime.ok.160 = icmp eq i32 %context.value.159, 0
  br i1 %runtime.ok.160, label %runtime.continue.161, label %frame.failure.0
runtime.continue.161:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.162 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.163 = load i32, ptr %context.field.162, align 4
  %context.field.164 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.165 = load i32, ptr %context.field.164, align 4
  %context.field.166 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.167 = load i32, ptr %context.field.166, align 4
  %stack.offset.168 = add i32 %context.value.5, %context.value.7
  %stack.offset.169 = add i32 %context.value.163, %context.value.165
  %stack.sub.170 = sub i32 %stack.offset.168, %stack.offset.169
  %stack.sub.171 = sub i32 %context.value.7, %context.value.165
  %stack.sub.172 = sub i32 %context.value.167, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.170, i32 %stack.sub.171)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.172)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %local.active.2 = alloca i1, align 1
  %local.offset.3 = alloca i32, align 4
  %local.extent.4 = alloca i32, align 4
  %local.payload.5 = alloca i32, align 4
  %local.owner.end.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %local.active.8 = alloca i1, align 1
  %local.offset.9 = alloca i32, align 4
  %local.extent.10 = alloca i32, align 4
  %local.payload.11 = alloca i32, align 4
  %local.owner.end.12 = alloca i32, align 4
  %local.type.13 = alloca i32, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  %local.active.14 = alloca i1, align 1
  %local.offset.15 = alloca i32, align 4
  %local.extent.16 = alloca i32, align 4
  %local.payload.17 = alloca i32, align 4
  %local.owner.end.18 = alloca i32, align 4
  %local.type.19 = alloca i32, align 4
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  %local.active.20 = alloca i1, align 1
  %local.offset.21 = alloca i32, align 4
  %local.extent.22 = alloca i32, align 4
  %local.payload.23 = alloca i32, align 4
  %local.owner.end.24 = alloca i32, align 4
  %local.type.25 = alloca i32, align 4
  store i1 false, ptr %local.active.20, align 1
  store i32 0, ptr %local.offset.21, align 4
  store i32 0, ptr %local.extent.22, align 4
  store i32 0, ptr %local.payload.23, align 4
  store i32 0, ptr %local.owner.end.24, align 4
  store i32 0, ptr %local.type.25, align 4
  %local.active.26 = alloca i1, align 1
  %local.offset.27 = alloca i32, align 4
  %local.extent.28 = alloca i32, align 4
  %local.payload.29 = alloca i32, align 4
  %local.owner.end.30 = alloca i32, align 4
  %local.type.31 = alloca i32, align 4
  store i1 false, ptr %local.active.26, align 1
  store i32 0, ptr %local.offset.27, align 4
  store i32 0, ptr %local.extent.28, align 4
  store i32 0, ptr %local.payload.29, align 4
  store i32 0, ptr %local.owner.end.30, align 4
  store i32 0, ptr %local.type.31, align 4
  %local.active.32 = alloca i1, align 1
  %local.offset.33 = alloca i32, align 4
  %local.extent.34 = alloca i32, align 4
  %local.payload.35 = alloca i32, align 4
  %local.owner.end.36 = alloca i32, align 4
  %local.type.37 = alloca i32, align 4
  store i1 false, ptr %local.active.32, align 1
  store i32 0, ptr %local.offset.33, align 4
  store i32 0, ptr %local.extent.34, align 4
  store i32 0, ptr %local.payload.35, align 4
  store i32 0, ptr %local.owner.end.36, align 4
  store i32 0, ptr %local.type.37, align 4
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %context.field.40 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.41 = load i32, ptr %context.field.40, align 4
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %context.field.44 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.45 = load i32, ptr %context.field.44, align 4
  %frame.entered.46 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.47 = icmp eq i32 %frame.entered.46, 0
  br i1 %frame.enter.ok.47, label %frame.enter.continue.48, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.48:
  %descriptor.element.49 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 0
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 1
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %descriptor.field.54 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 2
  %descriptor.value.55 = load i32, ptr %descriptor.field.54, align 4
  %descriptor.field.56 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 3
  %descriptor.value.57 = load i32, ptr %descriptor.field.56, align 4
  %descriptor.field.58 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 4
  %descriptor.value.59 = load i32, ptr %descriptor.field.58, align 4
  %argument.type.valid.60 = icmp eq i32 %descriptor.value.51, 12
  br i1 %argument.type.valid.60, label %argument.type.ok.61, label %frame.failure.0
argument.type.ok.61:
  %context.field.62 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.63 = load i32, ptr %context.field.62, align 4
  %stack.sub.66 = sub i32 %descriptor.value.59, %descriptor.value.53
  %descriptor.owner.inside.64 = icmp ule i32 %descriptor.value.59, %context.value.63
  %descriptor.offset.inside.65 = icmp ule i32 %descriptor.value.53, %descriptor.value.59
  %descriptor.extent.inside.67 = icmp ule i32 %descriptor.value.55, %stack.sub.66
  %descriptor.payload.inside.68 = icmp ule i32 %descriptor.value.57, %descriptor.value.55
  %descriptor.owner.offset.valid.69 = and i1 %descriptor.owner.inside.64, %descriptor.offset.inside.65
  %descriptor.range.inside.71 = and i1 %descriptor.owner.offset.valid.69, %descriptor.extent.inside.67
  %descriptor.range.valid.70 = and i1 %descriptor.range.inside.71, %descriptor.payload.inside.68
  %descriptor.type.valid.72 = icmp eq i32 12, 12
  %descriptor.valid.73 = and i1 %descriptor.range.valid.70, %descriptor.type.valid.72
  br i1 %descriptor.valid.73, label %descriptor.valid.74, label %descriptor.invalid.75
descriptor.invalid.75:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.74:
  %descriptor.initialized.status.76 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.53, i32 %descriptor.value.55)
  %helper.ok.77 = icmp eq i32 %descriptor.initialized.status.76, 0
  br i1 %helper.ok.77, label %helper.continue.78, label %frame.failure.0
helper.continue.78:
  %descriptor.element.79 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.80 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 0
  %descriptor.value.81 = load i32, ptr %descriptor.field.80, align 4
  %descriptor.field.82 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 1
  %descriptor.value.83 = load i32, ptr %descriptor.field.82, align 4
  %descriptor.field.84 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 2
  %descriptor.value.85 = load i32, ptr %descriptor.field.84, align 4
  %descriptor.field.86 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 3
  %descriptor.value.87 = load i32, ptr %descriptor.field.86, align 4
  %descriptor.field.88 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 4
  %descriptor.value.89 = load i32, ptr %descriptor.field.88, align 4
  %argument.type.valid.90 = icmp eq i32 %descriptor.value.81, 1
  br i1 %argument.type.valid.90, label %argument.type.ok.91, label %frame.failure.0
argument.type.ok.91:
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %stack.sub.96 = sub i32 %descriptor.value.89, %descriptor.value.83
  %descriptor.owner.inside.94 = icmp ule i32 %descriptor.value.89, %context.value.93
  %descriptor.offset.inside.95 = icmp ule i32 %descriptor.value.83, %descriptor.value.89
  %descriptor.extent.inside.97 = icmp ule i32 %descriptor.value.85, %stack.sub.96
  %descriptor.payload.inside.98 = icmp ule i32 %descriptor.value.87, %descriptor.value.85
  %descriptor.owner.offset.valid.99 = and i1 %descriptor.owner.inside.94, %descriptor.offset.inside.95
  %descriptor.range.inside.101 = and i1 %descriptor.owner.offset.valid.99, %descriptor.extent.inside.97
  %descriptor.range.valid.100 = and i1 %descriptor.range.inside.101, %descriptor.payload.inside.98
  %descriptor.type.valid.102 = icmp eq i32 1, 1
  %descriptor.valid.103 = and i1 %descriptor.range.valid.100, %descriptor.type.valid.102
  br i1 %descriptor.valid.103, label %descriptor.valid.104, label %descriptor.invalid.105
descriptor.invalid.105:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.104:
  %descriptor.initialized.status.106 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.83, i32 %descriptor.value.85)
  %helper.ok.107 = icmp eq i32 %descriptor.initialized.status.106, 0
  br i1 %helper.ok.107, label %helper.continue.108, label %frame.failure.0
helper.continue.108:
  %step.status.109 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.110 = icmp eq i32 %step.status.109, 0
  br i1 %helper.ok.110, label %helper.continue.111, label %frame.failure.0
helper.continue.111:
  store i1 true, ptr %local.active.2, align 1
  store i32 %descriptor.value.83, ptr %local.offset.3, align 4
  store i32 %descriptor.value.85, ptr %local.extent.4, align 4
  store i32 %descriptor.value.87, ptr %local.payload.5, align 4
  store i32 %descriptor.value.89, ptr %local.owner.end.6, align 4
  store i32 1, ptr %local.type.7, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %descriptor.value.83, i32 20, i32 %descriptor.value.87, i32 %descriptor.value.89, i32 %descriptor.value.85)
  %context.field.112 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.113 = load i32, ptr %context.field.112, align 4
  %runtime.ok.114 = icmp eq i32 %context.value.113, 0
  br i1 %runtime.ok.114, label %runtime.continue.115, label %frame.failure.0
runtime.continue.115:
  %context.field.116 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.117 = load i32, ptr %context.field.116, align 4
  %stack.sub.120 = sub i32 %descriptor.value.59, %descriptor.value.53
  %descriptor.owner.inside.118 = icmp ule i32 %descriptor.value.59, %context.value.117
  %descriptor.offset.inside.119 = icmp ule i32 %descriptor.value.53, %descriptor.value.59
  %descriptor.extent.inside.121 = icmp ule i32 %descriptor.value.55, %stack.sub.120
  %descriptor.payload.inside.122 = icmp ule i32 %descriptor.value.57, %descriptor.value.55
  %descriptor.owner.offset.valid.123 = and i1 %descriptor.owner.inside.118, %descriptor.offset.inside.119
  %descriptor.range.inside.125 = and i1 %descriptor.owner.offset.valid.123, %descriptor.extent.inside.121
  %descriptor.range.valid.124 = and i1 %descriptor.range.inside.125, %descriptor.payload.inside.122
  %descriptor.type.valid.126 = icmp eq i32 12, 12
  %descriptor.valid.127 = and i1 %descriptor.range.valid.124, %descriptor.type.valid.126
  br i1 %descriptor.valid.127, label %descriptor.valid.128, label %descriptor.invalid.129
descriptor.invalid.129:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.128:
  %descriptor.initialized.status.130 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.53, i32 %descriptor.value.55)
  %helper.ok.131 = icmp eq i32 %descriptor.initialized.status.130, 0
  br i1 %helper.ok.131, label %helper.continue.132, label %frame.failure.0
helper.continue.132:
  %local.is.active.133 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.133, label %local.descriptor.active.134, label %local.descriptor.inactive.135
local.descriptor.active.134:
  %local.check.offset.137 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.138 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.139 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.140 = load i32, ptr %local.owner.end.6, align 4
  %context.field.141 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.142 = load i32, ptr %context.field.141, align 4
  %stack.sub.145 = sub i32 %local.check.owner.end.140, %local.check.offset.137
  %descriptor.owner.inside.143 = icmp ule i32 %local.check.owner.end.140, %context.value.142
  %descriptor.offset.inside.144 = icmp ule i32 %local.check.offset.137, %local.check.owner.end.140
  %descriptor.extent.inside.146 = icmp ule i32 %local.check.extent.138, %stack.sub.145
  %descriptor.payload.inside.147 = icmp ule i32 %local.check.payload.139, %local.check.extent.138
  %descriptor.owner.offset.valid.148 = and i1 %descriptor.owner.inside.143, %descriptor.offset.inside.144
  %descriptor.range.inside.150 = and i1 %descriptor.owner.offset.valid.148, %descriptor.extent.inside.146
  %descriptor.range.valid.149 = and i1 %descriptor.range.inside.150, %descriptor.payload.inside.147
  br i1 %descriptor.range.valid.149, label %descriptor.valid.151, label %descriptor.invalid.152
descriptor.invalid.152:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.151:
  %descriptor.initialized.status.153 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.137, i32 %local.check.extent.138)
  %helper.ok.154 = icmp eq i32 %descriptor.initialized.status.153, 0
  br i1 %helper.ok.154, label %helper.continue.155, label %frame.failure.0
helper.continue.155:
  br label %local.descriptor.checked.136
local.descriptor.inactive.135:
  br label %local.descriptor.checked.136
local.descriptor.checked.136:
  %local.is.active.156 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.156, label %local.descriptor.active.157, label %local.descriptor.inactive.158
local.descriptor.active.157:
  %local.check.offset.160 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.161 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.162 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.163 = load i32, ptr %local.owner.end.12, align 4
  %context.field.164 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.165 = load i32, ptr %context.field.164, align 4
  %stack.sub.168 = sub i32 %local.check.owner.end.163, %local.check.offset.160
  %descriptor.owner.inside.166 = icmp ule i32 %local.check.owner.end.163, %context.value.165
  %descriptor.offset.inside.167 = icmp ule i32 %local.check.offset.160, %local.check.owner.end.163
  %descriptor.extent.inside.169 = icmp ule i32 %local.check.extent.161, %stack.sub.168
  %descriptor.payload.inside.170 = icmp ule i32 %local.check.payload.162, %local.check.extent.161
  %descriptor.owner.offset.valid.171 = and i1 %descriptor.owner.inside.166, %descriptor.offset.inside.167
  %descriptor.range.inside.173 = and i1 %descriptor.owner.offset.valid.171, %descriptor.extent.inside.169
  %descriptor.range.valid.172 = and i1 %descriptor.range.inside.173, %descriptor.payload.inside.170
  br i1 %descriptor.range.valid.172, label %descriptor.valid.174, label %descriptor.invalid.175
descriptor.invalid.175:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.174:
  %descriptor.initialized.status.176 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.160, i32 %local.check.extent.161)
  %helper.ok.177 = icmp eq i32 %descriptor.initialized.status.176, 0
  br i1 %helper.ok.177, label %helper.continue.178, label %frame.failure.0
helper.continue.178:
  br label %local.descriptor.checked.159
local.descriptor.inactive.158:
  br label %local.descriptor.checked.159
local.descriptor.checked.159:
  %local.is.active.179 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.179, label %local.descriptor.active.180, label %local.descriptor.inactive.181
local.descriptor.active.180:
  %local.check.offset.183 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.184 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.185 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.186 = load i32, ptr %local.owner.end.18, align 4
  %context.field.187 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.188 = load i32, ptr %context.field.187, align 4
  %stack.sub.191 = sub i32 %local.check.owner.end.186, %local.check.offset.183
  %descriptor.owner.inside.189 = icmp ule i32 %local.check.owner.end.186, %context.value.188
  %descriptor.offset.inside.190 = icmp ule i32 %local.check.offset.183, %local.check.owner.end.186
  %descriptor.extent.inside.192 = icmp ule i32 %local.check.extent.184, %stack.sub.191
  %descriptor.payload.inside.193 = icmp ule i32 %local.check.payload.185, %local.check.extent.184
  %descriptor.owner.offset.valid.194 = and i1 %descriptor.owner.inside.189, %descriptor.offset.inside.190
  %descriptor.range.inside.196 = and i1 %descriptor.owner.offset.valid.194, %descriptor.extent.inside.192
  %descriptor.range.valid.195 = and i1 %descriptor.range.inside.196, %descriptor.payload.inside.193
  br i1 %descriptor.range.valid.195, label %descriptor.valid.197, label %descriptor.invalid.198
descriptor.invalid.198:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.197:
  %descriptor.initialized.status.199 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.183, i32 %local.check.extent.184)
  %helper.ok.200 = icmp eq i32 %descriptor.initialized.status.199, 0
  br i1 %helper.ok.200, label %helper.continue.201, label %frame.failure.0
helper.continue.201:
  br label %local.descriptor.checked.182
local.descriptor.inactive.181:
  br label %local.descriptor.checked.182
local.descriptor.checked.182:
  %local.is.active.202 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.202, label %local.descriptor.active.203, label %local.descriptor.inactive.204
local.descriptor.active.203:
  %local.check.offset.206 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.207 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.208 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.209 = load i32, ptr %local.owner.end.24, align 4
  %context.field.210 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.211 = load i32, ptr %context.field.210, align 4
  %stack.sub.214 = sub i32 %local.check.owner.end.209, %local.check.offset.206
  %descriptor.owner.inside.212 = icmp ule i32 %local.check.owner.end.209, %context.value.211
  %descriptor.offset.inside.213 = icmp ule i32 %local.check.offset.206, %local.check.owner.end.209
  %descriptor.extent.inside.215 = icmp ule i32 %local.check.extent.207, %stack.sub.214
  %descriptor.payload.inside.216 = icmp ule i32 %local.check.payload.208, %local.check.extent.207
  %descriptor.owner.offset.valid.217 = and i1 %descriptor.owner.inside.212, %descriptor.offset.inside.213
  %descriptor.range.inside.219 = and i1 %descriptor.owner.offset.valid.217, %descriptor.extent.inside.215
  %descriptor.range.valid.218 = and i1 %descriptor.range.inside.219, %descriptor.payload.inside.216
  br i1 %descriptor.range.valid.218, label %descriptor.valid.220, label %descriptor.invalid.221
descriptor.invalid.221:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.220:
  %descriptor.initialized.status.222 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.206, i32 %local.check.extent.207)
  %helper.ok.223 = icmp eq i32 %descriptor.initialized.status.222, 0
  br i1 %helper.ok.223, label %helper.continue.224, label %frame.failure.0
helper.continue.224:
  br label %local.descriptor.checked.205
local.descriptor.inactive.204:
  br label %local.descriptor.checked.205
local.descriptor.checked.205:
  %local.is.active.225 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.225, label %local.descriptor.active.226, label %local.descriptor.inactive.227
local.descriptor.active.226:
  %local.check.offset.229 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.230 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.231 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.232 = load i32, ptr %local.owner.end.30, align 4
  %context.field.233 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.234 = load i32, ptr %context.field.233, align 4
  %stack.sub.237 = sub i32 %local.check.owner.end.232, %local.check.offset.229
  %descriptor.owner.inside.235 = icmp ule i32 %local.check.owner.end.232, %context.value.234
  %descriptor.offset.inside.236 = icmp ule i32 %local.check.offset.229, %local.check.owner.end.232
  %descriptor.extent.inside.238 = icmp ule i32 %local.check.extent.230, %stack.sub.237
  %descriptor.payload.inside.239 = icmp ule i32 %local.check.payload.231, %local.check.extent.230
  %descriptor.owner.offset.valid.240 = and i1 %descriptor.owner.inside.235, %descriptor.offset.inside.236
  %descriptor.range.inside.242 = and i1 %descriptor.owner.offset.valid.240, %descriptor.extent.inside.238
  %descriptor.range.valid.241 = and i1 %descriptor.range.inside.242, %descriptor.payload.inside.239
  br i1 %descriptor.range.valid.241, label %descriptor.valid.243, label %descriptor.invalid.244
descriptor.invalid.244:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.243:
  %descriptor.initialized.status.245 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.229, i32 %local.check.extent.230)
  %helper.ok.246 = icmp eq i32 %descriptor.initialized.status.245, 0
  br i1 %helper.ok.246, label %helper.continue.247, label %frame.failure.0
helper.continue.247:
  br label %local.descriptor.checked.228
local.descriptor.inactive.227:
  br label %local.descriptor.checked.228
local.descriptor.checked.228:
  %local.is.active.248 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.248, label %local.descriptor.active.249, label %local.descriptor.inactive.250
local.descriptor.active.249:
  %local.check.offset.252 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.253 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.254 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.255 = load i32, ptr %local.owner.end.36, align 4
  %context.field.256 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.257 = load i32, ptr %context.field.256, align 4
  %stack.sub.260 = sub i32 %local.check.owner.end.255, %local.check.offset.252
  %descriptor.owner.inside.258 = icmp ule i32 %local.check.owner.end.255, %context.value.257
  %descriptor.offset.inside.259 = icmp ule i32 %local.check.offset.252, %local.check.owner.end.255
  %descriptor.extent.inside.261 = icmp ule i32 %local.check.extent.253, %stack.sub.260
  %descriptor.payload.inside.262 = icmp ule i32 %local.check.payload.254, %local.check.extent.253
  %descriptor.owner.offset.valid.263 = and i1 %descriptor.owner.inside.258, %descriptor.offset.inside.259
  %descriptor.range.inside.265 = and i1 %descriptor.owner.offset.valid.263, %descriptor.extent.inside.261
  %descriptor.range.valid.264 = and i1 %descriptor.range.inside.265, %descriptor.payload.inside.262
  br i1 %descriptor.range.valid.264, label %descriptor.valid.266, label %descriptor.invalid.267
descriptor.invalid.267:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.266:
  %descriptor.initialized.status.268 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.252, i32 %local.check.extent.253)
  %helper.ok.269 = icmp eq i32 %descriptor.initialized.status.268, 0
  br i1 %helper.ok.269, label %helper.continue.270, label %frame.failure.0
helper.continue.270:
  br label %local.descriptor.checked.251
local.descriptor.inactive.250:
  br label %local.descriptor.checked.251
local.descriptor.checked.251:
  %step.status.271 = call i32 @al_owning_charge_step(ptr %ctx, i32 4)
  %helper.ok.272 = icmp eq i32 %step.status.271, 0
  br i1 %helper.ok.272, label %helper.continue.273, label %frame.failure.0
helper.continue.273:
  store i1 true, ptr %local.active.8, align 1
  store i32 %descriptor.value.53, ptr %local.offset.9, align 4
  store i32 %descriptor.value.55, ptr %local.extent.10, align 4
  store i32 %descriptor.value.57, ptr %local.payload.11, align 4
  store i32 %descriptor.value.59, ptr %local.owner.end.12, align 4
  store i32 12, ptr %local.type.13, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %descriptor.value.53, i32 20, i32 %descriptor.value.57, i32 %descriptor.value.59, i32 %descriptor.value.55)
  %context.field.274 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.275 = load i32, ptr %context.field.274, align 4
  %runtime.ok.276 = icmp eq i32 %context.value.275, 0
  br i1 %runtime.ok.276, label %runtime.continue.277, label %frame.failure.0
runtime.continue.277:
  %local.is.active.278 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.278, label %local.descriptor.active.279, label %local.descriptor.inactive.280
local.descriptor.active.279:
  %local.check.offset.282 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.283 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.284 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.285 = load i32, ptr %local.owner.end.6, align 4
  %context.field.286 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.287 = load i32, ptr %context.field.286, align 4
  %stack.sub.290 = sub i32 %local.check.owner.end.285, %local.check.offset.282
  %descriptor.owner.inside.288 = icmp ule i32 %local.check.owner.end.285, %context.value.287
  %descriptor.offset.inside.289 = icmp ule i32 %local.check.offset.282, %local.check.owner.end.285
  %descriptor.extent.inside.291 = icmp ule i32 %local.check.extent.283, %stack.sub.290
  %descriptor.payload.inside.292 = icmp ule i32 %local.check.payload.284, %local.check.extent.283
  %descriptor.owner.offset.valid.293 = and i1 %descriptor.owner.inside.288, %descriptor.offset.inside.289
  %descriptor.range.inside.295 = and i1 %descriptor.owner.offset.valid.293, %descriptor.extent.inside.291
  %descriptor.range.valid.294 = and i1 %descriptor.range.inside.295, %descriptor.payload.inside.292
  br i1 %descriptor.range.valid.294, label %descriptor.valid.296, label %descriptor.invalid.297
descriptor.invalid.297:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.296:
  %descriptor.initialized.status.298 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.282, i32 %local.check.extent.283)
  %helper.ok.299 = icmp eq i32 %descriptor.initialized.status.298, 0
  br i1 %helper.ok.299, label %helper.continue.300, label %frame.failure.0
helper.continue.300:
  br label %local.descriptor.checked.281
local.descriptor.inactive.280:
  br label %local.descriptor.checked.281
local.descriptor.checked.281:
  %local.is.active.301 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.301, label %local.descriptor.active.302, label %local.descriptor.inactive.303
local.descriptor.active.302:
  %local.check.offset.305 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.306 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.307 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.308 = load i32, ptr %local.owner.end.12, align 4
  %context.field.309 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.310 = load i32, ptr %context.field.309, align 4
  %stack.sub.313 = sub i32 %local.check.owner.end.308, %local.check.offset.305
  %descriptor.owner.inside.311 = icmp ule i32 %local.check.owner.end.308, %context.value.310
  %descriptor.offset.inside.312 = icmp ule i32 %local.check.offset.305, %local.check.owner.end.308
  %descriptor.extent.inside.314 = icmp ule i32 %local.check.extent.306, %stack.sub.313
  %descriptor.payload.inside.315 = icmp ule i32 %local.check.payload.307, %local.check.extent.306
  %descriptor.owner.offset.valid.316 = and i1 %descriptor.owner.inside.311, %descriptor.offset.inside.312
  %descriptor.range.inside.318 = and i1 %descriptor.owner.offset.valid.316, %descriptor.extent.inside.314
  %descriptor.range.valid.317 = and i1 %descriptor.range.inside.318, %descriptor.payload.inside.315
  br i1 %descriptor.range.valid.317, label %descriptor.valid.319, label %descriptor.invalid.320
descriptor.invalid.320:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.319:
  %descriptor.initialized.status.321 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.305, i32 %local.check.extent.306)
  %helper.ok.322 = icmp eq i32 %descriptor.initialized.status.321, 0
  br i1 %helper.ok.322, label %helper.continue.323, label %frame.failure.0
helper.continue.323:
  br label %local.descriptor.checked.304
local.descriptor.inactive.303:
  br label %local.descriptor.checked.304
local.descriptor.checked.304:
  %local.is.active.324 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.324, label %local.descriptor.active.325, label %local.descriptor.inactive.326
local.descriptor.active.325:
  %local.check.offset.328 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.329 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.330 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.331 = load i32, ptr %local.owner.end.18, align 4
  %context.field.332 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.333 = load i32, ptr %context.field.332, align 4
  %stack.sub.336 = sub i32 %local.check.owner.end.331, %local.check.offset.328
  %descriptor.owner.inside.334 = icmp ule i32 %local.check.owner.end.331, %context.value.333
  %descriptor.offset.inside.335 = icmp ule i32 %local.check.offset.328, %local.check.owner.end.331
  %descriptor.extent.inside.337 = icmp ule i32 %local.check.extent.329, %stack.sub.336
  %descriptor.payload.inside.338 = icmp ule i32 %local.check.payload.330, %local.check.extent.329
  %descriptor.owner.offset.valid.339 = and i1 %descriptor.owner.inside.334, %descriptor.offset.inside.335
  %descriptor.range.inside.341 = and i1 %descriptor.owner.offset.valid.339, %descriptor.extent.inside.337
  %descriptor.range.valid.340 = and i1 %descriptor.range.inside.341, %descriptor.payload.inside.338
  br i1 %descriptor.range.valid.340, label %descriptor.valid.342, label %descriptor.invalid.343
descriptor.invalid.343:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.342:
  %descriptor.initialized.status.344 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.328, i32 %local.check.extent.329)
  %helper.ok.345 = icmp eq i32 %descriptor.initialized.status.344, 0
  br i1 %helper.ok.345, label %helper.continue.346, label %frame.failure.0
helper.continue.346:
  br label %local.descriptor.checked.327
local.descriptor.inactive.326:
  br label %local.descriptor.checked.327
local.descriptor.checked.327:
  %local.is.active.347 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.347, label %local.descriptor.active.348, label %local.descriptor.inactive.349
local.descriptor.active.348:
  %local.check.offset.351 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.352 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.353 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.354 = load i32, ptr %local.owner.end.24, align 4
  %context.field.355 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.356 = load i32, ptr %context.field.355, align 4
  %stack.sub.359 = sub i32 %local.check.owner.end.354, %local.check.offset.351
  %descriptor.owner.inside.357 = icmp ule i32 %local.check.owner.end.354, %context.value.356
  %descriptor.offset.inside.358 = icmp ule i32 %local.check.offset.351, %local.check.owner.end.354
  %descriptor.extent.inside.360 = icmp ule i32 %local.check.extent.352, %stack.sub.359
  %descriptor.payload.inside.361 = icmp ule i32 %local.check.payload.353, %local.check.extent.352
  %descriptor.owner.offset.valid.362 = and i1 %descriptor.owner.inside.357, %descriptor.offset.inside.358
  %descriptor.range.inside.364 = and i1 %descriptor.owner.offset.valid.362, %descriptor.extent.inside.360
  %descriptor.range.valid.363 = and i1 %descriptor.range.inside.364, %descriptor.payload.inside.361
  br i1 %descriptor.range.valid.363, label %descriptor.valid.365, label %descriptor.invalid.366
descriptor.invalid.366:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.365:
  %descriptor.initialized.status.367 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.351, i32 %local.check.extent.352)
  %helper.ok.368 = icmp eq i32 %descriptor.initialized.status.367, 0
  br i1 %helper.ok.368, label %helper.continue.369, label %frame.failure.0
helper.continue.369:
  br label %local.descriptor.checked.350
local.descriptor.inactive.349:
  br label %local.descriptor.checked.350
local.descriptor.checked.350:
  %local.is.active.370 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.370, label %local.descriptor.active.371, label %local.descriptor.inactive.372
local.descriptor.active.371:
  %local.check.offset.374 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.375 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.376 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.377 = load i32, ptr %local.owner.end.30, align 4
  %context.field.378 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.379 = load i32, ptr %context.field.378, align 4
  %stack.sub.382 = sub i32 %local.check.owner.end.377, %local.check.offset.374
  %descriptor.owner.inside.380 = icmp ule i32 %local.check.owner.end.377, %context.value.379
  %descriptor.offset.inside.381 = icmp ule i32 %local.check.offset.374, %local.check.owner.end.377
  %descriptor.extent.inside.383 = icmp ule i32 %local.check.extent.375, %stack.sub.382
  %descriptor.payload.inside.384 = icmp ule i32 %local.check.payload.376, %local.check.extent.375
  %descriptor.owner.offset.valid.385 = and i1 %descriptor.owner.inside.380, %descriptor.offset.inside.381
  %descriptor.range.inside.387 = and i1 %descriptor.owner.offset.valid.385, %descriptor.extent.inside.383
  %descriptor.range.valid.386 = and i1 %descriptor.range.inside.387, %descriptor.payload.inside.384
  br i1 %descriptor.range.valid.386, label %descriptor.valid.388, label %descriptor.invalid.389
descriptor.invalid.389:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.388:
  %descriptor.initialized.status.390 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.374, i32 %local.check.extent.375)
  %helper.ok.391 = icmp eq i32 %descriptor.initialized.status.390, 0
  br i1 %helper.ok.391, label %helper.continue.392, label %frame.failure.0
helper.continue.392:
  br label %local.descriptor.checked.373
local.descriptor.inactive.372:
  br label %local.descriptor.checked.373
local.descriptor.checked.373:
  %local.is.active.393 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.393, label %local.descriptor.active.394, label %local.descriptor.inactive.395
local.descriptor.active.394:
  %local.check.offset.397 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.398 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.399 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.400 = load i32, ptr %local.owner.end.36, align 4
  %context.field.401 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.402 = load i32, ptr %context.field.401, align 4
  %stack.sub.405 = sub i32 %local.check.owner.end.400, %local.check.offset.397
  %descriptor.owner.inside.403 = icmp ule i32 %local.check.owner.end.400, %context.value.402
  %descriptor.offset.inside.404 = icmp ule i32 %local.check.offset.397, %local.check.owner.end.400
  %descriptor.extent.inside.406 = icmp ule i32 %local.check.extent.398, %stack.sub.405
  %descriptor.payload.inside.407 = icmp ule i32 %local.check.payload.399, %local.check.extent.398
  %descriptor.owner.offset.valid.408 = and i1 %descriptor.owner.inside.403, %descriptor.offset.inside.404
  %descriptor.range.inside.410 = and i1 %descriptor.owner.offset.valid.408, %descriptor.extent.inside.406
  %descriptor.range.valid.409 = and i1 %descriptor.range.inside.410, %descriptor.payload.inside.407
  br i1 %descriptor.range.valid.409, label %descriptor.valid.411, label %descriptor.invalid.412
descriptor.invalid.412:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.411:
  %descriptor.initialized.status.413 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.397, i32 %local.check.extent.398)
  %helper.ok.414 = icmp eq i32 %descriptor.initialized.status.413, 0
  br i1 %helper.ok.414, label %helper.continue.415, label %frame.failure.0
helper.continue.415:
  br label %local.descriptor.checked.396
local.descriptor.inactive.395:
  br label %local.descriptor.checked.396
local.descriptor.checked.396:
  %step.status.416 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.417 = icmp eq i32 %step.status.416, 0
  br i1 %helper.ok.417, label %helper.continue.418, label %frame.failure.0
helper.continue.418:
  %context.field.419 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.420 = load i32, ptr %context.field.419, align 4
  %stack.offset.421 = add i32 %context.value.420, 8
  %reserve.status.422 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.421, i32 6)
  %reserve.ok.423 = icmp eq i32 %reserve.status.422, 0
  br i1 %reserve.ok.423, label %reserve.continue.424, label %frame.failure.0
reserve.continue.424:
  call void @al_owning_store_token(ptr %ctx, i32 %context.value.420, i32 4)
  %context.field.425 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.426 = load i32, ptr %context.field.425, align 4
  %runtime.ok.427 = icmp eq i32 %context.value.426, 0
  br i1 %runtime.ok.427, label %runtime.continue.428, label %frame.failure.0
runtime.continue.428:
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 4, i32 %context.value.420, i32 8, i32 0, i32 0, i32 0)
  %context.field.429 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.430 = load i32, ptr %context.field.429, align 4
  %runtime.ok.431 = icmp eq i32 %context.value.430, 0
  br i1 %runtime.ok.431, label %runtime.continue.432, label %frame.failure.0
runtime.continue.432:
  %context.field.433 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.434 = load i32, ptr %context.field.433, align 4
  %stack.sub.437 = sub i32 %stack.offset.421, %context.value.420
  %descriptor.owner.inside.435 = icmp ule i32 %stack.offset.421, %context.value.434
  %descriptor.offset.inside.436 = icmp ule i32 %context.value.420, %stack.offset.421
  %descriptor.extent.inside.438 = icmp ule i32 8, %stack.sub.437
  %descriptor.payload.inside.439 = icmp ule i32 0, 8
  %descriptor.owner.offset.valid.440 = and i1 %descriptor.owner.inside.435, %descriptor.offset.inside.436
  %descriptor.range.inside.442 = and i1 %descriptor.owner.offset.valid.440, %descriptor.extent.inside.438
  %descriptor.range.valid.441 = and i1 %descriptor.range.inside.442, %descriptor.payload.inside.439
  %descriptor.type.valid.443 = icmp eq i32 4, 4
  %descriptor.valid.444 = and i1 %descriptor.range.valid.441, %descriptor.type.valid.443
  br i1 %descriptor.valid.444, label %descriptor.valid.445, label %descriptor.invalid.446
descriptor.invalid.446:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.445:
  %descriptor.initialized.status.447 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.420, i32 8)
  %helper.ok.448 = icmp eq i32 %descriptor.initialized.status.447, 0
  br i1 %helper.ok.448, label %helper.continue.449, label %frame.failure.0
helper.continue.449:
  %local.is.active.450 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.450, label %local.descriptor.active.451, label %local.descriptor.inactive.452
local.descriptor.active.451:
  %local.check.offset.454 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.455 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.456 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.457 = load i32, ptr %local.owner.end.6, align 4
  %context.field.458 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.459 = load i32, ptr %context.field.458, align 4
  %stack.sub.462 = sub i32 %local.check.owner.end.457, %local.check.offset.454
  %descriptor.owner.inside.460 = icmp ule i32 %local.check.owner.end.457, %context.value.459
  %descriptor.offset.inside.461 = icmp ule i32 %local.check.offset.454, %local.check.owner.end.457
  %descriptor.extent.inside.463 = icmp ule i32 %local.check.extent.455, %stack.sub.462
  %descriptor.payload.inside.464 = icmp ule i32 %local.check.payload.456, %local.check.extent.455
  %descriptor.owner.offset.valid.465 = and i1 %descriptor.owner.inside.460, %descriptor.offset.inside.461
  %descriptor.range.inside.467 = and i1 %descriptor.owner.offset.valid.465, %descriptor.extent.inside.463
  %descriptor.range.valid.466 = and i1 %descriptor.range.inside.467, %descriptor.payload.inside.464
  br i1 %descriptor.range.valid.466, label %descriptor.valid.468, label %descriptor.invalid.469
descriptor.invalid.469:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.468:
  %descriptor.initialized.status.470 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.454, i32 %local.check.extent.455)
  %helper.ok.471 = icmp eq i32 %descriptor.initialized.status.470, 0
  br i1 %helper.ok.471, label %helper.continue.472, label %frame.failure.0
helper.continue.472:
  br label %local.descriptor.checked.453
local.descriptor.inactive.452:
  br label %local.descriptor.checked.453
local.descriptor.checked.453:
  %local.is.active.473 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.473, label %local.descriptor.active.474, label %local.descriptor.inactive.475
local.descriptor.active.474:
  %local.check.offset.477 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.478 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.479 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.480 = load i32, ptr %local.owner.end.12, align 4
  %context.field.481 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.482 = load i32, ptr %context.field.481, align 4
  %stack.sub.485 = sub i32 %local.check.owner.end.480, %local.check.offset.477
  %descriptor.owner.inside.483 = icmp ule i32 %local.check.owner.end.480, %context.value.482
  %descriptor.offset.inside.484 = icmp ule i32 %local.check.offset.477, %local.check.owner.end.480
  %descriptor.extent.inside.486 = icmp ule i32 %local.check.extent.478, %stack.sub.485
  %descriptor.payload.inside.487 = icmp ule i32 %local.check.payload.479, %local.check.extent.478
  %descriptor.owner.offset.valid.488 = and i1 %descriptor.owner.inside.483, %descriptor.offset.inside.484
  %descriptor.range.inside.490 = and i1 %descriptor.owner.offset.valid.488, %descriptor.extent.inside.486
  %descriptor.range.valid.489 = and i1 %descriptor.range.inside.490, %descriptor.payload.inside.487
  br i1 %descriptor.range.valid.489, label %descriptor.valid.491, label %descriptor.invalid.492
descriptor.invalid.492:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.491:
  %descriptor.initialized.status.493 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.477, i32 %local.check.extent.478)
  %helper.ok.494 = icmp eq i32 %descriptor.initialized.status.493, 0
  br i1 %helper.ok.494, label %helper.continue.495, label %frame.failure.0
helper.continue.495:
  br label %local.descriptor.checked.476
local.descriptor.inactive.475:
  br label %local.descriptor.checked.476
local.descriptor.checked.476:
  %local.is.active.496 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.496, label %local.descriptor.active.497, label %local.descriptor.inactive.498
local.descriptor.active.497:
  %local.check.offset.500 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.501 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.502 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.503 = load i32, ptr %local.owner.end.18, align 4
  %context.field.504 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.505 = load i32, ptr %context.field.504, align 4
  %stack.sub.508 = sub i32 %local.check.owner.end.503, %local.check.offset.500
  %descriptor.owner.inside.506 = icmp ule i32 %local.check.owner.end.503, %context.value.505
  %descriptor.offset.inside.507 = icmp ule i32 %local.check.offset.500, %local.check.owner.end.503
  %descriptor.extent.inside.509 = icmp ule i32 %local.check.extent.501, %stack.sub.508
  %descriptor.payload.inside.510 = icmp ule i32 %local.check.payload.502, %local.check.extent.501
  %descriptor.owner.offset.valid.511 = and i1 %descriptor.owner.inside.506, %descriptor.offset.inside.507
  %descriptor.range.inside.513 = and i1 %descriptor.owner.offset.valid.511, %descriptor.extent.inside.509
  %descriptor.range.valid.512 = and i1 %descriptor.range.inside.513, %descriptor.payload.inside.510
  br i1 %descriptor.range.valid.512, label %descriptor.valid.514, label %descriptor.invalid.515
descriptor.invalid.515:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.514:
  %descriptor.initialized.status.516 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.500, i32 %local.check.extent.501)
  %helper.ok.517 = icmp eq i32 %descriptor.initialized.status.516, 0
  br i1 %helper.ok.517, label %helper.continue.518, label %frame.failure.0
helper.continue.518:
  br label %local.descriptor.checked.499
local.descriptor.inactive.498:
  br label %local.descriptor.checked.499
local.descriptor.checked.499:
  %local.is.active.519 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.519, label %local.descriptor.active.520, label %local.descriptor.inactive.521
local.descriptor.active.520:
  %local.check.offset.523 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.524 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.525 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.526 = load i32, ptr %local.owner.end.24, align 4
  %context.field.527 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.528 = load i32, ptr %context.field.527, align 4
  %stack.sub.531 = sub i32 %local.check.owner.end.526, %local.check.offset.523
  %descriptor.owner.inside.529 = icmp ule i32 %local.check.owner.end.526, %context.value.528
  %descriptor.offset.inside.530 = icmp ule i32 %local.check.offset.523, %local.check.owner.end.526
  %descriptor.extent.inside.532 = icmp ule i32 %local.check.extent.524, %stack.sub.531
  %descriptor.payload.inside.533 = icmp ule i32 %local.check.payload.525, %local.check.extent.524
  %descriptor.owner.offset.valid.534 = and i1 %descriptor.owner.inside.529, %descriptor.offset.inside.530
  %descriptor.range.inside.536 = and i1 %descriptor.owner.offset.valid.534, %descriptor.extent.inside.532
  %descriptor.range.valid.535 = and i1 %descriptor.range.inside.536, %descriptor.payload.inside.533
  br i1 %descriptor.range.valid.535, label %descriptor.valid.537, label %descriptor.invalid.538
descriptor.invalid.538:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.537:
  %descriptor.initialized.status.539 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.523, i32 %local.check.extent.524)
  %helper.ok.540 = icmp eq i32 %descriptor.initialized.status.539, 0
  br i1 %helper.ok.540, label %helper.continue.541, label %frame.failure.0
helper.continue.541:
  br label %local.descriptor.checked.522
local.descriptor.inactive.521:
  br label %local.descriptor.checked.522
local.descriptor.checked.522:
  %local.is.active.542 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.542, label %local.descriptor.active.543, label %local.descriptor.inactive.544
local.descriptor.active.543:
  %local.check.offset.546 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.547 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.548 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.549 = load i32, ptr %local.owner.end.30, align 4
  %context.field.550 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.551 = load i32, ptr %context.field.550, align 4
  %stack.sub.554 = sub i32 %local.check.owner.end.549, %local.check.offset.546
  %descriptor.owner.inside.552 = icmp ule i32 %local.check.owner.end.549, %context.value.551
  %descriptor.offset.inside.553 = icmp ule i32 %local.check.offset.546, %local.check.owner.end.549
  %descriptor.extent.inside.555 = icmp ule i32 %local.check.extent.547, %stack.sub.554
  %descriptor.payload.inside.556 = icmp ule i32 %local.check.payload.548, %local.check.extent.547
  %descriptor.owner.offset.valid.557 = and i1 %descriptor.owner.inside.552, %descriptor.offset.inside.553
  %descriptor.range.inside.559 = and i1 %descriptor.owner.offset.valid.557, %descriptor.extent.inside.555
  %descriptor.range.valid.558 = and i1 %descriptor.range.inside.559, %descriptor.payload.inside.556
  br i1 %descriptor.range.valid.558, label %descriptor.valid.560, label %descriptor.invalid.561
descriptor.invalid.561:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.560:
  %descriptor.initialized.status.562 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.546, i32 %local.check.extent.547)
  %helper.ok.563 = icmp eq i32 %descriptor.initialized.status.562, 0
  br i1 %helper.ok.563, label %helper.continue.564, label %frame.failure.0
helper.continue.564:
  br label %local.descriptor.checked.545
local.descriptor.inactive.544:
  br label %local.descriptor.checked.545
local.descriptor.checked.545:
  %local.is.active.565 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.565, label %local.descriptor.active.566, label %local.descriptor.inactive.567
local.descriptor.active.566:
  %local.check.offset.569 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.570 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.571 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.572 = load i32, ptr %local.owner.end.36, align 4
  %context.field.573 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.574 = load i32, ptr %context.field.573, align 4
  %stack.sub.577 = sub i32 %local.check.owner.end.572, %local.check.offset.569
  %descriptor.owner.inside.575 = icmp ule i32 %local.check.owner.end.572, %context.value.574
  %descriptor.offset.inside.576 = icmp ule i32 %local.check.offset.569, %local.check.owner.end.572
  %descriptor.extent.inside.578 = icmp ule i32 %local.check.extent.570, %stack.sub.577
  %descriptor.payload.inside.579 = icmp ule i32 %local.check.payload.571, %local.check.extent.570
  %descriptor.owner.offset.valid.580 = and i1 %descriptor.owner.inside.575, %descriptor.offset.inside.576
  %descriptor.range.inside.582 = and i1 %descriptor.owner.offset.valid.580, %descriptor.extent.inside.578
  %descriptor.range.valid.581 = and i1 %descriptor.range.inside.582, %descriptor.payload.inside.579
  br i1 %descriptor.range.valid.581, label %descriptor.valid.583, label %descriptor.invalid.584
descriptor.invalid.584:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.583:
  %descriptor.initialized.status.585 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.569, i32 %local.check.extent.570)
  %helper.ok.586 = icmp eq i32 %descriptor.initialized.status.585, 0
  br i1 %helper.ok.586, label %helper.continue.587, label %frame.failure.0
helper.continue.587:
  br label %local.descriptor.checked.568
local.descriptor.inactive.567:
  br label %local.descriptor.checked.568
local.descriptor.checked.568:
  %step.status.588 = call i32 @al_owning_charge_step(ptr %ctx, i32 7)
  %helper.ok.589 = icmp eq i32 %step.status.588, 0
  br i1 %helper.ok.589, label %helper.continue.590, label %frame.failure.0
helper.continue.590:
  store i1 true, ptr %local.active.14, align 1
  store i32 %context.value.420, ptr %local.offset.15, align 4
  store i32 8, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 %stack.offset.421, ptr %local.owner.end.18, align 4
  store i32 4, ptr %local.type.19, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %context.value.420, i32 20, i32 0, i32 %stack.offset.421, i32 8)
  %context.field.591 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.592 = load i32, ptr %context.field.591, align 4
  %runtime.ok.593 = icmp eq i32 %context.value.592, 0
  br i1 %runtime.ok.593, label %runtime.continue.594, label %frame.failure.0
runtime.continue.594:
  %local.is.active.595 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.595, label %local.descriptor.active.596, label %local.descriptor.inactive.597
local.descriptor.active.596:
  %local.check.offset.599 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.600 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.601 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.602 = load i32, ptr %local.owner.end.6, align 4
  %context.field.603 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.604 = load i32, ptr %context.field.603, align 4
  %stack.sub.607 = sub i32 %local.check.owner.end.602, %local.check.offset.599
  %descriptor.owner.inside.605 = icmp ule i32 %local.check.owner.end.602, %context.value.604
  %descriptor.offset.inside.606 = icmp ule i32 %local.check.offset.599, %local.check.owner.end.602
  %descriptor.extent.inside.608 = icmp ule i32 %local.check.extent.600, %stack.sub.607
  %descriptor.payload.inside.609 = icmp ule i32 %local.check.payload.601, %local.check.extent.600
  %descriptor.owner.offset.valid.610 = and i1 %descriptor.owner.inside.605, %descriptor.offset.inside.606
  %descriptor.range.inside.612 = and i1 %descriptor.owner.offset.valid.610, %descriptor.extent.inside.608
  %descriptor.range.valid.611 = and i1 %descriptor.range.inside.612, %descriptor.payload.inside.609
  br i1 %descriptor.range.valid.611, label %descriptor.valid.613, label %descriptor.invalid.614
descriptor.invalid.614:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.613:
  %descriptor.initialized.status.615 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.599, i32 %local.check.extent.600)
  %helper.ok.616 = icmp eq i32 %descriptor.initialized.status.615, 0
  br i1 %helper.ok.616, label %helper.continue.617, label %frame.failure.0
helper.continue.617:
  br label %local.descriptor.checked.598
local.descriptor.inactive.597:
  br label %local.descriptor.checked.598
local.descriptor.checked.598:
  %local.is.active.618 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.618, label %local.descriptor.active.619, label %local.descriptor.inactive.620
local.descriptor.active.619:
  %local.check.offset.622 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.623 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.624 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.625 = load i32, ptr %local.owner.end.12, align 4
  %context.field.626 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.627 = load i32, ptr %context.field.626, align 4
  %stack.sub.630 = sub i32 %local.check.owner.end.625, %local.check.offset.622
  %descriptor.owner.inside.628 = icmp ule i32 %local.check.owner.end.625, %context.value.627
  %descriptor.offset.inside.629 = icmp ule i32 %local.check.offset.622, %local.check.owner.end.625
  %descriptor.extent.inside.631 = icmp ule i32 %local.check.extent.623, %stack.sub.630
  %descriptor.payload.inside.632 = icmp ule i32 %local.check.payload.624, %local.check.extent.623
  %descriptor.owner.offset.valid.633 = and i1 %descriptor.owner.inside.628, %descriptor.offset.inside.629
  %descriptor.range.inside.635 = and i1 %descriptor.owner.offset.valid.633, %descriptor.extent.inside.631
  %descriptor.range.valid.634 = and i1 %descriptor.range.inside.635, %descriptor.payload.inside.632
  br i1 %descriptor.range.valid.634, label %descriptor.valid.636, label %descriptor.invalid.637
descriptor.invalid.637:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.636:
  %descriptor.initialized.status.638 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.622, i32 %local.check.extent.623)
  %helper.ok.639 = icmp eq i32 %descriptor.initialized.status.638, 0
  br i1 %helper.ok.639, label %helper.continue.640, label %frame.failure.0
helper.continue.640:
  br label %local.descriptor.checked.621
local.descriptor.inactive.620:
  br label %local.descriptor.checked.621
local.descriptor.checked.621:
  %local.is.active.641 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.641, label %local.descriptor.active.642, label %local.descriptor.inactive.643
local.descriptor.active.642:
  %local.check.offset.645 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.646 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.647 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.648 = load i32, ptr %local.owner.end.18, align 4
  %context.field.649 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.650 = load i32, ptr %context.field.649, align 4
  %stack.sub.653 = sub i32 %local.check.owner.end.648, %local.check.offset.645
  %descriptor.owner.inside.651 = icmp ule i32 %local.check.owner.end.648, %context.value.650
  %descriptor.offset.inside.652 = icmp ule i32 %local.check.offset.645, %local.check.owner.end.648
  %descriptor.extent.inside.654 = icmp ule i32 %local.check.extent.646, %stack.sub.653
  %descriptor.payload.inside.655 = icmp ule i32 %local.check.payload.647, %local.check.extent.646
  %descriptor.owner.offset.valid.656 = and i1 %descriptor.owner.inside.651, %descriptor.offset.inside.652
  %descriptor.range.inside.658 = and i1 %descriptor.owner.offset.valid.656, %descriptor.extent.inside.654
  %descriptor.range.valid.657 = and i1 %descriptor.range.inside.658, %descriptor.payload.inside.655
  br i1 %descriptor.range.valid.657, label %descriptor.valid.659, label %descriptor.invalid.660
descriptor.invalid.660:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.659:
  %descriptor.initialized.status.661 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.645, i32 %local.check.extent.646)
  %helper.ok.662 = icmp eq i32 %descriptor.initialized.status.661, 0
  br i1 %helper.ok.662, label %helper.continue.663, label %frame.failure.0
helper.continue.663:
  br label %local.descriptor.checked.644
local.descriptor.inactive.643:
  br label %local.descriptor.checked.644
local.descriptor.checked.644:
  %local.is.active.664 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.664, label %local.descriptor.active.665, label %local.descriptor.inactive.666
local.descriptor.active.665:
  %local.check.offset.668 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.669 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.670 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.671 = load i32, ptr %local.owner.end.24, align 4
  %context.field.672 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.673 = load i32, ptr %context.field.672, align 4
  %stack.sub.676 = sub i32 %local.check.owner.end.671, %local.check.offset.668
  %descriptor.owner.inside.674 = icmp ule i32 %local.check.owner.end.671, %context.value.673
  %descriptor.offset.inside.675 = icmp ule i32 %local.check.offset.668, %local.check.owner.end.671
  %descriptor.extent.inside.677 = icmp ule i32 %local.check.extent.669, %stack.sub.676
  %descriptor.payload.inside.678 = icmp ule i32 %local.check.payload.670, %local.check.extent.669
  %descriptor.owner.offset.valid.679 = and i1 %descriptor.owner.inside.674, %descriptor.offset.inside.675
  %descriptor.range.inside.681 = and i1 %descriptor.owner.offset.valid.679, %descriptor.extent.inside.677
  %descriptor.range.valid.680 = and i1 %descriptor.range.inside.681, %descriptor.payload.inside.678
  br i1 %descriptor.range.valid.680, label %descriptor.valid.682, label %descriptor.invalid.683
descriptor.invalid.683:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.682:
  %descriptor.initialized.status.684 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.668, i32 %local.check.extent.669)
  %helper.ok.685 = icmp eq i32 %descriptor.initialized.status.684, 0
  br i1 %helper.ok.685, label %helper.continue.686, label %frame.failure.0
helper.continue.686:
  br label %local.descriptor.checked.667
local.descriptor.inactive.666:
  br label %local.descriptor.checked.667
local.descriptor.checked.667:
  %local.is.active.687 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.687, label %local.descriptor.active.688, label %local.descriptor.inactive.689
local.descriptor.active.688:
  %local.check.offset.691 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.692 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.693 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.694 = load i32, ptr %local.owner.end.30, align 4
  %context.field.695 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.696 = load i32, ptr %context.field.695, align 4
  %stack.sub.699 = sub i32 %local.check.owner.end.694, %local.check.offset.691
  %descriptor.owner.inside.697 = icmp ule i32 %local.check.owner.end.694, %context.value.696
  %descriptor.offset.inside.698 = icmp ule i32 %local.check.offset.691, %local.check.owner.end.694
  %descriptor.extent.inside.700 = icmp ule i32 %local.check.extent.692, %stack.sub.699
  %descriptor.payload.inside.701 = icmp ule i32 %local.check.payload.693, %local.check.extent.692
  %descriptor.owner.offset.valid.702 = and i1 %descriptor.owner.inside.697, %descriptor.offset.inside.698
  %descriptor.range.inside.704 = and i1 %descriptor.owner.offset.valid.702, %descriptor.extent.inside.700
  %descriptor.range.valid.703 = and i1 %descriptor.range.inside.704, %descriptor.payload.inside.701
  br i1 %descriptor.range.valid.703, label %descriptor.valid.705, label %descriptor.invalid.706
descriptor.invalid.706:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.705:
  %descriptor.initialized.status.707 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.691, i32 %local.check.extent.692)
  %helper.ok.708 = icmp eq i32 %descriptor.initialized.status.707, 0
  br i1 %helper.ok.708, label %helper.continue.709, label %frame.failure.0
helper.continue.709:
  br label %local.descriptor.checked.690
local.descriptor.inactive.689:
  br label %local.descriptor.checked.690
local.descriptor.checked.690:
  %local.is.active.710 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.710, label %local.descriptor.active.711, label %local.descriptor.inactive.712
local.descriptor.active.711:
  %local.check.offset.714 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.715 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.716 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.717 = load i32, ptr %local.owner.end.36, align 4
  %context.field.718 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.719 = load i32, ptr %context.field.718, align 4
  %stack.sub.722 = sub i32 %local.check.owner.end.717, %local.check.offset.714
  %descriptor.owner.inside.720 = icmp ule i32 %local.check.owner.end.717, %context.value.719
  %descriptor.offset.inside.721 = icmp ule i32 %local.check.offset.714, %local.check.owner.end.717
  %descriptor.extent.inside.723 = icmp ule i32 %local.check.extent.715, %stack.sub.722
  %descriptor.payload.inside.724 = icmp ule i32 %local.check.payload.716, %local.check.extent.715
  %descriptor.owner.offset.valid.725 = and i1 %descriptor.owner.inside.720, %descriptor.offset.inside.721
  %descriptor.range.inside.727 = and i1 %descriptor.owner.offset.valid.725, %descriptor.extent.inside.723
  %descriptor.range.valid.726 = and i1 %descriptor.range.inside.727, %descriptor.payload.inside.724
  br i1 %descriptor.range.valid.726, label %descriptor.valid.728, label %descriptor.invalid.729
descriptor.invalid.729:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.728:
  %descriptor.initialized.status.730 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.714, i32 %local.check.extent.715)
  %helper.ok.731 = icmp eq i32 %descriptor.initialized.status.730, 0
  br i1 %helper.ok.731, label %helper.continue.732, label %frame.failure.0
helper.continue.732:
  br label %local.descriptor.checked.713
local.descriptor.inactive.712:
  br label %local.descriptor.checked.713
local.descriptor.checked.713:
  %step.status.733 = call i32 @al_owning_charge_step(ptr %ctx, i32 8)
  %helper.ok.734 = icmp eq i32 %step.status.733, 0
  br i1 %helper.ok.734, label %helper.continue.735, label %frame.failure.0
helper.continue.735:
  %context.field.736 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.737 = load i32, ptr %context.field.736, align 4
  store i1 false, ptr %local.active.20, align 1
  store i32 0, ptr %local.offset.21, align 4
  store i32 0, ptr %local.extent.22, align 4
  store i32 0, ptr %local.payload.23, align 4
  store i32 0, ptr %local.owner.end.24, align 4
  store i32 0, ptr %local.type.25, align 4
  store i1 false, ptr %local.active.26, align 1
  store i32 0, ptr %local.offset.27, align 4
  store i32 0, ptr %local.extent.28, align 4
  store i32 0, ptr %local.payload.29, align 4
  store i32 0, ptr %local.owner.end.30, align 4
  store i32 0, ptr %local.type.31, align 4
  store i1 false, ptr %local.active.32, align 1
  store i32 0, ptr %local.offset.33, align 4
  store i32 0, ptr %local.extent.34, align 4
  store i32 0, ptr %local.payload.35, align 4
  store i32 0, ptr %local.owner.end.36, align 4
  store i32 0, ptr %local.type.37, align 4
  %step.status.738 = call i32 @al_owning_charge_step(ptr %ctx, i32 9)
  %helper.ok.739 = icmp eq i32 %step.status.738, 0
  br i1 %helper.ok.739, label %helper.continue.740, label %frame.failure.0
helper.continue.740:
  %local.resolved.offset.741 = load i32, ptr %local.offset.15, align 4
  %local.resolved.extent.742 = load i32, ptr %local.extent.16, align 4
  %local.resolved.payload.743 = load i32, ptr %local.payload.17, align 4
  %local.resolved.owner.end.744 = load i32, ptr %local.owner.end.18, align 4
  %context.field.745 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.746 = load i32, ptr %context.field.745, align 4
  %stack.sub.749 = sub i32 %local.resolved.owner.end.744, %local.resolved.offset.741
  %descriptor.owner.inside.747 = icmp ule i32 %local.resolved.owner.end.744, %context.value.746
  %descriptor.offset.inside.748 = icmp ule i32 %local.resolved.offset.741, %local.resolved.owner.end.744
  %descriptor.extent.inside.750 = icmp ule i32 %local.resolved.extent.742, %stack.sub.749
  %descriptor.payload.inside.751 = icmp ule i32 %local.resolved.payload.743, %local.resolved.extent.742
  %descriptor.owner.offset.valid.752 = and i1 %descriptor.owner.inside.747, %descriptor.offset.inside.748
  %descriptor.range.inside.754 = and i1 %descriptor.owner.offset.valid.752, %descriptor.extent.inside.750
  %descriptor.range.valid.753 = and i1 %descriptor.range.inside.754, %descriptor.payload.inside.751
  %descriptor.type.valid.755 = icmp eq i32 4, 4
  %descriptor.valid.756 = and i1 %descriptor.range.valid.753, %descriptor.type.valid.755
  br i1 %descriptor.valid.756, label %descriptor.valid.757, label %descriptor.invalid.758
descriptor.invalid.758:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.757:
  %descriptor.initialized.status.759 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.741, i32 %local.resolved.extent.742)
  %helper.ok.760 = icmp eq i32 %descriptor.initialized.status.759, 0
  br i1 %helper.ok.760, label %helper.continue.761, label %frame.failure.0
helper.continue.761:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %local.resolved.offset.741, i32 20, i32 %local.resolved.payload.743, i32 %local.resolved.owner.end.744, i32 %local.resolved.extent.742)
  %context.field.762 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.763 = load i32, ptr %context.field.762, align 4
  %runtime.ok.764 = icmp eq i32 %context.value.763, 0
  br i1 %runtime.ok.764, label %runtime.continue.765, label %frame.failure.0
runtime.continue.765:
  %context.field.766 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.767 = load i32, ptr %context.field.766, align 4
  %stack.sub.770 = sub i32 %local.resolved.owner.end.744, %local.resolved.offset.741
  %descriptor.owner.inside.768 = icmp ule i32 %local.resolved.owner.end.744, %context.value.767
  %descriptor.offset.inside.769 = icmp ule i32 %local.resolved.offset.741, %local.resolved.owner.end.744
  %descriptor.extent.inside.771 = icmp ule i32 %local.resolved.extent.742, %stack.sub.770
  %descriptor.payload.inside.772 = icmp ule i32 %local.resolved.payload.743, %local.resolved.extent.742
  %descriptor.owner.offset.valid.773 = and i1 %descriptor.owner.inside.768, %descriptor.offset.inside.769
  %descriptor.range.inside.775 = and i1 %descriptor.owner.offset.valid.773, %descriptor.extent.inside.771
  %descriptor.range.valid.774 = and i1 %descriptor.range.inside.775, %descriptor.payload.inside.772
  %descriptor.type.valid.776 = icmp eq i32 4, 4
  %descriptor.valid.777 = and i1 %descriptor.range.valid.774, %descriptor.type.valid.776
  br i1 %descriptor.valid.777, label %descriptor.valid.778, label %descriptor.invalid.779
descriptor.invalid.779:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.778:
  %descriptor.initialized.status.780 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.741, i32 %local.resolved.extent.742)
  %helper.ok.781 = icmp eq i32 %descriptor.initialized.status.780, 0
  br i1 %helper.ok.781, label %helper.continue.782, label %frame.failure.0
helper.continue.782:
  %local.is.active.783 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.783, label %local.descriptor.active.784, label %local.descriptor.inactive.785
local.descriptor.active.784:
  %local.check.offset.787 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.788 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.789 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.790 = load i32, ptr %local.owner.end.6, align 4
  %context.field.791 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.792 = load i32, ptr %context.field.791, align 4
  %stack.sub.795 = sub i32 %local.check.owner.end.790, %local.check.offset.787
  %descriptor.owner.inside.793 = icmp ule i32 %local.check.owner.end.790, %context.value.792
  %descriptor.offset.inside.794 = icmp ule i32 %local.check.offset.787, %local.check.owner.end.790
  %descriptor.extent.inside.796 = icmp ule i32 %local.check.extent.788, %stack.sub.795
  %descriptor.payload.inside.797 = icmp ule i32 %local.check.payload.789, %local.check.extent.788
  %descriptor.owner.offset.valid.798 = and i1 %descriptor.owner.inside.793, %descriptor.offset.inside.794
  %descriptor.range.inside.800 = and i1 %descriptor.owner.offset.valid.798, %descriptor.extent.inside.796
  %descriptor.range.valid.799 = and i1 %descriptor.range.inside.800, %descriptor.payload.inside.797
  br i1 %descriptor.range.valid.799, label %descriptor.valid.801, label %descriptor.invalid.802
descriptor.invalid.802:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.801:
  %descriptor.initialized.status.803 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.787, i32 %local.check.extent.788)
  %helper.ok.804 = icmp eq i32 %descriptor.initialized.status.803, 0
  br i1 %helper.ok.804, label %helper.continue.805, label %frame.failure.0
helper.continue.805:
  br label %local.descriptor.checked.786
local.descriptor.inactive.785:
  br label %local.descriptor.checked.786
local.descriptor.checked.786:
  %local.is.active.806 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.806, label %local.descriptor.active.807, label %local.descriptor.inactive.808
local.descriptor.active.807:
  %local.check.offset.810 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.811 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.812 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.813 = load i32, ptr %local.owner.end.12, align 4
  %context.field.814 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.815 = load i32, ptr %context.field.814, align 4
  %stack.sub.818 = sub i32 %local.check.owner.end.813, %local.check.offset.810
  %descriptor.owner.inside.816 = icmp ule i32 %local.check.owner.end.813, %context.value.815
  %descriptor.offset.inside.817 = icmp ule i32 %local.check.offset.810, %local.check.owner.end.813
  %descriptor.extent.inside.819 = icmp ule i32 %local.check.extent.811, %stack.sub.818
  %descriptor.payload.inside.820 = icmp ule i32 %local.check.payload.812, %local.check.extent.811
  %descriptor.owner.offset.valid.821 = and i1 %descriptor.owner.inside.816, %descriptor.offset.inside.817
  %descriptor.range.inside.823 = and i1 %descriptor.owner.offset.valid.821, %descriptor.extent.inside.819
  %descriptor.range.valid.822 = and i1 %descriptor.range.inside.823, %descriptor.payload.inside.820
  br i1 %descriptor.range.valid.822, label %descriptor.valid.824, label %descriptor.invalid.825
descriptor.invalid.825:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.824:
  %descriptor.initialized.status.826 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.810, i32 %local.check.extent.811)
  %helper.ok.827 = icmp eq i32 %descriptor.initialized.status.826, 0
  br i1 %helper.ok.827, label %helper.continue.828, label %frame.failure.0
helper.continue.828:
  br label %local.descriptor.checked.809
local.descriptor.inactive.808:
  br label %local.descriptor.checked.809
local.descriptor.checked.809:
  %local.is.active.829 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.829, label %local.descriptor.active.830, label %local.descriptor.inactive.831
local.descriptor.active.830:
  %local.check.offset.833 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.834 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.835 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.836 = load i32, ptr %local.owner.end.18, align 4
  %context.field.837 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.838 = load i32, ptr %context.field.837, align 4
  %stack.sub.841 = sub i32 %local.check.owner.end.836, %local.check.offset.833
  %descriptor.owner.inside.839 = icmp ule i32 %local.check.owner.end.836, %context.value.838
  %descriptor.offset.inside.840 = icmp ule i32 %local.check.offset.833, %local.check.owner.end.836
  %descriptor.extent.inside.842 = icmp ule i32 %local.check.extent.834, %stack.sub.841
  %descriptor.payload.inside.843 = icmp ule i32 %local.check.payload.835, %local.check.extent.834
  %descriptor.owner.offset.valid.844 = and i1 %descriptor.owner.inside.839, %descriptor.offset.inside.840
  %descriptor.range.inside.846 = and i1 %descriptor.owner.offset.valid.844, %descriptor.extent.inside.842
  %descriptor.range.valid.845 = and i1 %descriptor.range.inside.846, %descriptor.payload.inside.843
  br i1 %descriptor.range.valid.845, label %descriptor.valid.847, label %descriptor.invalid.848
descriptor.invalid.848:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.847:
  %descriptor.initialized.status.849 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.833, i32 %local.check.extent.834)
  %helper.ok.850 = icmp eq i32 %descriptor.initialized.status.849, 0
  br i1 %helper.ok.850, label %helper.continue.851, label %frame.failure.0
helper.continue.851:
  br label %local.descriptor.checked.832
local.descriptor.inactive.831:
  br label %local.descriptor.checked.832
local.descriptor.checked.832:
  %local.is.active.852 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.852, label %local.descriptor.active.853, label %local.descriptor.inactive.854
local.descriptor.active.853:
  %local.check.offset.856 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.857 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.858 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.859 = load i32, ptr %local.owner.end.24, align 4
  %context.field.860 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.861 = load i32, ptr %context.field.860, align 4
  %stack.sub.864 = sub i32 %local.check.owner.end.859, %local.check.offset.856
  %descriptor.owner.inside.862 = icmp ule i32 %local.check.owner.end.859, %context.value.861
  %descriptor.offset.inside.863 = icmp ule i32 %local.check.offset.856, %local.check.owner.end.859
  %descriptor.extent.inside.865 = icmp ule i32 %local.check.extent.857, %stack.sub.864
  %descriptor.payload.inside.866 = icmp ule i32 %local.check.payload.858, %local.check.extent.857
  %descriptor.owner.offset.valid.867 = and i1 %descriptor.owner.inside.862, %descriptor.offset.inside.863
  %descriptor.range.inside.869 = and i1 %descriptor.owner.offset.valid.867, %descriptor.extent.inside.865
  %descriptor.range.valid.868 = and i1 %descriptor.range.inside.869, %descriptor.payload.inside.866
  br i1 %descriptor.range.valid.868, label %descriptor.valid.870, label %descriptor.invalid.871
descriptor.invalid.871:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.870:
  %descriptor.initialized.status.872 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.856, i32 %local.check.extent.857)
  %helper.ok.873 = icmp eq i32 %descriptor.initialized.status.872, 0
  br i1 %helper.ok.873, label %helper.continue.874, label %frame.failure.0
helper.continue.874:
  br label %local.descriptor.checked.855
local.descriptor.inactive.854:
  br label %local.descriptor.checked.855
local.descriptor.checked.855:
  %local.is.active.875 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.875, label %local.descriptor.active.876, label %local.descriptor.inactive.877
local.descriptor.active.876:
  %local.check.offset.879 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.880 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.881 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.882 = load i32, ptr %local.owner.end.30, align 4
  %context.field.883 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.884 = load i32, ptr %context.field.883, align 4
  %stack.sub.887 = sub i32 %local.check.owner.end.882, %local.check.offset.879
  %descriptor.owner.inside.885 = icmp ule i32 %local.check.owner.end.882, %context.value.884
  %descriptor.offset.inside.886 = icmp ule i32 %local.check.offset.879, %local.check.owner.end.882
  %descriptor.extent.inside.888 = icmp ule i32 %local.check.extent.880, %stack.sub.887
  %descriptor.payload.inside.889 = icmp ule i32 %local.check.payload.881, %local.check.extent.880
  %descriptor.owner.offset.valid.890 = and i1 %descriptor.owner.inside.885, %descriptor.offset.inside.886
  %descriptor.range.inside.892 = and i1 %descriptor.owner.offset.valid.890, %descriptor.extent.inside.888
  %descriptor.range.valid.891 = and i1 %descriptor.range.inside.892, %descriptor.payload.inside.889
  br i1 %descriptor.range.valid.891, label %descriptor.valid.893, label %descriptor.invalid.894
descriptor.invalid.894:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.893:
  %descriptor.initialized.status.895 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.879, i32 %local.check.extent.880)
  %helper.ok.896 = icmp eq i32 %descriptor.initialized.status.895, 0
  br i1 %helper.ok.896, label %helper.continue.897, label %frame.failure.0
helper.continue.897:
  br label %local.descriptor.checked.878
local.descriptor.inactive.877:
  br label %local.descriptor.checked.878
local.descriptor.checked.878:
  %local.is.active.898 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.898, label %local.descriptor.active.899, label %local.descriptor.inactive.900
local.descriptor.active.899:
  %local.check.offset.902 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.903 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.904 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.905 = load i32, ptr %local.owner.end.36, align 4
  %context.field.906 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.907 = load i32, ptr %context.field.906, align 4
  %stack.sub.910 = sub i32 %local.check.owner.end.905, %local.check.offset.902
  %descriptor.owner.inside.908 = icmp ule i32 %local.check.owner.end.905, %context.value.907
  %descriptor.offset.inside.909 = icmp ule i32 %local.check.offset.902, %local.check.owner.end.905
  %descriptor.extent.inside.911 = icmp ule i32 %local.check.extent.903, %stack.sub.910
  %descriptor.payload.inside.912 = icmp ule i32 %local.check.payload.904, %local.check.extent.903
  %descriptor.owner.offset.valid.913 = and i1 %descriptor.owner.inside.908, %descriptor.offset.inside.909
  %descriptor.range.inside.915 = and i1 %descriptor.owner.offset.valid.913, %descriptor.extent.inside.911
  %descriptor.range.valid.914 = and i1 %descriptor.range.inside.915, %descriptor.payload.inside.912
  br i1 %descriptor.range.valid.914, label %descriptor.valid.916, label %descriptor.invalid.917
descriptor.invalid.917:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.916:
  %descriptor.initialized.status.918 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.902, i32 %local.check.extent.903)
  %helper.ok.919 = icmp eq i32 %descriptor.initialized.status.918, 0
  br i1 %helper.ok.919, label %helper.continue.920, label %frame.failure.0
helper.continue.920:
  br label %local.descriptor.checked.901
local.descriptor.inactive.900:
  br label %local.descriptor.checked.901
local.descriptor.checked.901:
  %step.status.921 = call i32 @al_owning_charge_step(ptr %ctx, i32 10)
  %helper.ok.922 = icmp eq i32 %step.status.921, 0
  br i1 %helper.ok.922, label %helper.continue.923, label %frame.failure.0
helper.continue.923:
  store i1 true, ptr %local.active.20, align 1
  store i32 %local.resolved.offset.741, ptr %local.offset.21, align 4
  store i32 %local.resolved.extent.742, ptr %local.extent.22, align 4
  store i32 %local.resolved.payload.743, ptr %local.payload.23, align 4
  store i32 %local.resolved.owner.end.744, ptr %local.owner.end.24, align 4
  store i32 4, ptr %local.type.25, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %local.resolved.offset.741, i32 20, i32 %local.resolved.payload.743, i32 %local.resolved.owner.end.744, i32 %local.resolved.extent.742)
  %context.field.924 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.925 = load i32, ptr %context.field.924, align 4
  %runtime.ok.926 = icmp eq i32 %context.value.925, 0
  br i1 %runtime.ok.926, label %runtime.continue.927, label %frame.failure.0
runtime.continue.927:
  %local.is.active.928 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.928, label %local.descriptor.active.929, label %local.descriptor.inactive.930
local.descriptor.active.929:
  %local.check.offset.932 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.933 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.934 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.935 = load i32, ptr %local.owner.end.6, align 4
  %context.field.936 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.937 = load i32, ptr %context.field.936, align 4
  %stack.sub.940 = sub i32 %local.check.owner.end.935, %local.check.offset.932
  %descriptor.owner.inside.938 = icmp ule i32 %local.check.owner.end.935, %context.value.937
  %descriptor.offset.inside.939 = icmp ule i32 %local.check.offset.932, %local.check.owner.end.935
  %descriptor.extent.inside.941 = icmp ule i32 %local.check.extent.933, %stack.sub.940
  %descriptor.payload.inside.942 = icmp ule i32 %local.check.payload.934, %local.check.extent.933
  %descriptor.owner.offset.valid.943 = and i1 %descriptor.owner.inside.938, %descriptor.offset.inside.939
  %descriptor.range.inside.945 = and i1 %descriptor.owner.offset.valid.943, %descriptor.extent.inside.941
  %descriptor.range.valid.944 = and i1 %descriptor.range.inside.945, %descriptor.payload.inside.942
  br i1 %descriptor.range.valid.944, label %descriptor.valid.946, label %descriptor.invalid.947
descriptor.invalid.947:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.946:
  %descriptor.initialized.status.948 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.932, i32 %local.check.extent.933)
  %helper.ok.949 = icmp eq i32 %descriptor.initialized.status.948, 0
  br i1 %helper.ok.949, label %helper.continue.950, label %frame.failure.0
helper.continue.950:
  br label %local.descriptor.checked.931
local.descriptor.inactive.930:
  br label %local.descriptor.checked.931
local.descriptor.checked.931:
  %local.is.active.951 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.951, label %local.descriptor.active.952, label %local.descriptor.inactive.953
local.descriptor.active.952:
  %local.check.offset.955 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.956 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.957 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.958 = load i32, ptr %local.owner.end.12, align 4
  %context.field.959 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.960 = load i32, ptr %context.field.959, align 4
  %stack.sub.963 = sub i32 %local.check.owner.end.958, %local.check.offset.955
  %descriptor.owner.inside.961 = icmp ule i32 %local.check.owner.end.958, %context.value.960
  %descriptor.offset.inside.962 = icmp ule i32 %local.check.offset.955, %local.check.owner.end.958
  %descriptor.extent.inside.964 = icmp ule i32 %local.check.extent.956, %stack.sub.963
  %descriptor.payload.inside.965 = icmp ule i32 %local.check.payload.957, %local.check.extent.956
  %descriptor.owner.offset.valid.966 = and i1 %descriptor.owner.inside.961, %descriptor.offset.inside.962
  %descriptor.range.inside.968 = and i1 %descriptor.owner.offset.valid.966, %descriptor.extent.inside.964
  %descriptor.range.valid.967 = and i1 %descriptor.range.inside.968, %descriptor.payload.inside.965
  br i1 %descriptor.range.valid.967, label %descriptor.valid.969, label %descriptor.invalid.970
descriptor.invalid.970:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.969:
  %descriptor.initialized.status.971 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.955, i32 %local.check.extent.956)
  %helper.ok.972 = icmp eq i32 %descriptor.initialized.status.971, 0
  br i1 %helper.ok.972, label %helper.continue.973, label %frame.failure.0
helper.continue.973:
  br label %local.descriptor.checked.954
local.descriptor.inactive.953:
  br label %local.descriptor.checked.954
local.descriptor.checked.954:
  %local.is.active.974 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.974, label %local.descriptor.active.975, label %local.descriptor.inactive.976
local.descriptor.active.975:
  %local.check.offset.978 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.979 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.980 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.981 = load i32, ptr %local.owner.end.18, align 4
  %context.field.982 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.983 = load i32, ptr %context.field.982, align 4
  %stack.sub.986 = sub i32 %local.check.owner.end.981, %local.check.offset.978
  %descriptor.owner.inside.984 = icmp ule i32 %local.check.owner.end.981, %context.value.983
  %descriptor.offset.inside.985 = icmp ule i32 %local.check.offset.978, %local.check.owner.end.981
  %descriptor.extent.inside.987 = icmp ule i32 %local.check.extent.979, %stack.sub.986
  %descriptor.payload.inside.988 = icmp ule i32 %local.check.payload.980, %local.check.extent.979
  %descriptor.owner.offset.valid.989 = and i1 %descriptor.owner.inside.984, %descriptor.offset.inside.985
  %descriptor.range.inside.991 = and i1 %descriptor.owner.offset.valid.989, %descriptor.extent.inside.987
  %descriptor.range.valid.990 = and i1 %descriptor.range.inside.991, %descriptor.payload.inside.988
  br i1 %descriptor.range.valid.990, label %descriptor.valid.992, label %descriptor.invalid.993
descriptor.invalid.993:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.992:
  %descriptor.initialized.status.994 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.978, i32 %local.check.extent.979)
  %helper.ok.995 = icmp eq i32 %descriptor.initialized.status.994, 0
  br i1 %helper.ok.995, label %helper.continue.996, label %frame.failure.0
helper.continue.996:
  br label %local.descriptor.checked.977
local.descriptor.inactive.976:
  br label %local.descriptor.checked.977
local.descriptor.checked.977:
  %local.is.active.997 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.997, label %local.descriptor.active.998, label %local.descriptor.inactive.999
local.descriptor.active.998:
  %local.check.offset.1001 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1002 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1003 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1004 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1005 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1006 = load i32, ptr %context.field.1005, align 4
  %stack.sub.1009 = sub i32 %local.check.owner.end.1004, %local.check.offset.1001
  %descriptor.owner.inside.1007 = icmp ule i32 %local.check.owner.end.1004, %context.value.1006
  %descriptor.offset.inside.1008 = icmp ule i32 %local.check.offset.1001, %local.check.owner.end.1004
  %descriptor.extent.inside.1010 = icmp ule i32 %local.check.extent.1002, %stack.sub.1009
  %descriptor.payload.inside.1011 = icmp ule i32 %local.check.payload.1003, %local.check.extent.1002
  %descriptor.owner.offset.valid.1012 = and i1 %descriptor.owner.inside.1007, %descriptor.offset.inside.1008
  %descriptor.range.inside.1014 = and i1 %descriptor.owner.offset.valid.1012, %descriptor.extent.inside.1010
  %descriptor.range.valid.1013 = and i1 %descriptor.range.inside.1014, %descriptor.payload.inside.1011
  br i1 %descriptor.range.valid.1013, label %descriptor.valid.1015, label %descriptor.invalid.1016
descriptor.invalid.1016:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1015:
  %descriptor.initialized.status.1017 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1001, i32 %local.check.extent.1002)
  %helper.ok.1018 = icmp eq i32 %descriptor.initialized.status.1017, 0
  br i1 %helper.ok.1018, label %helper.continue.1019, label %frame.failure.0
helper.continue.1019:
  br label %local.descriptor.checked.1000
local.descriptor.inactive.999:
  br label %local.descriptor.checked.1000
local.descriptor.checked.1000:
  %local.is.active.1020 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1020, label %local.descriptor.active.1021, label %local.descriptor.inactive.1022
local.descriptor.active.1021:
  %local.check.offset.1024 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1025 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1026 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1027 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1028 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1029 = load i32, ptr %context.field.1028, align 4
  %stack.sub.1032 = sub i32 %local.check.owner.end.1027, %local.check.offset.1024
  %descriptor.owner.inside.1030 = icmp ule i32 %local.check.owner.end.1027, %context.value.1029
  %descriptor.offset.inside.1031 = icmp ule i32 %local.check.offset.1024, %local.check.owner.end.1027
  %descriptor.extent.inside.1033 = icmp ule i32 %local.check.extent.1025, %stack.sub.1032
  %descriptor.payload.inside.1034 = icmp ule i32 %local.check.payload.1026, %local.check.extent.1025
  %descriptor.owner.offset.valid.1035 = and i1 %descriptor.owner.inside.1030, %descriptor.offset.inside.1031
  %descriptor.range.inside.1037 = and i1 %descriptor.owner.offset.valid.1035, %descriptor.extent.inside.1033
  %descriptor.range.valid.1036 = and i1 %descriptor.range.inside.1037, %descriptor.payload.inside.1034
  br i1 %descriptor.range.valid.1036, label %descriptor.valid.1038, label %descriptor.invalid.1039
descriptor.invalid.1039:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1038:
  %descriptor.initialized.status.1040 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1024, i32 %local.check.extent.1025)
  %helper.ok.1041 = icmp eq i32 %descriptor.initialized.status.1040, 0
  br i1 %helper.ok.1041, label %helper.continue.1042, label %frame.failure.0
helper.continue.1042:
  br label %local.descriptor.checked.1023
local.descriptor.inactive.1022:
  br label %local.descriptor.checked.1023
local.descriptor.checked.1023:
  %local.is.active.1043 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1043, label %local.descriptor.active.1044, label %local.descriptor.inactive.1045
local.descriptor.active.1044:
  %local.check.offset.1047 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1048 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1049 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1050 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1051 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1052 = load i32, ptr %context.field.1051, align 4
  %stack.sub.1055 = sub i32 %local.check.owner.end.1050, %local.check.offset.1047
  %descriptor.owner.inside.1053 = icmp ule i32 %local.check.owner.end.1050, %context.value.1052
  %descriptor.offset.inside.1054 = icmp ule i32 %local.check.offset.1047, %local.check.owner.end.1050
  %descriptor.extent.inside.1056 = icmp ule i32 %local.check.extent.1048, %stack.sub.1055
  %descriptor.payload.inside.1057 = icmp ule i32 %local.check.payload.1049, %local.check.extent.1048
  %descriptor.owner.offset.valid.1058 = and i1 %descriptor.owner.inside.1053, %descriptor.offset.inside.1054
  %descriptor.range.inside.1060 = and i1 %descriptor.owner.offset.valid.1058, %descriptor.extent.inside.1056
  %descriptor.range.valid.1059 = and i1 %descriptor.range.inside.1060, %descriptor.payload.inside.1057
  br i1 %descriptor.range.valid.1059, label %descriptor.valid.1061, label %descriptor.invalid.1062
descriptor.invalid.1062:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1061:
  %descriptor.initialized.status.1063 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1047, i32 %local.check.extent.1048)
  %helper.ok.1064 = icmp eq i32 %descriptor.initialized.status.1063, 0
  br i1 %helper.ok.1064, label %helper.continue.1065, label %frame.failure.0
helper.continue.1065:
  br label %local.descriptor.checked.1046
local.descriptor.inactive.1045:
  br label %local.descriptor.checked.1046
local.descriptor.checked.1046:
  %step.status.1066 = call i32 @al_owning_charge_step(ptr %ctx, i32 11)
  %helper.ok.1067 = icmp eq i32 %step.status.1066, 0
  br i1 %helper.ok.1067, label %helper.continue.1068, label %frame.failure.0
helper.continue.1068:
  %local.resolved.offset.1069 = load i32, ptr %local.offset.9, align 4
  %local.resolved.extent.1070 = load i32, ptr %local.extent.10, align 4
  %local.resolved.payload.1071 = load i32, ptr %local.payload.11, align 4
  %local.resolved.owner.end.1072 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1073 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1074 = load i32, ptr %context.field.1073, align 4
  %stack.sub.1077 = sub i32 %local.resolved.owner.end.1072, %local.resolved.offset.1069
  %descriptor.owner.inside.1075 = icmp ule i32 %local.resolved.owner.end.1072, %context.value.1074
  %descriptor.offset.inside.1076 = icmp ule i32 %local.resolved.offset.1069, %local.resolved.owner.end.1072
  %descriptor.extent.inside.1078 = icmp ule i32 %local.resolved.extent.1070, %stack.sub.1077
  %descriptor.payload.inside.1079 = icmp ule i32 %local.resolved.payload.1071, %local.resolved.extent.1070
  %descriptor.owner.offset.valid.1080 = and i1 %descriptor.owner.inside.1075, %descriptor.offset.inside.1076
  %descriptor.range.inside.1082 = and i1 %descriptor.owner.offset.valid.1080, %descriptor.extent.inside.1078
  %descriptor.range.valid.1081 = and i1 %descriptor.range.inside.1082, %descriptor.payload.inside.1079
  %descriptor.type.valid.1083 = icmp eq i32 12, 12
  %descriptor.valid.1084 = and i1 %descriptor.range.valid.1081, %descriptor.type.valid.1083
  br i1 %descriptor.valid.1084, label %descriptor.valid.1085, label %descriptor.invalid.1086
descriptor.invalid.1086:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1085:
  %descriptor.initialized.status.1087 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1069, i32 %local.resolved.extent.1070)
  %helper.ok.1088 = icmp eq i32 %descriptor.initialized.status.1087, 0
  br i1 %helper.ok.1088, label %helper.continue.1089, label %frame.failure.0
helper.continue.1089:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %local.resolved.offset.1069, i32 20, i32 %local.resolved.payload.1071, i32 %local.resolved.owner.end.1072, i32 %local.resolved.extent.1070)
  %context.field.1090 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1091 = load i32, ptr %context.field.1090, align 4
  %runtime.ok.1092 = icmp eq i32 %context.value.1091, 0
  br i1 %runtime.ok.1092, label %runtime.continue.1093, label %frame.failure.0
runtime.continue.1093:
  %context.field.1094 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1095 = load i32, ptr %context.field.1094, align 4
  %stack.sub.1098 = sub i32 %local.resolved.owner.end.1072, %local.resolved.offset.1069
  %descriptor.owner.inside.1096 = icmp ule i32 %local.resolved.owner.end.1072, %context.value.1095
  %descriptor.offset.inside.1097 = icmp ule i32 %local.resolved.offset.1069, %local.resolved.owner.end.1072
  %descriptor.extent.inside.1099 = icmp ule i32 %local.resolved.extent.1070, %stack.sub.1098
  %descriptor.payload.inside.1100 = icmp ule i32 %local.resolved.payload.1071, %local.resolved.extent.1070
  %descriptor.owner.offset.valid.1101 = and i1 %descriptor.owner.inside.1096, %descriptor.offset.inside.1097
  %descriptor.range.inside.1103 = and i1 %descriptor.owner.offset.valid.1101, %descriptor.extent.inside.1099
  %descriptor.range.valid.1102 = and i1 %descriptor.range.inside.1103, %descriptor.payload.inside.1100
  %descriptor.type.valid.1104 = icmp eq i32 12, 12
  %descriptor.valid.1105 = and i1 %descriptor.range.valid.1102, %descriptor.type.valid.1104
  br i1 %descriptor.valid.1105, label %descriptor.valid.1106, label %descriptor.invalid.1107
descriptor.invalid.1107:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1106:
  %descriptor.initialized.status.1108 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1069, i32 %local.resolved.extent.1070)
  %helper.ok.1109 = icmp eq i32 %descriptor.initialized.status.1108, 0
  br i1 %helper.ok.1109, label %helper.continue.1110, label %frame.failure.0
helper.continue.1110:
  %local.is.active.1111 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1111, label %local.descriptor.active.1112, label %local.descriptor.inactive.1113
local.descriptor.active.1112:
  %local.check.offset.1115 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1116 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1117 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1118 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1119 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1120 = load i32, ptr %context.field.1119, align 4
  %stack.sub.1123 = sub i32 %local.check.owner.end.1118, %local.check.offset.1115
  %descriptor.owner.inside.1121 = icmp ule i32 %local.check.owner.end.1118, %context.value.1120
  %descriptor.offset.inside.1122 = icmp ule i32 %local.check.offset.1115, %local.check.owner.end.1118
  %descriptor.extent.inside.1124 = icmp ule i32 %local.check.extent.1116, %stack.sub.1123
  %descriptor.payload.inside.1125 = icmp ule i32 %local.check.payload.1117, %local.check.extent.1116
  %descriptor.owner.offset.valid.1126 = and i1 %descriptor.owner.inside.1121, %descriptor.offset.inside.1122
  %descriptor.range.inside.1128 = and i1 %descriptor.owner.offset.valid.1126, %descriptor.extent.inside.1124
  %descriptor.range.valid.1127 = and i1 %descriptor.range.inside.1128, %descriptor.payload.inside.1125
  br i1 %descriptor.range.valid.1127, label %descriptor.valid.1129, label %descriptor.invalid.1130
descriptor.invalid.1130:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1129:
  %descriptor.initialized.status.1131 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1115, i32 %local.check.extent.1116)
  %helper.ok.1132 = icmp eq i32 %descriptor.initialized.status.1131, 0
  br i1 %helper.ok.1132, label %helper.continue.1133, label %frame.failure.0
helper.continue.1133:
  br label %local.descriptor.checked.1114
local.descriptor.inactive.1113:
  br label %local.descriptor.checked.1114
local.descriptor.checked.1114:
  %local.is.active.1134 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1134, label %local.descriptor.active.1135, label %local.descriptor.inactive.1136
local.descriptor.active.1135:
  %local.check.offset.1138 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1139 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1140 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1141 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1142 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1143 = load i32, ptr %context.field.1142, align 4
  %stack.sub.1146 = sub i32 %local.check.owner.end.1141, %local.check.offset.1138
  %descriptor.owner.inside.1144 = icmp ule i32 %local.check.owner.end.1141, %context.value.1143
  %descriptor.offset.inside.1145 = icmp ule i32 %local.check.offset.1138, %local.check.owner.end.1141
  %descriptor.extent.inside.1147 = icmp ule i32 %local.check.extent.1139, %stack.sub.1146
  %descriptor.payload.inside.1148 = icmp ule i32 %local.check.payload.1140, %local.check.extent.1139
  %descriptor.owner.offset.valid.1149 = and i1 %descriptor.owner.inside.1144, %descriptor.offset.inside.1145
  %descriptor.range.inside.1151 = and i1 %descriptor.owner.offset.valid.1149, %descriptor.extent.inside.1147
  %descriptor.range.valid.1150 = and i1 %descriptor.range.inside.1151, %descriptor.payload.inside.1148
  br i1 %descriptor.range.valid.1150, label %descriptor.valid.1152, label %descriptor.invalid.1153
descriptor.invalid.1153:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1152:
  %descriptor.initialized.status.1154 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1138, i32 %local.check.extent.1139)
  %helper.ok.1155 = icmp eq i32 %descriptor.initialized.status.1154, 0
  br i1 %helper.ok.1155, label %helper.continue.1156, label %frame.failure.0
helper.continue.1156:
  br label %local.descriptor.checked.1137
local.descriptor.inactive.1136:
  br label %local.descriptor.checked.1137
local.descriptor.checked.1137:
  %local.is.active.1157 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1157, label %local.descriptor.active.1158, label %local.descriptor.inactive.1159
local.descriptor.active.1158:
  %local.check.offset.1161 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1162 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1163 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1164 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1165 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1166 = load i32, ptr %context.field.1165, align 4
  %stack.sub.1169 = sub i32 %local.check.owner.end.1164, %local.check.offset.1161
  %descriptor.owner.inside.1167 = icmp ule i32 %local.check.owner.end.1164, %context.value.1166
  %descriptor.offset.inside.1168 = icmp ule i32 %local.check.offset.1161, %local.check.owner.end.1164
  %descriptor.extent.inside.1170 = icmp ule i32 %local.check.extent.1162, %stack.sub.1169
  %descriptor.payload.inside.1171 = icmp ule i32 %local.check.payload.1163, %local.check.extent.1162
  %descriptor.owner.offset.valid.1172 = and i1 %descriptor.owner.inside.1167, %descriptor.offset.inside.1168
  %descriptor.range.inside.1174 = and i1 %descriptor.owner.offset.valid.1172, %descriptor.extent.inside.1170
  %descriptor.range.valid.1173 = and i1 %descriptor.range.inside.1174, %descriptor.payload.inside.1171
  br i1 %descriptor.range.valid.1173, label %descriptor.valid.1175, label %descriptor.invalid.1176
descriptor.invalid.1176:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1175:
  %descriptor.initialized.status.1177 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1161, i32 %local.check.extent.1162)
  %helper.ok.1178 = icmp eq i32 %descriptor.initialized.status.1177, 0
  br i1 %helper.ok.1178, label %helper.continue.1179, label %frame.failure.0
helper.continue.1179:
  br label %local.descriptor.checked.1160
local.descriptor.inactive.1159:
  br label %local.descriptor.checked.1160
local.descriptor.checked.1160:
  %local.is.active.1180 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1180, label %local.descriptor.active.1181, label %local.descriptor.inactive.1182
local.descriptor.active.1181:
  %local.check.offset.1184 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1185 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1186 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1187 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1188 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1189 = load i32, ptr %context.field.1188, align 4
  %stack.sub.1192 = sub i32 %local.check.owner.end.1187, %local.check.offset.1184
  %descriptor.owner.inside.1190 = icmp ule i32 %local.check.owner.end.1187, %context.value.1189
  %descriptor.offset.inside.1191 = icmp ule i32 %local.check.offset.1184, %local.check.owner.end.1187
  %descriptor.extent.inside.1193 = icmp ule i32 %local.check.extent.1185, %stack.sub.1192
  %descriptor.payload.inside.1194 = icmp ule i32 %local.check.payload.1186, %local.check.extent.1185
  %descriptor.owner.offset.valid.1195 = and i1 %descriptor.owner.inside.1190, %descriptor.offset.inside.1191
  %descriptor.range.inside.1197 = and i1 %descriptor.owner.offset.valid.1195, %descriptor.extent.inside.1193
  %descriptor.range.valid.1196 = and i1 %descriptor.range.inside.1197, %descriptor.payload.inside.1194
  br i1 %descriptor.range.valid.1196, label %descriptor.valid.1198, label %descriptor.invalid.1199
descriptor.invalid.1199:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1198:
  %descriptor.initialized.status.1200 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1184, i32 %local.check.extent.1185)
  %helper.ok.1201 = icmp eq i32 %descriptor.initialized.status.1200, 0
  br i1 %helper.ok.1201, label %helper.continue.1202, label %frame.failure.0
helper.continue.1202:
  br label %local.descriptor.checked.1183
local.descriptor.inactive.1182:
  br label %local.descriptor.checked.1183
local.descriptor.checked.1183:
  %local.is.active.1203 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1203, label %local.descriptor.active.1204, label %local.descriptor.inactive.1205
local.descriptor.active.1204:
  %local.check.offset.1207 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1208 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1209 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1210 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1211 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1212 = load i32, ptr %context.field.1211, align 4
  %stack.sub.1215 = sub i32 %local.check.owner.end.1210, %local.check.offset.1207
  %descriptor.owner.inside.1213 = icmp ule i32 %local.check.owner.end.1210, %context.value.1212
  %descriptor.offset.inside.1214 = icmp ule i32 %local.check.offset.1207, %local.check.owner.end.1210
  %descriptor.extent.inside.1216 = icmp ule i32 %local.check.extent.1208, %stack.sub.1215
  %descriptor.payload.inside.1217 = icmp ule i32 %local.check.payload.1209, %local.check.extent.1208
  %descriptor.owner.offset.valid.1218 = and i1 %descriptor.owner.inside.1213, %descriptor.offset.inside.1214
  %descriptor.range.inside.1220 = and i1 %descriptor.owner.offset.valid.1218, %descriptor.extent.inside.1216
  %descriptor.range.valid.1219 = and i1 %descriptor.range.inside.1220, %descriptor.payload.inside.1217
  br i1 %descriptor.range.valid.1219, label %descriptor.valid.1221, label %descriptor.invalid.1222
descriptor.invalid.1222:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1221:
  %descriptor.initialized.status.1223 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1207, i32 %local.check.extent.1208)
  %helper.ok.1224 = icmp eq i32 %descriptor.initialized.status.1223, 0
  br i1 %helper.ok.1224, label %helper.continue.1225, label %frame.failure.0
helper.continue.1225:
  br label %local.descriptor.checked.1206
local.descriptor.inactive.1205:
  br label %local.descriptor.checked.1206
local.descriptor.checked.1206:
  %local.is.active.1226 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1226, label %local.descriptor.active.1227, label %local.descriptor.inactive.1228
local.descriptor.active.1227:
  %local.check.offset.1230 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1231 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1232 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1233 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1234 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1235 = load i32, ptr %context.field.1234, align 4
  %stack.sub.1238 = sub i32 %local.check.owner.end.1233, %local.check.offset.1230
  %descriptor.owner.inside.1236 = icmp ule i32 %local.check.owner.end.1233, %context.value.1235
  %descriptor.offset.inside.1237 = icmp ule i32 %local.check.offset.1230, %local.check.owner.end.1233
  %descriptor.extent.inside.1239 = icmp ule i32 %local.check.extent.1231, %stack.sub.1238
  %descriptor.payload.inside.1240 = icmp ule i32 %local.check.payload.1232, %local.check.extent.1231
  %descriptor.owner.offset.valid.1241 = and i1 %descriptor.owner.inside.1236, %descriptor.offset.inside.1237
  %descriptor.range.inside.1243 = and i1 %descriptor.owner.offset.valid.1241, %descriptor.extent.inside.1239
  %descriptor.range.valid.1242 = and i1 %descriptor.range.inside.1243, %descriptor.payload.inside.1240
  br i1 %descriptor.range.valid.1242, label %descriptor.valid.1244, label %descriptor.invalid.1245
descriptor.invalid.1245:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1244:
  %descriptor.initialized.status.1246 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1230, i32 %local.check.extent.1231)
  %helper.ok.1247 = icmp eq i32 %descriptor.initialized.status.1246, 0
  br i1 %helper.ok.1247, label %helper.continue.1248, label %frame.failure.0
helper.continue.1248:
  br label %local.descriptor.checked.1229
local.descriptor.inactive.1228:
  br label %local.descriptor.checked.1229
local.descriptor.checked.1229:
  %step.status.1249 = call i32 @al_owning_charge_step(ptr %ctx, i32 12)
  %helper.ok.1250 = icmp eq i32 %step.status.1249, 0
  br i1 %helper.ok.1250, label %helper.continue.1251, label %frame.failure.0
helper.continue.1251:
  store i1 true, ptr %local.active.26, align 1
  store i32 %local.resolved.offset.1069, ptr %local.offset.27, align 4
  store i32 %local.resolved.extent.1070, ptr %local.extent.28, align 4
  store i32 %local.resolved.payload.1071, ptr %local.payload.29, align 4
  store i32 %local.resolved.owner.end.1072, ptr %local.owner.end.30, align 4
  store i32 12, ptr %local.type.31, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %local.resolved.offset.1069, i32 20, i32 %local.resolved.payload.1071, i32 %local.resolved.owner.end.1072, i32 %local.resolved.extent.1070)
  %context.field.1252 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1253 = load i32, ptr %context.field.1252, align 4
  %runtime.ok.1254 = icmp eq i32 %context.value.1253, 0
  br i1 %runtime.ok.1254, label %runtime.continue.1255, label %frame.failure.0
runtime.continue.1255:
  %local.is.active.1256 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1256, label %local.descriptor.active.1257, label %local.descriptor.inactive.1258
local.descriptor.active.1257:
  %local.check.offset.1260 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1261 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1262 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1263 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1264 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1265 = load i32, ptr %context.field.1264, align 4
  %stack.sub.1268 = sub i32 %local.check.owner.end.1263, %local.check.offset.1260
  %descriptor.owner.inside.1266 = icmp ule i32 %local.check.owner.end.1263, %context.value.1265
  %descriptor.offset.inside.1267 = icmp ule i32 %local.check.offset.1260, %local.check.owner.end.1263
  %descriptor.extent.inside.1269 = icmp ule i32 %local.check.extent.1261, %stack.sub.1268
  %descriptor.payload.inside.1270 = icmp ule i32 %local.check.payload.1262, %local.check.extent.1261
  %descriptor.owner.offset.valid.1271 = and i1 %descriptor.owner.inside.1266, %descriptor.offset.inside.1267
  %descriptor.range.inside.1273 = and i1 %descriptor.owner.offset.valid.1271, %descriptor.extent.inside.1269
  %descriptor.range.valid.1272 = and i1 %descriptor.range.inside.1273, %descriptor.payload.inside.1270
  br i1 %descriptor.range.valid.1272, label %descriptor.valid.1274, label %descriptor.invalid.1275
descriptor.invalid.1275:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1274:
  %descriptor.initialized.status.1276 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1260, i32 %local.check.extent.1261)
  %helper.ok.1277 = icmp eq i32 %descriptor.initialized.status.1276, 0
  br i1 %helper.ok.1277, label %helper.continue.1278, label %frame.failure.0
helper.continue.1278:
  br label %local.descriptor.checked.1259
local.descriptor.inactive.1258:
  br label %local.descriptor.checked.1259
local.descriptor.checked.1259:
  %local.is.active.1279 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1279, label %local.descriptor.active.1280, label %local.descriptor.inactive.1281
local.descriptor.active.1280:
  %local.check.offset.1283 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1284 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1285 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1286 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1287 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1288 = load i32, ptr %context.field.1287, align 4
  %stack.sub.1291 = sub i32 %local.check.owner.end.1286, %local.check.offset.1283
  %descriptor.owner.inside.1289 = icmp ule i32 %local.check.owner.end.1286, %context.value.1288
  %descriptor.offset.inside.1290 = icmp ule i32 %local.check.offset.1283, %local.check.owner.end.1286
  %descriptor.extent.inside.1292 = icmp ule i32 %local.check.extent.1284, %stack.sub.1291
  %descriptor.payload.inside.1293 = icmp ule i32 %local.check.payload.1285, %local.check.extent.1284
  %descriptor.owner.offset.valid.1294 = and i1 %descriptor.owner.inside.1289, %descriptor.offset.inside.1290
  %descriptor.range.inside.1296 = and i1 %descriptor.owner.offset.valid.1294, %descriptor.extent.inside.1292
  %descriptor.range.valid.1295 = and i1 %descriptor.range.inside.1296, %descriptor.payload.inside.1293
  br i1 %descriptor.range.valid.1295, label %descriptor.valid.1297, label %descriptor.invalid.1298
descriptor.invalid.1298:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1297:
  %descriptor.initialized.status.1299 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1283, i32 %local.check.extent.1284)
  %helper.ok.1300 = icmp eq i32 %descriptor.initialized.status.1299, 0
  br i1 %helper.ok.1300, label %helper.continue.1301, label %frame.failure.0
helper.continue.1301:
  br label %local.descriptor.checked.1282
local.descriptor.inactive.1281:
  br label %local.descriptor.checked.1282
local.descriptor.checked.1282:
  %local.is.active.1302 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1302, label %local.descriptor.active.1303, label %local.descriptor.inactive.1304
local.descriptor.active.1303:
  %local.check.offset.1306 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1307 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1308 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1309 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1310 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1311 = load i32, ptr %context.field.1310, align 4
  %stack.sub.1314 = sub i32 %local.check.owner.end.1309, %local.check.offset.1306
  %descriptor.owner.inside.1312 = icmp ule i32 %local.check.owner.end.1309, %context.value.1311
  %descriptor.offset.inside.1313 = icmp ule i32 %local.check.offset.1306, %local.check.owner.end.1309
  %descriptor.extent.inside.1315 = icmp ule i32 %local.check.extent.1307, %stack.sub.1314
  %descriptor.payload.inside.1316 = icmp ule i32 %local.check.payload.1308, %local.check.extent.1307
  %descriptor.owner.offset.valid.1317 = and i1 %descriptor.owner.inside.1312, %descriptor.offset.inside.1313
  %descriptor.range.inside.1319 = and i1 %descriptor.owner.offset.valid.1317, %descriptor.extent.inside.1315
  %descriptor.range.valid.1318 = and i1 %descriptor.range.inside.1319, %descriptor.payload.inside.1316
  br i1 %descriptor.range.valid.1318, label %descriptor.valid.1320, label %descriptor.invalid.1321
descriptor.invalid.1321:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1320:
  %descriptor.initialized.status.1322 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1306, i32 %local.check.extent.1307)
  %helper.ok.1323 = icmp eq i32 %descriptor.initialized.status.1322, 0
  br i1 %helper.ok.1323, label %helper.continue.1324, label %frame.failure.0
helper.continue.1324:
  br label %local.descriptor.checked.1305
local.descriptor.inactive.1304:
  br label %local.descriptor.checked.1305
local.descriptor.checked.1305:
  %local.is.active.1325 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1325, label %local.descriptor.active.1326, label %local.descriptor.inactive.1327
local.descriptor.active.1326:
  %local.check.offset.1329 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1330 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1331 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1332 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1333 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1334 = load i32, ptr %context.field.1333, align 4
  %stack.sub.1337 = sub i32 %local.check.owner.end.1332, %local.check.offset.1329
  %descriptor.owner.inside.1335 = icmp ule i32 %local.check.owner.end.1332, %context.value.1334
  %descriptor.offset.inside.1336 = icmp ule i32 %local.check.offset.1329, %local.check.owner.end.1332
  %descriptor.extent.inside.1338 = icmp ule i32 %local.check.extent.1330, %stack.sub.1337
  %descriptor.payload.inside.1339 = icmp ule i32 %local.check.payload.1331, %local.check.extent.1330
  %descriptor.owner.offset.valid.1340 = and i1 %descriptor.owner.inside.1335, %descriptor.offset.inside.1336
  %descriptor.range.inside.1342 = and i1 %descriptor.owner.offset.valid.1340, %descriptor.extent.inside.1338
  %descriptor.range.valid.1341 = and i1 %descriptor.range.inside.1342, %descriptor.payload.inside.1339
  br i1 %descriptor.range.valid.1341, label %descriptor.valid.1343, label %descriptor.invalid.1344
descriptor.invalid.1344:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1343:
  %descriptor.initialized.status.1345 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1329, i32 %local.check.extent.1330)
  %helper.ok.1346 = icmp eq i32 %descriptor.initialized.status.1345, 0
  br i1 %helper.ok.1346, label %helper.continue.1347, label %frame.failure.0
helper.continue.1347:
  br label %local.descriptor.checked.1328
local.descriptor.inactive.1327:
  br label %local.descriptor.checked.1328
local.descriptor.checked.1328:
  %local.is.active.1348 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1348, label %local.descriptor.active.1349, label %local.descriptor.inactive.1350
local.descriptor.active.1349:
  %local.check.offset.1352 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1353 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1354 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1355 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1356 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1357 = load i32, ptr %context.field.1356, align 4
  %stack.sub.1360 = sub i32 %local.check.owner.end.1355, %local.check.offset.1352
  %descriptor.owner.inside.1358 = icmp ule i32 %local.check.owner.end.1355, %context.value.1357
  %descriptor.offset.inside.1359 = icmp ule i32 %local.check.offset.1352, %local.check.owner.end.1355
  %descriptor.extent.inside.1361 = icmp ule i32 %local.check.extent.1353, %stack.sub.1360
  %descriptor.payload.inside.1362 = icmp ule i32 %local.check.payload.1354, %local.check.extent.1353
  %descriptor.owner.offset.valid.1363 = and i1 %descriptor.owner.inside.1358, %descriptor.offset.inside.1359
  %descriptor.range.inside.1365 = and i1 %descriptor.owner.offset.valid.1363, %descriptor.extent.inside.1361
  %descriptor.range.valid.1364 = and i1 %descriptor.range.inside.1365, %descriptor.payload.inside.1362
  br i1 %descriptor.range.valid.1364, label %descriptor.valid.1366, label %descriptor.invalid.1367
descriptor.invalid.1367:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1366:
  %descriptor.initialized.status.1368 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1352, i32 %local.check.extent.1353)
  %helper.ok.1369 = icmp eq i32 %descriptor.initialized.status.1368, 0
  br i1 %helper.ok.1369, label %helper.continue.1370, label %frame.failure.0
helper.continue.1370:
  br label %local.descriptor.checked.1351
local.descriptor.inactive.1350:
  br label %local.descriptor.checked.1351
local.descriptor.checked.1351:
  %local.is.active.1371 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1371, label %local.descriptor.active.1372, label %local.descriptor.inactive.1373
local.descriptor.active.1372:
  %local.check.offset.1375 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1376 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1377 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1378 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1379 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1380 = load i32, ptr %context.field.1379, align 4
  %stack.sub.1383 = sub i32 %local.check.owner.end.1378, %local.check.offset.1375
  %descriptor.owner.inside.1381 = icmp ule i32 %local.check.owner.end.1378, %context.value.1380
  %descriptor.offset.inside.1382 = icmp ule i32 %local.check.offset.1375, %local.check.owner.end.1378
  %descriptor.extent.inside.1384 = icmp ule i32 %local.check.extent.1376, %stack.sub.1383
  %descriptor.payload.inside.1385 = icmp ule i32 %local.check.payload.1377, %local.check.extent.1376
  %descriptor.owner.offset.valid.1386 = and i1 %descriptor.owner.inside.1381, %descriptor.offset.inside.1382
  %descriptor.range.inside.1388 = and i1 %descriptor.owner.offset.valid.1386, %descriptor.extent.inside.1384
  %descriptor.range.valid.1387 = and i1 %descriptor.range.inside.1388, %descriptor.payload.inside.1385
  br i1 %descriptor.range.valid.1387, label %descriptor.valid.1389, label %descriptor.invalid.1390
descriptor.invalid.1390:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1389:
  %descriptor.initialized.status.1391 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1375, i32 %local.check.extent.1376)
  %helper.ok.1392 = icmp eq i32 %descriptor.initialized.status.1391, 0
  br i1 %helper.ok.1392, label %helper.continue.1393, label %frame.failure.0
helper.continue.1393:
  br label %local.descriptor.checked.1374
local.descriptor.inactive.1373:
  br label %local.descriptor.checked.1374
local.descriptor.checked.1374:
  %step.status.1394 = call i32 @al_owning_charge_step(ptr %ctx, i32 13)
  %helper.ok.1395 = icmp eq i32 %step.status.1394, 0
  br i1 %helper.ok.1395, label %helper.continue.1396, label %frame.failure.0
helper.continue.1396:
  %local.resolved.offset.1397 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.1398 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.1399 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.1400 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1401 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1402 = load i32, ptr %context.field.1401, align 4
  %stack.sub.1405 = sub i32 %local.resolved.owner.end.1400, %local.resolved.offset.1397
  %descriptor.owner.inside.1403 = icmp ule i32 %local.resolved.owner.end.1400, %context.value.1402
  %descriptor.offset.inside.1404 = icmp ule i32 %local.resolved.offset.1397, %local.resolved.owner.end.1400
  %descriptor.extent.inside.1406 = icmp ule i32 %local.resolved.extent.1398, %stack.sub.1405
  %descriptor.payload.inside.1407 = icmp ule i32 %local.resolved.payload.1399, %local.resolved.extent.1398
  %descriptor.owner.offset.valid.1408 = and i1 %descriptor.owner.inside.1403, %descriptor.offset.inside.1404
  %descriptor.range.inside.1410 = and i1 %descriptor.owner.offset.valid.1408, %descriptor.extent.inside.1406
  %descriptor.range.valid.1409 = and i1 %descriptor.range.inside.1410, %descriptor.payload.inside.1407
  %descriptor.type.valid.1411 = icmp eq i32 1, 1
  %descriptor.valid.1412 = and i1 %descriptor.range.valid.1409, %descriptor.type.valid.1411
  br i1 %descriptor.valid.1412, label %descriptor.valid.1413, label %descriptor.invalid.1414
descriptor.invalid.1414:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1413:
  %descriptor.initialized.status.1415 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1397, i32 %local.resolved.extent.1398)
  %helper.ok.1416 = icmp eq i32 %descriptor.initialized.status.1415, 0
  br i1 %helper.ok.1416, label %helper.continue.1417, label %frame.failure.0
helper.continue.1417:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %local.resolved.offset.1397, i32 20, i32 %local.resolved.payload.1399, i32 %local.resolved.owner.end.1400, i32 %local.resolved.extent.1398)
  %context.field.1418 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1419 = load i32, ptr %context.field.1418, align 4
  %runtime.ok.1420 = icmp eq i32 %context.value.1419, 0
  br i1 %runtime.ok.1420, label %runtime.continue.1421, label %frame.failure.0
runtime.continue.1421:
  %context.field.1422 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1423 = load i32, ptr %context.field.1422, align 4
  %stack.sub.1426 = sub i32 %local.resolved.owner.end.1400, %local.resolved.offset.1397
  %descriptor.owner.inside.1424 = icmp ule i32 %local.resolved.owner.end.1400, %context.value.1423
  %descriptor.offset.inside.1425 = icmp ule i32 %local.resolved.offset.1397, %local.resolved.owner.end.1400
  %descriptor.extent.inside.1427 = icmp ule i32 %local.resolved.extent.1398, %stack.sub.1426
  %descriptor.payload.inside.1428 = icmp ule i32 %local.resolved.payload.1399, %local.resolved.extent.1398
  %descriptor.owner.offset.valid.1429 = and i1 %descriptor.owner.inside.1424, %descriptor.offset.inside.1425
  %descriptor.range.inside.1431 = and i1 %descriptor.owner.offset.valid.1429, %descriptor.extent.inside.1427
  %descriptor.range.valid.1430 = and i1 %descriptor.range.inside.1431, %descriptor.payload.inside.1428
  %descriptor.type.valid.1432 = icmp eq i32 1, 1
  %descriptor.valid.1433 = and i1 %descriptor.range.valid.1430, %descriptor.type.valid.1432
  br i1 %descriptor.valid.1433, label %descriptor.valid.1434, label %descriptor.invalid.1435
descriptor.invalid.1435:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1434:
  %descriptor.initialized.status.1436 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1397, i32 %local.resolved.extent.1398)
  %helper.ok.1437 = icmp eq i32 %descriptor.initialized.status.1436, 0
  br i1 %helper.ok.1437, label %helper.continue.1438, label %frame.failure.0
helper.continue.1438:
  %local.is.active.1439 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1439, label %local.descriptor.active.1440, label %local.descriptor.inactive.1441
local.descriptor.active.1440:
  %local.check.offset.1443 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1444 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1445 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1446 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1447 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1448 = load i32, ptr %context.field.1447, align 4
  %stack.sub.1451 = sub i32 %local.check.owner.end.1446, %local.check.offset.1443
  %descriptor.owner.inside.1449 = icmp ule i32 %local.check.owner.end.1446, %context.value.1448
  %descriptor.offset.inside.1450 = icmp ule i32 %local.check.offset.1443, %local.check.owner.end.1446
  %descriptor.extent.inside.1452 = icmp ule i32 %local.check.extent.1444, %stack.sub.1451
  %descriptor.payload.inside.1453 = icmp ule i32 %local.check.payload.1445, %local.check.extent.1444
  %descriptor.owner.offset.valid.1454 = and i1 %descriptor.owner.inside.1449, %descriptor.offset.inside.1450
  %descriptor.range.inside.1456 = and i1 %descriptor.owner.offset.valid.1454, %descriptor.extent.inside.1452
  %descriptor.range.valid.1455 = and i1 %descriptor.range.inside.1456, %descriptor.payload.inside.1453
  br i1 %descriptor.range.valid.1455, label %descriptor.valid.1457, label %descriptor.invalid.1458
descriptor.invalid.1458:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1457:
  %descriptor.initialized.status.1459 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1443, i32 %local.check.extent.1444)
  %helper.ok.1460 = icmp eq i32 %descriptor.initialized.status.1459, 0
  br i1 %helper.ok.1460, label %helper.continue.1461, label %frame.failure.0
helper.continue.1461:
  br label %local.descriptor.checked.1442
local.descriptor.inactive.1441:
  br label %local.descriptor.checked.1442
local.descriptor.checked.1442:
  %local.is.active.1462 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1462, label %local.descriptor.active.1463, label %local.descriptor.inactive.1464
local.descriptor.active.1463:
  %local.check.offset.1466 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1467 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1468 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1469 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1470 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1471 = load i32, ptr %context.field.1470, align 4
  %stack.sub.1474 = sub i32 %local.check.owner.end.1469, %local.check.offset.1466
  %descriptor.owner.inside.1472 = icmp ule i32 %local.check.owner.end.1469, %context.value.1471
  %descriptor.offset.inside.1473 = icmp ule i32 %local.check.offset.1466, %local.check.owner.end.1469
  %descriptor.extent.inside.1475 = icmp ule i32 %local.check.extent.1467, %stack.sub.1474
  %descriptor.payload.inside.1476 = icmp ule i32 %local.check.payload.1468, %local.check.extent.1467
  %descriptor.owner.offset.valid.1477 = and i1 %descriptor.owner.inside.1472, %descriptor.offset.inside.1473
  %descriptor.range.inside.1479 = and i1 %descriptor.owner.offset.valid.1477, %descriptor.extent.inside.1475
  %descriptor.range.valid.1478 = and i1 %descriptor.range.inside.1479, %descriptor.payload.inside.1476
  br i1 %descriptor.range.valid.1478, label %descriptor.valid.1480, label %descriptor.invalid.1481
descriptor.invalid.1481:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1480:
  %descriptor.initialized.status.1482 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1466, i32 %local.check.extent.1467)
  %helper.ok.1483 = icmp eq i32 %descriptor.initialized.status.1482, 0
  br i1 %helper.ok.1483, label %helper.continue.1484, label %frame.failure.0
helper.continue.1484:
  br label %local.descriptor.checked.1465
local.descriptor.inactive.1464:
  br label %local.descriptor.checked.1465
local.descriptor.checked.1465:
  %local.is.active.1485 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1485, label %local.descriptor.active.1486, label %local.descriptor.inactive.1487
local.descriptor.active.1486:
  %local.check.offset.1489 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1490 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1491 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1492 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1493 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1494 = load i32, ptr %context.field.1493, align 4
  %stack.sub.1497 = sub i32 %local.check.owner.end.1492, %local.check.offset.1489
  %descriptor.owner.inside.1495 = icmp ule i32 %local.check.owner.end.1492, %context.value.1494
  %descriptor.offset.inside.1496 = icmp ule i32 %local.check.offset.1489, %local.check.owner.end.1492
  %descriptor.extent.inside.1498 = icmp ule i32 %local.check.extent.1490, %stack.sub.1497
  %descriptor.payload.inside.1499 = icmp ule i32 %local.check.payload.1491, %local.check.extent.1490
  %descriptor.owner.offset.valid.1500 = and i1 %descriptor.owner.inside.1495, %descriptor.offset.inside.1496
  %descriptor.range.inside.1502 = and i1 %descriptor.owner.offset.valid.1500, %descriptor.extent.inside.1498
  %descriptor.range.valid.1501 = and i1 %descriptor.range.inside.1502, %descriptor.payload.inside.1499
  br i1 %descriptor.range.valid.1501, label %descriptor.valid.1503, label %descriptor.invalid.1504
descriptor.invalid.1504:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1503:
  %descriptor.initialized.status.1505 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1489, i32 %local.check.extent.1490)
  %helper.ok.1506 = icmp eq i32 %descriptor.initialized.status.1505, 0
  br i1 %helper.ok.1506, label %helper.continue.1507, label %frame.failure.0
helper.continue.1507:
  br label %local.descriptor.checked.1488
local.descriptor.inactive.1487:
  br label %local.descriptor.checked.1488
local.descriptor.checked.1488:
  %local.is.active.1508 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1508, label %local.descriptor.active.1509, label %local.descriptor.inactive.1510
local.descriptor.active.1509:
  %local.check.offset.1512 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1513 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1514 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1515 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1516 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1517 = load i32, ptr %context.field.1516, align 4
  %stack.sub.1520 = sub i32 %local.check.owner.end.1515, %local.check.offset.1512
  %descriptor.owner.inside.1518 = icmp ule i32 %local.check.owner.end.1515, %context.value.1517
  %descriptor.offset.inside.1519 = icmp ule i32 %local.check.offset.1512, %local.check.owner.end.1515
  %descriptor.extent.inside.1521 = icmp ule i32 %local.check.extent.1513, %stack.sub.1520
  %descriptor.payload.inside.1522 = icmp ule i32 %local.check.payload.1514, %local.check.extent.1513
  %descriptor.owner.offset.valid.1523 = and i1 %descriptor.owner.inside.1518, %descriptor.offset.inside.1519
  %descriptor.range.inside.1525 = and i1 %descriptor.owner.offset.valid.1523, %descriptor.extent.inside.1521
  %descriptor.range.valid.1524 = and i1 %descriptor.range.inside.1525, %descriptor.payload.inside.1522
  br i1 %descriptor.range.valid.1524, label %descriptor.valid.1526, label %descriptor.invalid.1527
descriptor.invalid.1527:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1526:
  %descriptor.initialized.status.1528 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1512, i32 %local.check.extent.1513)
  %helper.ok.1529 = icmp eq i32 %descriptor.initialized.status.1528, 0
  br i1 %helper.ok.1529, label %helper.continue.1530, label %frame.failure.0
helper.continue.1530:
  br label %local.descriptor.checked.1511
local.descriptor.inactive.1510:
  br label %local.descriptor.checked.1511
local.descriptor.checked.1511:
  %local.is.active.1531 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1531, label %local.descriptor.active.1532, label %local.descriptor.inactive.1533
local.descriptor.active.1532:
  %local.check.offset.1535 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1536 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1537 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1538 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1539 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1540 = load i32, ptr %context.field.1539, align 4
  %stack.sub.1543 = sub i32 %local.check.owner.end.1538, %local.check.offset.1535
  %descriptor.owner.inside.1541 = icmp ule i32 %local.check.owner.end.1538, %context.value.1540
  %descriptor.offset.inside.1542 = icmp ule i32 %local.check.offset.1535, %local.check.owner.end.1538
  %descriptor.extent.inside.1544 = icmp ule i32 %local.check.extent.1536, %stack.sub.1543
  %descriptor.payload.inside.1545 = icmp ule i32 %local.check.payload.1537, %local.check.extent.1536
  %descriptor.owner.offset.valid.1546 = and i1 %descriptor.owner.inside.1541, %descriptor.offset.inside.1542
  %descriptor.range.inside.1548 = and i1 %descriptor.owner.offset.valid.1546, %descriptor.extent.inside.1544
  %descriptor.range.valid.1547 = and i1 %descriptor.range.inside.1548, %descriptor.payload.inside.1545
  br i1 %descriptor.range.valid.1547, label %descriptor.valid.1549, label %descriptor.invalid.1550
descriptor.invalid.1550:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1549:
  %descriptor.initialized.status.1551 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1535, i32 %local.check.extent.1536)
  %helper.ok.1552 = icmp eq i32 %descriptor.initialized.status.1551, 0
  br i1 %helper.ok.1552, label %helper.continue.1553, label %frame.failure.0
helper.continue.1553:
  br label %local.descriptor.checked.1534
local.descriptor.inactive.1533:
  br label %local.descriptor.checked.1534
local.descriptor.checked.1534:
  %local.is.active.1554 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1554, label %local.descriptor.active.1555, label %local.descriptor.inactive.1556
local.descriptor.active.1555:
  %local.check.offset.1558 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1559 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1560 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1561 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1562 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1563 = load i32, ptr %context.field.1562, align 4
  %stack.sub.1566 = sub i32 %local.check.owner.end.1561, %local.check.offset.1558
  %descriptor.owner.inside.1564 = icmp ule i32 %local.check.owner.end.1561, %context.value.1563
  %descriptor.offset.inside.1565 = icmp ule i32 %local.check.offset.1558, %local.check.owner.end.1561
  %descriptor.extent.inside.1567 = icmp ule i32 %local.check.extent.1559, %stack.sub.1566
  %descriptor.payload.inside.1568 = icmp ule i32 %local.check.payload.1560, %local.check.extent.1559
  %descriptor.owner.offset.valid.1569 = and i1 %descriptor.owner.inside.1564, %descriptor.offset.inside.1565
  %descriptor.range.inside.1571 = and i1 %descriptor.owner.offset.valid.1569, %descriptor.extent.inside.1567
  %descriptor.range.valid.1570 = and i1 %descriptor.range.inside.1571, %descriptor.payload.inside.1568
  br i1 %descriptor.range.valid.1570, label %descriptor.valid.1572, label %descriptor.invalid.1573
descriptor.invalid.1573:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1572:
  %descriptor.initialized.status.1574 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1558, i32 %local.check.extent.1559)
  %helper.ok.1575 = icmp eq i32 %descriptor.initialized.status.1574, 0
  br i1 %helper.ok.1575, label %helper.continue.1576, label %frame.failure.0
helper.continue.1576:
  br label %local.descriptor.checked.1557
local.descriptor.inactive.1556:
  br label %local.descriptor.checked.1557
local.descriptor.checked.1557:
  %step.status.1577 = call i32 @al_owning_charge_step(ptr %ctx, i32 14)
  %helper.ok.1578 = icmp eq i32 %step.status.1577, 0
  br i1 %helper.ok.1578, label %helper.continue.1579, label %frame.failure.0
helper.continue.1579:
  store i1 true, ptr %local.active.32, align 1
  store i32 %local.resolved.offset.1397, ptr %local.offset.33, align 4
  store i32 %local.resolved.extent.1398, ptr %local.extent.34, align 4
  store i32 %local.resolved.payload.1399, ptr %local.payload.35, align 4
  store i32 %local.resolved.owner.end.1400, ptr %local.owner.end.36, align 4
  store i32 1, ptr %local.type.37, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %local.resolved.offset.1397, i32 20, i32 %local.resolved.payload.1399, i32 %local.resolved.owner.end.1400, i32 %local.resolved.extent.1398)
  %context.field.1580 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1581 = load i32, ptr %context.field.1580, align 4
  %runtime.ok.1582 = icmp eq i32 %context.value.1581, 0
  br i1 %runtime.ok.1582, label %runtime.continue.1583, label %frame.failure.0
runtime.continue.1583:
  %local.is.active.1584 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1584, label %local.descriptor.active.1585, label %local.descriptor.inactive.1586
local.descriptor.active.1585:
  %local.check.offset.1588 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1589 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1590 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1591 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1592 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1593 = load i32, ptr %context.field.1592, align 4
  %stack.sub.1596 = sub i32 %local.check.owner.end.1591, %local.check.offset.1588
  %descriptor.owner.inside.1594 = icmp ule i32 %local.check.owner.end.1591, %context.value.1593
  %descriptor.offset.inside.1595 = icmp ule i32 %local.check.offset.1588, %local.check.owner.end.1591
  %descriptor.extent.inside.1597 = icmp ule i32 %local.check.extent.1589, %stack.sub.1596
  %descriptor.payload.inside.1598 = icmp ule i32 %local.check.payload.1590, %local.check.extent.1589
  %descriptor.owner.offset.valid.1599 = and i1 %descriptor.owner.inside.1594, %descriptor.offset.inside.1595
  %descriptor.range.inside.1601 = and i1 %descriptor.owner.offset.valid.1599, %descriptor.extent.inside.1597
  %descriptor.range.valid.1600 = and i1 %descriptor.range.inside.1601, %descriptor.payload.inside.1598
  br i1 %descriptor.range.valid.1600, label %descriptor.valid.1602, label %descriptor.invalid.1603
descriptor.invalid.1603:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1602:
  %descriptor.initialized.status.1604 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1588, i32 %local.check.extent.1589)
  %helper.ok.1605 = icmp eq i32 %descriptor.initialized.status.1604, 0
  br i1 %helper.ok.1605, label %helper.continue.1606, label %frame.failure.0
helper.continue.1606:
  br label %local.descriptor.checked.1587
local.descriptor.inactive.1586:
  br label %local.descriptor.checked.1587
local.descriptor.checked.1587:
  %local.is.active.1607 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1607, label %local.descriptor.active.1608, label %local.descriptor.inactive.1609
local.descriptor.active.1608:
  %local.check.offset.1611 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1612 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1613 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1614 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1615 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1616 = load i32, ptr %context.field.1615, align 4
  %stack.sub.1619 = sub i32 %local.check.owner.end.1614, %local.check.offset.1611
  %descriptor.owner.inside.1617 = icmp ule i32 %local.check.owner.end.1614, %context.value.1616
  %descriptor.offset.inside.1618 = icmp ule i32 %local.check.offset.1611, %local.check.owner.end.1614
  %descriptor.extent.inside.1620 = icmp ule i32 %local.check.extent.1612, %stack.sub.1619
  %descriptor.payload.inside.1621 = icmp ule i32 %local.check.payload.1613, %local.check.extent.1612
  %descriptor.owner.offset.valid.1622 = and i1 %descriptor.owner.inside.1617, %descriptor.offset.inside.1618
  %descriptor.range.inside.1624 = and i1 %descriptor.owner.offset.valid.1622, %descriptor.extent.inside.1620
  %descriptor.range.valid.1623 = and i1 %descriptor.range.inside.1624, %descriptor.payload.inside.1621
  br i1 %descriptor.range.valid.1623, label %descriptor.valid.1625, label %descriptor.invalid.1626
descriptor.invalid.1626:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1625:
  %descriptor.initialized.status.1627 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1611, i32 %local.check.extent.1612)
  %helper.ok.1628 = icmp eq i32 %descriptor.initialized.status.1627, 0
  br i1 %helper.ok.1628, label %helper.continue.1629, label %frame.failure.0
helper.continue.1629:
  br label %local.descriptor.checked.1610
local.descriptor.inactive.1609:
  br label %local.descriptor.checked.1610
local.descriptor.checked.1610:
  %local.is.active.1630 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1630, label %local.descriptor.active.1631, label %local.descriptor.inactive.1632
local.descriptor.active.1631:
  %local.check.offset.1634 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1635 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1636 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1637 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1638 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1639 = load i32, ptr %context.field.1638, align 4
  %stack.sub.1642 = sub i32 %local.check.owner.end.1637, %local.check.offset.1634
  %descriptor.owner.inside.1640 = icmp ule i32 %local.check.owner.end.1637, %context.value.1639
  %descriptor.offset.inside.1641 = icmp ule i32 %local.check.offset.1634, %local.check.owner.end.1637
  %descriptor.extent.inside.1643 = icmp ule i32 %local.check.extent.1635, %stack.sub.1642
  %descriptor.payload.inside.1644 = icmp ule i32 %local.check.payload.1636, %local.check.extent.1635
  %descriptor.owner.offset.valid.1645 = and i1 %descriptor.owner.inside.1640, %descriptor.offset.inside.1641
  %descriptor.range.inside.1647 = and i1 %descriptor.owner.offset.valid.1645, %descriptor.extent.inside.1643
  %descriptor.range.valid.1646 = and i1 %descriptor.range.inside.1647, %descriptor.payload.inside.1644
  br i1 %descriptor.range.valid.1646, label %descriptor.valid.1648, label %descriptor.invalid.1649
descriptor.invalid.1649:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1648:
  %descriptor.initialized.status.1650 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1634, i32 %local.check.extent.1635)
  %helper.ok.1651 = icmp eq i32 %descriptor.initialized.status.1650, 0
  br i1 %helper.ok.1651, label %helper.continue.1652, label %frame.failure.0
helper.continue.1652:
  br label %local.descriptor.checked.1633
local.descriptor.inactive.1632:
  br label %local.descriptor.checked.1633
local.descriptor.checked.1633:
  %local.is.active.1653 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1653, label %local.descriptor.active.1654, label %local.descriptor.inactive.1655
local.descriptor.active.1654:
  %local.check.offset.1657 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1658 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1659 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1660 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1661 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1662 = load i32, ptr %context.field.1661, align 4
  %stack.sub.1665 = sub i32 %local.check.owner.end.1660, %local.check.offset.1657
  %descriptor.owner.inside.1663 = icmp ule i32 %local.check.owner.end.1660, %context.value.1662
  %descriptor.offset.inside.1664 = icmp ule i32 %local.check.offset.1657, %local.check.owner.end.1660
  %descriptor.extent.inside.1666 = icmp ule i32 %local.check.extent.1658, %stack.sub.1665
  %descriptor.payload.inside.1667 = icmp ule i32 %local.check.payload.1659, %local.check.extent.1658
  %descriptor.owner.offset.valid.1668 = and i1 %descriptor.owner.inside.1663, %descriptor.offset.inside.1664
  %descriptor.range.inside.1670 = and i1 %descriptor.owner.offset.valid.1668, %descriptor.extent.inside.1666
  %descriptor.range.valid.1669 = and i1 %descriptor.range.inside.1670, %descriptor.payload.inside.1667
  br i1 %descriptor.range.valid.1669, label %descriptor.valid.1671, label %descriptor.invalid.1672
descriptor.invalid.1672:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1671:
  %descriptor.initialized.status.1673 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1657, i32 %local.check.extent.1658)
  %helper.ok.1674 = icmp eq i32 %descriptor.initialized.status.1673, 0
  br i1 %helper.ok.1674, label %helper.continue.1675, label %frame.failure.0
helper.continue.1675:
  br label %local.descriptor.checked.1656
local.descriptor.inactive.1655:
  br label %local.descriptor.checked.1656
local.descriptor.checked.1656:
  %local.is.active.1676 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1676, label %local.descriptor.active.1677, label %local.descriptor.inactive.1678
local.descriptor.active.1677:
  %local.check.offset.1680 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1681 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1682 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1683 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1684 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1685 = load i32, ptr %context.field.1684, align 4
  %stack.sub.1688 = sub i32 %local.check.owner.end.1683, %local.check.offset.1680
  %descriptor.owner.inside.1686 = icmp ule i32 %local.check.owner.end.1683, %context.value.1685
  %descriptor.offset.inside.1687 = icmp ule i32 %local.check.offset.1680, %local.check.owner.end.1683
  %descriptor.extent.inside.1689 = icmp ule i32 %local.check.extent.1681, %stack.sub.1688
  %descriptor.payload.inside.1690 = icmp ule i32 %local.check.payload.1682, %local.check.extent.1681
  %descriptor.owner.offset.valid.1691 = and i1 %descriptor.owner.inside.1686, %descriptor.offset.inside.1687
  %descriptor.range.inside.1693 = and i1 %descriptor.owner.offset.valid.1691, %descriptor.extent.inside.1689
  %descriptor.range.valid.1692 = and i1 %descriptor.range.inside.1693, %descriptor.payload.inside.1690
  br i1 %descriptor.range.valid.1692, label %descriptor.valid.1694, label %descriptor.invalid.1695
descriptor.invalid.1695:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1694:
  %descriptor.initialized.status.1696 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1680, i32 %local.check.extent.1681)
  %helper.ok.1697 = icmp eq i32 %descriptor.initialized.status.1696, 0
  br i1 %helper.ok.1697, label %helper.continue.1698, label %frame.failure.0
helper.continue.1698:
  br label %local.descriptor.checked.1679
local.descriptor.inactive.1678:
  br label %local.descriptor.checked.1679
local.descriptor.checked.1679:
  %local.is.active.1699 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1699, label %local.descriptor.active.1700, label %local.descriptor.inactive.1701
local.descriptor.active.1700:
  %local.check.offset.1703 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1704 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1705 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1706 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1707 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1708 = load i32, ptr %context.field.1707, align 4
  %stack.sub.1711 = sub i32 %local.check.owner.end.1706, %local.check.offset.1703
  %descriptor.owner.inside.1709 = icmp ule i32 %local.check.owner.end.1706, %context.value.1708
  %descriptor.offset.inside.1710 = icmp ule i32 %local.check.offset.1703, %local.check.owner.end.1706
  %descriptor.extent.inside.1712 = icmp ule i32 %local.check.extent.1704, %stack.sub.1711
  %descriptor.payload.inside.1713 = icmp ule i32 %local.check.payload.1705, %local.check.extent.1704
  %descriptor.owner.offset.valid.1714 = and i1 %descriptor.owner.inside.1709, %descriptor.offset.inside.1710
  %descriptor.range.inside.1716 = and i1 %descriptor.owner.offset.valid.1714, %descriptor.extent.inside.1712
  %descriptor.range.valid.1715 = and i1 %descriptor.range.inside.1716, %descriptor.payload.inside.1713
  br i1 %descriptor.range.valid.1715, label %descriptor.valid.1717, label %descriptor.invalid.1718
descriptor.invalid.1718:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1717:
  %descriptor.initialized.status.1719 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1703, i32 %local.check.extent.1704)
  %helper.ok.1720 = icmp eq i32 %descriptor.initialized.status.1719, 0
  br i1 %helper.ok.1720, label %helper.continue.1721, label %frame.failure.0
helper.continue.1721:
  br label %local.descriptor.checked.1702
local.descriptor.inactive.1701:
  br label %local.descriptor.checked.1702
local.descriptor.checked.1702:
  %step.status.1722 = call i32 @al_owning_charge_step(ptr %ctx, i32 15)
  %helper.ok.1723 = icmp eq i32 %step.status.1722, 0
  br i1 %helper.ok.1723, label %helper.continue.1724, label %frame.failure.0
helper.continue.1724:
  %local.resolved.offset.1725 = load i32, ptr %local.offset.21, align 4
  %local.resolved.extent.1726 = load i32, ptr %local.extent.22, align 4
  %local.resolved.payload.1727 = load i32, ptr %local.payload.23, align 4
  %local.resolved.owner.end.1728 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1729 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1730 = load i32, ptr %context.field.1729, align 4
  %stack.sub.1733 = sub i32 %local.resolved.owner.end.1728, %local.resolved.offset.1725
  %descriptor.owner.inside.1731 = icmp ule i32 %local.resolved.owner.end.1728, %context.value.1730
  %descriptor.offset.inside.1732 = icmp ule i32 %local.resolved.offset.1725, %local.resolved.owner.end.1728
  %descriptor.extent.inside.1734 = icmp ule i32 %local.resolved.extent.1726, %stack.sub.1733
  %descriptor.payload.inside.1735 = icmp ule i32 %local.resolved.payload.1727, %local.resolved.extent.1726
  %descriptor.owner.offset.valid.1736 = and i1 %descriptor.owner.inside.1731, %descriptor.offset.inside.1732
  %descriptor.range.inside.1738 = and i1 %descriptor.owner.offset.valid.1736, %descriptor.extent.inside.1734
  %descriptor.range.valid.1737 = and i1 %descriptor.range.inside.1738, %descriptor.payload.inside.1735
  %descriptor.type.valid.1739 = icmp eq i32 4, 4
  %descriptor.valid.1740 = and i1 %descriptor.range.valid.1737, %descriptor.type.valid.1739
  br i1 %descriptor.valid.1740, label %descriptor.valid.1741, label %descriptor.invalid.1742
descriptor.invalid.1742:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1741:
  %descriptor.initialized.status.1743 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1725, i32 %local.resolved.extent.1726)
  %helper.ok.1744 = icmp eq i32 %descriptor.initialized.status.1743, 0
  br i1 %helper.ok.1744, label %helper.continue.1745, label %frame.failure.0
helper.continue.1745:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %local.resolved.offset.1725, i32 20, i32 %local.resolved.payload.1727, i32 %local.resolved.owner.end.1728, i32 %local.resolved.extent.1726)
  %context.field.1746 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1747 = load i32, ptr %context.field.1746, align 4
  %runtime.ok.1748 = icmp eq i32 %context.value.1747, 0
  br i1 %runtime.ok.1748, label %runtime.continue.1749, label %frame.failure.0
runtime.continue.1749:
  %context.field.1750 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1751 = load i32, ptr %context.field.1750, align 4
  %stack.sub.1754 = sub i32 %local.resolved.owner.end.1728, %local.resolved.offset.1725
  %descriptor.owner.inside.1752 = icmp ule i32 %local.resolved.owner.end.1728, %context.value.1751
  %descriptor.offset.inside.1753 = icmp ule i32 %local.resolved.offset.1725, %local.resolved.owner.end.1728
  %descriptor.extent.inside.1755 = icmp ule i32 %local.resolved.extent.1726, %stack.sub.1754
  %descriptor.payload.inside.1756 = icmp ule i32 %local.resolved.payload.1727, %local.resolved.extent.1726
  %descriptor.owner.offset.valid.1757 = and i1 %descriptor.owner.inside.1752, %descriptor.offset.inside.1753
  %descriptor.range.inside.1759 = and i1 %descriptor.owner.offset.valid.1757, %descriptor.extent.inside.1755
  %descriptor.range.valid.1758 = and i1 %descriptor.range.inside.1759, %descriptor.payload.inside.1756
  %descriptor.type.valid.1760 = icmp eq i32 4, 4
  %descriptor.valid.1761 = and i1 %descriptor.range.valid.1758, %descriptor.type.valid.1760
  br i1 %descriptor.valid.1761, label %descriptor.valid.1762, label %descriptor.invalid.1763
descriptor.invalid.1763:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1762:
  %descriptor.initialized.status.1764 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1725, i32 %local.resolved.extent.1726)
  %helper.ok.1765 = icmp eq i32 %descriptor.initialized.status.1764, 0
  br i1 %helper.ok.1765, label %helper.continue.1766, label %frame.failure.0
helper.continue.1766:
  %local.is.active.1767 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1767, label %local.descriptor.active.1768, label %local.descriptor.inactive.1769
local.descriptor.active.1768:
  %local.check.offset.1771 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1772 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1773 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1774 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1775 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1776 = load i32, ptr %context.field.1775, align 4
  %stack.sub.1779 = sub i32 %local.check.owner.end.1774, %local.check.offset.1771
  %descriptor.owner.inside.1777 = icmp ule i32 %local.check.owner.end.1774, %context.value.1776
  %descriptor.offset.inside.1778 = icmp ule i32 %local.check.offset.1771, %local.check.owner.end.1774
  %descriptor.extent.inside.1780 = icmp ule i32 %local.check.extent.1772, %stack.sub.1779
  %descriptor.payload.inside.1781 = icmp ule i32 %local.check.payload.1773, %local.check.extent.1772
  %descriptor.owner.offset.valid.1782 = and i1 %descriptor.owner.inside.1777, %descriptor.offset.inside.1778
  %descriptor.range.inside.1784 = and i1 %descriptor.owner.offset.valid.1782, %descriptor.extent.inside.1780
  %descriptor.range.valid.1783 = and i1 %descriptor.range.inside.1784, %descriptor.payload.inside.1781
  br i1 %descriptor.range.valid.1783, label %descriptor.valid.1785, label %descriptor.invalid.1786
descriptor.invalid.1786:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1785:
  %descriptor.initialized.status.1787 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1771, i32 %local.check.extent.1772)
  %helper.ok.1788 = icmp eq i32 %descriptor.initialized.status.1787, 0
  br i1 %helper.ok.1788, label %helper.continue.1789, label %frame.failure.0
helper.continue.1789:
  br label %local.descriptor.checked.1770
local.descriptor.inactive.1769:
  br label %local.descriptor.checked.1770
local.descriptor.checked.1770:
  %local.is.active.1790 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1790, label %local.descriptor.active.1791, label %local.descriptor.inactive.1792
local.descriptor.active.1791:
  %local.check.offset.1794 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1795 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1796 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1797 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1798 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1799 = load i32, ptr %context.field.1798, align 4
  %stack.sub.1802 = sub i32 %local.check.owner.end.1797, %local.check.offset.1794
  %descriptor.owner.inside.1800 = icmp ule i32 %local.check.owner.end.1797, %context.value.1799
  %descriptor.offset.inside.1801 = icmp ule i32 %local.check.offset.1794, %local.check.owner.end.1797
  %descriptor.extent.inside.1803 = icmp ule i32 %local.check.extent.1795, %stack.sub.1802
  %descriptor.payload.inside.1804 = icmp ule i32 %local.check.payload.1796, %local.check.extent.1795
  %descriptor.owner.offset.valid.1805 = and i1 %descriptor.owner.inside.1800, %descriptor.offset.inside.1801
  %descriptor.range.inside.1807 = and i1 %descriptor.owner.offset.valid.1805, %descriptor.extent.inside.1803
  %descriptor.range.valid.1806 = and i1 %descriptor.range.inside.1807, %descriptor.payload.inside.1804
  br i1 %descriptor.range.valid.1806, label %descriptor.valid.1808, label %descriptor.invalid.1809
descriptor.invalid.1809:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1808:
  %descriptor.initialized.status.1810 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1794, i32 %local.check.extent.1795)
  %helper.ok.1811 = icmp eq i32 %descriptor.initialized.status.1810, 0
  br i1 %helper.ok.1811, label %helper.continue.1812, label %frame.failure.0
helper.continue.1812:
  br label %local.descriptor.checked.1793
local.descriptor.inactive.1792:
  br label %local.descriptor.checked.1793
local.descriptor.checked.1793:
  %local.is.active.1813 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1813, label %local.descriptor.active.1814, label %local.descriptor.inactive.1815
local.descriptor.active.1814:
  %local.check.offset.1817 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1818 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1819 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1820 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1821 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1822 = load i32, ptr %context.field.1821, align 4
  %stack.sub.1825 = sub i32 %local.check.owner.end.1820, %local.check.offset.1817
  %descriptor.owner.inside.1823 = icmp ule i32 %local.check.owner.end.1820, %context.value.1822
  %descriptor.offset.inside.1824 = icmp ule i32 %local.check.offset.1817, %local.check.owner.end.1820
  %descriptor.extent.inside.1826 = icmp ule i32 %local.check.extent.1818, %stack.sub.1825
  %descriptor.payload.inside.1827 = icmp ule i32 %local.check.payload.1819, %local.check.extent.1818
  %descriptor.owner.offset.valid.1828 = and i1 %descriptor.owner.inside.1823, %descriptor.offset.inside.1824
  %descriptor.range.inside.1830 = and i1 %descriptor.owner.offset.valid.1828, %descriptor.extent.inside.1826
  %descriptor.range.valid.1829 = and i1 %descriptor.range.inside.1830, %descriptor.payload.inside.1827
  br i1 %descriptor.range.valid.1829, label %descriptor.valid.1831, label %descriptor.invalid.1832
descriptor.invalid.1832:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1831:
  %descriptor.initialized.status.1833 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1817, i32 %local.check.extent.1818)
  %helper.ok.1834 = icmp eq i32 %descriptor.initialized.status.1833, 0
  br i1 %helper.ok.1834, label %helper.continue.1835, label %frame.failure.0
helper.continue.1835:
  br label %local.descriptor.checked.1816
local.descriptor.inactive.1815:
  br label %local.descriptor.checked.1816
local.descriptor.checked.1816:
  %local.is.active.1836 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1836, label %local.descriptor.active.1837, label %local.descriptor.inactive.1838
local.descriptor.active.1837:
  %local.check.offset.1840 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1841 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1842 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1843 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1844 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1845 = load i32, ptr %context.field.1844, align 4
  %stack.sub.1848 = sub i32 %local.check.owner.end.1843, %local.check.offset.1840
  %descriptor.owner.inside.1846 = icmp ule i32 %local.check.owner.end.1843, %context.value.1845
  %descriptor.offset.inside.1847 = icmp ule i32 %local.check.offset.1840, %local.check.owner.end.1843
  %descriptor.extent.inside.1849 = icmp ule i32 %local.check.extent.1841, %stack.sub.1848
  %descriptor.payload.inside.1850 = icmp ule i32 %local.check.payload.1842, %local.check.extent.1841
  %descriptor.owner.offset.valid.1851 = and i1 %descriptor.owner.inside.1846, %descriptor.offset.inside.1847
  %descriptor.range.inside.1853 = and i1 %descriptor.owner.offset.valid.1851, %descriptor.extent.inside.1849
  %descriptor.range.valid.1852 = and i1 %descriptor.range.inside.1853, %descriptor.payload.inside.1850
  br i1 %descriptor.range.valid.1852, label %descriptor.valid.1854, label %descriptor.invalid.1855
descriptor.invalid.1855:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1854:
  %descriptor.initialized.status.1856 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1840, i32 %local.check.extent.1841)
  %helper.ok.1857 = icmp eq i32 %descriptor.initialized.status.1856, 0
  br i1 %helper.ok.1857, label %helper.continue.1858, label %frame.failure.0
helper.continue.1858:
  br label %local.descriptor.checked.1839
local.descriptor.inactive.1838:
  br label %local.descriptor.checked.1839
local.descriptor.checked.1839:
  %local.is.active.1859 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1859, label %local.descriptor.active.1860, label %local.descriptor.inactive.1861
local.descriptor.active.1860:
  %local.check.offset.1863 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1864 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1865 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1866 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1867 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1868 = load i32, ptr %context.field.1867, align 4
  %stack.sub.1871 = sub i32 %local.check.owner.end.1866, %local.check.offset.1863
  %descriptor.owner.inside.1869 = icmp ule i32 %local.check.owner.end.1866, %context.value.1868
  %descriptor.offset.inside.1870 = icmp ule i32 %local.check.offset.1863, %local.check.owner.end.1866
  %descriptor.extent.inside.1872 = icmp ule i32 %local.check.extent.1864, %stack.sub.1871
  %descriptor.payload.inside.1873 = icmp ule i32 %local.check.payload.1865, %local.check.extent.1864
  %descriptor.owner.offset.valid.1874 = and i1 %descriptor.owner.inside.1869, %descriptor.offset.inside.1870
  %descriptor.range.inside.1876 = and i1 %descriptor.owner.offset.valid.1874, %descriptor.extent.inside.1872
  %descriptor.range.valid.1875 = and i1 %descriptor.range.inside.1876, %descriptor.payload.inside.1873
  br i1 %descriptor.range.valid.1875, label %descriptor.valid.1877, label %descriptor.invalid.1878
descriptor.invalid.1878:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1877:
  %descriptor.initialized.status.1879 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1863, i32 %local.check.extent.1864)
  %helper.ok.1880 = icmp eq i32 %descriptor.initialized.status.1879, 0
  br i1 %helper.ok.1880, label %helper.continue.1881, label %frame.failure.0
helper.continue.1881:
  br label %local.descriptor.checked.1862
local.descriptor.inactive.1861:
  br label %local.descriptor.checked.1862
local.descriptor.checked.1862:
  %local.is.active.1882 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1882, label %local.descriptor.active.1883, label %local.descriptor.inactive.1884
local.descriptor.active.1883:
  %local.check.offset.1886 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1887 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1888 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1889 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1890 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1891 = load i32, ptr %context.field.1890, align 4
  %stack.sub.1894 = sub i32 %local.check.owner.end.1889, %local.check.offset.1886
  %descriptor.owner.inside.1892 = icmp ule i32 %local.check.owner.end.1889, %context.value.1891
  %descriptor.offset.inside.1893 = icmp ule i32 %local.check.offset.1886, %local.check.owner.end.1889
  %descriptor.extent.inside.1895 = icmp ule i32 %local.check.extent.1887, %stack.sub.1894
  %descriptor.payload.inside.1896 = icmp ule i32 %local.check.payload.1888, %local.check.extent.1887
  %descriptor.owner.offset.valid.1897 = and i1 %descriptor.owner.inside.1892, %descriptor.offset.inside.1893
  %descriptor.range.inside.1899 = and i1 %descriptor.owner.offset.valid.1897, %descriptor.extent.inside.1895
  %descriptor.range.valid.1898 = and i1 %descriptor.range.inside.1899, %descriptor.payload.inside.1896
  br i1 %descriptor.range.valid.1898, label %descriptor.valid.1900, label %descriptor.invalid.1901
descriptor.invalid.1901:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1900:
  %descriptor.initialized.status.1902 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1886, i32 %local.check.extent.1887)
  %helper.ok.1903 = icmp eq i32 %descriptor.initialized.status.1902, 0
  br i1 %helper.ok.1903, label %helper.continue.1904, label %frame.failure.0
helper.continue.1904:
  br label %local.descriptor.checked.1885
local.descriptor.inactive.1884:
  br label %local.descriptor.checked.1885
local.descriptor.checked.1885:
  %step.status.1905 = call i32 @al_owning_charge_step(ptr %ctx, i32 16)
  %helper.ok.1906 = icmp eq i32 %step.status.1905, 0
  br i1 %helper.ok.1906, label %helper.continue.1907, label %frame.failure.0
helper.continue.1907:
  %local.resolved.offset.1908 = load i32, ptr %local.offset.27, align 4
  %local.resolved.extent.1909 = load i32, ptr %local.extent.28, align 4
  %local.resolved.payload.1910 = load i32, ptr %local.payload.29, align 4
  %local.resolved.owner.end.1911 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1912 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1913 = load i32, ptr %context.field.1912, align 4
  %stack.sub.1916 = sub i32 %local.resolved.owner.end.1911, %local.resolved.offset.1908
  %descriptor.owner.inside.1914 = icmp ule i32 %local.resolved.owner.end.1911, %context.value.1913
  %descriptor.offset.inside.1915 = icmp ule i32 %local.resolved.offset.1908, %local.resolved.owner.end.1911
  %descriptor.extent.inside.1917 = icmp ule i32 %local.resolved.extent.1909, %stack.sub.1916
  %descriptor.payload.inside.1918 = icmp ule i32 %local.resolved.payload.1910, %local.resolved.extent.1909
  %descriptor.owner.offset.valid.1919 = and i1 %descriptor.owner.inside.1914, %descriptor.offset.inside.1915
  %descriptor.range.inside.1921 = and i1 %descriptor.owner.offset.valid.1919, %descriptor.extent.inside.1917
  %descriptor.range.valid.1920 = and i1 %descriptor.range.inside.1921, %descriptor.payload.inside.1918
  %descriptor.type.valid.1922 = icmp eq i32 12, 12
  %descriptor.valid.1923 = and i1 %descriptor.range.valid.1920, %descriptor.type.valid.1922
  br i1 %descriptor.valid.1923, label %descriptor.valid.1924, label %descriptor.invalid.1925
descriptor.invalid.1925:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1924:
  %descriptor.initialized.status.1926 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1908, i32 %local.resolved.extent.1909)
  %helper.ok.1927 = icmp eq i32 %descriptor.initialized.status.1926, 0
  br i1 %helper.ok.1927, label %helper.continue.1928, label %frame.failure.0
helper.continue.1928:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %local.resolved.offset.1908, i32 20, i32 %local.resolved.payload.1910, i32 %local.resolved.owner.end.1911, i32 %local.resolved.extent.1909)
  %context.field.1929 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1930 = load i32, ptr %context.field.1929, align 4
  %runtime.ok.1931 = icmp eq i32 %context.value.1930, 0
  br i1 %runtime.ok.1931, label %runtime.continue.1932, label %frame.failure.0
runtime.continue.1932:
  %context.field.1933 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1934 = load i32, ptr %context.field.1933, align 4
  %stack.sub.1937 = sub i32 %local.resolved.owner.end.1728, %local.resolved.offset.1725
  %descriptor.owner.inside.1935 = icmp ule i32 %local.resolved.owner.end.1728, %context.value.1934
  %descriptor.offset.inside.1936 = icmp ule i32 %local.resolved.offset.1725, %local.resolved.owner.end.1728
  %descriptor.extent.inside.1938 = icmp ule i32 %local.resolved.extent.1726, %stack.sub.1937
  %descriptor.payload.inside.1939 = icmp ule i32 %local.resolved.payload.1727, %local.resolved.extent.1726
  %descriptor.owner.offset.valid.1940 = and i1 %descriptor.owner.inside.1935, %descriptor.offset.inside.1936
  %descriptor.range.inside.1942 = and i1 %descriptor.owner.offset.valid.1940, %descriptor.extent.inside.1938
  %descriptor.range.valid.1941 = and i1 %descriptor.range.inside.1942, %descriptor.payload.inside.1939
  %descriptor.type.valid.1943 = icmp eq i32 4, 4
  %descriptor.valid.1944 = and i1 %descriptor.range.valid.1941, %descriptor.type.valid.1943
  br i1 %descriptor.valid.1944, label %descriptor.valid.1945, label %descriptor.invalid.1946
descriptor.invalid.1946:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1945:
  %descriptor.initialized.status.1947 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1725, i32 %local.resolved.extent.1726)
  %helper.ok.1948 = icmp eq i32 %descriptor.initialized.status.1947, 0
  br i1 %helper.ok.1948, label %helper.continue.1949, label %frame.failure.0
helper.continue.1949:
  %context.field.1950 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1951 = load i32, ptr %context.field.1950, align 4
  %stack.sub.1954 = sub i32 %local.resolved.owner.end.1911, %local.resolved.offset.1908
  %descriptor.owner.inside.1952 = icmp ule i32 %local.resolved.owner.end.1911, %context.value.1951
  %descriptor.offset.inside.1953 = icmp ule i32 %local.resolved.offset.1908, %local.resolved.owner.end.1911
  %descriptor.extent.inside.1955 = icmp ule i32 %local.resolved.extent.1909, %stack.sub.1954
  %descriptor.payload.inside.1956 = icmp ule i32 %local.resolved.payload.1910, %local.resolved.extent.1909
  %descriptor.owner.offset.valid.1957 = and i1 %descriptor.owner.inside.1952, %descriptor.offset.inside.1953
  %descriptor.range.inside.1959 = and i1 %descriptor.owner.offset.valid.1957, %descriptor.extent.inside.1955
  %descriptor.range.valid.1958 = and i1 %descriptor.range.inside.1959, %descriptor.payload.inside.1956
  %descriptor.type.valid.1960 = icmp eq i32 12, 12
  %descriptor.valid.1961 = and i1 %descriptor.range.valid.1958, %descriptor.type.valid.1960
  br i1 %descriptor.valid.1961, label %descriptor.valid.1962, label %descriptor.invalid.1963
descriptor.invalid.1963:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1962:
  %descriptor.initialized.status.1964 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1908, i32 %local.resolved.extent.1909)
  %helper.ok.1965 = icmp eq i32 %descriptor.initialized.status.1964, 0
  br i1 %helper.ok.1965, label %helper.continue.1966, label %frame.failure.0
helper.continue.1966:
  %local.is.active.1967 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1967, label %local.descriptor.active.1968, label %local.descriptor.inactive.1969
local.descriptor.active.1968:
  %local.check.offset.1971 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1972 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1973 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1974 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1975 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1976 = load i32, ptr %context.field.1975, align 4
  %stack.sub.1979 = sub i32 %local.check.owner.end.1974, %local.check.offset.1971
  %descriptor.owner.inside.1977 = icmp ule i32 %local.check.owner.end.1974, %context.value.1976
  %descriptor.offset.inside.1978 = icmp ule i32 %local.check.offset.1971, %local.check.owner.end.1974
  %descriptor.extent.inside.1980 = icmp ule i32 %local.check.extent.1972, %stack.sub.1979
  %descriptor.payload.inside.1981 = icmp ule i32 %local.check.payload.1973, %local.check.extent.1972
  %descriptor.owner.offset.valid.1982 = and i1 %descriptor.owner.inside.1977, %descriptor.offset.inside.1978
  %descriptor.range.inside.1984 = and i1 %descriptor.owner.offset.valid.1982, %descriptor.extent.inside.1980
  %descriptor.range.valid.1983 = and i1 %descriptor.range.inside.1984, %descriptor.payload.inside.1981
  br i1 %descriptor.range.valid.1983, label %descriptor.valid.1985, label %descriptor.invalid.1986
descriptor.invalid.1986:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1985:
  %descriptor.initialized.status.1987 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1971, i32 %local.check.extent.1972)
  %helper.ok.1988 = icmp eq i32 %descriptor.initialized.status.1987, 0
  br i1 %helper.ok.1988, label %helper.continue.1989, label %frame.failure.0
helper.continue.1989:
  br label %local.descriptor.checked.1970
local.descriptor.inactive.1969:
  br label %local.descriptor.checked.1970
local.descriptor.checked.1970:
  %local.is.active.1990 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1990, label %local.descriptor.active.1991, label %local.descriptor.inactive.1992
local.descriptor.active.1991:
  %local.check.offset.1994 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1995 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1996 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1997 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1998 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1999 = load i32, ptr %context.field.1998, align 4
  %stack.sub.2002 = sub i32 %local.check.owner.end.1997, %local.check.offset.1994
  %descriptor.owner.inside.2000 = icmp ule i32 %local.check.owner.end.1997, %context.value.1999
  %descriptor.offset.inside.2001 = icmp ule i32 %local.check.offset.1994, %local.check.owner.end.1997
  %descriptor.extent.inside.2003 = icmp ule i32 %local.check.extent.1995, %stack.sub.2002
  %descriptor.payload.inside.2004 = icmp ule i32 %local.check.payload.1996, %local.check.extent.1995
  %descriptor.owner.offset.valid.2005 = and i1 %descriptor.owner.inside.2000, %descriptor.offset.inside.2001
  %descriptor.range.inside.2007 = and i1 %descriptor.owner.offset.valid.2005, %descriptor.extent.inside.2003
  %descriptor.range.valid.2006 = and i1 %descriptor.range.inside.2007, %descriptor.payload.inside.2004
  br i1 %descriptor.range.valid.2006, label %descriptor.valid.2008, label %descriptor.invalid.2009
descriptor.invalid.2009:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2008:
  %descriptor.initialized.status.2010 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1994, i32 %local.check.extent.1995)
  %helper.ok.2011 = icmp eq i32 %descriptor.initialized.status.2010, 0
  br i1 %helper.ok.2011, label %helper.continue.2012, label %frame.failure.0
helper.continue.2012:
  br label %local.descriptor.checked.1993
local.descriptor.inactive.1992:
  br label %local.descriptor.checked.1993
local.descriptor.checked.1993:
  %local.is.active.2013 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2013, label %local.descriptor.active.2014, label %local.descriptor.inactive.2015
local.descriptor.active.2014:
  %local.check.offset.2017 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2018 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2019 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2020 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2021 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2022 = load i32, ptr %context.field.2021, align 4
  %stack.sub.2025 = sub i32 %local.check.owner.end.2020, %local.check.offset.2017
  %descriptor.owner.inside.2023 = icmp ule i32 %local.check.owner.end.2020, %context.value.2022
  %descriptor.offset.inside.2024 = icmp ule i32 %local.check.offset.2017, %local.check.owner.end.2020
  %descriptor.extent.inside.2026 = icmp ule i32 %local.check.extent.2018, %stack.sub.2025
  %descriptor.payload.inside.2027 = icmp ule i32 %local.check.payload.2019, %local.check.extent.2018
  %descriptor.owner.offset.valid.2028 = and i1 %descriptor.owner.inside.2023, %descriptor.offset.inside.2024
  %descriptor.range.inside.2030 = and i1 %descriptor.owner.offset.valid.2028, %descriptor.extent.inside.2026
  %descriptor.range.valid.2029 = and i1 %descriptor.range.inside.2030, %descriptor.payload.inside.2027
  br i1 %descriptor.range.valid.2029, label %descriptor.valid.2031, label %descriptor.invalid.2032
descriptor.invalid.2032:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2031:
  %descriptor.initialized.status.2033 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2017, i32 %local.check.extent.2018)
  %helper.ok.2034 = icmp eq i32 %descriptor.initialized.status.2033, 0
  br i1 %helper.ok.2034, label %helper.continue.2035, label %frame.failure.0
helper.continue.2035:
  br label %local.descriptor.checked.2016
local.descriptor.inactive.2015:
  br label %local.descriptor.checked.2016
local.descriptor.checked.2016:
  %local.is.active.2036 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2036, label %local.descriptor.active.2037, label %local.descriptor.inactive.2038
local.descriptor.active.2037:
  %local.check.offset.2040 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2041 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2042 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2043 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2044 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2045 = load i32, ptr %context.field.2044, align 4
  %stack.sub.2048 = sub i32 %local.check.owner.end.2043, %local.check.offset.2040
  %descriptor.owner.inside.2046 = icmp ule i32 %local.check.owner.end.2043, %context.value.2045
  %descriptor.offset.inside.2047 = icmp ule i32 %local.check.offset.2040, %local.check.owner.end.2043
  %descriptor.extent.inside.2049 = icmp ule i32 %local.check.extent.2041, %stack.sub.2048
  %descriptor.payload.inside.2050 = icmp ule i32 %local.check.payload.2042, %local.check.extent.2041
  %descriptor.owner.offset.valid.2051 = and i1 %descriptor.owner.inside.2046, %descriptor.offset.inside.2047
  %descriptor.range.inside.2053 = and i1 %descriptor.owner.offset.valid.2051, %descriptor.extent.inside.2049
  %descriptor.range.valid.2052 = and i1 %descriptor.range.inside.2053, %descriptor.payload.inside.2050
  br i1 %descriptor.range.valid.2052, label %descriptor.valid.2054, label %descriptor.invalid.2055
descriptor.invalid.2055:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2054:
  %descriptor.initialized.status.2056 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2040, i32 %local.check.extent.2041)
  %helper.ok.2057 = icmp eq i32 %descriptor.initialized.status.2056, 0
  br i1 %helper.ok.2057, label %helper.continue.2058, label %frame.failure.0
helper.continue.2058:
  br label %local.descriptor.checked.2039
local.descriptor.inactive.2038:
  br label %local.descriptor.checked.2039
local.descriptor.checked.2039:
  %local.is.active.2059 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2059, label %local.descriptor.active.2060, label %local.descriptor.inactive.2061
local.descriptor.active.2060:
  %local.check.offset.2063 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2064 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2065 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2066 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2067 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2068 = load i32, ptr %context.field.2067, align 4
  %stack.sub.2071 = sub i32 %local.check.owner.end.2066, %local.check.offset.2063
  %descriptor.owner.inside.2069 = icmp ule i32 %local.check.owner.end.2066, %context.value.2068
  %descriptor.offset.inside.2070 = icmp ule i32 %local.check.offset.2063, %local.check.owner.end.2066
  %descriptor.extent.inside.2072 = icmp ule i32 %local.check.extent.2064, %stack.sub.2071
  %descriptor.payload.inside.2073 = icmp ule i32 %local.check.payload.2065, %local.check.extent.2064
  %descriptor.owner.offset.valid.2074 = and i1 %descriptor.owner.inside.2069, %descriptor.offset.inside.2070
  %descriptor.range.inside.2076 = and i1 %descriptor.owner.offset.valid.2074, %descriptor.extent.inside.2072
  %descriptor.range.valid.2075 = and i1 %descriptor.range.inside.2076, %descriptor.payload.inside.2073
  br i1 %descriptor.range.valid.2075, label %descriptor.valid.2077, label %descriptor.invalid.2078
descriptor.invalid.2078:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2077:
  %descriptor.initialized.status.2079 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2063, i32 %local.check.extent.2064)
  %helper.ok.2080 = icmp eq i32 %descriptor.initialized.status.2079, 0
  br i1 %helper.ok.2080, label %helper.continue.2081, label %frame.failure.0
helper.continue.2081:
  br label %local.descriptor.checked.2062
local.descriptor.inactive.2061:
  br label %local.descriptor.checked.2062
local.descriptor.checked.2062:
  %local.is.active.2082 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2082, label %local.descriptor.active.2083, label %local.descriptor.inactive.2084
local.descriptor.active.2083:
  %local.check.offset.2086 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2087 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2088 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2089 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2090 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2091 = load i32, ptr %context.field.2090, align 4
  %stack.sub.2094 = sub i32 %local.check.owner.end.2089, %local.check.offset.2086
  %descriptor.owner.inside.2092 = icmp ule i32 %local.check.owner.end.2089, %context.value.2091
  %descriptor.offset.inside.2093 = icmp ule i32 %local.check.offset.2086, %local.check.owner.end.2089
  %descriptor.extent.inside.2095 = icmp ule i32 %local.check.extent.2087, %stack.sub.2094
  %descriptor.payload.inside.2096 = icmp ule i32 %local.check.payload.2088, %local.check.extent.2087
  %descriptor.owner.offset.valid.2097 = and i1 %descriptor.owner.inside.2092, %descriptor.offset.inside.2093
  %descriptor.range.inside.2099 = and i1 %descriptor.owner.offset.valid.2097, %descriptor.extent.inside.2095
  %descriptor.range.valid.2098 = and i1 %descriptor.range.inside.2099, %descriptor.payload.inside.2096
  br i1 %descriptor.range.valid.2098, label %descriptor.valid.2100, label %descriptor.invalid.2101
descriptor.invalid.2101:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2100:
  %descriptor.initialized.status.2102 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2086, i32 %local.check.extent.2087)
  %helper.ok.2103 = icmp eq i32 %descriptor.initialized.status.2102, 0
  br i1 %helper.ok.2103, label %helper.continue.2104, label %frame.failure.0
helper.continue.2104:
  br label %local.descriptor.checked.2085
local.descriptor.inactive.2084:
  br label %local.descriptor.checked.2085
local.descriptor.checked.2085:
  %step.status.2105 = call i32 @al_owning_charge_step(ptr %ctx, i32 17)
  %helper.ok.2106 = icmp eq i32 %step.status.2105, 0
  br i1 %helper.ok.2106, label %helper.continue.2107, label %frame.failure.0
helper.continue.2107:
  %local.resolved.offset.2108 = load i32, ptr %local.offset.33, align 4
  %local.resolved.extent.2109 = load i32, ptr %local.extent.34, align 4
  %local.resolved.payload.2110 = load i32, ptr %local.payload.35, align 4
  %local.resolved.owner.end.2111 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2112 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2113 = load i32, ptr %context.field.2112, align 4
  %stack.sub.2116 = sub i32 %local.resolved.owner.end.2111, %local.resolved.offset.2108
  %descriptor.owner.inside.2114 = icmp ule i32 %local.resolved.owner.end.2111, %context.value.2113
  %descriptor.offset.inside.2115 = icmp ule i32 %local.resolved.offset.2108, %local.resolved.owner.end.2111
  %descriptor.extent.inside.2117 = icmp ule i32 %local.resolved.extent.2109, %stack.sub.2116
  %descriptor.payload.inside.2118 = icmp ule i32 %local.resolved.payload.2110, %local.resolved.extent.2109
  %descriptor.owner.offset.valid.2119 = and i1 %descriptor.owner.inside.2114, %descriptor.offset.inside.2115
  %descriptor.range.inside.2121 = and i1 %descriptor.owner.offset.valid.2119, %descriptor.extent.inside.2117
  %descriptor.range.valid.2120 = and i1 %descriptor.range.inside.2121, %descriptor.payload.inside.2118
  %descriptor.type.valid.2122 = icmp eq i32 1, 1
  %descriptor.valid.2123 = and i1 %descriptor.range.valid.2120, %descriptor.type.valid.2122
  br i1 %descriptor.valid.2123, label %descriptor.valid.2124, label %descriptor.invalid.2125
descriptor.invalid.2125:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2124:
  %descriptor.initialized.status.2126 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.2108, i32 %local.resolved.extent.2109)
  %helper.ok.2127 = icmp eq i32 %descriptor.initialized.status.2126, 0
  br i1 %helper.ok.2127, label %helper.continue.2128, label %frame.failure.0
helper.continue.2128:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %local.resolved.offset.2108, i32 20, i32 %local.resolved.payload.2110, i32 %local.resolved.owner.end.2111, i32 %local.resolved.extent.2109)
  %context.field.2129 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2130 = load i32, ptr %context.field.2129, align 4
  %runtime.ok.2131 = icmp eq i32 %context.value.2130, 0
  br i1 %runtime.ok.2131, label %runtime.continue.2132, label %frame.failure.0
runtime.continue.2132:
  %context.field.2133 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2134 = load i32, ptr %context.field.2133, align 4
  %stack.sub.2137 = sub i32 %local.resolved.owner.end.1728, %local.resolved.offset.1725
  %descriptor.owner.inside.2135 = icmp ule i32 %local.resolved.owner.end.1728, %context.value.2134
  %descriptor.offset.inside.2136 = icmp ule i32 %local.resolved.offset.1725, %local.resolved.owner.end.1728
  %descriptor.extent.inside.2138 = icmp ule i32 %local.resolved.extent.1726, %stack.sub.2137
  %descriptor.payload.inside.2139 = icmp ule i32 %local.resolved.payload.1727, %local.resolved.extent.1726
  %descriptor.owner.offset.valid.2140 = and i1 %descriptor.owner.inside.2135, %descriptor.offset.inside.2136
  %descriptor.range.inside.2142 = and i1 %descriptor.owner.offset.valid.2140, %descriptor.extent.inside.2138
  %descriptor.range.valid.2141 = and i1 %descriptor.range.inside.2142, %descriptor.payload.inside.2139
  %descriptor.type.valid.2143 = icmp eq i32 4, 4
  %descriptor.valid.2144 = and i1 %descriptor.range.valid.2141, %descriptor.type.valid.2143
  br i1 %descriptor.valid.2144, label %descriptor.valid.2145, label %descriptor.invalid.2146
descriptor.invalid.2146:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2145:
  %descriptor.initialized.status.2147 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1725, i32 %local.resolved.extent.1726)
  %helper.ok.2148 = icmp eq i32 %descriptor.initialized.status.2147, 0
  br i1 %helper.ok.2148, label %helper.continue.2149, label %frame.failure.0
helper.continue.2149:
  %context.field.2150 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2151 = load i32, ptr %context.field.2150, align 4
  %stack.sub.2154 = sub i32 %local.resolved.owner.end.1911, %local.resolved.offset.1908
  %descriptor.owner.inside.2152 = icmp ule i32 %local.resolved.owner.end.1911, %context.value.2151
  %descriptor.offset.inside.2153 = icmp ule i32 %local.resolved.offset.1908, %local.resolved.owner.end.1911
  %descriptor.extent.inside.2155 = icmp ule i32 %local.resolved.extent.1909, %stack.sub.2154
  %descriptor.payload.inside.2156 = icmp ule i32 %local.resolved.payload.1910, %local.resolved.extent.1909
  %descriptor.owner.offset.valid.2157 = and i1 %descriptor.owner.inside.2152, %descriptor.offset.inside.2153
  %descriptor.range.inside.2159 = and i1 %descriptor.owner.offset.valid.2157, %descriptor.extent.inside.2155
  %descriptor.range.valid.2158 = and i1 %descriptor.range.inside.2159, %descriptor.payload.inside.2156
  %descriptor.type.valid.2160 = icmp eq i32 12, 12
  %descriptor.valid.2161 = and i1 %descriptor.range.valid.2158, %descriptor.type.valid.2160
  br i1 %descriptor.valid.2161, label %descriptor.valid.2162, label %descriptor.invalid.2163
descriptor.invalid.2163:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2162:
  %descriptor.initialized.status.2164 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1908, i32 %local.resolved.extent.1909)
  %helper.ok.2165 = icmp eq i32 %descriptor.initialized.status.2164, 0
  br i1 %helper.ok.2165, label %helper.continue.2166, label %frame.failure.0
helper.continue.2166:
  %context.field.2167 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2168 = load i32, ptr %context.field.2167, align 4
  %stack.sub.2171 = sub i32 %local.resolved.owner.end.2111, %local.resolved.offset.2108
  %descriptor.owner.inside.2169 = icmp ule i32 %local.resolved.owner.end.2111, %context.value.2168
  %descriptor.offset.inside.2170 = icmp ule i32 %local.resolved.offset.2108, %local.resolved.owner.end.2111
  %descriptor.extent.inside.2172 = icmp ule i32 %local.resolved.extent.2109, %stack.sub.2171
  %descriptor.payload.inside.2173 = icmp ule i32 %local.resolved.payload.2110, %local.resolved.extent.2109
  %descriptor.owner.offset.valid.2174 = and i1 %descriptor.owner.inside.2169, %descriptor.offset.inside.2170
  %descriptor.range.inside.2176 = and i1 %descriptor.owner.offset.valid.2174, %descriptor.extent.inside.2172
  %descriptor.range.valid.2175 = and i1 %descriptor.range.inside.2176, %descriptor.payload.inside.2173
  %descriptor.type.valid.2177 = icmp eq i32 1, 1
  %descriptor.valid.2178 = and i1 %descriptor.range.valid.2175, %descriptor.type.valid.2177
  br i1 %descriptor.valid.2178, label %descriptor.valid.2179, label %descriptor.invalid.2180
descriptor.invalid.2180:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2179:
  %descriptor.initialized.status.2181 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.2108, i32 %local.resolved.extent.2109)
  %helper.ok.2182 = icmp eq i32 %descriptor.initialized.status.2181, 0
  br i1 %helper.ok.2182, label %helper.continue.2183, label %frame.failure.0
helper.continue.2183:
  %local.is.active.2184 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2184, label %local.descriptor.active.2185, label %local.descriptor.inactive.2186
local.descriptor.active.2185:
  %local.check.offset.2188 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2189 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2190 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2191 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2192 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2193 = load i32, ptr %context.field.2192, align 4
  %stack.sub.2196 = sub i32 %local.check.owner.end.2191, %local.check.offset.2188
  %descriptor.owner.inside.2194 = icmp ule i32 %local.check.owner.end.2191, %context.value.2193
  %descriptor.offset.inside.2195 = icmp ule i32 %local.check.offset.2188, %local.check.owner.end.2191
  %descriptor.extent.inside.2197 = icmp ule i32 %local.check.extent.2189, %stack.sub.2196
  %descriptor.payload.inside.2198 = icmp ule i32 %local.check.payload.2190, %local.check.extent.2189
  %descriptor.owner.offset.valid.2199 = and i1 %descriptor.owner.inside.2194, %descriptor.offset.inside.2195
  %descriptor.range.inside.2201 = and i1 %descriptor.owner.offset.valid.2199, %descriptor.extent.inside.2197
  %descriptor.range.valid.2200 = and i1 %descriptor.range.inside.2201, %descriptor.payload.inside.2198
  br i1 %descriptor.range.valid.2200, label %descriptor.valid.2202, label %descriptor.invalid.2203
descriptor.invalid.2203:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2202:
  %descriptor.initialized.status.2204 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2188, i32 %local.check.extent.2189)
  %helper.ok.2205 = icmp eq i32 %descriptor.initialized.status.2204, 0
  br i1 %helper.ok.2205, label %helper.continue.2206, label %frame.failure.0
helper.continue.2206:
  br label %local.descriptor.checked.2187
local.descriptor.inactive.2186:
  br label %local.descriptor.checked.2187
local.descriptor.checked.2187:
  %local.is.active.2207 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2207, label %local.descriptor.active.2208, label %local.descriptor.inactive.2209
local.descriptor.active.2208:
  %local.check.offset.2211 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2212 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2213 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2214 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2215 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2216 = load i32, ptr %context.field.2215, align 4
  %stack.sub.2219 = sub i32 %local.check.owner.end.2214, %local.check.offset.2211
  %descriptor.owner.inside.2217 = icmp ule i32 %local.check.owner.end.2214, %context.value.2216
  %descriptor.offset.inside.2218 = icmp ule i32 %local.check.offset.2211, %local.check.owner.end.2214
  %descriptor.extent.inside.2220 = icmp ule i32 %local.check.extent.2212, %stack.sub.2219
  %descriptor.payload.inside.2221 = icmp ule i32 %local.check.payload.2213, %local.check.extent.2212
  %descriptor.owner.offset.valid.2222 = and i1 %descriptor.owner.inside.2217, %descriptor.offset.inside.2218
  %descriptor.range.inside.2224 = and i1 %descriptor.owner.offset.valid.2222, %descriptor.extent.inside.2220
  %descriptor.range.valid.2223 = and i1 %descriptor.range.inside.2224, %descriptor.payload.inside.2221
  br i1 %descriptor.range.valid.2223, label %descriptor.valid.2225, label %descriptor.invalid.2226
descriptor.invalid.2226:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2225:
  %descriptor.initialized.status.2227 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2211, i32 %local.check.extent.2212)
  %helper.ok.2228 = icmp eq i32 %descriptor.initialized.status.2227, 0
  br i1 %helper.ok.2228, label %helper.continue.2229, label %frame.failure.0
helper.continue.2229:
  br label %local.descriptor.checked.2210
local.descriptor.inactive.2209:
  br label %local.descriptor.checked.2210
local.descriptor.checked.2210:
  %local.is.active.2230 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2230, label %local.descriptor.active.2231, label %local.descriptor.inactive.2232
local.descriptor.active.2231:
  %local.check.offset.2234 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2235 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2236 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2237 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2238 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2239 = load i32, ptr %context.field.2238, align 4
  %stack.sub.2242 = sub i32 %local.check.owner.end.2237, %local.check.offset.2234
  %descriptor.owner.inside.2240 = icmp ule i32 %local.check.owner.end.2237, %context.value.2239
  %descriptor.offset.inside.2241 = icmp ule i32 %local.check.offset.2234, %local.check.owner.end.2237
  %descriptor.extent.inside.2243 = icmp ule i32 %local.check.extent.2235, %stack.sub.2242
  %descriptor.payload.inside.2244 = icmp ule i32 %local.check.payload.2236, %local.check.extent.2235
  %descriptor.owner.offset.valid.2245 = and i1 %descriptor.owner.inside.2240, %descriptor.offset.inside.2241
  %descriptor.range.inside.2247 = and i1 %descriptor.owner.offset.valid.2245, %descriptor.extent.inside.2243
  %descriptor.range.valid.2246 = and i1 %descriptor.range.inside.2247, %descriptor.payload.inside.2244
  br i1 %descriptor.range.valid.2246, label %descriptor.valid.2248, label %descriptor.invalid.2249
descriptor.invalid.2249:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2248:
  %descriptor.initialized.status.2250 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2234, i32 %local.check.extent.2235)
  %helper.ok.2251 = icmp eq i32 %descriptor.initialized.status.2250, 0
  br i1 %helper.ok.2251, label %helper.continue.2252, label %frame.failure.0
helper.continue.2252:
  br label %local.descriptor.checked.2233
local.descriptor.inactive.2232:
  br label %local.descriptor.checked.2233
local.descriptor.checked.2233:
  %local.is.active.2253 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2253, label %local.descriptor.active.2254, label %local.descriptor.inactive.2255
local.descriptor.active.2254:
  %local.check.offset.2257 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2258 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2259 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2260 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2261 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2262 = load i32, ptr %context.field.2261, align 4
  %stack.sub.2265 = sub i32 %local.check.owner.end.2260, %local.check.offset.2257
  %descriptor.owner.inside.2263 = icmp ule i32 %local.check.owner.end.2260, %context.value.2262
  %descriptor.offset.inside.2264 = icmp ule i32 %local.check.offset.2257, %local.check.owner.end.2260
  %descriptor.extent.inside.2266 = icmp ule i32 %local.check.extent.2258, %stack.sub.2265
  %descriptor.payload.inside.2267 = icmp ule i32 %local.check.payload.2259, %local.check.extent.2258
  %descriptor.owner.offset.valid.2268 = and i1 %descriptor.owner.inside.2263, %descriptor.offset.inside.2264
  %descriptor.range.inside.2270 = and i1 %descriptor.owner.offset.valid.2268, %descriptor.extent.inside.2266
  %descriptor.range.valid.2269 = and i1 %descriptor.range.inside.2270, %descriptor.payload.inside.2267
  br i1 %descriptor.range.valid.2269, label %descriptor.valid.2271, label %descriptor.invalid.2272
descriptor.invalid.2272:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2271:
  %descriptor.initialized.status.2273 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2257, i32 %local.check.extent.2258)
  %helper.ok.2274 = icmp eq i32 %descriptor.initialized.status.2273, 0
  br i1 %helper.ok.2274, label %helper.continue.2275, label %frame.failure.0
helper.continue.2275:
  br label %local.descriptor.checked.2256
local.descriptor.inactive.2255:
  br label %local.descriptor.checked.2256
local.descriptor.checked.2256:
  %local.is.active.2276 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2276, label %local.descriptor.active.2277, label %local.descriptor.inactive.2278
local.descriptor.active.2277:
  %local.check.offset.2280 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2281 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2282 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2283 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2284 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2285 = load i32, ptr %context.field.2284, align 4
  %stack.sub.2288 = sub i32 %local.check.owner.end.2283, %local.check.offset.2280
  %descriptor.owner.inside.2286 = icmp ule i32 %local.check.owner.end.2283, %context.value.2285
  %descriptor.offset.inside.2287 = icmp ule i32 %local.check.offset.2280, %local.check.owner.end.2283
  %descriptor.extent.inside.2289 = icmp ule i32 %local.check.extent.2281, %stack.sub.2288
  %descriptor.payload.inside.2290 = icmp ule i32 %local.check.payload.2282, %local.check.extent.2281
  %descriptor.owner.offset.valid.2291 = and i1 %descriptor.owner.inside.2286, %descriptor.offset.inside.2287
  %descriptor.range.inside.2293 = and i1 %descriptor.owner.offset.valid.2291, %descriptor.extent.inside.2289
  %descriptor.range.valid.2292 = and i1 %descriptor.range.inside.2293, %descriptor.payload.inside.2290
  br i1 %descriptor.range.valid.2292, label %descriptor.valid.2294, label %descriptor.invalid.2295
descriptor.invalid.2295:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2294:
  %descriptor.initialized.status.2296 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2280, i32 %local.check.extent.2281)
  %helper.ok.2297 = icmp eq i32 %descriptor.initialized.status.2296, 0
  br i1 %helper.ok.2297, label %helper.continue.2298, label %frame.failure.0
helper.continue.2298:
  br label %local.descriptor.checked.2279
local.descriptor.inactive.2278:
  br label %local.descriptor.checked.2279
local.descriptor.checked.2279:
  %local.is.active.2299 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2299, label %local.descriptor.active.2300, label %local.descriptor.inactive.2301
local.descriptor.active.2300:
  %local.check.offset.2303 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2304 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2305 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2306 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2307 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2308 = load i32, ptr %context.field.2307, align 4
  %stack.sub.2311 = sub i32 %local.check.owner.end.2306, %local.check.offset.2303
  %descriptor.owner.inside.2309 = icmp ule i32 %local.check.owner.end.2306, %context.value.2308
  %descriptor.offset.inside.2310 = icmp ule i32 %local.check.offset.2303, %local.check.owner.end.2306
  %descriptor.extent.inside.2312 = icmp ule i32 %local.check.extent.2304, %stack.sub.2311
  %descriptor.payload.inside.2313 = icmp ule i32 %local.check.payload.2305, %local.check.extent.2304
  %descriptor.owner.offset.valid.2314 = and i1 %descriptor.owner.inside.2309, %descriptor.offset.inside.2310
  %descriptor.range.inside.2316 = and i1 %descriptor.owner.offset.valid.2314, %descriptor.extent.inside.2312
  %descriptor.range.valid.2315 = and i1 %descriptor.range.inside.2316, %descriptor.payload.inside.2313
  br i1 %descriptor.range.valid.2315, label %descriptor.valid.2317, label %descriptor.invalid.2318
descriptor.invalid.2318:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2317:
  %descriptor.initialized.status.2319 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2303, i32 %local.check.extent.2304)
  %helper.ok.2320 = icmp eq i32 %descriptor.initialized.status.2319, 0
  br i1 %helper.ok.2320, label %helper.continue.2321, label %frame.failure.0
helper.continue.2321:
  br label %local.descriptor.checked.2302
local.descriptor.inactive.2301:
  br label %local.descriptor.checked.2302
local.descriptor.checked.2302:
  %step.status.2322 = call i32 @al_owning_charge_step(ptr %ctx, i32 18)
  %helper.ok.2323 = icmp eq i32 %step.status.2322, 0
  br i1 %helper.ok.2323, label %helper.continue.2324, label %frame.failure.0
helper.continue.2324:
  %stack.offset.2325 = add i32 0, %local.resolved.payload.1727
  %stack.offset.2326 = add i32 %stack.offset.2325, %local.resolved.payload.1910
  %stack.offset.2327 = add i32 %stack.offset.2326, %local.resolved.payload.2110
  %stack.offset.2328 = add i32 0, %local.resolved.extent.1909
  %stack.offset.2329 = add i32 %stack.offset.2328, %local.resolved.extent.2109
  %context.field.2330 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2331 = load i32, ptr %context.field.2330, align 4
  %stack.offset.2332 = add i32 %context.value.2331, %stack.offset.2329
  %reserve.status.2333 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.2332, i32 19)
  %reserve.ok.2334 = icmp eq i32 %reserve.status.2333, 0
  br i1 %reserve.ok.2334, label %reserve.continue.2335, label %frame.failure.0
reserve.continue.2335:
  %stack.offset.2336 = add i32 %context.value.2331, 0
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.2336, i32 %local.resolved.offset.1908, i32 %local.resolved.extent.1909, i32 %local.resolved.payload.1910, i32 12, i32 6)
  %context.field.2337 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2338 = load i32, ptr %context.field.2337, align 4
  %runtime.ok.2339 = icmp eq i32 %context.value.2338, 0
  br i1 %runtime.ok.2339, label %runtime.continue.2340, label %frame.failure.0
runtime.continue.2340:
  %stack.offset.2341 = add i32 0, %local.resolved.extent.1909
  %stack.offset.2342 = add i32 %context.value.2331, %stack.offset.2341
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.2342, i32 %local.resolved.offset.2108, i32 %local.resolved.extent.2109, i32 %local.resolved.payload.2110, i32 1, i32 6)
  %context.field.2343 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2344 = load i32, ptr %context.field.2343, align 4
  %runtime.ok.2345 = icmp eq i32 %context.value.2344, 0
  br i1 %runtime.ok.2345, label %runtime.continue.2346, label %frame.failure.0
runtime.continue.2346:
  %stack.offset.2347 = add i32 %stack.offset.2341, %local.resolved.extent.2109
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 10, i32 %context.value.2331, i32 %stack.offset.2329, i32 %stack.offset.2327, i32 0, i32 0)
  %context.field.2348 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2349 = load i32, ptr %context.field.2348, align 4
  %runtime.ok.2350 = icmp eq i32 %context.value.2349, 0
  br i1 %runtime.ok.2350, label %runtime.continue.2351, label %frame.failure.0
runtime.continue.2351:
  %context.field.2352 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2353 = load i32, ptr %context.field.2352, align 4
  %stack.sub.2356 = sub i32 %stack.offset.2332, %context.value.2331
  %descriptor.owner.inside.2354 = icmp ule i32 %stack.offset.2332, %context.value.2353
  %descriptor.offset.inside.2355 = icmp ule i32 %context.value.2331, %stack.offset.2332
  %descriptor.extent.inside.2357 = icmp ule i32 %stack.offset.2329, %stack.sub.2356
  %descriptor.payload.inside.2358 = icmp ule i32 %stack.offset.2327, %stack.offset.2329
  %descriptor.owner.offset.valid.2359 = and i1 %descriptor.owner.inside.2354, %descriptor.offset.inside.2355
  %descriptor.range.inside.2361 = and i1 %descriptor.owner.offset.valid.2359, %descriptor.extent.inside.2357
  %descriptor.range.valid.2360 = and i1 %descriptor.range.inside.2361, %descriptor.payload.inside.2358
  %descriptor.type.valid.2362 = icmp eq i32 10, 10
  %descriptor.valid.2363 = and i1 %descriptor.range.valid.2360, %descriptor.type.valid.2362
  br i1 %descriptor.valid.2363, label %descriptor.valid.2364, label %descriptor.invalid.2365
descriptor.invalid.2365:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2364:
  %descriptor.initialized.status.2366 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.2331, i32 %stack.offset.2329)
  %helper.ok.2367 = icmp eq i32 %descriptor.initialized.status.2366, 0
  br i1 %helper.ok.2367, label %helper.continue.2368, label %frame.failure.0
helper.continue.2368:
  %local.is.active.2369 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2369, label %local.descriptor.active.2370, label %local.descriptor.inactive.2371
local.descriptor.active.2370:
  %local.check.offset.2373 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2374 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2375 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2376 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2377 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2378 = load i32, ptr %context.field.2377, align 4
  %stack.sub.2381 = sub i32 %local.check.owner.end.2376, %local.check.offset.2373
  %descriptor.owner.inside.2379 = icmp ule i32 %local.check.owner.end.2376, %context.value.2378
  %descriptor.offset.inside.2380 = icmp ule i32 %local.check.offset.2373, %local.check.owner.end.2376
  %descriptor.extent.inside.2382 = icmp ule i32 %local.check.extent.2374, %stack.sub.2381
  %descriptor.payload.inside.2383 = icmp ule i32 %local.check.payload.2375, %local.check.extent.2374
  %descriptor.owner.offset.valid.2384 = and i1 %descriptor.owner.inside.2379, %descriptor.offset.inside.2380
  %descriptor.range.inside.2386 = and i1 %descriptor.owner.offset.valid.2384, %descriptor.extent.inside.2382
  %descriptor.range.valid.2385 = and i1 %descriptor.range.inside.2386, %descriptor.payload.inside.2383
  br i1 %descriptor.range.valid.2385, label %descriptor.valid.2387, label %descriptor.invalid.2388
descriptor.invalid.2388:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2387:
  %descriptor.initialized.status.2389 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2373, i32 %local.check.extent.2374)
  %helper.ok.2390 = icmp eq i32 %descriptor.initialized.status.2389, 0
  br i1 %helper.ok.2390, label %helper.continue.2391, label %frame.failure.0
helper.continue.2391:
  br label %local.descriptor.checked.2372
local.descriptor.inactive.2371:
  br label %local.descriptor.checked.2372
local.descriptor.checked.2372:
  %local.is.active.2392 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2392, label %local.descriptor.active.2393, label %local.descriptor.inactive.2394
local.descriptor.active.2393:
  %local.check.offset.2396 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2397 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2398 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2399 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2400 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2401 = load i32, ptr %context.field.2400, align 4
  %stack.sub.2404 = sub i32 %local.check.owner.end.2399, %local.check.offset.2396
  %descriptor.owner.inside.2402 = icmp ule i32 %local.check.owner.end.2399, %context.value.2401
  %descriptor.offset.inside.2403 = icmp ule i32 %local.check.offset.2396, %local.check.owner.end.2399
  %descriptor.extent.inside.2405 = icmp ule i32 %local.check.extent.2397, %stack.sub.2404
  %descriptor.payload.inside.2406 = icmp ule i32 %local.check.payload.2398, %local.check.extent.2397
  %descriptor.owner.offset.valid.2407 = and i1 %descriptor.owner.inside.2402, %descriptor.offset.inside.2403
  %descriptor.range.inside.2409 = and i1 %descriptor.owner.offset.valid.2407, %descriptor.extent.inside.2405
  %descriptor.range.valid.2408 = and i1 %descriptor.range.inside.2409, %descriptor.payload.inside.2406
  br i1 %descriptor.range.valid.2408, label %descriptor.valid.2410, label %descriptor.invalid.2411
descriptor.invalid.2411:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2410:
  %descriptor.initialized.status.2412 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2396, i32 %local.check.extent.2397)
  %helper.ok.2413 = icmp eq i32 %descriptor.initialized.status.2412, 0
  br i1 %helper.ok.2413, label %helper.continue.2414, label %frame.failure.0
helper.continue.2414:
  br label %local.descriptor.checked.2395
local.descriptor.inactive.2394:
  br label %local.descriptor.checked.2395
local.descriptor.checked.2395:
  %local.is.active.2415 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2415, label %local.descriptor.active.2416, label %local.descriptor.inactive.2417
local.descriptor.active.2416:
  %local.check.offset.2419 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2420 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2421 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2422 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2423 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2424 = load i32, ptr %context.field.2423, align 4
  %stack.sub.2427 = sub i32 %local.check.owner.end.2422, %local.check.offset.2419
  %descriptor.owner.inside.2425 = icmp ule i32 %local.check.owner.end.2422, %context.value.2424
  %descriptor.offset.inside.2426 = icmp ule i32 %local.check.offset.2419, %local.check.owner.end.2422
  %descriptor.extent.inside.2428 = icmp ule i32 %local.check.extent.2420, %stack.sub.2427
  %descriptor.payload.inside.2429 = icmp ule i32 %local.check.payload.2421, %local.check.extent.2420
  %descriptor.owner.offset.valid.2430 = and i1 %descriptor.owner.inside.2425, %descriptor.offset.inside.2426
  %descriptor.range.inside.2432 = and i1 %descriptor.owner.offset.valid.2430, %descriptor.extent.inside.2428
  %descriptor.range.valid.2431 = and i1 %descriptor.range.inside.2432, %descriptor.payload.inside.2429
  br i1 %descriptor.range.valid.2431, label %descriptor.valid.2433, label %descriptor.invalid.2434
descriptor.invalid.2434:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2433:
  %descriptor.initialized.status.2435 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2419, i32 %local.check.extent.2420)
  %helper.ok.2436 = icmp eq i32 %descriptor.initialized.status.2435, 0
  br i1 %helper.ok.2436, label %helper.continue.2437, label %frame.failure.0
helper.continue.2437:
  br label %local.descriptor.checked.2418
local.descriptor.inactive.2417:
  br label %local.descriptor.checked.2418
local.descriptor.checked.2418:
  %local.is.active.2438 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2438, label %local.descriptor.active.2439, label %local.descriptor.inactive.2440
local.descriptor.active.2439:
  %local.check.offset.2442 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2443 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2444 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2445 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2446 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2447 = load i32, ptr %context.field.2446, align 4
  %stack.sub.2450 = sub i32 %local.check.owner.end.2445, %local.check.offset.2442
  %descriptor.owner.inside.2448 = icmp ule i32 %local.check.owner.end.2445, %context.value.2447
  %descriptor.offset.inside.2449 = icmp ule i32 %local.check.offset.2442, %local.check.owner.end.2445
  %descriptor.extent.inside.2451 = icmp ule i32 %local.check.extent.2443, %stack.sub.2450
  %descriptor.payload.inside.2452 = icmp ule i32 %local.check.payload.2444, %local.check.extent.2443
  %descriptor.owner.offset.valid.2453 = and i1 %descriptor.owner.inside.2448, %descriptor.offset.inside.2449
  %descriptor.range.inside.2455 = and i1 %descriptor.owner.offset.valid.2453, %descriptor.extent.inside.2451
  %descriptor.range.valid.2454 = and i1 %descriptor.range.inside.2455, %descriptor.payload.inside.2452
  br i1 %descriptor.range.valid.2454, label %descriptor.valid.2456, label %descriptor.invalid.2457
descriptor.invalid.2457:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2456:
  %descriptor.initialized.status.2458 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2442, i32 %local.check.extent.2443)
  %helper.ok.2459 = icmp eq i32 %descriptor.initialized.status.2458, 0
  br i1 %helper.ok.2459, label %helper.continue.2460, label %frame.failure.0
helper.continue.2460:
  br label %local.descriptor.checked.2441
local.descriptor.inactive.2440:
  br label %local.descriptor.checked.2441
local.descriptor.checked.2441:
  %local.is.active.2461 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2461, label %local.descriptor.active.2462, label %local.descriptor.inactive.2463
local.descriptor.active.2462:
  %local.check.offset.2465 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2466 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2467 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2468 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2469 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2470 = load i32, ptr %context.field.2469, align 4
  %stack.sub.2473 = sub i32 %local.check.owner.end.2468, %local.check.offset.2465
  %descriptor.owner.inside.2471 = icmp ule i32 %local.check.owner.end.2468, %context.value.2470
  %descriptor.offset.inside.2472 = icmp ule i32 %local.check.offset.2465, %local.check.owner.end.2468
  %descriptor.extent.inside.2474 = icmp ule i32 %local.check.extent.2466, %stack.sub.2473
  %descriptor.payload.inside.2475 = icmp ule i32 %local.check.payload.2467, %local.check.extent.2466
  %descriptor.owner.offset.valid.2476 = and i1 %descriptor.owner.inside.2471, %descriptor.offset.inside.2472
  %descriptor.range.inside.2478 = and i1 %descriptor.owner.offset.valid.2476, %descriptor.extent.inside.2474
  %descriptor.range.valid.2477 = and i1 %descriptor.range.inside.2478, %descriptor.payload.inside.2475
  br i1 %descriptor.range.valid.2477, label %descriptor.valid.2479, label %descriptor.invalid.2480
descriptor.invalid.2480:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2479:
  %descriptor.initialized.status.2481 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2465, i32 %local.check.extent.2466)
  %helper.ok.2482 = icmp eq i32 %descriptor.initialized.status.2481, 0
  br i1 %helper.ok.2482, label %helper.continue.2483, label %frame.failure.0
helper.continue.2483:
  br label %local.descriptor.checked.2464
local.descriptor.inactive.2463:
  br label %local.descriptor.checked.2464
local.descriptor.checked.2464:
  %local.is.active.2484 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2484, label %local.descriptor.active.2485, label %local.descriptor.inactive.2486
local.descriptor.active.2485:
  %local.check.offset.2488 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2489 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2490 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2491 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2492 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2493 = load i32, ptr %context.field.2492, align 4
  %stack.sub.2496 = sub i32 %local.check.owner.end.2491, %local.check.offset.2488
  %descriptor.owner.inside.2494 = icmp ule i32 %local.check.owner.end.2491, %context.value.2493
  %descriptor.offset.inside.2495 = icmp ule i32 %local.check.offset.2488, %local.check.owner.end.2491
  %descriptor.extent.inside.2497 = icmp ule i32 %local.check.extent.2489, %stack.sub.2496
  %descriptor.payload.inside.2498 = icmp ule i32 %local.check.payload.2490, %local.check.extent.2489
  %descriptor.owner.offset.valid.2499 = and i1 %descriptor.owner.inside.2494, %descriptor.offset.inside.2495
  %descriptor.range.inside.2501 = and i1 %descriptor.owner.offset.valid.2499, %descriptor.extent.inside.2497
  %descriptor.range.valid.2500 = and i1 %descriptor.range.inside.2501, %descriptor.payload.inside.2498
  br i1 %descriptor.range.valid.2500, label %descriptor.valid.2502, label %descriptor.invalid.2503
descriptor.invalid.2503:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2502:
  %descriptor.initialized.status.2504 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2488, i32 %local.check.extent.2489)
  %helper.ok.2505 = icmp eq i32 %descriptor.initialized.status.2504, 0
  br i1 %helper.ok.2505, label %helper.continue.2506, label %frame.failure.0
helper.continue.2506:
  br label %local.descriptor.checked.2487
local.descriptor.inactive.2486:
  br label %local.descriptor.checked.2487
local.descriptor.checked.2487:
  store i1 false, ptr %local.active.32, align 1
  store i32 0, ptr %local.offset.33, align 4
  store i32 0, ptr %local.extent.34, align 4
  store i32 0, ptr %local.payload.35, align 4
  store i32 0, ptr %local.owner.end.36, align 4
  store i32 0, ptr %local.type.37, align 4
  store i1 false, ptr %local.active.26, align 1
  store i32 0, ptr %local.offset.27, align 4
  store i32 0, ptr %local.extent.28, align 4
  store i32 0, ptr %local.payload.29, align 4
  store i32 0, ptr %local.owner.end.30, align 4
  store i32 0, ptr %local.type.31, align 4
  store i1 false, ptr %local.active.20, align 1
  store i32 0, ptr %local.offset.21, align 4
  store i32 0, ptr %local.extent.22, align 4
  store i32 0, ptr %local.payload.23, align 4
  store i32 0, ptr %local.owner.end.24, align 4
  store i32 0, ptr %local.type.25, align 4
  %context.field.2507 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2508 = load i32, ptr %context.field.2507, align 4
  %stack.sub.2511 = sub i32 %stack.offset.2332, %context.value.2331
  %descriptor.owner.inside.2509 = icmp ule i32 %stack.offset.2332, %context.value.2508
  %descriptor.offset.inside.2510 = icmp ule i32 %context.value.2331, %stack.offset.2332
  %descriptor.extent.inside.2512 = icmp ule i32 %stack.offset.2329, %stack.sub.2511
  %descriptor.payload.inside.2513 = icmp ule i32 %stack.offset.2327, %stack.offset.2329
  %descriptor.owner.offset.valid.2514 = and i1 %descriptor.owner.inside.2509, %descriptor.offset.inside.2510
  %descriptor.range.inside.2516 = and i1 %descriptor.owner.offset.valid.2514, %descriptor.extent.inside.2512
  %descriptor.range.valid.2515 = and i1 %descriptor.range.inside.2516, %descriptor.payload.inside.2513
  %descriptor.type.valid.2517 = icmp eq i32 10, 10
  %descriptor.valid.2518 = and i1 %descriptor.range.valid.2515, %descriptor.type.valid.2517
  br i1 %descriptor.valid.2518, label %descriptor.valid.2519, label %descriptor.invalid.2520
descriptor.invalid.2520:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2519:
  %descriptor.initialized.status.2521 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.2331, i32 %stack.offset.2329)
  %helper.ok.2522 = icmp eq i32 %descriptor.initialized.status.2521, 0
  br i1 %helper.ok.2522, label %helper.continue.2523, label %frame.failure.0
helper.continue.2523:
  %local.is.active.2524 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2524, label %local.descriptor.active.2525, label %local.descriptor.inactive.2526
local.descriptor.active.2525:
  %local.check.offset.2528 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2529 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2530 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2531 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2532 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2533 = load i32, ptr %context.field.2532, align 4
  %stack.sub.2536 = sub i32 %local.check.owner.end.2531, %local.check.offset.2528
  %descriptor.owner.inside.2534 = icmp ule i32 %local.check.owner.end.2531, %context.value.2533
  %descriptor.offset.inside.2535 = icmp ule i32 %local.check.offset.2528, %local.check.owner.end.2531
  %descriptor.extent.inside.2537 = icmp ule i32 %local.check.extent.2529, %stack.sub.2536
  %descriptor.payload.inside.2538 = icmp ule i32 %local.check.payload.2530, %local.check.extent.2529
  %descriptor.owner.offset.valid.2539 = and i1 %descriptor.owner.inside.2534, %descriptor.offset.inside.2535
  %descriptor.range.inside.2541 = and i1 %descriptor.owner.offset.valid.2539, %descriptor.extent.inside.2537
  %descriptor.range.valid.2540 = and i1 %descriptor.range.inside.2541, %descriptor.payload.inside.2538
  br i1 %descriptor.range.valid.2540, label %descriptor.valid.2542, label %descriptor.invalid.2543
descriptor.invalid.2543:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2542:
  %descriptor.initialized.status.2544 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2528, i32 %local.check.extent.2529)
  %helper.ok.2545 = icmp eq i32 %descriptor.initialized.status.2544, 0
  br i1 %helper.ok.2545, label %helper.continue.2546, label %frame.failure.0
helper.continue.2546:
  br label %local.descriptor.checked.2527
local.descriptor.inactive.2526:
  br label %local.descriptor.checked.2527
local.descriptor.checked.2527:
  %local.is.active.2547 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2547, label %local.descriptor.active.2548, label %local.descriptor.inactive.2549
local.descriptor.active.2548:
  %local.check.offset.2551 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2552 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2553 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2554 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2555 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2556 = load i32, ptr %context.field.2555, align 4
  %stack.sub.2559 = sub i32 %local.check.owner.end.2554, %local.check.offset.2551
  %descriptor.owner.inside.2557 = icmp ule i32 %local.check.owner.end.2554, %context.value.2556
  %descriptor.offset.inside.2558 = icmp ule i32 %local.check.offset.2551, %local.check.owner.end.2554
  %descriptor.extent.inside.2560 = icmp ule i32 %local.check.extent.2552, %stack.sub.2559
  %descriptor.payload.inside.2561 = icmp ule i32 %local.check.payload.2553, %local.check.extent.2552
  %descriptor.owner.offset.valid.2562 = and i1 %descriptor.owner.inside.2557, %descriptor.offset.inside.2558
  %descriptor.range.inside.2564 = and i1 %descriptor.owner.offset.valid.2562, %descriptor.extent.inside.2560
  %descriptor.range.valid.2563 = and i1 %descriptor.range.inside.2564, %descriptor.payload.inside.2561
  br i1 %descriptor.range.valid.2563, label %descriptor.valid.2565, label %descriptor.invalid.2566
descriptor.invalid.2566:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2565:
  %descriptor.initialized.status.2567 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2551, i32 %local.check.extent.2552)
  %helper.ok.2568 = icmp eq i32 %descriptor.initialized.status.2567, 0
  br i1 %helper.ok.2568, label %helper.continue.2569, label %frame.failure.0
helper.continue.2569:
  br label %local.descriptor.checked.2550
local.descriptor.inactive.2549:
  br label %local.descriptor.checked.2550
local.descriptor.checked.2550:
  %local.is.active.2570 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2570, label %local.descriptor.active.2571, label %local.descriptor.inactive.2572
local.descriptor.active.2571:
  %local.check.offset.2574 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2575 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2576 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2577 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2578 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2579 = load i32, ptr %context.field.2578, align 4
  %stack.sub.2582 = sub i32 %local.check.owner.end.2577, %local.check.offset.2574
  %descriptor.owner.inside.2580 = icmp ule i32 %local.check.owner.end.2577, %context.value.2579
  %descriptor.offset.inside.2581 = icmp ule i32 %local.check.offset.2574, %local.check.owner.end.2577
  %descriptor.extent.inside.2583 = icmp ule i32 %local.check.extent.2575, %stack.sub.2582
  %descriptor.payload.inside.2584 = icmp ule i32 %local.check.payload.2576, %local.check.extent.2575
  %descriptor.owner.offset.valid.2585 = and i1 %descriptor.owner.inside.2580, %descriptor.offset.inside.2581
  %descriptor.range.inside.2587 = and i1 %descriptor.owner.offset.valid.2585, %descriptor.extent.inside.2583
  %descriptor.range.valid.2586 = and i1 %descriptor.range.inside.2587, %descriptor.payload.inside.2584
  br i1 %descriptor.range.valid.2586, label %descriptor.valid.2588, label %descriptor.invalid.2589
descriptor.invalid.2589:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2588:
  %descriptor.initialized.status.2590 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2574, i32 %local.check.extent.2575)
  %helper.ok.2591 = icmp eq i32 %descriptor.initialized.status.2590, 0
  br i1 %helper.ok.2591, label %helper.continue.2592, label %frame.failure.0
helper.continue.2592:
  br label %local.descriptor.checked.2573
local.descriptor.inactive.2572:
  br label %local.descriptor.checked.2573
local.descriptor.checked.2573:
  %local.is.active.2593 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2593, label %local.descriptor.active.2594, label %local.descriptor.inactive.2595
local.descriptor.active.2594:
  %local.check.offset.2597 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2598 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2599 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2600 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2601 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2602 = load i32, ptr %context.field.2601, align 4
  %stack.sub.2605 = sub i32 %local.check.owner.end.2600, %local.check.offset.2597
  %descriptor.owner.inside.2603 = icmp ule i32 %local.check.owner.end.2600, %context.value.2602
  %descriptor.offset.inside.2604 = icmp ule i32 %local.check.offset.2597, %local.check.owner.end.2600
  %descriptor.extent.inside.2606 = icmp ule i32 %local.check.extent.2598, %stack.sub.2605
  %descriptor.payload.inside.2607 = icmp ule i32 %local.check.payload.2599, %local.check.extent.2598
  %descriptor.owner.offset.valid.2608 = and i1 %descriptor.owner.inside.2603, %descriptor.offset.inside.2604
  %descriptor.range.inside.2610 = and i1 %descriptor.owner.offset.valid.2608, %descriptor.extent.inside.2606
  %descriptor.range.valid.2609 = and i1 %descriptor.range.inside.2610, %descriptor.payload.inside.2607
  br i1 %descriptor.range.valid.2609, label %descriptor.valid.2611, label %descriptor.invalid.2612
descriptor.invalid.2612:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2611:
  %descriptor.initialized.status.2613 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2597, i32 %local.check.extent.2598)
  %helper.ok.2614 = icmp eq i32 %descriptor.initialized.status.2613, 0
  br i1 %helper.ok.2614, label %helper.continue.2615, label %frame.failure.0
helper.continue.2615:
  br label %local.descriptor.checked.2596
local.descriptor.inactive.2595:
  br label %local.descriptor.checked.2596
local.descriptor.checked.2596:
  %local.is.active.2616 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2616, label %local.descriptor.active.2617, label %local.descriptor.inactive.2618
local.descriptor.active.2617:
  %local.check.offset.2620 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2621 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2622 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2623 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2624 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2625 = load i32, ptr %context.field.2624, align 4
  %stack.sub.2628 = sub i32 %local.check.owner.end.2623, %local.check.offset.2620
  %descriptor.owner.inside.2626 = icmp ule i32 %local.check.owner.end.2623, %context.value.2625
  %descriptor.offset.inside.2627 = icmp ule i32 %local.check.offset.2620, %local.check.owner.end.2623
  %descriptor.extent.inside.2629 = icmp ule i32 %local.check.extent.2621, %stack.sub.2628
  %descriptor.payload.inside.2630 = icmp ule i32 %local.check.payload.2622, %local.check.extent.2621
  %descriptor.owner.offset.valid.2631 = and i1 %descriptor.owner.inside.2626, %descriptor.offset.inside.2627
  %descriptor.range.inside.2633 = and i1 %descriptor.owner.offset.valid.2631, %descriptor.extent.inside.2629
  %descriptor.range.valid.2632 = and i1 %descriptor.range.inside.2633, %descriptor.payload.inside.2630
  br i1 %descriptor.range.valid.2632, label %descriptor.valid.2634, label %descriptor.invalid.2635
descriptor.invalid.2635:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2634:
  %descriptor.initialized.status.2636 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2620, i32 %local.check.extent.2621)
  %helper.ok.2637 = icmp eq i32 %descriptor.initialized.status.2636, 0
  br i1 %helper.ok.2637, label %helper.continue.2638, label %frame.failure.0
helper.continue.2638:
  br label %local.descriptor.checked.2619
local.descriptor.inactive.2618:
  br label %local.descriptor.checked.2619
local.descriptor.checked.2619:
  %local.is.active.2639 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2639, label %local.descriptor.active.2640, label %local.descriptor.inactive.2641
local.descriptor.active.2640:
  %local.check.offset.2643 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2644 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2645 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2646 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2647 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2648 = load i32, ptr %context.field.2647, align 4
  %stack.sub.2651 = sub i32 %local.check.owner.end.2646, %local.check.offset.2643
  %descriptor.owner.inside.2649 = icmp ule i32 %local.check.owner.end.2646, %context.value.2648
  %descriptor.offset.inside.2650 = icmp ule i32 %local.check.offset.2643, %local.check.owner.end.2646
  %descriptor.extent.inside.2652 = icmp ule i32 %local.check.extent.2644, %stack.sub.2651
  %descriptor.payload.inside.2653 = icmp ule i32 %local.check.payload.2645, %local.check.extent.2644
  %descriptor.owner.offset.valid.2654 = and i1 %descriptor.owner.inside.2649, %descriptor.offset.inside.2650
  %descriptor.range.inside.2656 = and i1 %descriptor.owner.offset.valid.2654, %descriptor.extent.inside.2652
  %descriptor.range.valid.2655 = and i1 %descriptor.range.inside.2656, %descriptor.payload.inside.2653
  br i1 %descriptor.range.valid.2655, label %descriptor.valid.2657, label %descriptor.invalid.2658
descriptor.invalid.2658:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2657:
  %descriptor.initialized.status.2659 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2643, i32 %local.check.extent.2644)
  %helper.ok.2660 = icmp eq i32 %descriptor.initialized.status.2659, 0
  br i1 %helper.ok.2660, label %helper.continue.2661, label %frame.failure.0
helper.continue.2661:
  br label %local.descriptor.checked.2642
local.descriptor.inactive.2641:
  br label %local.descriptor.checked.2642
local.descriptor.checked.2642:
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %descriptor.element.2662 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.2663 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.2662, i32 0, i32 0
  store i32 10, ptr %descriptor.field.2663, align 4
  %descriptor.field.2664 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.2662, i32 0, i32 1
  store i32 %context.value.2331, ptr %descriptor.field.2664, align 4
  %descriptor.field.2665 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.2662, i32 0, i32 2
  store i32 %stack.offset.2329, ptr %descriptor.field.2665, align 4
  %descriptor.field.2666 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.2662, i32 0, i32 3
  store i32 %stack.offset.2327, ptr %descriptor.field.2666, align 4
  %descriptor.field.2667 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.2662, i32 0, i32 4
  store i32 %stack.offset.2332, ptr %descriptor.field.2667, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 10, i32 %context.value.2331, i32 20, i32 %stack.offset.2327, i32 %stack.offset.2332, i32 %stack.offset.2329)
  %context.field.2668 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2669 = load i32, ptr %context.field.2668, align 4
  %runtime.ok.2670 = icmp eq i32 %context.value.2669, 0
  br i1 %runtime.ok.2670, label %runtime.continue.2671, label %frame.failure.0
runtime.continue.2671:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.39, i32 0, i32 0, i32 0)
  %context.field.2672 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.2673 = load i32, ptr %context.field.2672, align 4
  %context.field.2674 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.2675 = load i32, ptr %context.field.2674, align 4
  %context.field.2676 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.2677 = load i32, ptr %context.field.2676, align 4
  %stack.offset.2678 = add i32 %context.value.41, %context.value.43
  %stack.offset.2679 = add i32 %context.value.2673, %context.value.2675
  %stack.sub.2680 = sub i32 %stack.offset.2678, %stack.offset.2679
  %stack.sub.2681 = sub i32 %context.value.43, %context.value.2675
  %stack.sub.2682 = sub i32 %context.value.2677, %context.value.45
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.2680, i32 %stack.sub.2681)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.2682)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 2
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 2, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %entry.input.descriptors.10 = alloca [2 x %AlOwningDescriptor], align 4
  %input.extent.pointer.11 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.12 = load i32, ptr %input.extent.pointer.11, align 4
  %host.pointer.13 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.14 = alloca i32, align 4
  %input.measured.extent.pointer.15 = alloca i32, align 4
  %input.measure.status.16 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 3, ptr %host.pointer.13, i32 %input.host.extent.12, i32 0, i32 20, ptr %input.payload.pointer.14, ptr %input.measured.extent.pointer.15)
  %helper.ok.17 = icmp eq i32 %input.measure.status.16, 0
  br i1 %helper.ok.17, label %helper.continue.18, label %entry.failure.0
helper.continue.18:
  %input.measured.payload.19 = load i32, ptr %input.payload.pointer.14, align 4
  %input.measured.extent.20 = load i32, ptr %input.measured.extent.pointer.15, align 4
  %input.extent.exact.21 = icmp eq i32 %input.measured.extent.20, %input.host.extent.12
  br i1 %input.extent.exact.21, label %input.extent.exact.22, label %input.extent.invalid.23
input.extent.invalid.23:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 20, i32 %input.measured.extent.20, i32 %input.host.extent.12)
  br label %entry.failure.0
input.extent.exact.22:
  %stack.offset.24 = add i32 0, %input.host.extent.12
  %input.extent.pointer.25 = getelementptr inbounds i32, ptr %input.extents, i32 1
  %input.host.extent.26 = load i32, ptr %input.extent.pointer.25, align 4
  %host.pointer.27 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.24
  %input.payload.pointer.28 = alloca i32, align 4
  %input.measured.extent.pointer.29 = alloca i32, align 4
  %input.measure.status.30 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 0, ptr %host.pointer.27, i32 %input.host.extent.26, i32 0, i32 21, ptr %input.payload.pointer.28, ptr %input.measured.extent.pointer.29)
  %helper.ok.31 = icmp eq i32 %input.measure.status.30, 0
  br i1 %helper.ok.31, label %helper.continue.32, label %entry.failure.0
helper.continue.32:
  %input.measured.payload.33 = load i32, ptr %input.payload.pointer.28, align 4
  %input.measured.extent.34 = load i32, ptr %input.measured.extent.pointer.29, align 4
  %input.extent.exact.35 = icmp eq i32 %input.measured.extent.34, %input.host.extent.26
  br i1 %input.extent.exact.35, label %input.extent.exact.36, label %input.extent.invalid.37
input.extent.invalid.37:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 21, i32 %input.measured.extent.34, i32 %input.host.extent.26)
  br label %entry.failure.0
input.extent.exact.36:
  %stack.offset.38 = add i32 %stack.offset.24, %input.host.extent.26
  %input.total.exact.39 = icmp eq i32 %stack.offset.38, %input.bytes
  br i1 %input.total.exact.39, label %input.valid.40, label %input.invalid.41
input.invalid.41:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.38, i32 %input.bytes)
  br label %entry.failure.0
input.valid.40:
  %reserve.status.42 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.38, i32 22)
  %reserve.ok.43 = icmp eq i32 %reserve.status.42, 0
  br i1 %reserve.ok.43, label %reserve.continue.44, label %entry.failure.0
reserve.continue.44:
  %host.pointer.45 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.46 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.45, i32 %input.host.extent.12, i32 0, i32 %input.measured.payload.19, i32 %input.host.extent.12, i32 12, i32 23)
  %helper.ok.47 = icmp eq i32 %input.copy.status.46, 0
  br i1 %helper.ok.47, label %helper.continue.48, label %entry.failure.0
helper.continue.48:
  %stack.offset.49 = add i32 0, %input.host.extent.12
  %descriptor.element.50 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.10, i32 0
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 0
  store i32 12, ptr %descriptor.field.51, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 1
  store i32 0, ptr %descriptor.field.52, align 4
  %descriptor.field.53 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 2
  store i32 %input.host.extent.12, ptr %descriptor.field.53, align 4
  %descriptor.field.54 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 3
  store i32 %input.measured.payload.19, ptr %descriptor.field.54, align 4
  %descriptor.field.55 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 4
  store i32 %stack.offset.49, ptr %descriptor.field.55, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 0, i32 20, i32 %input.measured.payload.19, i32 %stack.offset.49, i32 %input.host.extent.12)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %entry.failure.0
runtime.continue.59:
  %host.pointer.60 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.24
  %input.copy.status.61 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.24, ptr %host.pointer.60, i32 %input.host.extent.26, i32 0, i32 %input.measured.payload.33, i32 %input.host.extent.26, i32 1, i32 24)
  %helper.ok.62 = icmp eq i32 %input.copy.status.61, 0
  br i1 %helper.ok.62, label %helper.continue.63, label %entry.failure.0
helper.continue.63:
  %stack.offset.64 = add i32 %stack.offset.24, %input.host.extent.26
  %descriptor.element.65 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.10, i32 1
  %descriptor.field.66 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.65, i32 0, i32 0
  store i32 1, ptr %descriptor.field.66, align 4
  %descriptor.field.67 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.65, i32 0, i32 1
  store i32 %stack.offset.24, ptr %descriptor.field.67, align 4
  %descriptor.field.68 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.65, i32 0, i32 2
  store i32 %input.host.extent.26, ptr %descriptor.field.68, align 4
  %descriptor.field.69 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.65, i32 0, i32 3
  store i32 %input.measured.payload.33, ptr %descriptor.field.69, align 4
  %descriptor.field.70 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.65, i32 0, i32 4
  store i32 %stack.offset.64, ptr %descriptor.field.70, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %stack.offset.24, i32 20, i32 %input.measured.payload.33, i32 %stack.offset.64, i32 %input.host.extent.26)
  %context.field.71 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.72 = load i32, ptr %context.field.71, align 4
  %runtime.ok.73 = icmp eq i32 %context.value.72, 0
  br i1 %runtime.ok.73, label %runtime.continue.74, label %entry.failure.0
runtime.continue.74:
  %entry.output.descriptors.75 = alloca [1 x %AlOwningDescriptor], align 4
  %entry.body.status.76 = call i32 @agentlang_entry_frame(ptr %ctx, ptr %entry.input.descriptors.10, ptr %entry.output.descriptors.75, i32 25)
  %entry.body.ok.77 = icmp eq i32 %entry.body.status.76, 0
  br i1 %entry.body.ok.77, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.78 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.75, i32 0
  %descriptor.field.79 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.78, i32 0, i32 0
  %descriptor.value.80 = load i32, ptr %descriptor.field.79, align 4
  %descriptor.field.81 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.78, i32 0, i32 1
  %descriptor.value.82 = load i32, ptr %descriptor.field.81, align 4
  %descriptor.field.83 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.78, i32 0, i32 2
  %descriptor.value.84 = load i32, ptr %descriptor.field.83, align 4
  %descriptor.field.85 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.78, i32 0, i32 3
  %descriptor.value.86 = load i32, ptr %descriptor.field.85, align 4
  %descriptor.field.87 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.78, i32 0, i32 4
  %descriptor.value.88 = load i32, ptr %descriptor.field.87, align 4
  %entry.output.type.valid.89 = icmp eq i32 %descriptor.value.80, 10
  br i1 %entry.output.type.valid.89, label %entry.output.type.ok.90, label %entry.output.type.invalid.91
entry.output.type.invalid.91:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.90:
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %stack.sub.96 = sub i32 %descriptor.value.88, %descriptor.value.82
  %descriptor.owner.inside.94 = icmp ule i32 %descriptor.value.88, %context.value.93
  %descriptor.offset.inside.95 = icmp ule i32 %descriptor.value.82, %descriptor.value.88
  %descriptor.extent.inside.97 = icmp ule i32 %descriptor.value.84, %stack.sub.96
  %descriptor.payload.inside.98 = icmp ule i32 %descriptor.value.86, %descriptor.value.84
  %descriptor.owner.offset.valid.99 = and i1 %descriptor.owner.inside.94, %descriptor.offset.inside.95
  %descriptor.range.inside.101 = and i1 %descriptor.owner.offset.valid.99, %descriptor.extent.inside.97
  %descriptor.range.valid.100 = and i1 %descriptor.range.inside.101, %descriptor.payload.inside.98
  %descriptor.type.valid.102 = icmp eq i32 10, 10
  %descriptor.valid.103 = and i1 %descriptor.range.valid.100, %descriptor.type.valid.102
  br i1 %descriptor.valid.103, label %descriptor.valid.104, label %descriptor.invalid.105
descriptor.invalid.105:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.104:
  %descriptor.initialized.status.106 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.82, i32 %descriptor.value.84)
  %helper.ok.107 = icmp eq i32 %descriptor.initialized.status.106, 0
  br i1 %helper.ok.107, label %helper.continue.108, label %entry.failure.0
helper.continue.108:
  %entry.output.size.i64.109 = zext i32 %descriptor.value.84 to i64
  %entry.output.total.i64.110 = add i64 0, %entry.output.size.i64.109
  %entry.retained.capacity.i64.111 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.112 = icmp ule i64 %entry.output.total.i64.110, 4294967295
  %entry.retained.required.truncated.113 = trunc i64 %entry.output.total.i64.110 to i32
  %entry.retained.required.114 = select i1 %entry.retained.required.fits.u32.112, i32 %entry.retained.required.truncated.113, i32 4294967295
  %entry.retained.capacity.ok.115 = icmp ule i64 %entry.output.total.i64.110, %entry.retained.capacity.i64.111
  br i1 %entry.retained.capacity.ok.115, label %entry.retained.capacity.ready.116, label %entry.retained.capacity.failure.117
entry.retained.capacity.failure.117:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.114, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.116:
  %host.pointer.118 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.119 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.118, i32 %stack.sub.119, i32 %descriptor.value.82, i32 %descriptor.value.84, i32 10)
  %context.field.120 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.121 = load i32, ptr %context.field.120, align 4
  %runtime.ok.122 = icmp eq i32 %context.value.121, 0
  br i1 %runtime.ok.122, label %runtime.continue.123, label %entry.failure.0
runtime.continue.123:
  %stack.offset.124 = add i32 0, %descriptor.value.84
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.125 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.126 = load i32, ptr %context.field.125, align 4
  %context.field.127 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.128 = load i32, ptr %context.field.127, align 4
  %stack.sub.129 = sub i32 0, %context.value.126
  %stack.sub.130 = sub i32 0, %context.value.128
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.129, i32 %stack.sub.130)
  %context.field.131 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.132 = load i32, ptr %context.field.131, align 4
  %runtime.ok.133 = icmp eq i32 %context.value.132, 0
  br i1 %runtime.ok.133, label %runtime.continue.134, label %entry.failure.0
runtime.continue.134:
  br label %entry.return.status
entry.failure.0:
  %context.field.135 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.136 = load i32, ptr %context.field.135, align 4
  %context.field.137 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.138 = load i32, ptr %context.field.137, align 4
  %context.field.139 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.140 = load i32, ptr %context.field.139, align 4
  %stack.offset.141 = add i32 %context.value.136, %context.value.138
  %stack.sub.142 = sub i32 0, %stack.offset.141
  %stack.sub.143 = sub i32 0, %context.value.138
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.142, i32 %stack.sub.143)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.140)
  br label %entry.return.status
entry.return.status:
  %context.field.144 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.145 = load i32, ptr %context.field.144, align 4
  ret i32 %context.value.145
}


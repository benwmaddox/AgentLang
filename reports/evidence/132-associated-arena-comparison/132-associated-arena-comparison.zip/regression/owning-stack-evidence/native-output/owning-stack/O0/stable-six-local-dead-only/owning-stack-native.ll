%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [2 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8 }, %AlOwningTypeDescriptor { i32 4, i32 6, i32 0, i32 1, i32 8, i32 8, i32 8, i32 8 }], align 4
@al_owning_fields = private constant [1 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 0, i32 0, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 1, ptr @al_owning_types, i32 2, ptr @al_owning_fields, i32 1 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %local.active.2 = alloca i1, align 1
  %local.offset.3 = alloca i32, align 4
  %local.extent.4 = alloca i32, align 4
  %local.payload.5 = alloca i32, align 4
  %local.owner.end.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %local.active.8 = alloca i1, align 1
  %local.offset.9 = alloca i32, align 4
  %local.extent.10 = alloca i32, align 4
  %local.payload.11 = alloca i32, align 4
  %local.owner.end.12 = alloca i32, align 4
  %local.type.13 = alloca i32, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  %local.active.14 = alloca i1, align 1
  %local.offset.15 = alloca i32, align 4
  %local.extent.16 = alloca i32, align 4
  %local.payload.17 = alloca i32, align 4
  %local.owner.end.18 = alloca i32, align 4
  %local.type.19 = alloca i32, align 4
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  %local.active.20 = alloca i1, align 1
  %local.offset.21 = alloca i32, align 4
  %local.extent.22 = alloca i32, align 4
  %local.payload.23 = alloca i32, align 4
  %local.owner.end.24 = alloca i32, align 4
  %local.type.25 = alloca i32, align 4
  store i1 false, ptr %local.active.20, align 1
  store i32 0, ptr %local.offset.21, align 4
  store i32 0, ptr %local.extent.22, align 4
  store i32 0, ptr %local.payload.23, align 4
  store i32 0, ptr %local.owner.end.24, align 4
  store i32 0, ptr %local.type.25, align 4
  %local.active.26 = alloca i1, align 1
  %local.offset.27 = alloca i32, align 4
  %local.extent.28 = alloca i32, align 4
  %local.payload.29 = alloca i32, align 4
  %local.owner.end.30 = alloca i32, align 4
  %local.type.31 = alloca i32, align 4
  store i1 false, ptr %local.active.26, align 1
  store i32 0, ptr %local.offset.27, align 4
  store i32 0, ptr %local.extent.28, align 4
  store i32 0, ptr %local.payload.29, align 4
  store i32 0, ptr %local.owner.end.30, align 4
  store i32 0, ptr %local.type.31, align 4
  %local.active.32 = alloca i1, align 1
  %local.offset.33 = alloca i32, align 4
  %local.extent.34 = alloca i32, align 4
  %local.payload.35 = alloca i32, align 4
  %local.owner.end.36 = alloca i32, align 4
  %local.type.37 = alloca i32, align 4
  store i1 false, ptr %local.active.32, align 1
  store i32 0, ptr %local.offset.33, align 4
  store i32 0, ptr %local.extent.34, align 4
  store i32 0, ptr %local.payload.35, align 4
  store i32 0, ptr %local.owner.end.36, align 4
  store i32 0, ptr %local.type.37, align 4
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %context.field.40 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.41 = load i32, ptr %context.field.40, align 4
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %context.field.44 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.45 = load i32, ptr %context.field.44, align 4
  %frame.entered.46 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.47 = icmp eq i32 %frame.entered.46, 0
  br i1 %frame.enter.ok.47, label %frame.enter.continue.48, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.48:
  %descriptor.element.49 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 0
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 1
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %descriptor.field.54 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 2
  %descriptor.value.55 = load i32, ptr %descriptor.field.54, align 4
  %descriptor.field.56 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 3
  %descriptor.value.57 = load i32, ptr %descriptor.field.56, align 4
  %descriptor.field.58 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 4
  %descriptor.value.59 = load i32, ptr %descriptor.field.58, align 4
  %argument.type.valid.60 = icmp eq i32 %descriptor.value.51, 1
  br i1 %argument.type.valid.60, label %argument.type.ok.61, label %frame.failure.0
argument.type.ok.61:
  %context.field.62 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.63 = load i32, ptr %context.field.62, align 4
  %stack.sub.66 = sub i32 %descriptor.value.59, %descriptor.value.53
  %descriptor.owner.inside.64 = icmp ule i32 %descriptor.value.59, %context.value.63
  %descriptor.offset.inside.65 = icmp ule i32 %descriptor.value.53, %descriptor.value.59
  %descriptor.extent.inside.67 = icmp ule i32 %descriptor.value.55, %stack.sub.66
  %descriptor.payload.inside.68 = icmp ule i32 %descriptor.value.57, %descriptor.value.55
  %descriptor.owner.offset.valid.69 = and i1 %descriptor.owner.inside.64, %descriptor.offset.inside.65
  %descriptor.range.inside.71 = and i1 %descriptor.owner.offset.valid.69, %descriptor.extent.inside.67
  %descriptor.range.valid.70 = and i1 %descriptor.range.inside.71, %descriptor.payload.inside.68
  %descriptor.type.valid.72 = icmp eq i32 1, 1
  %descriptor.valid.73 = and i1 %descriptor.range.valid.70, %descriptor.type.valid.72
  br i1 %descriptor.valid.73, label %descriptor.valid.74, label %descriptor.invalid.75
descriptor.invalid.75:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.74:
  %descriptor.initialized.status.76 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.53, i32 %descriptor.value.55)
  %helper.ok.77 = icmp eq i32 %descriptor.initialized.status.76, 0
  br i1 %helper.ok.77, label %helper.continue.78, label %frame.failure.0
helper.continue.78:
  %descriptor.element.79 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.80 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 0
  %descriptor.value.81 = load i32, ptr %descriptor.field.80, align 4
  %descriptor.field.82 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 1
  %descriptor.value.83 = load i32, ptr %descriptor.field.82, align 4
  %descriptor.field.84 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 2
  %descriptor.value.85 = load i32, ptr %descriptor.field.84, align 4
  %descriptor.field.86 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 3
  %descriptor.value.87 = load i32, ptr %descriptor.field.86, align 4
  %descriptor.field.88 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 4
  %descriptor.value.89 = load i32, ptr %descriptor.field.88, align 4
  %argument.type.valid.90 = icmp eq i32 %descriptor.value.81, 1
  br i1 %argument.type.valid.90, label %argument.type.ok.91, label %frame.failure.0
argument.type.ok.91:
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %stack.sub.96 = sub i32 %descriptor.value.89, %descriptor.value.83
  %descriptor.owner.inside.94 = icmp ule i32 %descriptor.value.89, %context.value.93
  %descriptor.offset.inside.95 = icmp ule i32 %descriptor.value.83, %descriptor.value.89
  %descriptor.extent.inside.97 = icmp ule i32 %descriptor.value.85, %stack.sub.96
  %descriptor.payload.inside.98 = icmp ule i32 %descriptor.value.87, %descriptor.value.85
  %descriptor.owner.offset.valid.99 = and i1 %descriptor.owner.inside.94, %descriptor.offset.inside.95
  %descriptor.range.inside.101 = and i1 %descriptor.owner.offset.valid.99, %descriptor.extent.inside.97
  %descriptor.range.valid.100 = and i1 %descriptor.range.inside.101, %descriptor.payload.inside.98
  %descriptor.type.valid.102 = icmp eq i32 1, 1
  %descriptor.valid.103 = and i1 %descriptor.range.valid.100, %descriptor.type.valid.102
  br i1 %descriptor.valid.103, label %descriptor.valid.104, label %descriptor.invalid.105
descriptor.invalid.105:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.104:
  %descriptor.initialized.status.106 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.83, i32 %descriptor.value.85)
  %helper.ok.107 = icmp eq i32 %descriptor.initialized.status.106, 0
  br i1 %helper.ok.107, label %helper.continue.108, label %frame.failure.0
helper.continue.108:
  %descriptor.element.109 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 2
  %descriptor.field.110 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.109, i32 0, i32 0
  %descriptor.value.111 = load i32, ptr %descriptor.field.110, align 4
  %descriptor.field.112 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.109, i32 0, i32 1
  %descriptor.value.113 = load i32, ptr %descriptor.field.112, align 4
  %descriptor.field.114 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.109, i32 0, i32 2
  %descriptor.value.115 = load i32, ptr %descriptor.field.114, align 4
  %descriptor.field.116 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.109, i32 0, i32 3
  %descriptor.value.117 = load i32, ptr %descriptor.field.116, align 4
  %descriptor.field.118 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.109, i32 0, i32 4
  %descriptor.value.119 = load i32, ptr %descriptor.field.118, align 4
  %argument.type.valid.120 = icmp eq i32 %descriptor.value.111, 1
  br i1 %argument.type.valid.120, label %argument.type.ok.121, label %frame.failure.0
argument.type.ok.121:
  %context.field.122 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.123 = load i32, ptr %context.field.122, align 4
  %stack.sub.126 = sub i32 %descriptor.value.119, %descriptor.value.113
  %descriptor.owner.inside.124 = icmp ule i32 %descriptor.value.119, %context.value.123
  %descriptor.offset.inside.125 = icmp ule i32 %descriptor.value.113, %descriptor.value.119
  %descriptor.extent.inside.127 = icmp ule i32 %descriptor.value.115, %stack.sub.126
  %descriptor.payload.inside.128 = icmp ule i32 %descriptor.value.117, %descriptor.value.115
  %descriptor.owner.offset.valid.129 = and i1 %descriptor.owner.inside.124, %descriptor.offset.inside.125
  %descriptor.range.inside.131 = and i1 %descriptor.owner.offset.valid.129, %descriptor.extent.inside.127
  %descriptor.range.valid.130 = and i1 %descriptor.range.inside.131, %descriptor.payload.inside.128
  %descriptor.type.valid.132 = icmp eq i32 1, 1
  %descriptor.valid.133 = and i1 %descriptor.range.valid.130, %descriptor.type.valid.132
  br i1 %descriptor.valid.133, label %descriptor.valid.134, label %descriptor.invalid.135
descriptor.invalid.135:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.134:
  %descriptor.initialized.status.136 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.113, i32 %descriptor.value.115)
  %helper.ok.137 = icmp eq i32 %descriptor.initialized.status.136, 0
  br i1 %helper.ok.137, label %helper.continue.138, label %frame.failure.0
helper.continue.138:
  %descriptor.element.139 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 3
  %descriptor.field.140 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.139, i32 0, i32 0
  %descriptor.value.141 = load i32, ptr %descriptor.field.140, align 4
  %descriptor.field.142 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.139, i32 0, i32 1
  %descriptor.value.143 = load i32, ptr %descriptor.field.142, align 4
  %descriptor.field.144 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.139, i32 0, i32 2
  %descriptor.value.145 = load i32, ptr %descriptor.field.144, align 4
  %descriptor.field.146 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.139, i32 0, i32 3
  %descriptor.value.147 = load i32, ptr %descriptor.field.146, align 4
  %descriptor.field.148 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.139, i32 0, i32 4
  %descriptor.value.149 = load i32, ptr %descriptor.field.148, align 4
  %argument.type.valid.150 = icmp eq i32 %descriptor.value.141, 1
  br i1 %argument.type.valid.150, label %argument.type.ok.151, label %frame.failure.0
argument.type.ok.151:
  %context.field.152 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.153 = load i32, ptr %context.field.152, align 4
  %stack.sub.156 = sub i32 %descriptor.value.149, %descriptor.value.143
  %descriptor.owner.inside.154 = icmp ule i32 %descriptor.value.149, %context.value.153
  %descriptor.offset.inside.155 = icmp ule i32 %descriptor.value.143, %descriptor.value.149
  %descriptor.extent.inside.157 = icmp ule i32 %descriptor.value.145, %stack.sub.156
  %descriptor.payload.inside.158 = icmp ule i32 %descriptor.value.147, %descriptor.value.145
  %descriptor.owner.offset.valid.159 = and i1 %descriptor.owner.inside.154, %descriptor.offset.inside.155
  %descriptor.range.inside.161 = and i1 %descriptor.owner.offset.valid.159, %descriptor.extent.inside.157
  %descriptor.range.valid.160 = and i1 %descriptor.range.inside.161, %descriptor.payload.inside.158
  %descriptor.type.valid.162 = icmp eq i32 1, 1
  %descriptor.valid.163 = and i1 %descriptor.range.valid.160, %descriptor.type.valid.162
  br i1 %descriptor.valid.163, label %descriptor.valid.164, label %descriptor.invalid.165
descriptor.invalid.165:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.164:
  %descriptor.initialized.status.166 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.143, i32 %descriptor.value.145)
  %helper.ok.167 = icmp eq i32 %descriptor.initialized.status.166, 0
  br i1 %helper.ok.167, label %helper.continue.168, label %frame.failure.0
helper.continue.168:
  %descriptor.element.169 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 4
  %descriptor.field.170 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.169, i32 0, i32 0
  %descriptor.value.171 = load i32, ptr %descriptor.field.170, align 4
  %descriptor.field.172 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.169, i32 0, i32 1
  %descriptor.value.173 = load i32, ptr %descriptor.field.172, align 4
  %descriptor.field.174 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.169, i32 0, i32 2
  %descriptor.value.175 = load i32, ptr %descriptor.field.174, align 4
  %descriptor.field.176 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.169, i32 0, i32 3
  %descriptor.value.177 = load i32, ptr %descriptor.field.176, align 4
  %descriptor.field.178 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.169, i32 0, i32 4
  %descriptor.value.179 = load i32, ptr %descriptor.field.178, align 4
  %argument.type.valid.180 = icmp eq i32 %descriptor.value.171, 1
  br i1 %argument.type.valid.180, label %argument.type.ok.181, label %frame.failure.0
argument.type.ok.181:
  %context.field.182 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.183 = load i32, ptr %context.field.182, align 4
  %stack.sub.186 = sub i32 %descriptor.value.179, %descriptor.value.173
  %descriptor.owner.inside.184 = icmp ule i32 %descriptor.value.179, %context.value.183
  %descriptor.offset.inside.185 = icmp ule i32 %descriptor.value.173, %descriptor.value.179
  %descriptor.extent.inside.187 = icmp ule i32 %descriptor.value.175, %stack.sub.186
  %descriptor.payload.inside.188 = icmp ule i32 %descriptor.value.177, %descriptor.value.175
  %descriptor.owner.offset.valid.189 = and i1 %descriptor.owner.inside.184, %descriptor.offset.inside.185
  %descriptor.range.inside.191 = and i1 %descriptor.owner.offset.valid.189, %descriptor.extent.inside.187
  %descriptor.range.valid.190 = and i1 %descriptor.range.inside.191, %descriptor.payload.inside.188
  %descriptor.type.valid.192 = icmp eq i32 1, 1
  %descriptor.valid.193 = and i1 %descriptor.range.valid.190, %descriptor.type.valid.192
  br i1 %descriptor.valid.193, label %descriptor.valid.194, label %descriptor.invalid.195
descriptor.invalid.195:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.194:
  %descriptor.initialized.status.196 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.173, i32 %descriptor.value.175)
  %helper.ok.197 = icmp eq i32 %descriptor.initialized.status.196, 0
  br i1 %helper.ok.197, label %helper.continue.198, label %frame.failure.0
helper.continue.198:
  %descriptor.element.199 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 5
  %descriptor.field.200 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.199, i32 0, i32 0
  %descriptor.value.201 = load i32, ptr %descriptor.field.200, align 4
  %descriptor.field.202 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.199, i32 0, i32 1
  %descriptor.value.203 = load i32, ptr %descriptor.field.202, align 4
  %descriptor.field.204 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.199, i32 0, i32 2
  %descriptor.value.205 = load i32, ptr %descriptor.field.204, align 4
  %descriptor.field.206 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.199, i32 0, i32 3
  %descriptor.value.207 = load i32, ptr %descriptor.field.206, align 4
  %descriptor.field.208 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.199, i32 0, i32 4
  %descriptor.value.209 = load i32, ptr %descriptor.field.208, align 4
  %argument.type.valid.210 = icmp eq i32 %descriptor.value.201, 1
  br i1 %argument.type.valid.210, label %argument.type.ok.211, label %frame.failure.0
argument.type.ok.211:
  %context.field.212 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.213 = load i32, ptr %context.field.212, align 4
  %stack.sub.216 = sub i32 %descriptor.value.209, %descriptor.value.203
  %descriptor.owner.inside.214 = icmp ule i32 %descriptor.value.209, %context.value.213
  %descriptor.offset.inside.215 = icmp ule i32 %descriptor.value.203, %descriptor.value.209
  %descriptor.extent.inside.217 = icmp ule i32 %descriptor.value.205, %stack.sub.216
  %descriptor.payload.inside.218 = icmp ule i32 %descriptor.value.207, %descriptor.value.205
  %descriptor.owner.offset.valid.219 = and i1 %descriptor.owner.inside.214, %descriptor.offset.inside.215
  %descriptor.range.inside.221 = and i1 %descriptor.owner.offset.valid.219, %descriptor.extent.inside.217
  %descriptor.range.valid.220 = and i1 %descriptor.range.inside.221, %descriptor.payload.inside.218
  %descriptor.type.valid.222 = icmp eq i32 1, 1
  %descriptor.valid.223 = and i1 %descriptor.range.valid.220, %descriptor.type.valid.222
  br i1 %descriptor.valid.223, label %descriptor.valid.224, label %descriptor.invalid.225
descriptor.invalid.225:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.224:
  %descriptor.initialized.status.226 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.203, i32 %descriptor.value.205)
  %helper.ok.227 = icmp eq i32 %descriptor.initialized.status.226, 0
  br i1 %helper.ok.227, label %helper.continue.228, label %frame.failure.0
helper.continue.228:
  %step.status.229 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.230 = icmp eq i32 %step.status.229, 0
  br i1 %helper.ok.230, label %helper.continue.231, label %frame.failure.0
helper.continue.231:
  %context.field.232 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.233 = load i32, ptr %context.field.232, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  store i1 false, ptr %local.active.20, align 1
  store i32 0, ptr %local.offset.21, align 4
  store i32 0, ptr %local.extent.22, align 4
  store i32 0, ptr %local.payload.23, align 4
  store i32 0, ptr %local.owner.end.24, align 4
  store i32 0, ptr %local.type.25, align 4
  store i1 false, ptr %local.active.26, align 1
  store i32 0, ptr %local.offset.27, align 4
  store i32 0, ptr %local.extent.28, align 4
  store i32 0, ptr %local.payload.29, align 4
  store i32 0, ptr %local.owner.end.30, align 4
  store i32 0, ptr %local.type.31, align 4
  store i1 false, ptr %local.active.32, align 1
  store i32 0, ptr %local.offset.33, align 4
  store i32 0, ptr %local.extent.34, align 4
  store i32 0, ptr %local.payload.35, align 4
  store i32 0, ptr %local.owner.end.36, align 4
  store i32 0, ptr %local.type.37, align 4
  %step.status.234 = call i32 @al_owning_charge_step(ptr %ctx, i32 2)
  %helper.ok.235 = icmp eq i32 %step.status.234, 0
  br i1 %helper.ok.235, label %helper.continue.236, label %frame.failure.0
helper.continue.236:
  store i1 true, ptr %local.active.2, align 1
  store i32 %descriptor.value.203, ptr %local.offset.3, align 4
  store i32 %descriptor.value.205, ptr %local.extent.4, align 4
  store i32 %descriptor.value.207, ptr %local.payload.5, align 4
  store i32 %descriptor.value.209, ptr %local.owner.end.6, align 4
  store i32 1, ptr %local.type.7, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %descriptor.value.203, i32 20, i32 %descriptor.value.207, i32 %descriptor.value.209, i32 %descriptor.value.205)
  %context.field.237 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.238 = load i32, ptr %context.field.237, align 4
  %runtime.ok.239 = icmp eq i32 %context.value.238, 0
  br i1 %runtime.ok.239, label %runtime.continue.240, label %frame.failure.0
runtime.continue.240:
  %context.field.241 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.242 = load i32, ptr %context.field.241, align 4
  %stack.sub.245 = sub i32 %descriptor.value.59, %descriptor.value.53
  %descriptor.owner.inside.243 = icmp ule i32 %descriptor.value.59, %context.value.242
  %descriptor.offset.inside.244 = icmp ule i32 %descriptor.value.53, %descriptor.value.59
  %descriptor.extent.inside.246 = icmp ule i32 %descriptor.value.55, %stack.sub.245
  %descriptor.payload.inside.247 = icmp ule i32 %descriptor.value.57, %descriptor.value.55
  %descriptor.owner.offset.valid.248 = and i1 %descriptor.owner.inside.243, %descriptor.offset.inside.244
  %descriptor.range.inside.250 = and i1 %descriptor.owner.offset.valid.248, %descriptor.extent.inside.246
  %descriptor.range.valid.249 = and i1 %descriptor.range.inside.250, %descriptor.payload.inside.247
  %descriptor.type.valid.251 = icmp eq i32 1, 1
  %descriptor.valid.252 = and i1 %descriptor.range.valid.249, %descriptor.type.valid.251
  br i1 %descriptor.valid.252, label %descriptor.valid.253, label %descriptor.invalid.254
descriptor.invalid.254:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.253:
  %descriptor.initialized.status.255 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.53, i32 %descriptor.value.55)
  %helper.ok.256 = icmp eq i32 %descriptor.initialized.status.255, 0
  br i1 %helper.ok.256, label %helper.continue.257, label %frame.failure.0
helper.continue.257:
  %context.field.258 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.259 = load i32, ptr %context.field.258, align 4
  %stack.sub.262 = sub i32 %descriptor.value.89, %descriptor.value.83
  %descriptor.owner.inside.260 = icmp ule i32 %descriptor.value.89, %context.value.259
  %descriptor.offset.inside.261 = icmp ule i32 %descriptor.value.83, %descriptor.value.89
  %descriptor.extent.inside.263 = icmp ule i32 %descriptor.value.85, %stack.sub.262
  %descriptor.payload.inside.264 = icmp ule i32 %descriptor.value.87, %descriptor.value.85
  %descriptor.owner.offset.valid.265 = and i1 %descriptor.owner.inside.260, %descriptor.offset.inside.261
  %descriptor.range.inside.267 = and i1 %descriptor.owner.offset.valid.265, %descriptor.extent.inside.263
  %descriptor.range.valid.266 = and i1 %descriptor.range.inside.267, %descriptor.payload.inside.264
  %descriptor.type.valid.268 = icmp eq i32 1, 1
  %descriptor.valid.269 = and i1 %descriptor.range.valid.266, %descriptor.type.valid.268
  br i1 %descriptor.valid.269, label %descriptor.valid.270, label %descriptor.invalid.271
descriptor.invalid.271:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.270:
  %descriptor.initialized.status.272 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.83, i32 %descriptor.value.85)
  %helper.ok.273 = icmp eq i32 %descriptor.initialized.status.272, 0
  br i1 %helper.ok.273, label %helper.continue.274, label %frame.failure.0
helper.continue.274:
  %context.field.275 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.276 = load i32, ptr %context.field.275, align 4
  %stack.sub.279 = sub i32 %descriptor.value.119, %descriptor.value.113
  %descriptor.owner.inside.277 = icmp ule i32 %descriptor.value.119, %context.value.276
  %descriptor.offset.inside.278 = icmp ule i32 %descriptor.value.113, %descriptor.value.119
  %descriptor.extent.inside.280 = icmp ule i32 %descriptor.value.115, %stack.sub.279
  %descriptor.payload.inside.281 = icmp ule i32 %descriptor.value.117, %descriptor.value.115
  %descriptor.owner.offset.valid.282 = and i1 %descriptor.owner.inside.277, %descriptor.offset.inside.278
  %descriptor.range.inside.284 = and i1 %descriptor.owner.offset.valid.282, %descriptor.extent.inside.280
  %descriptor.range.valid.283 = and i1 %descriptor.range.inside.284, %descriptor.payload.inside.281
  %descriptor.type.valid.285 = icmp eq i32 1, 1
  %descriptor.valid.286 = and i1 %descriptor.range.valid.283, %descriptor.type.valid.285
  br i1 %descriptor.valid.286, label %descriptor.valid.287, label %descriptor.invalid.288
descriptor.invalid.288:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.287:
  %descriptor.initialized.status.289 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.113, i32 %descriptor.value.115)
  %helper.ok.290 = icmp eq i32 %descriptor.initialized.status.289, 0
  br i1 %helper.ok.290, label %helper.continue.291, label %frame.failure.0
helper.continue.291:
  %context.field.292 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.293 = load i32, ptr %context.field.292, align 4
  %stack.sub.296 = sub i32 %descriptor.value.149, %descriptor.value.143
  %descriptor.owner.inside.294 = icmp ule i32 %descriptor.value.149, %context.value.293
  %descriptor.offset.inside.295 = icmp ule i32 %descriptor.value.143, %descriptor.value.149
  %descriptor.extent.inside.297 = icmp ule i32 %descriptor.value.145, %stack.sub.296
  %descriptor.payload.inside.298 = icmp ule i32 %descriptor.value.147, %descriptor.value.145
  %descriptor.owner.offset.valid.299 = and i1 %descriptor.owner.inside.294, %descriptor.offset.inside.295
  %descriptor.range.inside.301 = and i1 %descriptor.owner.offset.valid.299, %descriptor.extent.inside.297
  %descriptor.range.valid.300 = and i1 %descriptor.range.inside.301, %descriptor.payload.inside.298
  %descriptor.type.valid.302 = icmp eq i32 1, 1
  %descriptor.valid.303 = and i1 %descriptor.range.valid.300, %descriptor.type.valid.302
  br i1 %descriptor.valid.303, label %descriptor.valid.304, label %descriptor.invalid.305
descriptor.invalid.305:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.304:
  %descriptor.initialized.status.306 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.143, i32 %descriptor.value.145)
  %helper.ok.307 = icmp eq i32 %descriptor.initialized.status.306, 0
  br i1 %helper.ok.307, label %helper.continue.308, label %frame.failure.0
helper.continue.308:
  %context.field.309 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.310 = load i32, ptr %context.field.309, align 4
  %stack.sub.313 = sub i32 %descriptor.value.179, %descriptor.value.173
  %descriptor.owner.inside.311 = icmp ule i32 %descriptor.value.179, %context.value.310
  %descriptor.offset.inside.312 = icmp ule i32 %descriptor.value.173, %descriptor.value.179
  %descriptor.extent.inside.314 = icmp ule i32 %descriptor.value.175, %stack.sub.313
  %descriptor.payload.inside.315 = icmp ule i32 %descriptor.value.177, %descriptor.value.175
  %descriptor.owner.offset.valid.316 = and i1 %descriptor.owner.inside.311, %descriptor.offset.inside.312
  %descriptor.range.inside.318 = and i1 %descriptor.owner.offset.valid.316, %descriptor.extent.inside.314
  %descriptor.range.valid.317 = and i1 %descriptor.range.inside.318, %descriptor.payload.inside.315
  %descriptor.type.valid.319 = icmp eq i32 1, 1
  %descriptor.valid.320 = and i1 %descriptor.range.valid.317, %descriptor.type.valid.319
  br i1 %descriptor.valid.320, label %descriptor.valid.321, label %descriptor.invalid.322
descriptor.invalid.322:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.321:
  %descriptor.initialized.status.323 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.173, i32 %descriptor.value.175)
  %helper.ok.324 = icmp eq i32 %descriptor.initialized.status.323, 0
  br i1 %helper.ok.324, label %helper.continue.325, label %frame.failure.0
helper.continue.325:
  %local.is.active.326 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.326, label %local.descriptor.active.327, label %local.descriptor.inactive.328
local.descriptor.active.327:
  %local.check.offset.330 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.331 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.332 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.333 = load i32, ptr %local.owner.end.6, align 4
  %context.field.334 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.335 = load i32, ptr %context.field.334, align 4
  %stack.sub.338 = sub i32 %local.check.owner.end.333, %local.check.offset.330
  %descriptor.owner.inside.336 = icmp ule i32 %local.check.owner.end.333, %context.value.335
  %descriptor.offset.inside.337 = icmp ule i32 %local.check.offset.330, %local.check.owner.end.333
  %descriptor.extent.inside.339 = icmp ule i32 %local.check.extent.331, %stack.sub.338
  %descriptor.payload.inside.340 = icmp ule i32 %local.check.payload.332, %local.check.extent.331
  %descriptor.owner.offset.valid.341 = and i1 %descriptor.owner.inside.336, %descriptor.offset.inside.337
  %descriptor.range.inside.343 = and i1 %descriptor.owner.offset.valid.341, %descriptor.extent.inside.339
  %descriptor.range.valid.342 = and i1 %descriptor.range.inside.343, %descriptor.payload.inside.340
  br i1 %descriptor.range.valid.342, label %descriptor.valid.344, label %descriptor.invalid.345
descriptor.invalid.345:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.344:
  %descriptor.initialized.status.346 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.330, i32 %local.check.extent.331)
  %helper.ok.347 = icmp eq i32 %descriptor.initialized.status.346, 0
  br i1 %helper.ok.347, label %helper.continue.348, label %frame.failure.0
helper.continue.348:
  br label %local.descriptor.checked.329
local.descriptor.inactive.328:
  br label %local.descriptor.checked.329
local.descriptor.checked.329:
  %local.is.active.349 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.349, label %local.descriptor.active.350, label %local.descriptor.inactive.351
local.descriptor.active.350:
  %local.check.offset.353 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.354 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.355 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.356 = load i32, ptr %local.owner.end.12, align 4
  %context.field.357 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.358 = load i32, ptr %context.field.357, align 4
  %stack.sub.361 = sub i32 %local.check.owner.end.356, %local.check.offset.353
  %descriptor.owner.inside.359 = icmp ule i32 %local.check.owner.end.356, %context.value.358
  %descriptor.offset.inside.360 = icmp ule i32 %local.check.offset.353, %local.check.owner.end.356
  %descriptor.extent.inside.362 = icmp ule i32 %local.check.extent.354, %stack.sub.361
  %descriptor.payload.inside.363 = icmp ule i32 %local.check.payload.355, %local.check.extent.354
  %descriptor.owner.offset.valid.364 = and i1 %descriptor.owner.inside.359, %descriptor.offset.inside.360
  %descriptor.range.inside.366 = and i1 %descriptor.owner.offset.valid.364, %descriptor.extent.inside.362
  %descriptor.range.valid.365 = and i1 %descriptor.range.inside.366, %descriptor.payload.inside.363
  br i1 %descriptor.range.valid.365, label %descriptor.valid.367, label %descriptor.invalid.368
descriptor.invalid.368:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.367:
  %descriptor.initialized.status.369 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.353, i32 %local.check.extent.354)
  %helper.ok.370 = icmp eq i32 %descriptor.initialized.status.369, 0
  br i1 %helper.ok.370, label %helper.continue.371, label %frame.failure.0
helper.continue.371:
  br label %local.descriptor.checked.352
local.descriptor.inactive.351:
  br label %local.descriptor.checked.352
local.descriptor.checked.352:
  %local.is.active.372 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.372, label %local.descriptor.active.373, label %local.descriptor.inactive.374
local.descriptor.active.373:
  %local.check.offset.376 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.377 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.378 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.379 = load i32, ptr %local.owner.end.18, align 4
  %context.field.380 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.381 = load i32, ptr %context.field.380, align 4
  %stack.sub.384 = sub i32 %local.check.owner.end.379, %local.check.offset.376
  %descriptor.owner.inside.382 = icmp ule i32 %local.check.owner.end.379, %context.value.381
  %descriptor.offset.inside.383 = icmp ule i32 %local.check.offset.376, %local.check.owner.end.379
  %descriptor.extent.inside.385 = icmp ule i32 %local.check.extent.377, %stack.sub.384
  %descriptor.payload.inside.386 = icmp ule i32 %local.check.payload.378, %local.check.extent.377
  %descriptor.owner.offset.valid.387 = and i1 %descriptor.owner.inside.382, %descriptor.offset.inside.383
  %descriptor.range.inside.389 = and i1 %descriptor.owner.offset.valid.387, %descriptor.extent.inside.385
  %descriptor.range.valid.388 = and i1 %descriptor.range.inside.389, %descriptor.payload.inside.386
  br i1 %descriptor.range.valid.388, label %descriptor.valid.390, label %descriptor.invalid.391
descriptor.invalid.391:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.390:
  %descriptor.initialized.status.392 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.376, i32 %local.check.extent.377)
  %helper.ok.393 = icmp eq i32 %descriptor.initialized.status.392, 0
  br i1 %helper.ok.393, label %helper.continue.394, label %frame.failure.0
helper.continue.394:
  br label %local.descriptor.checked.375
local.descriptor.inactive.374:
  br label %local.descriptor.checked.375
local.descriptor.checked.375:
  %local.is.active.395 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.395, label %local.descriptor.active.396, label %local.descriptor.inactive.397
local.descriptor.active.396:
  %local.check.offset.399 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.400 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.401 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.402 = load i32, ptr %local.owner.end.24, align 4
  %context.field.403 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.404 = load i32, ptr %context.field.403, align 4
  %stack.sub.407 = sub i32 %local.check.owner.end.402, %local.check.offset.399
  %descriptor.owner.inside.405 = icmp ule i32 %local.check.owner.end.402, %context.value.404
  %descriptor.offset.inside.406 = icmp ule i32 %local.check.offset.399, %local.check.owner.end.402
  %descriptor.extent.inside.408 = icmp ule i32 %local.check.extent.400, %stack.sub.407
  %descriptor.payload.inside.409 = icmp ule i32 %local.check.payload.401, %local.check.extent.400
  %descriptor.owner.offset.valid.410 = and i1 %descriptor.owner.inside.405, %descriptor.offset.inside.406
  %descriptor.range.inside.412 = and i1 %descriptor.owner.offset.valid.410, %descriptor.extent.inside.408
  %descriptor.range.valid.411 = and i1 %descriptor.range.inside.412, %descriptor.payload.inside.409
  br i1 %descriptor.range.valid.411, label %descriptor.valid.413, label %descriptor.invalid.414
descriptor.invalid.414:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.413:
  %descriptor.initialized.status.415 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.399, i32 %local.check.extent.400)
  %helper.ok.416 = icmp eq i32 %descriptor.initialized.status.415, 0
  br i1 %helper.ok.416, label %helper.continue.417, label %frame.failure.0
helper.continue.417:
  br label %local.descriptor.checked.398
local.descriptor.inactive.397:
  br label %local.descriptor.checked.398
local.descriptor.checked.398:
  %local.is.active.418 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.418, label %local.descriptor.active.419, label %local.descriptor.inactive.420
local.descriptor.active.419:
  %local.check.offset.422 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.423 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.424 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.425 = load i32, ptr %local.owner.end.30, align 4
  %context.field.426 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.427 = load i32, ptr %context.field.426, align 4
  %stack.sub.430 = sub i32 %local.check.owner.end.425, %local.check.offset.422
  %descriptor.owner.inside.428 = icmp ule i32 %local.check.owner.end.425, %context.value.427
  %descriptor.offset.inside.429 = icmp ule i32 %local.check.offset.422, %local.check.owner.end.425
  %descriptor.extent.inside.431 = icmp ule i32 %local.check.extent.423, %stack.sub.430
  %descriptor.payload.inside.432 = icmp ule i32 %local.check.payload.424, %local.check.extent.423
  %descriptor.owner.offset.valid.433 = and i1 %descriptor.owner.inside.428, %descriptor.offset.inside.429
  %descriptor.range.inside.435 = and i1 %descriptor.owner.offset.valid.433, %descriptor.extent.inside.431
  %descriptor.range.valid.434 = and i1 %descriptor.range.inside.435, %descriptor.payload.inside.432
  br i1 %descriptor.range.valid.434, label %descriptor.valid.436, label %descriptor.invalid.437
descriptor.invalid.437:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.436:
  %descriptor.initialized.status.438 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.422, i32 %local.check.extent.423)
  %helper.ok.439 = icmp eq i32 %descriptor.initialized.status.438, 0
  br i1 %helper.ok.439, label %helper.continue.440, label %frame.failure.0
helper.continue.440:
  br label %local.descriptor.checked.421
local.descriptor.inactive.420:
  br label %local.descriptor.checked.421
local.descriptor.checked.421:
  %local.is.active.441 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.441, label %local.descriptor.active.442, label %local.descriptor.inactive.443
local.descriptor.active.442:
  %local.check.offset.445 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.446 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.447 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.448 = load i32, ptr %local.owner.end.36, align 4
  %context.field.449 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.450 = load i32, ptr %context.field.449, align 4
  %stack.sub.453 = sub i32 %local.check.owner.end.448, %local.check.offset.445
  %descriptor.owner.inside.451 = icmp ule i32 %local.check.owner.end.448, %context.value.450
  %descriptor.offset.inside.452 = icmp ule i32 %local.check.offset.445, %local.check.owner.end.448
  %descriptor.extent.inside.454 = icmp ule i32 %local.check.extent.446, %stack.sub.453
  %descriptor.payload.inside.455 = icmp ule i32 %local.check.payload.447, %local.check.extent.446
  %descriptor.owner.offset.valid.456 = and i1 %descriptor.owner.inside.451, %descriptor.offset.inside.452
  %descriptor.range.inside.458 = and i1 %descriptor.owner.offset.valid.456, %descriptor.extent.inside.454
  %descriptor.range.valid.457 = and i1 %descriptor.range.inside.458, %descriptor.payload.inside.455
  br i1 %descriptor.range.valid.457, label %descriptor.valid.459, label %descriptor.invalid.460
descriptor.invalid.460:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.459:
  %descriptor.initialized.status.461 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.445, i32 %local.check.extent.446)
  %helper.ok.462 = icmp eq i32 %descriptor.initialized.status.461, 0
  br i1 %helper.ok.462, label %helper.continue.463, label %frame.failure.0
helper.continue.463:
  br label %local.descriptor.checked.444
local.descriptor.inactive.443:
  br label %local.descriptor.checked.444
local.descriptor.checked.444:
  %step.status.464 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.465 = icmp eq i32 %step.status.464, 0
  br i1 %helper.ok.465, label %helper.continue.466, label %frame.failure.0
helper.continue.466:
  store i1 true, ptr %local.active.8, align 1
  store i32 %descriptor.value.173, ptr %local.offset.9, align 4
  store i32 %descriptor.value.175, ptr %local.extent.10, align 4
  store i32 %descriptor.value.177, ptr %local.payload.11, align 4
  store i32 %descriptor.value.179, ptr %local.owner.end.12, align 4
  store i32 1, ptr %local.type.13, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %descriptor.value.173, i32 20, i32 %descriptor.value.177, i32 %descriptor.value.179, i32 %descriptor.value.175)
  %context.field.467 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.468 = load i32, ptr %context.field.467, align 4
  %runtime.ok.469 = icmp eq i32 %context.value.468, 0
  br i1 %runtime.ok.469, label %runtime.continue.470, label %frame.failure.0
runtime.continue.470:
  %context.field.471 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.472 = load i32, ptr %context.field.471, align 4
  %stack.sub.475 = sub i32 %descriptor.value.59, %descriptor.value.53
  %descriptor.owner.inside.473 = icmp ule i32 %descriptor.value.59, %context.value.472
  %descriptor.offset.inside.474 = icmp ule i32 %descriptor.value.53, %descriptor.value.59
  %descriptor.extent.inside.476 = icmp ule i32 %descriptor.value.55, %stack.sub.475
  %descriptor.payload.inside.477 = icmp ule i32 %descriptor.value.57, %descriptor.value.55
  %descriptor.owner.offset.valid.478 = and i1 %descriptor.owner.inside.473, %descriptor.offset.inside.474
  %descriptor.range.inside.480 = and i1 %descriptor.owner.offset.valid.478, %descriptor.extent.inside.476
  %descriptor.range.valid.479 = and i1 %descriptor.range.inside.480, %descriptor.payload.inside.477
  %descriptor.type.valid.481 = icmp eq i32 1, 1
  %descriptor.valid.482 = and i1 %descriptor.range.valid.479, %descriptor.type.valid.481
  br i1 %descriptor.valid.482, label %descriptor.valid.483, label %descriptor.invalid.484
descriptor.invalid.484:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.483:
  %descriptor.initialized.status.485 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.53, i32 %descriptor.value.55)
  %helper.ok.486 = icmp eq i32 %descriptor.initialized.status.485, 0
  br i1 %helper.ok.486, label %helper.continue.487, label %frame.failure.0
helper.continue.487:
  %context.field.488 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.489 = load i32, ptr %context.field.488, align 4
  %stack.sub.492 = sub i32 %descriptor.value.89, %descriptor.value.83
  %descriptor.owner.inside.490 = icmp ule i32 %descriptor.value.89, %context.value.489
  %descriptor.offset.inside.491 = icmp ule i32 %descriptor.value.83, %descriptor.value.89
  %descriptor.extent.inside.493 = icmp ule i32 %descriptor.value.85, %stack.sub.492
  %descriptor.payload.inside.494 = icmp ule i32 %descriptor.value.87, %descriptor.value.85
  %descriptor.owner.offset.valid.495 = and i1 %descriptor.owner.inside.490, %descriptor.offset.inside.491
  %descriptor.range.inside.497 = and i1 %descriptor.owner.offset.valid.495, %descriptor.extent.inside.493
  %descriptor.range.valid.496 = and i1 %descriptor.range.inside.497, %descriptor.payload.inside.494
  %descriptor.type.valid.498 = icmp eq i32 1, 1
  %descriptor.valid.499 = and i1 %descriptor.range.valid.496, %descriptor.type.valid.498
  br i1 %descriptor.valid.499, label %descriptor.valid.500, label %descriptor.invalid.501
descriptor.invalid.501:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.500:
  %descriptor.initialized.status.502 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.83, i32 %descriptor.value.85)
  %helper.ok.503 = icmp eq i32 %descriptor.initialized.status.502, 0
  br i1 %helper.ok.503, label %helper.continue.504, label %frame.failure.0
helper.continue.504:
  %context.field.505 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.506 = load i32, ptr %context.field.505, align 4
  %stack.sub.509 = sub i32 %descriptor.value.119, %descriptor.value.113
  %descriptor.owner.inside.507 = icmp ule i32 %descriptor.value.119, %context.value.506
  %descriptor.offset.inside.508 = icmp ule i32 %descriptor.value.113, %descriptor.value.119
  %descriptor.extent.inside.510 = icmp ule i32 %descriptor.value.115, %stack.sub.509
  %descriptor.payload.inside.511 = icmp ule i32 %descriptor.value.117, %descriptor.value.115
  %descriptor.owner.offset.valid.512 = and i1 %descriptor.owner.inside.507, %descriptor.offset.inside.508
  %descriptor.range.inside.514 = and i1 %descriptor.owner.offset.valid.512, %descriptor.extent.inside.510
  %descriptor.range.valid.513 = and i1 %descriptor.range.inside.514, %descriptor.payload.inside.511
  %descriptor.type.valid.515 = icmp eq i32 1, 1
  %descriptor.valid.516 = and i1 %descriptor.range.valid.513, %descriptor.type.valid.515
  br i1 %descriptor.valid.516, label %descriptor.valid.517, label %descriptor.invalid.518
descriptor.invalid.518:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.517:
  %descriptor.initialized.status.519 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.113, i32 %descriptor.value.115)
  %helper.ok.520 = icmp eq i32 %descriptor.initialized.status.519, 0
  br i1 %helper.ok.520, label %helper.continue.521, label %frame.failure.0
helper.continue.521:
  %context.field.522 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.523 = load i32, ptr %context.field.522, align 4
  %stack.sub.526 = sub i32 %descriptor.value.149, %descriptor.value.143
  %descriptor.owner.inside.524 = icmp ule i32 %descriptor.value.149, %context.value.523
  %descriptor.offset.inside.525 = icmp ule i32 %descriptor.value.143, %descriptor.value.149
  %descriptor.extent.inside.527 = icmp ule i32 %descriptor.value.145, %stack.sub.526
  %descriptor.payload.inside.528 = icmp ule i32 %descriptor.value.147, %descriptor.value.145
  %descriptor.owner.offset.valid.529 = and i1 %descriptor.owner.inside.524, %descriptor.offset.inside.525
  %descriptor.range.inside.531 = and i1 %descriptor.owner.offset.valid.529, %descriptor.extent.inside.527
  %descriptor.range.valid.530 = and i1 %descriptor.range.inside.531, %descriptor.payload.inside.528
  %descriptor.type.valid.532 = icmp eq i32 1, 1
  %descriptor.valid.533 = and i1 %descriptor.range.valid.530, %descriptor.type.valid.532
  br i1 %descriptor.valid.533, label %descriptor.valid.534, label %descriptor.invalid.535
descriptor.invalid.535:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.534:
  %descriptor.initialized.status.536 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.143, i32 %descriptor.value.145)
  %helper.ok.537 = icmp eq i32 %descriptor.initialized.status.536, 0
  br i1 %helper.ok.537, label %helper.continue.538, label %frame.failure.0
helper.continue.538:
  %local.is.active.539 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.539, label %local.descriptor.active.540, label %local.descriptor.inactive.541
local.descriptor.active.540:
  %local.check.offset.543 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.544 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.545 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.546 = load i32, ptr %local.owner.end.6, align 4
  %context.field.547 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.548 = load i32, ptr %context.field.547, align 4
  %stack.sub.551 = sub i32 %local.check.owner.end.546, %local.check.offset.543
  %descriptor.owner.inside.549 = icmp ule i32 %local.check.owner.end.546, %context.value.548
  %descriptor.offset.inside.550 = icmp ule i32 %local.check.offset.543, %local.check.owner.end.546
  %descriptor.extent.inside.552 = icmp ule i32 %local.check.extent.544, %stack.sub.551
  %descriptor.payload.inside.553 = icmp ule i32 %local.check.payload.545, %local.check.extent.544
  %descriptor.owner.offset.valid.554 = and i1 %descriptor.owner.inside.549, %descriptor.offset.inside.550
  %descriptor.range.inside.556 = and i1 %descriptor.owner.offset.valid.554, %descriptor.extent.inside.552
  %descriptor.range.valid.555 = and i1 %descriptor.range.inside.556, %descriptor.payload.inside.553
  br i1 %descriptor.range.valid.555, label %descriptor.valid.557, label %descriptor.invalid.558
descriptor.invalid.558:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.557:
  %descriptor.initialized.status.559 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.543, i32 %local.check.extent.544)
  %helper.ok.560 = icmp eq i32 %descriptor.initialized.status.559, 0
  br i1 %helper.ok.560, label %helper.continue.561, label %frame.failure.0
helper.continue.561:
  br label %local.descriptor.checked.542
local.descriptor.inactive.541:
  br label %local.descriptor.checked.542
local.descriptor.checked.542:
  %local.is.active.562 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.562, label %local.descriptor.active.563, label %local.descriptor.inactive.564
local.descriptor.active.563:
  %local.check.offset.566 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.567 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.568 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.569 = load i32, ptr %local.owner.end.12, align 4
  %context.field.570 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.571 = load i32, ptr %context.field.570, align 4
  %stack.sub.574 = sub i32 %local.check.owner.end.569, %local.check.offset.566
  %descriptor.owner.inside.572 = icmp ule i32 %local.check.owner.end.569, %context.value.571
  %descriptor.offset.inside.573 = icmp ule i32 %local.check.offset.566, %local.check.owner.end.569
  %descriptor.extent.inside.575 = icmp ule i32 %local.check.extent.567, %stack.sub.574
  %descriptor.payload.inside.576 = icmp ule i32 %local.check.payload.568, %local.check.extent.567
  %descriptor.owner.offset.valid.577 = and i1 %descriptor.owner.inside.572, %descriptor.offset.inside.573
  %descriptor.range.inside.579 = and i1 %descriptor.owner.offset.valid.577, %descriptor.extent.inside.575
  %descriptor.range.valid.578 = and i1 %descriptor.range.inside.579, %descriptor.payload.inside.576
  br i1 %descriptor.range.valid.578, label %descriptor.valid.580, label %descriptor.invalid.581
descriptor.invalid.581:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.580:
  %descriptor.initialized.status.582 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.566, i32 %local.check.extent.567)
  %helper.ok.583 = icmp eq i32 %descriptor.initialized.status.582, 0
  br i1 %helper.ok.583, label %helper.continue.584, label %frame.failure.0
helper.continue.584:
  br label %local.descriptor.checked.565
local.descriptor.inactive.564:
  br label %local.descriptor.checked.565
local.descriptor.checked.565:
  %local.is.active.585 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.585, label %local.descriptor.active.586, label %local.descriptor.inactive.587
local.descriptor.active.586:
  %local.check.offset.589 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.590 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.591 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.592 = load i32, ptr %local.owner.end.18, align 4
  %context.field.593 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.594 = load i32, ptr %context.field.593, align 4
  %stack.sub.597 = sub i32 %local.check.owner.end.592, %local.check.offset.589
  %descriptor.owner.inside.595 = icmp ule i32 %local.check.owner.end.592, %context.value.594
  %descriptor.offset.inside.596 = icmp ule i32 %local.check.offset.589, %local.check.owner.end.592
  %descriptor.extent.inside.598 = icmp ule i32 %local.check.extent.590, %stack.sub.597
  %descriptor.payload.inside.599 = icmp ule i32 %local.check.payload.591, %local.check.extent.590
  %descriptor.owner.offset.valid.600 = and i1 %descriptor.owner.inside.595, %descriptor.offset.inside.596
  %descriptor.range.inside.602 = and i1 %descriptor.owner.offset.valid.600, %descriptor.extent.inside.598
  %descriptor.range.valid.601 = and i1 %descriptor.range.inside.602, %descriptor.payload.inside.599
  br i1 %descriptor.range.valid.601, label %descriptor.valid.603, label %descriptor.invalid.604
descriptor.invalid.604:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.603:
  %descriptor.initialized.status.605 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.589, i32 %local.check.extent.590)
  %helper.ok.606 = icmp eq i32 %descriptor.initialized.status.605, 0
  br i1 %helper.ok.606, label %helper.continue.607, label %frame.failure.0
helper.continue.607:
  br label %local.descriptor.checked.588
local.descriptor.inactive.587:
  br label %local.descriptor.checked.588
local.descriptor.checked.588:
  %local.is.active.608 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.608, label %local.descriptor.active.609, label %local.descriptor.inactive.610
local.descriptor.active.609:
  %local.check.offset.612 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.613 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.614 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.615 = load i32, ptr %local.owner.end.24, align 4
  %context.field.616 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.617 = load i32, ptr %context.field.616, align 4
  %stack.sub.620 = sub i32 %local.check.owner.end.615, %local.check.offset.612
  %descriptor.owner.inside.618 = icmp ule i32 %local.check.owner.end.615, %context.value.617
  %descriptor.offset.inside.619 = icmp ule i32 %local.check.offset.612, %local.check.owner.end.615
  %descriptor.extent.inside.621 = icmp ule i32 %local.check.extent.613, %stack.sub.620
  %descriptor.payload.inside.622 = icmp ule i32 %local.check.payload.614, %local.check.extent.613
  %descriptor.owner.offset.valid.623 = and i1 %descriptor.owner.inside.618, %descriptor.offset.inside.619
  %descriptor.range.inside.625 = and i1 %descriptor.owner.offset.valid.623, %descriptor.extent.inside.621
  %descriptor.range.valid.624 = and i1 %descriptor.range.inside.625, %descriptor.payload.inside.622
  br i1 %descriptor.range.valid.624, label %descriptor.valid.626, label %descriptor.invalid.627
descriptor.invalid.627:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.626:
  %descriptor.initialized.status.628 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.612, i32 %local.check.extent.613)
  %helper.ok.629 = icmp eq i32 %descriptor.initialized.status.628, 0
  br i1 %helper.ok.629, label %helper.continue.630, label %frame.failure.0
helper.continue.630:
  br label %local.descriptor.checked.611
local.descriptor.inactive.610:
  br label %local.descriptor.checked.611
local.descriptor.checked.611:
  %local.is.active.631 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.631, label %local.descriptor.active.632, label %local.descriptor.inactive.633
local.descriptor.active.632:
  %local.check.offset.635 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.636 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.637 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.638 = load i32, ptr %local.owner.end.30, align 4
  %context.field.639 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.640 = load i32, ptr %context.field.639, align 4
  %stack.sub.643 = sub i32 %local.check.owner.end.638, %local.check.offset.635
  %descriptor.owner.inside.641 = icmp ule i32 %local.check.owner.end.638, %context.value.640
  %descriptor.offset.inside.642 = icmp ule i32 %local.check.offset.635, %local.check.owner.end.638
  %descriptor.extent.inside.644 = icmp ule i32 %local.check.extent.636, %stack.sub.643
  %descriptor.payload.inside.645 = icmp ule i32 %local.check.payload.637, %local.check.extent.636
  %descriptor.owner.offset.valid.646 = and i1 %descriptor.owner.inside.641, %descriptor.offset.inside.642
  %descriptor.range.inside.648 = and i1 %descriptor.owner.offset.valid.646, %descriptor.extent.inside.644
  %descriptor.range.valid.647 = and i1 %descriptor.range.inside.648, %descriptor.payload.inside.645
  br i1 %descriptor.range.valid.647, label %descriptor.valid.649, label %descriptor.invalid.650
descriptor.invalid.650:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.649:
  %descriptor.initialized.status.651 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.635, i32 %local.check.extent.636)
  %helper.ok.652 = icmp eq i32 %descriptor.initialized.status.651, 0
  br i1 %helper.ok.652, label %helper.continue.653, label %frame.failure.0
helper.continue.653:
  br label %local.descriptor.checked.634
local.descriptor.inactive.633:
  br label %local.descriptor.checked.634
local.descriptor.checked.634:
  %local.is.active.654 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.654, label %local.descriptor.active.655, label %local.descriptor.inactive.656
local.descriptor.active.655:
  %local.check.offset.658 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.659 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.660 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.661 = load i32, ptr %local.owner.end.36, align 4
  %context.field.662 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.663 = load i32, ptr %context.field.662, align 4
  %stack.sub.666 = sub i32 %local.check.owner.end.661, %local.check.offset.658
  %descriptor.owner.inside.664 = icmp ule i32 %local.check.owner.end.661, %context.value.663
  %descriptor.offset.inside.665 = icmp ule i32 %local.check.offset.658, %local.check.owner.end.661
  %descriptor.extent.inside.667 = icmp ule i32 %local.check.extent.659, %stack.sub.666
  %descriptor.payload.inside.668 = icmp ule i32 %local.check.payload.660, %local.check.extent.659
  %descriptor.owner.offset.valid.669 = and i1 %descriptor.owner.inside.664, %descriptor.offset.inside.665
  %descriptor.range.inside.671 = and i1 %descriptor.owner.offset.valid.669, %descriptor.extent.inside.667
  %descriptor.range.valid.670 = and i1 %descriptor.range.inside.671, %descriptor.payload.inside.668
  br i1 %descriptor.range.valid.670, label %descriptor.valid.672, label %descriptor.invalid.673
descriptor.invalid.673:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.672:
  %descriptor.initialized.status.674 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.658, i32 %local.check.extent.659)
  %helper.ok.675 = icmp eq i32 %descriptor.initialized.status.674, 0
  br i1 %helper.ok.675, label %helper.continue.676, label %frame.failure.0
helper.continue.676:
  br label %local.descriptor.checked.657
local.descriptor.inactive.656:
  br label %local.descriptor.checked.657
local.descriptor.checked.657:
  %step.status.677 = call i32 @al_owning_charge_step(ptr %ctx, i32 4)
  %helper.ok.678 = icmp eq i32 %step.status.677, 0
  br i1 %helper.ok.678, label %helper.continue.679, label %frame.failure.0
helper.continue.679:
  store i1 true, ptr %local.active.14, align 1
  store i32 %descriptor.value.143, ptr %local.offset.15, align 4
  store i32 %descriptor.value.145, ptr %local.extent.16, align 4
  store i32 %descriptor.value.147, ptr %local.payload.17, align 4
  store i32 %descriptor.value.149, ptr %local.owner.end.18, align 4
  store i32 1, ptr %local.type.19, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %descriptor.value.143, i32 20, i32 %descriptor.value.147, i32 %descriptor.value.149, i32 %descriptor.value.145)
  %context.field.680 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.681 = load i32, ptr %context.field.680, align 4
  %runtime.ok.682 = icmp eq i32 %context.value.681, 0
  br i1 %runtime.ok.682, label %runtime.continue.683, label %frame.failure.0
runtime.continue.683:
  %context.field.684 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.685 = load i32, ptr %context.field.684, align 4
  %stack.sub.688 = sub i32 %descriptor.value.59, %descriptor.value.53
  %descriptor.owner.inside.686 = icmp ule i32 %descriptor.value.59, %context.value.685
  %descriptor.offset.inside.687 = icmp ule i32 %descriptor.value.53, %descriptor.value.59
  %descriptor.extent.inside.689 = icmp ule i32 %descriptor.value.55, %stack.sub.688
  %descriptor.payload.inside.690 = icmp ule i32 %descriptor.value.57, %descriptor.value.55
  %descriptor.owner.offset.valid.691 = and i1 %descriptor.owner.inside.686, %descriptor.offset.inside.687
  %descriptor.range.inside.693 = and i1 %descriptor.owner.offset.valid.691, %descriptor.extent.inside.689
  %descriptor.range.valid.692 = and i1 %descriptor.range.inside.693, %descriptor.payload.inside.690
  %descriptor.type.valid.694 = icmp eq i32 1, 1
  %descriptor.valid.695 = and i1 %descriptor.range.valid.692, %descriptor.type.valid.694
  br i1 %descriptor.valid.695, label %descriptor.valid.696, label %descriptor.invalid.697
descriptor.invalid.697:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.696:
  %descriptor.initialized.status.698 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.53, i32 %descriptor.value.55)
  %helper.ok.699 = icmp eq i32 %descriptor.initialized.status.698, 0
  br i1 %helper.ok.699, label %helper.continue.700, label %frame.failure.0
helper.continue.700:
  %context.field.701 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.702 = load i32, ptr %context.field.701, align 4
  %stack.sub.705 = sub i32 %descriptor.value.89, %descriptor.value.83
  %descriptor.owner.inside.703 = icmp ule i32 %descriptor.value.89, %context.value.702
  %descriptor.offset.inside.704 = icmp ule i32 %descriptor.value.83, %descriptor.value.89
  %descriptor.extent.inside.706 = icmp ule i32 %descriptor.value.85, %stack.sub.705
  %descriptor.payload.inside.707 = icmp ule i32 %descriptor.value.87, %descriptor.value.85
  %descriptor.owner.offset.valid.708 = and i1 %descriptor.owner.inside.703, %descriptor.offset.inside.704
  %descriptor.range.inside.710 = and i1 %descriptor.owner.offset.valid.708, %descriptor.extent.inside.706
  %descriptor.range.valid.709 = and i1 %descriptor.range.inside.710, %descriptor.payload.inside.707
  %descriptor.type.valid.711 = icmp eq i32 1, 1
  %descriptor.valid.712 = and i1 %descriptor.range.valid.709, %descriptor.type.valid.711
  br i1 %descriptor.valid.712, label %descriptor.valid.713, label %descriptor.invalid.714
descriptor.invalid.714:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.713:
  %descriptor.initialized.status.715 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.83, i32 %descriptor.value.85)
  %helper.ok.716 = icmp eq i32 %descriptor.initialized.status.715, 0
  br i1 %helper.ok.716, label %helper.continue.717, label %frame.failure.0
helper.continue.717:
  %context.field.718 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.719 = load i32, ptr %context.field.718, align 4
  %stack.sub.722 = sub i32 %descriptor.value.119, %descriptor.value.113
  %descriptor.owner.inside.720 = icmp ule i32 %descriptor.value.119, %context.value.719
  %descriptor.offset.inside.721 = icmp ule i32 %descriptor.value.113, %descriptor.value.119
  %descriptor.extent.inside.723 = icmp ule i32 %descriptor.value.115, %stack.sub.722
  %descriptor.payload.inside.724 = icmp ule i32 %descriptor.value.117, %descriptor.value.115
  %descriptor.owner.offset.valid.725 = and i1 %descriptor.owner.inside.720, %descriptor.offset.inside.721
  %descriptor.range.inside.727 = and i1 %descriptor.owner.offset.valid.725, %descriptor.extent.inside.723
  %descriptor.range.valid.726 = and i1 %descriptor.range.inside.727, %descriptor.payload.inside.724
  %descriptor.type.valid.728 = icmp eq i32 1, 1
  %descriptor.valid.729 = and i1 %descriptor.range.valid.726, %descriptor.type.valid.728
  br i1 %descriptor.valid.729, label %descriptor.valid.730, label %descriptor.invalid.731
descriptor.invalid.731:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.730:
  %descriptor.initialized.status.732 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.113, i32 %descriptor.value.115)
  %helper.ok.733 = icmp eq i32 %descriptor.initialized.status.732, 0
  br i1 %helper.ok.733, label %helper.continue.734, label %frame.failure.0
helper.continue.734:
  %local.is.active.735 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.735, label %local.descriptor.active.736, label %local.descriptor.inactive.737
local.descriptor.active.736:
  %local.check.offset.739 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.740 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.741 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.742 = load i32, ptr %local.owner.end.6, align 4
  %context.field.743 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.744 = load i32, ptr %context.field.743, align 4
  %stack.sub.747 = sub i32 %local.check.owner.end.742, %local.check.offset.739
  %descriptor.owner.inside.745 = icmp ule i32 %local.check.owner.end.742, %context.value.744
  %descriptor.offset.inside.746 = icmp ule i32 %local.check.offset.739, %local.check.owner.end.742
  %descriptor.extent.inside.748 = icmp ule i32 %local.check.extent.740, %stack.sub.747
  %descriptor.payload.inside.749 = icmp ule i32 %local.check.payload.741, %local.check.extent.740
  %descriptor.owner.offset.valid.750 = and i1 %descriptor.owner.inside.745, %descriptor.offset.inside.746
  %descriptor.range.inside.752 = and i1 %descriptor.owner.offset.valid.750, %descriptor.extent.inside.748
  %descriptor.range.valid.751 = and i1 %descriptor.range.inside.752, %descriptor.payload.inside.749
  br i1 %descriptor.range.valid.751, label %descriptor.valid.753, label %descriptor.invalid.754
descriptor.invalid.754:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.753:
  %descriptor.initialized.status.755 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.739, i32 %local.check.extent.740)
  %helper.ok.756 = icmp eq i32 %descriptor.initialized.status.755, 0
  br i1 %helper.ok.756, label %helper.continue.757, label %frame.failure.0
helper.continue.757:
  br label %local.descriptor.checked.738
local.descriptor.inactive.737:
  br label %local.descriptor.checked.738
local.descriptor.checked.738:
  %local.is.active.758 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.758, label %local.descriptor.active.759, label %local.descriptor.inactive.760
local.descriptor.active.759:
  %local.check.offset.762 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.763 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.764 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.765 = load i32, ptr %local.owner.end.12, align 4
  %context.field.766 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.767 = load i32, ptr %context.field.766, align 4
  %stack.sub.770 = sub i32 %local.check.owner.end.765, %local.check.offset.762
  %descriptor.owner.inside.768 = icmp ule i32 %local.check.owner.end.765, %context.value.767
  %descriptor.offset.inside.769 = icmp ule i32 %local.check.offset.762, %local.check.owner.end.765
  %descriptor.extent.inside.771 = icmp ule i32 %local.check.extent.763, %stack.sub.770
  %descriptor.payload.inside.772 = icmp ule i32 %local.check.payload.764, %local.check.extent.763
  %descriptor.owner.offset.valid.773 = and i1 %descriptor.owner.inside.768, %descriptor.offset.inside.769
  %descriptor.range.inside.775 = and i1 %descriptor.owner.offset.valid.773, %descriptor.extent.inside.771
  %descriptor.range.valid.774 = and i1 %descriptor.range.inside.775, %descriptor.payload.inside.772
  br i1 %descriptor.range.valid.774, label %descriptor.valid.776, label %descriptor.invalid.777
descriptor.invalid.777:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.776:
  %descriptor.initialized.status.778 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.762, i32 %local.check.extent.763)
  %helper.ok.779 = icmp eq i32 %descriptor.initialized.status.778, 0
  br i1 %helper.ok.779, label %helper.continue.780, label %frame.failure.0
helper.continue.780:
  br label %local.descriptor.checked.761
local.descriptor.inactive.760:
  br label %local.descriptor.checked.761
local.descriptor.checked.761:
  %local.is.active.781 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.781, label %local.descriptor.active.782, label %local.descriptor.inactive.783
local.descriptor.active.782:
  %local.check.offset.785 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.786 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.787 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.788 = load i32, ptr %local.owner.end.18, align 4
  %context.field.789 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.790 = load i32, ptr %context.field.789, align 4
  %stack.sub.793 = sub i32 %local.check.owner.end.788, %local.check.offset.785
  %descriptor.owner.inside.791 = icmp ule i32 %local.check.owner.end.788, %context.value.790
  %descriptor.offset.inside.792 = icmp ule i32 %local.check.offset.785, %local.check.owner.end.788
  %descriptor.extent.inside.794 = icmp ule i32 %local.check.extent.786, %stack.sub.793
  %descriptor.payload.inside.795 = icmp ule i32 %local.check.payload.787, %local.check.extent.786
  %descriptor.owner.offset.valid.796 = and i1 %descriptor.owner.inside.791, %descriptor.offset.inside.792
  %descriptor.range.inside.798 = and i1 %descriptor.owner.offset.valid.796, %descriptor.extent.inside.794
  %descriptor.range.valid.797 = and i1 %descriptor.range.inside.798, %descriptor.payload.inside.795
  br i1 %descriptor.range.valid.797, label %descriptor.valid.799, label %descriptor.invalid.800
descriptor.invalid.800:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.799:
  %descriptor.initialized.status.801 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.785, i32 %local.check.extent.786)
  %helper.ok.802 = icmp eq i32 %descriptor.initialized.status.801, 0
  br i1 %helper.ok.802, label %helper.continue.803, label %frame.failure.0
helper.continue.803:
  br label %local.descriptor.checked.784
local.descriptor.inactive.783:
  br label %local.descriptor.checked.784
local.descriptor.checked.784:
  %local.is.active.804 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.804, label %local.descriptor.active.805, label %local.descriptor.inactive.806
local.descriptor.active.805:
  %local.check.offset.808 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.809 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.810 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.811 = load i32, ptr %local.owner.end.24, align 4
  %context.field.812 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.813 = load i32, ptr %context.field.812, align 4
  %stack.sub.816 = sub i32 %local.check.owner.end.811, %local.check.offset.808
  %descriptor.owner.inside.814 = icmp ule i32 %local.check.owner.end.811, %context.value.813
  %descriptor.offset.inside.815 = icmp ule i32 %local.check.offset.808, %local.check.owner.end.811
  %descriptor.extent.inside.817 = icmp ule i32 %local.check.extent.809, %stack.sub.816
  %descriptor.payload.inside.818 = icmp ule i32 %local.check.payload.810, %local.check.extent.809
  %descriptor.owner.offset.valid.819 = and i1 %descriptor.owner.inside.814, %descriptor.offset.inside.815
  %descriptor.range.inside.821 = and i1 %descriptor.owner.offset.valid.819, %descriptor.extent.inside.817
  %descriptor.range.valid.820 = and i1 %descriptor.range.inside.821, %descriptor.payload.inside.818
  br i1 %descriptor.range.valid.820, label %descriptor.valid.822, label %descriptor.invalid.823
descriptor.invalid.823:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.822:
  %descriptor.initialized.status.824 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.808, i32 %local.check.extent.809)
  %helper.ok.825 = icmp eq i32 %descriptor.initialized.status.824, 0
  br i1 %helper.ok.825, label %helper.continue.826, label %frame.failure.0
helper.continue.826:
  br label %local.descriptor.checked.807
local.descriptor.inactive.806:
  br label %local.descriptor.checked.807
local.descriptor.checked.807:
  %local.is.active.827 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.827, label %local.descriptor.active.828, label %local.descriptor.inactive.829
local.descriptor.active.828:
  %local.check.offset.831 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.832 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.833 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.834 = load i32, ptr %local.owner.end.30, align 4
  %context.field.835 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.836 = load i32, ptr %context.field.835, align 4
  %stack.sub.839 = sub i32 %local.check.owner.end.834, %local.check.offset.831
  %descriptor.owner.inside.837 = icmp ule i32 %local.check.owner.end.834, %context.value.836
  %descriptor.offset.inside.838 = icmp ule i32 %local.check.offset.831, %local.check.owner.end.834
  %descriptor.extent.inside.840 = icmp ule i32 %local.check.extent.832, %stack.sub.839
  %descriptor.payload.inside.841 = icmp ule i32 %local.check.payload.833, %local.check.extent.832
  %descriptor.owner.offset.valid.842 = and i1 %descriptor.owner.inside.837, %descriptor.offset.inside.838
  %descriptor.range.inside.844 = and i1 %descriptor.owner.offset.valid.842, %descriptor.extent.inside.840
  %descriptor.range.valid.843 = and i1 %descriptor.range.inside.844, %descriptor.payload.inside.841
  br i1 %descriptor.range.valid.843, label %descriptor.valid.845, label %descriptor.invalid.846
descriptor.invalid.846:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.845:
  %descriptor.initialized.status.847 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.831, i32 %local.check.extent.832)
  %helper.ok.848 = icmp eq i32 %descriptor.initialized.status.847, 0
  br i1 %helper.ok.848, label %helper.continue.849, label %frame.failure.0
helper.continue.849:
  br label %local.descriptor.checked.830
local.descriptor.inactive.829:
  br label %local.descriptor.checked.830
local.descriptor.checked.830:
  %local.is.active.850 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.850, label %local.descriptor.active.851, label %local.descriptor.inactive.852
local.descriptor.active.851:
  %local.check.offset.854 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.855 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.856 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.857 = load i32, ptr %local.owner.end.36, align 4
  %context.field.858 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.859 = load i32, ptr %context.field.858, align 4
  %stack.sub.862 = sub i32 %local.check.owner.end.857, %local.check.offset.854
  %descriptor.owner.inside.860 = icmp ule i32 %local.check.owner.end.857, %context.value.859
  %descriptor.offset.inside.861 = icmp ule i32 %local.check.offset.854, %local.check.owner.end.857
  %descriptor.extent.inside.863 = icmp ule i32 %local.check.extent.855, %stack.sub.862
  %descriptor.payload.inside.864 = icmp ule i32 %local.check.payload.856, %local.check.extent.855
  %descriptor.owner.offset.valid.865 = and i1 %descriptor.owner.inside.860, %descriptor.offset.inside.861
  %descriptor.range.inside.867 = and i1 %descriptor.owner.offset.valid.865, %descriptor.extent.inside.863
  %descriptor.range.valid.866 = and i1 %descriptor.range.inside.867, %descriptor.payload.inside.864
  br i1 %descriptor.range.valid.866, label %descriptor.valid.868, label %descriptor.invalid.869
descriptor.invalid.869:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.868:
  %descriptor.initialized.status.870 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.854, i32 %local.check.extent.855)
  %helper.ok.871 = icmp eq i32 %descriptor.initialized.status.870, 0
  br i1 %helper.ok.871, label %helper.continue.872, label %frame.failure.0
helper.continue.872:
  br label %local.descriptor.checked.853
local.descriptor.inactive.852:
  br label %local.descriptor.checked.853
local.descriptor.checked.853:
  %step.status.873 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.874 = icmp eq i32 %step.status.873, 0
  br i1 %helper.ok.874, label %helper.continue.875, label %frame.failure.0
helper.continue.875:
  store i1 true, ptr %local.active.20, align 1
  store i32 %descriptor.value.113, ptr %local.offset.21, align 4
  store i32 %descriptor.value.115, ptr %local.extent.22, align 4
  store i32 %descriptor.value.117, ptr %local.payload.23, align 4
  store i32 %descriptor.value.119, ptr %local.owner.end.24, align 4
  store i32 1, ptr %local.type.25, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %descriptor.value.113, i32 20, i32 %descriptor.value.117, i32 %descriptor.value.119, i32 %descriptor.value.115)
  %context.field.876 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.877 = load i32, ptr %context.field.876, align 4
  %runtime.ok.878 = icmp eq i32 %context.value.877, 0
  br i1 %runtime.ok.878, label %runtime.continue.879, label %frame.failure.0
runtime.continue.879:
  %context.field.880 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.881 = load i32, ptr %context.field.880, align 4
  %stack.sub.884 = sub i32 %descriptor.value.59, %descriptor.value.53
  %descriptor.owner.inside.882 = icmp ule i32 %descriptor.value.59, %context.value.881
  %descriptor.offset.inside.883 = icmp ule i32 %descriptor.value.53, %descriptor.value.59
  %descriptor.extent.inside.885 = icmp ule i32 %descriptor.value.55, %stack.sub.884
  %descriptor.payload.inside.886 = icmp ule i32 %descriptor.value.57, %descriptor.value.55
  %descriptor.owner.offset.valid.887 = and i1 %descriptor.owner.inside.882, %descriptor.offset.inside.883
  %descriptor.range.inside.889 = and i1 %descriptor.owner.offset.valid.887, %descriptor.extent.inside.885
  %descriptor.range.valid.888 = and i1 %descriptor.range.inside.889, %descriptor.payload.inside.886
  %descriptor.type.valid.890 = icmp eq i32 1, 1
  %descriptor.valid.891 = and i1 %descriptor.range.valid.888, %descriptor.type.valid.890
  br i1 %descriptor.valid.891, label %descriptor.valid.892, label %descriptor.invalid.893
descriptor.invalid.893:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.892:
  %descriptor.initialized.status.894 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.53, i32 %descriptor.value.55)
  %helper.ok.895 = icmp eq i32 %descriptor.initialized.status.894, 0
  br i1 %helper.ok.895, label %helper.continue.896, label %frame.failure.0
helper.continue.896:
  %context.field.897 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.898 = load i32, ptr %context.field.897, align 4
  %stack.sub.901 = sub i32 %descriptor.value.89, %descriptor.value.83
  %descriptor.owner.inside.899 = icmp ule i32 %descriptor.value.89, %context.value.898
  %descriptor.offset.inside.900 = icmp ule i32 %descriptor.value.83, %descriptor.value.89
  %descriptor.extent.inside.902 = icmp ule i32 %descriptor.value.85, %stack.sub.901
  %descriptor.payload.inside.903 = icmp ule i32 %descriptor.value.87, %descriptor.value.85
  %descriptor.owner.offset.valid.904 = and i1 %descriptor.owner.inside.899, %descriptor.offset.inside.900
  %descriptor.range.inside.906 = and i1 %descriptor.owner.offset.valid.904, %descriptor.extent.inside.902
  %descriptor.range.valid.905 = and i1 %descriptor.range.inside.906, %descriptor.payload.inside.903
  %descriptor.type.valid.907 = icmp eq i32 1, 1
  %descriptor.valid.908 = and i1 %descriptor.range.valid.905, %descriptor.type.valid.907
  br i1 %descriptor.valid.908, label %descriptor.valid.909, label %descriptor.invalid.910
descriptor.invalid.910:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.909:
  %descriptor.initialized.status.911 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.83, i32 %descriptor.value.85)
  %helper.ok.912 = icmp eq i32 %descriptor.initialized.status.911, 0
  br i1 %helper.ok.912, label %helper.continue.913, label %frame.failure.0
helper.continue.913:
  %local.is.active.914 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.914, label %local.descriptor.active.915, label %local.descriptor.inactive.916
local.descriptor.active.915:
  %local.check.offset.918 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.919 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.920 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.921 = load i32, ptr %local.owner.end.6, align 4
  %context.field.922 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.923 = load i32, ptr %context.field.922, align 4
  %stack.sub.926 = sub i32 %local.check.owner.end.921, %local.check.offset.918
  %descriptor.owner.inside.924 = icmp ule i32 %local.check.owner.end.921, %context.value.923
  %descriptor.offset.inside.925 = icmp ule i32 %local.check.offset.918, %local.check.owner.end.921
  %descriptor.extent.inside.927 = icmp ule i32 %local.check.extent.919, %stack.sub.926
  %descriptor.payload.inside.928 = icmp ule i32 %local.check.payload.920, %local.check.extent.919
  %descriptor.owner.offset.valid.929 = and i1 %descriptor.owner.inside.924, %descriptor.offset.inside.925
  %descriptor.range.inside.931 = and i1 %descriptor.owner.offset.valid.929, %descriptor.extent.inside.927
  %descriptor.range.valid.930 = and i1 %descriptor.range.inside.931, %descriptor.payload.inside.928
  br i1 %descriptor.range.valid.930, label %descriptor.valid.932, label %descriptor.invalid.933
descriptor.invalid.933:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.932:
  %descriptor.initialized.status.934 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.918, i32 %local.check.extent.919)
  %helper.ok.935 = icmp eq i32 %descriptor.initialized.status.934, 0
  br i1 %helper.ok.935, label %helper.continue.936, label %frame.failure.0
helper.continue.936:
  br label %local.descriptor.checked.917
local.descriptor.inactive.916:
  br label %local.descriptor.checked.917
local.descriptor.checked.917:
  %local.is.active.937 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.937, label %local.descriptor.active.938, label %local.descriptor.inactive.939
local.descriptor.active.938:
  %local.check.offset.941 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.942 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.943 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.944 = load i32, ptr %local.owner.end.12, align 4
  %context.field.945 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.946 = load i32, ptr %context.field.945, align 4
  %stack.sub.949 = sub i32 %local.check.owner.end.944, %local.check.offset.941
  %descriptor.owner.inside.947 = icmp ule i32 %local.check.owner.end.944, %context.value.946
  %descriptor.offset.inside.948 = icmp ule i32 %local.check.offset.941, %local.check.owner.end.944
  %descriptor.extent.inside.950 = icmp ule i32 %local.check.extent.942, %stack.sub.949
  %descriptor.payload.inside.951 = icmp ule i32 %local.check.payload.943, %local.check.extent.942
  %descriptor.owner.offset.valid.952 = and i1 %descriptor.owner.inside.947, %descriptor.offset.inside.948
  %descriptor.range.inside.954 = and i1 %descriptor.owner.offset.valid.952, %descriptor.extent.inside.950
  %descriptor.range.valid.953 = and i1 %descriptor.range.inside.954, %descriptor.payload.inside.951
  br i1 %descriptor.range.valid.953, label %descriptor.valid.955, label %descriptor.invalid.956
descriptor.invalid.956:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.955:
  %descriptor.initialized.status.957 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.941, i32 %local.check.extent.942)
  %helper.ok.958 = icmp eq i32 %descriptor.initialized.status.957, 0
  br i1 %helper.ok.958, label %helper.continue.959, label %frame.failure.0
helper.continue.959:
  br label %local.descriptor.checked.940
local.descriptor.inactive.939:
  br label %local.descriptor.checked.940
local.descriptor.checked.940:
  %local.is.active.960 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.960, label %local.descriptor.active.961, label %local.descriptor.inactive.962
local.descriptor.active.961:
  %local.check.offset.964 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.965 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.966 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.967 = load i32, ptr %local.owner.end.18, align 4
  %context.field.968 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.969 = load i32, ptr %context.field.968, align 4
  %stack.sub.972 = sub i32 %local.check.owner.end.967, %local.check.offset.964
  %descriptor.owner.inside.970 = icmp ule i32 %local.check.owner.end.967, %context.value.969
  %descriptor.offset.inside.971 = icmp ule i32 %local.check.offset.964, %local.check.owner.end.967
  %descriptor.extent.inside.973 = icmp ule i32 %local.check.extent.965, %stack.sub.972
  %descriptor.payload.inside.974 = icmp ule i32 %local.check.payload.966, %local.check.extent.965
  %descriptor.owner.offset.valid.975 = and i1 %descriptor.owner.inside.970, %descriptor.offset.inside.971
  %descriptor.range.inside.977 = and i1 %descriptor.owner.offset.valid.975, %descriptor.extent.inside.973
  %descriptor.range.valid.976 = and i1 %descriptor.range.inside.977, %descriptor.payload.inside.974
  br i1 %descriptor.range.valid.976, label %descriptor.valid.978, label %descriptor.invalid.979
descriptor.invalid.979:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.978:
  %descriptor.initialized.status.980 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.964, i32 %local.check.extent.965)
  %helper.ok.981 = icmp eq i32 %descriptor.initialized.status.980, 0
  br i1 %helper.ok.981, label %helper.continue.982, label %frame.failure.0
helper.continue.982:
  br label %local.descriptor.checked.963
local.descriptor.inactive.962:
  br label %local.descriptor.checked.963
local.descriptor.checked.963:
  %local.is.active.983 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.983, label %local.descriptor.active.984, label %local.descriptor.inactive.985
local.descriptor.active.984:
  %local.check.offset.987 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.988 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.989 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.990 = load i32, ptr %local.owner.end.24, align 4
  %context.field.991 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.992 = load i32, ptr %context.field.991, align 4
  %stack.sub.995 = sub i32 %local.check.owner.end.990, %local.check.offset.987
  %descriptor.owner.inside.993 = icmp ule i32 %local.check.owner.end.990, %context.value.992
  %descriptor.offset.inside.994 = icmp ule i32 %local.check.offset.987, %local.check.owner.end.990
  %descriptor.extent.inside.996 = icmp ule i32 %local.check.extent.988, %stack.sub.995
  %descriptor.payload.inside.997 = icmp ule i32 %local.check.payload.989, %local.check.extent.988
  %descriptor.owner.offset.valid.998 = and i1 %descriptor.owner.inside.993, %descriptor.offset.inside.994
  %descriptor.range.inside.1000 = and i1 %descriptor.owner.offset.valid.998, %descriptor.extent.inside.996
  %descriptor.range.valid.999 = and i1 %descriptor.range.inside.1000, %descriptor.payload.inside.997
  br i1 %descriptor.range.valid.999, label %descriptor.valid.1001, label %descriptor.invalid.1002
descriptor.invalid.1002:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1001:
  %descriptor.initialized.status.1003 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.987, i32 %local.check.extent.988)
  %helper.ok.1004 = icmp eq i32 %descriptor.initialized.status.1003, 0
  br i1 %helper.ok.1004, label %helper.continue.1005, label %frame.failure.0
helper.continue.1005:
  br label %local.descriptor.checked.986
local.descriptor.inactive.985:
  br label %local.descriptor.checked.986
local.descriptor.checked.986:
  %local.is.active.1006 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1006, label %local.descriptor.active.1007, label %local.descriptor.inactive.1008
local.descriptor.active.1007:
  %local.check.offset.1010 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1011 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1012 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1013 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1014 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1015 = load i32, ptr %context.field.1014, align 4
  %stack.sub.1018 = sub i32 %local.check.owner.end.1013, %local.check.offset.1010
  %descriptor.owner.inside.1016 = icmp ule i32 %local.check.owner.end.1013, %context.value.1015
  %descriptor.offset.inside.1017 = icmp ule i32 %local.check.offset.1010, %local.check.owner.end.1013
  %descriptor.extent.inside.1019 = icmp ule i32 %local.check.extent.1011, %stack.sub.1018
  %descriptor.payload.inside.1020 = icmp ule i32 %local.check.payload.1012, %local.check.extent.1011
  %descriptor.owner.offset.valid.1021 = and i1 %descriptor.owner.inside.1016, %descriptor.offset.inside.1017
  %descriptor.range.inside.1023 = and i1 %descriptor.owner.offset.valid.1021, %descriptor.extent.inside.1019
  %descriptor.range.valid.1022 = and i1 %descriptor.range.inside.1023, %descriptor.payload.inside.1020
  br i1 %descriptor.range.valid.1022, label %descriptor.valid.1024, label %descriptor.invalid.1025
descriptor.invalid.1025:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1024:
  %descriptor.initialized.status.1026 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1010, i32 %local.check.extent.1011)
  %helper.ok.1027 = icmp eq i32 %descriptor.initialized.status.1026, 0
  br i1 %helper.ok.1027, label %helper.continue.1028, label %frame.failure.0
helper.continue.1028:
  br label %local.descriptor.checked.1009
local.descriptor.inactive.1008:
  br label %local.descriptor.checked.1009
local.descriptor.checked.1009:
  %local.is.active.1029 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1029, label %local.descriptor.active.1030, label %local.descriptor.inactive.1031
local.descriptor.active.1030:
  %local.check.offset.1033 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1034 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1035 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1036 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1037 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1038 = load i32, ptr %context.field.1037, align 4
  %stack.sub.1041 = sub i32 %local.check.owner.end.1036, %local.check.offset.1033
  %descriptor.owner.inside.1039 = icmp ule i32 %local.check.owner.end.1036, %context.value.1038
  %descriptor.offset.inside.1040 = icmp ule i32 %local.check.offset.1033, %local.check.owner.end.1036
  %descriptor.extent.inside.1042 = icmp ule i32 %local.check.extent.1034, %stack.sub.1041
  %descriptor.payload.inside.1043 = icmp ule i32 %local.check.payload.1035, %local.check.extent.1034
  %descriptor.owner.offset.valid.1044 = and i1 %descriptor.owner.inside.1039, %descriptor.offset.inside.1040
  %descriptor.range.inside.1046 = and i1 %descriptor.owner.offset.valid.1044, %descriptor.extent.inside.1042
  %descriptor.range.valid.1045 = and i1 %descriptor.range.inside.1046, %descriptor.payload.inside.1043
  br i1 %descriptor.range.valid.1045, label %descriptor.valid.1047, label %descriptor.invalid.1048
descriptor.invalid.1048:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1047:
  %descriptor.initialized.status.1049 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1033, i32 %local.check.extent.1034)
  %helper.ok.1050 = icmp eq i32 %descriptor.initialized.status.1049, 0
  br i1 %helper.ok.1050, label %helper.continue.1051, label %frame.failure.0
helper.continue.1051:
  br label %local.descriptor.checked.1032
local.descriptor.inactive.1031:
  br label %local.descriptor.checked.1032
local.descriptor.checked.1032:
  %step.status.1052 = call i32 @al_owning_charge_step(ptr %ctx, i32 6)
  %helper.ok.1053 = icmp eq i32 %step.status.1052, 0
  br i1 %helper.ok.1053, label %helper.continue.1054, label %frame.failure.0
helper.continue.1054:
  store i1 true, ptr %local.active.26, align 1
  store i32 %descriptor.value.83, ptr %local.offset.27, align 4
  store i32 %descriptor.value.85, ptr %local.extent.28, align 4
  store i32 %descriptor.value.87, ptr %local.payload.29, align 4
  store i32 %descriptor.value.89, ptr %local.owner.end.30, align 4
  store i32 1, ptr %local.type.31, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %descriptor.value.83, i32 20, i32 %descriptor.value.87, i32 %descriptor.value.89, i32 %descriptor.value.85)
  %context.field.1055 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1056 = load i32, ptr %context.field.1055, align 4
  %runtime.ok.1057 = icmp eq i32 %context.value.1056, 0
  br i1 %runtime.ok.1057, label %runtime.continue.1058, label %frame.failure.0
runtime.continue.1058:
  %context.field.1059 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1060 = load i32, ptr %context.field.1059, align 4
  %stack.sub.1063 = sub i32 %descriptor.value.59, %descriptor.value.53
  %descriptor.owner.inside.1061 = icmp ule i32 %descriptor.value.59, %context.value.1060
  %descriptor.offset.inside.1062 = icmp ule i32 %descriptor.value.53, %descriptor.value.59
  %descriptor.extent.inside.1064 = icmp ule i32 %descriptor.value.55, %stack.sub.1063
  %descriptor.payload.inside.1065 = icmp ule i32 %descriptor.value.57, %descriptor.value.55
  %descriptor.owner.offset.valid.1066 = and i1 %descriptor.owner.inside.1061, %descriptor.offset.inside.1062
  %descriptor.range.inside.1068 = and i1 %descriptor.owner.offset.valid.1066, %descriptor.extent.inside.1064
  %descriptor.range.valid.1067 = and i1 %descriptor.range.inside.1068, %descriptor.payload.inside.1065
  %descriptor.type.valid.1069 = icmp eq i32 1, 1
  %descriptor.valid.1070 = and i1 %descriptor.range.valid.1067, %descriptor.type.valid.1069
  br i1 %descriptor.valid.1070, label %descriptor.valid.1071, label %descriptor.invalid.1072
descriptor.invalid.1072:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1071:
  %descriptor.initialized.status.1073 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.53, i32 %descriptor.value.55)
  %helper.ok.1074 = icmp eq i32 %descriptor.initialized.status.1073, 0
  br i1 %helper.ok.1074, label %helper.continue.1075, label %frame.failure.0
helper.continue.1075:
  %local.is.active.1076 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1076, label %local.descriptor.active.1077, label %local.descriptor.inactive.1078
local.descriptor.active.1077:
  %local.check.offset.1080 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1081 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1082 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1083 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1084 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1085 = load i32, ptr %context.field.1084, align 4
  %stack.sub.1088 = sub i32 %local.check.owner.end.1083, %local.check.offset.1080
  %descriptor.owner.inside.1086 = icmp ule i32 %local.check.owner.end.1083, %context.value.1085
  %descriptor.offset.inside.1087 = icmp ule i32 %local.check.offset.1080, %local.check.owner.end.1083
  %descriptor.extent.inside.1089 = icmp ule i32 %local.check.extent.1081, %stack.sub.1088
  %descriptor.payload.inside.1090 = icmp ule i32 %local.check.payload.1082, %local.check.extent.1081
  %descriptor.owner.offset.valid.1091 = and i1 %descriptor.owner.inside.1086, %descriptor.offset.inside.1087
  %descriptor.range.inside.1093 = and i1 %descriptor.owner.offset.valid.1091, %descriptor.extent.inside.1089
  %descriptor.range.valid.1092 = and i1 %descriptor.range.inside.1093, %descriptor.payload.inside.1090
  br i1 %descriptor.range.valid.1092, label %descriptor.valid.1094, label %descriptor.invalid.1095
descriptor.invalid.1095:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1094:
  %descriptor.initialized.status.1096 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1080, i32 %local.check.extent.1081)
  %helper.ok.1097 = icmp eq i32 %descriptor.initialized.status.1096, 0
  br i1 %helper.ok.1097, label %helper.continue.1098, label %frame.failure.0
helper.continue.1098:
  br label %local.descriptor.checked.1079
local.descriptor.inactive.1078:
  br label %local.descriptor.checked.1079
local.descriptor.checked.1079:
  %local.is.active.1099 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1099, label %local.descriptor.active.1100, label %local.descriptor.inactive.1101
local.descriptor.active.1100:
  %local.check.offset.1103 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1104 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1105 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1106 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1107 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1108 = load i32, ptr %context.field.1107, align 4
  %stack.sub.1111 = sub i32 %local.check.owner.end.1106, %local.check.offset.1103
  %descriptor.owner.inside.1109 = icmp ule i32 %local.check.owner.end.1106, %context.value.1108
  %descriptor.offset.inside.1110 = icmp ule i32 %local.check.offset.1103, %local.check.owner.end.1106
  %descriptor.extent.inside.1112 = icmp ule i32 %local.check.extent.1104, %stack.sub.1111
  %descriptor.payload.inside.1113 = icmp ule i32 %local.check.payload.1105, %local.check.extent.1104
  %descriptor.owner.offset.valid.1114 = and i1 %descriptor.owner.inside.1109, %descriptor.offset.inside.1110
  %descriptor.range.inside.1116 = and i1 %descriptor.owner.offset.valid.1114, %descriptor.extent.inside.1112
  %descriptor.range.valid.1115 = and i1 %descriptor.range.inside.1116, %descriptor.payload.inside.1113
  br i1 %descriptor.range.valid.1115, label %descriptor.valid.1117, label %descriptor.invalid.1118
descriptor.invalid.1118:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1117:
  %descriptor.initialized.status.1119 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1103, i32 %local.check.extent.1104)
  %helper.ok.1120 = icmp eq i32 %descriptor.initialized.status.1119, 0
  br i1 %helper.ok.1120, label %helper.continue.1121, label %frame.failure.0
helper.continue.1121:
  br label %local.descriptor.checked.1102
local.descriptor.inactive.1101:
  br label %local.descriptor.checked.1102
local.descriptor.checked.1102:
  %local.is.active.1122 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1122, label %local.descriptor.active.1123, label %local.descriptor.inactive.1124
local.descriptor.active.1123:
  %local.check.offset.1126 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1127 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1128 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1129 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1130 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1131 = load i32, ptr %context.field.1130, align 4
  %stack.sub.1134 = sub i32 %local.check.owner.end.1129, %local.check.offset.1126
  %descriptor.owner.inside.1132 = icmp ule i32 %local.check.owner.end.1129, %context.value.1131
  %descriptor.offset.inside.1133 = icmp ule i32 %local.check.offset.1126, %local.check.owner.end.1129
  %descriptor.extent.inside.1135 = icmp ule i32 %local.check.extent.1127, %stack.sub.1134
  %descriptor.payload.inside.1136 = icmp ule i32 %local.check.payload.1128, %local.check.extent.1127
  %descriptor.owner.offset.valid.1137 = and i1 %descriptor.owner.inside.1132, %descriptor.offset.inside.1133
  %descriptor.range.inside.1139 = and i1 %descriptor.owner.offset.valid.1137, %descriptor.extent.inside.1135
  %descriptor.range.valid.1138 = and i1 %descriptor.range.inside.1139, %descriptor.payload.inside.1136
  br i1 %descriptor.range.valid.1138, label %descriptor.valid.1140, label %descriptor.invalid.1141
descriptor.invalid.1141:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1140:
  %descriptor.initialized.status.1142 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1126, i32 %local.check.extent.1127)
  %helper.ok.1143 = icmp eq i32 %descriptor.initialized.status.1142, 0
  br i1 %helper.ok.1143, label %helper.continue.1144, label %frame.failure.0
helper.continue.1144:
  br label %local.descriptor.checked.1125
local.descriptor.inactive.1124:
  br label %local.descriptor.checked.1125
local.descriptor.checked.1125:
  %local.is.active.1145 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1145, label %local.descriptor.active.1146, label %local.descriptor.inactive.1147
local.descriptor.active.1146:
  %local.check.offset.1149 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1150 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1151 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1152 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1153 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1154 = load i32, ptr %context.field.1153, align 4
  %stack.sub.1157 = sub i32 %local.check.owner.end.1152, %local.check.offset.1149
  %descriptor.owner.inside.1155 = icmp ule i32 %local.check.owner.end.1152, %context.value.1154
  %descriptor.offset.inside.1156 = icmp ule i32 %local.check.offset.1149, %local.check.owner.end.1152
  %descriptor.extent.inside.1158 = icmp ule i32 %local.check.extent.1150, %stack.sub.1157
  %descriptor.payload.inside.1159 = icmp ule i32 %local.check.payload.1151, %local.check.extent.1150
  %descriptor.owner.offset.valid.1160 = and i1 %descriptor.owner.inside.1155, %descriptor.offset.inside.1156
  %descriptor.range.inside.1162 = and i1 %descriptor.owner.offset.valid.1160, %descriptor.extent.inside.1158
  %descriptor.range.valid.1161 = and i1 %descriptor.range.inside.1162, %descriptor.payload.inside.1159
  br i1 %descriptor.range.valid.1161, label %descriptor.valid.1163, label %descriptor.invalid.1164
descriptor.invalid.1164:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1163:
  %descriptor.initialized.status.1165 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1149, i32 %local.check.extent.1150)
  %helper.ok.1166 = icmp eq i32 %descriptor.initialized.status.1165, 0
  br i1 %helper.ok.1166, label %helper.continue.1167, label %frame.failure.0
helper.continue.1167:
  br label %local.descriptor.checked.1148
local.descriptor.inactive.1147:
  br label %local.descriptor.checked.1148
local.descriptor.checked.1148:
  %local.is.active.1168 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1168, label %local.descriptor.active.1169, label %local.descriptor.inactive.1170
local.descriptor.active.1169:
  %local.check.offset.1172 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1173 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1174 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1175 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1176 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1177 = load i32, ptr %context.field.1176, align 4
  %stack.sub.1180 = sub i32 %local.check.owner.end.1175, %local.check.offset.1172
  %descriptor.owner.inside.1178 = icmp ule i32 %local.check.owner.end.1175, %context.value.1177
  %descriptor.offset.inside.1179 = icmp ule i32 %local.check.offset.1172, %local.check.owner.end.1175
  %descriptor.extent.inside.1181 = icmp ule i32 %local.check.extent.1173, %stack.sub.1180
  %descriptor.payload.inside.1182 = icmp ule i32 %local.check.payload.1174, %local.check.extent.1173
  %descriptor.owner.offset.valid.1183 = and i1 %descriptor.owner.inside.1178, %descriptor.offset.inside.1179
  %descriptor.range.inside.1185 = and i1 %descriptor.owner.offset.valid.1183, %descriptor.extent.inside.1181
  %descriptor.range.valid.1184 = and i1 %descriptor.range.inside.1185, %descriptor.payload.inside.1182
  br i1 %descriptor.range.valid.1184, label %descriptor.valid.1186, label %descriptor.invalid.1187
descriptor.invalid.1187:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1186:
  %descriptor.initialized.status.1188 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1172, i32 %local.check.extent.1173)
  %helper.ok.1189 = icmp eq i32 %descriptor.initialized.status.1188, 0
  br i1 %helper.ok.1189, label %helper.continue.1190, label %frame.failure.0
helper.continue.1190:
  br label %local.descriptor.checked.1171
local.descriptor.inactive.1170:
  br label %local.descriptor.checked.1171
local.descriptor.checked.1171:
  %local.is.active.1191 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1191, label %local.descriptor.active.1192, label %local.descriptor.inactive.1193
local.descriptor.active.1192:
  %local.check.offset.1195 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1196 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1197 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1198 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1199 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1200 = load i32, ptr %context.field.1199, align 4
  %stack.sub.1203 = sub i32 %local.check.owner.end.1198, %local.check.offset.1195
  %descriptor.owner.inside.1201 = icmp ule i32 %local.check.owner.end.1198, %context.value.1200
  %descriptor.offset.inside.1202 = icmp ule i32 %local.check.offset.1195, %local.check.owner.end.1198
  %descriptor.extent.inside.1204 = icmp ule i32 %local.check.extent.1196, %stack.sub.1203
  %descriptor.payload.inside.1205 = icmp ule i32 %local.check.payload.1197, %local.check.extent.1196
  %descriptor.owner.offset.valid.1206 = and i1 %descriptor.owner.inside.1201, %descriptor.offset.inside.1202
  %descriptor.range.inside.1208 = and i1 %descriptor.owner.offset.valid.1206, %descriptor.extent.inside.1204
  %descriptor.range.valid.1207 = and i1 %descriptor.range.inside.1208, %descriptor.payload.inside.1205
  br i1 %descriptor.range.valid.1207, label %descriptor.valid.1209, label %descriptor.invalid.1210
descriptor.invalid.1210:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1209:
  %descriptor.initialized.status.1211 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1195, i32 %local.check.extent.1196)
  %helper.ok.1212 = icmp eq i32 %descriptor.initialized.status.1211, 0
  br i1 %helper.ok.1212, label %helper.continue.1213, label %frame.failure.0
helper.continue.1213:
  br label %local.descriptor.checked.1194
local.descriptor.inactive.1193:
  br label %local.descriptor.checked.1194
local.descriptor.checked.1194:
  %step.status.1214 = call i32 @al_owning_charge_step(ptr %ctx, i32 7)
  %helper.ok.1215 = icmp eq i32 %step.status.1214, 0
  br i1 %helper.ok.1215, label %helper.continue.1216, label %frame.failure.0
helper.continue.1216:
  store i1 true, ptr %local.active.32, align 1
  store i32 %descriptor.value.53, ptr %local.offset.33, align 4
  store i32 %descriptor.value.55, ptr %local.extent.34, align 4
  store i32 %descriptor.value.57, ptr %local.payload.35, align 4
  store i32 %descriptor.value.59, ptr %local.owner.end.36, align 4
  store i32 1, ptr %local.type.37, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %descriptor.value.53, i32 20, i32 %descriptor.value.57, i32 %descriptor.value.59, i32 %descriptor.value.55)
  %context.field.1217 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1218 = load i32, ptr %context.field.1217, align 4
  %runtime.ok.1219 = icmp eq i32 %context.value.1218, 0
  br i1 %runtime.ok.1219, label %runtime.continue.1220, label %frame.failure.0
runtime.continue.1220:
  %local.is.active.1221 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1221, label %local.descriptor.active.1222, label %local.descriptor.inactive.1223
local.descriptor.active.1222:
  %local.check.offset.1225 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1226 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1227 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1228 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1229 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1230 = load i32, ptr %context.field.1229, align 4
  %stack.sub.1233 = sub i32 %local.check.owner.end.1228, %local.check.offset.1225
  %descriptor.owner.inside.1231 = icmp ule i32 %local.check.owner.end.1228, %context.value.1230
  %descriptor.offset.inside.1232 = icmp ule i32 %local.check.offset.1225, %local.check.owner.end.1228
  %descriptor.extent.inside.1234 = icmp ule i32 %local.check.extent.1226, %stack.sub.1233
  %descriptor.payload.inside.1235 = icmp ule i32 %local.check.payload.1227, %local.check.extent.1226
  %descriptor.owner.offset.valid.1236 = and i1 %descriptor.owner.inside.1231, %descriptor.offset.inside.1232
  %descriptor.range.inside.1238 = and i1 %descriptor.owner.offset.valid.1236, %descriptor.extent.inside.1234
  %descriptor.range.valid.1237 = and i1 %descriptor.range.inside.1238, %descriptor.payload.inside.1235
  br i1 %descriptor.range.valid.1237, label %descriptor.valid.1239, label %descriptor.invalid.1240
descriptor.invalid.1240:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1239:
  %descriptor.initialized.status.1241 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1225, i32 %local.check.extent.1226)
  %helper.ok.1242 = icmp eq i32 %descriptor.initialized.status.1241, 0
  br i1 %helper.ok.1242, label %helper.continue.1243, label %frame.failure.0
helper.continue.1243:
  br label %local.descriptor.checked.1224
local.descriptor.inactive.1223:
  br label %local.descriptor.checked.1224
local.descriptor.checked.1224:
  %local.is.active.1244 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1244, label %local.descriptor.active.1245, label %local.descriptor.inactive.1246
local.descriptor.active.1245:
  %local.check.offset.1248 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1249 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1250 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1251 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1252 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1253 = load i32, ptr %context.field.1252, align 4
  %stack.sub.1256 = sub i32 %local.check.owner.end.1251, %local.check.offset.1248
  %descriptor.owner.inside.1254 = icmp ule i32 %local.check.owner.end.1251, %context.value.1253
  %descriptor.offset.inside.1255 = icmp ule i32 %local.check.offset.1248, %local.check.owner.end.1251
  %descriptor.extent.inside.1257 = icmp ule i32 %local.check.extent.1249, %stack.sub.1256
  %descriptor.payload.inside.1258 = icmp ule i32 %local.check.payload.1250, %local.check.extent.1249
  %descriptor.owner.offset.valid.1259 = and i1 %descriptor.owner.inside.1254, %descriptor.offset.inside.1255
  %descriptor.range.inside.1261 = and i1 %descriptor.owner.offset.valid.1259, %descriptor.extent.inside.1257
  %descriptor.range.valid.1260 = and i1 %descriptor.range.inside.1261, %descriptor.payload.inside.1258
  br i1 %descriptor.range.valid.1260, label %descriptor.valid.1262, label %descriptor.invalid.1263
descriptor.invalid.1263:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1262:
  %descriptor.initialized.status.1264 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1248, i32 %local.check.extent.1249)
  %helper.ok.1265 = icmp eq i32 %descriptor.initialized.status.1264, 0
  br i1 %helper.ok.1265, label %helper.continue.1266, label %frame.failure.0
helper.continue.1266:
  br label %local.descriptor.checked.1247
local.descriptor.inactive.1246:
  br label %local.descriptor.checked.1247
local.descriptor.checked.1247:
  %local.is.active.1267 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1267, label %local.descriptor.active.1268, label %local.descriptor.inactive.1269
local.descriptor.active.1268:
  %local.check.offset.1271 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1272 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1273 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1274 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1275 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1276 = load i32, ptr %context.field.1275, align 4
  %stack.sub.1279 = sub i32 %local.check.owner.end.1274, %local.check.offset.1271
  %descriptor.owner.inside.1277 = icmp ule i32 %local.check.owner.end.1274, %context.value.1276
  %descriptor.offset.inside.1278 = icmp ule i32 %local.check.offset.1271, %local.check.owner.end.1274
  %descriptor.extent.inside.1280 = icmp ule i32 %local.check.extent.1272, %stack.sub.1279
  %descriptor.payload.inside.1281 = icmp ule i32 %local.check.payload.1273, %local.check.extent.1272
  %descriptor.owner.offset.valid.1282 = and i1 %descriptor.owner.inside.1277, %descriptor.offset.inside.1278
  %descriptor.range.inside.1284 = and i1 %descriptor.owner.offset.valid.1282, %descriptor.extent.inside.1280
  %descriptor.range.valid.1283 = and i1 %descriptor.range.inside.1284, %descriptor.payload.inside.1281
  br i1 %descriptor.range.valid.1283, label %descriptor.valid.1285, label %descriptor.invalid.1286
descriptor.invalid.1286:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1285:
  %descriptor.initialized.status.1287 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1271, i32 %local.check.extent.1272)
  %helper.ok.1288 = icmp eq i32 %descriptor.initialized.status.1287, 0
  br i1 %helper.ok.1288, label %helper.continue.1289, label %frame.failure.0
helper.continue.1289:
  br label %local.descriptor.checked.1270
local.descriptor.inactive.1269:
  br label %local.descriptor.checked.1270
local.descriptor.checked.1270:
  %local.is.active.1290 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1290, label %local.descriptor.active.1291, label %local.descriptor.inactive.1292
local.descriptor.active.1291:
  %local.check.offset.1294 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1295 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1296 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1297 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1298 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1299 = load i32, ptr %context.field.1298, align 4
  %stack.sub.1302 = sub i32 %local.check.owner.end.1297, %local.check.offset.1294
  %descriptor.owner.inside.1300 = icmp ule i32 %local.check.owner.end.1297, %context.value.1299
  %descriptor.offset.inside.1301 = icmp ule i32 %local.check.offset.1294, %local.check.owner.end.1297
  %descriptor.extent.inside.1303 = icmp ule i32 %local.check.extent.1295, %stack.sub.1302
  %descriptor.payload.inside.1304 = icmp ule i32 %local.check.payload.1296, %local.check.extent.1295
  %descriptor.owner.offset.valid.1305 = and i1 %descriptor.owner.inside.1300, %descriptor.offset.inside.1301
  %descriptor.range.inside.1307 = and i1 %descriptor.owner.offset.valid.1305, %descriptor.extent.inside.1303
  %descriptor.range.valid.1306 = and i1 %descriptor.range.inside.1307, %descriptor.payload.inside.1304
  br i1 %descriptor.range.valid.1306, label %descriptor.valid.1308, label %descriptor.invalid.1309
descriptor.invalid.1309:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1308:
  %descriptor.initialized.status.1310 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1294, i32 %local.check.extent.1295)
  %helper.ok.1311 = icmp eq i32 %descriptor.initialized.status.1310, 0
  br i1 %helper.ok.1311, label %helper.continue.1312, label %frame.failure.0
helper.continue.1312:
  br label %local.descriptor.checked.1293
local.descriptor.inactive.1292:
  br label %local.descriptor.checked.1293
local.descriptor.checked.1293:
  %local.is.active.1313 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1313, label %local.descriptor.active.1314, label %local.descriptor.inactive.1315
local.descriptor.active.1314:
  %local.check.offset.1317 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1318 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1319 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1320 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1321 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1322 = load i32, ptr %context.field.1321, align 4
  %stack.sub.1325 = sub i32 %local.check.owner.end.1320, %local.check.offset.1317
  %descriptor.owner.inside.1323 = icmp ule i32 %local.check.owner.end.1320, %context.value.1322
  %descriptor.offset.inside.1324 = icmp ule i32 %local.check.offset.1317, %local.check.owner.end.1320
  %descriptor.extent.inside.1326 = icmp ule i32 %local.check.extent.1318, %stack.sub.1325
  %descriptor.payload.inside.1327 = icmp ule i32 %local.check.payload.1319, %local.check.extent.1318
  %descriptor.owner.offset.valid.1328 = and i1 %descriptor.owner.inside.1323, %descriptor.offset.inside.1324
  %descriptor.range.inside.1330 = and i1 %descriptor.owner.offset.valid.1328, %descriptor.extent.inside.1326
  %descriptor.range.valid.1329 = and i1 %descriptor.range.inside.1330, %descriptor.payload.inside.1327
  br i1 %descriptor.range.valid.1329, label %descriptor.valid.1331, label %descriptor.invalid.1332
descriptor.invalid.1332:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1331:
  %descriptor.initialized.status.1333 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1317, i32 %local.check.extent.1318)
  %helper.ok.1334 = icmp eq i32 %descriptor.initialized.status.1333, 0
  br i1 %helper.ok.1334, label %helper.continue.1335, label %frame.failure.0
helper.continue.1335:
  br label %local.descriptor.checked.1316
local.descriptor.inactive.1315:
  br label %local.descriptor.checked.1316
local.descriptor.checked.1316:
  %local.is.active.1336 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1336, label %local.descriptor.active.1337, label %local.descriptor.inactive.1338
local.descriptor.active.1337:
  %local.check.offset.1340 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1341 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1342 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1343 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1344 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1345 = load i32, ptr %context.field.1344, align 4
  %stack.sub.1348 = sub i32 %local.check.owner.end.1343, %local.check.offset.1340
  %descriptor.owner.inside.1346 = icmp ule i32 %local.check.owner.end.1343, %context.value.1345
  %descriptor.offset.inside.1347 = icmp ule i32 %local.check.offset.1340, %local.check.owner.end.1343
  %descriptor.extent.inside.1349 = icmp ule i32 %local.check.extent.1341, %stack.sub.1348
  %descriptor.payload.inside.1350 = icmp ule i32 %local.check.payload.1342, %local.check.extent.1341
  %descriptor.owner.offset.valid.1351 = and i1 %descriptor.owner.inside.1346, %descriptor.offset.inside.1347
  %descriptor.range.inside.1353 = and i1 %descriptor.owner.offset.valid.1351, %descriptor.extent.inside.1349
  %descriptor.range.valid.1352 = and i1 %descriptor.range.inside.1353, %descriptor.payload.inside.1350
  br i1 %descriptor.range.valid.1352, label %descriptor.valid.1354, label %descriptor.invalid.1355
descriptor.invalid.1355:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1354:
  %descriptor.initialized.status.1356 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1340, i32 %local.check.extent.1341)
  %helper.ok.1357 = icmp eq i32 %descriptor.initialized.status.1356, 0
  br i1 %helper.ok.1357, label %helper.continue.1358, label %frame.failure.0
helper.continue.1358:
  br label %local.descriptor.checked.1339
local.descriptor.inactive.1338:
  br label %local.descriptor.checked.1339
local.descriptor.checked.1339:
  %step.status.1359 = call i32 @al_owning_charge_step(ptr %ctx, i32 8)
  %helper.ok.1360 = icmp eq i32 %step.status.1359, 0
  br i1 %helper.ok.1360, label %helper.continue.1361, label %frame.failure.0
helper.continue.1361:
  %context.field.1362 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1363 = load i32, ptr %context.field.1362, align 4
  %step.status.1364 = call i32 @al_owning_charge_step(ptr %ctx, i32 9)
  %helper.ok.1365 = icmp eq i32 %step.status.1364, 0
  br i1 %helper.ok.1365, label %helper.continue.1366, label %frame.failure.0
helper.continue.1366:
  %context.field.1367 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1368 = load i32, ptr %context.field.1367, align 4
  %stack.offset.1369 = add i32 %context.value.1368, 8
  %reserve.status.1370 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1369, i32 10)
  %reserve.ok.1371 = icmp eq i32 %reserve.status.1370, 0
  br i1 %reserve.ok.1371, label %reserve.continue.1372, label %frame.failure.0
reserve.continue.1372:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.1368, i64 777, i32 1)
  %context.field.1373 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1374 = load i32, ptr %context.field.1373, align 4
  %runtime.ok.1375 = icmp eq i32 %context.value.1374, 0
  br i1 %runtime.ok.1375, label %runtime.continue.1376, label %frame.failure.0
runtime.continue.1376:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.1377 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1378 = load i32, ptr %context.field.1377, align 4
  %runtime.ok.1379 = icmp eq i32 %context.value.1378, 0
  br i1 %runtime.ok.1379, label %runtime.continue.1380, label %frame.failure.0
runtime.continue.1380:
  %context.field.1381 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1382 = load i32, ptr %context.field.1381, align 4
  %stack.sub.1385 = sub i32 %stack.offset.1369, %context.value.1368
  %descriptor.owner.inside.1383 = icmp ule i32 %stack.offset.1369, %context.value.1382
  %descriptor.offset.inside.1384 = icmp ule i32 %context.value.1368, %stack.offset.1369
  %descriptor.extent.inside.1386 = icmp ule i32 8, %stack.sub.1385
  %descriptor.payload.inside.1387 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.1388 = and i1 %descriptor.owner.inside.1383, %descriptor.offset.inside.1384
  %descriptor.range.inside.1390 = and i1 %descriptor.owner.offset.valid.1388, %descriptor.extent.inside.1386
  %descriptor.range.valid.1389 = and i1 %descriptor.range.inside.1390, %descriptor.payload.inside.1387
  %descriptor.type.valid.1391 = icmp eq i32 1, 1
  %descriptor.valid.1392 = and i1 %descriptor.range.valid.1389, %descriptor.type.valid.1391
  br i1 %descriptor.valid.1392, label %descriptor.valid.1393, label %descriptor.invalid.1394
descriptor.invalid.1394:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1393:
  %descriptor.initialized.status.1395 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.1368, i32 8)
  %helper.ok.1396 = icmp eq i32 %descriptor.initialized.status.1395, 0
  br i1 %helper.ok.1396, label %helper.continue.1397, label %frame.failure.0
helper.continue.1397:
  %local.is.active.1398 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1398, label %local.descriptor.active.1399, label %local.descriptor.inactive.1400
local.descriptor.active.1399:
  %local.check.offset.1402 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1403 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1404 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1405 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1406 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1407 = load i32, ptr %context.field.1406, align 4
  %stack.sub.1410 = sub i32 %local.check.owner.end.1405, %local.check.offset.1402
  %descriptor.owner.inside.1408 = icmp ule i32 %local.check.owner.end.1405, %context.value.1407
  %descriptor.offset.inside.1409 = icmp ule i32 %local.check.offset.1402, %local.check.owner.end.1405
  %descriptor.extent.inside.1411 = icmp ule i32 %local.check.extent.1403, %stack.sub.1410
  %descriptor.payload.inside.1412 = icmp ule i32 %local.check.payload.1404, %local.check.extent.1403
  %descriptor.owner.offset.valid.1413 = and i1 %descriptor.owner.inside.1408, %descriptor.offset.inside.1409
  %descriptor.range.inside.1415 = and i1 %descriptor.owner.offset.valid.1413, %descriptor.extent.inside.1411
  %descriptor.range.valid.1414 = and i1 %descriptor.range.inside.1415, %descriptor.payload.inside.1412
  br i1 %descriptor.range.valid.1414, label %descriptor.valid.1416, label %descriptor.invalid.1417
descriptor.invalid.1417:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1416:
  %descriptor.initialized.status.1418 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1402, i32 %local.check.extent.1403)
  %helper.ok.1419 = icmp eq i32 %descriptor.initialized.status.1418, 0
  br i1 %helper.ok.1419, label %helper.continue.1420, label %frame.failure.0
helper.continue.1420:
  br label %local.descriptor.checked.1401
local.descriptor.inactive.1400:
  br label %local.descriptor.checked.1401
local.descriptor.checked.1401:
  %local.is.active.1421 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1421, label %local.descriptor.active.1422, label %local.descriptor.inactive.1423
local.descriptor.active.1422:
  %local.check.offset.1425 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1426 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1427 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1428 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1429 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1430 = load i32, ptr %context.field.1429, align 4
  %stack.sub.1433 = sub i32 %local.check.owner.end.1428, %local.check.offset.1425
  %descriptor.owner.inside.1431 = icmp ule i32 %local.check.owner.end.1428, %context.value.1430
  %descriptor.offset.inside.1432 = icmp ule i32 %local.check.offset.1425, %local.check.owner.end.1428
  %descriptor.extent.inside.1434 = icmp ule i32 %local.check.extent.1426, %stack.sub.1433
  %descriptor.payload.inside.1435 = icmp ule i32 %local.check.payload.1427, %local.check.extent.1426
  %descriptor.owner.offset.valid.1436 = and i1 %descriptor.owner.inside.1431, %descriptor.offset.inside.1432
  %descriptor.range.inside.1438 = and i1 %descriptor.owner.offset.valid.1436, %descriptor.extent.inside.1434
  %descriptor.range.valid.1437 = and i1 %descriptor.range.inside.1438, %descriptor.payload.inside.1435
  br i1 %descriptor.range.valid.1437, label %descriptor.valid.1439, label %descriptor.invalid.1440
descriptor.invalid.1440:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1439:
  %descriptor.initialized.status.1441 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1425, i32 %local.check.extent.1426)
  %helper.ok.1442 = icmp eq i32 %descriptor.initialized.status.1441, 0
  br i1 %helper.ok.1442, label %helper.continue.1443, label %frame.failure.0
helper.continue.1443:
  br label %local.descriptor.checked.1424
local.descriptor.inactive.1423:
  br label %local.descriptor.checked.1424
local.descriptor.checked.1424:
  %local.is.active.1444 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1444, label %local.descriptor.active.1445, label %local.descriptor.inactive.1446
local.descriptor.active.1445:
  %local.check.offset.1448 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1449 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1450 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1451 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1452 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1453 = load i32, ptr %context.field.1452, align 4
  %stack.sub.1456 = sub i32 %local.check.owner.end.1451, %local.check.offset.1448
  %descriptor.owner.inside.1454 = icmp ule i32 %local.check.owner.end.1451, %context.value.1453
  %descriptor.offset.inside.1455 = icmp ule i32 %local.check.offset.1448, %local.check.owner.end.1451
  %descriptor.extent.inside.1457 = icmp ule i32 %local.check.extent.1449, %stack.sub.1456
  %descriptor.payload.inside.1458 = icmp ule i32 %local.check.payload.1450, %local.check.extent.1449
  %descriptor.owner.offset.valid.1459 = and i1 %descriptor.owner.inside.1454, %descriptor.offset.inside.1455
  %descriptor.range.inside.1461 = and i1 %descriptor.owner.offset.valid.1459, %descriptor.extent.inside.1457
  %descriptor.range.valid.1460 = and i1 %descriptor.range.inside.1461, %descriptor.payload.inside.1458
  br i1 %descriptor.range.valid.1460, label %descriptor.valid.1462, label %descriptor.invalid.1463
descriptor.invalid.1463:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1462:
  %descriptor.initialized.status.1464 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1448, i32 %local.check.extent.1449)
  %helper.ok.1465 = icmp eq i32 %descriptor.initialized.status.1464, 0
  br i1 %helper.ok.1465, label %helper.continue.1466, label %frame.failure.0
helper.continue.1466:
  br label %local.descriptor.checked.1447
local.descriptor.inactive.1446:
  br label %local.descriptor.checked.1447
local.descriptor.checked.1447:
  %local.is.active.1467 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1467, label %local.descriptor.active.1468, label %local.descriptor.inactive.1469
local.descriptor.active.1468:
  %local.check.offset.1471 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1472 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1473 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1474 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1475 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1476 = load i32, ptr %context.field.1475, align 4
  %stack.sub.1479 = sub i32 %local.check.owner.end.1474, %local.check.offset.1471
  %descriptor.owner.inside.1477 = icmp ule i32 %local.check.owner.end.1474, %context.value.1476
  %descriptor.offset.inside.1478 = icmp ule i32 %local.check.offset.1471, %local.check.owner.end.1474
  %descriptor.extent.inside.1480 = icmp ule i32 %local.check.extent.1472, %stack.sub.1479
  %descriptor.payload.inside.1481 = icmp ule i32 %local.check.payload.1473, %local.check.extent.1472
  %descriptor.owner.offset.valid.1482 = and i1 %descriptor.owner.inside.1477, %descriptor.offset.inside.1478
  %descriptor.range.inside.1484 = and i1 %descriptor.owner.offset.valid.1482, %descriptor.extent.inside.1480
  %descriptor.range.valid.1483 = and i1 %descriptor.range.inside.1484, %descriptor.payload.inside.1481
  br i1 %descriptor.range.valid.1483, label %descriptor.valid.1485, label %descriptor.invalid.1486
descriptor.invalid.1486:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1485:
  %descriptor.initialized.status.1487 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1471, i32 %local.check.extent.1472)
  %helper.ok.1488 = icmp eq i32 %descriptor.initialized.status.1487, 0
  br i1 %helper.ok.1488, label %helper.continue.1489, label %frame.failure.0
helper.continue.1489:
  br label %local.descriptor.checked.1470
local.descriptor.inactive.1469:
  br label %local.descriptor.checked.1470
local.descriptor.checked.1470:
  %local.is.active.1490 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1490, label %local.descriptor.active.1491, label %local.descriptor.inactive.1492
local.descriptor.active.1491:
  %local.check.offset.1494 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1495 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1496 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1497 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1498 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1499 = load i32, ptr %context.field.1498, align 4
  %stack.sub.1502 = sub i32 %local.check.owner.end.1497, %local.check.offset.1494
  %descriptor.owner.inside.1500 = icmp ule i32 %local.check.owner.end.1497, %context.value.1499
  %descriptor.offset.inside.1501 = icmp ule i32 %local.check.offset.1494, %local.check.owner.end.1497
  %descriptor.extent.inside.1503 = icmp ule i32 %local.check.extent.1495, %stack.sub.1502
  %descriptor.payload.inside.1504 = icmp ule i32 %local.check.payload.1496, %local.check.extent.1495
  %descriptor.owner.offset.valid.1505 = and i1 %descriptor.owner.inside.1500, %descriptor.offset.inside.1501
  %descriptor.range.inside.1507 = and i1 %descriptor.owner.offset.valid.1505, %descriptor.extent.inside.1503
  %descriptor.range.valid.1506 = and i1 %descriptor.range.inside.1507, %descriptor.payload.inside.1504
  br i1 %descriptor.range.valid.1506, label %descriptor.valid.1508, label %descriptor.invalid.1509
descriptor.invalid.1509:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1508:
  %descriptor.initialized.status.1510 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1494, i32 %local.check.extent.1495)
  %helper.ok.1511 = icmp eq i32 %descriptor.initialized.status.1510, 0
  br i1 %helper.ok.1511, label %helper.continue.1512, label %frame.failure.0
helper.continue.1512:
  br label %local.descriptor.checked.1493
local.descriptor.inactive.1492:
  br label %local.descriptor.checked.1493
local.descriptor.checked.1493:
  %local.is.active.1513 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1513, label %local.descriptor.active.1514, label %local.descriptor.inactive.1515
local.descriptor.active.1514:
  %local.check.offset.1517 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1518 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1519 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1520 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1521 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1522 = load i32, ptr %context.field.1521, align 4
  %stack.sub.1525 = sub i32 %local.check.owner.end.1520, %local.check.offset.1517
  %descriptor.owner.inside.1523 = icmp ule i32 %local.check.owner.end.1520, %context.value.1522
  %descriptor.offset.inside.1524 = icmp ule i32 %local.check.offset.1517, %local.check.owner.end.1520
  %descriptor.extent.inside.1526 = icmp ule i32 %local.check.extent.1518, %stack.sub.1525
  %descriptor.payload.inside.1527 = icmp ule i32 %local.check.payload.1519, %local.check.extent.1518
  %descriptor.owner.offset.valid.1528 = and i1 %descriptor.owner.inside.1523, %descriptor.offset.inside.1524
  %descriptor.range.inside.1530 = and i1 %descriptor.owner.offset.valid.1528, %descriptor.extent.inside.1526
  %descriptor.range.valid.1529 = and i1 %descriptor.range.inside.1530, %descriptor.payload.inside.1527
  br i1 %descriptor.range.valid.1529, label %descriptor.valid.1531, label %descriptor.invalid.1532
descriptor.invalid.1532:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1531:
  %descriptor.initialized.status.1533 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1517, i32 %local.check.extent.1518)
  %helper.ok.1534 = icmp eq i32 %descriptor.initialized.status.1533, 0
  br i1 %helper.ok.1534, label %helper.continue.1535, label %frame.failure.0
helper.continue.1535:
  br label %local.descriptor.checked.1516
local.descriptor.inactive.1515:
  br label %local.descriptor.checked.1516
local.descriptor.checked.1516:
  %step.status.1536 = call i32 @al_owning_charge_step(ptr %ctx, i32 11)
  %helper.ok.1537 = icmp eq i32 %step.status.1536, 0
  br i1 %helper.ok.1537, label %helper.continue.1538, label %frame.failure.0
helper.continue.1538:
  %stack.offset.1539 = add i32 0, 8
  %stack.offset.1540 = add i32 0, 8
  %context.field.1541 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1542 = load i32, ptr %context.field.1541, align 4
  %stack.offset.1543 = add i32 %context.value.1542, %stack.offset.1540
  %reserve.status.1544 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1543, i32 12)
  %reserve.ok.1545 = icmp eq i32 %reserve.status.1544, 0
  br i1 %reserve.ok.1545, label %reserve.continue.1546, label %frame.failure.0
reserve.continue.1546:
  %stack.offset.1547 = add i32 %context.value.1542, 0
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.1547, i32 %context.value.1368, i32 8, i32 8, i32 1, i32 6)
  %context.field.1548 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1549 = load i32, ptr %context.field.1548, align 4
  %runtime.ok.1550 = icmp eq i32 %context.value.1549, 0
  br i1 %runtime.ok.1550, label %runtime.continue.1551, label %frame.failure.0
runtime.continue.1551:
  %stack.offset.1552 = add i32 0, 8
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 6, i32 %context.value.1542, i32 %stack.offset.1540, i32 %stack.offset.1539, i32 0, i32 0)
  %context.field.1553 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1554 = load i32, ptr %context.field.1553, align 4
  %runtime.ok.1555 = icmp eq i32 %context.value.1554, 0
  br i1 %runtime.ok.1555, label %runtime.continue.1556, label %frame.failure.0
runtime.continue.1556:
  %context.field.1557 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1558 = load i32, ptr %context.field.1557, align 4
  %stack.sub.1561 = sub i32 %stack.offset.1543, %context.value.1542
  %descriptor.owner.inside.1559 = icmp ule i32 %stack.offset.1543, %context.value.1558
  %descriptor.offset.inside.1560 = icmp ule i32 %context.value.1542, %stack.offset.1543
  %descriptor.extent.inside.1562 = icmp ule i32 %stack.offset.1540, %stack.sub.1561
  %descriptor.payload.inside.1563 = icmp ule i32 %stack.offset.1539, %stack.offset.1540
  %descriptor.owner.offset.valid.1564 = and i1 %descriptor.owner.inside.1559, %descriptor.offset.inside.1560
  %descriptor.range.inside.1566 = and i1 %descriptor.owner.offset.valid.1564, %descriptor.extent.inside.1562
  %descriptor.range.valid.1565 = and i1 %descriptor.range.inside.1566, %descriptor.payload.inside.1563
  %descriptor.type.valid.1567 = icmp eq i32 6, 6
  %descriptor.valid.1568 = and i1 %descriptor.range.valid.1565, %descriptor.type.valid.1567
  br i1 %descriptor.valid.1568, label %descriptor.valid.1569, label %descriptor.invalid.1570
descriptor.invalid.1570:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1569:
  %descriptor.initialized.status.1571 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.1542, i32 %stack.offset.1540)
  %helper.ok.1572 = icmp eq i32 %descriptor.initialized.status.1571, 0
  br i1 %helper.ok.1572, label %helper.continue.1573, label %frame.failure.0
helper.continue.1573:
  %local.is.active.1574 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1574, label %local.descriptor.active.1575, label %local.descriptor.inactive.1576
local.descriptor.active.1575:
  %local.check.offset.1578 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1579 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1580 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1581 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1582 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1583 = load i32, ptr %context.field.1582, align 4
  %stack.sub.1586 = sub i32 %local.check.owner.end.1581, %local.check.offset.1578
  %descriptor.owner.inside.1584 = icmp ule i32 %local.check.owner.end.1581, %context.value.1583
  %descriptor.offset.inside.1585 = icmp ule i32 %local.check.offset.1578, %local.check.owner.end.1581
  %descriptor.extent.inside.1587 = icmp ule i32 %local.check.extent.1579, %stack.sub.1586
  %descriptor.payload.inside.1588 = icmp ule i32 %local.check.payload.1580, %local.check.extent.1579
  %descriptor.owner.offset.valid.1589 = and i1 %descriptor.owner.inside.1584, %descriptor.offset.inside.1585
  %descriptor.range.inside.1591 = and i1 %descriptor.owner.offset.valid.1589, %descriptor.extent.inside.1587
  %descriptor.range.valid.1590 = and i1 %descriptor.range.inside.1591, %descriptor.payload.inside.1588
  br i1 %descriptor.range.valid.1590, label %descriptor.valid.1592, label %descriptor.invalid.1593
descriptor.invalid.1593:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1592:
  %descriptor.initialized.status.1594 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1578, i32 %local.check.extent.1579)
  %helper.ok.1595 = icmp eq i32 %descriptor.initialized.status.1594, 0
  br i1 %helper.ok.1595, label %helper.continue.1596, label %frame.failure.0
helper.continue.1596:
  br label %local.descriptor.checked.1577
local.descriptor.inactive.1576:
  br label %local.descriptor.checked.1577
local.descriptor.checked.1577:
  %local.is.active.1597 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1597, label %local.descriptor.active.1598, label %local.descriptor.inactive.1599
local.descriptor.active.1598:
  %local.check.offset.1601 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1602 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1603 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1604 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1605 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1606 = load i32, ptr %context.field.1605, align 4
  %stack.sub.1609 = sub i32 %local.check.owner.end.1604, %local.check.offset.1601
  %descriptor.owner.inside.1607 = icmp ule i32 %local.check.owner.end.1604, %context.value.1606
  %descriptor.offset.inside.1608 = icmp ule i32 %local.check.offset.1601, %local.check.owner.end.1604
  %descriptor.extent.inside.1610 = icmp ule i32 %local.check.extent.1602, %stack.sub.1609
  %descriptor.payload.inside.1611 = icmp ule i32 %local.check.payload.1603, %local.check.extent.1602
  %descriptor.owner.offset.valid.1612 = and i1 %descriptor.owner.inside.1607, %descriptor.offset.inside.1608
  %descriptor.range.inside.1614 = and i1 %descriptor.owner.offset.valid.1612, %descriptor.extent.inside.1610
  %descriptor.range.valid.1613 = and i1 %descriptor.range.inside.1614, %descriptor.payload.inside.1611
  br i1 %descriptor.range.valid.1613, label %descriptor.valid.1615, label %descriptor.invalid.1616
descriptor.invalid.1616:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1615:
  %descriptor.initialized.status.1617 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1601, i32 %local.check.extent.1602)
  %helper.ok.1618 = icmp eq i32 %descriptor.initialized.status.1617, 0
  br i1 %helper.ok.1618, label %helper.continue.1619, label %frame.failure.0
helper.continue.1619:
  br label %local.descriptor.checked.1600
local.descriptor.inactive.1599:
  br label %local.descriptor.checked.1600
local.descriptor.checked.1600:
  %local.is.active.1620 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1620, label %local.descriptor.active.1621, label %local.descriptor.inactive.1622
local.descriptor.active.1621:
  %local.check.offset.1624 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1625 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1626 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1627 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1628 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1629 = load i32, ptr %context.field.1628, align 4
  %stack.sub.1632 = sub i32 %local.check.owner.end.1627, %local.check.offset.1624
  %descriptor.owner.inside.1630 = icmp ule i32 %local.check.owner.end.1627, %context.value.1629
  %descriptor.offset.inside.1631 = icmp ule i32 %local.check.offset.1624, %local.check.owner.end.1627
  %descriptor.extent.inside.1633 = icmp ule i32 %local.check.extent.1625, %stack.sub.1632
  %descriptor.payload.inside.1634 = icmp ule i32 %local.check.payload.1626, %local.check.extent.1625
  %descriptor.owner.offset.valid.1635 = and i1 %descriptor.owner.inside.1630, %descriptor.offset.inside.1631
  %descriptor.range.inside.1637 = and i1 %descriptor.owner.offset.valid.1635, %descriptor.extent.inside.1633
  %descriptor.range.valid.1636 = and i1 %descriptor.range.inside.1637, %descriptor.payload.inside.1634
  br i1 %descriptor.range.valid.1636, label %descriptor.valid.1638, label %descriptor.invalid.1639
descriptor.invalid.1639:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1638:
  %descriptor.initialized.status.1640 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1624, i32 %local.check.extent.1625)
  %helper.ok.1641 = icmp eq i32 %descriptor.initialized.status.1640, 0
  br i1 %helper.ok.1641, label %helper.continue.1642, label %frame.failure.0
helper.continue.1642:
  br label %local.descriptor.checked.1623
local.descriptor.inactive.1622:
  br label %local.descriptor.checked.1623
local.descriptor.checked.1623:
  %local.is.active.1643 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1643, label %local.descriptor.active.1644, label %local.descriptor.inactive.1645
local.descriptor.active.1644:
  %local.check.offset.1647 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1648 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1649 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1650 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1651 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1652 = load i32, ptr %context.field.1651, align 4
  %stack.sub.1655 = sub i32 %local.check.owner.end.1650, %local.check.offset.1647
  %descriptor.owner.inside.1653 = icmp ule i32 %local.check.owner.end.1650, %context.value.1652
  %descriptor.offset.inside.1654 = icmp ule i32 %local.check.offset.1647, %local.check.owner.end.1650
  %descriptor.extent.inside.1656 = icmp ule i32 %local.check.extent.1648, %stack.sub.1655
  %descriptor.payload.inside.1657 = icmp ule i32 %local.check.payload.1649, %local.check.extent.1648
  %descriptor.owner.offset.valid.1658 = and i1 %descriptor.owner.inside.1653, %descriptor.offset.inside.1654
  %descriptor.range.inside.1660 = and i1 %descriptor.owner.offset.valid.1658, %descriptor.extent.inside.1656
  %descriptor.range.valid.1659 = and i1 %descriptor.range.inside.1660, %descriptor.payload.inside.1657
  br i1 %descriptor.range.valid.1659, label %descriptor.valid.1661, label %descriptor.invalid.1662
descriptor.invalid.1662:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1661:
  %descriptor.initialized.status.1663 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1647, i32 %local.check.extent.1648)
  %helper.ok.1664 = icmp eq i32 %descriptor.initialized.status.1663, 0
  br i1 %helper.ok.1664, label %helper.continue.1665, label %frame.failure.0
helper.continue.1665:
  br label %local.descriptor.checked.1646
local.descriptor.inactive.1645:
  br label %local.descriptor.checked.1646
local.descriptor.checked.1646:
  %local.is.active.1666 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1666, label %local.descriptor.active.1667, label %local.descriptor.inactive.1668
local.descriptor.active.1667:
  %local.check.offset.1670 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1671 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1672 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1673 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1674 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1675 = load i32, ptr %context.field.1674, align 4
  %stack.sub.1678 = sub i32 %local.check.owner.end.1673, %local.check.offset.1670
  %descriptor.owner.inside.1676 = icmp ule i32 %local.check.owner.end.1673, %context.value.1675
  %descriptor.offset.inside.1677 = icmp ule i32 %local.check.offset.1670, %local.check.owner.end.1673
  %descriptor.extent.inside.1679 = icmp ule i32 %local.check.extent.1671, %stack.sub.1678
  %descriptor.payload.inside.1680 = icmp ule i32 %local.check.payload.1672, %local.check.extent.1671
  %descriptor.owner.offset.valid.1681 = and i1 %descriptor.owner.inside.1676, %descriptor.offset.inside.1677
  %descriptor.range.inside.1683 = and i1 %descriptor.owner.offset.valid.1681, %descriptor.extent.inside.1679
  %descriptor.range.valid.1682 = and i1 %descriptor.range.inside.1683, %descriptor.payload.inside.1680
  br i1 %descriptor.range.valid.1682, label %descriptor.valid.1684, label %descriptor.invalid.1685
descriptor.invalid.1685:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1684:
  %descriptor.initialized.status.1686 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1670, i32 %local.check.extent.1671)
  %helper.ok.1687 = icmp eq i32 %descriptor.initialized.status.1686, 0
  br i1 %helper.ok.1687, label %helper.continue.1688, label %frame.failure.0
helper.continue.1688:
  br label %local.descriptor.checked.1669
local.descriptor.inactive.1668:
  br label %local.descriptor.checked.1669
local.descriptor.checked.1669:
  %local.is.active.1689 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1689, label %local.descriptor.active.1690, label %local.descriptor.inactive.1691
local.descriptor.active.1690:
  %local.check.offset.1693 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1694 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1695 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1696 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1697 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1698 = load i32, ptr %context.field.1697, align 4
  %stack.sub.1701 = sub i32 %local.check.owner.end.1696, %local.check.offset.1693
  %descriptor.owner.inside.1699 = icmp ule i32 %local.check.owner.end.1696, %context.value.1698
  %descriptor.offset.inside.1700 = icmp ule i32 %local.check.offset.1693, %local.check.owner.end.1696
  %descriptor.extent.inside.1702 = icmp ule i32 %local.check.extent.1694, %stack.sub.1701
  %descriptor.payload.inside.1703 = icmp ule i32 %local.check.payload.1695, %local.check.extent.1694
  %descriptor.owner.offset.valid.1704 = and i1 %descriptor.owner.inside.1699, %descriptor.offset.inside.1700
  %descriptor.range.inside.1706 = and i1 %descriptor.owner.offset.valid.1704, %descriptor.extent.inside.1702
  %descriptor.range.valid.1705 = and i1 %descriptor.range.inside.1706, %descriptor.payload.inside.1703
  br i1 %descriptor.range.valid.1705, label %descriptor.valid.1707, label %descriptor.invalid.1708
descriptor.invalid.1708:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1707:
  %descriptor.initialized.status.1709 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1693, i32 %local.check.extent.1694)
  %helper.ok.1710 = icmp eq i32 %descriptor.initialized.status.1709, 0
  br i1 %helper.ok.1710, label %helper.continue.1711, label %frame.failure.0
helper.continue.1711:
  br label %local.descriptor.checked.1692
local.descriptor.inactive.1691:
  br label %local.descriptor.checked.1692
local.descriptor.checked.1692:
  %step.status.1712 = call i32 @al_owning_charge_step(ptr %ctx, i32 13)
  %helper.ok.1713 = icmp eq i32 %step.status.1712, 0
  br i1 %helper.ok.1713, label %helper.continue.1714, label %frame.failure.0
helper.continue.1714:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 6, i32 %context.value.1542, i32 %stack.offset.1540, i32 %stack.offset.1539, i32 0, i32 0)
  %context.field.1715 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1716 = load i32, ptr %context.field.1715, align 4
  %runtime.ok.1717 = icmp eq i32 %context.value.1716, 0
  br i1 %runtime.ok.1717, label %runtime.continue.1718, label %frame.failure.0
runtime.continue.1718:
  %local.is.active.1719 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1719, label %local.descriptor.active.1720, label %local.descriptor.inactive.1721
local.descriptor.active.1720:
  %local.check.offset.1723 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1724 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1725 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1726 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1727 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1728 = load i32, ptr %context.field.1727, align 4
  %stack.sub.1731 = sub i32 %local.check.owner.end.1726, %local.check.offset.1723
  %descriptor.owner.inside.1729 = icmp ule i32 %local.check.owner.end.1726, %context.value.1728
  %descriptor.offset.inside.1730 = icmp ule i32 %local.check.offset.1723, %local.check.owner.end.1726
  %descriptor.extent.inside.1732 = icmp ule i32 %local.check.extent.1724, %stack.sub.1731
  %descriptor.payload.inside.1733 = icmp ule i32 %local.check.payload.1725, %local.check.extent.1724
  %descriptor.owner.offset.valid.1734 = and i1 %descriptor.owner.inside.1729, %descriptor.offset.inside.1730
  %descriptor.range.inside.1736 = and i1 %descriptor.owner.offset.valid.1734, %descriptor.extent.inside.1732
  %descriptor.range.valid.1735 = and i1 %descriptor.range.inside.1736, %descriptor.payload.inside.1733
  br i1 %descriptor.range.valid.1735, label %descriptor.valid.1737, label %descriptor.invalid.1738
descriptor.invalid.1738:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1737:
  %descriptor.initialized.status.1739 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1723, i32 %local.check.extent.1724)
  %helper.ok.1740 = icmp eq i32 %descriptor.initialized.status.1739, 0
  br i1 %helper.ok.1740, label %helper.continue.1741, label %frame.failure.0
helper.continue.1741:
  br label %local.descriptor.checked.1722
local.descriptor.inactive.1721:
  br label %local.descriptor.checked.1722
local.descriptor.checked.1722:
  %local.is.active.1742 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1742, label %local.descriptor.active.1743, label %local.descriptor.inactive.1744
local.descriptor.active.1743:
  %local.check.offset.1746 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1747 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1748 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1749 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1750 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1751 = load i32, ptr %context.field.1750, align 4
  %stack.sub.1754 = sub i32 %local.check.owner.end.1749, %local.check.offset.1746
  %descriptor.owner.inside.1752 = icmp ule i32 %local.check.owner.end.1749, %context.value.1751
  %descriptor.offset.inside.1753 = icmp ule i32 %local.check.offset.1746, %local.check.owner.end.1749
  %descriptor.extent.inside.1755 = icmp ule i32 %local.check.extent.1747, %stack.sub.1754
  %descriptor.payload.inside.1756 = icmp ule i32 %local.check.payload.1748, %local.check.extent.1747
  %descriptor.owner.offset.valid.1757 = and i1 %descriptor.owner.inside.1752, %descriptor.offset.inside.1753
  %descriptor.range.inside.1759 = and i1 %descriptor.owner.offset.valid.1757, %descriptor.extent.inside.1755
  %descriptor.range.valid.1758 = and i1 %descriptor.range.inside.1759, %descriptor.payload.inside.1756
  br i1 %descriptor.range.valid.1758, label %descriptor.valid.1760, label %descriptor.invalid.1761
descriptor.invalid.1761:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1760:
  %descriptor.initialized.status.1762 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1746, i32 %local.check.extent.1747)
  %helper.ok.1763 = icmp eq i32 %descriptor.initialized.status.1762, 0
  br i1 %helper.ok.1763, label %helper.continue.1764, label %frame.failure.0
helper.continue.1764:
  br label %local.descriptor.checked.1745
local.descriptor.inactive.1744:
  br label %local.descriptor.checked.1745
local.descriptor.checked.1745:
  %local.is.active.1765 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1765, label %local.descriptor.active.1766, label %local.descriptor.inactive.1767
local.descriptor.active.1766:
  %local.check.offset.1769 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1770 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1771 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1772 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1773 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1774 = load i32, ptr %context.field.1773, align 4
  %stack.sub.1777 = sub i32 %local.check.owner.end.1772, %local.check.offset.1769
  %descriptor.owner.inside.1775 = icmp ule i32 %local.check.owner.end.1772, %context.value.1774
  %descriptor.offset.inside.1776 = icmp ule i32 %local.check.offset.1769, %local.check.owner.end.1772
  %descriptor.extent.inside.1778 = icmp ule i32 %local.check.extent.1770, %stack.sub.1777
  %descriptor.payload.inside.1779 = icmp ule i32 %local.check.payload.1771, %local.check.extent.1770
  %descriptor.owner.offset.valid.1780 = and i1 %descriptor.owner.inside.1775, %descriptor.offset.inside.1776
  %descriptor.range.inside.1782 = and i1 %descriptor.owner.offset.valid.1780, %descriptor.extent.inside.1778
  %descriptor.range.valid.1781 = and i1 %descriptor.range.inside.1782, %descriptor.payload.inside.1779
  br i1 %descriptor.range.valid.1781, label %descriptor.valid.1783, label %descriptor.invalid.1784
descriptor.invalid.1784:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1783:
  %descriptor.initialized.status.1785 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1769, i32 %local.check.extent.1770)
  %helper.ok.1786 = icmp eq i32 %descriptor.initialized.status.1785, 0
  br i1 %helper.ok.1786, label %helper.continue.1787, label %frame.failure.0
helper.continue.1787:
  br label %local.descriptor.checked.1768
local.descriptor.inactive.1767:
  br label %local.descriptor.checked.1768
local.descriptor.checked.1768:
  %local.is.active.1788 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1788, label %local.descriptor.active.1789, label %local.descriptor.inactive.1790
local.descriptor.active.1789:
  %local.check.offset.1792 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1793 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1794 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1795 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1796 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1797 = load i32, ptr %context.field.1796, align 4
  %stack.sub.1800 = sub i32 %local.check.owner.end.1795, %local.check.offset.1792
  %descriptor.owner.inside.1798 = icmp ule i32 %local.check.owner.end.1795, %context.value.1797
  %descriptor.offset.inside.1799 = icmp ule i32 %local.check.offset.1792, %local.check.owner.end.1795
  %descriptor.extent.inside.1801 = icmp ule i32 %local.check.extent.1793, %stack.sub.1800
  %descriptor.payload.inside.1802 = icmp ule i32 %local.check.payload.1794, %local.check.extent.1793
  %descriptor.owner.offset.valid.1803 = and i1 %descriptor.owner.inside.1798, %descriptor.offset.inside.1799
  %descriptor.range.inside.1805 = and i1 %descriptor.owner.offset.valid.1803, %descriptor.extent.inside.1801
  %descriptor.range.valid.1804 = and i1 %descriptor.range.inside.1805, %descriptor.payload.inside.1802
  br i1 %descriptor.range.valid.1804, label %descriptor.valid.1806, label %descriptor.invalid.1807
descriptor.invalid.1807:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1806:
  %descriptor.initialized.status.1808 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1792, i32 %local.check.extent.1793)
  %helper.ok.1809 = icmp eq i32 %descriptor.initialized.status.1808, 0
  br i1 %helper.ok.1809, label %helper.continue.1810, label %frame.failure.0
helper.continue.1810:
  br label %local.descriptor.checked.1791
local.descriptor.inactive.1790:
  br label %local.descriptor.checked.1791
local.descriptor.checked.1791:
  %local.is.active.1811 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1811, label %local.descriptor.active.1812, label %local.descriptor.inactive.1813
local.descriptor.active.1812:
  %local.check.offset.1815 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1816 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1817 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1818 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1819 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1820 = load i32, ptr %context.field.1819, align 4
  %stack.sub.1823 = sub i32 %local.check.owner.end.1818, %local.check.offset.1815
  %descriptor.owner.inside.1821 = icmp ule i32 %local.check.owner.end.1818, %context.value.1820
  %descriptor.offset.inside.1822 = icmp ule i32 %local.check.offset.1815, %local.check.owner.end.1818
  %descriptor.extent.inside.1824 = icmp ule i32 %local.check.extent.1816, %stack.sub.1823
  %descriptor.payload.inside.1825 = icmp ule i32 %local.check.payload.1817, %local.check.extent.1816
  %descriptor.owner.offset.valid.1826 = and i1 %descriptor.owner.inside.1821, %descriptor.offset.inside.1822
  %descriptor.range.inside.1828 = and i1 %descriptor.owner.offset.valid.1826, %descriptor.extent.inside.1824
  %descriptor.range.valid.1827 = and i1 %descriptor.range.inside.1828, %descriptor.payload.inside.1825
  br i1 %descriptor.range.valid.1827, label %descriptor.valid.1829, label %descriptor.invalid.1830
descriptor.invalid.1830:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1829:
  %descriptor.initialized.status.1831 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1815, i32 %local.check.extent.1816)
  %helper.ok.1832 = icmp eq i32 %descriptor.initialized.status.1831, 0
  br i1 %helper.ok.1832, label %helper.continue.1833, label %frame.failure.0
helper.continue.1833:
  br label %local.descriptor.checked.1814
local.descriptor.inactive.1813:
  br label %local.descriptor.checked.1814
local.descriptor.checked.1814:
  %local.is.active.1834 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1834, label %local.descriptor.active.1835, label %local.descriptor.inactive.1836
local.descriptor.active.1835:
  %local.check.offset.1838 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1839 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1840 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1841 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1842 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1843 = load i32, ptr %context.field.1842, align 4
  %stack.sub.1846 = sub i32 %local.check.owner.end.1841, %local.check.offset.1838
  %descriptor.owner.inside.1844 = icmp ule i32 %local.check.owner.end.1841, %context.value.1843
  %descriptor.offset.inside.1845 = icmp ule i32 %local.check.offset.1838, %local.check.owner.end.1841
  %descriptor.extent.inside.1847 = icmp ule i32 %local.check.extent.1839, %stack.sub.1846
  %descriptor.payload.inside.1848 = icmp ule i32 %local.check.payload.1840, %local.check.extent.1839
  %descriptor.owner.offset.valid.1849 = and i1 %descriptor.owner.inside.1844, %descriptor.offset.inside.1845
  %descriptor.range.inside.1851 = and i1 %descriptor.owner.offset.valid.1849, %descriptor.extent.inside.1847
  %descriptor.range.valid.1850 = and i1 %descriptor.range.inside.1851, %descriptor.payload.inside.1848
  br i1 %descriptor.range.valid.1850, label %descriptor.valid.1852, label %descriptor.invalid.1853
descriptor.invalid.1853:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1852:
  %descriptor.initialized.status.1854 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1838, i32 %local.check.extent.1839)
  %helper.ok.1855 = icmp eq i32 %descriptor.initialized.status.1854, 0
  br i1 %helper.ok.1855, label %helper.continue.1856, label %frame.failure.0
helper.continue.1856:
  br label %local.descriptor.checked.1837
local.descriptor.inactive.1836:
  br label %local.descriptor.checked.1837
local.descriptor.checked.1837:
  %context.field.1857 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1858 = load i32, ptr %context.field.1857, align 4
  %stack.sub.1859 = sub i32 %context.value.1858, %context.value.1363
  call void @al_owning_record_layout(ptr %ctx, i32 18, i32 0, i32 %context.value.1363, i32 %stack.sub.1859, i32 0, i32 0, i32 0)
  %context.field.1860 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1861 = load i32, ptr %context.field.1860, align 4
  %runtime.ok.1862 = icmp eq i32 %context.value.1861, 0
  br i1 %runtime.ok.1862, label %runtime.continue.1863, label %frame.failure.0
runtime.continue.1863:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.1363, i32 0, i32 0, i32 0)
  %context.field.1864 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1865 = load i32, ptr %context.field.1864, align 4
  %runtime.ok.1866 = icmp eq i32 %context.value.1865, 0
  br i1 %runtime.ok.1866, label %runtime.continue.1867, label %frame.failure.0
runtime.continue.1867:
  %local.is.active.1868 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1868, label %local.descriptor.active.1869, label %local.descriptor.inactive.1870
local.descriptor.active.1869:
  %local.check.offset.1872 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1873 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1874 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1875 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1876 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1877 = load i32, ptr %context.field.1876, align 4
  %stack.sub.1880 = sub i32 %local.check.owner.end.1875, %local.check.offset.1872
  %descriptor.owner.inside.1878 = icmp ule i32 %local.check.owner.end.1875, %context.value.1877
  %descriptor.offset.inside.1879 = icmp ule i32 %local.check.offset.1872, %local.check.owner.end.1875
  %descriptor.extent.inside.1881 = icmp ule i32 %local.check.extent.1873, %stack.sub.1880
  %descriptor.payload.inside.1882 = icmp ule i32 %local.check.payload.1874, %local.check.extent.1873
  %descriptor.owner.offset.valid.1883 = and i1 %descriptor.owner.inside.1878, %descriptor.offset.inside.1879
  %descriptor.range.inside.1885 = and i1 %descriptor.owner.offset.valid.1883, %descriptor.extent.inside.1881
  %descriptor.range.valid.1884 = and i1 %descriptor.range.inside.1885, %descriptor.payload.inside.1882
  br i1 %descriptor.range.valid.1884, label %descriptor.valid.1886, label %descriptor.invalid.1887
descriptor.invalid.1887:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1886:
  %descriptor.initialized.status.1888 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1872, i32 %local.check.extent.1873)
  %helper.ok.1889 = icmp eq i32 %descriptor.initialized.status.1888, 0
  br i1 %helper.ok.1889, label %helper.continue.1890, label %frame.failure.0
helper.continue.1890:
  br label %local.descriptor.checked.1871
local.descriptor.inactive.1870:
  br label %local.descriptor.checked.1871
local.descriptor.checked.1871:
  %local.is.active.1891 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1891, label %local.descriptor.active.1892, label %local.descriptor.inactive.1893
local.descriptor.active.1892:
  %local.check.offset.1895 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1896 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1897 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1898 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1899 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1900 = load i32, ptr %context.field.1899, align 4
  %stack.sub.1903 = sub i32 %local.check.owner.end.1898, %local.check.offset.1895
  %descriptor.owner.inside.1901 = icmp ule i32 %local.check.owner.end.1898, %context.value.1900
  %descriptor.offset.inside.1902 = icmp ule i32 %local.check.offset.1895, %local.check.owner.end.1898
  %descriptor.extent.inside.1904 = icmp ule i32 %local.check.extent.1896, %stack.sub.1903
  %descriptor.payload.inside.1905 = icmp ule i32 %local.check.payload.1897, %local.check.extent.1896
  %descriptor.owner.offset.valid.1906 = and i1 %descriptor.owner.inside.1901, %descriptor.offset.inside.1902
  %descriptor.range.inside.1908 = and i1 %descriptor.owner.offset.valid.1906, %descriptor.extent.inside.1904
  %descriptor.range.valid.1907 = and i1 %descriptor.range.inside.1908, %descriptor.payload.inside.1905
  br i1 %descriptor.range.valid.1907, label %descriptor.valid.1909, label %descriptor.invalid.1910
descriptor.invalid.1910:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1909:
  %descriptor.initialized.status.1911 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1895, i32 %local.check.extent.1896)
  %helper.ok.1912 = icmp eq i32 %descriptor.initialized.status.1911, 0
  br i1 %helper.ok.1912, label %helper.continue.1913, label %frame.failure.0
helper.continue.1913:
  br label %local.descriptor.checked.1894
local.descriptor.inactive.1893:
  br label %local.descriptor.checked.1894
local.descriptor.checked.1894:
  %local.is.active.1914 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1914, label %local.descriptor.active.1915, label %local.descriptor.inactive.1916
local.descriptor.active.1915:
  %local.check.offset.1918 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1919 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1920 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1921 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1922 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1923 = load i32, ptr %context.field.1922, align 4
  %stack.sub.1926 = sub i32 %local.check.owner.end.1921, %local.check.offset.1918
  %descriptor.owner.inside.1924 = icmp ule i32 %local.check.owner.end.1921, %context.value.1923
  %descriptor.offset.inside.1925 = icmp ule i32 %local.check.offset.1918, %local.check.owner.end.1921
  %descriptor.extent.inside.1927 = icmp ule i32 %local.check.extent.1919, %stack.sub.1926
  %descriptor.payload.inside.1928 = icmp ule i32 %local.check.payload.1920, %local.check.extent.1919
  %descriptor.owner.offset.valid.1929 = and i1 %descriptor.owner.inside.1924, %descriptor.offset.inside.1925
  %descriptor.range.inside.1931 = and i1 %descriptor.owner.offset.valid.1929, %descriptor.extent.inside.1927
  %descriptor.range.valid.1930 = and i1 %descriptor.range.inside.1931, %descriptor.payload.inside.1928
  br i1 %descriptor.range.valid.1930, label %descriptor.valid.1932, label %descriptor.invalid.1933
descriptor.invalid.1933:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1932:
  %descriptor.initialized.status.1934 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1918, i32 %local.check.extent.1919)
  %helper.ok.1935 = icmp eq i32 %descriptor.initialized.status.1934, 0
  br i1 %helper.ok.1935, label %helper.continue.1936, label %frame.failure.0
helper.continue.1936:
  br label %local.descriptor.checked.1917
local.descriptor.inactive.1916:
  br label %local.descriptor.checked.1917
local.descriptor.checked.1917:
  %local.is.active.1937 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1937, label %local.descriptor.active.1938, label %local.descriptor.inactive.1939
local.descriptor.active.1938:
  %local.check.offset.1941 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1942 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1943 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1944 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1945 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1946 = load i32, ptr %context.field.1945, align 4
  %stack.sub.1949 = sub i32 %local.check.owner.end.1944, %local.check.offset.1941
  %descriptor.owner.inside.1947 = icmp ule i32 %local.check.owner.end.1944, %context.value.1946
  %descriptor.offset.inside.1948 = icmp ule i32 %local.check.offset.1941, %local.check.owner.end.1944
  %descriptor.extent.inside.1950 = icmp ule i32 %local.check.extent.1942, %stack.sub.1949
  %descriptor.payload.inside.1951 = icmp ule i32 %local.check.payload.1943, %local.check.extent.1942
  %descriptor.owner.offset.valid.1952 = and i1 %descriptor.owner.inside.1947, %descriptor.offset.inside.1948
  %descriptor.range.inside.1954 = and i1 %descriptor.owner.offset.valid.1952, %descriptor.extent.inside.1950
  %descriptor.range.valid.1953 = and i1 %descriptor.range.inside.1954, %descriptor.payload.inside.1951
  br i1 %descriptor.range.valid.1953, label %descriptor.valid.1955, label %descriptor.invalid.1956
descriptor.invalid.1956:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1955:
  %descriptor.initialized.status.1957 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1941, i32 %local.check.extent.1942)
  %helper.ok.1958 = icmp eq i32 %descriptor.initialized.status.1957, 0
  br i1 %helper.ok.1958, label %helper.continue.1959, label %frame.failure.0
helper.continue.1959:
  br label %local.descriptor.checked.1940
local.descriptor.inactive.1939:
  br label %local.descriptor.checked.1940
local.descriptor.checked.1940:
  %local.is.active.1960 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1960, label %local.descriptor.active.1961, label %local.descriptor.inactive.1962
local.descriptor.active.1961:
  %local.check.offset.1964 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1965 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1966 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1967 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1968 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1969 = load i32, ptr %context.field.1968, align 4
  %stack.sub.1972 = sub i32 %local.check.owner.end.1967, %local.check.offset.1964
  %descriptor.owner.inside.1970 = icmp ule i32 %local.check.owner.end.1967, %context.value.1969
  %descriptor.offset.inside.1971 = icmp ule i32 %local.check.offset.1964, %local.check.owner.end.1967
  %descriptor.extent.inside.1973 = icmp ule i32 %local.check.extent.1965, %stack.sub.1972
  %descriptor.payload.inside.1974 = icmp ule i32 %local.check.payload.1966, %local.check.extent.1965
  %descriptor.owner.offset.valid.1975 = and i1 %descriptor.owner.inside.1970, %descriptor.offset.inside.1971
  %descriptor.range.inside.1977 = and i1 %descriptor.owner.offset.valid.1975, %descriptor.extent.inside.1973
  %descriptor.range.valid.1976 = and i1 %descriptor.range.inside.1977, %descriptor.payload.inside.1974
  br i1 %descriptor.range.valid.1976, label %descriptor.valid.1978, label %descriptor.invalid.1979
descriptor.invalid.1979:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1978:
  %descriptor.initialized.status.1980 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1964, i32 %local.check.extent.1965)
  %helper.ok.1981 = icmp eq i32 %descriptor.initialized.status.1980, 0
  br i1 %helper.ok.1981, label %helper.continue.1982, label %frame.failure.0
helper.continue.1982:
  br label %local.descriptor.checked.1963
local.descriptor.inactive.1962:
  br label %local.descriptor.checked.1963
local.descriptor.checked.1963:
  %local.is.active.1983 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1983, label %local.descriptor.active.1984, label %local.descriptor.inactive.1985
local.descriptor.active.1984:
  %local.check.offset.1987 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1988 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1989 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1990 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1991 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1992 = load i32, ptr %context.field.1991, align 4
  %stack.sub.1995 = sub i32 %local.check.owner.end.1990, %local.check.offset.1987
  %descriptor.owner.inside.1993 = icmp ule i32 %local.check.owner.end.1990, %context.value.1992
  %descriptor.offset.inside.1994 = icmp ule i32 %local.check.offset.1987, %local.check.owner.end.1990
  %descriptor.extent.inside.1996 = icmp ule i32 %local.check.extent.1988, %stack.sub.1995
  %descriptor.payload.inside.1997 = icmp ule i32 %local.check.payload.1989, %local.check.extent.1988
  %descriptor.owner.offset.valid.1998 = and i1 %descriptor.owner.inside.1993, %descriptor.offset.inside.1994
  %descriptor.range.inside.2000 = and i1 %descriptor.owner.offset.valid.1998, %descriptor.extent.inside.1996
  %descriptor.range.valid.1999 = and i1 %descriptor.range.inside.2000, %descriptor.payload.inside.1997
  br i1 %descriptor.range.valid.1999, label %descriptor.valid.2001, label %descriptor.invalid.2002
descriptor.invalid.2002:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2001:
  %descriptor.initialized.status.2003 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1987, i32 %local.check.extent.1988)
  %helper.ok.2004 = icmp eq i32 %descriptor.initialized.status.2003, 0
  br i1 %helper.ok.2004, label %helper.continue.2005, label %frame.failure.0
helper.continue.2005:
  br label %local.descriptor.checked.1986
local.descriptor.inactive.1985:
  br label %local.descriptor.checked.1986
local.descriptor.checked.1986:
  %step.status.2006 = call i32 @al_owning_charge_step(ptr %ctx, i32 14)
  %helper.ok.2007 = icmp eq i32 %step.status.2006, 0
  br i1 %helper.ok.2007, label %helper.continue.2008, label %frame.failure.0
helper.continue.2008:
  %context.field.2009 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2010 = load i32, ptr %context.field.2009, align 4
  %stack.offset.2011 = add i32 %context.value.2010, 8
  %reserve.status.2012 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.2011, i32 15)
  %reserve.ok.2013 = icmp eq i32 %reserve.status.2012, 0
  br i1 %reserve.ok.2013, label %reserve.continue.2014, label %frame.failure.0
reserve.continue.2014:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.2010, i64 888, i32 1)
  %context.field.2015 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2016 = load i32, ptr %context.field.2015, align 4
  %runtime.ok.2017 = icmp eq i32 %context.value.2016, 0
  br i1 %runtime.ok.2017, label %runtime.continue.2018, label %frame.failure.0
runtime.continue.2018:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.2019 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2020 = load i32, ptr %context.field.2019, align 4
  %runtime.ok.2021 = icmp eq i32 %context.value.2020, 0
  br i1 %runtime.ok.2021, label %runtime.continue.2022, label %frame.failure.0
runtime.continue.2022:
  %context.field.2023 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2024 = load i32, ptr %context.field.2023, align 4
  %stack.sub.2027 = sub i32 %stack.offset.2011, %context.value.2010
  %descriptor.owner.inside.2025 = icmp ule i32 %stack.offset.2011, %context.value.2024
  %descriptor.offset.inside.2026 = icmp ule i32 %context.value.2010, %stack.offset.2011
  %descriptor.extent.inside.2028 = icmp ule i32 8, %stack.sub.2027
  %descriptor.payload.inside.2029 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.2030 = and i1 %descriptor.owner.inside.2025, %descriptor.offset.inside.2026
  %descriptor.range.inside.2032 = and i1 %descriptor.owner.offset.valid.2030, %descriptor.extent.inside.2028
  %descriptor.range.valid.2031 = and i1 %descriptor.range.inside.2032, %descriptor.payload.inside.2029
  %descriptor.type.valid.2033 = icmp eq i32 1, 1
  %descriptor.valid.2034 = and i1 %descriptor.range.valid.2031, %descriptor.type.valid.2033
  br i1 %descriptor.valid.2034, label %descriptor.valid.2035, label %descriptor.invalid.2036
descriptor.invalid.2036:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2035:
  %descriptor.initialized.status.2037 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.2010, i32 8)
  %helper.ok.2038 = icmp eq i32 %descriptor.initialized.status.2037, 0
  br i1 %helper.ok.2038, label %helper.continue.2039, label %frame.failure.0
helper.continue.2039:
  %local.is.active.2040 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2040, label %local.descriptor.active.2041, label %local.descriptor.inactive.2042
local.descriptor.active.2041:
  %local.check.offset.2044 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2045 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2046 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2047 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2048 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2049 = load i32, ptr %context.field.2048, align 4
  %stack.sub.2052 = sub i32 %local.check.owner.end.2047, %local.check.offset.2044
  %descriptor.owner.inside.2050 = icmp ule i32 %local.check.owner.end.2047, %context.value.2049
  %descriptor.offset.inside.2051 = icmp ule i32 %local.check.offset.2044, %local.check.owner.end.2047
  %descriptor.extent.inside.2053 = icmp ule i32 %local.check.extent.2045, %stack.sub.2052
  %descriptor.payload.inside.2054 = icmp ule i32 %local.check.payload.2046, %local.check.extent.2045
  %descriptor.owner.offset.valid.2055 = and i1 %descriptor.owner.inside.2050, %descriptor.offset.inside.2051
  %descriptor.range.inside.2057 = and i1 %descriptor.owner.offset.valid.2055, %descriptor.extent.inside.2053
  %descriptor.range.valid.2056 = and i1 %descriptor.range.inside.2057, %descriptor.payload.inside.2054
  br i1 %descriptor.range.valid.2056, label %descriptor.valid.2058, label %descriptor.invalid.2059
descriptor.invalid.2059:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2058:
  %descriptor.initialized.status.2060 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2044, i32 %local.check.extent.2045)
  %helper.ok.2061 = icmp eq i32 %descriptor.initialized.status.2060, 0
  br i1 %helper.ok.2061, label %helper.continue.2062, label %frame.failure.0
helper.continue.2062:
  br label %local.descriptor.checked.2043
local.descriptor.inactive.2042:
  br label %local.descriptor.checked.2043
local.descriptor.checked.2043:
  %local.is.active.2063 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2063, label %local.descriptor.active.2064, label %local.descriptor.inactive.2065
local.descriptor.active.2064:
  %local.check.offset.2067 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2068 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2069 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2070 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2071 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2072 = load i32, ptr %context.field.2071, align 4
  %stack.sub.2075 = sub i32 %local.check.owner.end.2070, %local.check.offset.2067
  %descriptor.owner.inside.2073 = icmp ule i32 %local.check.owner.end.2070, %context.value.2072
  %descriptor.offset.inside.2074 = icmp ule i32 %local.check.offset.2067, %local.check.owner.end.2070
  %descriptor.extent.inside.2076 = icmp ule i32 %local.check.extent.2068, %stack.sub.2075
  %descriptor.payload.inside.2077 = icmp ule i32 %local.check.payload.2069, %local.check.extent.2068
  %descriptor.owner.offset.valid.2078 = and i1 %descriptor.owner.inside.2073, %descriptor.offset.inside.2074
  %descriptor.range.inside.2080 = and i1 %descriptor.owner.offset.valid.2078, %descriptor.extent.inside.2076
  %descriptor.range.valid.2079 = and i1 %descriptor.range.inside.2080, %descriptor.payload.inside.2077
  br i1 %descriptor.range.valid.2079, label %descriptor.valid.2081, label %descriptor.invalid.2082
descriptor.invalid.2082:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2081:
  %descriptor.initialized.status.2083 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2067, i32 %local.check.extent.2068)
  %helper.ok.2084 = icmp eq i32 %descriptor.initialized.status.2083, 0
  br i1 %helper.ok.2084, label %helper.continue.2085, label %frame.failure.0
helper.continue.2085:
  br label %local.descriptor.checked.2066
local.descriptor.inactive.2065:
  br label %local.descriptor.checked.2066
local.descriptor.checked.2066:
  %local.is.active.2086 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2086, label %local.descriptor.active.2087, label %local.descriptor.inactive.2088
local.descriptor.active.2087:
  %local.check.offset.2090 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2091 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2092 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2093 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2094 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2095 = load i32, ptr %context.field.2094, align 4
  %stack.sub.2098 = sub i32 %local.check.owner.end.2093, %local.check.offset.2090
  %descriptor.owner.inside.2096 = icmp ule i32 %local.check.owner.end.2093, %context.value.2095
  %descriptor.offset.inside.2097 = icmp ule i32 %local.check.offset.2090, %local.check.owner.end.2093
  %descriptor.extent.inside.2099 = icmp ule i32 %local.check.extent.2091, %stack.sub.2098
  %descriptor.payload.inside.2100 = icmp ule i32 %local.check.payload.2092, %local.check.extent.2091
  %descriptor.owner.offset.valid.2101 = and i1 %descriptor.owner.inside.2096, %descriptor.offset.inside.2097
  %descriptor.range.inside.2103 = and i1 %descriptor.owner.offset.valid.2101, %descriptor.extent.inside.2099
  %descriptor.range.valid.2102 = and i1 %descriptor.range.inside.2103, %descriptor.payload.inside.2100
  br i1 %descriptor.range.valid.2102, label %descriptor.valid.2104, label %descriptor.invalid.2105
descriptor.invalid.2105:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2104:
  %descriptor.initialized.status.2106 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2090, i32 %local.check.extent.2091)
  %helper.ok.2107 = icmp eq i32 %descriptor.initialized.status.2106, 0
  br i1 %helper.ok.2107, label %helper.continue.2108, label %frame.failure.0
helper.continue.2108:
  br label %local.descriptor.checked.2089
local.descriptor.inactive.2088:
  br label %local.descriptor.checked.2089
local.descriptor.checked.2089:
  %local.is.active.2109 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2109, label %local.descriptor.active.2110, label %local.descriptor.inactive.2111
local.descriptor.active.2110:
  %local.check.offset.2113 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2114 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2115 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2116 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2117 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2118 = load i32, ptr %context.field.2117, align 4
  %stack.sub.2121 = sub i32 %local.check.owner.end.2116, %local.check.offset.2113
  %descriptor.owner.inside.2119 = icmp ule i32 %local.check.owner.end.2116, %context.value.2118
  %descriptor.offset.inside.2120 = icmp ule i32 %local.check.offset.2113, %local.check.owner.end.2116
  %descriptor.extent.inside.2122 = icmp ule i32 %local.check.extent.2114, %stack.sub.2121
  %descriptor.payload.inside.2123 = icmp ule i32 %local.check.payload.2115, %local.check.extent.2114
  %descriptor.owner.offset.valid.2124 = and i1 %descriptor.owner.inside.2119, %descriptor.offset.inside.2120
  %descriptor.range.inside.2126 = and i1 %descriptor.owner.offset.valid.2124, %descriptor.extent.inside.2122
  %descriptor.range.valid.2125 = and i1 %descriptor.range.inside.2126, %descriptor.payload.inside.2123
  br i1 %descriptor.range.valid.2125, label %descriptor.valid.2127, label %descriptor.invalid.2128
descriptor.invalid.2128:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2127:
  %descriptor.initialized.status.2129 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2113, i32 %local.check.extent.2114)
  %helper.ok.2130 = icmp eq i32 %descriptor.initialized.status.2129, 0
  br i1 %helper.ok.2130, label %helper.continue.2131, label %frame.failure.0
helper.continue.2131:
  br label %local.descriptor.checked.2112
local.descriptor.inactive.2111:
  br label %local.descriptor.checked.2112
local.descriptor.checked.2112:
  %local.is.active.2132 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2132, label %local.descriptor.active.2133, label %local.descriptor.inactive.2134
local.descriptor.active.2133:
  %local.check.offset.2136 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2137 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2138 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2139 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2140 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2141 = load i32, ptr %context.field.2140, align 4
  %stack.sub.2144 = sub i32 %local.check.owner.end.2139, %local.check.offset.2136
  %descriptor.owner.inside.2142 = icmp ule i32 %local.check.owner.end.2139, %context.value.2141
  %descriptor.offset.inside.2143 = icmp ule i32 %local.check.offset.2136, %local.check.owner.end.2139
  %descriptor.extent.inside.2145 = icmp ule i32 %local.check.extent.2137, %stack.sub.2144
  %descriptor.payload.inside.2146 = icmp ule i32 %local.check.payload.2138, %local.check.extent.2137
  %descriptor.owner.offset.valid.2147 = and i1 %descriptor.owner.inside.2142, %descriptor.offset.inside.2143
  %descriptor.range.inside.2149 = and i1 %descriptor.owner.offset.valid.2147, %descriptor.extent.inside.2145
  %descriptor.range.valid.2148 = and i1 %descriptor.range.inside.2149, %descriptor.payload.inside.2146
  br i1 %descriptor.range.valid.2148, label %descriptor.valid.2150, label %descriptor.invalid.2151
descriptor.invalid.2151:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2150:
  %descriptor.initialized.status.2152 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2136, i32 %local.check.extent.2137)
  %helper.ok.2153 = icmp eq i32 %descriptor.initialized.status.2152, 0
  br i1 %helper.ok.2153, label %helper.continue.2154, label %frame.failure.0
helper.continue.2154:
  br label %local.descriptor.checked.2135
local.descriptor.inactive.2134:
  br label %local.descriptor.checked.2135
local.descriptor.checked.2135:
  %local.is.active.2155 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2155, label %local.descriptor.active.2156, label %local.descriptor.inactive.2157
local.descriptor.active.2156:
  %local.check.offset.2159 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2160 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2161 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2162 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2163 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2164 = load i32, ptr %context.field.2163, align 4
  %stack.sub.2167 = sub i32 %local.check.owner.end.2162, %local.check.offset.2159
  %descriptor.owner.inside.2165 = icmp ule i32 %local.check.owner.end.2162, %context.value.2164
  %descriptor.offset.inside.2166 = icmp ule i32 %local.check.offset.2159, %local.check.owner.end.2162
  %descriptor.extent.inside.2168 = icmp ule i32 %local.check.extent.2160, %stack.sub.2167
  %descriptor.payload.inside.2169 = icmp ule i32 %local.check.payload.2161, %local.check.extent.2160
  %descriptor.owner.offset.valid.2170 = and i1 %descriptor.owner.inside.2165, %descriptor.offset.inside.2166
  %descriptor.range.inside.2172 = and i1 %descriptor.owner.offset.valid.2170, %descriptor.extent.inside.2168
  %descriptor.range.valid.2171 = and i1 %descriptor.range.inside.2172, %descriptor.payload.inside.2169
  br i1 %descriptor.range.valid.2171, label %descriptor.valid.2173, label %descriptor.invalid.2174
descriptor.invalid.2174:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2173:
  %descriptor.initialized.status.2175 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2159, i32 %local.check.extent.2160)
  %helper.ok.2176 = icmp eq i32 %descriptor.initialized.status.2175, 0
  br i1 %helper.ok.2176, label %helper.continue.2177, label %frame.failure.0
helper.continue.2177:
  br label %local.descriptor.checked.2158
local.descriptor.inactive.2157:
  br label %local.descriptor.checked.2158
local.descriptor.checked.2158:
  %step.status.2178 = call i32 @al_owning_charge_step(ptr %ctx, i32 16)
  %helper.ok.2179 = icmp eq i32 %step.status.2178, 0
  br i1 %helper.ok.2179, label %helper.continue.2180, label %frame.failure.0
helper.continue.2180:
  %stack.offset.2181 = add i32 0, 8
  %stack.offset.2182 = add i32 0, 8
  %context.field.2183 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2184 = load i32, ptr %context.field.2183, align 4
  %stack.offset.2185 = add i32 %context.value.2184, %stack.offset.2182
  %reserve.status.2186 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.2185, i32 17)
  %reserve.ok.2187 = icmp eq i32 %reserve.status.2186, 0
  br i1 %reserve.ok.2187, label %reserve.continue.2188, label %frame.failure.0
reserve.continue.2188:
  %stack.offset.2189 = add i32 %context.value.2184, 0
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.2189, i32 %context.value.2010, i32 8, i32 8, i32 1, i32 6)
  %context.field.2190 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2191 = load i32, ptr %context.field.2190, align 4
  %runtime.ok.2192 = icmp eq i32 %context.value.2191, 0
  br i1 %runtime.ok.2192, label %runtime.continue.2193, label %frame.failure.0
runtime.continue.2193:
  %stack.offset.2194 = add i32 0, 8
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 6, i32 %context.value.2184, i32 %stack.offset.2182, i32 %stack.offset.2181, i32 0, i32 0)
  %context.field.2195 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2196 = load i32, ptr %context.field.2195, align 4
  %runtime.ok.2197 = icmp eq i32 %context.value.2196, 0
  br i1 %runtime.ok.2197, label %runtime.continue.2198, label %frame.failure.0
runtime.continue.2198:
  %context.field.2199 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2200 = load i32, ptr %context.field.2199, align 4
  %stack.sub.2203 = sub i32 %stack.offset.2185, %context.value.2184
  %descriptor.owner.inside.2201 = icmp ule i32 %stack.offset.2185, %context.value.2200
  %descriptor.offset.inside.2202 = icmp ule i32 %context.value.2184, %stack.offset.2185
  %descriptor.extent.inside.2204 = icmp ule i32 %stack.offset.2182, %stack.sub.2203
  %descriptor.payload.inside.2205 = icmp ule i32 %stack.offset.2181, %stack.offset.2182
  %descriptor.owner.offset.valid.2206 = and i1 %descriptor.owner.inside.2201, %descriptor.offset.inside.2202
  %descriptor.range.inside.2208 = and i1 %descriptor.owner.offset.valid.2206, %descriptor.extent.inside.2204
  %descriptor.range.valid.2207 = and i1 %descriptor.range.inside.2208, %descriptor.payload.inside.2205
  %descriptor.type.valid.2209 = icmp eq i32 6, 6
  %descriptor.valid.2210 = and i1 %descriptor.range.valid.2207, %descriptor.type.valid.2209
  br i1 %descriptor.valid.2210, label %descriptor.valid.2211, label %descriptor.invalid.2212
descriptor.invalid.2212:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2211:
  %descriptor.initialized.status.2213 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.2184, i32 %stack.offset.2182)
  %helper.ok.2214 = icmp eq i32 %descriptor.initialized.status.2213, 0
  br i1 %helper.ok.2214, label %helper.continue.2215, label %frame.failure.0
helper.continue.2215:
  %local.is.active.2216 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2216, label %local.descriptor.active.2217, label %local.descriptor.inactive.2218
local.descriptor.active.2217:
  %local.check.offset.2220 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2221 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2222 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2223 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2224 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2225 = load i32, ptr %context.field.2224, align 4
  %stack.sub.2228 = sub i32 %local.check.owner.end.2223, %local.check.offset.2220
  %descriptor.owner.inside.2226 = icmp ule i32 %local.check.owner.end.2223, %context.value.2225
  %descriptor.offset.inside.2227 = icmp ule i32 %local.check.offset.2220, %local.check.owner.end.2223
  %descriptor.extent.inside.2229 = icmp ule i32 %local.check.extent.2221, %stack.sub.2228
  %descriptor.payload.inside.2230 = icmp ule i32 %local.check.payload.2222, %local.check.extent.2221
  %descriptor.owner.offset.valid.2231 = and i1 %descriptor.owner.inside.2226, %descriptor.offset.inside.2227
  %descriptor.range.inside.2233 = and i1 %descriptor.owner.offset.valid.2231, %descriptor.extent.inside.2229
  %descriptor.range.valid.2232 = and i1 %descriptor.range.inside.2233, %descriptor.payload.inside.2230
  br i1 %descriptor.range.valid.2232, label %descriptor.valid.2234, label %descriptor.invalid.2235
descriptor.invalid.2235:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2234:
  %descriptor.initialized.status.2236 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2220, i32 %local.check.extent.2221)
  %helper.ok.2237 = icmp eq i32 %descriptor.initialized.status.2236, 0
  br i1 %helper.ok.2237, label %helper.continue.2238, label %frame.failure.0
helper.continue.2238:
  br label %local.descriptor.checked.2219
local.descriptor.inactive.2218:
  br label %local.descriptor.checked.2219
local.descriptor.checked.2219:
  %local.is.active.2239 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2239, label %local.descriptor.active.2240, label %local.descriptor.inactive.2241
local.descriptor.active.2240:
  %local.check.offset.2243 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2244 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2245 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2246 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2247 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2248 = load i32, ptr %context.field.2247, align 4
  %stack.sub.2251 = sub i32 %local.check.owner.end.2246, %local.check.offset.2243
  %descriptor.owner.inside.2249 = icmp ule i32 %local.check.owner.end.2246, %context.value.2248
  %descriptor.offset.inside.2250 = icmp ule i32 %local.check.offset.2243, %local.check.owner.end.2246
  %descriptor.extent.inside.2252 = icmp ule i32 %local.check.extent.2244, %stack.sub.2251
  %descriptor.payload.inside.2253 = icmp ule i32 %local.check.payload.2245, %local.check.extent.2244
  %descriptor.owner.offset.valid.2254 = and i1 %descriptor.owner.inside.2249, %descriptor.offset.inside.2250
  %descriptor.range.inside.2256 = and i1 %descriptor.owner.offset.valid.2254, %descriptor.extent.inside.2252
  %descriptor.range.valid.2255 = and i1 %descriptor.range.inside.2256, %descriptor.payload.inside.2253
  br i1 %descriptor.range.valid.2255, label %descriptor.valid.2257, label %descriptor.invalid.2258
descriptor.invalid.2258:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2257:
  %descriptor.initialized.status.2259 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2243, i32 %local.check.extent.2244)
  %helper.ok.2260 = icmp eq i32 %descriptor.initialized.status.2259, 0
  br i1 %helper.ok.2260, label %helper.continue.2261, label %frame.failure.0
helper.continue.2261:
  br label %local.descriptor.checked.2242
local.descriptor.inactive.2241:
  br label %local.descriptor.checked.2242
local.descriptor.checked.2242:
  %local.is.active.2262 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2262, label %local.descriptor.active.2263, label %local.descriptor.inactive.2264
local.descriptor.active.2263:
  %local.check.offset.2266 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2267 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2268 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2269 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2270 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2271 = load i32, ptr %context.field.2270, align 4
  %stack.sub.2274 = sub i32 %local.check.owner.end.2269, %local.check.offset.2266
  %descriptor.owner.inside.2272 = icmp ule i32 %local.check.owner.end.2269, %context.value.2271
  %descriptor.offset.inside.2273 = icmp ule i32 %local.check.offset.2266, %local.check.owner.end.2269
  %descriptor.extent.inside.2275 = icmp ule i32 %local.check.extent.2267, %stack.sub.2274
  %descriptor.payload.inside.2276 = icmp ule i32 %local.check.payload.2268, %local.check.extent.2267
  %descriptor.owner.offset.valid.2277 = and i1 %descriptor.owner.inside.2272, %descriptor.offset.inside.2273
  %descriptor.range.inside.2279 = and i1 %descriptor.owner.offset.valid.2277, %descriptor.extent.inside.2275
  %descriptor.range.valid.2278 = and i1 %descriptor.range.inside.2279, %descriptor.payload.inside.2276
  br i1 %descriptor.range.valid.2278, label %descriptor.valid.2280, label %descriptor.invalid.2281
descriptor.invalid.2281:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2280:
  %descriptor.initialized.status.2282 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2266, i32 %local.check.extent.2267)
  %helper.ok.2283 = icmp eq i32 %descriptor.initialized.status.2282, 0
  br i1 %helper.ok.2283, label %helper.continue.2284, label %frame.failure.0
helper.continue.2284:
  br label %local.descriptor.checked.2265
local.descriptor.inactive.2264:
  br label %local.descriptor.checked.2265
local.descriptor.checked.2265:
  %local.is.active.2285 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2285, label %local.descriptor.active.2286, label %local.descriptor.inactive.2287
local.descriptor.active.2286:
  %local.check.offset.2289 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2290 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2291 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2292 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2293 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2294 = load i32, ptr %context.field.2293, align 4
  %stack.sub.2297 = sub i32 %local.check.owner.end.2292, %local.check.offset.2289
  %descriptor.owner.inside.2295 = icmp ule i32 %local.check.owner.end.2292, %context.value.2294
  %descriptor.offset.inside.2296 = icmp ule i32 %local.check.offset.2289, %local.check.owner.end.2292
  %descriptor.extent.inside.2298 = icmp ule i32 %local.check.extent.2290, %stack.sub.2297
  %descriptor.payload.inside.2299 = icmp ule i32 %local.check.payload.2291, %local.check.extent.2290
  %descriptor.owner.offset.valid.2300 = and i1 %descriptor.owner.inside.2295, %descriptor.offset.inside.2296
  %descriptor.range.inside.2302 = and i1 %descriptor.owner.offset.valid.2300, %descriptor.extent.inside.2298
  %descriptor.range.valid.2301 = and i1 %descriptor.range.inside.2302, %descriptor.payload.inside.2299
  br i1 %descriptor.range.valid.2301, label %descriptor.valid.2303, label %descriptor.invalid.2304
descriptor.invalid.2304:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2303:
  %descriptor.initialized.status.2305 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2289, i32 %local.check.extent.2290)
  %helper.ok.2306 = icmp eq i32 %descriptor.initialized.status.2305, 0
  br i1 %helper.ok.2306, label %helper.continue.2307, label %frame.failure.0
helper.continue.2307:
  br label %local.descriptor.checked.2288
local.descriptor.inactive.2287:
  br label %local.descriptor.checked.2288
local.descriptor.checked.2288:
  %local.is.active.2308 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2308, label %local.descriptor.active.2309, label %local.descriptor.inactive.2310
local.descriptor.active.2309:
  %local.check.offset.2312 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2313 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2314 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2315 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2316 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2317 = load i32, ptr %context.field.2316, align 4
  %stack.sub.2320 = sub i32 %local.check.owner.end.2315, %local.check.offset.2312
  %descriptor.owner.inside.2318 = icmp ule i32 %local.check.owner.end.2315, %context.value.2317
  %descriptor.offset.inside.2319 = icmp ule i32 %local.check.offset.2312, %local.check.owner.end.2315
  %descriptor.extent.inside.2321 = icmp ule i32 %local.check.extent.2313, %stack.sub.2320
  %descriptor.payload.inside.2322 = icmp ule i32 %local.check.payload.2314, %local.check.extent.2313
  %descriptor.owner.offset.valid.2323 = and i1 %descriptor.owner.inside.2318, %descriptor.offset.inside.2319
  %descriptor.range.inside.2325 = and i1 %descriptor.owner.offset.valid.2323, %descriptor.extent.inside.2321
  %descriptor.range.valid.2324 = and i1 %descriptor.range.inside.2325, %descriptor.payload.inside.2322
  br i1 %descriptor.range.valid.2324, label %descriptor.valid.2326, label %descriptor.invalid.2327
descriptor.invalid.2327:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2326:
  %descriptor.initialized.status.2328 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2312, i32 %local.check.extent.2313)
  %helper.ok.2329 = icmp eq i32 %descriptor.initialized.status.2328, 0
  br i1 %helper.ok.2329, label %helper.continue.2330, label %frame.failure.0
helper.continue.2330:
  br label %local.descriptor.checked.2311
local.descriptor.inactive.2310:
  br label %local.descriptor.checked.2311
local.descriptor.checked.2311:
  %local.is.active.2331 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2331, label %local.descriptor.active.2332, label %local.descriptor.inactive.2333
local.descriptor.active.2332:
  %local.check.offset.2335 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2336 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2337 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2338 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2339 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2340 = load i32, ptr %context.field.2339, align 4
  %stack.sub.2343 = sub i32 %local.check.owner.end.2338, %local.check.offset.2335
  %descriptor.owner.inside.2341 = icmp ule i32 %local.check.owner.end.2338, %context.value.2340
  %descriptor.offset.inside.2342 = icmp ule i32 %local.check.offset.2335, %local.check.owner.end.2338
  %descriptor.extent.inside.2344 = icmp ule i32 %local.check.extent.2336, %stack.sub.2343
  %descriptor.payload.inside.2345 = icmp ule i32 %local.check.payload.2337, %local.check.extent.2336
  %descriptor.owner.offset.valid.2346 = and i1 %descriptor.owner.inside.2341, %descriptor.offset.inside.2342
  %descriptor.range.inside.2348 = and i1 %descriptor.owner.offset.valid.2346, %descriptor.extent.inside.2344
  %descriptor.range.valid.2347 = and i1 %descriptor.range.inside.2348, %descriptor.payload.inside.2345
  br i1 %descriptor.range.valid.2347, label %descriptor.valid.2349, label %descriptor.invalid.2350
descriptor.invalid.2350:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2349:
  %descriptor.initialized.status.2351 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2335, i32 %local.check.extent.2336)
  %helper.ok.2352 = icmp eq i32 %descriptor.initialized.status.2351, 0
  br i1 %helper.ok.2352, label %helper.continue.2353, label %frame.failure.0
helper.continue.2353:
  br label %local.descriptor.checked.2334
local.descriptor.inactive.2333:
  br label %local.descriptor.checked.2334
local.descriptor.checked.2334:
  %step.status.2354 = call i32 @al_owning_charge_step(ptr %ctx, i32 18)
  %helper.ok.2355 = icmp eq i32 %step.status.2354, 0
  br i1 %helper.ok.2355, label %helper.continue.2356, label %frame.failure.0
helper.continue.2356:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 6, i32 %context.value.2184, i32 %stack.offset.2182, i32 %stack.offset.2181, i32 0, i32 0)
  %context.field.2357 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2358 = load i32, ptr %context.field.2357, align 4
  %runtime.ok.2359 = icmp eq i32 %context.value.2358, 0
  br i1 %runtime.ok.2359, label %runtime.continue.2360, label %frame.failure.0
runtime.continue.2360:
  %local.is.active.2361 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2361, label %local.descriptor.active.2362, label %local.descriptor.inactive.2363
local.descriptor.active.2362:
  %local.check.offset.2365 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2366 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2367 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2368 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2369 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2370 = load i32, ptr %context.field.2369, align 4
  %stack.sub.2373 = sub i32 %local.check.owner.end.2368, %local.check.offset.2365
  %descriptor.owner.inside.2371 = icmp ule i32 %local.check.owner.end.2368, %context.value.2370
  %descriptor.offset.inside.2372 = icmp ule i32 %local.check.offset.2365, %local.check.owner.end.2368
  %descriptor.extent.inside.2374 = icmp ule i32 %local.check.extent.2366, %stack.sub.2373
  %descriptor.payload.inside.2375 = icmp ule i32 %local.check.payload.2367, %local.check.extent.2366
  %descriptor.owner.offset.valid.2376 = and i1 %descriptor.owner.inside.2371, %descriptor.offset.inside.2372
  %descriptor.range.inside.2378 = and i1 %descriptor.owner.offset.valid.2376, %descriptor.extent.inside.2374
  %descriptor.range.valid.2377 = and i1 %descriptor.range.inside.2378, %descriptor.payload.inside.2375
  br i1 %descriptor.range.valid.2377, label %descriptor.valid.2379, label %descriptor.invalid.2380
descriptor.invalid.2380:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2379:
  %descriptor.initialized.status.2381 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2365, i32 %local.check.extent.2366)
  %helper.ok.2382 = icmp eq i32 %descriptor.initialized.status.2381, 0
  br i1 %helper.ok.2382, label %helper.continue.2383, label %frame.failure.0
helper.continue.2383:
  br label %local.descriptor.checked.2364
local.descriptor.inactive.2363:
  br label %local.descriptor.checked.2364
local.descriptor.checked.2364:
  %local.is.active.2384 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2384, label %local.descriptor.active.2385, label %local.descriptor.inactive.2386
local.descriptor.active.2385:
  %local.check.offset.2388 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2389 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2390 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2391 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2392 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2393 = load i32, ptr %context.field.2392, align 4
  %stack.sub.2396 = sub i32 %local.check.owner.end.2391, %local.check.offset.2388
  %descriptor.owner.inside.2394 = icmp ule i32 %local.check.owner.end.2391, %context.value.2393
  %descriptor.offset.inside.2395 = icmp ule i32 %local.check.offset.2388, %local.check.owner.end.2391
  %descriptor.extent.inside.2397 = icmp ule i32 %local.check.extent.2389, %stack.sub.2396
  %descriptor.payload.inside.2398 = icmp ule i32 %local.check.payload.2390, %local.check.extent.2389
  %descriptor.owner.offset.valid.2399 = and i1 %descriptor.owner.inside.2394, %descriptor.offset.inside.2395
  %descriptor.range.inside.2401 = and i1 %descriptor.owner.offset.valid.2399, %descriptor.extent.inside.2397
  %descriptor.range.valid.2400 = and i1 %descriptor.range.inside.2401, %descriptor.payload.inside.2398
  br i1 %descriptor.range.valid.2400, label %descriptor.valid.2402, label %descriptor.invalid.2403
descriptor.invalid.2403:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2402:
  %descriptor.initialized.status.2404 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2388, i32 %local.check.extent.2389)
  %helper.ok.2405 = icmp eq i32 %descriptor.initialized.status.2404, 0
  br i1 %helper.ok.2405, label %helper.continue.2406, label %frame.failure.0
helper.continue.2406:
  br label %local.descriptor.checked.2387
local.descriptor.inactive.2386:
  br label %local.descriptor.checked.2387
local.descriptor.checked.2387:
  %local.is.active.2407 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2407, label %local.descriptor.active.2408, label %local.descriptor.inactive.2409
local.descriptor.active.2408:
  %local.check.offset.2411 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2412 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2413 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2414 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2415 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2416 = load i32, ptr %context.field.2415, align 4
  %stack.sub.2419 = sub i32 %local.check.owner.end.2414, %local.check.offset.2411
  %descriptor.owner.inside.2417 = icmp ule i32 %local.check.owner.end.2414, %context.value.2416
  %descriptor.offset.inside.2418 = icmp ule i32 %local.check.offset.2411, %local.check.owner.end.2414
  %descriptor.extent.inside.2420 = icmp ule i32 %local.check.extent.2412, %stack.sub.2419
  %descriptor.payload.inside.2421 = icmp ule i32 %local.check.payload.2413, %local.check.extent.2412
  %descriptor.owner.offset.valid.2422 = and i1 %descriptor.owner.inside.2417, %descriptor.offset.inside.2418
  %descriptor.range.inside.2424 = and i1 %descriptor.owner.offset.valid.2422, %descriptor.extent.inside.2420
  %descriptor.range.valid.2423 = and i1 %descriptor.range.inside.2424, %descriptor.payload.inside.2421
  br i1 %descriptor.range.valid.2423, label %descriptor.valid.2425, label %descriptor.invalid.2426
descriptor.invalid.2426:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2425:
  %descriptor.initialized.status.2427 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2411, i32 %local.check.extent.2412)
  %helper.ok.2428 = icmp eq i32 %descriptor.initialized.status.2427, 0
  br i1 %helper.ok.2428, label %helper.continue.2429, label %frame.failure.0
helper.continue.2429:
  br label %local.descriptor.checked.2410
local.descriptor.inactive.2409:
  br label %local.descriptor.checked.2410
local.descriptor.checked.2410:
  %local.is.active.2430 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2430, label %local.descriptor.active.2431, label %local.descriptor.inactive.2432
local.descriptor.active.2431:
  %local.check.offset.2434 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2435 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2436 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2437 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2438 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2439 = load i32, ptr %context.field.2438, align 4
  %stack.sub.2442 = sub i32 %local.check.owner.end.2437, %local.check.offset.2434
  %descriptor.owner.inside.2440 = icmp ule i32 %local.check.owner.end.2437, %context.value.2439
  %descriptor.offset.inside.2441 = icmp ule i32 %local.check.offset.2434, %local.check.owner.end.2437
  %descriptor.extent.inside.2443 = icmp ule i32 %local.check.extent.2435, %stack.sub.2442
  %descriptor.payload.inside.2444 = icmp ule i32 %local.check.payload.2436, %local.check.extent.2435
  %descriptor.owner.offset.valid.2445 = and i1 %descriptor.owner.inside.2440, %descriptor.offset.inside.2441
  %descriptor.range.inside.2447 = and i1 %descriptor.owner.offset.valid.2445, %descriptor.extent.inside.2443
  %descriptor.range.valid.2446 = and i1 %descriptor.range.inside.2447, %descriptor.payload.inside.2444
  br i1 %descriptor.range.valid.2446, label %descriptor.valid.2448, label %descriptor.invalid.2449
descriptor.invalid.2449:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2448:
  %descriptor.initialized.status.2450 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2434, i32 %local.check.extent.2435)
  %helper.ok.2451 = icmp eq i32 %descriptor.initialized.status.2450, 0
  br i1 %helper.ok.2451, label %helper.continue.2452, label %frame.failure.0
helper.continue.2452:
  br label %local.descriptor.checked.2433
local.descriptor.inactive.2432:
  br label %local.descriptor.checked.2433
local.descriptor.checked.2433:
  %local.is.active.2453 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2453, label %local.descriptor.active.2454, label %local.descriptor.inactive.2455
local.descriptor.active.2454:
  %local.check.offset.2457 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2458 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2459 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2460 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2461 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2462 = load i32, ptr %context.field.2461, align 4
  %stack.sub.2465 = sub i32 %local.check.owner.end.2460, %local.check.offset.2457
  %descriptor.owner.inside.2463 = icmp ule i32 %local.check.owner.end.2460, %context.value.2462
  %descriptor.offset.inside.2464 = icmp ule i32 %local.check.offset.2457, %local.check.owner.end.2460
  %descriptor.extent.inside.2466 = icmp ule i32 %local.check.extent.2458, %stack.sub.2465
  %descriptor.payload.inside.2467 = icmp ule i32 %local.check.payload.2459, %local.check.extent.2458
  %descriptor.owner.offset.valid.2468 = and i1 %descriptor.owner.inside.2463, %descriptor.offset.inside.2464
  %descriptor.range.inside.2470 = and i1 %descriptor.owner.offset.valid.2468, %descriptor.extent.inside.2466
  %descriptor.range.valid.2469 = and i1 %descriptor.range.inside.2470, %descriptor.payload.inside.2467
  br i1 %descriptor.range.valid.2469, label %descriptor.valid.2471, label %descriptor.invalid.2472
descriptor.invalid.2472:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2471:
  %descriptor.initialized.status.2473 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2457, i32 %local.check.extent.2458)
  %helper.ok.2474 = icmp eq i32 %descriptor.initialized.status.2473, 0
  br i1 %helper.ok.2474, label %helper.continue.2475, label %frame.failure.0
helper.continue.2475:
  br label %local.descriptor.checked.2456
local.descriptor.inactive.2455:
  br label %local.descriptor.checked.2456
local.descriptor.checked.2456:
  %local.is.active.2476 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2476, label %local.descriptor.active.2477, label %local.descriptor.inactive.2478
local.descriptor.active.2477:
  %local.check.offset.2480 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2481 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2482 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2483 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2484 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2485 = load i32, ptr %context.field.2484, align 4
  %stack.sub.2488 = sub i32 %local.check.owner.end.2483, %local.check.offset.2480
  %descriptor.owner.inside.2486 = icmp ule i32 %local.check.owner.end.2483, %context.value.2485
  %descriptor.offset.inside.2487 = icmp ule i32 %local.check.offset.2480, %local.check.owner.end.2483
  %descriptor.extent.inside.2489 = icmp ule i32 %local.check.extent.2481, %stack.sub.2488
  %descriptor.payload.inside.2490 = icmp ule i32 %local.check.payload.2482, %local.check.extent.2481
  %descriptor.owner.offset.valid.2491 = and i1 %descriptor.owner.inside.2486, %descriptor.offset.inside.2487
  %descriptor.range.inside.2493 = and i1 %descriptor.owner.offset.valid.2491, %descriptor.extent.inside.2489
  %descriptor.range.valid.2492 = and i1 %descriptor.range.inside.2493, %descriptor.payload.inside.2490
  br i1 %descriptor.range.valid.2492, label %descriptor.valid.2494, label %descriptor.invalid.2495
descriptor.invalid.2495:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2494:
  %descriptor.initialized.status.2496 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2480, i32 %local.check.extent.2481)
  %helper.ok.2497 = icmp eq i32 %descriptor.initialized.status.2496, 0
  br i1 %helper.ok.2497, label %helper.continue.2498, label %frame.failure.0
helper.continue.2498:
  br label %local.descriptor.checked.2479
local.descriptor.inactive.2478:
  br label %local.descriptor.checked.2479
local.descriptor.checked.2479:
  %step.status.2499 = call i32 @al_owning_charge_step(ptr %ctx, i32 19)
  %helper.ok.2500 = icmp eq i32 %step.status.2499, 0
  br i1 %helper.ok.2500, label %helper.continue.2501, label %frame.failure.0
helper.continue.2501:
  %local.resolved.offset.2502 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.2503 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.2504 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.2505 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2506 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2507 = load i32, ptr %context.field.2506, align 4
  %stack.sub.2510 = sub i32 %local.resolved.owner.end.2505, %local.resolved.offset.2502
  %descriptor.owner.inside.2508 = icmp ule i32 %local.resolved.owner.end.2505, %context.value.2507
  %descriptor.offset.inside.2509 = icmp ule i32 %local.resolved.offset.2502, %local.resolved.owner.end.2505
  %descriptor.extent.inside.2511 = icmp ule i32 %local.resolved.extent.2503, %stack.sub.2510
  %descriptor.payload.inside.2512 = icmp ule i32 %local.resolved.payload.2504, %local.resolved.extent.2503
  %descriptor.owner.offset.valid.2513 = and i1 %descriptor.owner.inside.2508, %descriptor.offset.inside.2509
  %descriptor.range.inside.2515 = and i1 %descriptor.owner.offset.valid.2513, %descriptor.extent.inside.2511
  %descriptor.range.valid.2514 = and i1 %descriptor.range.inside.2515, %descriptor.payload.inside.2512
  %descriptor.type.valid.2516 = icmp eq i32 1, 1
  %descriptor.valid.2517 = and i1 %descriptor.range.valid.2514, %descriptor.type.valid.2516
  br i1 %descriptor.valid.2517, label %descriptor.valid.2518, label %descriptor.invalid.2519
descriptor.invalid.2519:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2518:
  %descriptor.initialized.status.2520 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.2502, i32 %local.resolved.extent.2503)
  %helper.ok.2521 = icmp eq i32 %descriptor.initialized.status.2520, 0
  br i1 %helper.ok.2521, label %helper.continue.2522, label %frame.failure.0
helper.continue.2522:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %local.resolved.offset.2502, i32 20, i32 %local.resolved.payload.2504, i32 %local.resolved.owner.end.2505, i32 %local.resolved.extent.2503)
  %context.field.2523 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2524 = load i32, ptr %context.field.2523, align 4
  %runtime.ok.2525 = icmp eq i32 %context.value.2524, 0
  br i1 %runtime.ok.2525, label %runtime.continue.2526, label %frame.failure.0
runtime.continue.2526:
  %context.field.2527 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2528 = load i32, ptr %context.field.2527, align 4
  %stack.sub.2531 = sub i32 %local.resolved.owner.end.2505, %local.resolved.offset.2502
  %descriptor.owner.inside.2529 = icmp ule i32 %local.resolved.owner.end.2505, %context.value.2528
  %descriptor.offset.inside.2530 = icmp ule i32 %local.resolved.offset.2502, %local.resolved.owner.end.2505
  %descriptor.extent.inside.2532 = icmp ule i32 %local.resolved.extent.2503, %stack.sub.2531
  %descriptor.payload.inside.2533 = icmp ule i32 %local.resolved.payload.2504, %local.resolved.extent.2503
  %descriptor.owner.offset.valid.2534 = and i1 %descriptor.owner.inside.2529, %descriptor.offset.inside.2530
  %descriptor.range.inside.2536 = and i1 %descriptor.owner.offset.valid.2534, %descriptor.extent.inside.2532
  %descriptor.range.valid.2535 = and i1 %descriptor.range.inside.2536, %descriptor.payload.inside.2533
  %descriptor.type.valid.2537 = icmp eq i32 1, 1
  %descriptor.valid.2538 = and i1 %descriptor.range.valid.2535, %descriptor.type.valid.2537
  br i1 %descriptor.valid.2538, label %descriptor.valid.2539, label %descriptor.invalid.2540
descriptor.invalid.2540:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2539:
  %descriptor.initialized.status.2541 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.2502, i32 %local.resolved.extent.2503)
  %helper.ok.2542 = icmp eq i32 %descriptor.initialized.status.2541, 0
  br i1 %helper.ok.2542, label %helper.continue.2543, label %frame.failure.0
helper.continue.2543:
  %local.is.active.2544 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2544, label %local.descriptor.active.2545, label %local.descriptor.inactive.2546
local.descriptor.active.2545:
  %local.check.offset.2548 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2549 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2550 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2551 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2552 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2553 = load i32, ptr %context.field.2552, align 4
  %stack.sub.2556 = sub i32 %local.check.owner.end.2551, %local.check.offset.2548
  %descriptor.owner.inside.2554 = icmp ule i32 %local.check.owner.end.2551, %context.value.2553
  %descriptor.offset.inside.2555 = icmp ule i32 %local.check.offset.2548, %local.check.owner.end.2551
  %descriptor.extent.inside.2557 = icmp ule i32 %local.check.extent.2549, %stack.sub.2556
  %descriptor.payload.inside.2558 = icmp ule i32 %local.check.payload.2550, %local.check.extent.2549
  %descriptor.owner.offset.valid.2559 = and i1 %descriptor.owner.inside.2554, %descriptor.offset.inside.2555
  %descriptor.range.inside.2561 = and i1 %descriptor.owner.offset.valid.2559, %descriptor.extent.inside.2557
  %descriptor.range.valid.2560 = and i1 %descriptor.range.inside.2561, %descriptor.payload.inside.2558
  br i1 %descriptor.range.valid.2560, label %descriptor.valid.2562, label %descriptor.invalid.2563
descriptor.invalid.2563:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2562:
  %descriptor.initialized.status.2564 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2548, i32 %local.check.extent.2549)
  %helper.ok.2565 = icmp eq i32 %descriptor.initialized.status.2564, 0
  br i1 %helper.ok.2565, label %helper.continue.2566, label %frame.failure.0
helper.continue.2566:
  br label %local.descriptor.checked.2547
local.descriptor.inactive.2546:
  br label %local.descriptor.checked.2547
local.descriptor.checked.2547:
  %local.is.active.2567 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2567, label %local.descriptor.active.2568, label %local.descriptor.inactive.2569
local.descriptor.active.2568:
  %local.check.offset.2571 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2572 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2573 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2574 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2575 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2576 = load i32, ptr %context.field.2575, align 4
  %stack.sub.2579 = sub i32 %local.check.owner.end.2574, %local.check.offset.2571
  %descriptor.owner.inside.2577 = icmp ule i32 %local.check.owner.end.2574, %context.value.2576
  %descriptor.offset.inside.2578 = icmp ule i32 %local.check.offset.2571, %local.check.owner.end.2574
  %descriptor.extent.inside.2580 = icmp ule i32 %local.check.extent.2572, %stack.sub.2579
  %descriptor.payload.inside.2581 = icmp ule i32 %local.check.payload.2573, %local.check.extent.2572
  %descriptor.owner.offset.valid.2582 = and i1 %descriptor.owner.inside.2577, %descriptor.offset.inside.2578
  %descriptor.range.inside.2584 = and i1 %descriptor.owner.offset.valid.2582, %descriptor.extent.inside.2580
  %descriptor.range.valid.2583 = and i1 %descriptor.range.inside.2584, %descriptor.payload.inside.2581
  br i1 %descriptor.range.valid.2583, label %descriptor.valid.2585, label %descriptor.invalid.2586
descriptor.invalid.2586:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2585:
  %descriptor.initialized.status.2587 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2571, i32 %local.check.extent.2572)
  %helper.ok.2588 = icmp eq i32 %descriptor.initialized.status.2587, 0
  br i1 %helper.ok.2588, label %helper.continue.2589, label %frame.failure.0
helper.continue.2589:
  br label %local.descriptor.checked.2570
local.descriptor.inactive.2569:
  br label %local.descriptor.checked.2570
local.descriptor.checked.2570:
  %local.is.active.2590 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2590, label %local.descriptor.active.2591, label %local.descriptor.inactive.2592
local.descriptor.active.2591:
  %local.check.offset.2594 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2595 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2596 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2597 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2598 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2599 = load i32, ptr %context.field.2598, align 4
  %stack.sub.2602 = sub i32 %local.check.owner.end.2597, %local.check.offset.2594
  %descriptor.owner.inside.2600 = icmp ule i32 %local.check.owner.end.2597, %context.value.2599
  %descriptor.offset.inside.2601 = icmp ule i32 %local.check.offset.2594, %local.check.owner.end.2597
  %descriptor.extent.inside.2603 = icmp ule i32 %local.check.extent.2595, %stack.sub.2602
  %descriptor.payload.inside.2604 = icmp ule i32 %local.check.payload.2596, %local.check.extent.2595
  %descriptor.owner.offset.valid.2605 = and i1 %descriptor.owner.inside.2600, %descriptor.offset.inside.2601
  %descriptor.range.inside.2607 = and i1 %descriptor.owner.offset.valid.2605, %descriptor.extent.inside.2603
  %descriptor.range.valid.2606 = and i1 %descriptor.range.inside.2607, %descriptor.payload.inside.2604
  br i1 %descriptor.range.valid.2606, label %descriptor.valid.2608, label %descriptor.invalid.2609
descriptor.invalid.2609:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2608:
  %descriptor.initialized.status.2610 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2594, i32 %local.check.extent.2595)
  %helper.ok.2611 = icmp eq i32 %descriptor.initialized.status.2610, 0
  br i1 %helper.ok.2611, label %helper.continue.2612, label %frame.failure.0
helper.continue.2612:
  br label %local.descriptor.checked.2593
local.descriptor.inactive.2592:
  br label %local.descriptor.checked.2593
local.descriptor.checked.2593:
  %local.is.active.2613 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2613, label %local.descriptor.active.2614, label %local.descriptor.inactive.2615
local.descriptor.active.2614:
  %local.check.offset.2617 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2618 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2619 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2620 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2621 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2622 = load i32, ptr %context.field.2621, align 4
  %stack.sub.2625 = sub i32 %local.check.owner.end.2620, %local.check.offset.2617
  %descriptor.owner.inside.2623 = icmp ule i32 %local.check.owner.end.2620, %context.value.2622
  %descriptor.offset.inside.2624 = icmp ule i32 %local.check.offset.2617, %local.check.owner.end.2620
  %descriptor.extent.inside.2626 = icmp ule i32 %local.check.extent.2618, %stack.sub.2625
  %descriptor.payload.inside.2627 = icmp ule i32 %local.check.payload.2619, %local.check.extent.2618
  %descriptor.owner.offset.valid.2628 = and i1 %descriptor.owner.inside.2623, %descriptor.offset.inside.2624
  %descriptor.range.inside.2630 = and i1 %descriptor.owner.offset.valid.2628, %descriptor.extent.inside.2626
  %descriptor.range.valid.2629 = and i1 %descriptor.range.inside.2630, %descriptor.payload.inside.2627
  br i1 %descriptor.range.valid.2629, label %descriptor.valid.2631, label %descriptor.invalid.2632
descriptor.invalid.2632:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2631:
  %descriptor.initialized.status.2633 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2617, i32 %local.check.extent.2618)
  %helper.ok.2634 = icmp eq i32 %descriptor.initialized.status.2633, 0
  br i1 %helper.ok.2634, label %helper.continue.2635, label %frame.failure.0
helper.continue.2635:
  br label %local.descriptor.checked.2616
local.descriptor.inactive.2615:
  br label %local.descriptor.checked.2616
local.descriptor.checked.2616:
  %local.is.active.2636 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2636, label %local.descriptor.active.2637, label %local.descriptor.inactive.2638
local.descriptor.active.2637:
  %local.check.offset.2640 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2641 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2642 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2643 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2644 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2645 = load i32, ptr %context.field.2644, align 4
  %stack.sub.2648 = sub i32 %local.check.owner.end.2643, %local.check.offset.2640
  %descriptor.owner.inside.2646 = icmp ule i32 %local.check.owner.end.2643, %context.value.2645
  %descriptor.offset.inside.2647 = icmp ule i32 %local.check.offset.2640, %local.check.owner.end.2643
  %descriptor.extent.inside.2649 = icmp ule i32 %local.check.extent.2641, %stack.sub.2648
  %descriptor.payload.inside.2650 = icmp ule i32 %local.check.payload.2642, %local.check.extent.2641
  %descriptor.owner.offset.valid.2651 = and i1 %descriptor.owner.inside.2646, %descriptor.offset.inside.2647
  %descriptor.range.inside.2653 = and i1 %descriptor.owner.offset.valid.2651, %descriptor.extent.inside.2649
  %descriptor.range.valid.2652 = and i1 %descriptor.range.inside.2653, %descriptor.payload.inside.2650
  br i1 %descriptor.range.valid.2652, label %descriptor.valid.2654, label %descriptor.invalid.2655
descriptor.invalid.2655:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2654:
  %descriptor.initialized.status.2656 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2640, i32 %local.check.extent.2641)
  %helper.ok.2657 = icmp eq i32 %descriptor.initialized.status.2656, 0
  br i1 %helper.ok.2657, label %helper.continue.2658, label %frame.failure.0
helper.continue.2658:
  br label %local.descriptor.checked.2639
local.descriptor.inactive.2638:
  br label %local.descriptor.checked.2639
local.descriptor.checked.2639:
  %local.is.active.2659 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2659, label %local.descriptor.active.2660, label %local.descriptor.inactive.2661
local.descriptor.active.2660:
  %local.check.offset.2663 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2664 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2665 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2666 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2667 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2668 = load i32, ptr %context.field.2667, align 4
  %stack.sub.2671 = sub i32 %local.check.owner.end.2666, %local.check.offset.2663
  %descriptor.owner.inside.2669 = icmp ule i32 %local.check.owner.end.2666, %context.value.2668
  %descriptor.offset.inside.2670 = icmp ule i32 %local.check.offset.2663, %local.check.owner.end.2666
  %descriptor.extent.inside.2672 = icmp ule i32 %local.check.extent.2664, %stack.sub.2671
  %descriptor.payload.inside.2673 = icmp ule i32 %local.check.payload.2665, %local.check.extent.2664
  %descriptor.owner.offset.valid.2674 = and i1 %descriptor.owner.inside.2669, %descriptor.offset.inside.2670
  %descriptor.range.inside.2676 = and i1 %descriptor.owner.offset.valid.2674, %descriptor.extent.inside.2672
  %descriptor.range.valid.2675 = and i1 %descriptor.range.inside.2676, %descriptor.payload.inside.2673
  br i1 %descriptor.range.valid.2675, label %descriptor.valid.2677, label %descriptor.invalid.2678
descriptor.invalid.2678:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2677:
  %descriptor.initialized.status.2679 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2663, i32 %local.check.extent.2664)
  %helper.ok.2680 = icmp eq i32 %descriptor.initialized.status.2679, 0
  br i1 %helper.ok.2680, label %helper.continue.2681, label %frame.failure.0
helper.continue.2681:
  br label %local.descriptor.checked.2662
local.descriptor.inactive.2661:
  br label %local.descriptor.checked.2662
local.descriptor.checked.2662:
  %step.status.2682 = call i32 @al_owning_charge_step(ptr %ctx, i32 20)
  %helper.ok.2683 = icmp eq i32 %step.status.2682, 0
  br i1 %helper.ok.2683, label %helper.continue.2684, label %frame.failure.0
helper.continue.2684:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %local.resolved.offset.2502, i32 %local.resolved.extent.2503, i32 %local.resolved.payload.2504, i32 0, i32 0)
  %context.field.2685 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2686 = load i32, ptr %context.field.2685, align 4
  %runtime.ok.2687 = icmp eq i32 %context.value.2686, 0
  br i1 %runtime.ok.2687, label %runtime.continue.2688, label %frame.failure.0
runtime.continue.2688:
  %local.is.active.2689 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2689, label %local.descriptor.active.2690, label %local.descriptor.inactive.2691
local.descriptor.active.2690:
  %local.check.offset.2693 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2694 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2695 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2696 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2697 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2698 = load i32, ptr %context.field.2697, align 4
  %stack.sub.2701 = sub i32 %local.check.owner.end.2696, %local.check.offset.2693
  %descriptor.owner.inside.2699 = icmp ule i32 %local.check.owner.end.2696, %context.value.2698
  %descriptor.offset.inside.2700 = icmp ule i32 %local.check.offset.2693, %local.check.owner.end.2696
  %descriptor.extent.inside.2702 = icmp ule i32 %local.check.extent.2694, %stack.sub.2701
  %descriptor.payload.inside.2703 = icmp ule i32 %local.check.payload.2695, %local.check.extent.2694
  %descriptor.owner.offset.valid.2704 = and i1 %descriptor.owner.inside.2699, %descriptor.offset.inside.2700
  %descriptor.range.inside.2706 = and i1 %descriptor.owner.offset.valid.2704, %descriptor.extent.inside.2702
  %descriptor.range.valid.2705 = and i1 %descriptor.range.inside.2706, %descriptor.payload.inside.2703
  br i1 %descriptor.range.valid.2705, label %descriptor.valid.2707, label %descriptor.invalid.2708
descriptor.invalid.2708:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2707:
  %descriptor.initialized.status.2709 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2693, i32 %local.check.extent.2694)
  %helper.ok.2710 = icmp eq i32 %descriptor.initialized.status.2709, 0
  br i1 %helper.ok.2710, label %helper.continue.2711, label %frame.failure.0
helper.continue.2711:
  br label %local.descriptor.checked.2692
local.descriptor.inactive.2691:
  br label %local.descriptor.checked.2692
local.descriptor.checked.2692:
  %local.is.active.2712 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2712, label %local.descriptor.active.2713, label %local.descriptor.inactive.2714
local.descriptor.active.2713:
  %local.check.offset.2716 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2717 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2718 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2719 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2720 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2721 = load i32, ptr %context.field.2720, align 4
  %stack.sub.2724 = sub i32 %local.check.owner.end.2719, %local.check.offset.2716
  %descriptor.owner.inside.2722 = icmp ule i32 %local.check.owner.end.2719, %context.value.2721
  %descriptor.offset.inside.2723 = icmp ule i32 %local.check.offset.2716, %local.check.owner.end.2719
  %descriptor.extent.inside.2725 = icmp ule i32 %local.check.extent.2717, %stack.sub.2724
  %descriptor.payload.inside.2726 = icmp ule i32 %local.check.payload.2718, %local.check.extent.2717
  %descriptor.owner.offset.valid.2727 = and i1 %descriptor.owner.inside.2722, %descriptor.offset.inside.2723
  %descriptor.range.inside.2729 = and i1 %descriptor.owner.offset.valid.2727, %descriptor.extent.inside.2725
  %descriptor.range.valid.2728 = and i1 %descriptor.range.inside.2729, %descriptor.payload.inside.2726
  br i1 %descriptor.range.valid.2728, label %descriptor.valid.2730, label %descriptor.invalid.2731
descriptor.invalid.2731:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2730:
  %descriptor.initialized.status.2732 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2716, i32 %local.check.extent.2717)
  %helper.ok.2733 = icmp eq i32 %descriptor.initialized.status.2732, 0
  br i1 %helper.ok.2733, label %helper.continue.2734, label %frame.failure.0
helper.continue.2734:
  br label %local.descriptor.checked.2715
local.descriptor.inactive.2714:
  br label %local.descriptor.checked.2715
local.descriptor.checked.2715:
  %local.is.active.2735 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2735, label %local.descriptor.active.2736, label %local.descriptor.inactive.2737
local.descriptor.active.2736:
  %local.check.offset.2739 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2740 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2741 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2742 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2743 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2744 = load i32, ptr %context.field.2743, align 4
  %stack.sub.2747 = sub i32 %local.check.owner.end.2742, %local.check.offset.2739
  %descriptor.owner.inside.2745 = icmp ule i32 %local.check.owner.end.2742, %context.value.2744
  %descriptor.offset.inside.2746 = icmp ule i32 %local.check.offset.2739, %local.check.owner.end.2742
  %descriptor.extent.inside.2748 = icmp ule i32 %local.check.extent.2740, %stack.sub.2747
  %descriptor.payload.inside.2749 = icmp ule i32 %local.check.payload.2741, %local.check.extent.2740
  %descriptor.owner.offset.valid.2750 = and i1 %descriptor.owner.inside.2745, %descriptor.offset.inside.2746
  %descriptor.range.inside.2752 = and i1 %descriptor.owner.offset.valid.2750, %descriptor.extent.inside.2748
  %descriptor.range.valid.2751 = and i1 %descriptor.range.inside.2752, %descriptor.payload.inside.2749
  br i1 %descriptor.range.valid.2751, label %descriptor.valid.2753, label %descriptor.invalid.2754
descriptor.invalid.2754:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2753:
  %descriptor.initialized.status.2755 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2739, i32 %local.check.extent.2740)
  %helper.ok.2756 = icmp eq i32 %descriptor.initialized.status.2755, 0
  br i1 %helper.ok.2756, label %helper.continue.2757, label %frame.failure.0
helper.continue.2757:
  br label %local.descriptor.checked.2738
local.descriptor.inactive.2737:
  br label %local.descriptor.checked.2738
local.descriptor.checked.2738:
  %local.is.active.2758 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2758, label %local.descriptor.active.2759, label %local.descriptor.inactive.2760
local.descriptor.active.2759:
  %local.check.offset.2762 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2763 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2764 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2765 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2766 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2767 = load i32, ptr %context.field.2766, align 4
  %stack.sub.2770 = sub i32 %local.check.owner.end.2765, %local.check.offset.2762
  %descriptor.owner.inside.2768 = icmp ule i32 %local.check.owner.end.2765, %context.value.2767
  %descriptor.offset.inside.2769 = icmp ule i32 %local.check.offset.2762, %local.check.owner.end.2765
  %descriptor.extent.inside.2771 = icmp ule i32 %local.check.extent.2763, %stack.sub.2770
  %descriptor.payload.inside.2772 = icmp ule i32 %local.check.payload.2764, %local.check.extent.2763
  %descriptor.owner.offset.valid.2773 = and i1 %descriptor.owner.inside.2768, %descriptor.offset.inside.2769
  %descriptor.range.inside.2775 = and i1 %descriptor.owner.offset.valid.2773, %descriptor.extent.inside.2771
  %descriptor.range.valid.2774 = and i1 %descriptor.range.inside.2775, %descriptor.payload.inside.2772
  br i1 %descriptor.range.valid.2774, label %descriptor.valid.2776, label %descriptor.invalid.2777
descriptor.invalid.2777:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2776:
  %descriptor.initialized.status.2778 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2762, i32 %local.check.extent.2763)
  %helper.ok.2779 = icmp eq i32 %descriptor.initialized.status.2778, 0
  br i1 %helper.ok.2779, label %helper.continue.2780, label %frame.failure.0
helper.continue.2780:
  br label %local.descriptor.checked.2761
local.descriptor.inactive.2760:
  br label %local.descriptor.checked.2761
local.descriptor.checked.2761:
  %local.is.active.2781 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2781, label %local.descriptor.active.2782, label %local.descriptor.inactive.2783
local.descriptor.active.2782:
  %local.check.offset.2785 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2786 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2787 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2788 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2789 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2790 = load i32, ptr %context.field.2789, align 4
  %stack.sub.2793 = sub i32 %local.check.owner.end.2788, %local.check.offset.2785
  %descriptor.owner.inside.2791 = icmp ule i32 %local.check.owner.end.2788, %context.value.2790
  %descriptor.offset.inside.2792 = icmp ule i32 %local.check.offset.2785, %local.check.owner.end.2788
  %descriptor.extent.inside.2794 = icmp ule i32 %local.check.extent.2786, %stack.sub.2793
  %descriptor.payload.inside.2795 = icmp ule i32 %local.check.payload.2787, %local.check.extent.2786
  %descriptor.owner.offset.valid.2796 = and i1 %descriptor.owner.inside.2791, %descriptor.offset.inside.2792
  %descriptor.range.inside.2798 = and i1 %descriptor.owner.offset.valid.2796, %descriptor.extent.inside.2794
  %descriptor.range.valid.2797 = and i1 %descriptor.range.inside.2798, %descriptor.payload.inside.2795
  br i1 %descriptor.range.valid.2797, label %descriptor.valid.2799, label %descriptor.invalid.2800
descriptor.invalid.2800:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2799:
  %descriptor.initialized.status.2801 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2785, i32 %local.check.extent.2786)
  %helper.ok.2802 = icmp eq i32 %descriptor.initialized.status.2801, 0
  br i1 %helper.ok.2802, label %helper.continue.2803, label %frame.failure.0
helper.continue.2803:
  br label %local.descriptor.checked.2784
local.descriptor.inactive.2783:
  br label %local.descriptor.checked.2784
local.descriptor.checked.2784:
  %local.is.active.2804 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2804, label %local.descriptor.active.2805, label %local.descriptor.inactive.2806
local.descriptor.active.2805:
  %local.check.offset.2808 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2809 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2810 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2811 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2812 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2813 = load i32, ptr %context.field.2812, align 4
  %stack.sub.2816 = sub i32 %local.check.owner.end.2811, %local.check.offset.2808
  %descriptor.owner.inside.2814 = icmp ule i32 %local.check.owner.end.2811, %context.value.2813
  %descriptor.offset.inside.2815 = icmp ule i32 %local.check.offset.2808, %local.check.owner.end.2811
  %descriptor.extent.inside.2817 = icmp ule i32 %local.check.extent.2809, %stack.sub.2816
  %descriptor.payload.inside.2818 = icmp ule i32 %local.check.payload.2810, %local.check.extent.2809
  %descriptor.owner.offset.valid.2819 = and i1 %descriptor.owner.inside.2814, %descriptor.offset.inside.2815
  %descriptor.range.inside.2821 = and i1 %descriptor.owner.offset.valid.2819, %descriptor.extent.inside.2817
  %descriptor.range.valid.2820 = and i1 %descriptor.range.inside.2821, %descriptor.payload.inside.2818
  br i1 %descriptor.range.valid.2820, label %descriptor.valid.2822, label %descriptor.invalid.2823
descriptor.invalid.2823:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2822:
  %descriptor.initialized.status.2824 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2808, i32 %local.check.extent.2809)
  %helper.ok.2825 = icmp eq i32 %descriptor.initialized.status.2824, 0
  br i1 %helper.ok.2825, label %helper.continue.2826, label %frame.failure.0
helper.continue.2826:
  br label %local.descriptor.checked.2807
local.descriptor.inactive.2806:
  br label %local.descriptor.checked.2807
local.descriptor.checked.2807:
  %step.status.2827 = call i32 @al_owning_charge_step(ptr %ctx, i32 21)
  %helper.ok.2828 = icmp eq i32 %step.status.2827, 0
  br i1 %helper.ok.2828, label %helper.continue.2829, label %frame.failure.0
helper.continue.2829:
  %local.resolved.offset.2830 = load i32, ptr %local.offset.9, align 4
  %local.resolved.extent.2831 = load i32, ptr %local.extent.10, align 4
  %local.resolved.payload.2832 = load i32, ptr %local.payload.11, align 4
  %local.resolved.owner.end.2833 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2834 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2835 = load i32, ptr %context.field.2834, align 4
  %stack.sub.2838 = sub i32 %local.resolved.owner.end.2833, %local.resolved.offset.2830
  %descriptor.owner.inside.2836 = icmp ule i32 %local.resolved.owner.end.2833, %context.value.2835
  %descriptor.offset.inside.2837 = icmp ule i32 %local.resolved.offset.2830, %local.resolved.owner.end.2833
  %descriptor.extent.inside.2839 = icmp ule i32 %local.resolved.extent.2831, %stack.sub.2838
  %descriptor.payload.inside.2840 = icmp ule i32 %local.resolved.payload.2832, %local.resolved.extent.2831
  %descriptor.owner.offset.valid.2841 = and i1 %descriptor.owner.inside.2836, %descriptor.offset.inside.2837
  %descriptor.range.inside.2843 = and i1 %descriptor.owner.offset.valid.2841, %descriptor.extent.inside.2839
  %descriptor.range.valid.2842 = and i1 %descriptor.range.inside.2843, %descriptor.payload.inside.2840
  %descriptor.type.valid.2844 = icmp eq i32 1, 1
  %descriptor.valid.2845 = and i1 %descriptor.range.valid.2842, %descriptor.type.valid.2844
  br i1 %descriptor.valid.2845, label %descriptor.valid.2846, label %descriptor.invalid.2847
descriptor.invalid.2847:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2846:
  %descriptor.initialized.status.2848 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.2830, i32 %local.resolved.extent.2831)
  %helper.ok.2849 = icmp eq i32 %descriptor.initialized.status.2848, 0
  br i1 %helper.ok.2849, label %helper.continue.2850, label %frame.failure.0
helper.continue.2850:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %local.resolved.offset.2830, i32 20, i32 %local.resolved.payload.2832, i32 %local.resolved.owner.end.2833, i32 %local.resolved.extent.2831)
  %context.field.2851 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2852 = load i32, ptr %context.field.2851, align 4
  %runtime.ok.2853 = icmp eq i32 %context.value.2852, 0
  br i1 %runtime.ok.2853, label %runtime.continue.2854, label %frame.failure.0
runtime.continue.2854:
  %context.field.2855 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2856 = load i32, ptr %context.field.2855, align 4
  %stack.sub.2859 = sub i32 %local.resolved.owner.end.2833, %local.resolved.offset.2830
  %descriptor.owner.inside.2857 = icmp ule i32 %local.resolved.owner.end.2833, %context.value.2856
  %descriptor.offset.inside.2858 = icmp ule i32 %local.resolved.offset.2830, %local.resolved.owner.end.2833
  %descriptor.extent.inside.2860 = icmp ule i32 %local.resolved.extent.2831, %stack.sub.2859
  %descriptor.payload.inside.2861 = icmp ule i32 %local.resolved.payload.2832, %local.resolved.extent.2831
  %descriptor.owner.offset.valid.2862 = and i1 %descriptor.owner.inside.2857, %descriptor.offset.inside.2858
  %descriptor.range.inside.2864 = and i1 %descriptor.owner.offset.valid.2862, %descriptor.extent.inside.2860
  %descriptor.range.valid.2863 = and i1 %descriptor.range.inside.2864, %descriptor.payload.inside.2861
  %descriptor.type.valid.2865 = icmp eq i32 1, 1
  %descriptor.valid.2866 = and i1 %descriptor.range.valid.2863, %descriptor.type.valid.2865
  br i1 %descriptor.valid.2866, label %descriptor.valid.2867, label %descriptor.invalid.2868
descriptor.invalid.2868:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2867:
  %descriptor.initialized.status.2869 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.2830, i32 %local.resolved.extent.2831)
  %helper.ok.2870 = icmp eq i32 %descriptor.initialized.status.2869, 0
  br i1 %helper.ok.2870, label %helper.continue.2871, label %frame.failure.0
helper.continue.2871:
  %local.is.active.2872 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2872, label %local.descriptor.active.2873, label %local.descriptor.inactive.2874
local.descriptor.active.2873:
  %local.check.offset.2876 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2877 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2878 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2879 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2880 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2881 = load i32, ptr %context.field.2880, align 4
  %stack.sub.2884 = sub i32 %local.check.owner.end.2879, %local.check.offset.2876
  %descriptor.owner.inside.2882 = icmp ule i32 %local.check.owner.end.2879, %context.value.2881
  %descriptor.offset.inside.2883 = icmp ule i32 %local.check.offset.2876, %local.check.owner.end.2879
  %descriptor.extent.inside.2885 = icmp ule i32 %local.check.extent.2877, %stack.sub.2884
  %descriptor.payload.inside.2886 = icmp ule i32 %local.check.payload.2878, %local.check.extent.2877
  %descriptor.owner.offset.valid.2887 = and i1 %descriptor.owner.inside.2882, %descriptor.offset.inside.2883
  %descriptor.range.inside.2889 = and i1 %descriptor.owner.offset.valid.2887, %descriptor.extent.inside.2885
  %descriptor.range.valid.2888 = and i1 %descriptor.range.inside.2889, %descriptor.payload.inside.2886
  br i1 %descriptor.range.valid.2888, label %descriptor.valid.2890, label %descriptor.invalid.2891
descriptor.invalid.2891:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2890:
  %descriptor.initialized.status.2892 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2876, i32 %local.check.extent.2877)
  %helper.ok.2893 = icmp eq i32 %descriptor.initialized.status.2892, 0
  br i1 %helper.ok.2893, label %helper.continue.2894, label %frame.failure.0
helper.continue.2894:
  br label %local.descriptor.checked.2875
local.descriptor.inactive.2874:
  br label %local.descriptor.checked.2875
local.descriptor.checked.2875:
  %local.is.active.2895 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2895, label %local.descriptor.active.2896, label %local.descriptor.inactive.2897
local.descriptor.active.2896:
  %local.check.offset.2899 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2900 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2901 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2902 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2903 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2904 = load i32, ptr %context.field.2903, align 4
  %stack.sub.2907 = sub i32 %local.check.owner.end.2902, %local.check.offset.2899
  %descriptor.owner.inside.2905 = icmp ule i32 %local.check.owner.end.2902, %context.value.2904
  %descriptor.offset.inside.2906 = icmp ule i32 %local.check.offset.2899, %local.check.owner.end.2902
  %descriptor.extent.inside.2908 = icmp ule i32 %local.check.extent.2900, %stack.sub.2907
  %descriptor.payload.inside.2909 = icmp ule i32 %local.check.payload.2901, %local.check.extent.2900
  %descriptor.owner.offset.valid.2910 = and i1 %descriptor.owner.inside.2905, %descriptor.offset.inside.2906
  %descriptor.range.inside.2912 = and i1 %descriptor.owner.offset.valid.2910, %descriptor.extent.inside.2908
  %descriptor.range.valid.2911 = and i1 %descriptor.range.inside.2912, %descriptor.payload.inside.2909
  br i1 %descriptor.range.valid.2911, label %descriptor.valid.2913, label %descriptor.invalid.2914
descriptor.invalid.2914:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2913:
  %descriptor.initialized.status.2915 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2899, i32 %local.check.extent.2900)
  %helper.ok.2916 = icmp eq i32 %descriptor.initialized.status.2915, 0
  br i1 %helper.ok.2916, label %helper.continue.2917, label %frame.failure.0
helper.continue.2917:
  br label %local.descriptor.checked.2898
local.descriptor.inactive.2897:
  br label %local.descriptor.checked.2898
local.descriptor.checked.2898:
  %local.is.active.2918 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2918, label %local.descriptor.active.2919, label %local.descriptor.inactive.2920
local.descriptor.active.2919:
  %local.check.offset.2922 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2923 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2924 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2925 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2926 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2927 = load i32, ptr %context.field.2926, align 4
  %stack.sub.2930 = sub i32 %local.check.owner.end.2925, %local.check.offset.2922
  %descriptor.owner.inside.2928 = icmp ule i32 %local.check.owner.end.2925, %context.value.2927
  %descriptor.offset.inside.2929 = icmp ule i32 %local.check.offset.2922, %local.check.owner.end.2925
  %descriptor.extent.inside.2931 = icmp ule i32 %local.check.extent.2923, %stack.sub.2930
  %descriptor.payload.inside.2932 = icmp ule i32 %local.check.payload.2924, %local.check.extent.2923
  %descriptor.owner.offset.valid.2933 = and i1 %descriptor.owner.inside.2928, %descriptor.offset.inside.2929
  %descriptor.range.inside.2935 = and i1 %descriptor.owner.offset.valid.2933, %descriptor.extent.inside.2931
  %descriptor.range.valid.2934 = and i1 %descriptor.range.inside.2935, %descriptor.payload.inside.2932
  br i1 %descriptor.range.valid.2934, label %descriptor.valid.2936, label %descriptor.invalid.2937
descriptor.invalid.2937:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2936:
  %descriptor.initialized.status.2938 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2922, i32 %local.check.extent.2923)
  %helper.ok.2939 = icmp eq i32 %descriptor.initialized.status.2938, 0
  br i1 %helper.ok.2939, label %helper.continue.2940, label %frame.failure.0
helper.continue.2940:
  br label %local.descriptor.checked.2921
local.descriptor.inactive.2920:
  br label %local.descriptor.checked.2921
local.descriptor.checked.2921:
  %local.is.active.2941 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2941, label %local.descriptor.active.2942, label %local.descriptor.inactive.2943
local.descriptor.active.2942:
  %local.check.offset.2945 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2946 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2947 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2948 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2949 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2950 = load i32, ptr %context.field.2949, align 4
  %stack.sub.2953 = sub i32 %local.check.owner.end.2948, %local.check.offset.2945
  %descriptor.owner.inside.2951 = icmp ule i32 %local.check.owner.end.2948, %context.value.2950
  %descriptor.offset.inside.2952 = icmp ule i32 %local.check.offset.2945, %local.check.owner.end.2948
  %descriptor.extent.inside.2954 = icmp ule i32 %local.check.extent.2946, %stack.sub.2953
  %descriptor.payload.inside.2955 = icmp ule i32 %local.check.payload.2947, %local.check.extent.2946
  %descriptor.owner.offset.valid.2956 = and i1 %descriptor.owner.inside.2951, %descriptor.offset.inside.2952
  %descriptor.range.inside.2958 = and i1 %descriptor.owner.offset.valid.2956, %descriptor.extent.inside.2954
  %descriptor.range.valid.2957 = and i1 %descriptor.range.inside.2958, %descriptor.payload.inside.2955
  br i1 %descriptor.range.valid.2957, label %descriptor.valid.2959, label %descriptor.invalid.2960
descriptor.invalid.2960:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2959:
  %descriptor.initialized.status.2961 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2945, i32 %local.check.extent.2946)
  %helper.ok.2962 = icmp eq i32 %descriptor.initialized.status.2961, 0
  br i1 %helper.ok.2962, label %helper.continue.2963, label %frame.failure.0
helper.continue.2963:
  br label %local.descriptor.checked.2944
local.descriptor.inactive.2943:
  br label %local.descriptor.checked.2944
local.descriptor.checked.2944:
  %local.is.active.2964 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2964, label %local.descriptor.active.2965, label %local.descriptor.inactive.2966
local.descriptor.active.2965:
  %local.check.offset.2968 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2969 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2970 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2971 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2972 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2973 = load i32, ptr %context.field.2972, align 4
  %stack.sub.2976 = sub i32 %local.check.owner.end.2971, %local.check.offset.2968
  %descriptor.owner.inside.2974 = icmp ule i32 %local.check.owner.end.2971, %context.value.2973
  %descriptor.offset.inside.2975 = icmp ule i32 %local.check.offset.2968, %local.check.owner.end.2971
  %descriptor.extent.inside.2977 = icmp ule i32 %local.check.extent.2969, %stack.sub.2976
  %descriptor.payload.inside.2978 = icmp ule i32 %local.check.payload.2970, %local.check.extent.2969
  %descriptor.owner.offset.valid.2979 = and i1 %descriptor.owner.inside.2974, %descriptor.offset.inside.2975
  %descriptor.range.inside.2981 = and i1 %descriptor.owner.offset.valid.2979, %descriptor.extent.inside.2977
  %descriptor.range.valid.2980 = and i1 %descriptor.range.inside.2981, %descriptor.payload.inside.2978
  br i1 %descriptor.range.valid.2980, label %descriptor.valid.2982, label %descriptor.invalid.2983
descriptor.invalid.2983:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2982:
  %descriptor.initialized.status.2984 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2968, i32 %local.check.extent.2969)
  %helper.ok.2985 = icmp eq i32 %descriptor.initialized.status.2984, 0
  br i1 %helper.ok.2985, label %helper.continue.2986, label %frame.failure.0
helper.continue.2986:
  br label %local.descriptor.checked.2967
local.descriptor.inactive.2966:
  br label %local.descriptor.checked.2967
local.descriptor.checked.2967:
  %local.is.active.2987 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2987, label %local.descriptor.active.2988, label %local.descriptor.inactive.2989
local.descriptor.active.2988:
  %local.check.offset.2991 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2992 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2993 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2994 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2995 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2996 = load i32, ptr %context.field.2995, align 4
  %stack.sub.2999 = sub i32 %local.check.owner.end.2994, %local.check.offset.2991
  %descriptor.owner.inside.2997 = icmp ule i32 %local.check.owner.end.2994, %context.value.2996
  %descriptor.offset.inside.2998 = icmp ule i32 %local.check.offset.2991, %local.check.owner.end.2994
  %descriptor.extent.inside.3000 = icmp ule i32 %local.check.extent.2992, %stack.sub.2999
  %descriptor.payload.inside.3001 = icmp ule i32 %local.check.payload.2993, %local.check.extent.2992
  %descriptor.owner.offset.valid.3002 = and i1 %descriptor.owner.inside.2997, %descriptor.offset.inside.2998
  %descriptor.range.inside.3004 = and i1 %descriptor.owner.offset.valid.3002, %descriptor.extent.inside.3000
  %descriptor.range.valid.3003 = and i1 %descriptor.range.inside.3004, %descriptor.payload.inside.3001
  br i1 %descriptor.range.valid.3003, label %descriptor.valid.3005, label %descriptor.invalid.3006
descriptor.invalid.3006:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3005:
  %descriptor.initialized.status.3007 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2991, i32 %local.check.extent.2992)
  %helper.ok.3008 = icmp eq i32 %descriptor.initialized.status.3007, 0
  br i1 %helper.ok.3008, label %helper.continue.3009, label %frame.failure.0
helper.continue.3009:
  br label %local.descriptor.checked.2990
local.descriptor.inactive.2989:
  br label %local.descriptor.checked.2990
local.descriptor.checked.2990:
  %step.status.3010 = call i32 @al_owning_charge_step(ptr %ctx, i32 22)
  %helper.ok.3011 = icmp eq i32 %step.status.3010, 0
  br i1 %helper.ok.3011, label %helper.continue.3012, label %frame.failure.0
helper.continue.3012:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %local.resolved.offset.2830, i32 %local.resolved.extent.2831, i32 %local.resolved.payload.2832, i32 0, i32 0)
  %context.field.3013 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3014 = load i32, ptr %context.field.3013, align 4
  %runtime.ok.3015 = icmp eq i32 %context.value.3014, 0
  br i1 %runtime.ok.3015, label %runtime.continue.3016, label %frame.failure.0
runtime.continue.3016:
  %local.is.active.3017 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.3017, label %local.descriptor.active.3018, label %local.descriptor.inactive.3019
local.descriptor.active.3018:
  %local.check.offset.3021 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.3022 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.3023 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.3024 = load i32, ptr %local.owner.end.6, align 4
  %context.field.3025 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3026 = load i32, ptr %context.field.3025, align 4
  %stack.sub.3029 = sub i32 %local.check.owner.end.3024, %local.check.offset.3021
  %descriptor.owner.inside.3027 = icmp ule i32 %local.check.owner.end.3024, %context.value.3026
  %descriptor.offset.inside.3028 = icmp ule i32 %local.check.offset.3021, %local.check.owner.end.3024
  %descriptor.extent.inside.3030 = icmp ule i32 %local.check.extent.3022, %stack.sub.3029
  %descriptor.payload.inside.3031 = icmp ule i32 %local.check.payload.3023, %local.check.extent.3022
  %descriptor.owner.offset.valid.3032 = and i1 %descriptor.owner.inside.3027, %descriptor.offset.inside.3028
  %descriptor.range.inside.3034 = and i1 %descriptor.owner.offset.valid.3032, %descriptor.extent.inside.3030
  %descriptor.range.valid.3033 = and i1 %descriptor.range.inside.3034, %descriptor.payload.inside.3031
  br i1 %descriptor.range.valid.3033, label %descriptor.valid.3035, label %descriptor.invalid.3036
descriptor.invalid.3036:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3035:
  %descriptor.initialized.status.3037 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3021, i32 %local.check.extent.3022)
  %helper.ok.3038 = icmp eq i32 %descriptor.initialized.status.3037, 0
  br i1 %helper.ok.3038, label %helper.continue.3039, label %frame.failure.0
helper.continue.3039:
  br label %local.descriptor.checked.3020
local.descriptor.inactive.3019:
  br label %local.descriptor.checked.3020
local.descriptor.checked.3020:
  %local.is.active.3040 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.3040, label %local.descriptor.active.3041, label %local.descriptor.inactive.3042
local.descriptor.active.3041:
  %local.check.offset.3044 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.3045 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.3046 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.3047 = load i32, ptr %local.owner.end.12, align 4
  %context.field.3048 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3049 = load i32, ptr %context.field.3048, align 4
  %stack.sub.3052 = sub i32 %local.check.owner.end.3047, %local.check.offset.3044
  %descriptor.owner.inside.3050 = icmp ule i32 %local.check.owner.end.3047, %context.value.3049
  %descriptor.offset.inside.3051 = icmp ule i32 %local.check.offset.3044, %local.check.owner.end.3047
  %descriptor.extent.inside.3053 = icmp ule i32 %local.check.extent.3045, %stack.sub.3052
  %descriptor.payload.inside.3054 = icmp ule i32 %local.check.payload.3046, %local.check.extent.3045
  %descriptor.owner.offset.valid.3055 = and i1 %descriptor.owner.inside.3050, %descriptor.offset.inside.3051
  %descriptor.range.inside.3057 = and i1 %descriptor.owner.offset.valid.3055, %descriptor.extent.inside.3053
  %descriptor.range.valid.3056 = and i1 %descriptor.range.inside.3057, %descriptor.payload.inside.3054
  br i1 %descriptor.range.valid.3056, label %descriptor.valid.3058, label %descriptor.invalid.3059
descriptor.invalid.3059:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3058:
  %descriptor.initialized.status.3060 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3044, i32 %local.check.extent.3045)
  %helper.ok.3061 = icmp eq i32 %descriptor.initialized.status.3060, 0
  br i1 %helper.ok.3061, label %helper.continue.3062, label %frame.failure.0
helper.continue.3062:
  br label %local.descriptor.checked.3043
local.descriptor.inactive.3042:
  br label %local.descriptor.checked.3043
local.descriptor.checked.3043:
  %local.is.active.3063 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.3063, label %local.descriptor.active.3064, label %local.descriptor.inactive.3065
local.descriptor.active.3064:
  %local.check.offset.3067 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.3068 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.3069 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.3070 = load i32, ptr %local.owner.end.18, align 4
  %context.field.3071 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3072 = load i32, ptr %context.field.3071, align 4
  %stack.sub.3075 = sub i32 %local.check.owner.end.3070, %local.check.offset.3067
  %descriptor.owner.inside.3073 = icmp ule i32 %local.check.owner.end.3070, %context.value.3072
  %descriptor.offset.inside.3074 = icmp ule i32 %local.check.offset.3067, %local.check.owner.end.3070
  %descriptor.extent.inside.3076 = icmp ule i32 %local.check.extent.3068, %stack.sub.3075
  %descriptor.payload.inside.3077 = icmp ule i32 %local.check.payload.3069, %local.check.extent.3068
  %descriptor.owner.offset.valid.3078 = and i1 %descriptor.owner.inside.3073, %descriptor.offset.inside.3074
  %descriptor.range.inside.3080 = and i1 %descriptor.owner.offset.valid.3078, %descriptor.extent.inside.3076
  %descriptor.range.valid.3079 = and i1 %descriptor.range.inside.3080, %descriptor.payload.inside.3077
  br i1 %descriptor.range.valid.3079, label %descriptor.valid.3081, label %descriptor.invalid.3082
descriptor.invalid.3082:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3081:
  %descriptor.initialized.status.3083 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3067, i32 %local.check.extent.3068)
  %helper.ok.3084 = icmp eq i32 %descriptor.initialized.status.3083, 0
  br i1 %helper.ok.3084, label %helper.continue.3085, label %frame.failure.0
helper.continue.3085:
  br label %local.descriptor.checked.3066
local.descriptor.inactive.3065:
  br label %local.descriptor.checked.3066
local.descriptor.checked.3066:
  %local.is.active.3086 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.3086, label %local.descriptor.active.3087, label %local.descriptor.inactive.3088
local.descriptor.active.3087:
  %local.check.offset.3090 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.3091 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.3092 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.3093 = load i32, ptr %local.owner.end.24, align 4
  %context.field.3094 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3095 = load i32, ptr %context.field.3094, align 4
  %stack.sub.3098 = sub i32 %local.check.owner.end.3093, %local.check.offset.3090
  %descriptor.owner.inside.3096 = icmp ule i32 %local.check.owner.end.3093, %context.value.3095
  %descriptor.offset.inside.3097 = icmp ule i32 %local.check.offset.3090, %local.check.owner.end.3093
  %descriptor.extent.inside.3099 = icmp ule i32 %local.check.extent.3091, %stack.sub.3098
  %descriptor.payload.inside.3100 = icmp ule i32 %local.check.payload.3092, %local.check.extent.3091
  %descriptor.owner.offset.valid.3101 = and i1 %descriptor.owner.inside.3096, %descriptor.offset.inside.3097
  %descriptor.range.inside.3103 = and i1 %descriptor.owner.offset.valid.3101, %descriptor.extent.inside.3099
  %descriptor.range.valid.3102 = and i1 %descriptor.range.inside.3103, %descriptor.payload.inside.3100
  br i1 %descriptor.range.valid.3102, label %descriptor.valid.3104, label %descriptor.invalid.3105
descriptor.invalid.3105:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3104:
  %descriptor.initialized.status.3106 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3090, i32 %local.check.extent.3091)
  %helper.ok.3107 = icmp eq i32 %descriptor.initialized.status.3106, 0
  br i1 %helper.ok.3107, label %helper.continue.3108, label %frame.failure.0
helper.continue.3108:
  br label %local.descriptor.checked.3089
local.descriptor.inactive.3088:
  br label %local.descriptor.checked.3089
local.descriptor.checked.3089:
  %local.is.active.3109 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.3109, label %local.descriptor.active.3110, label %local.descriptor.inactive.3111
local.descriptor.active.3110:
  %local.check.offset.3113 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.3114 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.3115 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.3116 = load i32, ptr %local.owner.end.30, align 4
  %context.field.3117 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3118 = load i32, ptr %context.field.3117, align 4
  %stack.sub.3121 = sub i32 %local.check.owner.end.3116, %local.check.offset.3113
  %descriptor.owner.inside.3119 = icmp ule i32 %local.check.owner.end.3116, %context.value.3118
  %descriptor.offset.inside.3120 = icmp ule i32 %local.check.offset.3113, %local.check.owner.end.3116
  %descriptor.extent.inside.3122 = icmp ule i32 %local.check.extent.3114, %stack.sub.3121
  %descriptor.payload.inside.3123 = icmp ule i32 %local.check.payload.3115, %local.check.extent.3114
  %descriptor.owner.offset.valid.3124 = and i1 %descriptor.owner.inside.3119, %descriptor.offset.inside.3120
  %descriptor.range.inside.3126 = and i1 %descriptor.owner.offset.valid.3124, %descriptor.extent.inside.3122
  %descriptor.range.valid.3125 = and i1 %descriptor.range.inside.3126, %descriptor.payload.inside.3123
  br i1 %descriptor.range.valid.3125, label %descriptor.valid.3127, label %descriptor.invalid.3128
descriptor.invalid.3128:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3127:
  %descriptor.initialized.status.3129 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3113, i32 %local.check.extent.3114)
  %helper.ok.3130 = icmp eq i32 %descriptor.initialized.status.3129, 0
  br i1 %helper.ok.3130, label %helper.continue.3131, label %frame.failure.0
helper.continue.3131:
  br label %local.descriptor.checked.3112
local.descriptor.inactive.3111:
  br label %local.descriptor.checked.3112
local.descriptor.checked.3112:
  %local.is.active.3132 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.3132, label %local.descriptor.active.3133, label %local.descriptor.inactive.3134
local.descriptor.active.3133:
  %local.check.offset.3136 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.3137 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.3138 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.3139 = load i32, ptr %local.owner.end.36, align 4
  %context.field.3140 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3141 = load i32, ptr %context.field.3140, align 4
  %stack.sub.3144 = sub i32 %local.check.owner.end.3139, %local.check.offset.3136
  %descriptor.owner.inside.3142 = icmp ule i32 %local.check.owner.end.3139, %context.value.3141
  %descriptor.offset.inside.3143 = icmp ule i32 %local.check.offset.3136, %local.check.owner.end.3139
  %descriptor.extent.inside.3145 = icmp ule i32 %local.check.extent.3137, %stack.sub.3144
  %descriptor.payload.inside.3146 = icmp ule i32 %local.check.payload.3138, %local.check.extent.3137
  %descriptor.owner.offset.valid.3147 = and i1 %descriptor.owner.inside.3142, %descriptor.offset.inside.3143
  %descriptor.range.inside.3149 = and i1 %descriptor.owner.offset.valid.3147, %descriptor.extent.inside.3145
  %descriptor.range.valid.3148 = and i1 %descriptor.range.inside.3149, %descriptor.payload.inside.3146
  br i1 %descriptor.range.valid.3148, label %descriptor.valid.3150, label %descriptor.invalid.3151
descriptor.invalid.3151:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3150:
  %descriptor.initialized.status.3152 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3136, i32 %local.check.extent.3137)
  %helper.ok.3153 = icmp eq i32 %descriptor.initialized.status.3152, 0
  br i1 %helper.ok.3153, label %helper.continue.3154, label %frame.failure.0
helper.continue.3154:
  br label %local.descriptor.checked.3135
local.descriptor.inactive.3134:
  br label %local.descriptor.checked.3135
local.descriptor.checked.3135:
  %step.status.3155 = call i32 @al_owning_charge_step(ptr %ctx, i32 23)
  %helper.ok.3156 = icmp eq i32 %step.status.3155, 0
  br i1 %helper.ok.3156, label %helper.continue.3157, label %frame.failure.0
helper.continue.3157:
  %local.resolved.offset.3158 = load i32, ptr %local.offset.15, align 4
  %local.resolved.extent.3159 = load i32, ptr %local.extent.16, align 4
  %local.resolved.payload.3160 = load i32, ptr %local.payload.17, align 4
  %local.resolved.owner.end.3161 = load i32, ptr %local.owner.end.18, align 4
  %context.field.3162 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3163 = load i32, ptr %context.field.3162, align 4
  %stack.sub.3166 = sub i32 %local.resolved.owner.end.3161, %local.resolved.offset.3158
  %descriptor.owner.inside.3164 = icmp ule i32 %local.resolved.owner.end.3161, %context.value.3163
  %descriptor.offset.inside.3165 = icmp ule i32 %local.resolved.offset.3158, %local.resolved.owner.end.3161
  %descriptor.extent.inside.3167 = icmp ule i32 %local.resolved.extent.3159, %stack.sub.3166
  %descriptor.payload.inside.3168 = icmp ule i32 %local.resolved.payload.3160, %local.resolved.extent.3159
  %descriptor.owner.offset.valid.3169 = and i1 %descriptor.owner.inside.3164, %descriptor.offset.inside.3165
  %descriptor.range.inside.3171 = and i1 %descriptor.owner.offset.valid.3169, %descriptor.extent.inside.3167
  %descriptor.range.valid.3170 = and i1 %descriptor.range.inside.3171, %descriptor.payload.inside.3168
  %descriptor.type.valid.3172 = icmp eq i32 1, 1
  %descriptor.valid.3173 = and i1 %descriptor.range.valid.3170, %descriptor.type.valid.3172
  br i1 %descriptor.valid.3173, label %descriptor.valid.3174, label %descriptor.invalid.3175
descriptor.invalid.3175:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3174:
  %descriptor.initialized.status.3176 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.3158, i32 %local.resolved.extent.3159)
  %helper.ok.3177 = icmp eq i32 %descriptor.initialized.status.3176, 0
  br i1 %helper.ok.3177, label %helper.continue.3178, label %frame.failure.0
helper.continue.3178:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %local.resolved.offset.3158, i32 20, i32 %local.resolved.payload.3160, i32 %local.resolved.owner.end.3161, i32 %local.resolved.extent.3159)
  %context.field.3179 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3180 = load i32, ptr %context.field.3179, align 4
  %runtime.ok.3181 = icmp eq i32 %context.value.3180, 0
  br i1 %runtime.ok.3181, label %runtime.continue.3182, label %frame.failure.0
runtime.continue.3182:
  %context.field.3183 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3184 = load i32, ptr %context.field.3183, align 4
  %stack.sub.3187 = sub i32 %local.resolved.owner.end.3161, %local.resolved.offset.3158
  %descriptor.owner.inside.3185 = icmp ule i32 %local.resolved.owner.end.3161, %context.value.3184
  %descriptor.offset.inside.3186 = icmp ule i32 %local.resolved.offset.3158, %local.resolved.owner.end.3161
  %descriptor.extent.inside.3188 = icmp ule i32 %local.resolved.extent.3159, %stack.sub.3187
  %descriptor.payload.inside.3189 = icmp ule i32 %local.resolved.payload.3160, %local.resolved.extent.3159
  %descriptor.owner.offset.valid.3190 = and i1 %descriptor.owner.inside.3185, %descriptor.offset.inside.3186
  %descriptor.range.inside.3192 = and i1 %descriptor.owner.offset.valid.3190, %descriptor.extent.inside.3188
  %descriptor.range.valid.3191 = and i1 %descriptor.range.inside.3192, %descriptor.payload.inside.3189
  %descriptor.type.valid.3193 = icmp eq i32 1, 1
  %descriptor.valid.3194 = and i1 %descriptor.range.valid.3191, %descriptor.type.valid.3193
  br i1 %descriptor.valid.3194, label %descriptor.valid.3195, label %descriptor.invalid.3196
descriptor.invalid.3196:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3195:
  %descriptor.initialized.status.3197 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.3158, i32 %local.resolved.extent.3159)
  %helper.ok.3198 = icmp eq i32 %descriptor.initialized.status.3197, 0
  br i1 %helper.ok.3198, label %helper.continue.3199, label %frame.failure.0
helper.continue.3199:
  %local.is.active.3200 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.3200, label %local.descriptor.active.3201, label %local.descriptor.inactive.3202
local.descriptor.active.3201:
  %local.check.offset.3204 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.3205 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.3206 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.3207 = load i32, ptr %local.owner.end.6, align 4
  %context.field.3208 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3209 = load i32, ptr %context.field.3208, align 4
  %stack.sub.3212 = sub i32 %local.check.owner.end.3207, %local.check.offset.3204
  %descriptor.owner.inside.3210 = icmp ule i32 %local.check.owner.end.3207, %context.value.3209
  %descriptor.offset.inside.3211 = icmp ule i32 %local.check.offset.3204, %local.check.owner.end.3207
  %descriptor.extent.inside.3213 = icmp ule i32 %local.check.extent.3205, %stack.sub.3212
  %descriptor.payload.inside.3214 = icmp ule i32 %local.check.payload.3206, %local.check.extent.3205
  %descriptor.owner.offset.valid.3215 = and i1 %descriptor.owner.inside.3210, %descriptor.offset.inside.3211
  %descriptor.range.inside.3217 = and i1 %descriptor.owner.offset.valid.3215, %descriptor.extent.inside.3213
  %descriptor.range.valid.3216 = and i1 %descriptor.range.inside.3217, %descriptor.payload.inside.3214
  br i1 %descriptor.range.valid.3216, label %descriptor.valid.3218, label %descriptor.invalid.3219
descriptor.invalid.3219:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3218:
  %descriptor.initialized.status.3220 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3204, i32 %local.check.extent.3205)
  %helper.ok.3221 = icmp eq i32 %descriptor.initialized.status.3220, 0
  br i1 %helper.ok.3221, label %helper.continue.3222, label %frame.failure.0
helper.continue.3222:
  br label %local.descriptor.checked.3203
local.descriptor.inactive.3202:
  br label %local.descriptor.checked.3203
local.descriptor.checked.3203:
  %local.is.active.3223 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.3223, label %local.descriptor.active.3224, label %local.descriptor.inactive.3225
local.descriptor.active.3224:
  %local.check.offset.3227 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.3228 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.3229 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.3230 = load i32, ptr %local.owner.end.12, align 4
  %context.field.3231 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3232 = load i32, ptr %context.field.3231, align 4
  %stack.sub.3235 = sub i32 %local.check.owner.end.3230, %local.check.offset.3227
  %descriptor.owner.inside.3233 = icmp ule i32 %local.check.owner.end.3230, %context.value.3232
  %descriptor.offset.inside.3234 = icmp ule i32 %local.check.offset.3227, %local.check.owner.end.3230
  %descriptor.extent.inside.3236 = icmp ule i32 %local.check.extent.3228, %stack.sub.3235
  %descriptor.payload.inside.3237 = icmp ule i32 %local.check.payload.3229, %local.check.extent.3228
  %descriptor.owner.offset.valid.3238 = and i1 %descriptor.owner.inside.3233, %descriptor.offset.inside.3234
  %descriptor.range.inside.3240 = and i1 %descriptor.owner.offset.valid.3238, %descriptor.extent.inside.3236
  %descriptor.range.valid.3239 = and i1 %descriptor.range.inside.3240, %descriptor.payload.inside.3237
  br i1 %descriptor.range.valid.3239, label %descriptor.valid.3241, label %descriptor.invalid.3242
descriptor.invalid.3242:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3241:
  %descriptor.initialized.status.3243 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3227, i32 %local.check.extent.3228)
  %helper.ok.3244 = icmp eq i32 %descriptor.initialized.status.3243, 0
  br i1 %helper.ok.3244, label %helper.continue.3245, label %frame.failure.0
helper.continue.3245:
  br label %local.descriptor.checked.3226
local.descriptor.inactive.3225:
  br label %local.descriptor.checked.3226
local.descriptor.checked.3226:
  %local.is.active.3246 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.3246, label %local.descriptor.active.3247, label %local.descriptor.inactive.3248
local.descriptor.active.3247:
  %local.check.offset.3250 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.3251 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.3252 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.3253 = load i32, ptr %local.owner.end.18, align 4
  %context.field.3254 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3255 = load i32, ptr %context.field.3254, align 4
  %stack.sub.3258 = sub i32 %local.check.owner.end.3253, %local.check.offset.3250
  %descriptor.owner.inside.3256 = icmp ule i32 %local.check.owner.end.3253, %context.value.3255
  %descriptor.offset.inside.3257 = icmp ule i32 %local.check.offset.3250, %local.check.owner.end.3253
  %descriptor.extent.inside.3259 = icmp ule i32 %local.check.extent.3251, %stack.sub.3258
  %descriptor.payload.inside.3260 = icmp ule i32 %local.check.payload.3252, %local.check.extent.3251
  %descriptor.owner.offset.valid.3261 = and i1 %descriptor.owner.inside.3256, %descriptor.offset.inside.3257
  %descriptor.range.inside.3263 = and i1 %descriptor.owner.offset.valid.3261, %descriptor.extent.inside.3259
  %descriptor.range.valid.3262 = and i1 %descriptor.range.inside.3263, %descriptor.payload.inside.3260
  br i1 %descriptor.range.valid.3262, label %descriptor.valid.3264, label %descriptor.invalid.3265
descriptor.invalid.3265:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3264:
  %descriptor.initialized.status.3266 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3250, i32 %local.check.extent.3251)
  %helper.ok.3267 = icmp eq i32 %descriptor.initialized.status.3266, 0
  br i1 %helper.ok.3267, label %helper.continue.3268, label %frame.failure.0
helper.continue.3268:
  br label %local.descriptor.checked.3249
local.descriptor.inactive.3248:
  br label %local.descriptor.checked.3249
local.descriptor.checked.3249:
  %local.is.active.3269 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.3269, label %local.descriptor.active.3270, label %local.descriptor.inactive.3271
local.descriptor.active.3270:
  %local.check.offset.3273 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.3274 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.3275 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.3276 = load i32, ptr %local.owner.end.24, align 4
  %context.field.3277 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3278 = load i32, ptr %context.field.3277, align 4
  %stack.sub.3281 = sub i32 %local.check.owner.end.3276, %local.check.offset.3273
  %descriptor.owner.inside.3279 = icmp ule i32 %local.check.owner.end.3276, %context.value.3278
  %descriptor.offset.inside.3280 = icmp ule i32 %local.check.offset.3273, %local.check.owner.end.3276
  %descriptor.extent.inside.3282 = icmp ule i32 %local.check.extent.3274, %stack.sub.3281
  %descriptor.payload.inside.3283 = icmp ule i32 %local.check.payload.3275, %local.check.extent.3274
  %descriptor.owner.offset.valid.3284 = and i1 %descriptor.owner.inside.3279, %descriptor.offset.inside.3280
  %descriptor.range.inside.3286 = and i1 %descriptor.owner.offset.valid.3284, %descriptor.extent.inside.3282
  %descriptor.range.valid.3285 = and i1 %descriptor.range.inside.3286, %descriptor.payload.inside.3283
  br i1 %descriptor.range.valid.3285, label %descriptor.valid.3287, label %descriptor.invalid.3288
descriptor.invalid.3288:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3287:
  %descriptor.initialized.status.3289 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3273, i32 %local.check.extent.3274)
  %helper.ok.3290 = icmp eq i32 %descriptor.initialized.status.3289, 0
  br i1 %helper.ok.3290, label %helper.continue.3291, label %frame.failure.0
helper.continue.3291:
  br label %local.descriptor.checked.3272
local.descriptor.inactive.3271:
  br label %local.descriptor.checked.3272
local.descriptor.checked.3272:
  %local.is.active.3292 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.3292, label %local.descriptor.active.3293, label %local.descriptor.inactive.3294
local.descriptor.active.3293:
  %local.check.offset.3296 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.3297 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.3298 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.3299 = load i32, ptr %local.owner.end.30, align 4
  %context.field.3300 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3301 = load i32, ptr %context.field.3300, align 4
  %stack.sub.3304 = sub i32 %local.check.owner.end.3299, %local.check.offset.3296
  %descriptor.owner.inside.3302 = icmp ule i32 %local.check.owner.end.3299, %context.value.3301
  %descriptor.offset.inside.3303 = icmp ule i32 %local.check.offset.3296, %local.check.owner.end.3299
  %descriptor.extent.inside.3305 = icmp ule i32 %local.check.extent.3297, %stack.sub.3304
  %descriptor.payload.inside.3306 = icmp ule i32 %local.check.payload.3298, %local.check.extent.3297
  %descriptor.owner.offset.valid.3307 = and i1 %descriptor.owner.inside.3302, %descriptor.offset.inside.3303
  %descriptor.range.inside.3309 = and i1 %descriptor.owner.offset.valid.3307, %descriptor.extent.inside.3305
  %descriptor.range.valid.3308 = and i1 %descriptor.range.inside.3309, %descriptor.payload.inside.3306
  br i1 %descriptor.range.valid.3308, label %descriptor.valid.3310, label %descriptor.invalid.3311
descriptor.invalid.3311:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3310:
  %descriptor.initialized.status.3312 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3296, i32 %local.check.extent.3297)
  %helper.ok.3313 = icmp eq i32 %descriptor.initialized.status.3312, 0
  br i1 %helper.ok.3313, label %helper.continue.3314, label %frame.failure.0
helper.continue.3314:
  br label %local.descriptor.checked.3295
local.descriptor.inactive.3294:
  br label %local.descriptor.checked.3295
local.descriptor.checked.3295:
  %local.is.active.3315 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.3315, label %local.descriptor.active.3316, label %local.descriptor.inactive.3317
local.descriptor.active.3316:
  %local.check.offset.3319 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.3320 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.3321 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.3322 = load i32, ptr %local.owner.end.36, align 4
  %context.field.3323 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3324 = load i32, ptr %context.field.3323, align 4
  %stack.sub.3327 = sub i32 %local.check.owner.end.3322, %local.check.offset.3319
  %descriptor.owner.inside.3325 = icmp ule i32 %local.check.owner.end.3322, %context.value.3324
  %descriptor.offset.inside.3326 = icmp ule i32 %local.check.offset.3319, %local.check.owner.end.3322
  %descriptor.extent.inside.3328 = icmp ule i32 %local.check.extent.3320, %stack.sub.3327
  %descriptor.payload.inside.3329 = icmp ule i32 %local.check.payload.3321, %local.check.extent.3320
  %descriptor.owner.offset.valid.3330 = and i1 %descriptor.owner.inside.3325, %descriptor.offset.inside.3326
  %descriptor.range.inside.3332 = and i1 %descriptor.owner.offset.valid.3330, %descriptor.extent.inside.3328
  %descriptor.range.valid.3331 = and i1 %descriptor.range.inside.3332, %descriptor.payload.inside.3329
  br i1 %descriptor.range.valid.3331, label %descriptor.valid.3333, label %descriptor.invalid.3334
descriptor.invalid.3334:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3333:
  %descriptor.initialized.status.3335 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3319, i32 %local.check.extent.3320)
  %helper.ok.3336 = icmp eq i32 %descriptor.initialized.status.3335, 0
  br i1 %helper.ok.3336, label %helper.continue.3337, label %frame.failure.0
helper.continue.3337:
  br label %local.descriptor.checked.3318
local.descriptor.inactive.3317:
  br label %local.descriptor.checked.3318
local.descriptor.checked.3318:
  %step.status.3338 = call i32 @al_owning_charge_step(ptr %ctx, i32 24)
  %helper.ok.3339 = icmp eq i32 %step.status.3338, 0
  br i1 %helper.ok.3339, label %helper.continue.3340, label %frame.failure.0
helper.continue.3340:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %local.resolved.offset.3158, i32 %local.resolved.extent.3159, i32 %local.resolved.payload.3160, i32 0, i32 0)
  %context.field.3341 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3342 = load i32, ptr %context.field.3341, align 4
  %runtime.ok.3343 = icmp eq i32 %context.value.3342, 0
  br i1 %runtime.ok.3343, label %runtime.continue.3344, label %frame.failure.0
runtime.continue.3344:
  %local.is.active.3345 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.3345, label %local.descriptor.active.3346, label %local.descriptor.inactive.3347
local.descriptor.active.3346:
  %local.check.offset.3349 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.3350 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.3351 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.3352 = load i32, ptr %local.owner.end.6, align 4
  %context.field.3353 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3354 = load i32, ptr %context.field.3353, align 4
  %stack.sub.3357 = sub i32 %local.check.owner.end.3352, %local.check.offset.3349
  %descriptor.owner.inside.3355 = icmp ule i32 %local.check.owner.end.3352, %context.value.3354
  %descriptor.offset.inside.3356 = icmp ule i32 %local.check.offset.3349, %local.check.owner.end.3352
  %descriptor.extent.inside.3358 = icmp ule i32 %local.check.extent.3350, %stack.sub.3357
  %descriptor.payload.inside.3359 = icmp ule i32 %local.check.payload.3351, %local.check.extent.3350
  %descriptor.owner.offset.valid.3360 = and i1 %descriptor.owner.inside.3355, %descriptor.offset.inside.3356
  %descriptor.range.inside.3362 = and i1 %descriptor.owner.offset.valid.3360, %descriptor.extent.inside.3358
  %descriptor.range.valid.3361 = and i1 %descriptor.range.inside.3362, %descriptor.payload.inside.3359
  br i1 %descriptor.range.valid.3361, label %descriptor.valid.3363, label %descriptor.invalid.3364
descriptor.invalid.3364:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3363:
  %descriptor.initialized.status.3365 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3349, i32 %local.check.extent.3350)
  %helper.ok.3366 = icmp eq i32 %descriptor.initialized.status.3365, 0
  br i1 %helper.ok.3366, label %helper.continue.3367, label %frame.failure.0
helper.continue.3367:
  br label %local.descriptor.checked.3348
local.descriptor.inactive.3347:
  br label %local.descriptor.checked.3348
local.descriptor.checked.3348:
  %local.is.active.3368 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.3368, label %local.descriptor.active.3369, label %local.descriptor.inactive.3370
local.descriptor.active.3369:
  %local.check.offset.3372 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.3373 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.3374 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.3375 = load i32, ptr %local.owner.end.12, align 4
  %context.field.3376 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3377 = load i32, ptr %context.field.3376, align 4
  %stack.sub.3380 = sub i32 %local.check.owner.end.3375, %local.check.offset.3372
  %descriptor.owner.inside.3378 = icmp ule i32 %local.check.owner.end.3375, %context.value.3377
  %descriptor.offset.inside.3379 = icmp ule i32 %local.check.offset.3372, %local.check.owner.end.3375
  %descriptor.extent.inside.3381 = icmp ule i32 %local.check.extent.3373, %stack.sub.3380
  %descriptor.payload.inside.3382 = icmp ule i32 %local.check.payload.3374, %local.check.extent.3373
  %descriptor.owner.offset.valid.3383 = and i1 %descriptor.owner.inside.3378, %descriptor.offset.inside.3379
  %descriptor.range.inside.3385 = and i1 %descriptor.owner.offset.valid.3383, %descriptor.extent.inside.3381
  %descriptor.range.valid.3384 = and i1 %descriptor.range.inside.3385, %descriptor.payload.inside.3382
  br i1 %descriptor.range.valid.3384, label %descriptor.valid.3386, label %descriptor.invalid.3387
descriptor.invalid.3387:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3386:
  %descriptor.initialized.status.3388 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3372, i32 %local.check.extent.3373)
  %helper.ok.3389 = icmp eq i32 %descriptor.initialized.status.3388, 0
  br i1 %helper.ok.3389, label %helper.continue.3390, label %frame.failure.0
helper.continue.3390:
  br label %local.descriptor.checked.3371
local.descriptor.inactive.3370:
  br label %local.descriptor.checked.3371
local.descriptor.checked.3371:
  %local.is.active.3391 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.3391, label %local.descriptor.active.3392, label %local.descriptor.inactive.3393
local.descriptor.active.3392:
  %local.check.offset.3395 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.3396 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.3397 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.3398 = load i32, ptr %local.owner.end.18, align 4
  %context.field.3399 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3400 = load i32, ptr %context.field.3399, align 4
  %stack.sub.3403 = sub i32 %local.check.owner.end.3398, %local.check.offset.3395
  %descriptor.owner.inside.3401 = icmp ule i32 %local.check.owner.end.3398, %context.value.3400
  %descriptor.offset.inside.3402 = icmp ule i32 %local.check.offset.3395, %local.check.owner.end.3398
  %descriptor.extent.inside.3404 = icmp ule i32 %local.check.extent.3396, %stack.sub.3403
  %descriptor.payload.inside.3405 = icmp ule i32 %local.check.payload.3397, %local.check.extent.3396
  %descriptor.owner.offset.valid.3406 = and i1 %descriptor.owner.inside.3401, %descriptor.offset.inside.3402
  %descriptor.range.inside.3408 = and i1 %descriptor.owner.offset.valid.3406, %descriptor.extent.inside.3404
  %descriptor.range.valid.3407 = and i1 %descriptor.range.inside.3408, %descriptor.payload.inside.3405
  br i1 %descriptor.range.valid.3407, label %descriptor.valid.3409, label %descriptor.invalid.3410
descriptor.invalid.3410:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3409:
  %descriptor.initialized.status.3411 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3395, i32 %local.check.extent.3396)
  %helper.ok.3412 = icmp eq i32 %descriptor.initialized.status.3411, 0
  br i1 %helper.ok.3412, label %helper.continue.3413, label %frame.failure.0
helper.continue.3413:
  br label %local.descriptor.checked.3394
local.descriptor.inactive.3393:
  br label %local.descriptor.checked.3394
local.descriptor.checked.3394:
  %local.is.active.3414 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.3414, label %local.descriptor.active.3415, label %local.descriptor.inactive.3416
local.descriptor.active.3415:
  %local.check.offset.3418 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.3419 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.3420 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.3421 = load i32, ptr %local.owner.end.24, align 4
  %context.field.3422 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3423 = load i32, ptr %context.field.3422, align 4
  %stack.sub.3426 = sub i32 %local.check.owner.end.3421, %local.check.offset.3418
  %descriptor.owner.inside.3424 = icmp ule i32 %local.check.owner.end.3421, %context.value.3423
  %descriptor.offset.inside.3425 = icmp ule i32 %local.check.offset.3418, %local.check.owner.end.3421
  %descriptor.extent.inside.3427 = icmp ule i32 %local.check.extent.3419, %stack.sub.3426
  %descriptor.payload.inside.3428 = icmp ule i32 %local.check.payload.3420, %local.check.extent.3419
  %descriptor.owner.offset.valid.3429 = and i1 %descriptor.owner.inside.3424, %descriptor.offset.inside.3425
  %descriptor.range.inside.3431 = and i1 %descriptor.owner.offset.valid.3429, %descriptor.extent.inside.3427
  %descriptor.range.valid.3430 = and i1 %descriptor.range.inside.3431, %descriptor.payload.inside.3428
  br i1 %descriptor.range.valid.3430, label %descriptor.valid.3432, label %descriptor.invalid.3433
descriptor.invalid.3433:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3432:
  %descriptor.initialized.status.3434 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3418, i32 %local.check.extent.3419)
  %helper.ok.3435 = icmp eq i32 %descriptor.initialized.status.3434, 0
  br i1 %helper.ok.3435, label %helper.continue.3436, label %frame.failure.0
helper.continue.3436:
  br label %local.descriptor.checked.3417
local.descriptor.inactive.3416:
  br label %local.descriptor.checked.3417
local.descriptor.checked.3417:
  %local.is.active.3437 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.3437, label %local.descriptor.active.3438, label %local.descriptor.inactive.3439
local.descriptor.active.3438:
  %local.check.offset.3441 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.3442 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.3443 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.3444 = load i32, ptr %local.owner.end.30, align 4
  %context.field.3445 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3446 = load i32, ptr %context.field.3445, align 4
  %stack.sub.3449 = sub i32 %local.check.owner.end.3444, %local.check.offset.3441
  %descriptor.owner.inside.3447 = icmp ule i32 %local.check.owner.end.3444, %context.value.3446
  %descriptor.offset.inside.3448 = icmp ule i32 %local.check.offset.3441, %local.check.owner.end.3444
  %descriptor.extent.inside.3450 = icmp ule i32 %local.check.extent.3442, %stack.sub.3449
  %descriptor.payload.inside.3451 = icmp ule i32 %local.check.payload.3443, %local.check.extent.3442
  %descriptor.owner.offset.valid.3452 = and i1 %descriptor.owner.inside.3447, %descriptor.offset.inside.3448
  %descriptor.range.inside.3454 = and i1 %descriptor.owner.offset.valid.3452, %descriptor.extent.inside.3450
  %descriptor.range.valid.3453 = and i1 %descriptor.range.inside.3454, %descriptor.payload.inside.3451
  br i1 %descriptor.range.valid.3453, label %descriptor.valid.3455, label %descriptor.invalid.3456
descriptor.invalid.3456:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3455:
  %descriptor.initialized.status.3457 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3441, i32 %local.check.extent.3442)
  %helper.ok.3458 = icmp eq i32 %descriptor.initialized.status.3457, 0
  br i1 %helper.ok.3458, label %helper.continue.3459, label %frame.failure.0
helper.continue.3459:
  br label %local.descriptor.checked.3440
local.descriptor.inactive.3439:
  br label %local.descriptor.checked.3440
local.descriptor.checked.3440:
  %local.is.active.3460 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.3460, label %local.descriptor.active.3461, label %local.descriptor.inactive.3462
local.descriptor.active.3461:
  %local.check.offset.3464 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.3465 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.3466 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.3467 = load i32, ptr %local.owner.end.36, align 4
  %context.field.3468 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3469 = load i32, ptr %context.field.3468, align 4
  %stack.sub.3472 = sub i32 %local.check.owner.end.3467, %local.check.offset.3464
  %descriptor.owner.inside.3470 = icmp ule i32 %local.check.owner.end.3467, %context.value.3469
  %descriptor.offset.inside.3471 = icmp ule i32 %local.check.offset.3464, %local.check.owner.end.3467
  %descriptor.extent.inside.3473 = icmp ule i32 %local.check.extent.3465, %stack.sub.3472
  %descriptor.payload.inside.3474 = icmp ule i32 %local.check.payload.3466, %local.check.extent.3465
  %descriptor.owner.offset.valid.3475 = and i1 %descriptor.owner.inside.3470, %descriptor.offset.inside.3471
  %descriptor.range.inside.3477 = and i1 %descriptor.owner.offset.valid.3475, %descriptor.extent.inside.3473
  %descriptor.range.valid.3476 = and i1 %descriptor.range.inside.3477, %descriptor.payload.inside.3474
  br i1 %descriptor.range.valid.3476, label %descriptor.valid.3478, label %descriptor.invalid.3479
descriptor.invalid.3479:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3478:
  %descriptor.initialized.status.3480 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3464, i32 %local.check.extent.3465)
  %helper.ok.3481 = icmp eq i32 %descriptor.initialized.status.3480, 0
  br i1 %helper.ok.3481, label %helper.continue.3482, label %frame.failure.0
helper.continue.3482:
  br label %local.descriptor.checked.3463
local.descriptor.inactive.3462:
  br label %local.descriptor.checked.3463
local.descriptor.checked.3463:
  %step.status.3483 = call i32 @al_owning_charge_step(ptr %ctx, i32 25)
  %helper.ok.3484 = icmp eq i32 %step.status.3483, 0
  br i1 %helper.ok.3484, label %helper.continue.3485, label %frame.failure.0
helper.continue.3485:
  %local.resolved.offset.3486 = load i32, ptr %local.offset.21, align 4
  %local.resolved.extent.3487 = load i32, ptr %local.extent.22, align 4
  %local.resolved.payload.3488 = load i32, ptr %local.payload.23, align 4
  %local.resolved.owner.end.3489 = load i32, ptr %local.owner.end.24, align 4
  %context.field.3490 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3491 = load i32, ptr %context.field.3490, align 4
  %stack.sub.3494 = sub i32 %local.resolved.owner.end.3489, %local.resolved.offset.3486
  %descriptor.owner.inside.3492 = icmp ule i32 %local.resolved.owner.end.3489, %context.value.3491
  %descriptor.offset.inside.3493 = icmp ule i32 %local.resolved.offset.3486, %local.resolved.owner.end.3489
  %descriptor.extent.inside.3495 = icmp ule i32 %local.resolved.extent.3487, %stack.sub.3494
  %descriptor.payload.inside.3496 = icmp ule i32 %local.resolved.payload.3488, %local.resolved.extent.3487
  %descriptor.owner.offset.valid.3497 = and i1 %descriptor.owner.inside.3492, %descriptor.offset.inside.3493
  %descriptor.range.inside.3499 = and i1 %descriptor.owner.offset.valid.3497, %descriptor.extent.inside.3495
  %descriptor.range.valid.3498 = and i1 %descriptor.range.inside.3499, %descriptor.payload.inside.3496
  %descriptor.type.valid.3500 = icmp eq i32 1, 1
  %descriptor.valid.3501 = and i1 %descriptor.range.valid.3498, %descriptor.type.valid.3500
  br i1 %descriptor.valid.3501, label %descriptor.valid.3502, label %descriptor.invalid.3503
descriptor.invalid.3503:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3502:
  %descriptor.initialized.status.3504 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.3486, i32 %local.resolved.extent.3487)
  %helper.ok.3505 = icmp eq i32 %descriptor.initialized.status.3504, 0
  br i1 %helper.ok.3505, label %helper.continue.3506, label %frame.failure.0
helper.continue.3506:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %local.resolved.offset.3486, i32 20, i32 %local.resolved.payload.3488, i32 %local.resolved.owner.end.3489, i32 %local.resolved.extent.3487)
  %context.field.3507 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3508 = load i32, ptr %context.field.3507, align 4
  %runtime.ok.3509 = icmp eq i32 %context.value.3508, 0
  br i1 %runtime.ok.3509, label %runtime.continue.3510, label %frame.failure.0
runtime.continue.3510:
  %context.field.3511 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3512 = load i32, ptr %context.field.3511, align 4
  %stack.sub.3515 = sub i32 %local.resolved.owner.end.3489, %local.resolved.offset.3486
  %descriptor.owner.inside.3513 = icmp ule i32 %local.resolved.owner.end.3489, %context.value.3512
  %descriptor.offset.inside.3514 = icmp ule i32 %local.resolved.offset.3486, %local.resolved.owner.end.3489
  %descriptor.extent.inside.3516 = icmp ule i32 %local.resolved.extent.3487, %stack.sub.3515
  %descriptor.payload.inside.3517 = icmp ule i32 %local.resolved.payload.3488, %local.resolved.extent.3487
  %descriptor.owner.offset.valid.3518 = and i1 %descriptor.owner.inside.3513, %descriptor.offset.inside.3514
  %descriptor.range.inside.3520 = and i1 %descriptor.owner.offset.valid.3518, %descriptor.extent.inside.3516
  %descriptor.range.valid.3519 = and i1 %descriptor.range.inside.3520, %descriptor.payload.inside.3517
  %descriptor.type.valid.3521 = icmp eq i32 1, 1
  %descriptor.valid.3522 = and i1 %descriptor.range.valid.3519, %descriptor.type.valid.3521
  br i1 %descriptor.valid.3522, label %descriptor.valid.3523, label %descriptor.invalid.3524
descriptor.invalid.3524:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3523:
  %descriptor.initialized.status.3525 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.3486, i32 %local.resolved.extent.3487)
  %helper.ok.3526 = icmp eq i32 %descriptor.initialized.status.3525, 0
  br i1 %helper.ok.3526, label %helper.continue.3527, label %frame.failure.0
helper.continue.3527:
  %local.is.active.3528 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.3528, label %local.descriptor.active.3529, label %local.descriptor.inactive.3530
local.descriptor.active.3529:
  %local.check.offset.3532 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.3533 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.3534 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.3535 = load i32, ptr %local.owner.end.6, align 4
  %context.field.3536 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3537 = load i32, ptr %context.field.3536, align 4
  %stack.sub.3540 = sub i32 %local.check.owner.end.3535, %local.check.offset.3532
  %descriptor.owner.inside.3538 = icmp ule i32 %local.check.owner.end.3535, %context.value.3537
  %descriptor.offset.inside.3539 = icmp ule i32 %local.check.offset.3532, %local.check.owner.end.3535
  %descriptor.extent.inside.3541 = icmp ule i32 %local.check.extent.3533, %stack.sub.3540
  %descriptor.payload.inside.3542 = icmp ule i32 %local.check.payload.3534, %local.check.extent.3533
  %descriptor.owner.offset.valid.3543 = and i1 %descriptor.owner.inside.3538, %descriptor.offset.inside.3539
  %descriptor.range.inside.3545 = and i1 %descriptor.owner.offset.valid.3543, %descriptor.extent.inside.3541
  %descriptor.range.valid.3544 = and i1 %descriptor.range.inside.3545, %descriptor.payload.inside.3542
  br i1 %descriptor.range.valid.3544, label %descriptor.valid.3546, label %descriptor.invalid.3547
descriptor.invalid.3547:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3546:
  %descriptor.initialized.status.3548 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3532, i32 %local.check.extent.3533)
  %helper.ok.3549 = icmp eq i32 %descriptor.initialized.status.3548, 0
  br i1 %helper.ok.3549, label %helper.continue.3550, label %frame.failure.0
helper.continue.3550:
  br label %local.descriptor.checked.3531
local.descriptor.inactive.3530:
  br label %local.descriptor.checked.3531
local.descriptor.checked.3531:
  %local.is.active.3551 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.3551, label %local.descriptor.active.3552, label %local.descriptor.inactive.3553
local.descriptor.active.3552:
  %local.check.offset.3555 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.3556 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.3557 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.3558 = load i32, ptr %local.owner.end.12, align 4
  %context.field.3559 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3560 = load i32, ptr %context.field.3559, align 4
  %stack.sub.3563 = sub i32 %local.check.owner.end.3558, %local.check.offset.3555
  %descriptor.owner.inside.3561 = icmp ule i32 %local.check.owner.end.3558, %context.value.3560
  %descriptor.offset.inside.3562 = icmp ule i32 %local.check.offset.3555, %local.check.owner.end.3558
  %descriptor.extent.inside.3564 = icmp ule i32 %local.check.extent.3556, %stack.sub.3563
  %descriptor.payload.inside.3565 = icmp ule i32 %local.check.payload.3557, %local.check.extent.3556
  %descriptor.owner.offset.valid.3566 = and i1 %descriptor.owner.inside.3561, %descriptor.offset.inside.3562
  %descriptor.range.inside.3568 = and i1 %descriptor.owner.offset.valid.3566, %descriptor.extent.inside.3564
  %descriptor.range.valid.3567 = and i1 %descriptor.range.inside.3568, %descriptor.payload.inside.3565
  br i1 %descriptor.range.valid.3567, label %descriptor.valid.3569, label %descriptor.invalid.3570
descriptor.invalid.3570:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3569:
  %descriptor.initialized.status.3571 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3555, i32 %local.check.extent.3556)
  %helper.ok.3572 = icmp eq i32 %descriptor.initialized.status.3571, 0
  br i1 %helper.ok.3572, label %helper.continue.3573, label %frame.failure.0
helper.continue.3573:
  br label %local.descriptor.checked.3554
local.descriptor.inactive.3553:
  br label %local.descriptor.checked.3554
local.descriptor.checked.3554:
  %local.is.active.3574 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.3574, label %local.descriptor.active.3575, label %local.descriptor.inactive.3576
local.descriptor.active.3575:
  %local.check.offset.3578 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.3579 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.3580 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.3581 = load i32, ptr %local.owner.end.18, align 4
  %context.field.3582 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3583 = load i32, ptr %context.field.3582, align 4
  %stack.sub.3586 = sub i32 %local.check.owner.end.3581, %local.check.offset.3578
  %descriptor.owner.inside.3584 = icmp ule i32 %local.check.owner.end.3581, %context.value.3583
  %descriptor.offset.inside.3585 = icmp ule i32 %local.check.offset.3578, %local.check.owner.end.3581
  %descriptor.extent.inside.3587 = icmp ule i32 %local.check.extent.3579, %stack.sub.3586
  %descriptor.payload.inside.3588 = icmp ule i32 %local.check.payload.3580, %local.check.extent.3579
  %descriptor.owner.offset.valid.3589 = and i1 %descriptor.owner.inside.3584, %descriptor.offset.inside.3585
  %descriptor.range.inside.3591 = and i1 %descriptor.owner.offset.valid.3589, %descriptor.extent.inside.3587
  %descriptor.range.valid.3590 = and i1 %descriptor.range.inside.3591, %descriptor.payload.inside.3588
  br i1 %descriptor.range.valid.3590, label %descriptor.valid.3592, label %descriptor.invalid.3593
descriptor.invalid.3593:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3592:
  %descriptor.initialized.status.3594 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3578, i32 %local.check.extent.3579)
  %helper.ok.3595 = icmp eq i32 %descriptor.initialized.status.3594, 0
  br i1 %helper.ok.3595, label %helper.continue.3596, label %frame.failure.0
helper.continue.3596:
  br label %local.descriptor.checked.3577
local.descriptor.inactive.3576:
  br label %local.descriptor.checked.3577
local.descriptor.checked.3577:
  %local.is.active.3597 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.3597, label %local.descriptor.active.3598, label %local.descriptor.inactive.3599
local.descriptor.active.3598:
  %local.check.offset.3601 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.3602 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.3603 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.3604 = load i32, ptr %local.owner.end.24, align 4
  %context.field.3605 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3606 = load i32, ptr %context.field.3605, align 4
  %stack.sub.3609 = sub i32 %local.check.owner.end.3604, %local.check.offset.3601
  %descriptor.owner.inside.3607 = icmp ule i32 %local.check.owner.end.3604, %context.value.3606
  %descriptor.offset.inside.3608 = icmp ule i32 %local.check.offset.3601, %local.check.owner.end.3604
  %descriptor.extent.inside.3610 = icmp ule i32 %local.check.extent.3602, %stack.sub.3609
  %descriptor.payload.inside.3611 = icmp ule i32 %local.check.payload.3603, %local.check.extent.3602
  %descriptor.owner.offset.valid.3612 = and i1 %descriptor.owner.inside.3607, %descriptor.offset.inside.3608
  %descriptor.range.inside.3614 = and i1 %descriptor.owner.offset.valid.3612, %descriptor.extent.inside.3610
  %descriptor.range.valid.3613 = and i1 %descriptor.range.inside.3614, %descriptor.payload.inside.3611
  br i1 %descriptor.range.valid.3613, label %descriptor.valid.3615, label %descriptor.invalid.3616
descriptor.invalid.3616:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3615:
  %descriptor.initialized.status.3617 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3601, i32 %local.check.extent.3602)
  %helper.ok.3618 = icmp eq i32 %descriptor.initialized.status.3617, 0
  br i1 %helper.ok.3618, label %helper.continue.3619, label %frame.failure.0
helper.continue.3619:
  br label %local.descriptor.checked.3600
local.descriptor.inactive.3599:
  br label %local.descriptor.checked.3600
local.descriptor.checked.3600:
  %local.is.active.3620 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.3620, label %local.descriptor.active.3621, label %local.descriptor.inactive.3622
local.descriptor.active.3621:
  %local.check.offset.3624 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.3625 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.3626 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.3627 = load i32, ptr %local.owner.end.30, align 4
  %context.field.3628 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3629 = load i32, ptr %context.field.3628, align 4
  %stack.sub.3632 = sub i32 %local.check.owner.end.3627, %local.check.offset.3624
  %descriptor.owner.inside.3630 = icmp ule i32 %local.check.owner.end.3627, %context.value.3629
  %descriptor.offset.inside.3631 = icmp ule i32 %local.check.offset.3624, %local.check.owner.end.3627
  %descriptor.extent.inside.3633 = icmp ule i32 %local.check.extent.3625, %stack.sub.3632
  %descriptor.payload.inside.3634 = icmp ule i32 %local.check.payload.3626, %local.check.extent.3625
  %descriptor.owner.offset.valid.3635 = and i1 %descriptor.owner.inside.3630, %descriptor.offset.inside.3631
  %descriptor.range.inside.3637 = and i1 %descriptor.owner.offset.valid.3635, %descriptor.extent.inside.3633
  %descriptor.range.valid.3636 = and i1 %descriptor.range.inside.3637, %descriptor.payload.inside.3634
  br i1 %descriptor.range.valid.3636, label %descriptor.valid.3638, label %descriptor.invalid.3639
descriptor.invalid.3639:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3638:
  %descriptor.initialized.status.3640 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3624, i32 %local.check.extent.3625)
  %helper.ok.3641 = icmp eq i32 %descriptor.initialized.status.3640, 0
  br i1 %helper.ok.3641, label %helper.continue.3642, label %frame.failure.0
helper.continue.3642:
  br label %local.descriptor.checked.3623
local.descriptor.inactive.3622:
  br label %local.descriptor.checked.3623
local.descriptor.checked.3623:
  %local.is.active.3643 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.3643, label %local.descriptor.active.3644, label %local.descriptor.inactive.3645
local.descriptor.active.3644:
  %local.check.offset.3647 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.3648 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.3649 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.3650 = load i32, ptr %local.owner.end.36, align 4
  %context.field.3651 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3652 = load i32, ptr %context.field.3651, align 4
  %stack.sub.3655 = sub i32 %local.check.owner.end.3650, %local.check.offset.3647
  %descriptor.owner.inside.3653 = icmp ule i32 %local.check.owner.end.3650, %context.value.3652
  %descriptor.offset.inside.3654 = icmp ule i32 %local.check.offset.3647, %local.check.owner.end.3650
  %descriptor.extent.inside.3656 = icmp ule i32 %local.check.extent.3648, %stack.sub.3655
  %descriptor.payload.inside.3657 = icmp ule i32 %local.check.payload.3649, %local.check.extent.3648
  %descriptor.owner.offset.valid.3658 = and i1 %descriptor.owner.inside.3653, %descriptor.offset.inside.3654
  %descriptor.range.inside.3660 = and i1 %descriptor.owner.offset.valid.3658, %descriptor.extent.inside.3656
  %descriptor.range.valid.3659 = and i1 %descriptor.range.inside.3660, %descriptor.payload.inside.3657
  br i1 %descriptor.range.valid.3659, label %descriptor.valid.3661, label %descriptor.invalid.3662
descriptor.invalid.3662:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3661:
  %descriptor.initialized.status.3663 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3647, i32 %local.check.extent.3648)
  %helper.ok.3664 = icmp eq i32 %descriptor.initialized.status.3663, 0
  br i1 %helper.ok.3664, label %helper.continue.3665, label %frame.failure.0
helper.continue.3665:
  br label %local.descriptor.checked.3646
local.descriptor.inactive.3645:
  br label %local.descriptor.checked.3646
local.descriptor.checked.3646:
  %step.status.3666 = call i32 @al_owning_charge_step(ptr %ctx, i32 26)
  %helper.ok.3667 = icmp eq i32 %step.status.3666, 0
  br i1 %helper.ok.3667, label %helper.continue.3668, label %frame.failure.0
helper.continue.3668:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %local.resolved.offset.3486, i32 %local.resolved.extent.3487, i32 %local.resolved.payload.3488, i32 0, i32 0)
  %context.field.3669 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3670 = load i32, ptr %context.field.3669, align 4
  %runtime.ok.3671 = icmp eq i32 %context.value.3670, 0
  br i1 %runtime.ok.3671, label %runtime.continue.3672, label %frame.failure.0
runtime.continue.3672:
  %local.is.active.3673 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.3673, label %local.descriptor.active.3674, label %local.descriptor.inactive.3675
local.descriptor.active.3674:
  %local.check.offset.3677 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.3678 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.3679 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.3680 = load i32, ptr %local.owner.end.6, align 4
  %context.field.3681 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3682 = load i32, ptr %context.field.3681, align 4
  %stack.sub.3685 = sub i32 %local.check.owner.end.3680, %local.check.offset.3677
  %descriptor.owner.inside.3683 = icmp ule i32 %local.check.owner.end.3680, %context.value.3682
  %descriptor.offset.inside.3684 = icmp ule i32 %local.check.offset.3677, %local.check.owner.end.3680
  %descriptor.extent.inside.3686 = icmp ule i32 %local.check.extent.3678, %stack.sub.3685
  %descriptor.payload.inside.3687 = icmp ule i32 %local.check.payload.3679, %local.check.extent.3678
  %descriptor.owner.offset.valid.3688 = and i1 %descriptor.owner.inside.3683, %descriptor.offset.inside.3684
  %descriptor.range.inside.3690 = and i1 %descriptor.owner.offset.valid.3688, %descriptor.extent.inside.3686
  %descriptor.range.valid.3689 = and i1 %descriptor.range.inside.3690, %descriptor.payload.inside.3687
  br i1 %descriptor.range.valid.3689, label %descriptor.valid.3691, label %descriptor.invalid.3692
descriptor.invalid.3692:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3691:
  %descriptor.initialized.status.3693 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3677, i32 %local.check.extent.3678)
  %helper.ok.3694 = icmp eq i32 %descriptor.initialized.status.3693, 0
  br i1 %helper.ok.3694, label %helper.continue.3695, label %frame.failure.0
helper.continue.3695:
  br label %local.descriptor.checked.3676
local.descriptor.inactive.3675:
  br label %local.descriptor.checked.3676
local.descriptor.checked.3676:
  %local.is.active.3696 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.3696, label %local.descriptor.active.3697, label %local.descriptor.inactive.3698
local.descriptor.active.3697:
  %local.check.offset.3700 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.3701 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.3702 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.3703 = load i32, ptr %local.owner.end.12, align 4
  %context.field.3704 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3705 = load i32, ptr %context.field.3704, align 4
  %stack.sub.3708 = sub i32 %local.check.owner.end.3703, %local.check.offset.3700
  %descriptor.owner.inside.3706 = icmp ule i32 %local.check.owner.end.3703, %context.value.3705
  %descriptor.offset.inside.3707 = icmp ule i32 %local.check.offset.3700, %local.check.owner.end.3703
  %descriptor.extent.inside.3709 = icmp ule i32 %local.check.extent.3701, %stack.sub.3708
  %descriptor.payload.inside.3710 = icmp ule i32 %local.check.payload.3702, %local.check.extent.3701
  %descriptor.owner.offset.valid.3711 = and i1 %descriptor.owner.inside.3706, %descriptor.offset.inside.3707
  %descriptor.range.inside.3713 = and i1 %descriptor.owner.offset.valid.3711, %descriptor.extent.inside.3709
  %descriptor.range.valid.3712 = and i1 %descriptor.range.inside.3713, %descriptor.payload.inside.3710
  br i1 %descriptor.range.valid.3712, label %descriptor.valid.3714, label %descriptor.invalid.3715
descriptor.invalid.3715:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3714:
  %descriptor.initialized.status.3716 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3700, i32 %local.check.extent.3701)
  %helper.ok.3717 = icmp eq i32 %descriptor.initialized.status.3716, 0
  br i1 %helper.ok.3717, label %helper.continue.3718, label %frame.failure.0
helper.continue.3718:
  br label %local.descriptor.checked.3699
local.descriptor.inactive.3698:
  br label %local.descriptor.checked.3699
local.descriptor.checked.3699:
  %local.is.active.3719 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.3719, label %local.descriptor.active.3720, label %local.descriptor.inactive.3721
local.descriptor.active.3720:
  %local.check.offset.3723 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.3724 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.3725 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.3726 = load i32, ptr %local.owner.end.18, align 4
  %context.field.3727 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3728 = load i32, ptr %context.field.3727, align 4
  %stack.sub.3731 = sub i32 %local.check.owner.end.3726, %local.check.offset.3723
  %descriptor.owner.inside.3729 = icmp ule i32 %local.check.owner.end.3726, %context.value.3728
  %descriptor.offset.inside.3730 = icmp ule i32 %local.check.offset.3723, %local.check.owner.end.3726
  %descriptor.extent.inside.3732 = icmp ule i32 %local.check.extent.3724, %stack.sub.3731
  %descriptor.payload.inside.3733 = icmp ule i32 %local.check.payload.3725, %local.check.extent.3724
  %descriptor.owner.offset.valid.3734 = and i1 %descriptor.owner.inside.3729, %descriptor.offset.inside.3730
  %descriptor.range.inside.3736 = and i1 %descriptor.owner.offset.valid.3734, %descriptor.extent.inside.3732
  %descriptor.range.valid.3735 = and i1 %descriptor.range.inside.3736, %descriptor.payload.inside.3733
  br i1 %descriptor.range.valid.3735, label %descriptor.valid.3737, label %descriptor.invalid.3738
descriptor.invalid.3738:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3737:
  %descriptor.initialized.status.3739 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3723, i32 %local.check.extent.3724)
  %helper.ok.3740 = icmp eq i32 %descriptor.initialized.status.3739, 0
  br i1 %helper.ok.3740, label %helper.continue.3741, label %frame.failure.0
helper.continue.3741:
  br label %local.descriptor.checked.3722
local.descriptor.inactive.3721:
  br label %local.descriptor.checked.3722
local.descriptor.checked.3722:
  %local.is.active.3742 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.3742, label %local.descriptor.active.3743, label %local.descriptor.inactive.3744
local.descriptor.active.3743:
  %local.check.offset.3746 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.3747 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.3748 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.3749 = load i32, ptr %local.owner.end.24, align 4
  %context.field.3750 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3751 = load i32, ptr %context.field.3750, align 4
  %stack.sub.3754 = sub i32 %local.check.owner.end.3749, %local.check.offset.3746
  %descriptor.owner.inside.3752 = icmp ule i32 %local.check.owner.end.3749, %context.value.3751
  %descriptor.offset.inside.3753 = icmp ule i32 %local.check.offset.3746, %local.check.owner.end.3749
  %descriptor.extent.inside.3755 = icmp ule i32 %local.check.extent.3747, %stack.sub.3754
  %descriptor.payload.inside.3756 = icmp ule i32 %local.check.payload.3748, %local.check.extent.3747
  %descriptor.owner.offset.valid.3757 = and i1 %descriptor.owner.inside.3752, %descriptor.offset.inside.3753
  %descriptor.range.inside.3759 = and i1 %descriptor.owner.offset.valid.3757, %descriptor.extent.inside.3755
  %descriptor.range.valid.3758 = and i1 %descriptor.range.inside.3759, %descriptor.payload.inside.3756
  br i1 %descriptor.range.valid.3758, label %descriptor.valid.3760, label %descriptor.invalid.3761
descriptor.invalid.3761:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3760:
  %descriptor.initialized.status.3762 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3746, i32 %local.check.extent.3747)
  %helper.ok.3763 = icmp eq i32 %descriptor.initialized.status.3762, 0
  br i1 %helper.ok.3763, label %helper.continue.3764, label %frame.failure.0
helper.continue.3764:
  br label %local.descriptor.checked.3745
local.descriptor.inactive.3744:
  br label %local.descriptor.checked.3745
local.descriptor.checked.3745:
  %local.is.active.3765 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.3765, label %local.descriptor.active.3766, label %local.descriptor.inactive.3767
local.descriptor.active.3766:
  %local.check.offset.3769 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.3770 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.3771 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.3772 = load i32, ptr %local.owner.end.30, align 4
  %context.field.3773 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3774 = load i32, ptr %context.field.3773, align 4
  %stack.sub.3777 = sub i32 %local.check.owner.end.3772, %local.check.offset.3769
  %descriptor.owner.inside.3775 = icmp ule i32 %local.check.owner.end.3772, %context.value.3774
  %descriptor.offset.inside.3776 = icmp ule i32 %local.check.offset.3769, %local.check.owner.end.3772
  %descriptor.extent.inside.3778 = icmp ule i32 %local.check.extent.3770, %stack.sub.3777
  %descriptor.payload.inside.3779 = icmp ule i32 %local.check.payload.3771, %local.check.extent.3770
  %descriptor.owner.offset.valid.3780 = and i1 %descriptor.owner.inside.3775, %descriptor.offset.inside.3776
  %descriptor.range.inside.3782 = and i1 %descriptor.owner.offset.valid.3780, %descriptor.extent.inside.3778
  %descriptor.range.valid.3781 = and i1 %descriptor.range.inside.3782, %descriptor.payload.inside.3779
  br i1 %descriptor.range.valid.3781, label %descriptor.valid.3783, label %descriptor.invalid.3784
descriptor.invalid.3784:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3783:
  %descriptor.initialized.status.3785 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3769, i32 %local.check.extent.3770)
  %helper.ok.3786 = icmp eq i32 %descriptor.initialized.status.3785, 0
  br i1 %helper.ok.3786, label %helper.continue.3787, label %frame.failure.0
helper.continue.3787:
  br label %local.descriptor.checked.3768
local.descriptor.inactive.3767:
  br label %local.descriptor.checked.3768
local.descriptor.checked.3768:
  %local.is.active.3788 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.3788, label %local.descriptor.active.3789, label %local.descriptor.inactive.3790
local.descriptor.active.3789:
  %local.check.offset.3792 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.3793 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.3794 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.3795 = load i32, ptr %local.owner.end.36, align 4
  %context.field.3796 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3797 = load i32, ptr %context.field.3796, align 4
  %stack.sub.3800 = sub i32 %local.check.owner.end.3795, %local.check.offset.3792
  %descriptor.owner.inside.3798 = icmp ule i32 %local.check.owner.end.3795, %context.value.3797
  %descriptor.offset.inside.3799 = icmp ule i32 %local.check.offset.3792, %local.check.owner.end.3795
  %descriptor.extent.inside.3801 = icmp ule i32 %local.check.extent.3793, %stack.sub.3800
  %descriptor.payload.inside.3802 = icmp ule i32 %local.check.payload.3794, %local.check.extent.3793
  %descriptor.owner.offset.valid.3803 = and i1 %descriptor.owner.inside.3798, %descriptor.offset.inside.3799
  %descriptor.range.inside.3805 = and i1 %descriptor.owner.offset.valid.3803, %descriptor.extent.inside.3801
  %descriptor.range.valid.3804 = and i1 %descriptor.range.inside.3805, %descriptor.payload.inside.3802
  br i1 %descriptor.range.valid.3804, label %descriptor.valid.3806, label %descriptor.invalid.3807
descriptor.invalid.3807:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3806:
  %descriptor.initialized.status.3808 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3792, i32 %local.check.extent.3793)
  %helper.ok.3809 = icmp eq i32 %descriptor.initialized.status.3808, 0
  br i1 %helper.ok.3809, label %helper.continue.3810, label %frame.failure.0
helper.continue.3810:
  br label %local.descriptor.checked.3791
local.descriptor.inactive.3790:
  br label %local.descriptor.checked.3791
local.descriptor.checked.3791:
  %step.status.3811 = call i32 @al_owning_charge_step(ptr %ctx, i32 27)
  %helper.ok.3812 = icmp eq i32 %step.status.3811, 0
  br i1 %helper.ok.3812, label %helper.continue.3813, label %frame.failure.0
helper.continue.3813:
  %local.resolved.offset.3814 = load i32, ptr %local.offset.27, align 4
  %local.resolved.extent.3815 = load i32, ptr %local.extent.28, align 4
  %local.resolved.payload.3816 = load i32, ptr %local.payload.29, align 4
  %local.resolved.owner.end.3817 = load i32, ptr %local.owner.end.30, align 4
  %context.field.3818 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3819 = load i32, ptr %context.field.3818, align 4
  %stack.sub.3822 = sub i32 %local.resolved.owner.end.3817, %local.resolved.offset.3814
  %descriptor.owner.inside.3820 = icmp ule i32 %local.resolved.owner.end.3817, %context.value.3819
  %descriptor.offset.inside.3821 = icmp ule i32 %local.resolved.offset.3814, %local.resolved.owner.end.3817
  %descriptor.extent.inside.3823 = icmp ule i32 %local.resolved.extent.3815, %stack.sub.3822
  %descriptor.payload.inside.3824 = icmp ule i32 %local.resolved.payload.3816, %local.resolved.extent.3815
  %descriptor.owner.offset.valid.3825 = and i1 %descriptor.owner.inside.3820, %descriptor.offset.inside.3821
  %descriptor.range.inside.3827 = and i1 %descriptor.owner.offset.valid.3825, %descriptor.extent.inside.3823
  %descriptor.range.valid.3826 = and i1 %descriptor.range.inside.3827, %descriptor.payload.inside.3824
  %descriptor.type.valid.3828 = icmp eq i32 1, 1
  %descriptor.valid.3829 = and i1 %descriptor.range.valid.3826, %descriptor.type.valid.3828
  br i1 %descriptor.valid.3829, label %descriptor.valid.3830, label %descriptor.invalid.3831
descriptor.invalid.3831:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3830:
  %descriptor.initialized.status.3832 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.3814, i32 %local.resolved.extent.3815)
  %helper.ok.3833 = icmp eq i32 %descriptor.initialized.status.3832, 0
  br i1 %helper.ok.3833, label %helper.continue.3834, label %frame.failure.0
helper.continue.3834:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %local.resolved.offset.3814, i32 20, i32 %local.resolved.payload.3816, i32 %local.resolved.owner.end.3817, i32 %local.resolved.extent.3815)
  %context.field.3835 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3836 = load i32, ptr %context.field.3835, align 4
  %runtime.ok.3837 = icmp eq i32 %context.value.3836, 0
  br i1 %runtime.ok.3837, label %runtime.continue.3838, label %frame.failure.0
runtime.continue.3838:
  %context.field.3839 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3840 = load i32, ptr %context.field.3839, align 4
  %stack.sub.3843 = sub i32 %local.resolved.owner.end.3817, %local.resolved.offset.3814
  %descriptor.owner.inside.3841 = icmp ule i32 %local.resolved.owner.end.3817, %context.value.3840
  %descriptor.offset.inside.3842 = icmp ule i32 %local.resolved.offset.3814, %local.resolved.owner.end.3817
  %descriptor.extent.inside.3844 = icmp ule i32 %local.resolved.extent.3815, %stack.sub.3843
  %descriptor.payload.inside.3845 = icmp ule i32 %local.resolved.payload.3816, %local.resolved.extent.3815
  %descriptor.owner.offset.valid.3846 = and i1 %descriptor.owner.inside.3841, %descriptor.offset.inside.3842
  %descriptor.range.inside.3848 = and i1 %descriptor.owner.offset.valid.3846, %descriptor.extent.inside.3844
  %descriptor.range.valid.3847 = and i1 %descriptor.range.inside.3848, %descriptor.payload.inside.3845
  %descriptor.type.valid.3849 = icmp eq i32 1, 1
  %descriptor.valid.3850 = and i1 %descriptor.range.valid.3847, %descriptor.type.valid.3849
  br i1 %descriptor.valid.3850, label %descriptor.valid.3851, label %descriptor.invalid.3852
descriptor.invalid.3852:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3851:
  %descriptor.initialized.status.3853 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.3814, i32 %local.resolved.extent.3815)
  %helper.ok.3854 = icmp eq i32 %descriptor.initialized.status.3853, 0
  br i1 %helper.ok.3854, label %helper.continue.3855, label %frame.failure.0
helper.continue.3855:
  %local.is.active.3856 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.3856, label %local.descriptor.active.3857, label %local.descriptor.inactive.3858
local.descriptor.active.3857:
  %local.check.offset.3860 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.3861 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.3862 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.3863 = load i32, ptr %local.owner.end.6, align 4
  %context.field.3864 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3865 = load i32, ptr %context.field.3864, align 4
  %stack.sub.3868 = sub i32 %local.check.owner.end.3863, %local.check.offset.3860
  %descriptor.owner.inside.3866 = icmp ule i32 %local.check.owner.end.3863, %context.value.3865
  %descriptor.offset.inside.3867 = icmp ule i32 %local.check.offset.3860, %local.check.owner.end.3863
  %descriptor.extent.inside.3869 = icmp ule i32 %local.check.extent.3861, %stack.sub.3868
  %descriptor.payload.inside.3870 = icmp ule i32 %local.check.payload.3862, %local.check.extent.3861
  %descriptor.owner.offset.valid.3871 = and i1 %descriptor.owner.inside.3866, %descriptor.offset.inside.3867
  %descriptor.range.inside.3873 = and i1 %descriptor.owner.offset.valid.3871, %descriptor.extent.inside.3869
  %descriptor.range.valid.3872 = and i1 %descriptor.range.inside.3873, %descriptor.payload.inside.3870
  br i1 %descriptor.range.valid.3872, label %descriptor.valid.3874, label %descriptor.invalid.3875
descriptor.invalid.3875:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3874:
  %descriptor.initialized.status.3876 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3860, i32 %local.check.extent.3861)
  %helper.ok.3877 = icmp eq i32 %descriptor.initialized.status.3876, 0
  br i1 %helper.ok.3877, label %helper.continue.3878, label %frame.failure.0
helper.continue.3878:
  br label %local.descriptor.checked.3859
local.descriptor.inactive.3858:
  br label %local.descriptor.checked.3859
local.descriptor.checked.3859:
  %local.is.active.3879 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.3879, label %local.descriptor.active.3880, label %local.descriptor.inactive.3881
local.descriptor.active.3880:
  %local.check.offset.3883 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.3884 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.3885 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.3886 = load i32, ptr %local.owner.end.12, align 4
  %context.field.3887 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3888 = load i32, ptr %context.field.3887, align 4
  %stack.sub.3891 = sub i32 %local.check.owner.end.3886, %local.check.offset.3883
  %descriptor.owner.inside.3889 = icmp ule i32 %local.check.owner.end.3886, %context.value.3888
  %descriptor.offset.inside.3890 = icmp ule i32 %local.check.offset.3883, %local.check.owner.end.3886
  %descriptor.extent.inside.3892 = icmp ule i32 %local.check.extent.3884, %stack.sub.3891
  %descriptor.payload.inside.3893 = icmp ule i32 %local.check.payload.3885, %local.check.extent.3884
  %descriptor.owner.offset.valid.3894 = and i1 %descriptor.owner.inside.3889, %descriptor.offset.inside.3890
  %descriptor.range.inside.3896 = and i1 %descriptor.owner.offset.valid.3894, %descriptor.extent.inside.3892
  %descriptor.range.valid.3895 = and i1 %descriptor.range.inside.3896, %descriptor.payload.inside.3893
  br i1 %descriptor.range.valid.3895, label %descriptor.valid.3897, label %descriptor.invalid.3898
descriptor.invalid.3898:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3897:
  %descriptor.initialized.status.3899 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3883, i32 %local.check.extent.3884)
  %helper.ok.3900 = icmp eq i32 %descriptor.initialized.status.3899, 0
  br i1 %helper.ok.3900, label %helper.continue.3901, label %frame.failure.0
helper.continue.3901:
  br label %local.descriptor.checked.3882
local.descriptor.inactive.3881:
  br label %local.descriptor.checked.3882
local.descriptor.checked.3882:
  %local.is.active.3902 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.3902, label %local.descriptor.active.3903, label %local.descriptor.inactive.3904
local.descriptor.active.3903:
  %local.check.offset.3906 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.3907 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.3908 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.3909 = load i32, ptr %local.owner.end.18, align 4
  %context.field.3910 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3911 = load i32, ptr %context.field.3910, align 4
  %stack.sub.3914 = sub i32 %local.check.owner.end.3909, %local.check.offset.3906
  %descriptor.owner.inside.3912 = icmp ule i32 %local.check.owner.end.3909, %context.value.3911
  %descriptor.offset.inside.3913 = icmp ule i32 %local.check.offset.3906, %local.check.owner.end.3909
  %descriptor.extent.inside.3915 = icmp ule i32 %local.check.extent.3907, %stack.sub.3914
  %descriptor.payload.inside.3916 = icmp ule i32 %local.check.payload.3908, %local.check.extent.3907
  %descriptor.owner.offset.valid.3917 = and i1 %descriptor.owner.inside.3912, %descriptor.offset.inside.3913
  %descriptor.range.inside.3919 = and i1 %descriptor.owner.offset.valid.3917, %descriptor.extent.inside.3915
  %descriptor.range.valid.3918 = and i1 %descriptor.range.inside.3919, %descriptor.payload.inside.3916
  br i1 %descriptor.range.valid.3918, label %descriptor.valid.3920, label %descriptor.invalid.3921
descriptor.invalid.3921:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3920:
  %descriptor.initialized.status.3922 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3906, i32 %local.check.extent.3907)
  %helper.ok.3923 = icmp eq i32 %descriptor.initialized.status.3922, 0
  br i1 %helper.ok.3923, label %helper.continue.3924, label %frame.failure.0
helper.continue.3924:
  br label %local.descriptor.checked.3905
local.descriptor.inactive.3904:
  br label %local.descriptor.checked.3905
local.descriptor.checked.3905:
  %local.is.active.3925 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.3925, label %local.descriptor.active.3926, label %local.descriptor.inactive.3927
local.descriptor.active.3926:
  %local.check.offset.3929 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.3930 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.3931 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.3932 = load i32, ptr %local.owner.end.24, align 4
  %context.field.3933 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3934 = load i32, ptr %context.field.3933, align 4
  %stack.sub.3937 = sub i32 %local.check.owner.end.3932, %local.check.offset.3929
  %descriptor.owner.inside.3935 = icmp ule i32 %local.check.owner.end.3932, %context.value.3934
  %descriptor.offset.inside.3936 = icmp ule i32 %local.check.offset.3929, %local.check.owner.end.3932
  %descriptor.extent.inside.3938 = icmp ule i32 %local.check.extent.3930, %stack.sub.3937
  %descriptor.payload.inside.3939 = icmp ule i32 %local.check.payload.3931, %local.check.extent.3930
  %descriptor.owner.offset.valid.3940 = and i1 %descriptor.owner.inside.3935, %descriptor.offset.inside.3936
  %descriptor.range.inside.3942 = and i1 %descriptor.owner.offset.valid.3940, %descriptor.extent.inside.3938
  %descriptor.range.valid.3941 = and i1 %descriptor.range.inside.3942, %descriptor.payload.inside.3939
  br i1 %descriptor.range.valid.3941, label %descriptor.valid.3943, label %descriptor.invalid.3944
descriptor.invalid.3944:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3943:
  %descriptor.initialized.status.3945 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3929, i32 %local.check.extent.3930)
  %helper.ok.3946 = icmp eq i32 %descriptor.initialized.status.3945, 0
  br i1 %helper.ok.3946, label %helper.continue.3947, label %frame.failure.0
helper.continue.3947:
  br label %local.descriptor.checked.3928
local.descriptor.inactive.3927:
  br label %local.descriptor.checked.3928
local.descriptor.checked.3928:
  %local.is.active.3948 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.3948, label %local.descriptor.active.3949, label %local.descriptor.inactive.3950
local.descriptor.active.3949:
  %local.check.offset.3952 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.3953 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.3954 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.3955 = load i32, ptr %local.owner.end.30, align 4
  %context.field.3956 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3957 = load i32, ptr %context.field.3956, align 4
  %stack.sub.3960 = sub i32 %local.check.owner.end.3955, %local.check.offset.3952
  %descriptor.owner.inside.3958 = icmp ule i32 %local.check.owner.end.3955, %context.value.3957
  %descriptor.offset.inside.3959 = icmp ule i32 %local.check.offset.3952, %local.check.owner.end.3955
  %descriptor.extent.inside.3961 = icmp ule i32 %local.check.extent.3953, %stack.sub.3960
  %descriptor.payload.inside.3962 = icmp ule i32 %local.check.payload.3954, %local.check.extent.3953
  %descriptor.owner.offset.valid.3963 = and i1 %descriptor.owner.inside.3958, %descriptor.offset.inside.3959
  %descriptor.range.inside.3965 = and i1 %descriptor.owner.offset.valid.3963, %descriptor.extent.inside.3961
  %descriptor.range.valid.3964 = and i1 %descriptor.range.inside.3965, %descriptor.payload.inside.3962
  br i1 %descriptor.range.valid.3964, label %descriptor.valid.3966, label %descriptor.invalid.3967
descriptor.invalid.3967:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3966:
  %descriptor.initialized.status.3968 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3952, i32 %local.check.extent.3953)
  %helper.ok.3969 = icmp eq i32 %descriptor.initialized.status.3968, 0
  br i1 %helper.ok.3969, label %helper.continue.3970, label %frame.failure.0
helper.continue.3970:
  br label %local.descriptor.checked.3951
local.descriptor.inactive.3950:
  br label %local.descriptor.checked.3951
local.descriptor.checked.3951:
  %local.is.active.3971 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.3971, label %local.descriptor.active.3972, label %local.descriptor.inactive.3973
local.descriptor.active.3972:
  %local.check.offset.3975 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.3976 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.3977 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.3978 = load i32, ptr %local.owner.end.36, align 4
  %context.field.3979 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3980 = load i32, ptr %context.field.3979, align 4
  %stack.sub.3983 = sub i32 %local.check.owner.end.3978, %local.check.offset.3975
  %descriptor.owner.inside.3981 = icmp ule i32 %local.check.owner.end.3978, %context.value.3980
  %descriptor.offset.inside.3982 = icmp ule i32 %local.check.offset.3975, %local.check.owner.end.3978
  %descriptor.extent.inside.3984 = icmp ule i32 %local.check.extent.3976, %stack.sub.3983
  %descriptor.payload.inside.3985 = icmp ule i32 %local.check.payload.3977, %local.check.extent.3976
  %descriptor.owner.offset.valid.3986 = and i1 %descriptor.owner.inside.3981, %descriptor.offset.inside.3982
  %descriptor.range.inside.3988 = and i1 %descriptor.owner.offset.valid.3986, %descriptor.extent.inside.3984
  %descriptor.range.valid.3987 = and i1 %descriptor.range.inside.3988, %descriptor.payload.inside.3985
  br i1 %descriptor.range.valid.3987, label %descriptor.valid.3989, label %descriptor.invalid.3990
descriptor.invalid.3990:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3989:
  %descriptor.initialized.status.3991 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3975, i32 %local.check.extent.3976)
  %helper.ok.3992 = icmp eq i32 %descriptor.initialized.status.3991, 0
  br i1 %helper.ok.3992, label %helper.continue.3993, label %frame.failure.0
helper.continue.3993:
  br label %local.descriptor.checked.3974
local.descriptor.inactive.3973:
  br label %local.descriptor.checked.3974
local.descriptor.checked.3974:
  %step.status.3994 = call i32 @al_owning_charge_step(ptr %ctx, i32 28)
  %helper.ok.3995 = icmp eq i32 %step.status.3994, 0
  br i1 %helper.ok.3995, label %helper.continue.3996, label %frame.failure.0
helper.continue.3996:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %local.resolved.offset.3814, i32 %local.resolved.extent.3815, i32 %local.resolved.payload.3816, i32 0, i32 0)
  %context.field.3997 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3998 = load i32, ptr %context.field.3997, align 4
  %runtime.ok.3999 = icmp eq i32 %context.value.3998, 0
  br i1 %runtime.ok.3999, label %runtime.continue.4000, label %frame.failure.0
runtime.continue.4000:
  %local.is.active.4001 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.4001, label %local.descriptor.active.4002, label %local.descriptor.inactive.4003
local.descriptor.active.4002:
  %local.check.offset.4005 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.4006 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.4007 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.4008 = load i32, ptr %local.owner.end.6, align 4
  %context.field.4009 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4010 = load i32, ptr %context.field.4009, align 4
  %stack.sub.4013 = sub i32 %local.check.owner.end.4008, %local.check.offset.4005
  %descriptor.owner.inside.4011 = icmp ule i32 %local.check.owner.end.4008, %context.value.4010
  %descriptor.offset.inside.4012 = icmp ule i32 %local.check.offset.4005, %local.check.owner.end.4008
  %descriptor.extent.inside.4014 = icmp ule i32 %local.check.extent.4006, %stack.sub.4013
  %descriptor.payload.inside.4015 = icmp ule i32 %local.check.payload.4007, %local.check.extent.4006
  %descriptor.owner.offset.valid.4016 = and i1 %descriptor.owner.inside.4011, %descriptor.offset.inside.4012
  %descriptor.range.inside.4018 = and i1 %descriptor.owner.offset.valid.4016, %descriptor.extent.inside.4014
  %descriptor.range.valid.4017 = and i1 %descriptor.range.inside.4018, %descriptor.payload.inside.4015
  br i1 %descriptor.range.valid.4017, label %descriptor.valid.4019, label %descriptor.invalid.4020
descriptor.invalid.4020:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4019:
  %descriptor.initialized.status.4021 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4005, i32 %local.check.extent.4006)
  %helper.ok.4022 = icmp eq i32 %descriptor.initialized.status.4021, 0
  br i1 %helper.ok.4022, label %helper.continue.4023, label %frame.failure.0
helper.continue.4023:
  br label %local.descriptor.checked.4004
local.descriptor.inactive.4003:
  br label %local.descriptor.checked.4004
local.descriptor.checked.4004:
  %local.is.active.4024 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.4024, label %local.descriptor.active.4025, label %local.descriptor.inactive.4026
local.descriptor.active.4025:
  %local.check.offset.4028 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.4029 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.4030 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.4031 = load i32, ptr %local.owner.end.12, align 4
  %context.field.4032 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4033 = load i32, ptr %context.field.4032, align 4
  %stack.sub.4036 = sub i32 %local.check.owner.end.4031, %local.check.offset.4028
  %descriptor.owner.inside.4034 = icmp ule i32 %local.check.owner.end.4031, %context.value.4033
  %descriptor.offset.inside.4035 = icmp ule i32 %local.check.offset.4028, %local.check.owner.end.4031
  %descriptor.extent.inside.4037 = icmp ule i32 %local.check.extent.4029, %stack.sub.4036
  %descriptor.payload.inside.4038 = icmp ule i32 %local.check.payload.4030, %local.check.extent.4029
  %descriptor.owner.offset.valid.4039 = and i1 %descriptor.owner.inside.4034, %descriptor.offset.inside.4035
  %descriptor.range.inside.4041 = and i1 %descriptor.owner.offset.valid.4039, %descriptor.extent.inside.4037
  %descriptor.range.valid.4040 = and i1 %descriptor.range.inside.4041, %descriptor.payload.inside.4038
  br i1 %descriptor.range.valid.4040, label %descriptor.valid.4042, label %descriptor.invalid.4043
descriptor.invalid.4043:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4042:
  %descriptor.initialized.status.4044 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4028, i32 %local.check.extent.4029)
  %helper.ok.4045 = icmp eq i32 %descriptor.initialized.status.4044, 0
  br i1 %helper.ok.4045, label %helper.continue.4046, label %frame.failure.0
helper.continue.4046:
  br label %local.descriptor.checked.4027
local.descriptor.inactive.4026:
  br label %local.descriptor.checked.4027
local.descriptor.checked.4027:
  %local.is.active.4047 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.4047, label %local.descriptor.active.4048, label %local.descriptor.inactive.4049
local.descriptor.active.4048:
  %local.check.offset.4051 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.4052 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.4053 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.4054 = load i32, ptr %local.owner.end.18, align 4
  %context.field.4055 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4056 = load i32, ptr %context.field.4055, align 4
  %stack.sub.4059 = sub i32 %local.check.owner.end.4054, %local.check.offset.4051
  %descriptor.owner.inside.4057 = icmp ule i32 %local.check.owner.end.4054, %context.value.4056
  %descriptor.offset.inside.4058 = icmp ule i32 %local.check.offset.4051, %local.check.owner.end.4054
  %descriptor.extent.inside.4060 = icmp ule i32 %local.check.extent.4052, %stack.sub.4059
  %descriptor.payload.inside.4061 = icmp ule i32 %local.check.payload.4053, %local.check.extent.4052
  %descriptor.owner.offset.valid.4062 = and i1 %descriptor.owner.inside.4057, %descriptor.offset.inside.4058
  %descriptor.range.inside.4064 = and i1 %descriptor.owner.offset.valid.4062, %descriptor.extent.inside.4060
  %descriptor.range.valid.4063 = and i1 %descriptor.range.inside.4064, %descriptor.payload.inside.4061
  br i1 %descriptor.range.valid.4063, label %descriptor.valid.4065, label %descriptor.invalid.4066
descriptor.invalid.4066:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4065:
  %descriptor.initialized.status.4067 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4051, i32 %local.check.extent.4052)
  %helper.ok.4068 = icmp eq i32 %descriptor.initialized.status.4067, 0
  br i1 %helper.ok.4068, label %helper.continue.4069, label %frame.failure.0
helper.continue.4069:
  br label %local.descriptor.checked.4050
local.descriptor.inactive.4049:
  br label %local.descriptor.checked.4050
local.descriptor.checked.4050:
  %local.is.active.4070 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.4070, label %local.descriptor.active.4071, label %local.descriptor.inactive.4072
local.descriptor.active.4071:
  %local.check.offset.4074 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.4075 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.4076 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.4077 = load i32, ptr %local.owner.end.24, align 4
  %context.field.4078 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4079 = load i32, ptr %context.field.4078, align 4
  %stack.sub.4082 = sub i32 %local.check.owner.end.4077, %local.check.offset.4074
  %descriptor.owner.inside.4080 = icmp ule i32 %local.check.owner.end.4077, %context.value.4079
  %descriptor.offset.inside.4081 = icmp ule i32 %local.check.offset.4074, %local.check.owner.end.4077
  %descriptor.extent.inside.4083 = icmp ule i32 %local.check.extent.4075, %stack.sub.4082
  %descriptor.payload.inside.4084 = icmp ule i32 %local.check.payload.4076, %local.check.extent.4075
  %descriptor.owner.offset.valid.4085 = and i1 %descriptor.owner.inside.4080, %descriptor.offset.inside.4081
  %descriptor.range.inside.4087 = and i1 %descriptor.owner.offset.valid.4085, %descriptor.extent.inside.4083
  %descriptor.range.valid.4086 = and i1 %descriptor.range.inside.4087, %descriptor.payload.inside.4084
  br i1 %descriptor.range.valid.4086, label %descriptor.valid.4088, label %descriptor.invalid.4089
descriptor.invalid.4089:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4088:
  %descriptor.initialized.status.4090 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4074, i32 %local.check.extent.4075)
  %helper.ok.4091 = icmp eq i32 %descriptor.initialized.status.4090, 0
  br i1 %helper.ok.4091, label %helper.continue.4092, label %frame.failure.0
helper.continue.4092:
  br label %local.descriptor.checked.4073
local.descriptor.inactive.4072:
  br label %local.descriptor.checked.4073
local.descriptor.checked.4073:
  %local.is.active.4093 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.4093, label %local.descriptor.active.4094, label %local.descriptor.inactive.4095
local.descriptor.active.4094:
  %local.check.offset.4097 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.4098 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.4099 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.4100 = load i32, ptr %local.owner.end.30, align 4
  %context.field.4101 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4102 = load i32, ptr %context.field.4101, align 4
  %stack.sub.4105 = sub i32 %local.check.owner.end.4100, %local.check.offset.4097
  %descriptor.owner.inside.4103 = icmp ule i32 %local.check.owner.end.4100, %context.value.4102
  %descriptor.offset.inside.4104 = icmp ule i32 %local.check.offset.4097, %local.check.owner.end.4100
  %descriptor.extent.inside.4106 = icmp ule i32 %local.check.extent.4098, %stack.sub.4105
  %descriptor.payload.inside.4107 = icmp ule i32 %local.check.payload.4099, %local.check.extent.4098
  %descriptor.owner.offset.valid.4108 = and i1 %descriptor.owner.inside.4103, %descriptor.offset.inside.4104
  %descriptor.range.inside.4110 = and i1 %descriptor.owner.offset.valid.4108, %descriptor.extent.inside.4106
  %descriptor.range.valid.4109 = and i1 %descriptor.range.inside.4110, %descriptor.payload.inside.4107
  br i1 %descriptor.range.valid.4109, label %descriptor.valid.4111, label %descriptor.invalid.4112
descriptor.invalid.4112:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4111:
  %descriptor.initialized.status.4113 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4097, i32 %local.check.extent.4098)
  %helper.ok.4114 = icmp eq i32 %descriptor.initialized.status.4113, 0
  br i1 %helper.ok.4114, label %helper.continue.4115, label %frame.failure.0
helper.continue.4115:
  br label %local.descriptor.checked.4096
local.descriptor.inactive.4095:
  br label %local.descriptor.checked.4096
local.descriptor.checked.4096:
  %local.is.active.4116 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.4116, label %local.descriptor.active.4117, label %local.descriptor.inactive.4118
local.descriptor.active.4117:
  %local.check.offset.4120 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.4121 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.4122 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.4123 = load i32, ptr %local.owner.end.36, align 4
  %context.field.4124 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4125 = load i32, ptr %context.field.4124, align 4
  %stack.sub.4128 = sub i32 %local.check.owner.end.4123, %local.check.offset.4120
  %descriptor.owner.inside.4126 = icmp ule i32 %local.check.owner.end.4123, %context.value.4125
  %descriptor.offset.inside.4127 = icmp ule i32 %local.check.offset.4120, %local.check.owner.end.4123
  %descriptor.extent.inside.4129 = icmp ule i32 %local.check.extent.4121, %stack.sub.4128
  %descriptor.payload.inside.4130 = icmp ule i32 %local.check.payload.4122, %local.check.extent.4121
  %descriptor.owner.offset.valid.4131 = and i1 %descriptor.owner.inside.4126, %descriptor.offset.inside.4127
  %descriptor.range.inside.4133 = and i1 %descriptor.owner.offset.valid.4131, %descriptor.extent.inside.4129
  %descriptor.range.valid.4132 = and i1 %descriptor.range.inside.4133, %descriptor.payload.inside.4130
  br i1 %descriptor.range.valid.4132, label %descriptor.valid.4134, label %descriptor.invalid.4135
descriptor.invalid.4135:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4134:
  %descriptor.initialized.status.4136 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4120, i32 %local.check.extent.4121)
  %helper.ok.4137 = icmp eq i32 %descriptor.initialized.status.4136, 0
  br i1 %helper.ok.4137, label %helper.continue.4138, label %frame.failure.0
helper.continue.4138:
  br label %local.descriptor.checked.4119
local.descriptor.inactive.4118:
  br label %local.descriptor.checked.4119
local.descriptor.checked.4119:
  %step.status.4139 = call i32 @al_owning_charge_step(ptr %ctx, i32 29)
  %helper.ok.4140 = icmp eq i32 %step.status.4139, 0
  br i1 %helper.ok.4140, label %helper.continue.4141, label %frame.failure.0
helper.continue.4141:
  %local.resolved.offset.4142 = load i32, ptr %local.offset.33, align 4
  %local.resolved.extent.4143 = load i32, ptr %local.extent.34, align 4
  %local.resolved.payload.4144 = load i32, ptr %local.payload.35, align 4
  %local.resolved.owner.end.4145 = load i32, ptr %local.owner.end.36, align 4
  %context.field.4146 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4147 = load i32, ptr %context.field.4146, align 4
  %stack.sub.4150 = sub i32 %local.resolved.owner.end.4145, %local.resolved.offset.4142
  %descriptor.owner.inside.4148 = icmp ule i32 %local.resolved.owner.end.4145, %context.value.4147
  %descriptor.offset.inside.4149 = icmp ule i32 %local.resolved.offset.4142, %local.resolved.owner.end.4145
  %descriptor.extent.inside.4151 = icmp ule i32 %local.resolved.extent.4143, %stack.sub.4150
  %descriptor.payload.inside.4152 = icmp ule i32 %local.resolved.payload.4144, %local.resolved.extent.4143
  %descriptor.owner.offset.valid.4153 = and i1 %descriptor.owner.inside.4148, %descriptor.offset.inside.4149
  %descriptor.range.inside.4155 = and i1 %descriptor.owner.offset.valid.4153, %descriptor.extent.inside.4151
  %descriptor.range.valid.4154 = and i1 %descriptor.range.inside.4155, %descriptor.payload.inside.4152
  %descriptor.type.valid.4156 = icmp eq i32 1, 1
  %descriptor.valid.4157 = and i1 %descriptor.range.valid.4154, %descriptor.type.valid.4156
  br i1 %descriptor.valid.4157, label %descriptor.valid.4158, label %descriptor.invalid.4159
descriptor.invalid.4159:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4158:
  %descriptor.initialized.status.4160 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.4142, i32 %local.resolved.extent.4143)
  %helper.ok.4161 = icmp eq i32 %descriptor.initialized.status.4160, 0
  br i1 %helper.ok.4161, label %helper.continue.4162, label %frame.failure.0
helper.continue.4162:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %local.resolved.offset.4142, i32 20, i32 %local.resolved.payload.4144, i32 %local.resolved.owner.end.4145, i32 %local.resolved.extent.4143)
  %context.field.4163 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4164 = load i32, ptr %context.field.4163, align 4
  %runtime.ok.4165 = icmp eq i32 %context.value.4164, 0
  br i1 %runtime.ok.4165, label %runtime.continue.4166, label %frame.failure.0
runtime.continue.4166:
  %context.field.4167 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4168 = load i32, ptr %context.field.4167, align 4
  %stack.sub.4171 = sub i32 %local.resolved.owner.end.4145, %local.resolved.offset.4142
  %descriptor.owner.inside.4169 = icmp ule i32 %local.resolved.owner.end.4145, %context.value.4168
  %descriptor.offset.inside.4170 = icmp ule i32 %local.resolved.offset.4142, %local.resolved.owner.end.4145
  %descriptor.extent.inside.4172 = icmp ule i32 %local.resolved.extent.4143, %stack.sub.4171
  %descriptor.payload.inside.4173 = icmp ule i32 %local.resolved.payload.4144, %local.resolved.extent.4143
  %descriptor.owner.offset.valid.4174 = and i1 %descriptor.owner.inside.4169, %descriptor.offset.inside.4170
  %descriptor.range.inside.4176 = and i1 %descriptor.owner.offset.valid.4174, %descriptor.extent.inside.4172
  %descriptor.range.valid.4175 = and i1 %descriptor.range.inside.4176, %descriptor.payload.inside.4173
  %descriptor.type.valid.4177 = icmp eq i32 1, 1
  %descriptor.valid.4178 = and i1 %descriptor.range.valid.4175, %descriptor.type.valid.4177
  br i1 %descriptor.valid.4178, label %descriptor.valid.4179, label %descriptor.invalid.4180
descriptor.invalid.4180:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4179:
  %descriptor.initialized.status.4181 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.4142, i32 %local.resolved.extent.4143)
  %helper.ok.4182 = icmp eq i32 %descriptor.initialized.status.4181, 0
  br i1 %helper.ok.4182, label %helper.continue.4183, label %frame.failure.0
helper.continue.4183:
  %local.is.active.4184 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.4184, label %local.descriptor.active.4185, label %local.descriptor.inactive.4186
local.descriptor.active.4185:
  %local.check.offset.4188 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.4189 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.4190 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.4191 = load i32, ptr %local.owner.end.6, align 4
  %context.field.4192 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4193 = load i32, ptr %context.field.4192, align 4
  %stack.sub.4196 = sub i32 %local.check.owner.end.4191, %local.check.offset.4188
  %descriptor.owner.inside.4194 = icmp ule i32 %local.check.owner.end.4191, %context.value.4193
  %descriptor.offset.inside.4195 = icmp ule i32 %local.check.offset.4188, %local.check.owner.end.4191
  %descriptor.extent.inside.4197 = icmp ule i32 %local.check.extent.4189, %stack.sub.4196
  %descriptor.payload.inside.4198 = icmp ule i32 %local.check.payload.4190, %local.check.extent.4189
  %descriptor.owner.offset.valid.4199 = and i1 %descriptor.owner.inside.4194, %descriptor.offset.inside.4195
  %descriptor.range.inside.4201 = and i1 %descriptor.owner.offset.valid.4199, %descriptor.extent.inside.4197
  %descriptor.range.valid.4200 = and i1 %descriptor.range.inside.4201, %descriptor.payload.inside.4198
  br i1 %descriptor.range.valid.4200, label %descriptor.valid.4202, label %descriptor.invalid.4203
descriptor.invalid.4203:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4202:
  %descriptor.initialized.status.4204 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4188, i32 %local.check.extent.4189)
  %helper.ok.4205 = icmp eq i32 %descriptor.initialized.status.4204, 0
  br i1 %helper.ok.4205, label %helper.continue.4206, label %frame.failure.0
helper.continue.4206:
  br label %local.descriptor.checked.4187
local.descriptor.inactive.4186:
  br label %local.descriptor.checked.4187
local.descriptor.checked.4187:
  %local.is.active.4207 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.4207, label %local.descriptor.active.4208, label %local.descriptor.inactive.4209
local.descriptor.active.4208:
  %local.check.offset.4211 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.4212 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.4213 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.4214 = load i32, ptr %local.owner.end.12, align 4
  %context.field.4215 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4216 = load i32, ptr %context.field.4215, align 4
  %stack.sub.4219 = sub i32 %local.check.owner.end.4214, %local.check.offset.4211
  %descriptor.owner.inside.4217 = icmp ule i32 %local.check.owner.end.4214, %context.value.4216
  %descriptor.offset.inside.4218 = icmp ule i32 %local.check.offset.4211, %local.check.owner.end.4214
  %descriptor.extent.inside.4220 = icmp ule i32 %local.check.extent.4212, %stack.sub.4219
  %descriptor.payload.inside.4221 = icmp ule i32 %local.check.payload.4213, %local.check.extent.4212
  %descriptor.owner.offset.valid.4222 = and i1 %descriptor.owner.inside.4217, %descriptor.offset.inside.4218
  %descriptor.range.inside.4224 = and i1 %descriptor.owner.offset.valid.4222, %descriptor.extent.inside.4220
  %descriptor.range.valid.4223 = and i1 %descriptor.range.inside.4224, %descriptor.payload.inside.4221
  br i1 %descriptor.range.valid.4223, label %descriptor.valid.4225, label %descriptor.invalid.4226
descriptor.invalid.4226:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4225:
  %descriptor.initialized.status.4227 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4211, i32 %local.check.extent.4212)
  %helper.ok.4228 = icmp eq i32 %descriptor.initialized.status.4227, 0
  br i1 %helper.ok.4228, label %helper.continue.4229, label %frame.failure.0
helper.continue.4229:
  br label %local.descriptor.checked.4210
local.descriptor.inactive.4209:
  br label %local.descriptor.checked.4210
local.descriptor.checked.4210:
  %local.is.active.4230 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.4230, label %local.descriptor.active.4231, label %local.descriptor.inactive.4232
local.descriptor.active.4231:
  %local.check.offset.4234 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.4235 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.4236 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.4237 = load i32, ptr %local.owner.end.18, align 4
  %context.field.4238 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4239 = load i32, ptr %context.field.4238, align 4
  %stack.sub.4242 = sub i32 %local.check.owner.end.4237, %local.check.offset.4234
  %descriptor.owner.inside.4240 = icmp ule i32 %local.check.owner.end.4237, %context.value.4239
  %descriptor.offset.inside.4241 = icmp ule i32 %local.check.offset.4234, %local.check.owner.end.4237
  %descriptor.extent.inside.4243 = icmp ule i32 %local.check.extent.4235, %stack.sub.4242
  %descriptor.payload.inside.4244 = icmp ule i32 %local.check.payload.4236, %local.check.extent.4235
  %descriptor.owner.offset.valid.4245 = and i1 %descriptor.owner.inside.4240, %descriptor.offset.inside.4241
  %descriptor.range.inside.4247 = and i1 %descriptor.owner.offset.valid.4245, %descriptor.extent.inside.4243
  %descriptor.range.valid.4246 = and i1 %descriptor.range.inside.4247, %descriptor.payload.inside.4244
  br i1 %descriptor.range.valid.4246, label %descriptor.valid.4248, label %descriptor.invalid.4249
descriptor.invalid.4249:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4248:
  %descriptor.initialized.status.4250 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4234, i32 %local.check.extent.4235)
  %helper.ok.4251 = icmp eq i32 %descriptor.initialized.status.4250, 0
  br i1 %helper.ok.4251, label %helper.continue.4252, label %frame.failure.0
helper.continue.4252:
  br label %local.descriptor.checked.4233
local.descriptor.inactive.4232:
  br label %local.descriptor.checked.4233
local.descriptor.checked.4233:
  %local.is.active.4253 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.4253, label %local.descriptor.active.4254, label %local.descriptor.inactive.4255
local.descriptor.active.4254:
  %local.check.offset.4257 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.4258 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.4259 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.4260 = load i32, ptr %local.owner.end.24, align 4
  %context.field.4261 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4262 = load i32, ptr %context.field.4261, align 4
  %stack.sub.4265 = sub i32 %local.check.owner.end.4260, %local.check.offset.4257
  %descriptor.owner.inside.4263 = icmp ule i32 %local.check.owner.end.4260, %context.value.4262
  %descriptor.offset.inside.4264 = icmp ule i32 %local.check.offset.4257, %local.check.owner.end.4260
  %descriptor.extent.inside.4266 = icmp ule i32 %local.check.extent.4258, %stack.sub.4265
  %descriptor.payload.inside.4267 = icmp ule i32 %local.check.payload.4259, %local.check.extent.4258
  %descriptor.owner.offset.valid.4268 = and i1 %descriptor.owner.inside.4263, %descriptor.offset.inside.4264
  %descriptor.range.inside.4270 = and i1 %descriptor.owner.offset.valid.4268, %descriptor.extent.inside.4266
  %descriptor.range.valid.4269 = and i1 %descriptor.range.inside.4270, %descriptor.payload.inside.4267
  br i1 %descriptor.range.valid.4269, label %descriptor.valid.4271, label %descriptor.invalid.4272
descriptor.invalid.4272:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4271:
  %descriptor.initialized.status.4273 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4257, i32 %local.check.extent.4258)
  %helper.ok.4274 = icmp eq i32 %descriptor.initialized.status.4273, 0
  br i1 %helper.ok.4274, label %helper.continue.4275, label %frame.failure.0
helper.continue.4275:
  br label %local.descriptor.checked.4256
local.descriptor.inactive.4255:
  br label %local.descriptor.checked.4256
local.descriptor.checked.4256:
  %local.is.active.4276 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.4276, label %local.descriptor.active.4277, label %local.descriptor.inactive.4278
local.descriptor.active.4277:
  %local.check.offset.4280 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.4281 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.4282 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.4283 = load i32, ptr %local.owner.end.30, align 4
  %context.field.4284 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4285 = load i32, ptr %context.field.4284, align 4
  %stack.sub.4288 = sub i32 %local.check.owner.end.4283, %local.check.offset.4280
  %descriptor.owner.inside.4286 = icmp ule i32 %local.check.owner.end.4283, %context.value.4285
  %descriptor.offset.inside.4287 = icmp ule i32 %local.check.offset.4280, %local.check.owner.end.4283
  %descriptor.extent.inside.4289 = icmp ule i32 %local.check.extent.4281, %stack.sub.4288
  %descriptor.payload.inside.4290 = icmp ule i32 %local.check.payload.4282, %local.check.extent.4281
  %descriptor.owner.offset.valid.4291 = and i1 %descriptor.owner.inside.4286, %descriptor.offset.inside.4287
  %descriptor.range.inside.4293 = and i1 %descriptor.owner.offset.valid.4291, %descriptor.extent.inside.4289
  %descriptor.range.valid.4292 = and i1 %descriptor.range.inside.4293, %descriptor.payload.inside.4290
  br i1 %descriptor.range.valid.4292, label %descriptor.valid.4294, label %descriptor.invalid.4295
descriptor.invalid.4295:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4294:
  %descriptor.initialized.status.4296 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4280, i32 %local.check.extent.4281)
  %helper.ok.4297 = icmp eq i32 %descriptor.initialized.status.4296, 0
  br i1 %helper.ok.4297, label %helper.continue.4298, label %frame.failure.0
helper.continue.4298:
  br label %local.descriptor.checked.4279
local.descriptor.inactive.4278:
  br label %local.descriptor.checked.4279
local.descriptor.checked.4279:
  %local.is.active.4299 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.4299, label %local.descriptor.active.4300, label %local.descriptor.inactive.4301
local.descriptor.active.4300:
  %local.check.offset.4303 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.4304 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.4305 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.4306 = load i32, ptr %local.owner.end.36, align 4
  %context.field.4307 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4308 = load i32, ptr %context.field.4307, align 4
  %stack.sub.4311 = sub i32 %local.check.owner.end.4306, %local.check.offset.4303
  %descriptor.owner.inside.4309 = icmp ule i32 %local.check.owner.end.4306, %context.value.4308
  %descriptor.offset.inside.4310 = icmp ule i32 %local.check.offset.4303, %local.check.owner.end.4306
  %descriptor.extent.inside.4312 = icmp ule i32 %local.check.extent.4304, %stack.sub.4311
  %descriptor.payload.inside.4313 = icmp ule i32 %local.check.payload.4305, %local.check.extent.4304
  %descriptor.owner.offset.valid.4314 = and i1 %descriptor.owner.inside.4309, %descriptor.offset.inside.4310
  %descriptor.range.inside.4316 = and i1 %descriptor.owner.offset.valid.4314, %descriptor.extent.inside.4312
  %descriptor.range.valid.4315 = and i1 %descriptor.range.inside.4316, %descriptor.payload.inside.4313
  br i1 %descriptor.range.valid.4315, label %descriptor.valid.4317, label %descriptor.invalid.4318
descriptor.invalid.4318:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4317:
  %descriptor.initialized.status.4319 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4303, i32 %local.check.extent.4304)
  %helper.ok.4320 = icmp eq i32 %descriptor.initialized.status.4319, 0
  br i1 %helper.ok.4320, label %helper.continue.4321, label %frame.failure.0
helper.continue.4321:
  br label %local.descriptor.checked.4302
local.descriptor.inactive.4301:
  br label %local.descriptor.checked.4302
local.descriptor.checked.4302:
  %step.status.4322 = call i32 @al_owning_charge_step(ptr %ctx, i32 30)
  %helper.ok.4323 = icmp eq i32 %step.status.4322, 0
  br i1 %helper.ok.4323, label %helper.continue.4324, label %frame.failure.0
helper.continue.4324:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %local.resolved.offset.4142, i32 %local.resolved.extent.4143, i32 %local.resolved.payload.4144, i32 0, i32 0)
  %context.field.4325 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4326 = load i32, ptr %context.field.4325, align 4
  %runtime.ok.4327 = icmp eq i32 %context.value.4326, 0
  br i1 %runtime.ok.4327, label %runtime.continue.4328, label %frame.failure.0
runtime.continue.4328:
  %local.is.active.4329 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.4329, label %local.descriptor.active.4330, label %local.descriptor.inactive.4331
local.descriptor.active.4330:
  %local.check.offset.4333 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.4334 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.4335 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.4336 = load i32, ptr %local.owner.end.6, align 4
  %context.field.4337 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4338 = load i32, ptr %context.field.4337, align 4
  %stack.sub.4341 = sub i32 %local.check.owner.end.4336, %local.check.offset.4333
  %descriptor.owner.inside.4339 = icmp ule i32 %local.check.owner.end.4336, %context.value.4338
  %descriptor.offset.inside.4340 = icmp ule i32 %local.check.offset.4333, %local.check.owner.end.4336
  %descriptor.extent.inside.4342 = icmp ule i32 %local.check.extent.4334, %stack.sub.4341
  %descriptor.payload.inside.4343 = icmp ule i32 %local.check.payload.4335, %local.check.extent.4334
  %descriptor.owner.offset.valid.4344 = and i1 %descriptor.owner.inside.4339, %descriptor.offset.inside.4340
  %descriptor.range.inside.4346 = and i1 %descriptor.owner.offset.valid.4344, %descriptor.extent.inside.4342
  %descriptor.range.valid.4345 = and i1 %descriptor.range.inside.4346, %descriptor.payload.inside.4343
  br i1 %descriptor.range.valid.4345, label %descriptor.valid.4347, label %descriptor.invalid.4348
descriptor.invalid.4348:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4347:
  %descriptor.initialized.status.4349 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4333, i32 %local.check.extent.4334)
  %helper.ok.4350 = icmp eq i32 %descriptor.initialized.status.4349, 0
  br i1 %helper.ok.4350, label %helper.continue.4351, label %frame.failure.0
helper.continue.4351:
  br label %local.descriptor.checked.4332
local.descriptor.inactive.4331:
  br label %local.descriptor.checked.4332
local.descriptor.checked.4332:
  %local.is.active.4352 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.4352, label %local.descriptor.active.4353, label %local.descriptor.inactive.4354
local.descriptor.active.4353:
  %local.check.offset.4356 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.4357 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.4358 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.4359 = load i32, ptr %local.owner.end.12, align 4
  %context.field.4360 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4361 = load i32, ptr %context.field.4360, align 4
  %stack.sub.4364 = sub i32 %local.check.owner.end.4359, %local.check.offset.4356
  %descriptor.owner.inside.4362 = icmp ule i32 %local.check.owner.end.4359, %context.value.4361
  %descriptor.offset.inside.4363 = icmp ule i32 %local.check.offset.4356, %local.check.owner.end.4359
  %descriptor.extent.inside.4365 = icmp ule i32 %local.check.extent.4357, %stack.sub.4364
  %descriptor.payload.inside.4366 = icmp ule i32 %local.check.payload.4358, %local.check.extent.4357
  %descriptor.owner.offset.valid.4367 = and i1 %descriptor.owner.inside.4362, %descriptor.offset.inside.4363
  %descriptor.range.inside.4369 = and i1 %descriptor.owner.offset.valid.4367, %descriptor.extent.inside.4365
  %descriptor.range.valid.4368 = and i1 %descriptor.range.inside.4369, %descriptor.payload.inside.4366
  br i1 %descriptor.range.valid.4368, label %descriptor.valid.4370, label %descriptor.invalid.4371
descriptor.invalid.4371:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4370:
  %descriptor.initialized.status.4372 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4356, i32 %local.check.extent.4357)
  %helper.ok.4373 = icmp eq i32 %descriptor.initialized.status.4372, 0
  br i1 %helper.ok.4373, label %helper.continue.4374, label %frame.failure.0
helper.continue.4374:
  br label %local.descriptor.checked.4355
local.descriptor.inactive.4354:
  br label %local.descriptor.checked.4355
local.descriptor.checked.4355:
  %local.is.active.4375 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.4375, label %local.descriptor.active.4376, label %local.descriptor.inactive.4377
local.descriptor.active.4376:
  %local.check.offset.4379 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.4380 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.4381 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.4382 = load i32, ptr %local.owner.end.18, align 4
  %context.field.4383 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4384 = load i32, ptr %context.field.4383, align 4
  %stack.sub.4387 = sub i32 %local.check.owner.end.4382, %local.check.offset.4379
  %descriptor.owner.inside.4385 = icmp ule i32 %local.check.owner.end.4382, %context.value.4384
  %descriptor.offset.inside.4386 = icmp ule i32 %local.check.offset.4379, %local.check.owner.end.4382
  %descriptor.extent.inside.4388 = icmp ule i32 %local.check.extent.4380, %stack.sub.4387
  %descriptor.payload.inside.4389 = icmp ule i32 %local.check.payload.4381, %local.check.extent.4380
  %descriptor.owner.offset.valid.4390 = and i1 %descriptor.owner.inside.4385, %descriptor.offset.inside.4386
  %descriptor.range.inside.4392 = and i1 %descriptor.owner.offset.valid.4390, %descriptor.extent.inside.4388
  %descriptor.range.valid.4391 = and i1 %descriptor.range.inside.4392, %descriptor.payload.inside.4389
  br i1 %descriptor.range.valid.4391, label %descriptor.valid.4393, label %descriptor.invalid.4394
descriptor.invalid.4394:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4393:
  %descriptor.initialized.status.4395 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4379, i32 %local.check.extent.4380)
  %helper.ok.4396 = icmp eq i32 %descriptor.initialized.status.4395, 0
  br i1 %helper.ok.4396, label %helper.continue.4397, label %frame.failure.0
helper.continue.4397:
  br label %local.descriptor.checked.4378
local.descriptor.inactive.4377:
  br label %local.descriptor.checked.4378
local.descriptor.checked.4378:
  %local.is.active.4398 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.4398, label %local.descriptor.active.4399, label %local.descriptor.inactive.4400
local.descriptor.active.4399:
  %local.check.offset.4402 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.4403 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.4404 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.4405 = load i32, ptr %local.owner.end.24, align 4
  %context.field.4406 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4407 = load i32, ptr %context.field.4406, align 4
  %stack.sub.4410 = sub i32 %local.check.owner.end.4405, %local.check.offset.4402
  %descriptor.owner.inside.4408 = icmp ule i32 %local.check.owner.end.4405, %context.value.4407
  %descriptor.offset.inside.4409 = icmp ule i32 %local.check.offset.4402, %local.check.owner.end.4405
  %descriptor.extent.inside.4411 = icmp ule i32 %local.check.extent.4403, %stack.sub.4410
  %descriptor.payload.inside.4412 = icmp ule i32 %local.check.payload.4404, %local.check.extent.4403
  %descriptor.owner.offset.valid.4413 = and i1 %descriptor.owner.inside.4408, %descriptor.offset.inside.4409
  %descriptor.range.inside.4415 = and i1 %descriptor.owner.offset.valid.4413, %descriptor.extent.inside.4411
  %descriptor.range.valid.4414 = and i1 %descriptor.range.inside.4415, %descriptor.payload.inside.4412
  br i1 %descriptor.range.valid.4414, label %descriptor.valid.4416, label %descriptor.invalid.4417
descriptor.invalid.4417:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4416:
  %descriptor.initialized.status.4418 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4402, i32 %local.check.extent.4403)
  %helper.ok.4419 = icmp eq i32 %descriptor.initialized.status.4418, 0
  br i1 %helper.ok.4419, label %helper.continue.4420, label %frame.failure.0
helper.continue.4420:
  br label %local.descriptor.checked.4401
local.descriptor.inactive.4400:
  br label %local.descriptor.checked.4401
local.descriptor.checked.4401:
  %local.is.active.4421 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.4421, label %local.descriptor.active.4422, label %local.descriptor.inactive.4423
local.descriptor.active.4422:
  %local.check.offset.4425 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.4426 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.4427 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.4428 = load i32, ptr %local.owner.end.30, align 4
  %context.field.4429 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4430 = load i32, ptr %context.field.4429, align 4
  %stack.sub.4433 = sub i32 %local.check.owner.end.4428, %local.check.offset.4425
  %descriptor.owner.inside.4431 = icmp ule i32 %local.check.owner.end.4428, %context.value.4430
  %descriptor.offset.inside.4432 = icmp ule i32 %local.check.offset.4425, %local.check.owner.end.4428
  %descriptor.extent.inside.4434 = icmp ule i32 %local.check.extent.4426, %stack.sub.4433
  %descriptor.payload.inside.4435 = icmp ule i32 %local.check.payload.4427, %local.check.extent.4426
  %descriptor.owner.offset.valid.4436 = and i1 %descriptor.owner.inside.4431, %descriptor.offset.inside.4432
  %descriptor.range.inside.4438 = and i1 %descriptor.owner.offset.valid.4436, %descriptor.extent.inside.4434
  %descriptor.range.valid.4437 = and i1 %descriptor.range.inside.4438, %descriptor.payload.inside.4435
  br i1 %descriptor.range.valid.4437, label %descriptor.valid.4439, label %descriptor.invalid.4440
descriptor.invalid.4440:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4439:
  %descriptor.initialized.status.4441 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4425, i32 %local.check.extent.4426)
  %helper.ok.4442 = icmp eq i32 %descriptor.initialized.status.4441, 0
  br i1 %helper.ok.4442, label %helper.continue.4443, label %frame.failure.0
helper.continue.4443:
  br label %local.descriptor.checked.4424
local.descriptor.inactive.4423:
  br label %local.descriptor.checked.4424
local.descriptor.checked.4424:
  %local.is.active.4444 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.4444, label %local.descriptor.active.4445, label %local.descriptor.inactive.4446
local.descriptor.active.4445:
  %local.check.offset.4448 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.4449 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.4450 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.4451 = load i32, ptr %local.owner.end.36, align 4
  %context.field.4452 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4453 = load i32, ptr %context.field.4452, align 4
  %stack.sub.4456 = sub i32 %local.check.owner.end.4451, %local.check.offset.4448
  %descriptor.owner.inside.4454 = icmp ule i32 %local.check.owner.end.4451, %context.value.4453
  %descriptor.offset.inside.4455 = icmp ule i32 %local.check.offset.4448, %local.check.owner.end.4451
  %descriptor.extent.inside.4457 = icmp ule i32 %local.check.extent.4449, %stack.sub.4456
  %descriptor.payload.inside.4458 = icmp ule i32 %local.check.payload.4450, %local.check.extent.4449
  %descriptor.owner.offset.valid.4459 = and i1 %descriptor.owner.inside.4454, %descriptor.offset.inside.4455
  %descriptor.range.inside.4461 = and i1 %descriptor.owner.offset.valid.4459, %descriptor.extent.inside.4457
  %descriptor.range.valid.4460 = and i1 %descriptor.range.inside.4461, %descriptor.payload.inside.4458
  br i1 %descriptor.range.valid.4460, label %descriptor.valid.4462, label %descriptor.invalid.4463
descriptor.invalid.4463:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4462:
  %descriptor.initialized.status.4464 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4448, i32 %local.check.extent.4449)
  %helper.ok.4465 = icmp eq i32 %descriptor.initialized.status.4464, 0
  br i1 %helper.ok.4465, label %helper.continue.4466, label %frame.failure.0
helper.continue.4466:
  br label %local.descriptor.checked.4447
local.descriptor.inactive.4446:
  br label %local.descriptor.checked.4447
local.descriptor.checked.4447:
  store i1 false, ptr %local.active.32, align 1
  store i32 0, ptr %local.offset.33, align 4
  store i32 0, ptr %local.extent.34, align 4
  store i32 0, ptr %local.payload.35, align 4
  store i32 0, ptr %local.owner.end.36, align 4
  store i32 0, ptr %local.type.37, align 4
  store i1 false, ptr %local.active.26, align 1
  store i32 0, ptr %local.offset.27, align 4
  store i32 0, ptr %local.extent.28, align 4
  store i32 0, ptr %local.payload.29, align 4
  store i32 0, ptr %local.owner.end.30, align 4
  store i32 0, ptr %local.type.31, align 4
  store i1 false, ptr %local.active.20, align 1
  store i32 0, ptr %local.offset.21, align 4
  store i32 0, ptr %local.extent.22, align 4
  store i32 0, ptr %local.payload.23, align 4
  store i32 0, ptr %local.owner.end.24, align 4
  store i32 0, ptr %local.type.25, align 4
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %context.field.4467 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4468 = load i32, ptr %context.field.4467, align 4
  %stack.sub.4469 = sub i32 %context.value.4468, %context.value.233
  call void @al_owning_record_layout(ptr %ctx, i32 18, i32 0, i32 %context.value.233, i32 %stack.sub.4469, i32 0, i32 0, i32 0)
  %context.field.4470 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4471 = load i32, ptr %context.field.4470, align 4
  %runtime.ok.4472 = icmp eq i32 %context.value.4471, 0
  br i1 %runtime.ok.4472, label %runtime.continue.4473, label %frame.failure.0
runtime.continue.4473:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.233, i32 0, i32 0, i32 0)
  %context.field.4474 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4475 = load i32, ptr %context.field.4474, align 4
  %runtime.ok.4476 = icmp eq i32 %context.value.4475, 0
  br i1 %runtime.ok.4476, label %runtime.continue.4477, label %frame.failure.0
runtime.continue.4477:
  %local.is.active.4478 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.4478, label %local.descriptor.active.4479, label %local.descriptor.inactive.4480
local.descriptor.active.4479:
  %local.check.offset.4482 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.4483 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.4484 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.4485 = load i32, ptr %local.owner.end.6, align 4
  %context.field.4486 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4487 = load i32, ptr %context.field.4486, align 4
  %stack.sub.4490 = sub i32 %local.check.owner.end.4485, %local.check.offset.4482
  %descriptor.owner.inside.4488 = icmp ule i32 %local.check.owner.end.4485, %context.value.4487
  %descriptor.offset.inside.4489 = icmp ule i32 %local.check.offset.4482, %local.check.owner.end.4485
  %descriptor.extent.inside.4491 = icmp ule i32 %local.check.extent.4483, %stack.sub.4490
  %descriptor.payload.inside.4492 = icmp ule i32 %local.check.payload.4484, %local.check.extent.4483
  %descriptor.owner.offset.valid.4493 = and i1 %descriptor.owner.inside.4488, %descriptor.offset.inside.4489
  %descriptor.range.inside.4495 = and i1 %descriptor.owner.offset.valid.4493, %descriptor.extent.inside.4491
  %descriptor.range.valid.4494 = and i1 %descriptor.range.inside.4495, %descriptor.payload.inside.4492
  br i1 %descriptor.range.valid.4494, label %descriptor.valid.4496, label %descriptor.invalid.4497
descriptor.invalid.4497:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4496:
  %descriptor.initialized.status.4498 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4482, i32 %local.check.extent.4483)
  %helper.ok.4499 = icmp eq i32 %descriptor.initialized.status.4498, 0
  br i1 %helper.ok.4499, label %helper.continue.4500, label %frame.failure.0
helper.continue.4500:
  br label %local.descriptor.checked.4481
local.descriptor.inactive.4480:
  br label %local.descriptor.checked.4481
local.descriptor.checked.4481:
  %local.is.active.4501 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.4501, label %local.descriptor.active.4502, label %local.descriptor.inactive.4503
local.descriptor.active.4502:
  %local.check.offset.4505 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.4506 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.4507 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.4508 = load i32, ptr %local.owner.end.12, align 4
  %context.field.4509 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4510 = load i32, ptr %context.field.4509, align 4
  %stack.sub.4513 = sub i32 %local.check.owner.end.4508, %local.check.offset.4505
  %descriptor.owner.inside.4511 = icmp ule i32 %local.check.owner.end.4508, %context.value.4510
  %descriptor.offset.inside.4512 = icmp ule i32 %local.check.offset.4505, %local.check.owner.end.4508
  %descriptor.extent.inside.4514 = icmp ule i32 %local.check.extent.4506, %stack.sub.4513
  %descriptor.payload.inside.4515 = icmp ule i32 %local.check.payload.4507, %local.check.extent.4506
  %descriptor.owner.offset.valid.4516 = and i1 %descriptor.owner.inside.4511, %descriptor.offset.inside.4512
  %descriptor.range.inside.4518 = and i1 %descriptor.owner.offset.valid.4516, %descriptor.extent.inside.4514
  %descriptor.range.valid.4517 = and i1 %descriptor.range.inside.4518, %descriptor.payload.inside.4515
  br i1 %descriptor.range.valid.4517, label %descriptor.valid.4519, label %descriptor.invalid.4520
descriptor.invalid.4520:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4519:
  %descriptor.initialized.status.4521 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4505, i32 %local.check.extent.4506)
  %helper.ok.4522 = icmp eq i32 %descriptor.initialized.status.4521, 0
  br i1 %helper.ok.4522, label %helper.continue.4523, label %frame.failure.0
helper.continue.4523:
  br label %local.descriptor.checked.4504
local.descriptor.inactive.4503:
  br label %local.descriptor.checked.4504
local.descriptor.checked.4504:
  %local.is.active.4524 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.4524, label %local.descriptor.active.4525, label %local.descriptor.inactive.4526
local.descriptor.active.4525:
  %local.check.offset.4528 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.4529 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.4530 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.4531 = load i32, ptr %local.owner.end.18, align 4
  %context.field.4532 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4533 = load i32, ptr %context.field.4532, align 4
  %stack.sub.4536 = sub i32 %local.check.owner.end.4531, %local.check.offset.4528
  %descriptor.owner.inside.4534 = icmp ule i32 %local.check.owner.end.4531, %context.value.4533
  %descriptor.offset.inside.4535 = icmp ule i32 %local.check.offset.4528, %local.check.owner.end.4531
  %descriptor.extent.inside.4537 = icmp ule i32 %local.check.extent.4529, %stack.sub.4536
  %descriptor.payload.inside.4538 = icmp ule i32 %local.check.payload.4530, %local.check.extent.4529
  %descriptor.owner.offset.valid.4539 = and i1 %descriptor.owner.inside.4534, %descriptor.offset.inside.4535
  %descriptor.range.inside.4541 = and i1 %descriptor.owner.offset.valid.4539, %descriptor.extent.inside.4537
  %descriptor.range.valid.4540 = and i1 %descriptor.range.inside.4541, %descriptor.payload.inside.4538
  br i1 %descriptor.range.valid.4540, label %descriptor.valid.4542, label %descriptor.invalid.4543
descriptor.invalid.4543:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4542:
  %descriptor.initialized.status.4544 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4528, i32 %local.check.extent.4529)
  %helper.ok.4545 = icmp eq i32 %descriptor.initialized.status.4544, 0
  br i1 %helper.ok.4545, label %helper.continue.4546, label %frame.failure.0
helper.continue.4546:
  br label %local.descriptor.checked.4527
local.descriptor.inactive.4526:
  br label %local.descriptor.checked.4527
local.descriptor.checked.4527:
  %local.is.active.4547 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.4547, label %local.descriptor.active.4548, label %local.descriptor.inactive.4549
local.descriptor.active.4548:
  %local.check.offset.4551 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.4552 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.4553 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.4554 = load i32, ptr %local.owner.end.24, align 4
  %context.field.4555 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4556 = load i32, ptr %context.field.4555, align 4
  %stack.sub.4559 = sub i32 %local.check.owner.end.4554, %local.check.offset.4551
  %descriptor.owner.inside.4557 = icmp ule i32 %local.check.owner.end.4554, %context.value.4556
  %descriptor.offset.inside.4558 = icmp ule i32 %local.check.offset.4551, %local.check.owner.end.4554
  %descriptor.extent.inside.4560 = icmp ule i32 %local.check.extent.4552, %stack.sub.4559
  %descriptor.payload.inside.4561 = icmp ule i32 %local.check.payload.4553, %local.check.extent.4552
  %descriptor.owner.offset.valid.4562 = and i1 %descriptor.owner.inside.4557, %descriptor.offset.inside.4558
  %descriptor.range.inside.4564 = and i1 %descriptor.owner.offset.valid.4562, %descriptor.extent.inside.4560
  %descriptor.range.valid.4563 = and i1 %descriptor.range.inside.4564, %descriptor.payload.inside.4561
  br i1 %descriptor.range.valid.4563, label %descriptor.valid.4565, label %descriptor.invalid.4566
descriptor.invalid.4566:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4565:
  %descriptor.initialized.status.4567 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4551, i32 %local.check.extent.4552)
  %helper.ok.4568 = icmp eq i32 %descriptor.initialized.status.4567, 0
  br i1 %helper.ok.4568, label %helper.continue.4569, label %frame.failure.0
helper.continue.4569:
  br label %local.descriptor.checked.4550
local.descriptor.inactive.4549:
  br label %local.descriptor.checked.4550
local.descriptor.checked.4550:
  %local.is.active.4570 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.4570, label %local.descriptor.active.4571, label %local.descriptor.inactive.4572
local.descriptor.active.4571:
  %local.check.offset.4574 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.4575 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.4576 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.4577 = load i32, ptr %local.owner.end.30, align 4
  %context.field.4578 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4579 = load i32, ptr %context.field.4578, align 4
  %stack.sub.4582 = sub i32 %local.check.owner.end.4577, %local.check.offset.4574
  %descriptor.owner.inside.4580 = icmp ule i32 %local.check.owner.end.4577, %context.value.4579
  %descriptor.offset.inside.4581 = icmp ule i32 %local.check.offset.4574, %local.check.owner.end.4577
  %descriptor.extent.inside.4583 = icmp ule i32 %local.check.extent.4575, %stack.sub.4582
  %descriptor.payload.inside.4584 = icmp ule i32 %local.check.payload.4576, %local.check.extent.4575
  %descriptor.owner.offset.valid.4585 = and i1 %descriptor.owner.inside.4580, %descriptor.offset.inside.4581
  %descriptor.range.inside.4587 = and i1 %descriptor.owner.offset.valid.4585, %descriptor.extent.inside.4583
  %descriptor.range.valid.4586 = and i1 %descriptor.range.inside.4587, %descriptor.payload.inside.4584
  br i1 %descriptor.range.valid.4586, label %descriptor.valid.4588, label %descriptor.invalid.4589
descriptor.invalid.4589:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4588:
  %descriptor.initialized.status.4590 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4574, i32 %local.check.extent.4575)
  %helper.ok.4591 = icmp eq i32 %descriptor.initialized.status.4590, 0
  br i1 %helper.ok.4591, label %helper.continue.4592, label %frame.failure.0
helper.continue.4592:
  br label %local.descriptor.checked.4573
local.descriptor.inactive.4572:
  br label %local.descriptor.checked.4573
local.descriptor.checked.4573:
  %local.is.active.4593 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.4593, label %local.descriptor.active.4594, label %local.descriptor.inactive.4595
local.descriptor.active.4594:
  %local.check.offset.4597 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.4598 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.4599 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.4600 = load i32, ptr %local.owner.end.36, align 4
  %context.field.4601 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4602 = load i32, ptr %context.field.4601, align 4
  %stack.sub.4605 = sub i32 %local.check.owner.end.4600, %local.check.offset.4597
  %descriptor.owner.inside.4603 = icmp ule i32 %local.check.owner.end.4600, %context.value.4602
  %descriptor.offset.inside.4604 = icmp ule i32 %local.check.offset.4597, %local.check.owner.end.4600
  %descriptor.extent.inside.4606 = icmp ule i32 %local.check.extent.4598, %stack.sub.4605
  %descriptor.payload.inside.4607 = icmp ule i32 %local.check.payload.4599, %local.check.extent.4598
  %descriptor.owner.offset.valid.4608 = and i1 %descriptor.owner.inside.4603, %descriptor.offset.inside.4604
  %descriptor.range.inside.4610 = and i1 %descriptor.owner.offset.valid.4608, %descriptor.extent.inside.4606
  %descriptor.range.valid.4609 = and i1 %descriptor.range.inside.4610, %descriptor.payload.inside.4607
  br i1 %descriptor.range.valid.4609, label %descriptor.valid.4611, label %descriptor.invalid.4612
descriptor.invalid.4612:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4611:
  %descriptor.initialized.status.4613 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4597, i32 %local.check.extent.4598)
  %helper.ok.4614 = icmp eq i32 %descriptor.initialized.status.4613, 0
  br i1 %helper.ok.4614, label %helper.continue.4615, label %frame.failure.0
helper.continue.4615:
  br label %local.descriptor.checked.4596
local.descriptor.inactive.4595:
  br label %local.descriptor.checked.4596
local.descriptor.checked.4596:
  %context.field.4616 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4617 = load i32, ptr %context.field.4616, align 4
  %stack.sub.4618 = sub i32 %context.value.4617, %context.value.39
  call void @al_owning_record_layout(ptr %ctx, i32 18, i32 0, i32 %context.value.39, i32 %stack.sub.4618, i32 0, i32 0, i32 0)
  %context.field.4619 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4620 = load i32, ptr %context.field.4619, align 4
  %runtime.ok.4621 = icmp eq i32 %context.value.4620, 0
  br i1 %runtime.ok.4621, label %runtime.continue.4622, label %frame.failure.0
runtime.continue.4622:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.39, i32 0, i32 0, i32 0)
  %context.field.4623 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4624 = load i32, ptr %context.field.4623, align 4
  %runtime.ok.4625 = icmp eq i32 %context.value.4624, 0
  br i1 %runtime.ok.4625, label %runtime.continue.4626, label %frame.failure.0
runtime.continue.4626:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.39, i32 0, i32 0, i32 0)
  %context.field.4627 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.4628 = load i32, ptr %context.field.4627, align 4
  %context.field.4629 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.4630 = load i32, ptr %context.field.4629, align 4
  %context.field.4631 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.4632 = load i32, ptr %context.field.4631, align 4
  %stack.offset.4633 = add i32 %context.value.41, %context.value.43
  %stack.offset.4634 = add i32 %context.value.4628, %context.value.4630
  %stack.sub.4635 = sub i32 %stack.offset.4633, %stack.offset.4634
  %stack.sub.4636 = sub i32 %context.value.43, %context.value.4630
  %stack.sub.4637 = sub i32 %context.value.4632, %context.value.45
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.4635, i32 %stack.sub.4636)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.4637)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 6
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 6, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %entry.input.descriptors.10 = alloca [6 x %AlOwningDescriptor], align 4
  %input.extent.pointer.11 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.12 = load i32, ptr %input.extent.pointer.11, align 4
  %host.pointer.13 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.14 = alloca i32, align 4
  %input.measured.extent.pointer.15 = alloca i32, align 4
  %input.measure.status.16 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 0, ptr %host.pointer.13, i32 %input.host.extent.12, i32 0, i32 31, ptr %input.payload.pointer.14, ptr %input.measured.extent.pointer.15)
  %helper.ok.17 = icmp eq i32 %input.measure.status.16, 0
  br i1 %helper.ok.17, label %helper.continue.18, label %entry.failure.0
helper.continue.18:
  %input.measured.payload.19 = load i32, ptr %input.payload.pointer.14, align 4
  %input.measured.extent.20 = load i32, ptr %input.measured.extent.pointer.15, align 4
  %input.extent.exact.21 = icmp eq i32 %input.measured.extent.20, %input.host.extent.12
  br i1 %input.extent.exact.21, label %input.extent.exact.22, label %input.extent.invalid.23
input.extent.invalid.23:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 31, i32 %input.measured.extent.20, i32 %input.host.extent.12)
  br label %entry.failure.0
input.extent.exact.22:
  %stack.offset.24 = add i32 0, %input.host.extent.12
  %input.extent.pointer.25 = getelementptr inbounds i32, ptr %input.extents, i32 1
  %input.host.extent.26 = load i32, ptr %input.extent.pointer.25, align 4
  %host.pointer.27 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.24
  %input.payload.pointer.28 = alloca i32, align 4
  %input.measured.extent.pointer.29 = alloca i32, align 4
  %input.measure.status.30 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 0, ptr %host.pointer.27, i32 %input.host.extent.26, i32 0, i32 32, ptr %input.payload.pointer.28, ptr %input.measured.extent.pointer.29)
  %helper.ok.31 = icmp eq i32 %input.measure.status.30, 0
  br i1 %helper.ok.31, label %helper.continue.32, label %entry.failure.0
helper.continue.32:
  %input.measured.payload.33 = load i32, ptr %input.payload.pointer.28, align 4
  %input.measured.extent.34 = load i32, ptr %input.measured.extent.pointer.29, align 4
  %input.extent.exact.35 = icmp eq i32 %input.measured.extent.34, %input.host.extent.26
  br i1 %input.extent.exact.35, label %input.extent.exact.36, label %input.extent.invalid.37
input.extent.invalid.37:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 32, i32 %input.measured.extent.34, i32 %input.host.extent.26)
  br label %entry.failure.0
input.extent.exact.36:
  %stack.offset.38 = add i32 %stack.offset.24, %input.host.extent.26
  %input.extent.pointer.39 = getelementptr inbounds i32, ptr %input.extents, i32 2
  %input.host.extent.40 = load i32, ptr %input.extent.pointer.39, align 4
  %host.pointer.41 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.38
  %input.payload.pointer.42 = alloca i32, align 4
  %input.measured.extent.pointer.43 = alloca i32, align 4
  %input.measure.status.44 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 0, ptr %host.pointer.41, i32 %input.host.extent.40, i32 0, i32 33, ptr %input.payload.pointer.42, ptr %input.measured.extent.pointer.43)
  %helper.ok.45 = icmp eq i32 %input.measure.status.44, 0
  br i1 %helper.ok.45, label %helper.continue.46, label %entry.failure.0
helper.continue.46:
  %input.measured.payload.47 = load i32, ptr %input.payload.pointer.42, align 4
  %input.measured.extent.48 = load i32, ptr %input.measured.extent.pointer.43, align 4
  %input.extent.exact.49 = icmp eq i32 %input.measured.extent.48, %input.host.extent.40
  br i1 %input.extent.exact.49, label %input.extent.exact.50, label %input.extent.invalid.51
input.extent.invalid.51:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 33, i32 %input.measured.extent.48, i32 %input.host.extent.40)
  br label %entry.failure.0
input.extent.exact.50:
  %stack.offset.52 = add i32 %stack.offset.38, %input.host.extent.40
  %input.extent.pointer.53 = getelementptr inbounds i32, ptr %input.extents, i32 3
  %input.host.extent.54 = load i32, ptr %input.extent.pointer.53, align 4
  %host.pointer.55 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.52
  %input.payload.pointer.56 = alloca i32, align 4
  %input.measured.extent.pointer.57 = alloca i32, align 4
  %input.measure.status.58 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 0, ptr %host.pointer.55, i32 %input.host.extent.54, i32 0, i32 34, ptr %input.payload.pointer.56, ptr %input.measured.extent.pointer.57)
  %helper.ok.59 = icmp eq i32 %input.measure.status.58, 0
  br i1 %helper.ok.59, label %helper.continue.60, label %entry.failure.0
helper.continue.60:
  %input.measured.payload.61 = load i32, ptr %input.payload.pointer.56, align 4
  %input.measured.extent.62 = load i32, ptr %input.measured.extent.pointer.57, align 4
  %input.extent.exact.63 = icmp eq i32 %input.measured.extent.62, %input.host.extent.54
  br i1 %input.extent.exact.63, label %input.extent.exact.64, label %input.extent.invalid.65
input.extent.invalid.65:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 34, i32 %input.measured.extent.62, i32 %input.host.extent.54)
  br label %entry.failure.0
input.extent.exact.64:
  %stack.offset.66 = add i32 %stack.offset.52, %input.host.extent.54
  %input.extent.pointer.67 = getelementptr inbounds i32, ptr %input.extents, i32 4
  %input.host.extent.68 = load i32, ptr %input.extent.pointer.67, align 4
  %host.pointer.69 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.66
  %input.payload.pointer.70 = alloca i32, align 4
  %input.measured.extent.pointer.71 = alloca i32, align 4
  %input.measure.status.72 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 0, ptr %host.pointer.69, i32 %input.host.extent.68, i32 0, i32 35, ptr %input.payload.pointer.70, ptr %input.measured.extent.pointer.71)
  %helper.ok.73 = icmp eq i32 %input.measure.status.72, 0
  br i1 %helper.ok.73, label %helper.continue.74, label %entry.failure.0
helper.continue.74:
  %input.measured.payload.75 = load i32, ptr %input.payload.pointer.70, align 4
  %input.measured.extent.76 = load i32, ptr %input.measured.extent.pointer.71, align 4
  %input.extent.exact.77 = icmp eq i32 %input.measured.extent.76, %input.host.extent.68
  br i1 %input.extent.exact.77, label %input.extent.exact.78, label %input.extent.invalid.79
input.extent.invalid.79:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 35, i32 %input.measured.extent.76, i32 %input.host.extent.68)
  br label %entry.failure.0
input.extent.exact.78:
  %stack.offset.80 = add i32 %stack.offset.66, %input.host.extent.68
  %input.extent.pointer.81 = getelementptr inbounds i32, ptr %input.extents, i32 5
  %input.host.extent.82 = load i32, ptr %input.extent.pointer.81, align 4
  %host.pointer.83 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.80
  %input.payload.pointer.84 = alloca i32, align 4
  %input.measured.extent.pointer.85 = alloca i32, align 4
  %input.measure.status.86 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 0, ptr %host.pointer.83, i32 %input.host.extent.82, i32 0, i32 36, ptr %input.payload.pointer.84, ptr %input.measured.extent.pointer.85)
  %helper.ok.87 = icmp eq i32 %input.measure.status.86, 0
  br i1 %helper.ok.87, label %helper.continue.88, label %entry.failure.0
helper.continue.88:
  %input.measured.payload.89 = load i32, ptr %input.payload.pointer.84, align 4
  %input.measured.extent.90 = load i32, ptr %input.measured.extent.pointer.85, align 4
  %input.extent.exact.91 = icmp eq i32 %input.measured.extent.90, %input.host.extent.82
  br i1 %input.extent.exact.91, label %input.extent.exact.92, label %input.extent.invalid.93
input.extent.invalid.93:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 36, i32 %input.measured.extent.90, i32 %input.host.extent.82)
  br label %entry.failure.0
input.extent.exact.92:
  %stack.offset.94 = add i32 %stack.offset.80, %input.host.extent.82
  %input.total.exact.95 = icmp eq i32 %stack.offset.94, %input.bytes
  br i1 %input.total.exact.95, label %input.valid.96, label %input.invalid.97
input.invalid.97:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.94, i32 %input.bytes)
  br label %entry.failure.0
input.valid.96:
  %reserve.status.98 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.94, i32 37)
  %reserve.ok.99 = icmp eq i32 %reserve.status.98, 0
  br i1 %reserve.ok.99, label %reserve.continue.100, label %entry.failure.0
reserve.continue.100:
  %host.pointer.101 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.102 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.101, i32 %input.host.extent.12, i32 0, i32 %input.measured.payload.19, i32 %input.host.extent.12, i32 1, i32 38)
  %helper.ok.103 = icmp eq i32 %input.copy.status.102, 0
  br i1 %helper.ok.103, label %helper.continue.104, label %entry.failure.0
helper.continue.104:
  %stack.offset.105 = add i32 0, %input.host.extent.12
  %descriptor.element.106 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.10, i32 0
  %descriptor.field.107 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.106, i32 0, i32 0
  store i32 1, ptr %descriptor.field.107, align 4
  %descriptor.field.108 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.106, i32 0, i32 1
  store i32 0, ptr %descriptor.field.108, align 4
  %descriptor.field.109 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.106, i32 0, i32 2
  store i32 %input.host.extent.12, ptr %descriptor.field.109, align 4
  %descriptor.field.110 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.106, i32 0, i32 3
  store i32 %input.measured.payload.19, ptr %descriptor.field.110, align 4
  %descriptor.field.111 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.106, i32 0, i32 4
  store i32 %stack.offset.105, ptr %descriptor.field.111, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 0, i32 20, i32 %input.measured.payload.19, i32 %stack.offset.105, i32 %input.host.extent.12)
  %context.field.112 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.113 = load i32, ptr %context.field.112, align 4
  %runtime.ok.114 = icmp eq i32 %context.value.113, 0
  br i1 %runtime.ok.114, label %runtime.continue.115, label %entry.failure.0
runtime.continue.115:
  %host.pointer.116 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.24
  %input.copy.status.117 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.24, ptr %host.pointer.116, i32 %input.host.extent.26, i32 0, i32 %input.measured.payload.33, i32 %input.host.extent.26, i32 1, i32 39)
  %helper.ok.118 = icmp eq i32 %input.copy.status.117, 0
  br i1 %helper.ok.118, label %helper.continue.119, label %entry.failure.0
helper.continue.119:
  %stack.offset.120 = add i32 %stack.offset.24, %input.host.extent.26
  %descriptor.element.121 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.10, i32 1
  %descriptor.field.122 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.121, i32 0, i32 0
  store i32 1, ptr %descriptor.field.122, align 4
  %descriptor.field.123 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.121, i32 0, i32 1
  store i32 %stack.offset.24, ptr %descriptor.field.123, align 4
  %descriptor.field.124 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.121, i32 0, i32 2
  store i32 %input.host.extent.26, ptr %descriptor.field.124, align 4
  %descriptor.field.125 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.121, i32 0, i32 3
  store i32 %input.measured.payload.33, ptr %descriptor.field.125, align 4
  %descriptor.field.126 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.121, i32 0, i32 4
  store i32 %stack.offset.120, ptr %descriptor.field.126, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %stack.offset.24, i32 20, i32 %input.measured.payload.33, i32 %stack.offset.120, i32 %input.host.extent.26)
  %context.field.127 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.128 = load i32, ptr %context.field.127, align 4
  %runtime.ok.129 = icmp eq i32 %context.value.128, 0
  br i1 %runtime.ok.129, label %runtime.continue.130, label %entry.failure.0
runtime.continue.130:
  %host.pointer.131 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.38
  %input.copy.status.132 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.38, ptr %host.pointer.131, i32 %input.host.extent.40, i32 0, i32 %input.measured.payload.47, i32 %input.host.extent.40, i32 1, i32 40)
  %helper.ok.133 = icmp eq i32 %input.copy.status.132, 0
  br i1 %helper.ok.133, label %helper.continue.134, label %entry.failure.0
helper.continue.134:
  %stack.offset.135 = add i32 %stack.offset.38, %input.host.extent.40
  %descriptor.element.136 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.10, i32 2
  %descriptor.field.137 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.136, i32 0, i32 0
  store i32 1, ptr %descriptor.field.137, align 4
  %descriptor.field.138 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.136, i32 0, i32 1
  store i32 %stack.offset.38, ptr %descriptor.field.138, align 4
  %descriptor.field.139 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.136, i32 0, i32 2
  store i32 %input.host.extent.40, ptr %descriptor.field.139, align 4
  %descriptor.field.140 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.136, i32 0, i32 3
  store i32 %input.measured.payload.47, ptr %descriptor.field.140, align 4
  %descriptor.field.141 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.136, i32 0, i32 4
  store i32 %stack.offset.135, ptr %descriptor.field.141, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %stack.offset.38, i32 20, i32 %input.measured.payload.47, i32 %stack.offset.135, i32 %input.host.extent.40)
  %context.field.142 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.143 = load i32, ptr %context.field.142, align 4
  %runtime.ok.144 = icmp eq i32 %context.value.143, 0
  br i1 %runtime.ok.144, label %runtime.continue.145, label %entry.failure.0
runtime.continue.145:
  %host.pointer.146 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.52
  %input.copy.status.147 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.52, ptr %host.pointer.146, i32 %input.host.extent.54, i32 0, i32 %input.measured.payload.61, i32 %input.host.extent.54, i32 1, i32 41)
  %helper.ok.148 = icmp eq i32 %input.copy.status.147, 0
  br i1 %helper.ok.148, label %helper.continue.149, label %entry.failure.0
helper.continue.149:
  %stack.offset.150 = add i32 %stack.offset.52, %input.host.extent.54
  %descriptor.element.151 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.10, i32 3
  %descriptor.field.152 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.151, i32 0, i32 0
  store i32 1, ptr %descriptor.field.152, align 4
  %descriptor.field.153 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.151, i32 0, i32 1
  store i32 %stack.offset.52, ptr %descriptor.field.153, align 4
  %descriptor.field.154 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.151, i32 0, i32 2
  store i32 %input.host.extent.54, ptr %descriptor.field.154, align 4
  %descriptor.field.155 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.151, i32 0, i32 3
  store i32 %input.measured.payload.61, ptr %descriptor.field.155, align 4
  %descriptor.field.156 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.151, i32 0, i32 4
  store i32 %stack.offset.150, ptr %descriptor.field.156, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %stack.offset.52, i32 20, i32 %input.measured.payload.61, i32 %stack.offset.150, i32 %input.host.extent.54)
  %context.field.157 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.158 = load i32, ptr %context.field.157, align 4
  %runtime.ok.159 = icmp eq i32 %context.value.158, 0
  br i1 %runtime.ok.159, label %runtime.continue.160, label %entry.failure.0
runtime.continue.160:
  %host.pointer.161 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.66
  %input.copy.status.162 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.66, ptr %host.pointer.161, i32 %input.host.extent.68, i32 0, i32 %input.measured.payload.75, i32 %input.host.extent.68, i32 1, i32 42)
  %helper.ok.163 = icmp eq i32 %input.copy.status.162, 0
  br i1 %helper.ok.163, label %helper.continue.164, label %entry.failure.0
helper.continue.164:
  %stack.offset.165 = add i32 %stack.offset.66, %input.host.extent.68
  %descriptor.element.166 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.10, i32 4
  %descriptor.field.167 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.166, i32 0, i32 0
  store i32 1, ptr %descriptor.field.167, align 4
  %descriptor.field.168 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.166, i32 0, i32 1
  store i32 %stack.offset.66, ptr %descriptor.field.168, align 4
  %descriptor.field.169 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.166, i32 0, i32 2
  store i32 %input.host.extent.68, ptr %descriptor.field.169, align 4
  %descriptor.field.170 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.166, i32 0, i32 3
  store i32 %input.measured.payload.75, ptr %descriptor.field.170, align 4
  %descriptor.field.171 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.166, i32 0, i32 4
  store i32 %stack.offset.165, ptr %descriptor.field.171, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %stack.offset.66, i32 20, i32 %input.measured.payload.75, i32 %stack.offset.165, i32 %input.host.extent.68)
  %context.field.172 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.173 = load i32, ptr %context.field.172, align 4
  %runtime.ok.174 = icmp eq i32 %context.value.173, 0
  br i1 %runtime.ok.174, label %runtime.continue.175, label %entry.failure.0
runtime.continue.175:
  %host.pointer.176 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.80
  %input.copy.status.177 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.80, ptr %host.pointer.176, i32 %input.host.extent.82, i32 0, i32 %input.measured.payload.89, i32 %input.host.extent.82, i32 1, i32 43)
  %helper.ok.178 = icmp eq i32 %input.copy.status.177, 0
  br i1 %helper.ok.178, label %helper.continue.179, label %entry.failure.0
helper.continue.179:
  %stack.offset.180 = add i32 %stack.offset.80, %input.host.extent.82
  %descriptor.element.181 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.10, i32 5
  %descriptor.field.182 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.181, i32 0, i32 0
  store i32 1, ptr %descriptor.field.182, align 4
  %descriptor.field.183 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.181, i32 0, i32 1
  store i32 %stack.offset.80, ptr %descriptor.field.183, align 4
  %descriptor.field.184 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.181, i32 0, i32 2
  store i32 %input.host.extent.82, ptr %descriptor.field.184, align 4
  %descriptor.field.185 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.181, i32 0, i32 3
  store i32 %input.measured.payload.89, ptr %descriptor.field.185, align 4
  %descriptor.field.186 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.181, i32 0, i32 4
  store i32 %stack.offset.180, ptr %descriptor.field.186, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %stack.offset.80, i32 20, i32 %input.measured.payload.89, i32 %stack.offset.180, i32 %input.host.extent.82)
  %context.field.187 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.188 = load i32, ptr %context.field.187, align 4
  %runtime.ok.189 = icmp eq i32 %context.value.188, 0
  br i1 %runtime.ok.189, label %runtime.continue.190, label %entry.failure.0
runtime.continue.190:
  %entry.body.status.191 = call i32 @agentlang_entry_frame(ptr %ctx, ptr %entry.input.descriptors.10, ptr null, i32 44)
  %entry.body.ok.192 = icmp eq i32 %entry.body.status.191, 0
  br i1 %entry.body.ok.192, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %entry.retained.capacity.i64.193 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.194 = icmp ule i64 0, 4294967295
  %entry.retained.required.truncated.195 = trunc i64 0 to i32
  %entry.retained.required.196 = select i1 %entry.retained.required.fits.u32.194, i32 %entry.retained.required.truncated.195, i32 4294967295
  %entry.retained.capacity.ok.197 = icmp ule i64 0, %entry.retained.capacity.i64.193
  br i1 %entry.retained.capacity.ok.197, label %entry.retained.capacity.ready.198, label %entry.retained.capacity.failure.199
entry.retained.capacity.failure.199:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.196, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.198:
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.200 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.201 = load i32, ptr %context.field.200, align 4
  %context.field.202 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.203 = load i32, ptr %context.field.202, align 4
  %stack.sub.204 = sub i32 0, %context.value.201
  %stack.sub.205 = sub i32 0, %context.value.203
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.204, i32 %stack.sub.205)
  %context.field.206 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.207 = load i32, ptr %context.field.206, align 4
  %runtime.ok.208 = icmp eq i32 %context.value.207, 0
  br i1 %runtime.ok.208, label %runtime.continue.209, label %entry.failure.0
runtime.continue.209:
  br label %entry.return.status
entry.failure.0:
  %context.field.210 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.211 = load i32, ptr %context.field.210, align 4
  %context.field.212 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.213 = load i32, ptr %context.field.212, align 4
  %context.field.214 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.215 = load i32, ptr %context.field.214, align 4
  %stack.offset.216 = add i32 %context.value.211, %context.value.213
  %stack.sub.217 = sub i32 0, %stack.offset.216
  %stack.sub.218 = sub i32 0, %context.value.213
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.217, i32 %stack.sub.218)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.215)
  br label %entry.return.status
entry.return.status:
  %context.field.219 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.220 = load i32, ptr %context.field.219, align 4
  ret i32 %context.value.220
}


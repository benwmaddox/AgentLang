%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [5 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8 }, %AlOwningTypeDescriptor { i32 4, i32 8, i32 0, i32 2, i32 4294967295, i32 4294967295, i32 24, i32 24 }, %AlOwningTypeDescriptor { i32 4, i32 9, i32 2, i32 2, i32 4294967295, i32 4294967295, i32 16, i32 16 }, %AlOwningTypeDescriptor { i32 4, i32 11, i32 4, i32 2, i32 4294967295, i32 4294967295, i32 32, i32 32 }, %AlOwningTypeDescriptor { i32 5, i32 12, i32 6, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8 }], align 4
@al_owning_fields = private constant [6 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 2, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 4294967295, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 4, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 4294967295, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 1, i32 8, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 1, ptr @al_owning_types, i32 5, ptr @al_owning_fields, i32 6 }, align 8
@al_owning_string_literal_0 = private unnamed_addr constant [16 x i8] c"\01\00\00\00\00\00\00\00\21\00\00\00\00\00\00\00", align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 11
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 11, 11
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %step.status.43 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.44 = icmp eq i32 %step.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %frame.failure.0
helper.continue.45:
  %call.arguments.46 = alloca [1 x %AlOwningDescriptor], align 4
  %descriptor.element.47 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.46, i32 0
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 0
  store i32 11, ptr %descriptor.field.48, align 4
  %descriptor.field.49 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.49, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.50, align 4
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.51, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.52, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 11, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.53 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.54 = load i32, ptr %context.field.53, align 4
  %runtime.ok.55 = icmp eq i32 %context.value.54, 0
  br i1 %runtime.ok.55, label %runtime.continue.56, label %frame.failure.0
runtime.continue.56:
  %call.results.57 = alloca [1 x %AlOwningDescriptor], align 4
  %callee.status.58 = call i32 @agentlang_word_0000(ptr %ctx, ptr %call.arguments.46, ptr %call.results.57, i32 2)
  %helper.ok.59 = icmp eq i32 %callee.status.58, 0
  br i1 %helper.ok.59, label %helper.continue.60, label %frame.failure.0
helper.continue.60:
  %descriptor.element.61 = getelementptr inbounds %AlOwningDescriptor, ptr %call.results.57, i32 0
  %descriptor.field.62 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 0
  %descriptor.value.63 = load i32, ptr %descriptor.field.62, align 4
  %descriptor.field.64 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 1
  %descriptor.value.65 = load i32, ptr %descriptor.field.64, align 4
  %descriptor.field.66 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 2
  %descriptor.value.67 = load i32, ptr %descriptor.field.66, align 4
  %descriptor.field.68 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 3
  %descriptor.value.69 = load i32, ptr %descriptor.field.68, align 4
  %descriptor.field.70 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 4
  %descriptor.value.71 = load i32, ptr %descriptor.field.70, align 4
  %callee.result.type.valid.72 = icmp eq i32 %descriptor.value.63, 1
  br i1 %callee.result.type.valid.72, label %callee.result.type.ok.73, label %frame.failure.0
callee.result.type.ok.73:
  %context.field.74 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.75 = load i32, ptr %context.field.74, align 4
  %stack.sub.78 = sub i32 %descriptor.value.71, %descriptor.value.65
  %descriptor.owner.inside.76 = icmp ule i32 %descriptor.value.71, %context.value.75
  %descriptor.offset.inside.77 = icmp ule i32 %descriptor.value.65, %descriptor.value.71
  %descriptor.extent.inside.79 = icmp ule i32 %descriptor.value.67, %stack.sub.78
  %descriptor.payload.inside.80 = icmp ule i32 %descriptor.value.69, %descriptor.value.67
  %descriptor.owner.offset.valid.81 = and i1 %descriptor.owner.inside.76, %descriptor.offset.inside.77
  %descriptor.range.inside.83 = and i1 %descriptor.owner.offset.valid.81, %descriptor.extent.inside.79
  %descriptor.range.valid.82 = and i1 %descriptor.range.inside.83, %descriptor.payload.inside.80
  %descriptor.type.valid.84 = icmp eq i32 1, 1
  %descriptor.valid.85 = and i1 %descriptor.range.valid.82, %descriptor.type.valid.84
  br i1 %descriptor.valid.85, label %descriptor.valid.86, label %descriptor.invalid.87
descriptor.invalid.87:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.86:
  %descriptor.initialized.status.88 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.65, i32 %descriptor.value.67)
  %helper.ok.89 = icmp eq i32 %descriptor.initialized.status.88, 0
  br i1 %helper.ok.89, label %helper.continue.90, label %frame.failure.0
helper.continue.90:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %descriptor.value.65, i32 20, i32 %descriptor.value.69, i32 %descriptor.value.71, i32 %descriptor.value.67)
  %context.field.91 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.92 = load i32, ptr %context.field.91, align 4
  %runtime.ok.93 = icmp eq i32 %context.value.92, 0
  br i1 %runtime.ok.93, label %runtime.continue.94, label %frame.failure.0
runtime.continue.94:
  %context.field.95 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.96 = load i32, ptr %context.field.95, align 4
  %stack.sub.99 = sub i32 %descriptor.value.71, %descriptor.value.65
  %descriptor.owner.inside.97 = icmp ule i32 %descriptor.value.71, %context.value.96
  %descriptor.offset.inside.98 = icmp ule i32 %descriptor.value.65, %descriptor.value.71
  %descriptor.extent.inside.100 = icmp ule i32 %descriptor.value.67, %stack.sub.99
  %descriptor.payload.inside.101 = icmp ule i32 %descriptor.value.69, %descriptor.value.67
  %descriptor.owner.offset.valid.102 = and i1 %descriptor.owner.inside.97, %descriptor.offset.inside.98
  %descriptor.range.inside.104 = and i1 %descriptor.owner.offset.valid.102, %descriptor.extent.inside.100
  %descriptor.range.valid.103 = and i1 %descriptor.range.inside.104, %descriptor.payload.inside.101
  %descriptor.type.valid.105 = icmp eq i32 1, 1
  %descriptor.valid.106 = and i1 %descriptor.range.valid.103, %descriptor.type.valid.105
  br i1 %descriptor.valid.106, label %descriptor.valid.107, label %descriptor.invalid.108
descriptor.invalid.108:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.107:
  %descriptor.initialized.status.109 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.65, i32 %descriptor.value.67)
  %helper.ok.110 = icmp eq i32 %descriptor.initialized.status.109, 0
  br i1 %helper.ok.110, label %helper.continue.111, label %frame.failure.0
helper.continue.111:
  %descriptor.element.112 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.113 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 0
  store i32 1, ptr %descriptor.field.113, align 4
  %descriptor.field.114 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 1
  store i32 %descriptor.value.65, ptr %descriptor.field.114, align 4
  %descriptor.field.115 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 2
  store i32 %descriptor.value.67, ptr %descriptor.field.115, align 4
  %descriptor.field.116 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 3
  store i32 %descriptor.value.69, ptr %descriptor.field.116, align 4
  %descriptor.field.117 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 4
  store i32 %descriptor.value.71, ptr %descriptor.field.117, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %descriptor.value.65, i32 20, i32 %descriptor.value.69, i32 %descriptor.value.71, i32 %descriptor.value.67)
  %context.field.118 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.119 = load i32, ptr %context.field.118, align 4
  %runtime.ok.120 = icmp eq i32 %context.value.119, 0
  br i1 %runtime.ok.120, label %runtime.continue.121, label %frame.failure.0
runtime.continue.121:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.122 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.123 = load i32, ptr %context.field.122, align 4
  %context.field.124 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.125 = load i32, ptr %context.field.124, align 4
  %context.field.126 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.127 = load i32, ptr %context.field.126, align 4
  %stack.offset.128 = add i32 %context.value.5, %context.value.7
  %stack.offset.129 = add i32 %context.value.123, %context.value.125
  %stack.sub.130 = sub i32 %stack.offset.128, %stack.offset.129
  %stack.sub.131 = sub i32 %context.value.7, %context.value.125
  %stack.sub.132 = sub i32 %context.value.127, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.130, i32 %stack.sub.131)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.132)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %local.active.2 = alloca i1, align 1
  %local.offset.3 = alloca i32, align 4
  %local.extent.4 = alloca i32, align 4
  %local.payload.5 = alloca i32, align 4
  %local.owner.end.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %local.active.8 = alloca i1, align 1
  %local.offset.9 = alloca i32, align 4
  %local.extent.10 = alloca i32, align 4
  %local.payload.11 = alloca i32, align 4
  %local.owner.end.12 = alloca i32, align 4
  %local.type.13 = alloca i32, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  %context.field.14 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.15 = load i32, ptr %context.field.14, align 4
  %context.field.16 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.17 = load i32, ptr %context.field.16, align 4
  %context.field.18 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.19 = load i32, ptr %context.field.18, align 4
  %context.field.20 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.21 = load i32, ptr %context.field.20, align 4
  %frame.entered.22 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.23 = icmp eq i32 %frame.entered.22, 0
  br i1 %frame.enter.ok.23, label %frame.enter.continue.24, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.24:
  %descriptor.element.25 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.26 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 0
  %descriptor.value.27 = load i32, ptr %descriptor.field.26, align 4
  %descriptor.field.28 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 1
  %descriptor.value.29 = load i32, ptr %descriptor.field.28, align 4
  %descriptor.field.30 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 2
  %descriptor.value.31 = load i32, ptr %descriptor.field.30, align 4
  %descriptor.field.32 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 3
  %descriptor.value.33 = load i32, ptr %descriptor.field.32, align 4
  %descriptor.field.34 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 4
  %descriptor.value.35 = load i32, ptr %descriptor.field.34, align 4
  %argument.type.valid.36 = icmp eq i32 %descriptor.value.27, 11
  br i1 %argument.type.valid.36, label %argument.type.ok.37, label %frame.failure.0
argument.type.ok.37:
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %stack.sub.42 = sub i32 %descriptor.value.35, %descriptor.value.29
  %descriptor.owner.inside.40 = icmp ule i32 %descriptor.value.35, %context.value.39
  %descriptor.offset.inside.41 = icmp ule i32 %descriptor.value.29, %descriptor.value.35
  %descriptor.extent.inside.43 = icmp ule i32 %descriptor.value.31, %stack.sub.42
  %descriptor.payload.inside.44 = icmp ule i32 %descriptor.value.33, %descriptor.value.31
  %descriptor.owner.offset.valid.45 = and i1 %descriptor.owner.inside.40, %descriptor.offset.inside.41
  %descriptor.range.inside.47 = and i1 %descriptor.owner.offset.valid.45, %descriptor.extent.inside.43
  %descriptor.range.valid.46 = and i1 %descriptor.range.inside.47, %descriptor.payload.inside.44
  %descriptor.type.valid.48 = icmp eq i32 11, 11
  %descriptor.valid.49 = and i1 %descriptor.range.valid.46, %descriptor.type.valid.48
  br i1 %descriptor.valid.49, label %descriptor.valid.50, label %descriptor.invalid.51
descriptor.invalid.51:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.50:
  %descriptor.initialized.status.52 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.29, i32 %descriptor.value.31)
  %helper.ok.53 = icmp eq i32 %descriptor.initialized.status.52, 0
  br i1 %helper.ok.53, label %helper.continue.54, label %frame.failure.0
helper.continue.54:
  %step.status.55 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.56 = icmp eq i32 %step.status.55, 0
  br i1 %helper.ok.56, label %helper.continue.57, label %frame.failure.0
helper.continue.57:
  store i1 true, ptr %local.active.2, align 1
  store i32 %descriptor.value.29, ptr %local.offset.3, align 4
  store i32 %descriptor.value.31, ptr %local.extent.4, align 4
  store i32 %descriptor.value.33, ptr %local.payload.5, align 4
  store i32 %descriptor.value.35, ptr %local.owner.end.6, align 4
  store i32 11, ptr %local.type.7, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 11, i32 %descriptor.value.29, i32 20, i32 %descriptor.value.33, i32 %descriptor.value.35, i32 %descriptor.value.31)
  %context.field.58 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.59 = load i32, ptr %context.field.58, align 4
  %runtime.ok.60 = icmp eq i32 %context.value.59, 0
  br i1 %runtime.ok.60, label %runtime.continue.61, label %frame.failure.0
runtime.continue.61:
  %local.is.active.62 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.62, label %local.descriptor.active.63, label %local.descriptor.inactive.64
local.descriptor.active.63:
  %local.check.offset.66 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.67 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.68 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.69 = load i32, ptr %local.owner.end.6, align 4
  %context.field.70 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.71 = load i32, ptr %context.field.70, align 4
  %stack.sub.74 = sub i32 %local.check.owner.end.69, %local.check.offset.66
  %descriptor.owner.inside.72 = icmp ule i32 %local.check.owner.end.69, %context.value.71
  %descriptor.offset.inside.73 = icmp ule i32 %local.check.offset.66, %local.check.owner.end.69
  %descriptor.extent.inside.75 = icmp ule i32 %local.check.extent.67, %stack.sub.74
  %descriptor.payload.inside.76 = icmp ule i32 %local.check.payload.68, %local.check.extent.67
  %descriptor.owner.offset.valid.77 = and i1 %descriptor.owner.inside.72, %descriptor.offset.inside.73
  %descriptor.range.inside.79 = and i1 %descriptor.owner.offset.valid.77, %descriptor.extent.inside.75
  %descriptor.range.valid.78 = and i1 %descriptor.range.inside.79, %descriptor.payload.inside.76
  br i1 %descriptor.range.valid.78, label %descriptor.valid.80, label %descriptor.invalid.81
descriptor.invalid.81:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.80:
  %descriptor.initialized.status.82 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.66, i32 %local.check.extent.67)
  %helper.ok.83 = icmp eq i32 %descriptor.initialized.status.82, 0
  br i1 %helper.ok.83, label %helper.continue.84, label %frame.failure.0
helper.continue.84:
  br label %local.descriptor.checked.65
local.descriptor.inactive.64:
  br label %local.descriptor.checked.65
local.descriptor.checked.65:
  %local.is.active.85 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.85, label %local.descriptor.active.86, label %local.descriptor.inactive.87
local.descriptor.active.86:
  %local.check.offset.89 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.90 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.91 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.92 = load i32, ptr %local.owner.end.12, align 4
  %context.field.93 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.94 = load i32, ptr %context.field.93, align 4
  %stack.sub.97 = sub i32 %local.check.owner.end.92, %local.check.offset.89
  %descriptor.owner.inside.95 = icmp ule i32 %local.check.owner.end.92, %context.value.94
  %descriptor.offset.inside.96 = icmp ule i32 %local.check.offset.89, %local.check.owner.end.92
  %descriptor.extent.inside.98 = icmp ule i32 %local.check.extent.90, %stack.sub.97
  %descriptor.payload.inside.99 = icmp ule i32 %local.check.payload.91, %local.check.extent.90
  %descriptor.owner.offset.valid.100 = and i1 %descriptor.owner.inside.95, %descriptor.offset.inside.96
  %descriptor.range.inside.102 = and i1 %descriptor.owner.offset.valid.100, %descriptor.extent.inside.98
  %descriptor.range.valid.101 = and i1 %descriptor.range.inside.102, %descriptor.payload.inside.99
  br i1 %descriptor.range.valid.101, label %descriptor.valid.103, label %descriptor.invalid.104
descriptor.invalid.104:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.103:
  %descriptor.initialized.status.105 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.89, i32 %local.check.extent.90)
  %helper.ok.106 = icmp eq i32 %descriptor.initialized.status.105, 0
  br i1 %helper.ok.106, label %helper.continue.107, label %frame.failure.0
helper.continue.107:
  br label %local.descriptor.checked.88
local.descriptor.inactive.87:
  br label %local.descriptor.checked.88
local.descriptor.checked.88:
  %step.status.108 = call i32 @al_owning_charge_step(ptr %ctx, i32 4)
  %helper.ok.109 = icmp eq i32 %step.status.108, 0
  br i1 %helper.ok.109, label %helper.continue.110, label %frame.failure.0
helper.continue.110:
  %local.resolved.offset.111 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.112 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.113 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.114 = load i32, ptr %local.owner.end.6, align 4
  %context.field.115 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.116 = load i32, ptr %context.field.115, align 4
  %stack.sub.119 = sub i32 %local.resolved.owner.end.114, %local.resolved.offset.111
  %descriptor.owner.inside.117 = icmp ule i32 %local.resolved.owner.end.114, %context.value.116
  %descriptor.offset.inside.118 = icmp ule i32 %local.resolved.offset.111, %local.resolved.owner.end.114
  %descriptor.extent.inside.120 = icmp ule i32 %local.resolved.extent.112, %stack.sub.119
  %descriptor.payload.inside.121 = icmp ule i32 %local.resolved.payload.113, %local.resolved.extent.112
  %descriptor.owner.offset.valid.122 = and i1 %descriptor.owner.inside.117, %descriptor.offset.inside.118
  %descriptor.range.inside.124 = and i1 %descriptor.owner.offset.valid.122, %descriptor.extent.inside.120
  %descriptor.range.valid.123 = and i1 %descriptor.range.inside.124, %descriptor.payload.inside.121
  %descriptor.type.valid.125 = icmp eq i32 11, 11
  %descriptor.valid.126 = and i1 %descriptor.range.valid.123, %descriptor.type.valid.125
  br i1 %descriptor.valid.126, label %descriptor.valid.127, label %descriptor.invalid.128
descriptor.invalid.128:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.127:
  %descriptor.initialized.status.129 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.111, i32 %local.resolved.extent.112)
  %helper.ok.130 = icmp eq i32 %descriptor.initialized.status.129, 0
  br i1 %helper.ok.130, label %helper.continue.131, label %frame.failure.0
helper.continue.131:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 11, i32 %local.resolved.offset.111, i32 20, i32 %local.resolved.payload.113, i32 %local.resolved.owner.end.114, i32 %local.resolved.extent.112)
  %context.field.132 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.133 = load i32, ptr %context.field.132, align 4
  %runtime.ok.134 = icmp eq i32 %context.value.133, 0
  br i1 %runtime.ok.134, label %runtime.continue.135, label %frame.failure.0
runtime.continue.135:
  %context.field.136 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.137 = load i32, ptr %context.field.136, align 4
  %stack.sub.140 = sub i32 %local.resolved.owner.end.114, %local.resolved.offset.111
  %descriptor.owner.inside.138 = icmp ule i32 %local.resolved.owner.end.114, %context.value.137
  %descriptor.offset.inside.139 = icmp ule i32 %local.resolved.offset.111, %local.resolved.owner.end.114
  %descriptor.extent.inside.141 = icmp ule i32 %local.resolved.extent.112, %stack.sub.140
  %descriptor.payload.inside.142 = icmp ule i32 %local.resolved.payload.113, %local.resolved.extent.112
  %descriptor.owner.offset.valid.143 = and i1 %descriptor.owner.inside.138, %descriptor.offset.inside.139
  %descriptor.range.inside.145 = and i1 %descriptor.owner.offset.valid.143, %descriptor.extent.inside.141
  %descriptor.range.valid.144 = and i1 %descriptor.range.inside.145, %descriptor.payload.inside.142
  %descriptor.type.valid.146 = icmp eq i32 11, 11
  %descriptor.valid.147 = and i1 %descriptor.range.valid.144, %descriptor.type.valid.146
  br i1 %descriptor.valid.147, label %descriptor.valid.148, label %descriptor.invalid.149
descriptor.invalid.149:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.148:
  %descriptor.initialized.status.150 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.111, i32 %local.resolved.extent.112)
  %helper.ok.151 = icmp eq i32 %descriptor.initialized.status.150, 0
  br i1 %helper.ok.151, label %helper.continue.152, label %frame.failure.0
helper.continue.152:
  %local.is.active.153 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.153, label %local.descriptor.active.154, label %local.descriptor.inactive.155
local.descriptor.active.154:
  %local.check.offset.157 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.158 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.159 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.160 = load i32, ptr %local.owner.end.6, align 4
  %context.field.161 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.162 = load i32, ptr %context.field.161, align 4
  %stack.sub.165 = sub i32 %local.check.owner.end.160, %local.check.offset.157
  %descriptor.owner.inside.163 = icmp ule i32 %local.check.owner.end.160, %context.value.162
  %descriptor.offset.inside.164 = icmp ule i32 %local.check.offset.157, %local.check.owner.end.160
  %descriptor.extent.inside.166 = icmp ule i32 %local.check.extent.158, %stack.sub.165
  %descriptor.payload.inside.167 = icmp ule i32 %local.check.payload.159, %local.check.extent.158
  %descriptor.owner.offset.valid.168 = and i1 %descriptor.owner.inside.163, %descriptor.offset.inside.164
  %descriptor.range.inside.170 = and i1 %descriptor.owner.offset.valid.168, %descriptor.extent.inside.166
  %descriptor.range.valid.169 = and i1 %descriptor.range.inside.170, %descriptor.payload.inside.167
  br i1 %descriptor.range.valid.169, label %descriptor.valid.171, label %descriptor.invalid.172
descriptor.invalid.172:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.171:
  %descriptor.initialized.status.173 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.157, i32 %local.check.extent.158)
  %helper.ok.174 = icmp eq i32 %descriptor.initialized.status.173, 0
  br i1 %helper.ok.174, label %helper.continue.175, label %frame.failure.0
helper.continue.175:
  br label %local.descriptor.checked.156
local.descriptor.inactive.155:
  br label %local.descriptor.checked.156
local.descriptor.checked.156:
  %local.is.active.176 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.176, label %local.descriptor.active.177, label %local.descriptor.inactive.178
local.descriptor.active.177:
  %local.check.offset.180 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.181 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.182 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.183 = load i32, ptr %local.owner.end.12, align 4
  %context.field.184 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.185 = load i32, ptr %context.field.184, align 4
  %stack.sub.188 = sub i32 %local.check.owner.end.183, %local.check.offset.180
  %descriptor.owner.inside.186 = icmp ule i32 %local.check.owner.end.183, %context.value.185
  %descriptor.offset.inside.187 = icmp ule i32 %local.check.offset.180, %local.check.owner.end.183
  %descriptor.extent.inside.189 = icmp ule i32 %local.check.extent.181, %stack.sub.188
  %descriptor.payload.inside.190 = icmp ule i32 %local.check.payload.182, %local.check.extent.181
  %descriptor.owner.offset.valid.191 = and i1 %descriptor.owner.inside.186, %descriptor.offset.inside.187
  %descriptor.range.inside.193 = and i1 %descriptor.owner.offset.valid.191, %descriptor.extent.inside.189
  %descriptor.range.valid.192 = and i1 %descriptor.range.inside.193, %descriptor.payload.inside.190
  br i1 %descriptor.range.valid.192, label %descriptor.valid.194, label %descriptor.invalid.195
descriptor.invalid.195:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.194:
  %descriptor.initialized.status.196 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.180, i32 %local.check.extent.181)
  %helper.ok.197 = icmp eq i32 %descriptor.initialized.status.196, 0
  br i1 %helper.ok.197, label %helper.continue.198, label %frame.failure.0
helper.continue.198:
  br label %local.descriptor.checked.179
local.descriptor.inactive.178:
  br label %local.descriptor.checked.179
local.descriptor.checked.179:
  %step.status.199 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.200 = icmp eq i32 %step.status.199, 0
  br i1 %helper.ok.200, label %helper.continue.201, label %frame.failure.0
helper.continue.201:
  %field.location.202 = alloca %AlOwningFieldLocation, align 4
  %field.location.status.203 = call i32 @al_owning_locate_field(ptr %ctx, ptr @al_owning_layout, i32 3, i32 %local.resolved.offset.111, i32 %local.resolved.extent.112, i32 1, i32 6, ptr %field.location.202)
  %helper.ok.204 = icmp eq i32 %field.location.status.203, 0
  br i1 %helper.ok.204, label %helper.continue.205, label %frame.failure.0
helper.continue.205:
  %field.offset.pointer.206 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.202, i32 0, i32 0
  %field.offset.207 = load i32, ptr %field.offset.pointer.206, align 4
  %field.payload.pointer.208 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.202, i32 0, i32 1
  %field.payload.209 = load i32, ptr %field.payload.pointer.208, align 4
  %field.extent.pointer.210 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.202, i32 0, i32 2
  %field.extent.211 = load i32, ptr %field.extent.pointer.210, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 7, i32 8, i32 %local.resolved.offset.111, i32 %field.extent.211, i32 %field.payload.209, i32 %field.offset.207, i32 %field.extent.211)
  %context.field.212 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.213 = load i32, ptr %context.field.212, align 4
  %runtime.ok.214 = icmp eq i32 %context.value.213, 0
  br i1 %runtime.ok.214, label %runtime.continue.215, label %frame.failure.0
runtime.continue.215:
  %context.field.216 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.217 = load i32, ptr %context.field.216, align 4
  %stack.sub.220 = sub i32 %local.resolved.owner.end.114, %field.offset.207
  %descriptor.owner.inside.218 = icmp ule i32 %local.resolved.owner.end.114, %context.value.217
  %descriptor.offset.inside.219 = icmp ule i32 %field.offset.207, %local.resolved.owner.end.114
  %descriptor.extent.inside.221 = icmp ule i32 %field.extent.211, %stack.sub.220
  %descriptor.payload.inside.222 = icmp ule i32 %field.payload.209, %field.extent.211
  %descriptor.owner.offset.valid.223 = and i1 %descriptor.owner.inside.218, %descriptor.offset.inside.219
  %descriptor.range.inside.225 = and i1 %descriptor.owner.offset.valid.223, %descriptor.extent.inside.221
  %descriptor.range.valid.224 = and i1 %descriptor.range.inside.225, %descriptor.payload.inside.222
  %descriptor.type.valid.226 = icmp eq i32 8, 8
  %descriptor.valid.227 = and i1 %descriptor.range.valid.224, %descriptor.type.valid.226
  br i1 %descriptor.valid.227, label %descriptor.valid.228, label %descriptor.invalid.229
descriptor.invalid.229:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.228:
  %descriptor.initialized.status.230 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %field.offset.207, i32 %field.extent.211)
  %helper.ok.231 = icmp eq i32 %descriptor.initialized.status.230, 0
  br i1 %helper.ok.231, label %helper.continue.232, label %frame.failure.0
helper.continue.232:
  %local.is.active.233 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.233, label %local.descriptor.active.234, label %local.descriptor.inactive.235
local.descriptor.active.234:
  %local.check.offset.237 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.238 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.239 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.240 = load i32, ptr %local.owner.end.6, align 4
  %context.field.241 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.242 = load i32, ptr %context.field.241, align 4
  %stack.sub.245 = sub i32 %local.check.owner.end.240, %local.check.offset.237
  %descriptor.owner.inside.243 = icmp ule i32 %local.check.owner.end.240, %context.value.242
  %descriptor.offset.inside.244 = icmp ule i32 %local.check.offset.237, %local.check.owner.end.240
  %descriptor.extent.inside.246 = icmp ule i32 %local.check.extent.238, %stack.sub.245
  %descriptor.payload.inside.247 = icmp ule i32 %local.check.payload.239, %local.check.extent.238
  %descriptor.owner.offset.valid.248 = and i1 %descriptor.owner.inside.243, %descriptor.offset.inside.244
  %descriptor.range.inside.250 = and i1 %descriptor.owner.offset.valid.248, %descriptor.extent.inside.246
  %descriptor.range.valid.249 = and i1 %descriptor.range.inside.250, %descriptor.payload.inside.247
  br i1 %descriptor.range.valid.249, label %descriptor.valid.251, label %descriptor.invalid.252
descriptor.invalid.252:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.251:
  %descriptor.initialized.status.253 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.237, i32 %local.check.extent.238)
  %helper.ok.254 = icmp eq i32 %descriptor.initialized.status.253, 0
  br i1 %helper.ok.254, label %helper.continue.255, label %frame.failure.0
helper.continue.255:
  br label %local.descriptor.checked.236
local.descriptor.inactive.235:
  br label %local.descriptor.checked.236
local.descriptor.checked.236:
  %local.is.active.256 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.256, label %local.descriptor.active.257, label %local.descriptor.inactive.258
local.descriptor.active.257:
  %local.check.offset.260 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.261 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.262 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.263 = load i32, ptr %local.owner.end.12, align 4
  %context.field.264 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.265 = load i32, ptr %context.field.264, align 4
  %stack.sub.268 = sub i32 %local.check.owner.end.263, %local.check.offset.260
  %descriptor.owner.inside.266 = icmp ule i32 %local.check.owner.end.263, %context.value.265
  %descriptor.offset.inside.267 = icmp ule i32 %local.check.offset.260, %local.check.owner.end.263
  %descriptor.extent.inside.269 = icmp ule i32 %local.check.extent.261, %stack.sub.268
  %descriptor.payload.inside.270 = icmp ule i32 %local.check.payload.262, %local.check.extent.261
  %descriptor.owner.offset.valid.271 = and i1 %descriptor.owner.inside.266, %descriptor.offset.inside.267
  %descriptor.range.inside.273 = and i1 %descriptor.owner.offset.valid.271, %descriptor.extent.inside.269
  %descriptor.range.valid.272 = and i1 %descriptor.range.inside.273, %descriptor.payload.inside.270
  br i1 %descriptor.range.valid.272, label %descriptor.valid.274, label %descriptor.invalid.275
descriptor.invalid.275:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.274:
  %descriptor.initialized.status.276 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.260, i32 %local.check.extent.261)
  %helper.ok.277 = icmp eq i32 %descriptor.initialized.status.276, 0
  br i1 %helper.ok.277, label %helper.continue.278, label %frame.failure.0
helper.continue.278:
  br label %local.descriptor.checked.259
local.descriptor.inactive.258:
  br label %local.descriptor.checked.259
local.descriptor.checked.259:
  %step.status.279 = call i32 @al_owning_charge_step(ptr %ctx, i32 7)
  %helper.ok.280 = icmp eq i32 %step.status.279, 0
  br i1 %helper.ok.280, label %helper.continue.281, label %frame.failure.0
helper.continue.281:
  %field.location.282 = alloca %AlOwningFieldLocation, align 4
  %field.location.status.283 = call i32 @al_owning_locate_field(ptr %ctx, ptr @al_owning_layout, i32 1, i32 %field.offset.207, i32 %field.extent.211, i32 0, i32 8, ptr %field.location.282)
  %helper.ok.284 = icmp eq i32 %field.location.status.283, 0
  br i1 %helper.ok.284, label %helper.continue.285, label %frame.failure.0
helper.continue.285:
  %field.offset.pointer.286 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.282, i32 0, i32 0
  %field.offset.287 = load i32, ptr %field.offset.pointer.286, align 4
  %field.payload.pointer.288 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.282, i32 0, i32 1
  %field.payload.289 = load i32, ptr %field.payload.pointer.288, align 4
  %field.extent.pointer.290 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.282, i32 0, i32 2
  %field.extent.291 = load i32, ptr %field.extent.pointer.290, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 7, i32 9, i32 %field.offset.207, i32 %field.extent.291, i32 %field.payload.289, i32 %field.offset.287, i32 %field.extent.291)
  %context.field.292 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.293 = load i32, ptr %context.field.292, align 4
  %runtime.ok.294 = icmp eq i32 %context.value.293, 0
  br i1 %runtime.ok.294, label %runtime.continue.295, label %frame.failure.0
runtime.continue.295:
  %context.field.296 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.297 = load i32, ptr %context.field.296, align 4
  %stack.sub.300 = sub i32 %local.resolved.owner.end.114, %field.offset.287
  %descriptor.owner.inside.298 = icmp ule i32 %local.resolved.owner.end.114, %context.value.297
  %descriptor.offset.inside.299 = icmp ule i32 %field.offset.287, %local.resolved.owner.end.114
  %descriptor.extent.inside.301 = icmp ule i32 %field.extent.291, %stack.sub.300
  %descriptor.payload.inside.302 = icmp ule i32 %field.payload.289, %field.extent.291
  %descriptor.owner.offset.valid.303 = and i1 %descriptor.owner.inside.298, %descriptor.offset.inside.299
  %descriptor.range.inside.305 = and i1 %descriptor.owner.offset.valid.303, %descriptor.extent.inside.301
  %descriptor.range.valid.304 = and i1 %descriptor.range.inside.305, %descriptor.payload.inside.302
  %descriptor.type.valid.306 = icmp eq i32 9, 9
  %descriptor.valid.307 = and i1 %descriptor.range.valid.304, %descriptor.type.valid.306
  br i1 %descriptor.valid.307, label %descriptor.valid.308, label %descriptor.invalid.309
descriptor.invalid.309:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.308:
  %descriptor.initialized.status.310 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %field.offset.287, i32 %field.extent.291)
  %helper.ok.311 = icmp eq i32 %descriptor.initialized.status.310, 0
  br i1 %helper.ok.311, label %helper.continue.312, label %frame.failure.0
helper.continue.312:
  %local.is.active.313 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.313, label %local.descriptor.active.314, label %local.descriptor.inactive.315
local.descriptor.active.314:
  %local.check.offset.317 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.318 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.319 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.320 = load i32, ptr %local.owner.end.6, align 4
  %context.field.321 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.322 = load i32, ptr %context.field.321, align 4
  %stack.sub.325 = sub i32 %local.check.owner.end.320, %local.check.offset.317
  %descriptor.owner.inside.323 = icmp ule i32 %local.check.owner.end.320, %context.value.322
  %descriptor.offset.inside.324 = icmp ule i32 %local.check.offset.317, %local.check.owner.end.320
  %descriptor.extent.inside.326 = icmp ule i32 %local.check.extent.318, %stack.sub.325
  %descriptor.payload.inside.327 = icmp ule i32 %local.check.payload.319, %local.check.extent.318
  %descriptor.owner.offset.valid.328 = and i1 %descriptor.owner.inside.323, %descriptor.offset.inside.324
  %descriptor.range.inside.330 = and i1 %descriptor.owner.offset.valid.328, %descriptor.extent.inside.326
  %descriptor.range.valid.329 = and i1 %descriptor.range.inside.330, %descriptor.payload.inside.327
  br i1 %descriptor.range.valid.329, label %descriptor.valid.331, label %descriptor.invalid.332
descriptor.invalid.332:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.331:
  %descriptor.initialized.status.333 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.317, i32 %local.check.extent.318)
  %helper.ok.334 = icmp eq i32 %descriptor.initialized.status.333, 0
  br i1 %helper.ok.334, label %helper.continue.335, label %frame.failure.0
helper.continue.335:
  br label %local.descriptor.checked.316
local.descriptor.inactive.315:
  br label %local.descriptor.checked.316
local.descriptor.checked.316:
  %local.is.active.336 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.336, label %local.descriptor.active.337, label %local.descriptor.inactive.338
local.descriptor.active.337:
  %local.check.offset.340 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.341 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.342 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.343 = load i32, ptr %local.owner.end.12, align 4
  %context.field.344 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.345 = load i32, ptr %context.field.344, align 4
  %stack.sub.348 = sub i32 %local.check.owner.end.343, %local.check.offset.340
  %descriptor.owner.inside.346 = icmp ule i32 %local.check.owner.end.343, %context.value.345
  %descriptor.offset.inside.347 = icmp ule i32 %local.check.offset.340, %local.check.owner.end.343
  %descriptor.extent.inside.349 = icmp ule i32 %local.check.extent.341, %stack.sub.348
  %descriptor.payload.inside.350 = icmp ule i32 %local.check.payload.342, %local.check.extent.341
  %descriptor.owner.offset.valid.351 = and i1 %descriptor.owner.inside.346, %descriptor.offset.inside.347
  %descriptor.range.inside.353 = and i1 %descriptor.owner.offset.valid.351, %descriptor.extent.inside.349
  %descriptor.range.valid.352 = and i1 %descriptor.range.inside.353, %descriptor.payload.inside.350
  br i1 %descriptor.range.valid.352, label %descriptor.valid.354, label %descriptor.invalid.355
descriptor.invalid.355:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.354:
  %descriptor.initialized.status.356 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.340, i32 %local.check.extent.341)
  %helper.ok.357 = icmp eq i32 %descriptor.initialized.status.356, 0
  br i1 %helper.ok.357, label %helper.continue.358, label %frame.failure.0
helper.continue.358:
  br label %local.descriptor.checked.339
local.descriptor.inactive.338:
  br label %local.descriptor.checked.339
local.descriptor.checked.339:
  %step.status.359 = call i32 @al_owning_charge_step(ptr %ctx, i32 9)
  %helper.ok.360 = icmp eq i32 %step.status.359, 0
  br i1 %helper.ok.360, label %helper.continue.361, label %frame.failure.0
helper.continue.361:
  %field.location.362 = alloca %AlOwningFieldLocation, align 4
  %field.location.status.363 = call i32 @al_owning_locate_field(ptr %ctx, ptr @al_owning_layout, i32 2, i32 %field.offset.287, i32 %field.extent.291, i32 0, i32 10, ptr %field.location.362)
  %helper.ok.364 = icmp eq i32 %field.location.status.363, 0
  br i1 %helper.ok.364, label %helper.continue.365, label %frame.failure.0
helper.continue.365:
  %field.offset.pointer.366 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.362, i32 0, i32 0
  %field.offset.367 = load i32, ptr %field.offset.pointer.366, align 4
  %field.payload.pointer.368 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.362, i32 0, i32 1
  %field.payload.369 = load i32, ptr %field.payload.pointer.368, align 4
  %field.extent.pointer.370 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.362, i32 0, i32 2
  %field.extent.371 = load i32, ptr %field.extent.pointer.370, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 7, i32 12, i32 %field.offset.287, i32 %field.extent.371, i32 %field.payload.369, i32 %field.offset.367, i32 %field.extent.371)
  %context.field.372 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.373 = load i32, ptr %context.field.372, align 4
  %runtime.ok.374 = icmp eq i32 %context.value.373, 0
  br i1 %runtime.ok.374, label %runtime.continue.375, label %frame.failure.0
runtime.continue.375:
  %context.field.376 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.377 = load i32, ptr %context.field.376, align 4
  %stack.sub.380 = sub i32 %local.resolved.owner.end.114, %field.offset.367
  %descriptor.owner.inside.378 = icmp ule i32 %local.resolved.owner.end.114, %context.value.377
  %descriptor.offset.inside.379 = icmp ule i32 %field.offset.367, %local.resolved.owner.end.114
  %descriptor.extent.inside.381 = icmp ule i32 %field.extent.371, %stack.sub.380
  %descriptor.payload.inside.382 = icmp ule i32 %field.payload.369, %field.extent.371
  %descriptor.owner.offset.valid.383 = and i1 %descriptor.owner.inside.378, %descriptor.offset.inside.379
  %descriptor.range.inside.385 = and i1 %descriptor.owner.offset.valid.383, %descriptor.extent.inside.381
  %descriptor.range.valid.384 = and i1 %descriptor.range.inside.385, %descriptor.payload.inside.382
  %descriptor.type.valid.386 = icmp eq i32 12, 12
  %descriptor.valid.387 = and i1 %descriptor.range.valid.384, %descriptor.type.valid.386
  br i1 %descriptor.valid.387, label %descriptor.valid.388, label %descriptor.invalid.389
descriptor.invalid.389:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.388:
  %descriptor.initialized.status.390 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %field.offset.367, i32 %field.extent.371)
  %helper.ok.391 = icmp eq i32 %descriptor.initialized.status.390, 0
  br i1 %helper.ok.391, label %helper.continue.392, label %frame.failure.0
helper.continue.392:
  %local.is.active.393 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.393, label %local.descriptor.active.394, label %local.descriptor.inactive.395
local.descriptor.active.394:
  %local.check.offset.397 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.398 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.399 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.400 = load i32, ptr %local.owner.end.6, align 4
  %context.field.401 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.402 = load i32, ptr %context.field.401, align 4
  %stack.sub.405 = sub i32 %local.check.owner.end.400, %local.check.offset.397
  %descriptor.owner.inside.403 = icmp ule i32 %local.check.owner.end.400, %context.value.402
  %descriptor.offset.inside.404 = icmp ule i32 %local.check.offset.397, %local.check.owner.end.400
  %descriptor.extent.inside.406 = icmp ule i32 %local.check.extent.398, %stack.sub.405
  %descriptor.payload.inside.407 = icmp ule i32 %local.check.payload.399, %local.check.extent.398
  %descriptor.owner.offset.valid.408 = and i1 %descriptor.owner.inside.403, %descriptor.offset.inside.404
  %descriptor.range.inside.410 = and i1 %descriptor.owner.offset.valid.408, %descriptor.extent.inside.406
  %descriptor.range.valid.409 = and i1 %descriptor.range.inside.410, %descriptor.payload.inside.407
  br i1 %descriptor.range.valid.409, label %descriptor.valid.411, label %descriptor.invalid.412
descriptor.invalid.412:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.411:
  %descriptor.initialized.status.413 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.397, i32 %local.check.extent.398)
  %helper.ok.414 = icmp eq i32 %descriptor.initialized.status.413, 0
  br i1 %helper.ok.414, label %helper.continue.415, label %frame.failure.0
helper.continue.415:
  br label %local.descriptor.checked.396
local.descriptor.inactive.395:
  br label %local.descriptor.checked.396
local.descriptor.checked.396:
  %local.is.active.416 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.416, label %local.descriptor.active.417, label %local.descriptor.inactive.418
local.descriptor.active.417:
  %local.check.offset.420 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.421 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.422 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.423 = load i32, ptr %local.owner.end.12, align 4
  %context.field.424 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.425 = load i32, ptr %context.field.424, align 4
  %stack.sub.428 = sub i32 %local.check.owner.end.423, %local.check.offset.420
  %descriptor.owner.inside.426 = icmp ule i32 %local.check.owner.end.423, %context.value.425
  %descriptor.offset.inside.427 = icmp ule i32 %local.check.offset.420, %local.check.owner.end.423
  %descriptor.extent.inside.429 = icmp ule i32 %local.check.extent.421, %stack.sub.428
  %descriptor.payload.inside.430 = icmp ule i32 %local.check.payload.422, %local.check.extent.421
  %descriptor.owner.offset.valid.431 = and i1 %descriptor.owner.inside.426, %descriptor.offset.inside.427
  %descriptor.range.inside.433 = and i1 %descriptor.owner.offset.valid.431, %descriptor.extent.inside.429
  %descriptor.range.valid.432 = and i1 %descriptor.range.inside.433, %descriptor.payload.inside.430
  br i1 %descriptor.range.valid.432, label %descriptor.valid.434, label %descriptor.invalid.435
descriptor.invalid.435:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.434:
  %descriptor.initialized.status.436 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.420, i32 %local.check.extent.421)
  %helper.ok.437 = icmp eq i32 %descriptor.initialized.status.436, 0
  br i1 %helper.ok.437, label %helper.continue.438, label %frame.failure.0
helper.continue.438:
  br label %local.descriptor.checked.419
local.descriptor.inactive.418:
  br label %local.descriptor.checked.419
local.descriptor.checked.419:
  %step.status.439 = call i32 @al_owning_charge_step(ptr %ctx, i32 11)
  %helper.ok.440 = icmp eq i32 %step.status.439, 0
  br i1 %helper.ok.440, label %helper.continue.441, label %frame.failure.0
helper.continue.441:
  %context.field.442 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.443 = load i32, ptr %context.field.442, align 4
  %stack.offset.444 = add i32 %context.value.443, 16
  %reserve.status.445 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.444, i32 12)
  %reserve.ok.446 = icmp eq i32 %reserve.status.445, 0
  br i1 %reserve.ok.446, label %reserve.continue.447, label %frame.failure.0
reserve.continue.447:
  %literal.status.448 = call i32 @al_owning_copy_constant(ptr %ctx, i32 %context.value.443, ptr getelementptr inbounds ([16 x i8], ptr @al_owning_string_literal_0, i64 0, i64 0), i32 16, i32 10, i32 16, i32 12, i32 13)
  %helper.ok.449 = icmp eq i32 %literal.status.448, 0
  br i1 %helper.ok.449, label %helper.continue.450, label %frame.failure.0
helper.continue.450:
  %context.field.451 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.452 = load i32, ptr %context.field.451, align 4
  %stack.sub.455 = sub i32 %local.resolved.owner.end.114, %field.offset.367
  %descriptor.owner.inside.453 = icmp ule i32 %local.resolved.owner.end.114, %context.value.452
  %descriptor.offset.inside.454 = icmp ule i32 %field.offset.367, %local.resolved.owner.end.114
  %descriptor.extent.inside.456 = icmp ule i32 %field.extent.371, %stack.sub.455
  %descriptor.payload.inside.457 = icmp ule i32 %field.payload.369, %field.extent.371
  %descriptor.owner.offset.valid.458 = and i1 %descriptor.owner.inside.453, %descriptor.offset.inside.454
  %descriptor.range.inside.460 = and i1 %descriptor.owner.offset.valid.458, %descriptor.extent.inside.456
  %descriptor.range.valid.459 = and i1 %descriptor.range.inside.460, %descriptor.payload.inside.457
  %descriptor.type.valid.461 = icmp eq i32 12, 12
  %descriptor.valid.462 = and i1 %descriptor.range.valid.459, %descriptor.type.valid.461
  br i1 %descriptor.valid.462, label %descriptor.valid.463, label %descriptor.invalid.464
descriptor.invalid.464:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.463:
  %descriptor.initialized.status.465 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %field.offset.367, i32 %field.extent.371)
  %helper.ok.466 = icmp eq i32 %descriptor.initialized.status.465, 0
  br i1 %helper.ok.466, label %helper.continue.467, label %frame.failure.0
helper.continue.467:
  %context.field.468 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.469 = load i32, ptr %context.field.468, align 4
  %stack.sub.472 = sub i32 %stack.offset.444, %context.value.443
  %descriptor.owner.inside.470 = icmp ule i32 %stack.offset.444, %context.value.469
  %descriptor.offset.inside.471 = icmp ule i32 %context.value.443, %stack.offset.444
  %descriptor.extent.inside.473 = icmp ule i32 16, %stack.sub.472
  %descriptor.payload.inside.474 = icmp ule i32 10, 16
  %descriptor.owner.offset.valid.475 = and i1 %descriptor.owner.inside.470, %descriptor.offset.inside.471
  %descriptor.range.inside.477 = and i1 %descriptor.owner.offset.valid.475, %descriptor.extent.inside.473
  %descriptor.range.valid.476 = and i1 %descriptor.range.inside.477, %descriptor.payload.inside.474
  %descriptor.type.valid.478 = icmp eq i32 12, 12
  %descriptor.valid.479 = and i1 %descriptor.range.valid.476, %descriptor.type.valid.478
  br i1 %descriptor.valid.479, label %descriptor.valid.480, label %descriptor.invalid.481
descriptor.invalid.481:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.480:
  %descriptor.initialized.status.482 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.443, i32 16)
  %helper.ok.483 = icmp eq i32 %descriptor.initialized.status.482, 0
  br i1 %helper.ok.483, label %helper.continue.484, label %frame.failure.0
helper.continue.484:
  %local.is.active.485 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.485, label %local.descriptor.active.486, label %local.descriptor.inactive.487
local.descriptor.active.486:
  %local.check.offset.489 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.490 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.491 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.492 = load i32, ptr %local.owner.end.6, align 4
  %context.field.493 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.494 = load i32, ptr %context.field.493, align 4
  %stack.sub.497 = sub i32 %local.check.owner.end.492, %local.check.offset.489
  %descriptor.owner.inside.495 = icmp ule i32 %local.check.owner.end.492, %context.value.494
  %descriptor.offset.inside.496 = icmp ule i32 %local.check.offset.489, %local.check.owner.end.492
  %descriptor.extent.inside.498 = icmp ule i32 %local.check.extent.490, %stack.sub.497
  %descriptor.payload.inside.499 = icmp ule i32 %local.check.payload.491, %local.check.extent.490
  %descriptor.owner.offset.valid.500 = and i1 %descriptor.owner.inside.495, %descriptor.offset.inside.496
  %descriptor.range.inside.502 = and i1 %descriptor.owner.offset.valid.500, %descriptor.extent.inside.498
  %descriptor.range.valid.501 = and i1 %descriptor.range.inside.502, %descriptor.payload.inside.499
  br i1 %descriptor.range.valid.501, label %descriptor.valid.503, label %descriptor.invalid.504
descriptor.invalid.504:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.503:
  %descriptor.initialized.status.505 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.489, i32 %local.check.extent.490)
  %helper.ok.506 = icmp eq i32 %descriptor.initialized.status.505, 0
  br i1 %helper.ok.506, label %helper.continue.507, label %frame.failure.0
helper.continue.507:
  br label %local.descriptor.checked.488
local.descriptor.inactive.487:
  br label %local.descriptor.checked.488
local.descriptor.checked.488:
  %local.is.active.508 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.508, label %local.descriptor.active.509, label %local.descriptor.inactive.510
local.descriptor.active.509:
  %local.check.offset.512 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.513 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.514 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.515 = load i32, ptr %local.owner.end.12, align 4
  %context.field.516 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.517 = load i32, ptr %context.field.516, align 4
  %stack.sub.520 = sub i32 %local.check.owner.end.515, %local.check.offset.512
  %descriptor.owner.inside.518 = icmp ule i32 %local.check.owner.end.515, %context.value.517
  %descriptor.offset.inside.519 = icmp ule i32 %local.check.offset.512, %local.check.owner.end.515
  %descriptor.extent.inside.521 = icmp ule i32 %local.check.extent.513, %stack.sub.520
  %descriptor.payload.inside.522 = icmp ule i32 %local.check.payload.514, %local.check.extent.513
  %descriptor.owner.offset.valid.523 = and i1 %descriptor.owner.inside.518, %descriptor.offset.inside.519
  %descriptor.range.inside.525 = and i1 %descriptor.owner.offset.valid.523, %descriptor.extent.inside.521
  %descriptor.range.valid.524 = and i1 %descriptor.range.inside.525, %descriptor.payload.inside.522
  br i1 %descriptor.range.valid.524, label %descriptor.valid.526, label %descriptor.invalid.527
descriptor.invalid.527:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.526:
  %descriptor.initialized.status.528 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.512, i32 %local.check.extent.513)
  %helper.ok.529 = icmp eq i32 %descriptor.initialized.status.528, 0
  br i1 %helper.ok.529, label %helper.continue.530, label %frame.failure.0
helper.continue.530:
  br label %local.descriptor.checked.511
local.descriptor.inactive.510:
  br label %local.descriptor.checked.511
local.descriptor.checked.511:
  %step.status.531 = call i32 @al_owning_charge_step(ptr %ctx, i32 14)
  %helper.ok.532 = icmp eq i32 %step.status.531, 0
  br i1 %helper.ok.532, label %helper.continue.533, label %frame.failure.0
helper.continue.533:
  %context.field.534 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.535 = load i32, ptr %context.field.534, align 4
  %string.concat.units.536 = alloca i32, align 4
  %string.concat.payload.pointer.537 = alloca i32, align 4
  %string.concat.extent.pointer.538 = alloca i32, align 4
  %string.concat.plan.status.539 = call i32 @al_owning_string_concat_plan(ptr %ctx, i32 %field.offset.367, i32 %field.extent.371, i32 %context.value.443, i32 16, i32 15, ptr %string.concat.units.536, ptr %string.concat.payload.pointer.537, ptr %string.concat.extent.pointer.538)
  %helper.ok.540 = icmp eq i32 %string.concat.plan.status.539, 0
  br i1 %helper.ok.540, label %helper.continue.541, label %frame.failure.0
helper.continue.541:
  %string.concat.payload.542 = load i32, ptr %string.concat.payload.pointer.537, align 4
  %string.concat.extent.543 = load i32, ptr %string.concat.extent.pointer.538, align 4
  %stack.offset.544 = add i32 %context.value.535, %string.concat.extent.543
  %reserve.status.545 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.544, i32 16)
  %reserve.ok.546 = icmp eq i32 %reserve.status.545, 0
  br i1 %reserve.ok.546, label %reserve.continue.547, label %frame.failure.0
reserve.continue.547:
  %string.concat.write.status.548 = call i32 @al_owning_string_concat_write(ptr %ctx, i32 %context.value.535, i32 %string.concat.extent.543, i32 %field.offset.367, i32 %field.extent.371, i32 %context.value.443, i32 16, i32 12, i32 15)
  %helper.ok.549 = icmp eq i32 %string.concat.write.status.548, 0
  br i1 %helper.ok.549, label %helper.continue.550, label %frame.failure.0
helper.continue.550:
  call void @al_owning_update_live(ptr %ctx, i32 %string.concat.payload.542, i32 0)
  %context.field.551 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.552 = load i32, ptr %context.field.551, align 4
  %runtime.ok.553 = icmp eq i32 %context.value.552, 0
  br i1 %runtime.ok.553, label %runtime.continue.554, label %frame.failure.0
runtime.continue.554:
  %context.field.555 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.556 = load i32, ptr %context.field.555, align 4
  %stack.sub.559 = sub i32 %stack.offset.544, %context.value.535
  %descriptor.owner.inside.557 = icmp ule i32 %stack.offset.544, %context.value.556
  %descriptor.offset.inside.558 = icmp ule i32 %context.value.535, %stack.offset.544
  %descriptor.extent.inside.560 = icmp ule i32 %string.concat.extent.543, %stack.sub.559
  %descriptor.payload.inside.561 = icmp ule i32 %string.concat.payload.542, %string.concat.extent.543
  %descriptor.owner.offset.valid.562 = and i1 %descriptor.owner.inside.557, %descriptor.offset.inside.558
  %descriptor.range.inside.564 = and i1 %descriptor.owner.offset.valid.562, %descriptor.extent.inside.560
  %descriptor.range.valid.563 = and i1 %descriptor.range.inside.564, %descriptor.payload.inside.561
  %descriptor.type.valid.565 = icmp eq i32 12, 12
  %descriptor.valid.566 = and i1 %descriptor.range.valid.563, %descriptor.type.valid.565
  br i1 %descriptor.valid.566, label %descriptor.valid.567, label %descriptor.invalid.568
descriptor.invalid.568:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.567:
  %descriptor.initialized.status.569 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.535, i32 %string.concat.extent.543)
  %helper.ok.570 = icmp eq i32 %descriptor.initialized.status.569, 0
  br i1 %helper.ok.570, label %helper.continue.571, label %frame.failure.0
helper.continue.571:
  %local.is.active.572 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.572, label %local.descriptor.active.573, label %local.descriptor.inactive.574
local.descriptor.active.573:
  %local.check.offset.576 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.577 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.578 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.579 = load i32, ptr %local.owner.end.6, align 4
  %context.field.580 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.581 = load i32, ptr %context.field.580, align 4
  %stack.sub.584 = sub i32 %local.check.owner.end.579, %local.check.offset.576
  %descriptor.owner.inside.582 = icmp ule i32 %local.check.owner.end.579, %context.value.581
  %descriptor.offset.inside.583 = icmp ule i32 %local.check.offset.576, %local.check.owner.end.579
  %descriptor.extent.inside.585 = icmp ule i32 %local.check.extent.577, %stack.sub.584
  %descriptor.payload.inside.586 = icmp ule i32 %local.check.payload.578, %local.check.extent.577
  %descriptor.owner.offset.valid.587 = and i1 %descriptor.owner.inside.582, %descriptor.offset.inside.583
  %descriptor.range.inside.589 = and i1 %descriptor.owner.offset.valid.587, %descriptor.extent.inside.585
  %descriptor.range.valid.588 = and i1 %descriptor.range.inside.589, %descriptor.payload.inside.586
  br i1 %descriptor.range.valid.588, label %descriptor.valid.590, label %descriptor.invalid.591
descriptor.invalid.591:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.590:
  %descriptor.initialized.status.592 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.576, i32 %local.check.extent.577)
  %helper.ok.593 = icmp eq i32 %descriptor.initialized.status.592, 0
  br i1 %helper.ok.593, label %helper.continue.594, label %frame.failure.0
helper.continue.594:
  br label %local.descriptor.checked.575
local.descriptor.inactive.574:
  br label %local.descriptor.checked.575
local.descriptor.checked.575:
  %local.is.active.595 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.595, label %local.descriptor.active.596, label %local.descriptor.inactive.597
local.descriptor.active.596:
  %local.check.offset.599 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.600 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.601 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.602 = load i32, ptr %local.owner.end.12, align 4
  %context.field.603 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.604 = load i32, ptr %context.field.603, align 4
  %stack.sub.607 = sub i32 %local.check.owner.end.602, %local.check.offset.599
  %descriptor.owner.inside.605 = icmp ule i32 %local.check.owner.end.602, %context.value.604
  %descriptor.offset.inside.606 = icmp ule i32 %local.check.offset.599, %local.check.owner.end.602
  %descriptor.extent.inside.608 = icmp ule i32 %local.check.extent.600, %stack.sub.607
  %descriptor.payload.inside.609 = icmp ule i32 %local.check.payload.601, %local.check.extent.600
  %descriptor.owner.offset.valid.610 = and i1 %descriptor.owner.inside.605, %descriptor.offset.inside.606
  %descriptor.range.inside.612 = and i1 %descriptor.owner.offset.valid.610, %descriptor.extent.inside.608
  %descriptor.range.valid.611 = and i1 %descriptor.range.inside.612, %descriptor.payload.inside.609
  br i1 %descriptor.range.valid.611, label %descriptor.valid.613, label %descriptor.invalid.614
descriptor.invalid.614:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.613:
  %descriptor.initialized.status.615 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.599, i32 %local.check.extent.600)
  %helper.ok.616 = icmp eq i32 %descriptor.initialized.status.615, 0
  br i1 %helper.ok.616, label %helper.continue.617, label %frame.failure.0
helper.continue.617:
  br label %local.descriptor.checked.598
local.descriptor.inactive.597:
  br label %local.descriptor.checked.598
local.descriptor.checked.598:
  %step.status.618 = call i32 @al_owning_charge_step(ptr %ctx, i32 17)
  %helper.ok.619 = icmp eq i32 %step.status.618, 0
  br i1 %helper.ok.619, label %helper.continue.620, label %frame.failure.0
helper.continue.620:
  store i1 true, ptr %local.active.8, align 1
  store i32 %context.value.535, ptr %local.offset.9, align 4
  store i32 %string.concat.extent.543, ptr %local.extent.10, align 4
  store i32 %string.concat.payload.542, ptr %local.payload.11, align 4
  store i32 %stack.offset.544, ptr %local.owner.end.12, align 4
  store i32 12, ptr %local.type.13, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %context.value.535, i32 20, i32 %string.concat.payload.542, i32 %stack.offset.544, i32 %string.concat.extent.543)
  %context.field.621 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.622 = load i32, ptr %context.field.621, align 4
  %runtime.ok.623 = icmp eq i32 %context.value.622, 0
  br i1 %runtime.ok.623, label %runtime.continue.624, label %frame.failure.0
runtime.continue.624:
  %local.is.active.625 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.625, label %local.descriptor.active.626, label %local.descriptor.inactive.627
local.descriptor.active.626:
  %local.check.offset.629 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.630 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.631 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.632 = load i32, ptr %local.owner.end.6, align 4
  %context.field.633 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.634 = load i32, ptr %context.field.633, align 4
  %stack.sub.637 = sub i32 %local.check.owner.end.632, %local.check.offset.629
  %descriptor.owner.inside.635 = icmp ule i32 %local.check.owner.end.632, %context.value.634
  %descriptor.offset.inside.636 = icmp ule i32 %local.check.offset.629, %local.check.owner.end.632
  %descriptor.extent.inside.638 = icmp ule i32 %local.check.extent.630, %stack.sub.637
  %descriptor.payload.inside.639 = icmp ule i32 %local.check.payload.631, %local.check.extent.630
  %descriptor.owner.offset.valid.640 = and i1 %descriptor.owner.inside.635, %descriptor.offset.inside.636
  %descriptor.range.inside.642 = and i1 %descriptor.owner.offset.valid.640, %descriptor.extent.inside.638
  %descriptor.range.valid.641 = and i1 %descriptor.range.inside.642, %descriptor.payload.inside.639
  br i1 %descriptor.range.valid.641, label %descriptor.valid.643, label %descriptor.invalid.644
descriptor.invalid.644:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.643:
  %descriptor.initialized.status.645 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.629, i32 %local.check.extent.630)
  %helper.ok.646 = icmp eq i32 %descriptor.initialized.status.645, 0
  br i1 %helper.ok.646, label %helper.continue.647, label %frame.failure.0
helper.continue.647:
  br label %local.descriptor.checked.628
local.descriptor.inactive.627:
  br label %local.descriptor.checked.628
local.descriptor.checked.628:
  %local.is.active.648 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.648, label %local.descriptor.active.649, label %local.descriptor.inactive.650
local.descriptor.active.649:
  %local.check.offset.652 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.653 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.654 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.655 = load i32, ptr %local.owner.end.12, align 4
  %context.field.656 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.657 = load i32, ptr %context.field.656, align 4
  %stack.sub.660 = sub i32 %local.check.owner.end.655, %local.check.offset.652
  %descriptor.owner.inside.658 = icmp ule i32 %local.check.owner.end.655, %context.value.657
  %descriptor.offset.inside.659 = icmp ule i32 %local.check.offset.652, %local.check.owner.end.655
  %descriptor.extent.inside.661 = icmp ule i32 %local.check.extent.653, %stack.sub.660
  %descriptor.payload.inside.662 = icmp ule i32 %local.check.payload.654, %local.check.extent.653
  %descriptor.owner.offset.valid.663 = and i1 %descriptor.owner.inside.658, %descriptor.offset.inside.659
  %descriptor.range.inside.665 = and i1 %descriptor.owner.offset.valid.663, %descriptor.extent.inside.661
  %descriptor.range.valid.664 = and i1 %descriptor.range.inside.665, %descriptor.payload.inside.662
  br i1 %descriptor.range.valid.664, label %descriptor.valid.666, label %descriptor.invalid.667
descriptor.invalid.667:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.666:
  %descriptor.initialized.status.668 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.652, i32 %local.check.extent.653)
  %helper.ok.669 = icmp eq i32 %descriptor.initialized.status.668, 0
  br i1 %helper.ok.669, label %helper.continue.670, label %frame.failure.0
helper.continue.670:
  br label %local.descriptor.checked.651
local.descriptor.inactive.650:
  br label %local.descriptor.checked.651
local.descriptor.checked.651:
  %step.status.671 = call i32 @al_owning_charge_step(ptr %ctx, i32 18)
  %helper.ok.672 = icmp eq i32 %step.status.671, 0
  br i1 %helper.ok.672, label %helper.continue.673, label %frame.failure.0
helper.continue.673:
  %context.field.674 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.675 = load i32, ptr %context.field.674, align 4
  %stack.offset.676 = add i32 %context.value.675, 8
  %reserve.status.677 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.676, i32 19)
  %reserve.ok.678 = icmp eq i32 %reserve.status.677, 0
  br i1 %reserve.ok.678, label %reserve.continue.679, label %frame.failure.0
reserve.continue.679:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.675, i64 1, i32 1)
  %context.field.680 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.681 = load i32, ptr %context.field.680, align 4
  %runtime.ok.682 = icmp eq i32 %context.value.681, 0
  br i1 %runtime.ok.682, label %runtime.continue.683, label %frame.failure.0
runtime.continue.683:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.684 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.685 = load i32, ptr %context.field.684, align 4
  %runtime.ok.686 = icmp eq i32 %context.value.685, 0
  br i1 %runtime.ok.686, label %runtime.continue.687, label %frame.failure.0
runtime.continue.687:
  %context.field.688 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.689 = load i32, ptr %context.field.688, align 4
  %stack.sub.692 = sub i32 %stack.offset.676, %context.value.675
  %descriptor.owner.inside.690 = icmp ule i32 %stack.offset.676, %context.value.689
  %descriptor.offset.inside.691 = icmp ule i32 %context.value.675, %stack.offset.676
  %descriptor.extent.inside.693 = icmp ule i32 8, %stack.sub.692
  %descriptor.payload.inside.694 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.695 = and i1 %descriptor.owner.inside.690, %descriptor.offset.inside.691
  %descriptor.range.inside.697 = and i1 %descriptor.owner.offset.valid.695, %descriptor.extent.inside.693
  %descriptor.range.valid.696 = and i1 %descriptor.range.inside.697, %descriptor.payload.inside.694
  %descriptor.type.valid.698 = icmp eq i32 1, 1
  %descriptor.valid.699 = and i1 %descriptor.range.valid.696, %descriptor.type.valid.698
  br i1 %descriptor.valid.699, label %descriptor.valid.700, label %descriptor.invalid.701
descriptor.invalid.701:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.700:
  %descriptor.initialized.status.702 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.675, i32 8)
  %helper.ok.703 = icmp eq i32 %descriptor.initialized.status.702, 0
  br i1 %helper.ok.703, label %helper.continue.704, label %frame.failure.0
helper.continue.704:
  %local.is.active.705 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.705, label %local.descriptor.active.706, label %local.descriptor.inactive.707
local.descriptor.active.706:
  %local.check.offset.709 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.710 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.711 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.712 = load i32, ptr %local.owner.end.6, align 4
  %context.field.713 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.714 = load i32, ptr %context.field.713, align 4
  %stack.sub.717 = sub i32 %local.check.owner.end.712, %local.check.offset.709
  %descriptor.owner.inside.715 = icmp ule i32 %local.check.owner.end.712, %context.value.714
  %descriptor.offset.inside.716 = icmp ule i32 %local.check.offset.709, %local.check.owner.end.712
  %descriptor.extent.inside.718 = icmp ule i32 %local.check.extent.710, %stack.sub.717
  %descriptor.payload.inside.719 = icmp ule i32 %local.check.payload.711, %local.check.extent.710
  %descriptor.owner.offset.valid.720 = and i1 %descriptor.owner.inside.715, %descriptor.offset.inside.716
  %descriptor.range.inside.722 = and i1 %descriptor.owner.offset.valid.720, %descriptor.extent.inside.718
  %descriptor.range.valid.721 = and i1 %descriptor.range.inside.722, %descriptor.payload.inside.719
  br i1 %descriptor.range.valid.721, label %descriptor.valid.723, label %descriptor.invalid.724
descriptor.invalid.724:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.723:
  %descriptor.initialized.status.725 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.709, i32 %local.check.extent.710)
  %helper.ok.726 = icmp eq i32 %descriptor.initialized.status.725, 0
  br i1 %helper.ok.726, label %helper.continue.727, label %frame.failure.0
helper.continue.727:
  br label %local.descriptor.checked.708
local.descriptor.inactive.707:
  br label %local.descriptor.checked.708
local.descriptor.checked.708:
  %local.is.active.728 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.728, label %local.descriptor.active.729, label %local.descriptor.inactive.730
local.descriptor.active.729:
  %local.check.offset.732 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.733 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.734 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.735 = load i32, ptr %local.owner.end.12, align 4
  %context.field.736 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.737 = load i32, ptr %context.field.736, align 4
  %stack.sub.740 = sub i32 %local.check.owner.end.735, %local.check.offset.732
  %descriptor.owner.inside.738 = icmp ule i32 %local.check.owner.end.735, %context.value.737
  %descriptor.offset.inside.739 = icmp ule i32 %local.check.offset.732, %local.check.owner.end.735
  %descriptor.extent.inside.741 = icmp ule i32 %local.check.extent.733, %stack.sub.740
  %descriptor.payload.inside.742 = icmp ule i32 %local.check.payload.734, %local.check.extent.733
  %descriptor.owner.offset.valid.743 = and i1 %descriptor.owner.inside.738, %descriptor.offset.inside.739
  %descriptor.range.inside.745 = and i1 %descriptor.owner.offset.valid.743, %descriptor.extent.inside.741
  %descriptor.range.valid.744 = and i1 %descriptor.range.inside.745, %descriptor.payload.inside.742
  br i1 %descriptor.range.valid.744, label %descriptor.valid.746, label %descriptor.invalid.747
descriptor.invalid.747:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.746:
  %descriptor.initialized.status.748 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.732, i32 %local.check.extent.733)
  %helper.ok.749 = icmp eq i32 %descriptor.initialized.status.748, 0
  br i1 %helper.ok.749, label %helper.continue.750, label %frame.failure.0
helper.continue.750:
  br label %local.descriptor.checked.731
local.descriptor.inactive.730:
  br label %local.descriptor.checked.731
local.descriptor.checked.731:
  %step.status.751 = call i32 @al_owning_charge_step(ptr %ctx, i32 20)
  %helper.ok.752 = icmp eq i32 %step.status.751, 0
  br i1 %helper.ok.752, label %helper.continue.753, label %frame.failure.0
helper.continue.753:
  %context.field.754 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.755 = load i32, ptr %context.field.754, align 4
  %stack.offset.756 = add i32 %context.value.755, 8
  %reserve.status.757 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.756, i32 21)
  %reserve.ok.758 = icmp eq i32 %reserve.status.757, 0
  br i1 %reserve.ok.758, label %reserve.continue.759, label %frame.failure.0
reserve.continue.759:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.755, i64 0, i32 1)
  %context.field.760 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.761 = load i32, ptr %context.field.760, align 4
  %runtime.ok.762 = icmp eq i32 %context.value.761, 0
  br i1 %runtime.ok.762, label %runtime.continue.763, label %frame.failure.0
runtime.continue.763:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.764 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.765 = load i32, ptr %context.field.764, align 4
  %runtime.ok.766 = icmp eq i32 %context.value.765, 0
  br i1 %runtime.ok.766, label %runtime.continue.767, label %frame.failure.0
runtime.continue.767:
  %context.field.768 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.769 = load i32, ptr %context.field.768, align 4
  %stack.sub.772 = sub i32 %stack.offset.676, %context.value.675
  %descriptor.owner.inside.770 = icmp ule i32 %stack.offset.676, %context.value.769
  %descriptor.offset.inside.771 = icmp ule i32 %context.value.675, %stack.offset.676
  %descriptor.extent.inside.773 = icmp ule i32 8, %stack.sub.772
  %descriptor.payload.inside.774 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.775 = and i1 %descriptor.owner.inside.770, %descriptor.offset.inside.771
  %descriptor.range.inside.777 = and i1 %descriptor.owner.offset.valid.775, %descriptor.extent.inside.773
  %descriptor.range.valid.776 = and i1 %descriptor.range.inside.777, %descriptor.payload.inside.774
  %descriptor.type.valid.778 = icmp eq i32 1, 1
  %descriptor.valid.779 = and i1 %descriptor.range.valid.776, %descriptor.type.valid.778
  br i1 %descriptor.valid.779, label %descriptor.valid.780, label %descriptor.invalid.781
descriptor.invalid.781:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.780:
  %descriptor.initialized.status.782 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.675, i32 8)
  %helper.ok.783 = icmp eq i32 %descriptor.initialized.status.782, 0
  br i1 %helper.ok.783, label %helper.continue.784, label %frame.failure.0
helper.continue.784:
  %context.field.785 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.786 = load i32, ptr %context.field.785, align 4
  %stack.sub.789 = sub i32 %stack.offset.756, %context.value.755
  %descriptor.owner.inside.787 = icmp ule i32 %stack.offset.756, %context.value.786
  %descriptor.offset.inside.788 = icmp ule i32 %context.value.755, %stack.offset.756
  %descriptor.extent.inside.790 = icmp ule i32 8, %stack.sub.789
  %descriptor.payload.inside.791 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.792 = and i1 %descriptor.owner.inside.787, %descriptor.offset.inside.788
  %descriptor.range.inside.794 = and i1 %descriptor.owner.offset.valid.792, %descriptor.extent.inside.790
  %descriptor.range.valid.793 = and i1 %descriptor.range.inside.794, %descriptor.payload.inside.791
  %descriptor.type.valid.795 = icmp eq i32 1, 1
  %descriptor.valid.796 = and i1 %descriptor.range.valid.793, %descriptor.type.valid.795
  br i1 %descriptor.valid.796, label %descriptor.valid.797, label %descriptor.invalid.798
descriptor.invalid.798:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.797:
  %descriptor.initialized.status.799 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.755, i32 8)
  %helper.ok.800 = icmp eq i32 %descriptor.initialized.status.799, 0
  br i1 %helper.ok.800, label %helper.continue.801, label %frame.failure.0
helper.continue.801:
  %local.is.active.802 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.802, label %local.descriptor.active.803, label %local.descriptor.inactive.804
local.descriptor.active.803:
  %local.check.offset.806 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.807 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.808 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.809 = load i32, ptr %local.owner.end.6, align 4
  %context.field.810 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.811 = load i32, ptr %context.field.810, align 4
  %stack.sub.814 = sub i32 %local.check.owner.end.809, %local.check.offset.806
  %descriptor.owner.inside.812 = icmp ule i32 %local.check.owner.end.809, %context.value.811
  %descriptor.offset.inside.813 = icmp ule i32 %local.check.offset.806, %local.check.owner.end.809
  %descriptor.extent.inside.815 = icmp ule i32 %local.check.extent.807, %stack.sub.814
  %descriptor.payload.inside.816 = icmp ule i32 %local.check.payload.808, %local.check.extent.807
  %descriptor.owner.offset.valid.817 = and i1 %descriptor.owner.inside.812, %descriptor.offset.inside.813
  %descriptor.range.inside.819 = and i1 %descriptor.owner.offset.valid.817, %descriptor.extent.inside.815
  %descriptor.range.valid.818 = and i1 %descriptor.range.inside.819, %descriptor.payload.inside.816
  br i1 %descriptor.range.valid.818, label %descriptor.valid.820, label %descriptor.invalid.821
descriptor.invalid.821:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.820:
  %descriptor.initialized.status.822 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.806, i32 %local.check.extent.807)
  %helper.ok.823 = icmp eq i32 %descriptor.initialized.status.822, 0
  br i1 %helper.ok.823, label %helper.continue.824, label %frame.failure.0
helper.continue.824:
  br label %local.descriptor.checked.805
local.descriptor.inactive.804:
  br label %local.descriptor.checked.805
local.descriptor.checked.805:
  %local.is.active.825 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.825, label %local.descriptor.active.826, label %local.descriptor.inactive.827
local.descriptor.active.826:
  %local.check.offset.829 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.830 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.831 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.832 = load i32, ptr %local.owner.end.12, align 4
  %context.field.833 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.834 = load i32, ptr %context.field.833, align 4
  %stack.sub.837 = sub i32 %local.check.owner.end.832, %local.check.offset.829
  %descriptor.owner.inside.835 = icmp ule i32 %local.check.owner.end.832, %context.value.834
  %descriptor.offset.inside.836 = icmp ule i32 %local.check.offset.829, %local.check.owner.end.832
  %descriptor.extent.inside.838 = icmp ule i32 %local.check.extent.830, %stack.sub.837
  %descriptor.payload.inside.839 = icmp ule i32 %local.check.payload.831, %local.check.extent.830
  %descriptor.owner.offset.valid.840 = and i1 %descriptor.owner.inside.835, %descriptor.offset.inside.836
  %descriptor.range.inside.842 = and i1 %descriptor.owner.offset.valid.840, %descriptor.extent.inside.838
  %descriptor.range.valid.841 = and i1 %descriptor.range.inside.842, %descriptor.payload.inside.839
  br i1 %descriptor.range.valid.841, label %descriptor.valid.843, label %descriptor.invalid.844
descriptor.invalid.844:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.843:
  %descriptor.initialized.status.845 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.829, i32 %local.check.extent.830)
  %helper.ok.846 = icmp eq i32 %descriptor.initialized.status.845, 0
  br i1 %helper.ok.846, label %helper.continue.847, label %frame.failure.0
helper.continue.847:
  br label %local.descriptor.checked.828
local.descriptor.inactive.827:
  br label %local.descriptor.checked.828
local.descriptor.checked.828:
  %step.status.848 = call i32 @al_owning_charge_step(ptr %ctx, i32 22)
  %helper.ok.849 = icmp eq i32 %step.status.848, 0
  br i1 %helper.ok.849, label %helper.continue.850, label %frame.failure.0
helper.continue.850:
  %integer.left.851 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.675)
  %context.field.853 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.854 = load i32, ptr %context.field.853, align 4
  %runtime.ok.855 = icmp eq i32 %context.value.854, 0
  br i1 %runtime.ok.855, label %runtime.continue.856, label %frame.failure.0
runtime.continue.856:
  %integer.right.852 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.755)
  %context.field.857 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.858 = load i32, ptr %context.field.857, align 4
  %runtime.ok.859 = icmp eq i32 %context.value.858, 0
  br i1 %runtime.ok.859, label %runtime.continue.860, label %frame.failure.0
runtime.continue.860:
  %divide.zero.861 = icmp eq i64 %integer.right.852, 0
  br i1 %divide.zero.861, label %divide.zero.862, label %divide.nonzero.863
divide.zero.862:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 23, i32 0, i32 0)
  br label %frame.failure.0
divide.nonzero.863:
  %divide.min.864 = icmp eq i64 %integer.left.851, -9223372036854775808
  %divide.minusone.865 = icmp eq i64 %integer.right.852, -1
  %divide.overflow.866 = and i1 %divide.min.864, %divide.minusone.865
  br i1 %divide.overflow.866, label %divide.overflow.867, label %divide.valid.868
divide.overflow.867:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 24, i32 0, i32 0)
  br label %frame.failure.0
divide.valid.868:
  %divide.result.869 = sdiv i64 %integer.left.851, %integer.right.852
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.755, i32 8, i32 8, i32 0, i32 0)
  %context.field.870 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.871 = load i32, ptr %context.field.870, align 4
  %runtime.ok.872 = icmp eq i32 %context.value.871, 0
  br i1 %runtime.ok.872, label %runtime.continue.873, label %frame.failure.0
runtime.continue.873:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.675, i32 8, i32 8, i32 0, i32 0)
  %context.field.874 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.875 = load i32, ptr %context.field.874, align 4
  %runtime.ok.876 = icmp eq i32 %context.value.875, 0
  br i1 %runtime.ok.876, label %runtime.continue.877, label %frame.failure.0
runtime.continue.877:
  %context.field.878 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.879 = load i32, ptr %context.field.878, align 4
  %stack.offset.880 = add i32 %context.value.879, 8
  %reserve.status.881 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.880, i32 25)
  %reserve.ok.882 = icmp eq i32 %reserve.status.881, 0
  br i1 %reserve.ok.882, label %reserve.continue.883, label %frame.failure.0
reserve.continue.883:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.879, i64 %divide.result.869, i32 1)
  %context.field.884 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.885 = load i32, ptr %context.field.884, align 4
  %runtime.ok.886 = icmp eq i32 %context.value.885, 0
  br i1 %runtime.ok.886, label %runtime.continue.887, label %frame.failure.0
runtime.continue.887:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.888 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.889 = load i32, ptr %context.field.888, align 4
  %runtime.ok.890 = icmp eq i32 %context.value.889, 0
  br i1 %runtime.ok.890, label %runtime.continue.891, label %frame.failure.0
runtime.continue.891:
  %stack.offset.892 = add i32 %context.value.879, 8
  %context.field.893 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.894 = load i32, ptr %context.field.893, align 4
  %stack.sub.897 = sub i32 %stack.offset.892, %context.value.879
  %descriptor.owner.inside.895 = icmp ule i32 %stack.offset.892, %context.value.894
  %descriptor.offset.inside.896 = icmp ule i32 %context.value.879, %stack.offset.892
  %descriptor.extent.inside.898 = icmp ule i32 8, %stack.sub.897
  %descriptor.payload.inside.899 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.900 = and i1 %descriptor.owner.inside.895, %descriptor.offset.inside.896
  %descriptor.range.inside.902 = and i1 %descriptor.owner.offset.valid.900, %descriptor.extent.inside.898
  %descriptor.range.valid.901 = and i1 %descriptor.range.inside.902, %descriptor.payload.inside.899
  %descriptor.type.valid.903 = icmp eq i32 1, 1
  %descriptor.valid.904 = and i1 %descriptor.range.valid.901, %descriptor.type.valid.903
  br i1 %descriptor.valid.904, label %descriptor.valid.905, label %descriptor.invalid.906
descriptor.invalid.906:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.905:
  %descriptor.initialized.status.907 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.879, i32 8)
  %helper.ok.908 = icmp eq i32 %descriptor.initialized.status.907, 0
  br i1 %helper.ok.908, label %helper.continue.909, label %frame.failure.0
helper.continue.909:
  %local.is.active.910 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.910, label %local.descriptor.active.911, label %local.descriptor.inactive.912
local.descriptor.active.911:
  %local.check.offset.914 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.915 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.916 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.917 = load i32, ptr %local.owner.end.6, align 4
  %context.field.918 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.919 = load i32, ptr %context.field.918, align 4
  %stack.sub.922 = sub i32 %local.check.owner.end.917, %local.check.offset.914
  %descriptor.owner.inside.920 = icmp ule i32 %local.check.owner.end.917, %context.value.919
  %descriptor.offset.inside.921 = icmp ule i32 %local.check.offset.914, %local.check.owner.end.917
  %descriptor.extent.inside.923 = icmp ule i32 %local.check.extent.915, %stack.sub.922
  %descriptor.payload.inside.924 = icmp ule i32 %local.check.payload.916, %local.check.extent.915
  %descriptor.owner.offset.valid.925 = and i1 %descriptor.owner.inside.920, %descriptor.offset.inside.921
  %descriptor.range.inside.927 = and i1 %descriptor.owner.offset.valid.925, %descriptor.extent.inside.923
  %descriptor.range.valid.926 = and i1 %descriptor.range.inside.927, %descriptor.payload.inside.924
  br i1 %descriptor.range.valid.926, label %descriptor.valid.928, label %descriptor.invalid.929
descriptor.invalid.929:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.928:
  %descriptor.initialized.status.930 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.914, i32 %local.check.extent.915)
  %helper.ok.931 = icmp eq i32 %descriptor.initialized.status.930, 0
  br i1 %helper.ok.931, label %helper.continue.932, label %frame.failure.0
helper.continue.932:
  br label %local.descriptor.checked.913
local.descriptor.inactive.912:
  br label %local.descriptor.checked.913
local.descriptor.checked.913:
  %local.is.active.933 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.933, label %local.descriptor.active.934, label %local.descriptor.inactive.935
local.descriptor.active.934:
  %local.check.offset.937 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.938 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.939 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.940 = load i32, ptr %local.owner.end.12, align 4
  %context.field.941 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.942 = load i32, ptr %context.field.941, align 4
  %stack.sub.945 = sub i32 %local.check.owner.end.940, %local.check.offset.937
  %descriptor.owner.inside.943 = icmp ule i32 %local.check.owner.end.940, %context.value.942
  %descriptor.offset.inside.944 = icmp ule i32 %local.check.offset.937, %local.check.owner.end.940
  %descriptor.extent.inside.946 = icmp ule i32 %local.check.extent.938, %stack.sub.945
  %descriptor.payload.inside.947 = icmp ule i32 %local.check.payload.939, %local.check.extent.938
  %descriptor.owner.offset.valid.948 = and i1 %descriptor.owner.inside.943, %descriptor.offset.inside.944
  %descriptor.range.inside.950 = and i1 %descriptor.owner.offset.valid.948, %descriptor.extent.inside.946
  %descriptor.range.valid.949 = and i1 %descriptor.range.inside.950, %descriptor.payload.inside.947
  br i1 %descriptor.range.valid.949, label %descriptor.valid.951, label %descriptor.invalid.952
descriptor.invalid.952:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.951:
  %descriptor.initialized.status.953 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.937, i32 %local.check.extent.938)
  %helper.ok.954 = icmp eq i32 %descriptor.initialized.status.953, 0
  br i1 %helper.ok.954, label %helper.continue.955, label %frame.failure.0
helper.continue.955:
  br label %local.descriptor.checked.936
local.descriptor.inactive.935:
  br label %local.descriptor.checked.936
local.descriptor.checked.936:
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %descriptor.element.956 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.957 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.956, i32 0, i32 0
  store i32 1, ptr %descriptor.field.957, align 4
  %descriptor.field.958 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.956, i32 0, i32 1
  store i32 %context.value.879, ptr %descriptor.field.958, align 4
  %descriptor.field.959 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.956, i32 0, i32 2
  store i32 8, ptr %descriptor.field.959, align 4
  %descriptor.field.960 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.956, i32 0, i32 3
  store i32 8, ptr %descriptor.field.960, align 4
  %descriptor.field.961 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.956, i32 0, i32 4
  store i32 %stack.offset.892, ptr %descriptor.field.961, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %context.value.879, i32 20, i32 8, i32 %stack.offset.892, i32 8)
  %context.field.962 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.963 = load i32, ptr %context.field.962, align 4
  %runtime.ok.964 = icmp eq i32 %context.value.963, 0
  br i1 %runtime.ok.964, label %runtime.continue.965, label %frame.failure.0
runtime.continue.965:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.15, i32 0, i32 0, i32 0)
  %context.field.966 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.967 = load i32, ptr %context.field.966, align 4
  %context.field.968 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.969 = load i32, ptr %context.field.968, align 4
  %context.field.970 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.971 = load i32, ptr %context.field.970, align 4
  %stack.offset.972 = add i32 %context.value.17, %context.value.19
  %stack.offset.973 = add i32 %context.value.967, %context.value.969
  %stack.sub.974 = sub i32 %stack.offset.972, %stack.offset.973
  %stack.sub.975 = sub i32 %context.value.19, %context.value.969
  %stack.sub.976 = sub i32 %context.value.971, %context.value.21
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.974, i32 %stack.sub.975)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.976)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 1
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %entry.input.descriptors.10 = alloca [1 x %AlOwningDescriptor], align 4
  %input.extent.pointer.11 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.12 = load i32, ptr %input.extent.pointer.11, align 4
  %host.pointer.13 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.14 = alloca i32, align 4
  %input.measured.extent.pointer.15 = alloca i32, align 4
  %input.measure.status.16 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 3, ptr %host.pointer.13, i32 %input.host.extent.12, i32 0, i32 26, ptr %input.payload.pointer.14, ptr %input.measured.extent.pointer.15)
  %helper.ok.17 = icmp eq i32 %input.measure.status.16, 0
  br i1 %helper.ok.17, label %helper.continue.18, label %entry.failure.0
helper.continue.18:
  %input.measured.payload.19 = load i32, ptr %input.payload.pointer.14, align 4
  %input.measured.extent.20 = load i32, ptr %input.measured.extent.pointer.15, align 4
  %input.extent.exact.21 = icmp eq i32 %input.measured.extent.20, %input.host.extent.12
  br i1 %input.extent.exact.21, label %input.extent.exact.22, label %input.extent.invalid.23
input.extent.invalid.23:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 26, i32 %input.measured.extent.20, i32 %input.host.extent.12)
  br label %entry.failure.0
input.extent.exact.22:
  %stack.offset.24 = add i32 0, %input.host.extent.12
  %input.total.exact.25 = icmp eq i32 %stack.offset.24, %input.bytes
  br i1 %input.total.exact.25, label %input.valid.26, label %input.invalid.27
input.invalid.27:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.24, i32 %input.bytes)
  br label %entry.failure.0
input.valid.26:
  %reserve.status.28 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.24, i32 27)
  %reserve.ok.29 = icmp eq i32 %reserve.status.28, 0
  br i1 %reserve.ok.29, label %reserve.continue.30, label %entry.failure.0
reserve.continue.30:
  %host.pointer.31 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.32 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.31, i32 %input.host.extent.12, i32 0, i32 %input.measured.payload.19, i32 %input.host.extent.12, i32 11, i32 28)
  %helper.ok.33 = icmp eq i32 %input.copy.status.32, 0
  br i1 %helper.ok.33, label %helper.continue.34, label %entry.failure.0
helper.continue.34:
  %stack.offset.35 = add i32 0, %input.host.extent.12
  %descriptor.element.36 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.10, i32 0
  %descriptor.field.37 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.36, i32 0, i32 0
  store i32 11, ptr %descriptor.field.37, align 4
  %descriptor.field.38 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.36, i32 0, i32 1
  store i32 0, ptr %descriptor.field.38, align 4
  %descriptor.field.39 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.36, i32 0, i32 2
  store i32 %input.host.extent.12, ptr %descriptor.field.39, align 4
  %descriptor.field.40 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.36, i32 0, i32 3
  store i32 %input.measured.payload.19, ptr %descriptor.field.40, align 4
  %descriptor.field.41 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.36, i32 0, i32 4
  store i32 %stack.offset.35, ptr %descriptor.field.41, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 11, i32 0, i32 20, i32 %input.measured.payload.19, i32 %stack.offset.35, i32 %input.host.extent.12)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %entry.failure.0
runtime.continue.45:
  %entry.output.descriptors.46 = alloca [1 x %AlOwningDescriptor], align 4
  %entry.body.status.47 = call i32 @agentlang_entry_frame(ptr %ctx, ptr %entry.input.descriptors.10, ptr %entry.output.descriptors.46, i32 29)
  %entry.body.ok.48 = icmp eq i32 %entry.body.status.47, 0
  br i1 %entry.body.ok.48, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.49 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.46, i32 0
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 0
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 1
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %descriptor.field.54 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 2
  %descriptor.value.55 = load i32, ptr %descriptor.field.54, align 4
  %descriptor.field.56 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 3
  %descriptor.value.57 = load i32, ptr %descriptor.field.56, align 4
  %descriptor.field.58 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 4
  %descriptor.value.59 = load i32, ptr %descriptor.field.58, align 4
  %entry.output.type.valid.60 = icmp eq i32 %descriptor.value.51, 1
  br i1 %entry.output.type.valid.60, label %entry.output.type.ok.61, label %entry.output.type.invalid.62
entry.output.type.invalid.62:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.61:
  %context.field.63 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.64 = load i32, ptr %context.field.63, align 4
  %stack.sub.67 = sub i32 %descriptor.value.59, %descriptor.value.53
  %descriptor.owner.inside.65 = icmp ule i32 %descriptor.value.59, %context.value.64
  %descriptor.offset.inside.66 = icmp ule i32 %descriptor.value.53, %descriptor.value.59
  %descriptor.extent.inside.68 = icmp ule i32 %descriptor.value.55, %stack.sub.67
  %descriptor.payload.inside.69 = icmp ule i32 %descriptor.value.57, %descriptor.value.55
  %descriptor.owner.offset.valid.70 = and i1 %descriptor.owner.inside.65, %descriptor.offset.inside.66
  %descriptor.range.inside.72 = and i1 %descriptor.owner.offset.valid.70, %descriptor.extent.inside.68
  %descriptor.range.valid.71 = and i1 %descriptor.range.inside.72, %descriptor.payload.inside.69
  %descriptor.type.valid.73 = icmp eq i32 1, 1
  %descriptor.valid.74 = and i1 %descriptor.range.valid.71, %descriptor.type.valid.73
  br i1 %descriptor.valid.74, label %descriptor.valid.75, label %descriptor.invalid.76
descriptor.invalid.76:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.75:
  %descriptor.initialized.status.77 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.53, i32 %descriptor.value.55)
  %helper.ok.78 = icmp eq i32 %descriptor.initialized.status.77, 0
  br i1 %helper.ok.78, label %helper.continue.79, label %entry.failure.0
helper.continue.79:
  %entry.output.size.i64.80 = zext i32 %descriptor.value.55 to i64
  %entry.output.total.i64.81 = add i64 0, %entry.output.size.i64.80
  %entry.retained.capacity.i64.82 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.83 = icmp ule i64 %entry.output.total.i64.81, 4294967295
  %entry.retained.required.truncated.84 = trunc i64 %entry.output.total.i64.81 to i32
  %entry.retained.required.85 = select i1 %entry.retained.required.fits.u32.83, i32 %entry.retained.required.truncated.84, i32 4294967295
  %entry.retained.capacity.ok.86 = icmp ule i64 %entry.output.total.i64.81, %entry.retained.capacity.i64.82
  br i1 %entry.retained.capacity.ok.86, label %entry.retained.capacity.ready.87, label %entry.retained.capacity.failure.88
entry.retained.capacity.failure.88:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.85, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.87:
  %host.pointer.89 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.90 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.89, i32 %stack.sub.90, i32 %descriptor.value.53, i32 %descriptor.value.55, i32 1)
  %context.field.91 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.92 = load i32, ptr %context.field.91, align 4
  %runtime.ok.93 = icmp eq i32 %context.value.92, 0
  br i1 %runtime.ok.93, label %runtime.continue.94, label %entry.failure.0
runtime.continue.94:
  %stack.offset.95 = add i32 0, %descriptor.value.55
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %stack.sub.100 = sub i32 0, %context.value.97
  %stack.sub.101 = sub i32 0, %context.value.99
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.100, i32 %stack.sub.101)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %entry.failure.0
runtime.continue.105:
  br label %entry.return.status
entry.failure.0:
  %context.field.106 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.107 = load i32, ptr %context.field.106, align 4
  %context.field.108 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.109 = load i32, ptr %context.field.108, align 4
  %context.field.110 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.111 = load i32, ptr %context.field.110, align 4
  %stack.offset.112 = add i32 %context.value.107, %context.value.109
  %stack.sub.113 = sub i32 0, %stack.offset.112
  %stack.sub.114 = sub i32 0, %context.value.109
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.113, i32 %stack.sub.114)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.111)
  br label %entry.return.status
entry.return.status:
  %context.field.115 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.116 = load i32, ptr %context.field.115, align 4
  ret i32 %context.value.116
}


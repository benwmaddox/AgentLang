%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [1 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 5, i32 12, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8 }], align 4
@al_owning_fields = private constant [1 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 0, i32 0, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 1, ptr @al_owning_types, i32 1, ptr @al_owning_fields, i32 0 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 12
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 12, 12
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %step.status.43 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.44 = icmp eq i32 %step.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %frame.failure.0
helper.continue.45:
  %context.field.46 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.47 = load i32, ptr %context.field.46, align 4
  %step.status.48 = call i32 @al_owning_charge_step(ptr %ctx, i32 2)
  %helper.ok.49 = icmp eq i32 %step.status.48, 0
  br i1 %helper.ok.49, label %helper.continue.50, label %frame.failure.0
helper.continue.50:
  %call.arguments.51 = alloca [1 x %AlOwningDescriptor], align 4
  %descriptor.element.52 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.51, i32 0
  %descriptor.field.53 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.52, i32 0, i32 0
  store i32 12, ptr %descriptor.field.53, align 4
  %descriptor.field.54 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.52, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.54, align 4
  %descriptor.field.55 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.52, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.55, align 4
  %descriptor.field.56 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.52, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.56, align 4
  %descriptor.field.57 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.52, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.57, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.58 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.59 = load i32, ptr %context.field.58, align 4
  %runtime.ok.60 = icmp eq i32 %context.value.59, 0
  br i1 %runtime.ok.60, label %runtime.continue.61, label %frame.failure.0
runtime.continue.61:
  %call.results.62 = alloca [1 x %AlOwningDescriptor], align 4
  %callee.status.63 = call i32 @agentlang_word_0000(ptr %ctx, ptr %call.arguments.51, ptr %call.results.62, i32 3)
  %helper.ok.64 = icmp eq i32 %callee.status.63, 0
  br i1 %helper.ok.64, label %helper.continue.65, label %frame.failure.0
helper.continue.65:
  %descriptor.element.66 = getelementptr inbounds %AlOwningDescriptor, ptr %call.results.62, i32 0
  %descriptor.field.67 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.66, i32 0, i32 0
  %descriptor.value.68 = load i32, ptr %descriptor.field.67, align 4
  %descriptor.field.69 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.66, i32 0, i32 1
  %descriptor.value.70 = load i32, ptr %descriptor.field.69, align 4
  %descriptor.field.71 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.66, i32 0, i32 2
  %descriptor.value.72 = load i32, ptr %descriptor.field.71, align 4
  %descriptor.field.73 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.66, i32 0, i32 3
  %descriptor.value.74 = load i32, ptr %descriptor.field.73, align 4
  %descriptor.field.75 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.66, i32 0, i32 4
  %descriptor.value.76 = load i32, ptr %descriptor.field.75, align 4
  %callee.result.type.valid.77 = icmp eq i32 %descriptor.value.68, 12
  br i1 %callee.result.type.valid.77, label %callee.result.type.ok.78, label %frame.failure.0
callee.result.type.ok.78:
  %context.field.79 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.80 = load i32, ptr %context.field.79, align 4
  %stack.sub.83 = sub i32 %descriptor.value.76, %descriptor.value.70
  %descriptor.owner.inside.81 = icmp ule i32 %descriptor.value.76, %context.value.80
  %descriptor.offset.inside.82 = icmp ule i32 %descriptor.value.70, %descriptor.value.76
  %descriptor.extent.inside.84 = icmp ule i32 %descriptor.value.72, %stack.sub.83
  %descriptor.payload.inside.85 = icmp ule i32 %descriptor.value.74, %descriptor.value.72
  %descriptor.owner.offset.valid.86 = and i1 %descriptor.owner.inside.81, %descriptor.offset.inside.82
  %descriptor.range.inside.88 = and i1 %descriptor.owner.offset.valid.86, %descriptor.extent.inside.84
  %descriptor.range.valid.87 = and i1 %descriptor.range.inside.88, %descriptor.payload.inside.85
  %descriptor.type.valid.89 = icmp eq i32 12, 12
  %descriptor.valid.90 = and i1 %descriptor.range.valid.87, %descriptor.type.valid.89
  br i1 %descriptor.valid.90, label %descriptor.valid.91, label %descriptor.invalid.92
descriptor.invalid.92:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.91:
  %descriptor.initialized.status.93 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.70, i32 %descriptor.value.72)
  %helper.ok.94 = icmp eq i32 %descriptor.initialized.status.93, 0
  br i1 %helper.ok.94, label %helper.continue.95, label %frame.failure.0
helper.continue.95:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %descriptor.value.70, i32 20, i32 %descriptor.value.74, i32 %descriptor.value.76, i32 %descriptor.value.72)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %runtime.ok.98 = icmp eq i32 %context.value.97, 0
  br i1 %runtime.ok.98, label %runtime.continue.99, label %frame.failure.0
runtime.continue.99:
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %stack.sub.104 = sub i32 %descriptor.value.76, %descriptor.value.70
  %descriptor.owner.inside.102 = icmp ule i32 %descriptor.value.76, %context.value.101
  %descriptor.offset.inside.103 = icmp ule i32 %descriptor.value.70, %descriptor.value.76
  %descriptor.extent.inside.105 = icmp ule i32 %descriptor.value.72, %stack.sub.104
  %descriptor.payload.inside.106 = icmp ule i32 %descriptor.value.74, %descriptor.value.72
  %descriptor.owner.offset.valid.107 = and i1 %descriptor.owner.inside.102, %descriptor.offset.inside.103
  %descriptor.range.inside.109 = and i1 %descriptor.owner.offset.valid.107, %descriptor.extent.inside.105
  %descriptor.range.valid.108 = and i1 %descriptor.range.inside.109, %descriptor.payload.inside.106
  %descriptor.type.valid.110 = icmp eq i32 12, 12
  %descriptor.valid.111 = and i1 %descriptor.range.valid.108, %descriptor.type.valid.110
  br i1 %descriptor.valid.111, label %descriptor.valid.112, label %descriptor.invalid.113
descriptor.invalid.113:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.112:
  %descriptor.initialized.status.114 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.70, i32 %descriptor.value.72)
  %helper.ok.115 = icmp eq i32 %descriptor.initialized.status.114, 0
  br i1 %helper.ok.115, label %helper.continue.116, label %frame.failure.0
helper.continue.116:
  %context.field.117 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.118 = load i32, ptr %context.field.117, align 4
  %stack.sub.121 = sub i32 %descriptor.value.76, %descriptor.value.70
  %descriptor.owner.inside.119 = icmp ule i32 %descriptor.value.76, %context.value.118
  %descriptor.offset.inside.120 = icmp ule i32 %descriptor.value.70, %descriptor.value.76
  %descriptor.extent.inside.122 = icmp ule i32 %descriptor.value.72, %stack.sub.121
  %descriptor.payload.inside.123 = icmp ule i32 %descriptor.value.74, %descriptor.value.72
  %descriptor.owner.offset.valid.124 = and i1 %descriptor.owner.inside.119, %descriptor.offset.inside.120
  %descriptor.range.inside.126 = and i1 %descriptor.owner.offset.valid.124, %descriptor.extent.inside.122
  %descriptor.range.valid.125 = and i1 %descriptor.range.inside.126, %descriptor.payload.inside.123
  %descriptor.type.valid.127 = icmp eq i32 12, 12
  %descriptor.valid.128 = and i1 %descriptor.range.valid.125, %descriptor.type.valid.127
  br i1 %descriptor.valid.128, label %descriptor.valid.129, label %descriptor.invalid.130
descriptor.invalid.130:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.129:
  %descriptor.initialized.status.131 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.70, i32 %descriptor.value.72)
  %helper.ok.132 = icmp eq i32 %descriptor.initialized.status.131, 0
  br i1 %helper.ok.132, label %helper.continue.133, label %frame.failure.0
helper.continue.133:
  %descriptor.element.134 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.135 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.134, i32 0, i32 0
  store i32 12, ptr %descriptor.field.135, align 4
  %descriptor.field.136 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.134, i32 0, i32 1
  store i32 %descriptor.value.70, ptr %descriptor.field.136, align 4
  %descriptor.field.137 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.134, i32 0, i32 2
  store i32 %descriptor.value.72, ptr %descriptor.field.137, align 4
  %descriptor.field.138 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.134, i32 0, i32 3
  store i32 %descriptor.value.74, ptr %descriptor.field.138, align 4
  %descriptor.field.139 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.134, i32 0, i32 4
  store i32 %descriptor.value.76, ptr %descriptor.field.139, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %descriptor.value.70, i32 20, i32 %descriptor.value.74, i32 %descriptor.value.76, i32 %descriptor.value.72)
  %context.field.140 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.141 = load i32, ptr %context.field.140, align 4
  %runtime.ok.142 = icmp eq i32 %context.value.141, 0
  br i1 %runtime.ok.142, label %runtime.continue.143, label %frame.failure.0
runtime.continue.143:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.144 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.145 = load i32, ptr %context.field.144, align 4
  %context.field.146 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.147 = load i32, ptr %context.field.146, align 4
  %context.field.148 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.149 = load i32, ptr %context.field.148, align 4
  %stack.offset.150 = add i32 %context.value.5, %context.value.7
  %stack.offset.151 = add i32 %context.value.145, %context.value.147
  %stack.sub.152 = sub i32 %stack.offset.150, %stack.offset.151
  %stack.sub.153 = sub i32 %context.value.7, %context.value.147
  %stack.sub.154 = sub i32 %context.value.149, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.152, i32 %stack.sub.153)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.154)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 12
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 12, 12
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %context.field.43 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.44 = load i32, ptr %context.field.43, align 4
  %stack.sub.45 = sub i32 %context.value.44, %context.value.3
  call void @al_owning_record_layout(ptr %ctx, i32 18, i32 0, i32 %context.value.3, i32 %stack.sub.45, i32 0, i32 0, i32 0)
  %context.field.46 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.47 = load i32, ptr %context.field.46, align 4
  %runtime.ok.48 = icmp eq i32 %context.value.47, 0
  br i1 %runtime.ok.48, label %runtime.continue.49, label %frame.failure.0
runtime.continue.49:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.50 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.51 = load i32, ptr %context.field.50, align 4
  %runtime.ok.52 = icmp eq i32 %context.value.51, 0
  br i1 %runtime.ok.52, label %runtime.continue.53, label %frame.failure.0
runtime.continue.53:
  %descriptor.element.54 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.55 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.54, i32 0, i32 0
  store i32 12, ptr %descriptor.field.55, align 4
  %descriptor.field.56 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.54, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.56, align 4
  %descriptor.field.57 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.54, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.57, align 4
  %descriptor.field.58 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.54, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.58, align 4
  %descriptor.field.59 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.54, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.59, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.60 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.61 = load i32, ptr %context.field.60, align 4
  %runtime.ok.62 = icmp eq i32 %context.value.61, 0
  br i1 %runtime.ok.62, label %runtime.continue.63, label %frame.failure.0
runtime.continue.63:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.64 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.65 = load i32, ptr %context.field.64, align 4
  %context.field.66 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.67 = load i32, ptr %context.field.66, align 4
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %stack.offset.70 = add i32 %context.value.5, %context.value.7
  %stack.offset.71 = add i32 %context.value.65, %context.value.67
  %stack.sub.72 = sub i32 %stack.offset.70, %stack.offset.71
  %stack.sub.73 = sub i32 %context.value.7, %context.value.67
  %stack.sub.74 = sub i32 %context.value.69, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.72, i32 %stack.sub.73)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.74)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 1
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %entry.input.descriptors.10 = alloca [1 x %AlOwningDescriptor], align 4
  %input.extent.pointer.11 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.12 = load i32, ptr %input.extent.pointer.11, align 4
  %host.pointer.13 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.14 = alloca i32, align 4
  %input.measured.extent.pointer.15 = alloca i32, align 4
  %input.measure.status.16 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 0, ptr %host.pointer.13, i32 %input.host.extent.12, i32 0, i32 4, ptr %input.payload.pointer.14, ptr %input.measured.extent.pointer.15)
  %helper.ok.17 = icmp eq i32 %input.measure.status.16, 0
  br i1 %helper.ok.17, label %helper.continue.18, label %entry.failure.0
helper.continue.18:
  %input.measured.payload.19 = load i32, ptr %input.payload.pointer.14, align 4
  %input.measured.extent.20 = load i32, ptr %input.measured.extent.pointer.15, align 4
  %input.extent.exact.21 = icmp eq i32 %input.measured.extent.20, %input.host.extent.12
  br i1 %input.extent.exact.21, label %input.extent.exact.22, label %input.extent.invalid.23
input.extent.invalid.23:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 4, i32 %input.measured.extent.20, i32 %input.host.extent.12)
  br label %entry.failure.0
input.extent.exact.22:
  %stack.offset.24 = add i32 0, %input.host.extent.12
  %input.total.exact.25 = icmp eq i32 %stack.offset.24, %input.bytes
  br i1 %input.total.exact.25, label %input.valid.26, label %input.invalid.27
input.invalid.27:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.24, i32 %input.bytes)
  br label %entry.failure.0
input.valid.26:
  %reserve.status.28 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.24, i32 5)
  %reserve.ok.29 = icmp eq i32 %reserve.status.28, 0
  br i1 %reserve.ok.29, label %reserve.continue.30, label %entry.failure.0
reserve.continue.30:
  %host.pointer.31 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.32 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.31, i32 %input.host.extent.12, i32 0, i32 %input.measured.payload.19, i32 %input.host.extent.12, i32 12, i32 6)
  %helper.ok.33 = icmp eq i32 %input.copy.status.32, 0
  br i1 %helper.ok.33, label %helper.continue.34, label %entry.failure.0
helper.continue.34:
  %stack.offset.35 = add i32 0, %input.host.extent.12
  %descriptor.element.36 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.10, i32 0
  %descriptor.field.37 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.36, i32 0, i32 0
  store i32 12, ptr %descriptor.field.37, align 4
  %descriptor.field.38 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.36, i32 0, i32 1
  store i32 0, ptr %descriptor.field.38, align 4
  %descriptor.field.39 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.36, i32 0, i32 2
  store i32 %input.host.extent.12, ptr %descriptor.field.39, align 4
  %descriptor.field.40 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.36, i32 0, i32 3
  store i32 %input.measured.payload.19, ptr %descriptor.field.40, align 4
  %descriptor.field.41 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.36, i32 0, i32 4
  store i32 %stack.offset.35, ptr %descriptor.field.41, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 0, i32 20, i32 %input.measured.payload.19, i32 %stack.offset.35, i32 %input.host.extent.12)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %entry.failure.0
runtime.continue.45:
  %entry.output.descriptors.46 = alloca [1 x %AlOwningDescriptor], align 4
  %entry.body.status.47 = call i32 @agentlang_entry_frame(ptr %ctx, ptr %entry.input.descriptors.10, ptr %entry.output.descriptors.46, i32 7)
  %entry.body.ok.48 = icmp eq i32 %entry.body.status.47, 0
  br i1 %entry.body.ok.48, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.49 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.46, i32 0
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 0
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 1
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %descriptor.field.54 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 2
  %descriptor.value.55 = load i32, ptr %descriptor.field.54, align 4
  %descriptor.field.56 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 3
  %descriptor.value.57 = load i32, ptr %descriptor.field.56, align 4
  %descriptor.field.58 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 4
  %descriptor.value.59 = load i32, ptr %descriptor.field.58, align 4
  %entry.output.type.valid.60 = icmp eq i32 %descriptor.value.51, 12
  br i1 %entry.output.type.valid.60, label %entry.output.type.ok.61, label %entry.output.type.invalid.62
entry.output.type.invalid.62:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.61:
  %context.field.63 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.64 = load i32, ptr %context.field.63, align 4
  %stack.sub.67 = sub i32 %descriptor.value.59, %descriptor.value.53
  %descriptor.owner.inside.65 = icmp ule i32 %descriptor.value.59, %context.value.64
  %descriptor.offset.inside.66 = icmp ule i32 %descriptor.value.53, %descriptor.value.59
  %descriptor.extent.inside.68 = icmp ule i32 %descriptor.value.55, %stack.sub.67
  %descriptor.payload.inside.69 = icmp ule i32 %descriptor.value.57, %descriptor.value.55
  %descriptor.owner.offset.valid.70 = and i1 %descriptor.owner.inside.65, %descriptor.offset.inside.66
  %descriptor.range.inside.72 = and i1 %descriptor.owner.offset.valid.70, %descriptor.extent.inside.68
  %descriptor.range.valid.71 = and i1 %descriptor.range.inside.72, %descriptor.payload.inside.69
  %descriptor.type.valid.73 = icmp eq i32 12, 12
  %descriptor.valid.74 = and i1 %descriptor.range.valid.71, %descriptor.type.valid.73
  br i1 %descriptor.valid.74, label %descriptor.valid.75, label %descriptor.invalid.76
descriptor.invalid.76:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.75:
  %descriptor.initialized.status.77 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.53, i32 %descriptor.value.55)
  %helper.ok.78 = icmp eq i32 %descriptor.initialized.status.77, 0
  br i1 %helper.ok.78, label %helper.continue.79, label %entry.failure.0
helper.continue.79:
  %entry.output.size.i64.80 = zext i32 %descriptor.value.55 to i64
  %entry.output.total.i64.81 = add i64 0, %entry.output.size.i64.80
  %entry.retained.capacity.i64.82 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.83 = icmp ule i64 %entry.output.total.i64.81, 4294967295
  %entry.retained.required.truncated.84 = trunc i64 %entry.output.total.i64.81 to i32
  %entry.retained.required.85 = select i1 %entry.retained.required.fits.u32.83, i32 %entry.retained.required.truncated.84, i32 4294967295
  %entry.retained.capacity.ok.86 = icmp ule i64 %entry.output.total.i64.81, %entry.retained.capacity.i64.82
  br i1 %entry.retained.capacity.ok.86, label %entry.retained.capacity.ready.87, label %entry.retained.capacity.failure.88
entry.retained.capacity.failure.88:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.85, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.87:
  %host.pointer.89 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.90 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.89, i32 %stack.sub.90, i32 %descriptor.value.53, i32 %descriptor.value.55, i32 12)
  %context.field.91 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.92 = load i32, ptr %context.field.91, align 4
  %runtime.ok.93 = icmp eq i32 %context.value.92, 0
  br i1 %runtime.ok.93, label %runtime.continue.94, label %entry.failure.0
runtime.continue.94:
  %stack.offset.95 = add i32 0, %descriptor.value.55
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %stack.sub.100 = sub i32 0, %context.value.97
  %stack.sub.101 = sub i32 0, %context.value.99
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.100, i32 %stack.sub.101)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %entry.failure.0
runtime.continue.105:
  br label %entry.return.status
entry.failure.0:
  %context.field.106 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.107 = load i32, ptr %context.field.106, align 4
  %context.field.108 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.109 = load i32, ptr %context.field.108, align 4
  %context.field.110 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.111 = load i32, ptr %context.field.110, align 4
  %stack.offset.112 = add i32 %context.value.107, %context.value.109
  %stack.sub.113 = sub i32 0, %stack.offset.112
  %stack.sub.114 = sub i32 0, %context.value.109
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.113, i32 %stack.sub.114)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.111)
  br label %entry.return.status
entry.return.status:
  %context.field.115 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.116 = load i32, ptr %context.field.115, align 4
  ret i32 %context.value.116
}


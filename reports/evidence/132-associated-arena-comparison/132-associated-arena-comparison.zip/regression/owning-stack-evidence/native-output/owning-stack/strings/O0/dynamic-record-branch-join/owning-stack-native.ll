%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [5 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8 }, %AlOwningTypeDescriptor { i32 2, i32 2, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8 }, %AlOwningTypeDescriptor { i32 4, i32 8, i32 0, i32 2, i32 4294967295, i32 4294967295, i32 24, i32 24 }, %AlOwningTypeDescriptor { i32 4, i32 9, i32 2, i32 2, i32 4294967295, i32 4294967295, i32 16, i32 16 }, %AlOwningTypeDescriptor { i32 5, i32 12, i32 4, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8 }], align 4
@al_owning_fields = private constant [4 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 3, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 4294967295, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 4, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 4294967295, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 1, ptr @al_owning_types, i32 5, ptr @al_owning_fields, i32 4 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 8
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 8, 8
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %descriptor.element.43 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.44 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 0
  %descriptor.value.45 = load i32, ptr %descriptor.field.44, align 4
  %descriptor.field.46 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 1
  %descriptor.value.47 = load i32, ptr %descriptor.field.46, align 4
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 2
  %descriptor.value.49 = load i32, ptr %descriptor.field.48, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 3
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 4
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %argument.type.valid.54 = icmp eq i32 %descriptor.value.45, 8
  br i1 %argument.type.valid.54, label %argument.type.ok.55, label %frame.failure.0
argument.type.ok.55:
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %stack.sub.60 = sub i32 %descriptor.value.53, %descriptor.value.47
  %descriptor.owner.inside.58 = icmp ule i32 %descriptor.value.53, %context.value.57
  %descriptor.offset.inside.59 = icmp ule i32 %descriptor.value.47, %descriptor.value.53
  %descriptor.extent.inside.61 = icmp ule i32 %descriptor.value.49, %stack.sub.60
  %descriptor.payload.inside.62 = icmp ule i32 %descriptor.value.51, %descriptor.value.49
  %descriptor.owner.offset.valid.63 = and i1 %descriptor.owner.inside.58, %descriptor.offset.inside.59
  %descriptor.range.inside.65 = and i1 %descriptor.owner.offset.valid.63, %descriptor.extent.inside.61
  %descriptor.range.valid.64 = and i1 %descriptor.range.inside.65, %descriptor.payload.inside.62
  %descriptor.type.valid.66 = icmp eq i32 8, 8
  %descriptor.valid.67 = and i1 %descriptor.range.valid.64, %descriptor.type.valid.66
  br i1 %descriptor.valid.67, label %descriptor.valid.68, label %descriptor.invalid.69
descriptor.invalid.69:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.68:
  %descriptor.initialized.status.70 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.47, i32 %descriptor.value.49)
  %helper.ok.71 = icmp eq i32 %descriptor.initialized.status.70, 0
  br i1 %helper.ok.71, label %helper.continue.72, label %frame.failure.0
helper.continue.72:
  %descriptor.element.73 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 2
  %descriptor.field.74 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 0
  %descriptor.value.75 = load i32, ptr %descriptor.field.74, align 4
  %descriptor.field.76 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 1
  %descriptor.value.77 = load i32, ptr %descriptor.field.76, align 4
  %descriptor.field.78 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 2
  %descriptor.value.79 = load i32, ptr %descriptor.field.78, align 4
  %descriptor.field.80 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 3
  %descriptor.value.81 = load i32, ptr %descriptor.field.80, align 4
  %descriptor.field.82 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 4
  %descriptor.value.83 = load i32, ptr %descriptor.field.82, align 4
  %argument.type.valid.84 = icmp eq i32 %descriptor.value.75, 2
  br i1 %argument.type.valid.84, label %argument.type.ok.85, label %frame.failure.0
argument.type.ok.85:
  %context.field.86 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.87 = load i32, ptr %context.field.86, align 4
  %stack.sub.90 = sub i32 %descriptor.value.83, %descriptor.value.77
  %descriptor.owner.inside.88 = icmp ule i32 %descriptor.value.83, %context.value.87
  %descriptor.offset.inside.89 = icmp ule i32 %descriptor.value.77, %descriptor.value.83
  %descriptor.extent.inside.91 = icmp ule i32 %descriptor.value.79, %stack.sub.90
  %descriptor.payload.inside.92 = icmp ule i32 %descriptor.value.81, %descriptor.value.79
  %descriptor.owner.offset.valid.93 = and i1 %descriptor.owner.inside.88, %descriptor.offset.inside.89
  %descriptor.range.inside.95 = and i1 %descriptor.owner.offset.valid.93, %descriptor.extent.inside.91
  %descriptor.range.valid.94 = and i1 %descriptor.range.inside.95, %descriptor.payload.inside.92
  %descriptor.type.valid.96 = icmp eq i32 2, 2
  %descriptor.valid.97 = and i1 %descriptor.range.valid.94, %descriptor.type.valid.96
  br i1 %descriptor.valid.97, label %descriptor.valid.98, label %descriptor.invalid.99
descriptor.invalid.99:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.98:
  %descriptor.initialized.status.100 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.77, i32 %descriptor.value.79)
  %helper.ok.101 = icmp eq i32 %descriptor.initialized.status.100, 0
  br i1 %helper.ok.101, label %helper.continue.102, label %frame.failure.0
helper.continue.102:
  %step.status.103 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.104 = icmp eq i32 %step.status.103, 0
  br i1 %helper.ok.104, label %helper.continue.105, label %frame.failure.0
helper.continue.105:
  %call.arguments.106 = alloca [3 x %AlOwningDescriptor], align 4
  %descriptor.element.107 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.106, i32 0
  %descriptor.field.108 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.107, i32 0, i32 0
  store i32 8, ptr %descriptor.field.108, align 4
  %descriptor.field.109 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.107, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.109, align 4
  %descriptor.field.110 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.107, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.110, align 4
  %descriptor.field.111 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.107, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.111, align 4
  %descriptor.field.112 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.107, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.112, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.113 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.114 = load i32, ptr %context.field.113, align 4
  %runtime.ok.115 = icmp eq i32 %context.value.114, 0
  br i1 %runtime.ok.115, label %runtime.continue.116, label %frame.failure.0
runtime.continue.116:
  %descriptor.element.117 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.106, i32 1
  %descriptor.field.118 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.117, i32 0, i32 0
  store i32 8, ptr %descriptor.field.118, align 4
  %descriptor.field.119 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.117, i32 0, i32 1
  store i32 %descriptor.value.47, ptr %descriptor.field.119, align 4
  %descriptor.field.120 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.117, i32 0, i32 2
  store i32 %descriptor.value.49, ptr %descriptor.field.120, align 4
  %descriptor.field.121 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.117, i32 0, i32 3
  store i32 %descriptor.value.51, ptr %descriptor.field.121, align 4
  %descriptor.field.122 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.117, i32 0, i32 4
  store i32 %descriptor.value.53, ptr %descriptor.field.122, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %descriptor.value.47, i32 20, i32 %descriptor.value.51, i32 %descriptor.value.53, i32 %descriptor.value.49)
  %context.field.123 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.124 = load i32, ptr %context.field.123, align 4
  %runtime.ok.125 = icmp eq i32 %context.value.124, 0
  br i1 %runtime.ok.125, label %runtime.continue.126, label %frame.failure.0
runtime.continue.126:
  %descriptor.element.127 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.106, i32 2
  %descriptor.field.128 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.127, i32 0, i32 0
  store i32 2, ptr %descriptor.field.128, align 4
  %descriptor.field.129 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.127, i32 0, i32 1
  store i32 %descriptor.value.77, ptr %descriptor.field.129, align 4
  %descriptor.field.130 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.127, i32 0, i32 2
  store i32 %descriptor.value.79, ptr %descriptor.field.130, align 4
  %descriptor.field.131 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.127, i32 0, i32 3
  store i32 %descriptor.value.81, ptr %descriptor.field.131, align 4
  %descriptor.field.132 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.127, i32 0, i32 4
  store i32 %descriptor.value.83, ptr %descriptor.field.132, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %descriptor.value.77, i32 20, i32 %descriptor.value.81, i32 %descriptor.value.83, i32 %descriptor.value.79)
  %context.field.133 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.134 = load i32, ptr %context.field.133, align 4
  %runtime.ok.135 = icmp eq i32 %context.value.134, 0
  br i1 %runtime.ok.135, label %runtime.continue.136, label %frame.failure.0
runtime.continue.136:
  %call.results.137 = alloca [2 x %AlOwningDescriptor], align 4
  %callee.status.138 = call i32 @agentlang_word_0000(ptr %ctx, ptr %call.arguments.106, ptr %call.results.137, i32 2)
  %helper.ok.139 = icmp eq i32 %callee.status.138, 0
  br i1 %helper.ok.139, label %helper.continue.140, label %frame.failure.0
helper.continue.140:
  %descriptor.element.141 = getelementptr inbounds %AlOwningDescriptor, ptr %call.results.137, i32 0
  %descriptor.field.142 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.141, i32 0, i32 0
  %descriptor.value.143 = load i32, ptr %descriptor.field.142, align 4
  %descriptor.field.144 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.141, i32 0, i32 1
  %descriptor.value.145 = load i32, ptr %descriptor.field.144, align 4
  %descriptor.field.146 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.141, i32 0, i32 2
  %descriptor.value.147 = load i32, ptr %descriptor.field.146, align 4
  %descriptor.field.148 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.141, i32 0, i32 3
  %descriptor.value.149 = load i32, ptr %descriptor.field.148, align 4
  %descriptor.field.150 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.141, i32 0, i32 4
  %descriptor.value.151 = load i32, ptr %descriptor.field.150, align 4
  %callee.result.type.valid.152 = icmp eq i32 %descriptor.value.143, 8
  br i1 %callee.result.type.valid.152, label %callee.result.type.ok.153, label %frame.failure.0
callee.result.type.ok.153:
  %context.field.154 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.155 = load i32, ptr %context.field.154, align 4
  %stack.sub.158 = sub i32 %descriptor.value.151, %descriptor.value.145
  %descriptor.owner.inside.156 = icmp ule i32 %descriptor.value.151, %context.value.155
  %descriptor.offset.inside.157 = icmp ule i32 %descriptor.value.145, %descriptor.value.151
  %descriptor.extent.inside.159 = icmp ule i32 %descriptor.value.147, %stack.sub.158
  %descriptor.payload.inside.160 = icmp ule i32 %descriptor.value.149, %descriptor.value.147
  %descriptor.owner.offset.valid.161 = and i1 %descriptor.owner.inside.156, %descriptor.offset.inside.157
  %descriptor.range.inside.163 = and i1 %descriptor.owner.offset.valid.161, %descriptor.extent.inside.159
  %descriptor.range.valid.162 = and i1 %descriptor.range.inside.163, %descriptor.payload.inside.160
  %descriptor.type.valid.164 = icmp eq i32 8, 8
  %descriptor.valid.165 = and i1 %descriptor.range.valid.162, %descriptor.type.valid.164
  br i1 %descriptor.valid.165, label %descriptor.valid.166, label %descriptor.invalid.167
descriptor.invalid.167:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.166:
  %descriptor.initialized.status.168 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.145, i32 %descriptor.value.147)
  %helper.ok.169 = icmp eq i32 %descriptor.initialized.status.168, 0
  br i1 %helper.ok.169, label %helper.continue.170, label %frame.failure.0
helper.continue.170:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %descriptor.value.145, i32 20, i32 %descriptor.value.149, i32 %descriptor.value.151, i32 %descriptor.value.147)
  %context.field.171 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.172 = load i32, ptr %context.field.171, align 4
  %runtime.ok.173 = icmp eq i32 %context.value.172, 0
  br i1 %runtime.ok.173, label %runtime.continue.174, label %frame.failure.0
runtime.continue.174:
  %descriptor.element.175 = getelementptr inbounds %AlOwningDescriptor, ptr %call.results.137, i32 1
  %descriptor.field.176 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.175, i32 0, i32 0
  %descriptor.value.177 = load i32, ptr %descriptor.field.176, align 4
  %descriptor.field.178 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.175, i32 0, i32 1
  %descriptor.value.179 = load i32, ptr %descriptor.field.178, align 4
  %descriptor.field.180 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.175, i32 0, i32 2
  %descriptor.value.181 = load i32, ptr %descriptor.field.180, align 4
  %descriptor.field.182 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.175, i32 0, i32 3
  %descriptor.value.183 = load i32, ptr %descriptor.field.182, align 4
  %descriptor.field.184 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.175, i32 0, i32 4
  %descriptor.value.185 = load i32, ptr %descriptor.field.184, align 4
  %callee.result.type.valid.186 = icmp eq i32 %descriptor.value.177, 1
  br i1 %callee.result.type.valid.186, label %callee.result.type.ok.187, label %frame.failure.0
callee.result.type.ok.187:
  %context.field.188 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.189 = load i32, ptr %context.field.188, align 4
  %stack.sub.192 = sub i32 %descriptor.value.185, %descriptor.value.179
  %descriptor.owner.inside.190 = icmp ule i32 %descriptor.value.185, %context.value.189
  %descriptor.offset.inside.191 = icmp ule i32 %descriptor.value.179, %descriptor.value.185
  %descriptor.extent.inside.193 = icmp ule i32 %descriptor.value.181, %stack.sub.192
  %descriptor.payload.inside.194 = icmp ule i32 %descriptor.value.183, %descriptor.value.181
  %descriptor.owner.offset.valid.195 = and i1 %descriptor.owner.inside.190, %descriptor.offset.inside.191
  %descriptor.range.inside.197 = and i1 %descriptor.owner.offset.valid.195, %descriptor.extent.inside.193
  %descriptor.range.valid.196 = and i1 %descriptor.range.inside.197, %descriptor.payload.inside.194
  %descriptor.type.valid.198 = icmp eq i32 1, 1
  %descriptor.valid.199 = and i1 %descriptor.range.valid.196, %descriptor.type.valid.198
  br i1 %descriptor.valid.199, label %descriptor.valid.200, label %descriptor.invalid.201
descriptor.invalid.201:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.200:
  %descriptor.initialized.status.202 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.179, i32 %descriptor.value.181)
  %helper.ok.203 = icmp eq i32 %descriptor.initialized.status.202, 0
  br i1 %helper.ok.203, label %helper.continue.204, label %frame.failure.0
helper.continue.204:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %descriptor.value.179, i32 20, i32 %descriptor.value.183, i32 %descriptor.value.185, i32 %descriptor.value.181)
  %context.field.205 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.206 = load i32, ptr %context.field.205, align 4
  %runtime.ok.207 = icmp eq i32 %context.value.206, 0
  br i1 %runtime.ok.207, label %runtime.continue.208, label %frame.failure.0
runtime.continue.208:
  %context.field.209 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.210 = load i32, ptr %context.field.209, align 4
  %stack.sub.213 = sub i32 %descriptor.value.151, %descriptor.value.145
  %descriptor.owner.inside.211 = icmp ule i32 %descriptor.value.151, %context.value.210
  %descriptor.offset.inside.212 = icmp ule i32 %descriptor.value.145, %descriptor.value.151
  %descriptor.extent.inside.214 = icmp ule i32 %descriptor.value.147, %stack.sub.213
  %descriptor.payload.inside.215 = icmp ule i32 %descriptor.value.149, %descriptor.value.147
  %descriptor.owner.offset.valid.216 = and i1 %descriptor.owner.inside.211, %descriptor.offset.inside.212
  %descriptor.range.inside.218 = and i1 %descriptor.owner.offset.valid.216, %descriptor.extent.inside.214
  %descriptor.range.valid.217 = and i1 %descriptor.range.inside.218, %descriptor.payload.inside.215
  %descriptor.type.valid.219 = icmp eq i32 8, 8
  %descriptor.valid.220 = and i1 %descriptor.range.valid.217, %descriptor.type.valid.219
  br i1 %descriptor.valid.220, label %descriptor.valid.221, label %descriptor.invalid.222
descriptor.invalid.222:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.221:
  %descriptor.initialized.status.223 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.145, i32 %descriptor.value.147)
  %helper.ok.224 = icmp eq i32 %descriptor.initialized.status.223, 0
  br i1 %helper.ok.224, label %helper.continue.225, label %frame.failure.0
helper.continue.225:
  %context.field.226 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.227 = load i32, ptr %context.field.226, align 4
  %stack.sub.230 = sub i32 %descriptor.value.185, %descriptor.value.179
  %descriptor.owner.inside.228 = icmp ule i32 %descriptor.value.185, %context.value.227
  %descriptor.offset.inside.229 = icmp ule i32 %descriptor.value.179, %descriptor.value.185
  %descriptor.extent.inside.231 = icmp ule i32 %descriptor.value.181, %stack.sub.230
  %descriptor.payload.inside.232 = icmp ule i32 %descriptor.value.183, %descriptor.value.181
  %descriptor.owner.offset.valid.233 = and i1 %descriptor.owner.inside.228, %descriptor.offset.inside.229
  %descriptor.range.inside.235 = and i1 %descriptor.owner.offset.valid.233, %descriptor.extent.inside.231
  %descriptor.range.valid.234 = and i1 %descriptor.range.inside.235, %descriptor.payload.inside.232
  %descriptor.type.valid.236 = icmp eq i32 1, 1
  %descriptor.valid.237 = and i1 %descriptor.range.valid.234, %descriptor.type.valid.236
  br i1 %descriptor.valid.237, label %descriptor.valid.238, label %descriptor.invalid.239
descriptor.invalid.239:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.238:
  %descriptor.initialized.status.240 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.179, i32 %descriptor.value.181)
  %helper.ok.241 = icmp eq i32 %descriptor.initialized.status.240, 0
  br i1 %helper.ok.241, label %helper.continue.242, label %frame.failure.0
helper.continue.242:
  %descriptor.element.243 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.244 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.243, i32 0, i32 0
  store i32 8, ptr %descriptor.field.244, align 4
  %descriptor.field.245 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.243, i32 0, i32 1
  store i32 %descriptor.value.145, ptr %descriptor.field.245, align 4
  %descriptor.field.246 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.243, i32 0, i32 2
  store i32 %descriptor.value.147, ptr %descriptor.field.246, align 4
  %descriptor.field.247 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.243, i32 0, i32 3
  store i32 %descriptor.value.149, ptr %descriptor.field.247, align 4
  %descriptor.field.248 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.243, i32 0, i32 4
  store i32 %descriptor.value.151, ptr %descriptor.field.248, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %descriptor.value.145, i32 20, i32 %descriptor.value.149, i32 %descriptor.value.151, i32 %descriptor.value.147)
  %context.field.249 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.250 = load i32, ptr %context.field.249, align 4
  %runtime.ok.251 = icmp eq i32 %context.value.250, 0
  br i1 %runtime.ok.251, label %runtime.continue.252, label %frame.failure.0
runtime.continue.252:
  %descriptor.element.253 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 1
  %descriptor.field.254 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.253, i32 0, i32 0
  store i32 1, ptr %descriptor.field.254, align 4
  %descriptor.field.255 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.253, i32 0, i32 1
  store i32 %descriptor.value.179, ptr %descriptor.field.255, align 4
  %descriptor.field.256 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.253, i32 0, i32 2
  store i32 %descriptor.value.181, ptr %descriptor.field.256, align 4
  %descriptor.field.257 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.253, i32 0, i32 3
  store i32 %descriptor.value.183, ptr %descriptor.field.257, align 4
  %descriptor.field.258 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.253, i32 0, i32 4
  store i32 %descriptor.value.185, ptr %descriptor.field.258, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %descriptor.value.179, i32 20, i32 %descriptor.value.183, i32 %descriptor.value.185, i32 %descriptor.value.181)
  %context.field.259 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.260 = load i32, ptr %context.field.259, align 4
  %runtime.ok.261 = icmp eq i32 %context.value.260, 0
  br i1 %runtime.ok.261, label %runtime.continue.262, label %frame.failure.0
runtime.continue.262:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.263 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.264 = load i32, ptr %context.field.263, align 4
  %context.field.265 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.266 = load i32, ptr %context.field.265, align 4
  %context.field.267 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.268 = load i32, ptr %context.field.267, align 4
  %stack.offset.269 = add i32 %context.value.5, %context.value.7
  %stack.offset.270 = add i32 %context.value.264, %context.value.266
  %stack.sub.271 = sub i32 %stack.offset.269, %stack.offset.270
  %stack.sub.272 = sub i32 %context.value.7, %context.value.266
  %stack.sub.273 = sub i32 %context.value.268, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.271, i32 %stack.sub.272)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.273)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %local.active.2 = alloca i1, align 1
  %local.offset.3 = alloca i32, align 4
  %local.extent.4 = alloca i32, align 4
  %local.payload.5 = alloca i32, align 4
  %local.owner.end.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %local.active.8 = alloca i1, align 1
  %local.offset.9 = alloca i32, align 4
  %local.extent.10 = alloca i32, align 4
  %local.payload.11 = alloca i32, align 4
  %local.owner.end.12 = alloca i32, align 4
  %local.type.13 = alloca i32, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  %local.active.14 = alloca i1, align 1
  %local.offset.15 = alloca i32, align 4
  %local.extent.16 = alloca i32, align 4
  %local.payload.17 = alloca i32, align 4
  %local.owner.end.18 = alloca i32, align 4
  %local.type.19 = alloca i32, align 4
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  %local.active.20 = alloca i1, align 1
  %local.offset.21 = alloca i32, align 4
  %local.extent.22 = alloca i32, align 4
  %local.payload.23 = alloca i32, align 4
  %local.owner.end.24 = alloca i32, align 4
  %local.type.25 = alloca i32, align 4
  store i1 false, ptr %local.active.20, align 1
  store i32 0, ptr %local.offset.21, align 4
  store i32 0, ptr %local.extent.22, align 4
  store i32 0, ptr %local.payload.23, align 4
  store i32 0, ptr %local.owner.end.24, align 4
  store i32 0, ptr %local.type.25, align 4
  %local.active.26 = alloca i1, align 1
  %local.offset.27 = alloca i32, align 4
  %local.extent.28 = alloca i32, align 4
  %local.payload.29 = alloca i32, align 4
  %local.owner.end.30 = alloca i32, align 4
  %local.type.31 = alloca i32, align 4
  store i1 false, ptr %local.active.26, align 1
  store i32 0, ptr %local.offset.27, align 4
  store i32 0, ptr %local.extent.28, align 4
  store i32 0, ptr %local.payload.29, align 4
  store i32 0, ptr %local.owner.end.30, align 4
  store i32 0, ptr %local.type.31, align 4
  %context.field.32 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.33 = load i32, ptr %context.field.32, align 4
  %context.field.34 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.35 = load i32, ptr %context.field.34, align 4
  %context.field.36 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.37 = load i32, ptr %context.field.36, align 4
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %frame.entered.40 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.41 = icmp eq i32 %frame.entered.40, 0
  br i1 %frame.enter.ok.41, label %frame.enter.continue.42, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.42:
  %descriptor.element.43 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.44 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 0
  %descriptor.value.45 = load i32, ptr %descriptor.field.44, align 4
  %descriptor.field.46 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 1
  %descriptor.value.47 = load i32, ptr %descriptor.field.46, align 4
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 2
  %descriptor.value.49 = load i32, ptr %descriptor.field.48, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 3
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 4
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %argument.type.valid.54 = icmp eq i32 %descriptor.value.45, 8
  br i1 %argument.type.valid.54, label %argument.type.ok.55, label %frame.failure.0
argument.type.ok.55:
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %stack.sub.60 = sub i32 %descriptor.value.53, %descriptor.value.47
  %descriptor.owner.inside.58 = icmp ule i32 %descriptor.value.53, %context.value.57
  %descriptor.offset.inside.59 = icmp ule i32 %descriptor.value.47, %descriptor.value.53
  %descriptor.extent.inside.61 = icmp ule i32 %descriptor.value.49, %stack.sub.60
  %descriptor.payload.inside.62 = icmp ule i32 %descriptor.value.51, %descriptor.value.49
  %descriptor.owner.offset.valid.63 = and i1 %descriptor.owner.inside.58, %descriptor.offset.inside.59
  %descriptor.range.inside.65 = and i1 %descriptor.owner.offset.valid.63, %descriptor.extent.inside.61
  %descriptor.range.valid.64 = and i1 %descriptor.range.inside.65, %descriptor.payload.inside.62
  %descriptor.type.valid.66 = icmp eq i32 8, 8
  %descriptor.valid.67 = and i1 %descriptor.range.valid.64, %descriptor.type.valid.66
  br i1 %descriptor.valid.67, label %descriptor.valid.68, label %descriptor.invalid.69
descriptor.invalid.69:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.68:
  %descriptor.initialized.status.70 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.47, i32 %descriptor.value.49)
  %helper.ok.71 = icmp eq i32 %descriptor.initialized.status.70, 0
  br i1 %helper.ok.71, label %helper.continue.72, label %frame.failure.0
helper.continue.72:
  %descriptor.element.73 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.74 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 0
  %descriptor.value.75 = load i32, ptr %descriptor.field.74, align 4
  %descriptor.field.76 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 1
  %descriptor.value.77 = load i32, ptr %descriptor.field.76, align 4
  %descriptor.field.78 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 2
  %descriptor.value.79 = load i32, ptr %descriptor.field.78, align 4
  %descriptor.field.80 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 3
  %descriptor.value.81 = load i32, ptr %descriptor.field.80, align 4
  %descriptor.field.82 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 4
  %descriptor.value.83 = load i32, ptr %descriptor.field.82, align 4
  %argument.type.valid.84 = icmp eq i32 %descriptor.value.75, 8
  br i1 %argument.type.valid.84, label %argument.type.ok.85, label %frame.failure.0
argument.type.ok.85:
  %context.field.86 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.87 = load i32, ptr %context.field.86, align 4
  %stack.sub.90 = sub i32 %descriptor.value.83, %descriptor.value.77
  %descriptor.owner.inside.88 = icmp ule i32 %descriptor.value.83, %context.value.87
  %descriptor.offset.inside.89 = icmp ule i32 %descriptor.value.77, %descriptor.value.83
  %descriptor.extent.inside.91 = icmp ule i32 %descriptor.value.79, %stack.sub.90
  %descriptor.payload.inside.92 = icmp ule i32 %descriptor.value.81, %descriptor.value.79
  %descriptor.owner.offset.valid.93 = and i1 %descriptor.owner.inside.88, %descriptor.offset.inside.89
  %descriptor.range.inside.95 = and i1 %descriptor.owner.offset.valid.93, %descriptor.extent.inside.91
  %descriptor.range.valid.94 = and i1 %descriptor.range.inside.95, %descriptor.payload.inside.92
  %descriptor.type.valid.96 = icmp eq i32 8, 8
  %descriptor.valid.97 = and i1 %descriptor.range.valid.94, %descriptor.type.valid.96
  br i1 %descriptor.valid.97, label %descriptor.valid.98, label %descriptor.invalid.99
descriptor.invalid.99:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.98:
  %descriptor.initialized.status.100 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.77, i32 %descriptor.value.79)
  %helper.ok.101 = icmp eq i32 %descriptor.initialized.status.100, 0
  br i1 %helper.ok.101, label %helper.continue.102, label %frame.failure.0
helper.continue.102:
  %descriptor.element.103 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 2
  %descriptor.field.104 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.103, i32 0, i32 0
  %descriptor.value.105 = load i32, ptr %descriptor.field.104, align 4
  %descriptor.field.106 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.103, i32 0, i32 1
  %descriptor.value.107 = load i32, ptr %descriptor.field.106, align 4
  %descriptor.field.108 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.103, i32 0, i32 2
  %descriptor.value.109 = load i32, ptr %descriptor.field.108, align 4
  %descriptor.field.110 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.103, i32 0, i32 3
  %descriptor.value.111 = load i32, ptr %descriptor.field.110, align 4
  %descriptor.field.112 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.103, i32 0, i32 4
  %descriptor.value.113 = load i32, ptr %descriptor.field.112, align 4
  %argument.type.valid.114 = icmp eq i32 %descriptor.value.105, 2
  br i1 %argument.type.valid.114, label %argument.type.ok.115, label %frame.failure.0
argument.type.ok.115:
  %context.field.116 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.117 = load i32, ptr %context.field.116, align 4
  %stack.sub.120 = sub i32 %descriptor.value.113, %descriptor.value.107
  %descriptor.owner.inside.118 = icmp ule i32 %descriptor.value.113, %context.value.117
  %descriptor.offset.inside.119 = icmp ule i32 %descriptor.value.107, %descriptor.value.113
  %descriptor.extent.inside.121 = icmp ule i32 %descriptor.value.109, %stack.sub.120
  %descriptor.payload.inside.122 = icmp ule i32 %descriptor.value.111, %descriptor.value.109
  %descriptor.owner.offset.valid.123 = and i1 %descriptor.owner.inside.118, %descriptor.offset.inside.119
  %descriptor.range.inside.125 = and i1 %descriptor.owner.offset.valid.123, %descriptor.extent.inside.121
  %descriptor.range.valid.124 = and i1 %descriptor.range.inside.125, %descriptor.payload.inside.122
  %descriptor.type.valid.126 = icmp eq i32 2, 2
  %descriptor.valid.127 = and i1 %descriptor.range.valid.124, %descriptor.type.valid.126
  br i1 %descriptor.valid.127, label %descriptor.valid.128, label %descriptor.invalid.129
descriptor.invalid.129:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.128:
  %descriptor.initialized.status.130 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.107, i32 %descriptor.value.109)
  %helper.ok.131 = icmp eq i32 %descriptor.initialized.status.130, 0
  br i1 %helper.ok.131, label %helper.continue.132, label %frame.failure.0
helper.continue.132:
  %step.status.133 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.134 = icmp eq i32 %step.status.133, 0
  br i1 %helper.ok.134, label %helper.continue.135, label %frame.failure.0
helper.continue.135:
  store i1 true, ptr %local.active.2, align 1
  store i32 %descriptor.value.107, ptr %local.offset.3, align 4
  store i32 %descriptor.value.109, ptr %local.extent.4, align 4
  store i32 %descriptor.value.111, ptr %local.payload.5, align 4
  store i32 %descriptor.value.113, ptr %local.owner.end.6, align 4
  store i32 2, ptr %local.type.7, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %descriptor.value.107, i32 20, i32 %descriptor.value.111, i32 %descriptor.value.113, i32 %descriptor.value.109)
  %context.field.136 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.137 = load i32, ptr %context.field.136, align 4
  %runtime.ok.138 = icmp eq i32 %context.value.137, 0
  br i1 %runtime.ok.138, label %runtime.continue.139, label %frame.failure.0
runtime.continue.139:
  %context.field.140 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.141 = load i32, ptr %context.field.140, align 4
  %stack.sub.144 = sub i32 %descriptor.value.53, %descriptor.value.47
  %descriptor.owner.inside.142 = icmp ule i32 %descriptor.value.53, %context.value.141
  %descriptor.offset.inside.143 = icmp ule i32 %descriptor.value.47, %descriptor.value.53
  %descriptor.extent.inside.145 = icmp ule i32 %descriptor.value.49, %stack.sub.144
  %descriptor.payload.inside.146 = icmp ule i32 %descriptor.value.51, %descriptor.value.49
  %descriptor.owner.offset.valid.147 = and i1 %descriptor.owner.inside.142, %descriptor.offset.inside.143
  %descriptor.range.inside.149 = and i1 %descriptor.owner.offset.valid.147, %descriptor.extent.inside.145
  %descriptor.range.valid.148 = and i1 %descriptor.range.inside.149, %descriptor.payload.inside.146
  %descriptor.type.valid.150 = icmp eq i32 8, 8
  %descriptor.valid.151 = and i1 %descriptor.range.valid.148, %descriptor.type.valid.150
  br i1 %descriptor.valid.151, label %descriptor.valid.152, label %descriptor.invalid.153
descriptor.invalid.153:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.152:
  %descriptor.initialized.status.154 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.47, i32 %descriptor.value.49)
  %helper.ok.155 = icmp eq i32 %descriptor.initialized.status.154, 0
  br i1 %helper.ok.155, label %helper.continue.156, label %frame.failure.0
helper.continue.156:
  %context.field.157 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.158 = load i32, ptr %context.field.157, align 4
  %stack.sub.161 = sub i32 %descriptor.value.83, %descriptor.value.77
  %descriptor.owner.inside.159 = icmp ule i32 %descriptor.value.83, %context.value.158
  %descriptor.offset.inside.160 = icmp ule i32 %descriptor.value.77, %descriptor.value.83
  %descriptor.extent.inside.162 = icmp ule i32 %descriptor.value.79, %stack.sub.161
  %descriptor.payload.inside.163 = icmp ule i32 %descriptor.value.81, %descriptor.value.79
  %descriptor.owner.offset.valid.164 = and i1 %descriptor.owner.inside.159, %descriptor.offset.inside.160
  %descriptor.range.inside.166 = and i1 %descriptor.owner.offset.valid.164, %descriptor.extent.inside.162
  %descriptor.range.valid.165 = and i1 %descriptor.range.inside.166, %descriptor.payload.inside.163
  %descriptor.type.valid.167 = icmp eq i32 8, 8
  %descriptor.valid.168 = and i1 %descriptor.range.valid.165, %descriptor.type.valid.167
  br i1 %descriptor.valid.168, label %descriptor.valid.169, label %descriptor.invalid.170
descriptor.invalid.170:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.169:
  %descriptor.initialized.status.171 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.77, i32 %descriptor.value.79)
  %helper.ok.172 = icmp eq i32 %descriptor.initialized.status.171, 0
  br i1 %helper.ok.172, label %helper.continue.173, label %frame.failure.0
helper.continue.173:
  %local.is.active.174 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.174, label %local.descriptor.active.175, label %local.descriptor.inactive.176
local.descriptor.active.175:
  %local.check.offset.178 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.179 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.180 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.181 = load i32, ptr %local.owner.end.6, align 4
  %context.field.182 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.183 = load i32, ptr %context.field.182, align 4
  %stack.sub.186 = sub i32 %local.check.owner.end.181, %local.check.offset.178
  %descriptor.owner.inside.184 = icmp ule i32 %local.check.owner.end.181, %context.value.183
  %descriptor.offset.inside.185 = icmp ule i32 %local.check.offset.178, %local.check.owner.end.181
  %descriptor.extent.inside.187 = icmp ule i32 %local.check.extent.179, %stack.sub.186
  %descriptor.payload.inside.188 = icmp ule i32 %local.check.payload.180, %local.check.extent.179
  %descriptor.owner.offset.valid.189 = and i1 %descriptor.owner.inside.184, %descriptor.offset.inside.185
  %descriptor.range.inside.191 = and i1 %descriptor.owner.offset.valid.189, %descriptor.extent.inside.187
  %descriptor.range.valid.190 = and i1 %descriptor.range.inside.191, %descriptor.payload.inside.188
  br i1 %descriptor.range.valid.190, label %descriptor.valid.192, label %descriptor.invalid.193
descriptor.invalid.193:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.192:
  %descriptor.initialized.status.194 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.178, i32 %local.check.extent.179)
  %helper.ok.195 = icmp eq i32 %descriptor.initialized.status.194, 0
  br i1 %helper.ok.195, label %helper.continue.196, label %frame.failure.0
helper.continue.196:
  br label %local.descriptor.checked.177
local.descriptor.inactive.176:
  br label %local.descriptor.checked.177
local.descriptor.checked.177:
  %local.is.active.197 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.197, label %local.descriptor.active.198, label %local.descriptor.inactive.199
local.descriptor.active.198:
  %local.check.offset.201 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.202 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.203 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.204 = load i32, ptr %local.owner.end.12, align 4
  %context.field.205 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.206 = load i32, ptr %context.field.205, align 4
  %stack.sub.209 = sub i32 %local.check.owner.end.204, %local.check.offset.201
  %descriptor.owner.inside.207 = icmp ule i32 %local.check.owner.end.204, %context.value.206
  %descriptor.offset.inside.208 = icmp ule i32 %local.check.offset.201, %local.check.owner.end.204
  %descriptor.extent.inside.210 = icmp ule i32 %local.check.extent.202, %stack.sub.209
  %descriptor.payload.inside.211 = icmp ule i32 %local.check.payload.203, %local.check.extent.202
  %descriptor.owner.offset.valid.212 = and i1 %descriptor.owner.inside.207, %descriptor.offset.inside.208
  %descriptor.range.inside.214 = and i1 %descriptor.owner.offset.valid.212, %descriptor.extent.inside.210
  %descriptor.range.valid.213 = and i1 %descriptor.range.inside.214, %descriptor.payload.inside.211
  br i1 %descriptor.range.valid.213, label %descriptor.valid.215, label %descriptor.invalid.216
descriptor.invalid.216:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.215:
  %descriptor.initialized.status.217 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.201, i32 %local.check.extent.202)
  %helper.ok.218 = icmp eq i32 %descriptor.initialized.status.217, 0
  br i1 %helper.ok.218, label %helper.continue.219, label %frame.failure.0
helper.continue.219:
  br label %local.descriptor.checked.200
local.descriptor.inactive.199:
  br label %local.descriptor.checked.200
local.descriptor.checked.200:
  %local.is.active.220 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.220, label %local.descriptor.active.221, label %local.descriptor.inactive.222
local.descriptor.active.221:
  %local.check.offset.224 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.225 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.226 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.227 = load i32, ptr %local.owner.end.18, align 4
  %context.field.228 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.229 = load i32, ptr %context.field.228, align 4
  %stack.sub.232 = sub i32 %local.check.owner.end.227, %local.check.offset.224
  %descriptor.owner.inside.230 = icmp ule i32 %local.check.owner.end.227, %context.value.229
  %descriptor.offset.inside.231 = icmp ule i32 %local.check.offset.224, %local.check.owner.end.227
  %descriptor.extent.inside.233 = icmp ule i32 %local.check.extent.225, %stack.sub.232
  %descriptor.payload.inside.234 = icmp ule i32 %local.check.payload.226, %local.check.extent.225
  %descriptor.owner.offset.valid.235 = and i1 %descriptor.owner.inside.230, %descriptor.offset.inside.231
  %descriptor.range.inside.237 = and i1 %descriptor.owner.offset.valid.235, %descriptor.extent.inside.233
  %descriptor.range.valid.236 = and i1 %descriptor.range.inside.237, %descriptor.payload.inside.234
  br i1 %descriptor.range.valid.236, label %descriptor.valid.238, label %descriptor.invalid.239
descriptor.invalid.239:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.238:
  %descriptor.initialized.status.240 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.224, i32 %local.check.extent.225)
  %helper.ok.241 = icmp eq i32 %descriptor.initialized.status.240, 0
  br i1 %helper.ok.241, label %helper.continue.242, label %frame.failure.0
helper.continue.242:
  br label %local.descriptor.checked.223
local.descriptor.inactive.222:
  br label %local.descriptor.checked.223
local.descriptor.checked.223:
  %local.is.active.243 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.243, label %local.descriptor.active.244, label %local.descriptor.inactive.245
local.descriptor.active.244:
  %local.check.offset.247 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.248 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.249 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.250 = load i32, ptr %local.owner.end.24, align 4
  %context.field.251 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.252 = load i32, ptr %context.field.251, align 4
  %stack.sub.255 = sub i32 %local.check.owner.end.250, %local.check.offset.247
  %descriptor.owner.inside.253 = icmp ule i32 %local.check.owner.end.250, %context.value.252
  %descriptor.offset.inside.254 = icmp ule i32 %local.check.offset.247, %local.check.owner.end.250
  %descriptor.extent.inside.256 = icmp ule i32 %local.check.extent.248, %stack.sub.255
  %descriptor.payload.inside.257 = icmp ule i32 %local.check.payload.249, %local.check.extent.248
  %descriptor.owner.offset.valid.258 = and i1 %descriptor.owner.inside.253, %descriptor.offset.inside.254
  %descriptor.range.inside.260 = and i1 %descriptor.owner.offset.valid.258, %descriptor.extent.inside.256
  %descriptor.range.valid.259 = and i1 %descriptor.range.inside.260, %descriptor.payload.inside.257
  br i1 %descriptor.range.valid.259, label %descriptor.valid.261, label %descriptor.invalid.262
descriptor.invalid.262:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.261:
  %descriptor.initialized.status.263 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.247, i32 %local.check.extent.248)
  %helper.ok.264 = icmp eq i32 %descriptor.initialized.status.263, 0
  br i1 %helper.ok.264, label %helper.continue.265, label %frame.failure.0
helper.continue.265:
  br label %local.descriptor.checked.246
local.descriptor.inactive.245:
  br label %local.descriptor.checked.246
local.descriptor.checked.246:
  %local.is.active.266 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.266, label %local.descriptor.active.267, label %local.descriptor.inactive.268
local.descriptor.active.267:
  %local.check.offset.270 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.271 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.272 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.273 = load i32, ptr %local.owner.end.30, align 4
  %context.field.274 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.275 = load i32, ptr %context.field.274, align 4
  %stack.sub.278 = sub i32 %local.check.owner.end.273, %local.check.offset.270
  %descriptor.owner.inside.276 = icmp ule i32 %local.check.owner.end.273, %context.value.275
  %descriptor.offset.inside.277 = icmp ule i32 %local.check.offset.270, %local.check.owner.end.273
  %descriptor.extent.inside.279 = icmp ule i32 %local.check.extent.271, %stack.sub.278
  %descriptor.payload.inside.280 = icmp ule i32 %local.check.payload.272, %local.check.extent.271
  %descriptor.owner.offset.valid.281 = and i1 %descriptor.owner.inside.276, %descriptor.offset.inside.277
  %descriptor.range.inside.283 = and i1 %descriptor.owner.offset.valid.281, %descriptor.extent.inside.279
  %descriptor.range.valid.282 = and i1 %descriptor.range.inside.283, %descriptor.payload.inside.280
  br i1 %descriptor.range.valid.282, label %descriptor.valid.284, label %descriptor.invalid.285
descriptor.invalid.285:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.284:
  %descriptor.initialized.status.286 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.270, i32 %local.check.extent.271)
  %helper.ok.287 = icmp eq i32 %descriptor.initialized.status.286, 0
  br i1 %helper.ok.287, label %helper.continue.288, label %frame.failure.0
helper.continue.288:
  br label %local.descriptor.checked.269
local.descriptor.inactive.268:
  br label %local.descriptor.checked.269
local.descriptor.checked.269:
  %step.status.289 = call i32 @al_owning_charge_step(ptr %ctx, i32 4)
  %helper.ok.290 = icmp eq i32 %step.status.289, 0
  br i1 %helper.ok.290, label %helper.continue.291, label %frame.failure.0
helper.continue.291:
  store i1 true, ptr %local.active.8, align 1
  store i32 %descriptor.value.77, ptr %local.offset.9, align 4
  store i32 %descriptor.value.79, ptr %local.extent.10, align 4
  store i32 %descriptor.value.81, ptr %local.payload.11, align 4
  store i32 %descriptor.value.83, ptr %local.owner.end.12, align 4
  store i32 8, ptr %local.type.13, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %descriptor.value.77, i32 20, i32 %descriptor.value.81, i32 %descriptor.value.83, i32 %descriptor.value.79)
  %context.field.292 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.293 = load i32, ptr %context.field.292, align 4
  %runtime.ok.294 = icmp eq i32 %context.value.293, 0
  br i1 %runtime.ok.294, label %runtime.continue.295, label %frame.failure.0
runtime.continue.295:
  %context.field.296 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.297 = load i32, ptr %context.field.296, align 4
  %stack.sub.300 = sub i32 %descriptor.value.53, %descriptor.value.47
  %descriptor.owner.inside.298 = icmp ule i32 %descriptor.value.53, %context.value.297
  %descriptor.offset.inside.299 = icmp ule i32 %descriptor.value.47, %descriptor.value.53
  %descriptor.extent.inside.301 = icmp ule i32 %descriptor.value.49, %stack.sub.300
  %descriptor.payload.inside.302 = icmp ule i32 %descriptor.value.51, %descriptor.value.49
  %descriptor.owner.offset.valid.303 = and i1 %descriptor.owner.inside.298, %descriptor.offset.inside.299
  %descriptor.range.inside.305 = and i1 %descriptor.owner.offset.valid.303, %descriptor.extent.inside.301
  %descriptor.range.valid.304 = and i1 %descriptor.range.inside.305, %descriptor.payload.inside.302
  %descriptor.type.valid.306 = icmp eq i32 8, 8
  %descriptor.valid.307 = and i1 %descriptor.range.valid.304, %descriptor.type.valid.306
  br i1 %descriptor.valid.307, label %descriptor.valid.308, label %descriptor.invalid.309
descriptor.invalid.309:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.308:
  %descriptor.initialized.status.310 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.47, i32 %descriptor.value.49)
  %helper.ok.311 = icmp eq i32 %descriptor.initialized.status.310, 0
  br i1 %helper.ok.311, label %helper.continue.312, label %frame.failure.0
helper.continue.312:
  %local.is.active.313 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.313, label %local.descriptor.active.314, label %local.descriptor.inactive.315
local.descriptor.active.314:
  %local.check.offset.317 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.318 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.319 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.320 = load i32, ptr %local.owner.end.6, align 4
  %context.field.321 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.322 = load i32, ptr %context.field.321, align 4
  %stack.sub.325 = sub i32 %local.check.owner.end.320, %local.check.offset.317
  %descriptor.owner.inside.323 = icmp ule i32 %local.check.owner.end.320, %context.value.322
  %descriptor.offset.inside.324 = icmp ule i32 %local.check.offset.317, %local.check.owner.end.320
  %descriptor.extent.inside.326 = icmp ule i32 %local.check.extent.318, %stack.sub.325
  %descriptor.payload.inside.327 = icmp ule i32 %local.check.payload.319, %local.check.extent.318
  %descriptor.owner.offset.valid.328 = and i1 %descriptor.owner.inside.323, %descriptor.offset.inside.324
  %descriptor.range.inside.330 = and i1 %descriptor.owner.offset.valid.328, %descriptor.extent.inside.326
  %descriptor.range.valid.329 = and i1 %descriptor.range.inside.330, %descriptor.payload.inside.327
  br i1 %descriptor.range.valid.329, label %descriptor.valid.331, label %descriptor.invalid.332
descriptor.invalid.332:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.331:
  %descriptor.initialized.status.333 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.317, i32 %local.check.extent.318)
  %helper.ok.334 = icmp eq i32 %descriptor.initialized.status.333, 0
  br i1 %helper.ok.334, label %helper.continue.335, label %frame.failure.0
helper.continue.335:
  br label %local.descriptor.checked.316
local.descriptor.inactive.315:
  br label %local.descriptor.checked.316
local.descriptor.checked.316:
  %local.is.active.336 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.336, label %local.descriptor.active.337, label %local.descriptor.inactive.338
local.descriptor.active.337:
  %local.check.offset.340 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.341 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.342 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.343 = load i32, ptr %local.owner.end.12, align 4
  %context.field.344 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.345 = load i32, ptr %context.field.344, align 4
  %stack.sub.348 = sub i32 %local.check.owner.end.343, %local.check.offset.340
  %descriptor.owner.inside.346 = icmp ule i32 %local.check.owner.end.343, %context.value.345
  %descriptor.offset.inside.347 = icmp ule i32 %local.check.offset.340, %local.check.owner.end.343
  %descriptor.extent.inside.349 = icmp ule i32 %local.check.extent.341, %stack.sub.348
  %descriptor.payload.inside.350 = icmp ule i32 %local.check.payload.342, %local.check.extent.341
  %descriptor.owner.offset.valid.351 = and i1 %descriptor.owner.inside.346, %descriptor.offset.inside.347
  %descriptor.range.inside.353 = and i1 %descriptor.owner.offset.valid.351, %descriptor.extent.inside.349
  %descriptor.range.valid.352 = and i1 %descriptor.range.inside.353, %descriptor.payload.inside.350
  br i1 %descriptor.range.valid.352, label %descriptor.valid.354, label %descriptor.invalid.355
descriptor.invalid.355:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.354:
  %descriptor.initialized.status.356 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.340, i32 %local.check.extent.341)
  %helper.ok.357 = icmp eq i32 %descriptor.initialized.status.356, 0
  br i1 %helper.ok.357, label %helper.continue.358, label %frame.failure.0
helper.continue.358:
  br label %local.descriptor.checked.339
local.descriptor.inactive.338:
  br label %local.descriptor.checked.339
local.descriptor.checked.339:
  %local.is.active.359 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.359, label %local.descriptor.active.360, label %local.descriptor.inactive.361
local.descriptor.active.360:
  %local.check.offset.363 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.364 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.365 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.366 = load i32, ptr %local.owner.end.18, align 4
  %context.field.367 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.368 = load i32, ptr %context.field.367, align 4
  %stack.sub.371 = sub i32 %local.check.owner.end.366, %local.check.offset.363
  %descriptor.owner.inside.369 = icmp ule i32 %local.check.owner.end.366, %context.value.368
  %descriptor.offset.inside.370 = icmp ule i32 %local.check.offset.363, %local.check.owner.end.366
  %descriptor.extent.inside.372 = icmp ule i32 %local.check.extent.364, %stack.sub.371
  %descriptor.payload.inside.373 = icmp ule i32 %local.check.payload.365, %local.check.extent.364
  %descriptor.owner.offset.valid.374 = and i1 %descriptor.owner.inside.369, %descriptor.offset.inside.370
  %descriptor.range.inside.376 = and i1 %descriptor.owner.offset.valid.374, %descriptor.extent.inside.372
  %descriptor.range.valid.375 = and i1 %descriptor.range.inside.376, %descriptor.payload.inside.373
  br i1 %descriptor.range.valid.375, label %descriptor.valid.377, label %descriptor.invalid.378
descriptor.invalid.378:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.377:
  %descriptor.initialized.status.379 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.363, i32 %local.check.extent.364)
  %helper.ok.380 = icmp eq i32 %descriptor.initialized.status.379, 0
  br i1 %helper.ok.380, label %helper.continue.381, label %frame.failure.0
helper.continue.381:
  br label %local.descriptor.checked.362
local.descriptor.inactive.361:
  br label %local.descriptor.checked.362
local.descriptor.checked.362:
  %local.is.active.382 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.382, label %local.descriptor.active.383, label %local.descriptor.inactive.384
local.descriptor.active.383:
  %local.check.offset.386 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.387 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.388 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.389 = load i32, ptr %local.owner.end.24, align 4
  %context.field.390 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.391 = load i32, ptr %context.field.390, align 4
  %stack.sub.394 = sub i32 %local.check.owner.end.389, %local.check.offset.386
  %descriptor.owner.inside.392 = icmp ule i32 %local.check.owner.end.389, %context.value.391
  %descriptor.offset.inside.393 = icmp ule i32 %local.check.offset.386, %local.check.owner.end.389
  %descriptor.extent.inside.395 = icmp ule i32 %local.check.extent.387, %stack.sub.394
  %descriptor.payload.inside.396 = icmp ule i32 %local.check.payload.388, %local.check.extent.387
  %descriptor.owner.offset.valid.397 = and i1 %descriptor.owner.inside.392, %descriptor.offset.inside.393
  %descriptor.range.inside.399 = and i1 %descriptor.owner.offset.valid.397, %descriptor.extent.inside.395
  %descriptor.range.valid.398 = and i1 %descriptor.range.inside.399, %descriptor.payload.inside.396
  br i1 %descriptor.range.valid.398, label %descriptor.valid.400, label %descriptor.invalid.401
descriptor.invalid.401:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.400:
  %descriptor.initialized.status.402 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.386, i32 %local.check.extent.387)
  %helper.ok.403 = icmp eq i32 %descriptor.initialized.status.402, 0
  br i1 %helper.ok.403, label %helper.continue.404, label %frame.failure.0
helper.continue.404:
  br label %local.descriptor.checked.385
local.descriptor.inactive.384:
  br label %local.descriptor.checked.385
local.descriptor.checked.385:
  %local.is.active.405 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.405, label %local.descriptor.active.406, label %local.descriptor.inactive.407
local.descriptor.active.406:
  %local.check.offset.409 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.410 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.411 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.412 = load i32, ptr %local.owner.end.30, align 4
  %context.field.413 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.414 = load i32, ptr %context.field.413, align 4
  %stack.sub.417 = sub i32 %local.check.owner.end.412, %local.check.offset.409
  %descriptor.owner.inside.415 = icmp ule i32 %local.check.owner.end.412, %context.value.414
  %descriptor.offset.inside.416 = icmp ule i32 %local.check.offset.409, %local.check.owner.end.412
  %descriptor.extent.inside.418 = icmp ule i32 %local.check.extent.410, %stack.sub.417
  %descriptor.payload.inside.419 = icmp ule i32 %local.check.payload.411, %local.check.extent.410
  %descriptor.owner.offset.valid.420 = and i1 %descriptor.owner.inside.415, %descriptor.offset.inside.416
  %descriptor.range.inside.422 = and i1 %descriptor.owner.offset.valid.420, %descriptor.extent.inside.418
  %descriptor.range.valid.421 = and i1 %descriptor.range.inside.422, %descriptor.payload.inside.419
  br i1 %descriptor.range.valid.421, label %descriptor.valid.423, label %descriptor.invalid.424
descriptor.invalid.424:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.423:
  %descriptor.initialized.status.425 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.409, i32 %local.check.extent.410)
  %helper.ok.426 = icmp eq i32 %descriptor.initialized.status.425, 0
  br i1 %helper.ok.426, label %helper.continue.427, label %frame.failure.0
helper.continue.427:
  br label %local.descriptor.checked.408
local.descriptor.inactive.407:
  br label %local.descriptor.checked.408
local.descriptor.checked.408:
  %step.status.428 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.429 = icmp eq i32 %step.status.428, 0
  br i1 %helper.ok.429, label %helper.continue.430, label %frame.failure.0
helper.continue.430:
  store i1 true, ptr %local.active.14, align 1
  store i32 %descriptor.value.47, ptr %local.offset.15, align 4
  store i32 %descriptor.value.49, ptr %local.extent.16, align 4
  store i32 %descriptor.value.51, ptr %local.payload.17, align 4
  store i32 %descriptor.value.53, ptr %local.owner.end.18, align 4
  store i32 8, ptr %local.type.19, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %descriptor.value.47, i32 20, i32 %descriptor.value.51, i32 %descriptor.value.53, i32 %descriptor.value.49)
  %context.field.431 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.432 = load i32, ptr %context.field.431, align 4
  %runtime.ok.433 = icmp eq i32 %context.value.432, 0
  br i1 %runtime.ok.433, label %runtime.continue.434, label %frame.failure.0
runtime.continue.434:
  %local.is.active.435 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.435, label %local.descriptor.active.436, label %local.descriptor.inactive.437
local.descriptor.active.436:
  %local.check.offset.439 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.440 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.441 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.442 = load i32, ptr %local.owner.end.6, align 4
  %context.field.443 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.444 = load i32, ptr %context.field.443, align 4
  %stack.sub.447 = sub i32 %local.check.owner.end.442, %local.check.offset.439
  %descriptor.owner.inside.445 = icmp ule i32 %local.check.owner.end.442, %context.value.444
  %descriptor.offset.inside.446 = icmp ule i32 %local.check.offset.439, %local.check.owner.end.442
  %descriptor.extent.inside.448 = icmp ule i32 %local.check.extent.440, %stack.sub.447
  %descriptor.payload.inside.449 = icmp ule i32 %local.check.payload.441, %local.check.extent.440
  %descriptor.owner.offset.valid.450 = and i1 %descriptor.owner.inside.445, %descriptor.offset.inside.446
  %descriptor.range.inside.452 = and i1 %descriptor.owner.offset.valid.450, %descriptor.extent.inside.448
  %descriptor.range.valid.451 = and i1 %descriptor.range.inside.452, %descriptor.payload.inside.449
  br i1 %descriptor.range.valid.451, label %descriptor.valid.453, label %descriptor.invalid.454
descriptor.invalid.454:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.453:
  %descriptor.initialized.status.455 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.439, i32 %local.check.extent.440)
  %helper.ok.456 = icmp eq i32 %descriptor.initialized.status.455, 0
  br i1 %helper.ok.456, label %helper.continue.457, label %frame.failure.0
helper.continue.457:
  br label %local.descriptor.checked.438
local.descriptor.inactive.437:
  br label %local.descriptor.checked.438
local.descriptor.checked.438:
  %local.is.active.458 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.458, label %local.descriptor.active.459, label %local.descriptor.inactive.460
local.descriptor.active.459:
  %local.check.offset.462 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.463 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.464 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.465 = load i32, ptr %local.owner.end.12, align 4
  %context.field.466 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.467 = load i32, ptr %context.field.466, align 4
  %stack.sub.470 = sub i32 %local.check.owner.end.465, %local.check.offset.462
  %descriptor.owner.inside.468 = icmp ule i32 %local.check.owner.end.465, %context.value.467
  %descriptor.offset.inside.469 = icmp ule i32 %local.check.offset.462, %local.check.owner.end.465
  %descriptor.extent.inside.471 = icmp ule i32 %local.check.extent.463, %stack.sub.470
  %descriptor.payload.inside.472 = icmp ule i32 %local.check.payload.464, %local.check.extent.463
  %descriptor.owner.offset.valid.473 = and i1 %descriptor.owner.inside.468, %descriptor.offset.inside.469
  %descriptor.range.inside.475 = and i1 %descriptor.owner.offset.valid.473, %descriptor.extent.inside.471
  %descriptor.range.valid.474 = and i1 %descriptor.range.inside.475, %descriptor.payload.inside.472
  br i1 %descriptor.range.valid.474, label %descriptor.valid.476, label %descriptor.invalid.477
descriptor.invalid.477:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.476:
  %descriptor.initialized.status.478 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.462, i32 %local.check.extent.463)
  %helper.ok.479 = icmp eq i32 %descriptor.initialized.status.478, 0
  br i1 %helper.ok.479, label %helper.continue.480, label %frame.failure.0
helper.continue.480:
  br label %local.descriptor.checked.461
local.descriptor.inactive.460:
  br label %local.descriptor.checked.461
local.descriptor.checked.461:
  %local.is.active.481 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.481, label %local.descriptor.active.482, label %local.descriptor.inactive.483
local.descriptor.active.482:
  %local.check.offset.485 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.486 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.487 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.488 = load i32, ptr %local.owner.end.18, align 4
  %context.field.489 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.490 = load i32, ptr %context.field.489, align 4
  %stack.sub.493 = sub i32 %local.check.owner.end.488, %local.check.offset.485
  %descriptor.owner.inside.491 = icmp ule i32 %local.check.owner.end.488, %context.value.490
  %descriptor.offset.inside.492 = icmp ule i32 %local.check.offset.485, %local.check.owner.end.488
  %descriptor.extent.inside.494 = icmp ule i32 %local.check.extent.486, %stack.sub.493
  %descriptor.payload.inside.495 = icmp ule i32 %local.check.payload.487, %local.check.extent.486
  %descriptor.owner.offset.valid.496 = and i1 %descriptor.owner.inside.491, %descriptor.offset.inside.492
  %descriptor.range.inside.498 = and i1 %descriptor.owner.offset.valid.496, %descriptor.extent.inside.494
  %descriptor.range.valid.497 = and i1 %descriptor.range.inside.498, %descriptor.payload.inside.495
  br i1 %descriptor.range.valid.497, label %descriptor.valid.499, label %descriptor.invalid.500
descriptor.invalid.500:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.499:
  %descriptor.initialized.status.501 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.485, i32 %local.check.extent.486)
  %helper.ok.502 = icmp eq i32 %descriptor.initialized.status.501, 0
  br i1 %helper.ok.502, label %helper.continue.503, label %frame.failure.0
helper.continue.503:
  br label %local.descriptor.checked.484
local.descriptor.inactive.483:
  br label %local.descriptor.checked.484
local.descriptor.checked.484:
  %local.is.active.504 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.504, label %local.descriptor.active.505, label %local.descriptor.inactive.506
local.descriptor.active.505:
  %local.check.offset.508 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.509 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.510 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.511 = load i32, ptr %local.owner.end.24, align 4
  %context.field.512 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.513 = load i32, ptr %context.field.512, align 4
  %stack.sub.516 = sub i32 %local.check.owner.end.511, %local.check.offset.508
  %descriptor.owner.inside.514 = icmp ule i32 %local.check.owner.end.511, %context.value.513
  %descriptor.offset.inside.515 = icmp ule i32 %local.check.offset.508, %local.check.owner.end.511
  %descriptor.extent.inside.517 = icmp ule i32 %local.check.extent.509, %stack.sub.516
  %descriptor.payload.inside.518 = icmp ule i32 %local.check.payload.510, %local.check.extent.509
  %descriptor.owner.offset.valid.519 = and i1 %descriptor.owner.inside.514, %descriptor.offset.inside.515
  %descriptor.range.inside.521 = and i1 %descriptor.owner.offset.valid.519, %descriptor.extent.inside.517
  %descriptor.range.valid.520 = and i1 %descriptor.range.inside.521, %descriptor.payload.inside.518
  br i1 %descriptor.range.valid.520, label %descriptor.valid.522, label %descriptor.invalid.523
descriptor.invalid.523:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.522:
  %descriptor.initialized.status.524 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.508, i32 %local.check.extent.509)
  %helper.ok.525 = icmp eq i32 %descriptor.initialized.status.524, 0
  br i1 %helper.ok.525, label %helper.continue.526, label %frame.failure.0
helper.continue.526:
  br label %local.descriptor.checked.507
local.descriptor.inactive.506:
  br label %local.descriptor.checked.507
local.descriptor.checked.507:
  %local.is.active.527 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.527, label %local.descriptor.active.528, label %local.descriptor.inactive.529
local.descriptor.active.528:
  %local.check.offset.531 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.532 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.533 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.534 = load i32, ptr %local.owner.end.30, align 4
  %context.field.535 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.536 = load i32, ptr %context.field.535, align 4
  %stack.sub.539 = sub i32 %local.check.owner.end.534, %local.check.offset.531
  %descriptor.owner.inside.537 = icmp ule i32 %local.check.owner.end.534, %context.value.536
  %descriptor.offset.inside.538 = icmp ule i32 %local.check.offset.531, %local.check.owner.end.534
  %descriptor.extent.inside.540 = icmp ule i32 %local.check.extent.532, %stack.sub.539
  %descriptor.payload.inside.541 = icmp ule i32 %local.check.payload.533, %local.check.extent.532
  %descriptor.owner.offset.valid.542 = and i1 %descriptor.owner.inside.537, %descriptor.offset.inside.538
  %descriptor.range.inside.544 = and i1 %descriptor.owner.offset.valid.542, %descriptor.extent.inside.540
  %descriptor.range.valid.543 = and i1 %descriptor.range.inside.544, %descriptor.payload.inside.541
  br i1 %descriptor.range.valid.543, label %descriptor.valid.545, label %descriptor.invalid.546
descriptor.invalid.546:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.545:
  %descriptor.initialized.status.547 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.531, i32 %local.check.extent.532)
  %helper.ok.548 = icmp eq i32 %descriptor.initialized.status.547, 0
  br i1 %helper.ok.548, label %helper.continue.549, label %frame.failure.0
helper.continue.549:
  br label %local.descriptor.checked.530
local.descriptor.inactive.529:
  br label %local.descriptor.checked.530
local.descriptor.checked.530:
  %step.status.550 = call i32 @al_owning_charge_step(ptr %ctx, i32 6)
  %helper.ok.551 = icmp eq i32 %step.status.550, 0
  br i1 %helper.ok.551, label %helper.continue.552, label %frame.failure.0
helper.continue.552:
  %local.resolved.offset.553 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.554 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.555 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.556 = load i32, ptr %local.owner.end.6, align 4
  %context.field.557 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.558 = load i32, ptr %context.field.557, align 4
  %stack.sub.561 = sub i32 %local.resolved.owner.end.556, %local.resolved.offset.553
  %descriptor.owner.inside.559 = icmp ule i32 %local.resolved.owner.end.556, %context.value.558
  %descriptor.offset.inside.560 = icmp ule i32 %local.resolved.offset.553, %local.resolved.owner.end.556
  %descriptor.extent.inside.562 = icmp ule i32 %local.resolved.extent.554, %stack.sub.561
  %descriptor.payload.inside.563 = icmp ule i32 %local.resolved.payload.555, %local.resolved.extent.554
  %descriptor.owner.offset.valid.564 = and i1 %descriptor.owner.inside.559, %descriptor.offset.inside.560
  %descriptor.range.inside.566 = and i1 %descriptor.owner.offset.valid.564, %descriptor.extent.inside.562
  %descriptor.range.valid.565 = and i1 %descriptor.range.inside.566, %descriptor.payload.inside.563
  %descriptor.type.valid.567 = icmp eq i32 2, 2
  %descriptor.valid.568 = and i1 %descriptor.range.valid.565, %descriptor.type.valid.567
  br i1 %descriptor.valid.568, label %descriptor.valid.569, label %descriptor.invalid.570
descriptor.invalid.570:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.569:
  %descriptor.initialized.status.571 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.553, i32 %local.resolved.extent.554)
  %helper.ok.572 = icmp eq i32 %descriptor.initialized.status.571, 0
  br i1 %helper.ok.572, label %helper.continue.573, label %frame.failure.0
helper.continue.573:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %local.resolved.offset.553, i32 20, i32 %local.resolved.payload.555, i32 %local.resolved.owner.end.556, i32 %local.resolved.extent.554)
  %context.field.574 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.575 = load i32, ptr %context.field.574, align 4
  %runtime.ok.576 = icmp eq i32 %context.value.575, 0
  br i1 %runtime.ok.576, label %runtime.continue.577, label %frame.failure.0
runtime.continue.577:
  %context.field.578 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.579 = load i32, ptr %context.field.578, align 4
  %stack.sub.582 = sub i32 %local.resolved.owner.end.556, %local.resolved.offset.553
  %descriptor.owner.inside.580 = icmp ule i32 %local.resolved.owner.end.556, %context.value.579
  %descriptor.offset.inside.581 = icmp ule i32 %local.resolved.offset.553, %local.resolved.owner.end.556
  %descriptor.extent.inside.583 = icmp ule i32 %local.resolved.extent.554, %stack.sub.582
  %descriptor.payload.inside.584 = icmp ule i32 %local.resolved.payload.555, %local.resolved.extent.554
  %descriptor.owner.offset.valid.585 = and i1 %descriptor.owner.inside.580, %descriptor.offset.inside.581
  %descriptor.range.inside.587 = and i1 %descriptor.owner.offset.valid.585, %descriptor.extent.inside.583
  %descriptor.range.valid.586 = and i1 %descriptor.range.inside.587, %descriptor.payload.inside.584
  %descriptor.type.valid.588 = icmp eq i32 2, 2
  %descriptor.valid.589 = and i1 %descriptor.range.valid.586, %descriptor.type.valid.588
  br i1 %descriptor.valid.589, label %descriptor.valid.590, label %descriptor.invalid.591
descriptor.invalid.591:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.590:
  %descriptor.initialized.status.592 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.553, i32 %local.resolved.extent.554)
  %helper.ok.593 = icmp eq i32 %descriptor.initialized.status.592, 0
  br i1 %helper.ok.593, label %helper.continue.594, label %frame.failure.0
helper.continue.594:
  %local.is.active.595 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.595, label %local.descriptor.active.596, label %local.descriptor.inactive.597
local.descriptor.active.596:
  %local.check.offset.599 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.600 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.601 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.602 = load i32, ptr %local.owner.end.6, align 4
  %context.field.603 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.604 = load i32, ptr %context.field.603, align 4
  %stack.sub.607 = sub i32 %local.check.owner.end.602, %local.check.offset.599
  %descriptor.owner.inside.605 = icmp ule i32 %local.check.owner.end.602, %context.value.604
  %descriptor.offset.inside.606 = icmp ule i32 %local.check.offset.599, %local.check.owner.end.602
  %descriptor.extent.inside.608 = icmp ule i32 %local.check.extent.600, %stack.sub.607
  %descriptor.payload.inside.609 = icmp ule i32 %local.check.payload.601, %local.check.extent.600
  %descriptor.owner.offset.valid.610 = and i1 %descriptor.owner.inside.605, %descriptor.offset.inside.606
  %descriptor.range.inside.612 = and i1 %descriptor.owner.offset.valid.610, %descriptor.extent.inside.608
  %descriptor.range.valid.611 = and i1 %descriptor.range.inside.612, %descriptor.payload.inside.609
  br i1 %descriptor.range.valid.611, label %descriptor.valid.613, label %descriptor.invalid.614
descriptor.invalid.614:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.613:
  %descriptor.initialized.status.615 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.599, i32 %local.check.extent.600)
  %helper.ok.616 = icmp eq i32 %descriptor.initialized.status.615, 0
  br i1 %helper.ok.616, label %helper.continue.617, label %frame.failure.0
helper.continue.617:
  br label %local.descriptor.checked.598
local.descriptor.inactive.597:
  br label %local.descriptor.checked.598
local.descriptor.checked.598:
  %local.is.active.618 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.618, label %local.descriptor.active.619, label %local.descriptor.inactive.620
local.descriptor.active.619:
  %local.check.offset.622 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.623 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.624 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.625 = load i32, ptr %local.owner.end.12, align 4
  %context.field.626 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.627 = load i32, ptr %context.field.626, align 4
  %stack.sub.630 = sub i32 %local.check.owner.end.625, %local.check.offset.622
  %descriptor.owner.inside.628 = icmp ule i32 %local.check.owner.end.625, %context.value.627
  %descriptor.offset.inside.629 = icmp ule i32 %local.check.offset.622, %local.check.owner.end.625
  %descriptor.extent.inside.631 = icmp ule i32 %local.check.extent.623, %stack.sub.630
  %descriptor.payload.inside.632 = icmp ule i32 %local.check.payload.624, %local.check.extent.623
  %descriptor.owner.offset.valid.633 = and i1 %descriptor.owner.inside.628, %descriptor.offset.inside.629
  %descriptor.range.inside.635 = and i1 %descriptor.owner.offset.valid.633, %descriptor.extent.inside.631
  %descriptor.range.valid.634 = and i1 %descriptor.range.inside.635, %descriptor.payload.inside.632
  br i1 %descriptor.range.valid.634, label %descriptor.valid.636, label %descriptor.invalid.637
descriptor.invalid.637:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.636:
  %descriptor.initialized.status.638 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.622, i32 %local.check.extent.623)
  %helper.ok.639 = icmp eq i32 %descriptor.initialized.status.638, 0
  br i1 %helper.ok.639, label %helper.continue.640, label %frame.failure.0
helper.continue.640:
  br label %local.descriptor.checked.621
local.descriptor.inactive.620:
  br label %local.descriptor.checked.621
local.descriptor.checked.621:
  %local.is.active.641 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.641, label %local.descriptor.active.642, label %local.descriptor.inactive.643
local.descriptor.active.642:
  %local.check.offset.645 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.646 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.647 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.648 = load i32, ptr %local.owner.end.18, align 4
  %context.field.649 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.650 = load i32, ptr %context.field.649, align 4
  %stack.sub.653 = sub i32 %local.check.owner.end.648, %local.check.offset.645
  %descriptor.owner.inside.651 = icmp ule i32 %local.check.owner.end.648, %context.value.650
  %descriptor.offset.inside.652 = icmp ule i32 %local.check.offset.645, %local.check.owner.end.648
  %descriptor.extent.inside.654 = icmp ule i32 %local.check.extent.646, %stack.sub.653
  %descriptor.payload.inside.655 = icmp ule i32 %local.check.payload.647, %local.check.extent.646
  %descriptor.owner.offset.valid.656 = and i1 %descriptor.owner.inside.651, %descriptor.offset.inside.652
  %descriptor.range.inside.658 = and i1 %descriptor.owner.offset.valid.656, %descriptor.extent.inside.654
  %descriptor.range.valid.657 = and i1 %descriptor.range.inside.658, %descriptor.payload.inside.655
  br i1 %descriptor.range.valid.657, label %descriptor.valid.659, label %descriptor.invalid.660
descriptor.invalid.660:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.659:
  %descriptor.initialized.status.661 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.645, i32 %local.check.extent.646)
  %helper.ok.662 = icmp eq i32 %descriptor.initialized.status.661, 0
  br i1 %helper.ok.662, label %helper.continue.663, label %frame.failure.0
helper.continue.663:
  br label %local.descriptor.checked.644
local.descriptor.inactive.643:
  br label %local.descriptor.checked.644
local.descriptor.checked.644:
  %local.is.active.664 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.664, label %local.descriptor.active.665, label %local.descriptor.inactive.666
local.descriptor.active.665:
  %local.check.offset.668 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.669 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.670 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.671 = load i32, ptr %local.owner.end.24, align 4
  %context.field.672 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.673 = load i32, ptr %context.field.672, align 4
  %stack.sub.676 = sub i32 %local.check.owner.end.671, %local.check.offset.668
  %descriptor.owner.inside.674 = icmp ule i32 %local.check.owner.end.671, %context.value.673
  %descriptor.offset.inside.675 = icmp ule i32 %local.check.offset.668, %local.check.owner.end.671
  %descriptor.extent.inside.677 = icmp ule i32 %local.check.extent.669, %stack.sub.676
  %descriptor.payload.inside.678 = icmp ule i32 %local.check.payload.670, %local.check.extent.669
  %descriptor.owner.offset.valid.679 = and i1 %descriptor.owner.inside.674, %descriptor.offset.inside.675
  %descriptor.range.inside.681 = and i1 %descriptor.owner.offset.valid.679, %descriptor.extent.inside.677
  %descriptor.range.valid.680 = and i1 %descriptor.range.inside.681, %descriptor.payload.inside.678
  br i1 %descriptor.range.valid.680, label %descriptor.valid.682, label %descriptor.invalid.683
descriptor.invalid.683:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.682:
  %descriptor.initialized.status.684 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.668, i32 %local.check.extent.669)
  %helper.ok.685 = icmp eq i32 %descriptor.initialized.status.684, 0
  br i1 %helper.ok.685, label %helper.continue.686, label %frame.failure.0
helper.continue.686:
  br label %local.descriptor.checked.667
local.descriptor.inactive.666:
  br label %local.descriptor.checked.667
local.descriptor.checked.667:
  %local.is.active.687 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.687, label %local.descriptor.active.688, label %local.descriptor.inactive.689
local.descriptor.active.688:
  %local.check.offset.691 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.692 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.693 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.694 = load i32, ptr %local.owner.end.30, align 4
  %context.field.695 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.696 = load i32, ptr %context.field.695, align 4
  %stack.sub.699 = sub i32 %local.check.owner.end.694, %local.check.offset.691
  %descriptor.owner.inside.697 = icmp ule i32 %local.check.owner.end.694, %context.value.696
  %descriptor.offset.inside.698 = icmp ule i32 %local.check.offset.691, %local.check.owner.end.694
  %descriptor.extent.inside.700 = icmp ule i32 %local.check.extent.692, %stack.sub.699
  %descriptor.payload.inside.701 = icmp ule i32 %local.check.payload.693, %local.check.extent.692
  %descriptor.owner.offset.valid.702 = and i1 %descriptor.owner.inside.697, %descriptor.offset.inside.698
  %descriptor.range.inside.704 = and i1 %descriptor.owner.offset.valid.702, %descriptor.extent.inside.700
  %descriptor.range.valid.703 = and i1 %descriptor.range.inside.704, %descriptor.payload.inside.701
  br i1 %descriptor.range.valid.703, label %descriptor.valid.705, label %descriptor.invalid.706
descriptor.invalid.706:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.705:
  %descriptor.initialized.status.707 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.691, i32 %local.check.extent.692)
  %helper.ok.708 = icmp eq i32 %descriptor.initialized.status.707, 0
  br i1 %helper.ok.708, label %helper.continue.709, label %frame.failure.0
helper.continue.709:
  br label %local.descriptor.checked.690
local.descriptor.inactive.689:
  br label %local.descriptor.checked.690
local.descriptor.checked.690:
  %step.status.710 = call i32 @al_owning_charge_step(ptr %ctx, i32 7)
  %helper.ok.711 = icmp eq i32 %step.status.710, 0
  br i1 %helper.ok.711, label %helper.continue.712, label %frame.failure.0
helper.continue.712:
  %if.condition.raw.713 = call i64 @al_owning_load_i64(ptr %ctx, i32 %local.resolved.offset.553)
  %context.field.714 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.715 = load i32, ptr %context.field.714, align 4
  %runtime.ok.716 = icmp eq i32 %context.value.715, 0
  br i1 %runtime.ok.716, label %runtime.continue.717, label %frame.failure.0
runtime.continue.717:
  %if.condition.718 = icmp ne i64 %if.condition.raw.713, 0
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 2, i32 %local.resolved.offset.553, i32 %local.resolved.extent.554, i32 %local.resolved.payload.555, i32 0, i32 0)
  %context.field.719 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.720 = load i32, ptr %context.field.719, align 4
  %runtime.ok.721 = icmp eq i32 %context.value.720, 0
  br i1 %runtime.ok.721, label %runtime.continue.722, label %frame.failure.0
runtime.continue.722:
  br i1 %if.condition.718, label %if.then.723, label %if.else.724
if.then.723:
  %step.status.726 = call i32 @al_owning_charge_step(ptr %ctx, i32 8)
  %helper.ok.727 = icmp eq i32 %step.status.726, 0
  br i1 %helper.ok.727, label %helper.continue.728, label %frame.failure.0
helper.continue.728:
  %context.field.729 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.730 = load i32, ptr %context.field.729, align 4
  %step.status.731 = call i32 @al_owning_charge_step(ptr %ctx, i32 9)
  %helper.ok.732 = icmp eq i32 %step.status.731, 0
  br i1 %helper.ok.732, label %helper.continue.733, label %frame.failure.0
helper.continue.733:
  %local.resolved.offset.734 = load i32, ptr %local.offset.15, align 4
  %local.resolved.extent.735 = load i32, ptr %local.extent.16, align 4
  %local.resolved.payload.736 = load i32, ptr %local.payload.17, align 4
  %local.resolved.owner.end.737 = load i32, ptr %local.owner.end.18, align 4
  %context.field.738 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.739 = load i32, ptr %context.field.738, align 4
  %stack.sub.742 = sub i32 %local.resolved.owner.end.737, %local.resolved.offset.734
  %descriptor.owner.inside.740 = icmp ule i32 %local.resolved.owner.end.737, %context.value.739
  %descriptor.offset.inside.741 = icmp ule i32 %local.resolved.offset.734, %local.resolved.owner.end.737
  %descriptor.extent.inside.743 = icmp ule i32 %local.resolved.extent.735, %stack.sub.742
  %descriptor.payload.inside.744 = icmp ule i32 %local.resolved.payload.736, %local.resolved.extent.735
  %descriptor.owner.offset.valid.745 = and i1 %descriptor.owner.inside.740, %descriptor.offset.inside.741
  %descriptor.range.inside.747 = and i1 %descriptor.owner.offset.valid.745, %descriptor.extent.inside.743
  %descriptor.range.valid.746 = and i1 %descriptor.range.inside.747, %descriptor.payload.inside.744
  %descriptor.type.valid.748 = icmp eq i32 8, 8
  %descriptor.valid.749 = and i1 %descriptor.range.valid.746, %descriptor.type.valid.748
  br i1 %descriptor.valid.749, label %descriptor.valid.750, label %descriptor.invalid.751
descriptor.invalid.751:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.750:
  %descriptor.initialized.status.752 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.734, i32 %local.resolved.extent.735)
  %helper.ok.753 = icmp eq i32 %descriptor.initialized.status.752, 0
  br i1 %helper.ok.753, label %helper.continue.754, label %frame.failure.0
helper.continue.754:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %local.resolved.offset.734, i32 20, i32 %local.resolved.payload.736, i32 %local.resolved.owner.end.737, i32 %local.resolved.extent.735)
  %context.field.755 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.756 = load i32, ptr %context.field.755, align 4
  %runtime.ok.757 = icmp eq i32 %context.value.756, 0
  br i1 %runtime.ok.757, label %runtime.continue.758, label %frame.failure.0
runtime.continue.758:
  %context.field.759 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.760 = load i32, ptr %context.field.759, align 4
  %stack.sub.763 = sub i32 %local.resolved.owner.end.737, %local.resolved.offset.734
  %descriptor.owner.inside.761 = icmp ule i32 %local.resolved.owner.end.737, %context.value.760
  %descriptor.offset.inside.762 = icmp ule i32 %local.resolved.offset.734, %local.resolved.owner.end.737
  %descriptor.extent.inside.764 = icmp ule i32 %local.resolved.extent.735, %stack.sub.763
  %descriptor.payload.inside.765 = icmp ule i32 %local.resolved.payload.736, %local.resolved.extent.735
  %descriptor.owner.offset.valid.766 = and i1 %descriptor.owner.inside.761, %descriptor.offset.inside.762
  %descriptor.range.inside.768 = and i1 %descriptor.owner.offset.valid.766, %descriptor.extent.inside.764
  %descriptor.range.valid.767 = and i1 %descriptor.range.inside.768, %descriptor.payload.inside.765
  %descriptor.type.valid.769 = icmp eq i32 8, 8
  %descriptor.valid.770 = and i1 %descriptor.range.valid.767, %descriptor.type.valid.769
  br i1 %descriptor.valid.770, label %descriptor.valid.771, label %descriptor.invalid.772
descriptor.invalid.772:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.771:
  %descriptor.initialized.status.773 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.734, i32 %local.resolved.extent.735)
  %helper.ok.774 = icmp eq i32 %descriptor.initialized.status.773, 0
  br i1 %helper.ok.774, label %helper.continue.775, label %frame.failure.0
helper.continue.775:
  %local.is.active.776 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.776, label %local.descriptor.active.777, label %local.descriptor.inactive.778
local.descriptor.active.777:
  %local.check.offset.780 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.781 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.782 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.783 = load i32, ptr %local.owner.end.6, align 4
  %context.field.784 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.785 = load i32, ptr %context.field.784, align 4
  %stack.sub.788 = sub i32 %local.check.owner.end.783, %local.check.offset.780
  %descriptor.owner.inside.786 = icmp ule i32 %local.check.owner.end.783, %context.value.785
  %descriptor.offset.inside.787 = icmp ule i32 %local.check.offset.780, %local.check.owner.end.783
  %descriptor.extent.inside.789 = icmp ule i32 %local.check.extent.781, %stack.sub.788
  %descriptor.payload.inside.790 = icmp ule i32 %local.check.payload.782, %local.check.extent.781
  %descriptor.owner.offset.valid.791 = and i1 %descriptor.owner.inside.786, %descriptor.offset.inside.787
  %descriptor.range.inside.793 = and i1 %descriptor.owner.offset.valid.791, %descriptor.extent.inside.789
  %descriptor.range.valid.792 = and i1 %descriptor.range.inside.793, %descriptor.payload.inside.790
  br i1 %descriptor.range.valid.792, label %descriptor.valid.794, label %descriptor.invalid.795
descriptor.invalid.795:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.794:
  %descriptor.initialized.status.796 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.780, i32 %local.check.extent.781)
  %helper.ok.797 = icmp eq i32 %descriptor.initialized.status.796, 0
  br i1 %helper.ok.797, label %helper.continue.798, label %frame.failure.0
helper.continue.798:
  br label %local.descriptor.checked.779
local.descriptor.inactive.778:
  br label %local.descriptor.checked.779
local.descriptor.checked.779:
  %local.is.active.799 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.799, label %local.descriptor.active.800, label %local.descriptor.inactive.801
local.descriptor.active.800:
  %local.check.offset.803 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.804 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.805 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.806 = load i32, ptr %local.owner.end.12, align 4
  %context.field.807 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.808 = load i32, ptr %context.field.807, align 4
  %stack.sub.811 = sub i32 %local.check.owner.end.806, %local.check.offset.803
  %descriptor.owner.inside.809 = icmp ule i32 %local.check.owner.end.806, %context.value.808
  %descriptor.offset.inside.810 = icmp ule i32 %local.check.offset.803, %local.check.owner.end.806
  %descriptor.extent.inside.812 = icmp ule i32 %local.check.extent.804, %stack.sub.811
  %descriptor.payload.inside.813 = icmp ule i32 %local.check.payload.805, %local.check.extent.804
  %descriptor.owner.offset.valid.814 = and i1 %descriptor.owner.inside.809, %descriptor.offset.inside.810
  %descriptor.range.inside.816 = and i1 %descriptor.owner.offset.valid.814, %descriptor.extent.inside.812
  %descriptor.range.valid.815 = and i1 %descriptor.range.inside.816, %descriptor.payload.inside.813
  br i1 %descriptor.range.valid.815, label %descriptor.valid.817, label %descriptor.invalid.818
descriptor.invalid.818:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.817:
  %descriptor.initialized.status.819 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.803, i32 %local.check.extent.804)
  %helper.ok.820 = icmp eq i32 %descriptor.initialized.status.819, 0
  br i1 %helper.ok.820, label %helper.continue.821, label %frame.failure.0
helper.continue.821:
  br label %local.descriptor.checked.802
local.descriptor.inactive.801:
  br label %local.descriptor.checked.802
local.descriptor.checked.802:
  %local.is.active.822 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.822, label %local.descriptor.active.823, label %local.descriptor.inactive.824
local.descriptor.active.823:
  %local.check.offset.826 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.827 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.828 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.829 = load i32, ptr %local.owner.end.18, align 4
  %context.field.830 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.831 = load i32, ptr %context.field.830, align 4
  %stack.sub.834 = sub i32 %local.check.owner.end.829, %local.check.offset.826
  %descriptor.owner.inside.832 = icmp ule i32 %local.check.owner.end.829, %context.value.831
  %descriptor.offset.inside.833 = icmp ule i32 %local.check.offset.826, %local.check.owner.end.829
  %descriptor.extent.inside.835 = icmp ule i32 %local.check.extent.827, %stack.sub.834
  %descriptor.payload.inside.836 = icmp ule i32 %local.check.payload.828, %local.check.extent.827
  %descriptor.owner.offset.valid.837 = and i1 %descriptor.owner.inside.832, %descriptor.offset.inside.833
  %descriptor.range.inside.839 = and i1 %descriptor.owner.offset.valid.837, %descriptor.extent.inside.835
  %descriptor.range.valid.838 = and i1 %descriptor.range.inside.839, %descriptor.payload.inside.836
  br i1 %descriptor.range.valid.838, label %descriptor.valid.840, label %descriptor.invalid.841
descriptor.invalid.841:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.840:
  %descriptor.initialized.status.842 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.826, i32 %local.check.extent.827)
  %helper.ok.843 = icmp eq i32 %descriptor.initialized.status.842, 0
  br i1 %helper.ok.843, label %helper.continue.844, label %frame.failure.0
helper.continue.844:
  br label %local.descriptor.checked.825
local.descriptor.inactive.824:
  br label %local.descriptor.checked.825
local.descriptor.checked.825:
  %local.is.active.845 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.845, label %local.descriptor.active.846, label %local.descriptor.inactive.847
local.descriptor.active.846:
  %local.check.offset.849 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.850 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.851 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.852 = load i32, ptr %local.owner.end.24, align 4
  %context.field.853 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.854 = load i32, ptr %context.field.853, align 4
  %stack.sub.857 = sub i32 %local.check.owner.end.852, %local.check.offset.849
  %descriptor.owner.inside.855 = icmp ule i32 %local.check.owner.end.852, %context.value.854
  %descriptor.offset.inside.856 = icmp ule i32 %local.check.offset.849, %local.check.owner.end.852
  %descriptor.extent.inside.858 = icmp ule i32 %local.check.extent.850, %stack.sub.857
  %descriptor.payload.inside.859 = icmp ule i32 %local.check.payload.851, %local.check.extent.850
  %descriptor.owner.offset.valid.860 = and i1 %descriptor.owner.inside.855, %descriptor.offset.inside.856
  %descriptor.range.inside.862 = and i1 %descriptor.owner.offset.valid.860, %descriptor.extent.inside.858
  %descriptor.range.valid.861 = and i1 %descriptor.range.inside.862, %descriptor.payload.inside.859
  br i1 %descriptor.range.valid.861, label %descriptor.valid.863, label %descriptor.invalid.864
descriptor.invalid.864:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.863:
  %descriptor.initialized.status.865 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.849, i32 %local.check.extent.850)
  %helper.ok.866 = icmp eq i32 %descriptor.initialized.status.865, 0
  br i1 %helper.ok.866, label %helper.continue.867, label %frame.failure.0
helper.continue.867:
  br label %local.descriptor.checked.848
local.descriptor.inactive.847:
  br label %local.descriptor.checked.848
local.descriptor.checked.848:
  %local.is.active.868 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.868, label %local.descriptor.active.869, label %local.descriptor.inactive.870
local.descriptor.active.869:
  %local.check.offset.872 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.873 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.874 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.875 = load i32, ptr %local.owner.end.30, align 4
  %context.field.876 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.877 = load i32, ptr %context.field.876, align 4
  %stack.sub.880 = sub i32 %local.check.owner.end.875, %local.check.offset.872
  %descriptor.owner.inside.878 = icmp ule i32 %local.check.owner.end.875, %context.value.877
  %descriptor.offset.inside.879 = icmp ule i32 %local.check.offset.872, %local.check.owner.end.875
  %descriptor.extent.inside.881 = icmp ule i32 %local.check.extent.873, %stack.sub.880
  %descriptor.payload.inside.882 = icmp ule i32 %local.check.payload.874, %local.check.extent.873
  %descriptor.owner.offset.valid.883 = and i1 %descriptor.owner.inside.878, %descriptor.offset.inside.879
  %descriptor.range.inside.885 = and i1 %descriptor.owner.offset.valid.883, %descriptor.extent.inside.881
  %descriptor.range.valid.884 = and i1 %descriptor.range.inside.885, %descriptor.payload.inside.882
  br i1 %descriptor.range.valid.884, label %descriptor.valid.886, label %descriptor.invalid.887
descriptor.invalid.887:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.886:
  %descriptor.initialized.status.888 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.872, i32 %local.check.extent.873)
  %helper.ok.889 = icmp eq i32 %descriptor.initialized.status.888, 0
  br i1 %helper.ok.889, label %helper.continue.890, label %frame.failure.0
helper.continue.890:
  br label %local.descriptor.checked.871
local.descriptor.inactive.870:
  br label %local.descriptor.checked.871
local.descriptor.checked.871:
  %context.field.891 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.892 = load i32, ptr %context.field.891, align 4
  %stack.sub.893 = sub i32 %context.value.892, %context.value.730
  call void @al_owning_record_layout(ptr %ctx, i32 18, i32 0, i32 %context.value.730, i32 %stack.sub.893, i32 0, i32 0, i32 0)
  %context.field.894 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.895 = load i32, ptr %context.field.894, align 4
  %runtime.ok.896 = icmp eq i32 %context.value.895, 0
  br i1 %runtime.ok.896, label %runtime.continue.897, label %frame.failure.0
runtime.continue.897:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.730, i32 0, i32 0, i32 0)
  %context.field.898 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.899 = load i32, ptr %context.field.898, align 4
  %runtime.ok.900 = icmp eq i32 %context.value.899, 0
  br i1 %runtime.ok.900, label %runtime.continue.901, label %frame.failure.0
runtime.continue.901:
  %context.field.902 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.903 = load i32, ptr %context.field.902, align 4
  %stack.sub.906 = sub i32 %local.resolved.owner.end.737, %local.resolved.offset.734
  %descriptor.owner.inside.904 = icmp ule i32 %local.resolved.owner.end.737, %context.value.903
  %descriptor.offset.inside.905 = icmp ule i32 %local.resolved.offset.734, %local.resolved.owner.end.737
  %descriptor.extent.inside.907 = icmp ule i32 %local.resolved.extent.735, %stack.sub.906
  %descriptor.payload.inside.908 = icmp ule i32 %local.resolved.payload.736, %local.resolved.extent.735
  %descriptor.owner.offset.valid.909 = and i1 %descriptor.owner.inside.904, %descriptor.offset.inside.905
  %descriptor.range.inside.911 = and i1 %descriptor.owner.offset.valid.909, %descriptor.extent.inside.907
  %descriptor.range.valid.910 = and i1 %descriptor.range.inside.911, %descriptor.payload.inside.908
  %descriptor.type.valid.912 = icmp eq i32 8, 8
  %descriptor.valid.913 = and i1 %descriptor.range.valid.910, %descriptor.type.valid.912
  br i1 %descriptor.valid.913, label %descriptor.valid.914, label %descriptor.invalid.915
descriptor.invalid.915:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.914:
  %descriptor.initialized.status.916 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.734, i32 %local.resolved.extent.735)
  %helper.ok.917 = icmp eq i32 %descriptor.initialized.status.916, 0
  br i1 %helper.ok.917, label %helper.continue.918, label %frame.failure.0
helper.continue.918:
  %local.is.active.919 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.919, label %local.descriptor.active.920, label %local.descriptor.inactive.921
local.descriptor.active.920:
  %local.check.offset.923 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.924 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.925 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.926 = load i32, ptr %local.owner.end.6, align 4
  %context.field.927 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.928 = load i32, ptr %context.field.927, align 4
  %stack.sub.931 = sub i32 %local.check.owner.end.926, %local.check.offset.923
  %descriptor.owner.inside.929 = icmp ule i32 %local.check.owner.end.926, %context.value.928
  %descriptor.offset.inside.930 = icmp ule i32 %local.check.offset.923, %local.check.owner.end.926
  %descriptor.extent.inside.932 = icmp ule i32 %local.check.extent.924, %stack.sub.931
  %descriptor.payload.inside.933 = icmp ule i32 %local.check.payload.925, %local.check.extent.924
  %descriptor.owner.offset.valid.934 = and i1 %descriptor.owner.inside.929, %descriptor.offset.inside.930
  %descriptor.range.inside.936 = and i1 %descriptor.owner.offset.valid.934, %descriptor.extent.inside.932
  %descriptor.range.valid.935 = and i1 %descriptor.range.inside.936, %descriptor.payload.inside.933
  br i1 %descriptor.range.valid.935, label %descriptor.valid.937, label %descriptor.invalid.938
descriptor.invalid.938:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.937:
  %descriptor.initialized.status.939 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.923, i32 %local.check.extent.924)
  %helper.ok.940 = icmp eq i32 %descriptor.initialized.status.939, 0
  br i1 %helper.ok.940, label %helper.continue.941, label %frame.failure.0
helper.continue.941:
  br label %local.descriptor.checked.922
local.descriptor.inactive.921:
  br label %local.descriptor.checked.922
local.descriptor.checked.922:
  %local.is.active.942 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.942, label %local.descriptor.active.943, label %local.descriptor.inactive.944
local.descriptor.active.943:
  %local.check.offset.946 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.947 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.948 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.949 = load i32, ptr %local.owner.end.12, align 4
  %context.field.950 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.951 = load i32, ptr %context.field.950, align 4
  %stack.sub.954 = sub i32 %local.check.owner.end.949, %local.check.offset.946
  %descriptor.owner.inside.952 = icmp ule i32 %local.check.owner.end.949, %context.value.951
  %descriptor.offset.inside.953 = icmp ule i32 %local.check.offset.946, %local.check.owner.end.949
  %descriptor.extent.inside.955 = icmp ule i32 %local.check.extent.947, %stack.sub.954
  %descriptor.payload.inside.956 = icmp ule i32 %local.check.payload.948, %local.check.extent.947
  %descriptor.owner.offset.valid.957 = and i1 %descriptor.owner.inside.952, %descriptor.offset.inside.953
  %descriptor.range.inside.959 = and i1 %descriptor.owner.offset.valid.957, %descriptor.extent.inside.955
  %descriptor.range.valid.958 = and i1 %descriptor.range.inside.959, %descriptor.payload.inside.956
  br i1 %descriptor.range.valid.958, label %descriptor.valid.960, label %descriptor.invalid.961
descriptor.invalid.961:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.960:
  %descriptor.initialized.status.962 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.946, i32 %local.check.extent.947)
  %helper.ok.963 = icmp eq i32 %descriptor.initialized.status.962, 0
  br i1 %helper.ok.963, label %helper.continue.964, label %frame.failure.0
helper.continue.964:
  br label %local.descriptor.checked.945
local.descriptor.inactive.944:
  br label %local.descriptor.checked.945
local.descriptor.checked.945:
  %local.is.active.965 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.965, label %local.descriptor.active.966, label %local.descriptor.inactive.967
local.descriptor.active.966:
  %local.check.offset.969 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.970 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.971 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.972 = load i32, ptr %local.owner.end.18, align 4
  %context.field.973 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.974 = load i32, ptr %context.field.973, align 4
  %stack.sub.977 = sub i32 %local.check.owner.end.972, %local.check.offset.969
  %descriptor.owner.inside.975 = icmp ule i32 %local.check.owner.end.972, %context.value.974
  %descriptor.offset.inside.976 = icmp ule i32 %local.check.offset.969, %local.check.owner.end.972
  %descriptor.extent.inside.978 = icmp ule i32 %local.check.extent.970, %stack.sub.977
  %descriptor.payload.inside.979 = icmp ule i32 %local.check.payload.971, %local.check.extent.970
  %descriptor.owner.offset.valid.980 = and i1 %descriptor.owner.inside.975, %descriptor.offset.inside.976
  %descriptor.range.inside.982 = and i1 %descriptor.owner.offset.valid.980, %descriptor.extent.inside.978
  %descriptor.range.valid.981 = and i1 %descriptor.range.inside.982, %descriptor.payload.inside.979
  br i1 %descriptor.range.valid.981, label %descriptor.valid.983, label %descriptor.invalid.984
descriptor.invalid.984:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.983:
  %descriptor.initialized.status.985 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.969, i32 %local.check.extent.970)
  %helper.ok.986 = icmp eq i32 %descriptor.initialized.status.985, 0
  br i1 %helper.ok.986, label %helper.continue.987, label %frame.failure.0
helper.continue.987:
  br label %local.descriptor.checked.968
local.descriptor.inactive.967:
  br label %local.descriptor.checked.968
local.descriptor.checked.968:
  %local.is.active.988 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.988, label %local.descriptor.active.989, label %local.descriptor.inactive.990
local.descriptor.active.989:
  %local.check.offset.992 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.993 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.994 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.995 = load i32, ptr %local.owner.end.24, align 4
  %context.field.996 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.997 = load i32, ptr %context.field.996, align 4
  %stack.sub.1000 = sub i32 %local.check.owner.end.995, %local.check.offset.992
  %descriptor.owner.inside.998 = icmp ule i32 %local.check.owner.end.995, %context.value.997
  %descriptor.offset.inside.999 = icmp ule i32 %local.check.offset.992, %local.check.owner.end.995
  %descriptor.extent.inside.1001 = icmp ule i32 %local.check.extent.993, %stack.sub.1000
  %descriptor.payload.inside.1002 = icmp ule i32 %local.check.payload.994, %local.check.extent.993
  %descriptor.owner.offset.valid.1003 = and i1 %descriptor.owner.inside.998, %descriptor.offset.inside.999
  %descriptor.range.inside.1005 = and i1 %descriptor.owner.offset.valid.1003, %descriptor.extent.inside.1001
  %descriptor.range.valid.1004 = and i1 %descriptor.range.inside.1005, %descriptor.payload.inside.1002
  br i1 %descriptor.range.valid.1004, label %descriptor.valid.1006, label %descriptor.invalid.1007
descriptor.invalid.1007:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1006:
  %descriptor.initialized.status.1008 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.992, i32 %local.check.extent.993)
  %helper.ok.1009 = icmp eq i32 %descriptor.initialized.status.1008, 0
  br i1 %helper.ok.1009, label %helper.continue.1010, label %frame.failure.0
helper.continue.1010:
  br label %local.descriptor.checked.991
local.descriptor.inactive.990:
  br label %local.descriptor.checked.991
local.descriptor.checked.991:
  %local.is.active.1011 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1011, label %local.descriptor.active.1012, label %local.descriptor.inactive.1013
local.descriptor.active.1012:
  %local.check.offset.1015 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1016 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1017 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1018 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1019 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1020 = load i32, ptr %context.field.1019, align 4
  %stack.sub.1023 = sub i32 %local.check.owner.end.1018, %local.check.offset.1015
  %descriptor.owner.inside.1021 = icmp ule i32 %local.check.owner.end.1018, %context.value.1020
  %descriptor.offset.inside.1022 = icmp ule i32 %local.check.offset.1015, %local.check.owner.end.1018
  %descriptor.extent.inside.1024 = icmp ule i32 %local.check.extent.1016, %stack.sub.1023
  %descriptor.payload.inside.1025 = icmp ule i32 %local.check.payload.1017, %local.check.extent.1016
  %descriptor.owner.offset.valid.1026 = and i1 %descriptor.owner.inside.1021, %descriptor.offset.inside.1022
  %descriptor.range.inside.1028 = and i1 %descriptor.owner.offset.valid.1026, %descriptor.extent.inside.1024
  %descriptor.range.valid.1027 = and i1 %descriptor.range.inside.1028, %descriptor.payload.inside.1025
  br i1 %descriptor.range.valid.1027, label %descriptor.valid.1029, label %descriptor.invalid.1030
descriptor.invalid.1030:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1029:
  %descriptor.initialized.status.1031 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1015, i32 %local.check.extent.1016)
  %helper.ok.1032 = icmp eq i32 %descriptor.initialized.status.1031, 0
  br i1 %helper.ok.1032, label %helper.continue.1033, label %frame.failure.0
helper.continue.1033:
  br label %local.descriptor.checked.1014
local.descriptor.inactive.1013:
  br label %local.descriptor.checked.1014
local.descriptor.checked.1014:
  br label %if.join.725
if.else.724:
  %step.status.1034 = call i32 @al_owning_charge_step(ptr %ctx, i32 10)
  %helper.ok.1035 = icmp eq i32 %step.status.1034, 0
  br i1 %helper.ok.1035, label %helper.continue.1036, label %frame.failure.0
helper.continue.1036:
  %context.field.1037 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1038 = load i32, ptr %context.field.1037, align 4
  %step.status.1039 = call i32 @al_owning_charge_step(ptr %ctx, i32 11)
  %helper.ok.1040 = icmp eq i32 %step.status.1039, 0
  br i1 %helper.ok.1040, label %helper.continue.1041, label %frame.failure.0
helper.continue.1041:
  %local.resolved.offset.1042 = load i32, ptr %local.offset.9, align 4
  %local.resolved.extent.1043 = load i32, ptr %local.extent.10, align 4
  %local.resolved.payload.1044 = load i32, ptr %local.payload.11, align 4
  %local.resolved.owner.end.1045 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1046 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1047 = load i32, ptr %context.field.1046, align 4
  %stack.sub.1050 = sub i32 %local.resolved.owner.end.1045, %local.resolved.offset.1042
  %descriptor.owner.inside.1048 = icmp ule i32 %local.resolved.owner.end.1045, %context.value.1047
  %descriptor.offset.inside.1049 = icmp ule i32 %local.resolved.offset.1042, %local.resolved.owner.end.1045
  %descriptor.extent.inside.1051 = icmp ule i32 %local.resolved.extent.1043, %stack.sub.1050
  %descriptor.payload.inside.1052 = icmp ule i32 %local.resolved.payload.1044, %local.resolved.extent.1043
  %descriptor.owner.offset.valid.1053 = and i1 %descriptor.owner.inside.1048, %descriptor.offset.inside.1049
  %descriptor.range.inside.1055 = and i1 %descriptor.owner.offset.valid.1053, %descriptor.extent.inside.1051
  %descriptor.range.valid.1054 = and i1 %descriptor.range.inside.1055, %descriptor.payload.inside.1052
  %descriptor.type.valid.1056 = icmp eq i32 8, 8
  %descriptor.valid.1057 = and i1 %descriptor.range.valid.1054, %descriptor.type.valid.1056
  br i1 %descriptor.valid.1057, label %descriptor.valid.1058, label %descriptor.invalid.1059
descriptor.invalid.1059:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1058:
  %descriptor.initialized.status.1060 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1042, i32 %local.resolved.extent.1043)
  %helper.ok.1061 = icmp eq i32 %descriptor.initialized.status.1060, 0
  br i1 %helper.ok.1061, label %helper.continue.1062, label %frame.failure.0
helper.continue.1062:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %local.resolved.offset.1042, i32 20, i32 %local.resolved.payload.1044, i32 %local.resolved.owner.end.1045, i32 %local.resolved.extent.1043)
  %context.field.1063 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1064 = load i32, ptr %context.field.1063, align 4
  %runtime.ok.1065 = icmp eq i32 %context.value.1064, 0
  br i1 %runtime.ok.1065, label %runtime.continue.1066, label %frame.failure.0
runtime.continue.1066:
  %context.field.1067 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1068 = load i32, ptr %context.field.1067, align 4
  %stack.sub.1071 = sub i32 %local.resolved.owner.end.1045, %local.resolved.offset.1042
  %descriptor.owner.inside.1069 = icmp ule i32 %local.resolved.owner.end.1045, %context.value.1068
  %descriptor.offset.inside.1070 = icmp ule i32 %local.resolved.offset.1042, %local.resolved.owner.end.1045
  %descriptor.extent.inside.1072 = icmp ule i32 %local.resolved.extent.1043, %stack.sub.1071
  %descriptor.payload.inside.1073 = icmp ule i32 %local.resolved.payload.1044, %local.resolved.extent.1043
  %descriptor.owner.offset.valid.1074 = and i1 %descriptor.owner.inside.1069, %descriptor.offset.inside.1070
  %descriptor.range.inside.1076 = and i1 %descriptor.owner.offset.valid.1074, %descriptor.extent.inside.1072
  %descriptor.range.valid.1075 = and i1 %descriptor.range.inside.1076, %descriptor.payload.inside.1073
  %descriptor.type.valid.1077 = icmp eq i32 8, 8
  %descriptor.valid.1078 = and i1 %descriptor.range.valid.1075, %descriptor.type.valid.1077
  br i1 %descriptor.valid.1078, label %descriptor.valid.1079, label %descriptor.invalid.1080
descriptor.invalid.1080:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1079:
  %descriptor.initialized.status.1081 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1042, i32 %local.resolved.extent.1043)
  %helper.ok.1082 = icmp eq i32 %descriptor.initialized.status.1081, 0
  br i1 %helper.ok.1082, label %helper.continue.1083, label %frame.failure.0
helper.continue.1083:
  %local.is.active.1084 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1084, label %local.descriptor.active.1085, label %local.descriptor.inactive.1086
local.descriptor.active.1085:
  %local.check.offset.1088 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1089 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1090 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1091 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1092 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1093 = load i32, ptr %context.field.1092, align 4
  %stack.sub.1096 = sub i32 %local.check.owner.end.1091, %local.check.offset.1088
  %descriptor.owner.inside.1094 = icmp ule i32 %local.check.owner.end.1091, %context.value.1093
  %descriptor.offset.inside.1095 = icmp ule i32 %local.check.offset.1088, %local.check.owner.end.1091
  %descriptor.extent.inside.1097 = icmp ule i32 %local.check.extent.1089, %stack.sub.1096
  %descriptor.payload.inside.1098 = icmp ule i32 %local.check.payload.1090, %local.check.extent.1089
  %descriptor.owner.offset.valid.1099 = and i1 %descriptor.owner.inside.1094, %descriptor.offset.inside.1095
  %descriptor.range.inside.1101 = and i1 %descriptor.owner.offset.valid.1099, %descriptor.extent.inside.1097
  %descriptor.range.valid.1100 = and i1 %descriptor.range.inside.1101, %descriptor.payload.inside.1098
  br i1 %descriptor.range.valid.1100, label %descriptor.valid.1102, label %descriptor.invalid.1103
descriptor.invalid.1103:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1102:
  %descriptor.initialized.status.1104 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1088, i32 %local.check.extent.1089)
  %helper.ok.1105 = icmp eq i32 %descriptor.initialized.status.1104, 0
  br i1 %helper.ok.1105, label %helper.continue.1106, label %frame.failure.0
helper.continue.1106:
  br label %local.descriptor.checked.1087
local.descriptor.inactive.1086:
  br label %local.descriptor.checked.1087
local.descriptor.checked.1087:
  %local.is.active.1107 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1107, label %local.descriptor.active.1108, label %local.descriptor.inactive.1109
local.descriptor.active.1108:
  %local.check.offset.1111 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1112 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1113 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1114 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1115 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1116 = load i32, ptr %context.field.1115, align 4
  %stack.sub.1119 = sub i32 %local.check.owner.end.1114, %local.check.offset.1111
  %descriptor.owner.inside.1117 = icmp ule i32 %local.check.owner.end.1114, %context.value.1116
  %descriptor.offset.inside.1118 = icmp ule i32 %local.check.offset.1111, %local.check.owner.end.1114
  %descriptor.extent.inside.1120 = icmp ule i32 %local.check.extent.1112, %stack.sub.1119
  %descriptor.payload.inside.1121 = icmp ule i32 %local.check.payload.1113, %local.check.extent.1112
  %descriptor.owner.offset.valid.1122 = and i1 %descriptor.owner.inside.1117, %descriptor.offset.inside.1118
  %descriptor.range.inside.1124 = and i1 %descriptor.owner.offset.valid.1122, %descriptor.extent.inside.1120
  %descriptor.range.valid.1123 = and i1 %descriptor.range.inside.1124, %descriptor.payload.inside.1121
  br i1 %descriptor.range.valid.1123, label %descriptor.valid.1125, label %descriptor.invalid.1126
descriptor.invalid.1126:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1125:
  %descriptor.initialized.status.1127 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1111, i32 %local.check.extent.1112)
  %helper.ok.1128 = icmp eq i32 %descriptor.initialized.status.1127, 0
  br i1 %helper.ok.1128, label %helper.continue.1129, label %frame.failure.0
helper.continue.1129:
  br label %local.descriptor.checked.1110
local.descriptor.inactive.1109:
  br label %local.descriptor.checked.1110
local.descriptor.checked.1110:
  %local.is.active.1130 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1130, label %local.descriptor.active.1131, label %local.descriptor.inactive.1132
local.descriptor.active.1131:
  %local.check.offset.1134 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1135 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1136 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1137 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1138 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1139 = load i32, ptr %context.field.1138, align 4
  %stack.sub.1142 = sub i32 %local.check.owner.end.1137, %local.check.offset.1134
  %descriptor.owner.inside.1140 = icmp ule i32 %local.check.owner.end.1137, %context.value.1139
  %descriptor.offset.inside.1141 = icmp ule i32 %local.check.offset.1134, %local.check.owner.end.1137
  %descriptor.extent.inside.1143 = icmp ule i32 %local.check.extent.1135, %stack.sub.1142
  %descriptor.payload.inside.1144 = icmp ule i32 %local.check.payload.1136, %local.check.extent.1135
  %descriptor.owner.offset.valid.1145 = and i1 %descriptor.owner.inside.1140, %descriptor.offset.inside.1141
  %descriptor.range.inside.1147 = and i1 %descriptor.owner.offset.valid.1145, %descriptor.extent.inside.1143
  %descriptor.range.valid.1146 = and i1 %descriptor.range.inside.1147, %descriptor.payload.inside.1144
  br i1 %descriptor.range.valid.1146, label %descriptor.valid.1148, label %descriptor.invalid.1149
descriptor.invalid.1149:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1148:
  %descriptor.initialized.status.1150 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1134, i32 %local.check.extent.1135)
  %helper.ok.1151 = icmp eq i32 %descriptor.initialized.status.1150, 0
  br i1 %helper.ok.1151, label %helper.continue.1152, label %frame.failure.0
helper.continue.1152:
  br label %local.descriptor.checked.1133
local.descriptor.inactive.1132:
  br label %local.descriptor.checked.1133
local.descriptor.checked.1133:
  %local.is.active.1153 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1153, label %local.descriptor.active.1154, label %local.descriptor.inactive.1155
local.descriptor.active.1154:
  %local.check.offset.1157 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1158 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1159 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1160 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1161 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1162 = load i32, ptr %context.field.1161, align 4
  %stack.sub.1165 = sub i32 %local.check.owner.end.1160, %local.check.offset.1157
  %descriptor.owner.inside.1163 = icmp ule i32 %local.check.owner.end.1160, %context.value.1162
  %descriptor.offset.inside.1164 = icmp ule i32 %local.check.offset.1157, %local.check.owner.end.1160
  %descriptor.extent.inside.1166 = icmp ule i32 %local.check.extent.1158, %stack.sub.1165
  %descriptor.payload.inside.1167 = icmp ule i32 %local.check.payload.1159, %local.check.extent.1158
  %descriptor.owner.offset.valid.1168 = and i1 %descriptor.owner.inside.1163, %descriptor.offset.inside.1164
  %descriptor.range.inside.1170 = and i1 %descriptor.owner.offset.valid.1168, %descriptor.extent.inside.1166
  %descriptor.range.valid.1169 = and i1 %descriptor.range.inside.1170, %descriptor.payload.inside.1167
  br i1 %descriptor.range.valid.1169, label %descriptor.valid.1171, label %descriptor.invalid.1172
descriptor.invalid.1172:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1171:
  %descriptor.initialized.status.1173 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1157, i32 %local.check.extent.1158)
  %helper.ok.1174 = icmp eq i32 %descriptor.initialized.status.1173, 0
  br i1 %helper.ok.1174, label %helper.continue.1175, label %frame.failure.0
helper.continue.1175:
  br label %local.descriptor.checked.1156
local.descriptor.inactive.1155:
  br label %local.descriptor.checked.1156
local.descriptor.checked.1156:
  %local.is.active.1176 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1176, label %local.descriptor.active.1177, label %local.descriptor.inactive.1178
local.descriptor.active.1177:
  %local.check.offset.1180 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1181 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1182 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1183 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1184 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1185 = load i32, ptr %context.field.1184, align 4
  %stack.sub.1188 = sub i32 %local.check.owner.end.1183, %local.check.offset.1180
  %descriptor.owner.inside.1186 = icmp ule i32 %local.check.owner.end.1183, %context.value.1185
  %descriptor.offset.inside.1187 = icmp ule i32 %local.check.offset.1180, %local.check.owner.end.1183
  %descriptor.extent.inside.1189 = icmp ule i32 %local.check.extent.1181, %stack.sub.1188
  %descriptor.payload.inside.1190 = icmp ule i32 %local.check.payload.1182, %local.check.extent.1181
  %descriptor.owner.offset.valid.1191 = and i1 %descriptor.owner.inside.1186, %descriptor.offset.inside.1187
  %descriptor.range.inside.1193 = and i1 %descriptor.owner.offset.valid.1191, %descriptor.extent.inside.1189
  %descriptor.range.valid.1192 = and i1 %descriptor.range.inside.1193, %descriptor.payload.inside.1190
  br i1 %descriptor.range.valid.1192, label %descriptor.valid.1194, label %descriptor.invalid.1195
descriptor.invalid.1195:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1194:
  %descriptor.initialized.status.1196 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1180, i32 %local.check.extent.1181)
  %helper.ok.1197 = icmp eq i32 %descriptor.initialized.status.1196, 0
  br i1 %helper.ok.1197, label %helper.continue.1198, label %frame.failure.0
helper.continue.1198:
  br label %local.descriptor.checked.1179
local.descriptor.inactive.1178:
  br label %local.descriptor.checked.1179
local.descriptor.checked.1179:
  %context.field.1199 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1200 = load i32, ptr %context.field.1199, align 4
  %stack.sub.1201 = sub i32 %context.value.1200, %context.value.1038
  call void @al_owning_record_layout(ptr %ctx, i32 18, i32 0, i32 %context.value.1038, i32 %stack.sub.1201, i32 0, i32 0, i32 0)
  %context.field.1202 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1203 = load i32, ptr %context.field.1202, align 4
  %runtime.ok.1204 = icmp eq i32 %context.value.1203, 0
  br i1 %runtime.ok.1204, label %runtime.continue.1205, label %frame.failure.0
runtime.continue.1205:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.1038, i32 0, i32 0, i32 0)
  %context.field.1206 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1207 = load i32, ptr %context.field.1206, align 4
  %runtime.ok.1208 = icmp eq i32 %context.value.1207, 0
  br i1 %runtime.ok.1208, label %runtime.continue.1209, label %frame.failure.0
runtime.continue.1209:
  %context.field.1210 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1211 = load i32, ptr %context.field.1210, align 4
  %stack.sub.1214 = sub i32 %local.resolved.owner.end.1045, %local.resolved.offset.1042
  %descriptor.owner.inside.1212 = icmp ule i32 %local.resolved.owner.end.1045, %context.value.1211
  %descriptor.offset.inside.1213 = icmp ule i32 %local.resolved.offset.1042, %local.resolved.owner.end.1045
  %descriptor.extent.inside.1215 = icmp ule i32 %local.resolved.extent.1043, %stack.sub.1214
  %descriptor.payload.inside.1216 = icmp ule i32 %local.resolved.payload.1044, %local.resolved.extent.1043
  %descriptor.owner.offset.valid.1217 = and i1 %descriptor.owner.inside.1212, %descriptor.offset.inside.1213
  %descriptor.range.inside.1219 = and i1 %descriptor.owner.offset.valid.1217, %descriptor.extent.inside.1215
  %descriptor.range.valid.1218 = and i1 %descriptor.range.inside.1219, %descriptor.payload.inside.1216
  %descriptor.type.valid.1220 = icmp eq i32 8, 8
  %descriptor.valid.1221 = and i1 %descriptor.range.valid.1218, %descriptor.type.valid.1220
  br i1 %descriptor.valid.1221, label %descriptor.valid.1222, label %descriptor.invalid.1223
descriptor.invalid.1223:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1222:
  %descriptor.initialized.status.1224 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1042, i32 %local.resolved.extent.1043)
  %helper.ok.1225 = icmp eq i32 %descriptor.initialized.status.1224, 0
  br i1 %helper.ok.1225, label %helper.continue.1226, label %frame.failure.0
helper.continue.1226:
  %local.is.active.1227 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1227, label %local.descriptor.active.1228, label %local.descriptor.inactive.1229
local.descriptor.active.1228:
  %local.check.offset.1231 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1232 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1233 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1234 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1235 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1236 = load i32, ptr %context.field.1235, align 4
  %stack.sub.1239 = sub i32 %local.check.owner.end.1234, %local.check.offset.1231
  %descriptor.owner.inside.1237 = icmp ule i32 %local.check.owner.end.1234, %context.value.1236
  %descriptor.offset.inside.1238 = icmp ule i32 %local.check.offset.1231, %local.check.owner.end.1234
  %descriptor.extent.inside.1240 = icmp ule i32 %local.check.extent.1232, %stack.sub.1239
  %descriptor.payload.inside.1241 = icmp ule i32 %local.check.payload.1233, %local.check.extent.1232
  %descriptor.owner.offset.valid.1242 = and i1 %descriptor.owner.inside.1237, %descriptor.offset.inside.1238
  %descriptor.range.inside.1244 = and i1 %descriptor.owner.offset.valid.1242, %descriptor.extent.inside.1240
  %descriptor.range.valid.1243 = and i1 %descriptor.range.inside.1244, %descriptor.payload.inside.1241
  br i1 %descriptor.range.valid.1243, label %descriptor.valid.1245, label %descriptor.invalid.1246
descriptor.invalid.1246:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1245:
  %descriptor.initialized.status.1247 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1231, i32 %local.check.extent.1232)
  %helper.ok.1248 = icmp eq i32 %descriptor.initialized.status.1247, 0
  br i1 %helper.ok.1248, label %helper.continue.1249, label %frame.failure.0
helper.continue.1249:
  br label %local.descriptor.checked.1230
local.descriptor.inactive.1229:
  br label %local.descriptor.checked.1230
local.descriptor.checked.1230:
  %local.is.active.1250 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1250, label %local.descriptor.active.1251, label %local.descriptor.inactive.1252
local.descriptor.active.1251:
  %local.check.offset.1254 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1255 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1256 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1257 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1258 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1259 = load i32, ptr %context.field.1258, align 4
  %stack.sub.1262 = sub i32 %local.check.owner.end.1257, %local.check.offset.1254
  %descriptor.owner.inside.1260 = icmp ule i32 %local.check.owner.end.1257, %context.value.1259
  %descriptor.offset.inside.1261 = icmp ule i32 %local.check.offset.1254, %local.check.owner.end.1257
  %descriptor.extent.inside.1263 = icmp ule i32 %local.check.extent.1255, %stack.sub.1262
  %descriptor.payload.inside.1264 = icmp ule i32 %local.check.payload.1256, %local.check.extent.1255
  %descriptor.owner.offset.valid.1265 = and i1 %descriptor.owner.inside.1260, %descriptor.offset.inside.1261
  %descriptor.range.inside.1267 = and i1 %descriptor.owner.offset.valid.1265, %descriptor.extent.inside.1263
  %descriptor.range.valid.1266 = and i1 %descriptor.range.inside.1267, %descriptor.payload.inside.1264
  br i1 %descriptor.range.valid.1266, label %descriptor.valid.1268, label %descriptor.invalid.1269
descriptor.invalid.1269:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1268:
  %descriptor.initialized.status.1270 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1254, i32 %local.check.extent.1255)
  %helper.ok.1271 = icmp eq i32 %descriptor.initialized.status.1270, 0
  br i1 %helper.ok.1271, label %helper.continue.1272, label %frame.failure.0
helper.continue.1272:
  br label %local.descriptor.checked.1253
local.descriptor.inactive.1252:
  br label %local.descriptor.checked.1253
local.descriptor.checked.1253:
  %local.is.active.1273 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1273, label %local.descriptor.active.1274, label %local.descriptor.inactive.1275
local.descriptor.active.1274:
  %local.check.offset.1277 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1278 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1279 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1280 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1281 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1282 = load i32, ptr %context.field.1281, align 4
  %stack.sub.1285 = sub i32 %local.check.owner.end.1280, %local.check.offset.1277
  %descriptor.owner.inside.1283 = icmp ule i32 %local.check.owner.end.1280, %context.value.1282
  %descriptor.offset.inside.1284 = icmp ule i32 %local.check.offset.1277, %local.check.owner.end.1280
  %descriptor.extent.inside.1286 = icmp ule i32 %local.check.extent.1278, %stack.sub.1285
  %descriptor.payload.inside.1287 = icmp ule i32 %local.check.payload.1279, %local.check.extent.1278
  %descriptor.owner.offset.valid.1288 = and i1 %descriptor.owner.inside.1283, %descriptor.offset.inside.1284
  %descriptor.range.inside.1290 = and i1 %descriptor.owner.offset.valid.1288, %descriptor.extent.inside.1286
  %descriptor.range.valid.1289 = and i1 %descriptor.range.inside.1290, %descriptor.payload.inside.1287
  br i1 %descriptor.range.valid.1289, label %descriptor.valid.1291, label %descriptor.invalid.1292
descriptor.invalid.1292:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1291:
  %descriptor.initialized.status.1293 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1277, i32 %local.check.extent.1278)
  %helper.ok.1294 = icmp eq i32 %descriptor.initialized.status.1293, 0
  br i1 %helper.ok.1294, label %helper.continue.1295, label %frame.failure.0
helper.continue.1295:
  br label %local.descriptor.checked.1276
local.descriptor.inactive.1275:
  br label %local.descriptor.checked.1276
local.descriptor.checked.1276:
  %local.is.active.1296 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1296, label %local.descriptor.active.1297, label %local.descriptor.inactive.1298
local.descriptor.active.1297:
  %local.check.offset.1300 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1301 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1302 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1303 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1304 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1305 = load i32, ptr %context.field.1304, align 4
  %stack.sub.1308 = sub i32 %local.check.owner.end.1303, %local.check.offset.1300
  %descriptor.owner.inside.1306 = icmp ule i32 %local.check.owner.end.1303, %context.value.1305
  %descriptor.offset.inside.1307 = icmp ule i32 %local.check.offset.1300, %local.check.owner.end.1303
  %descriptor.extent.inside.1309 = icmp ule i32 %local.check.extent.1301, %stack.sub.1308
  %descriptor.payload.inside.1310 = icmp ule i32 %local.check.payload.1302, %local.check.extent.1301
  %descriptor.owner.offset.valid.1311 = and i1 %descriptor.owner.inside.1306, %descriptor.offset.inside.1307
  %descriptor.range.inside.1313 = and i1 %descriptor.owner.offset.valid.1311, %descriptor.extent.inside.1309
  %descriptor.range.valid.1312 = and i1 %descriptor.range.inside.1313, %descriptor.payload.inside.1310
  br i1 %descriptor.range.valid.1312, label %descriptor.valid.1314, label %descriptor.invalid.1315
descriptor.invalid.1315:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1314:
  %descriptor.initialized.status.1316 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1300, i32 %local.check.extent.1301)
  %helper.ok.1317 = icmp eq i32 %descriptor.initialized.status.1316, 0
  br i1 %helper.ok.1317, label %helper.continue.1318, label %frame.failure.0
helper.continue.1318:
  br label %local.descriptor.checked.1299
local.descriptor.inactive.1298:
  br label %local.descriptor.checked.1299
local.descriptor.checked.1299:
  %local.is.active.1319 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1319, label %local.descriptor.active.1320, label %local.descriptor.inactive.1321
local.descriptor.active.1320:
  %local.check.offset.1323 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1324 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1325 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1326 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1327 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1328 = load i32, ptr %context.field.1327, align 4
  %stack.sub.1331 = sub i32 %local.check.owner.end.1326, %local.check.offset.1323
  %descriptor.owner.inside.1329 = icmp ule i32 %local.check.owner.end.1326, %context.value.1328
  %descriptor.offset.inside.1330 = icmp ule i32 %local.check.offset.1323, %local.check.owner.end.1326
  %descriptor.extent.inside.1332 = icmp ule i32 %local.check.extent.1324, %stack.sub.1331
  %descriptor.payload.inside.1333 = icmp ule i32 %local.check.payload.1325, %local.check.extent.1324
  %descriptor.owner.offset.valid.1334 = and i1 %descriptor.owner.inside.1329, %descriptor.offset.inside.1330
  %descriptor.range.inside.1336 = and i1 %descriptor.owner.offset.valid.1334, %descriptor.extent.inside.1332
  %descriptor.range.valid.1335 = and i1 %descriptor.range.inside.1336, %descriptor.payload.inside.1333
  br i1 %descriptor.range.valid.1335, label %descriptor.valid.1337, label %descriptor.invalid.1338
descriptor.invalid.1338:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1337:
  %descriptor.initialized.status.1339 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1323, i32 %local.check.extent.1324)
  %helper.ok.1340 = icmp eq i32 %descriptor.initialized.status.1339, 0
  br i1 %helper.ok.1340, label %helper.continue.1341, label %frame.failure.0
helper.continue.1341:
  br label %local.descriptor.checked.1322
local.descriptor.inactive.1321:
  br label %local.descriptor.checked.1322
local.descriptor.checked.1322:
  br label %if.join.725
if.join.725:
  %if.value.offset.1342 = phi i32 [ %local.resolved.offset.734, %local.descriptor.checked.1014 ], [ %local.resolved.offset.1042, %local.descriptor.checked.1322 ]
  %if.value.extent.1343 = phi i32 [ %local.resolved.extent.735, %local.descriptor.checked.1014 ], [ %local.resolved.extent.1043, %local.descriptor.checked.1322 ]
  %if.value.payload.1344 = phi i32 [ %local.resolved.payload.736, %local.descriptor.checked.1014 ], [ %local.resolved.payload.1044, %local.descriptor.checked.1322 ]
  %if.value.owner.end.1345 = phi i32 [ %local.resolved.owner.end.737, %local.descriptor.checked.1014 ], [ %local.resolved.owner.end.1045, %local.descriptor.checked.1322 ]
  %context.field.1346 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1347 = load i32, ptr %context.field.1346, align 4
  %stack.sub.1350 = sub i32 %if.value.owner.end.1345, %if.value.offset.1342
  %descriptor.owner.inside.1348 = icmp ule i32 %if.value.owner.end.1345, %context.value.1347
  %descriptor.offset.inside.1349 = icmp ule i32 %if.value.offset.1342, %if.value.owner.end.1345
  %descriptor.extent.inside.1351 = icmp ule i32 %if.value.extent.1343, %stack.sub.1350
  %descriptor.payload.inside.1352 = icmp ule i32 %if.value.payload.1344, %if.value.extent.1343
  %descriptor.owner.offset.valid.1353 = and i1 %descriptor.owner.inside.1348, %descriptor.offset.inside.1349
  %descriptor.range.inside.1355 = and i1 %descriptor.owner.offset.valid.1353, %descriptor.extent.inside.1351
  %descriptor.range.valid.1354 = and i1 %descriptor.range.inside.1355, %descriptor.payload.inside.1352
  %descriptor.type.valid.1356 = icmp eq i32 8, 8
  %descriptor.valid.1357 = and i1 %descriptor.range.valid.1354, %descriptor.type.valid.1356
  br i1 %descriptor.valid.1357, label %descriptor.valid.1358, label %descriptor.invalid.1359
descriptor.invalid.1359:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1358:
  %descriptor.initialized.status.1360 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %if.value.offset.1342, i32 %if.value.extent.1343)
  %helper.ok.1361 = icmp eq i32 %descriptor.initialized.status.1360, 0
  br i1 %helper.ok.1361, label %helper.continue.1362, label %frame.failure.0
helper.continue.1362:
  %local.is.active.1363 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1363, label %local.descriptor.active.1364, label %local.descriptor.inactive.1365
local.descriptor.active.1364:
  %local.check.offset.1367 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1368 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1369 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1370 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1371 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1372 = load i32, ptr %context.field.1371, align 4
  %stack.sub.1375 = sub i32 %local.check.owner.end.1370, %local.check.offset.1367
  %descriptor.owner.inside.1373 = icmp ule i32 %local.check.owner.end.1370, %context.value.1372
  %descriptor.offset.inside.1374 = icmp ule i32 %local.check.offset.1367, %local.check.owner.end.1370
  %descriptor.extent.inside.1376 = icmp ule i32 %local.check.extent.1368, %stack.sub.1375
  %descriptor.payload.inside.1377 = icmp ule i32 %local.check.payload.1369, %local.check.extent.1368
  %descriptor.owner.offset.valid.1378 = and i1 %descriptor.owner.inside.1373, %descriptor.offset.inside.1374
  %descriptor.range.inside.1380 = and i1 %descriptor.owner.offset.valid.1378, %descriptor.extent.inside.1376
  %descriptor.range.valid.1379 = and i1 %descriptor.range.inside.1380, %descriptor.payload.inside.1377
  br i1 %descriptor.range.valid.1379, label %descriptor.valid.1381, label %descriptor.invalid.1382
descriptor.invalid.1382:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1381:
  %descriptor.initialized.status.1383 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1367, i32 %local.check.extent.1368)
  %helper.ok.1384 = icmp eq i32 %descriptor.initialized.status.1383, 0
  br i1 %helper.ok.1384, label %helper.continue.1385, label %frame.failure.0
helper.continue.1385:
  br label %local.descriptor.checked.1366
local.descriptor.inactive.1365:
  br label %local.descriptor.checked.1366
local.descriptor.checked.1366:
  %local.is.active.1386 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1386, label %local.descriptor.active.1387, label %local.descriptor.inactive.1388
local.descriptor.active.1387:
  %local.check.offset.1390 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1391 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1392 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1393 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1394 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1395 = load i32, ptr %context.field.1394, align 4
  %stack.sub.1398 = sub i32 %local.check.owner.end.1393, %local.check.offset.1390
  %descriptor.owner.inside.1396 = icmp ule i32 %local.check.owner.end.1393, %context.value.1395
  %descriptor.offset.inside.1397 = icmp ule i32 %local.check.offset.1390, %local.check.owner.end.1393
  %descriptor.extent.inside.1399 = icmp ule i32 %local.check.extent.1391, %stack.sub.1398
  %descriptor.payload.inside.1400 = icmp ule i32 %local.check.payload.1392, %local.check.extent.1391
  %descriptor.owner.offset.valid.1401 = and i1 %descriptor.owner.inside.1396, %descriptor.offset.inside.1397
  %descriptor.range.inside.1403 = and i1 %descriptor.owner.offset.valid.1401, %descriptor.extent.inside.1399
  %descriptor.range.valid.1402 = and i1 %descriptor.range.inside.1403, %descriptor.payload.inside.1400
  br i1 %descriptor.range.valid.1402, label %descriptor.valid.1404, label %descriptor.invalid.1405
descriptor.invalid.1405:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1404:
  %descriptor.initialized.status.1406 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1390, i32 %local.check.extent.1391)
  %helper.ok.1407 = icmp eq i32 %descriptor.initialized.status.1406, 0
  br i1 %helper.ok.1407, label %helper.continue.1408, label %frame.failure.0
helper.continue.1408:
  br label %local.descriptor.checked.1389
local.descriptor.inactive.1388:
  br label %local.descriptor.checked.1389
local.descriptor.checked.1389:
  %local.is.active.1409 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1409, label %local.descriptor.active.1410, label %local.descriptor.inactive.1411
local.descriptor.active.1410:
  %local.check.offset.1413 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1414 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1415 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1416 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1417 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1418 = load i32, ptr %context.field.1417, align 4
  %stack.sub.1421 = sub i32 %local.check.owner.end.1416, %local.check.offset.1413
  %descriptor.owner.inside.1419 = icmp ule i32 %local.check.owner.end.1416, %context.value.1418
  %descriptor.offset.inside.1420 = icmp ule i32 %local.check.offset.1413, %local.check.owner.end.1416
  %descriptor.extent.inside.1422 = icmp ule i32 %local.check.extent.1414, %stack.sub.1421
  %descriptor.payload.inside.1423 = icmp ule i32 %local.check.payload.1415, %local.check.extent.1414
  %descriptor.owner.offset.valid.1424 = and i1 %descriptor.owner.inside.1419, %descriptor.offset.inside.1420
  %descriptor.range.inside.1426 = and i1 %descriptor.owner.offset.valid.1424, %descriptor.extent.inside.1422
  %descriptor.range.valid.1425 = and i1 %descriptor.range.inside.1426, %descriptor.payload.inside.1423
  br i1 %descriptor.range.valid.1425, label %descriptor.valid.1427, label %descriptor.invalid.1428
descriptor.invalid.1428:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1427:
  %descriptor.initialized.status.1429 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1413, i32 %local.check.extent.1414)
  %helper.ok.1430 = icmp eq i32 %descriptor.initialized.status.1429, 0
  br i1 %helper.ok.1430, label %helper.continue.1431, label %frame.failure.0
helper.continue.1431:
  br label %local.descriptor.checked.1412
local.descriptor.inactive.1411:
  br label %local.descriptor.checked.1412
local.descriptor.checked.1412:
  %local.is.active.1432 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1432, label %local.descriptor.active.1433, label %local.descriptor.inactive.1434
local.descriptor.active.1433:
  %local.check.offset.1436 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1437 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1438 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1439 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1440 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1441 = load i32, ptr %context.field.1440, align 4
  %stack.sub.1444 = sub i32 %local.check.owner.end.1439, %local.check.offset.1436
  %descriptor.owner.inside.1442 = icmp ule i32 %local.check.owner.end.1439, %context.value.1441
  %descriptor.offset.inside.1443 = icmp ule i32 %local.check.offset.1436, %local.check.owner.end.1439
  %descriptor.extent.inside.1445 = icmp ule i32 %local.check.extent.1437, %stack.sub.1444
  %descriptor.payload.inside.1446 = icmp ule i32 %local.check.payload.1438, %local.check.extent.1437
  %descriptor.owner.offset.valid.1447 = and i1 %descriptor.owner.inside.1442, %descriptor.offset.inside.1443
  %descriptor.range.inside.1449 = and i1 %descriptor.owner.offset.valid.1447, %descriptor.extent.inside.1445
  %descriptor.range.valid.1448 = and i1 %descriptor.range.inside.1449, %descriptor.payload.inside.1446
  br i1 %descriptor.range.valid.1448, label %descriptor.valid.1450, label %descriptor.invalid.1451
descriptor.invalid.1451:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1450:
  %descriptor.initialized.status.1452 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1436, i32 %local.check.extent.1437)
  %helper.ok.1453 = icmp eq i32 %descriptor.initialized.status.1452, 0
  br i1 %helper.ok.1453, label %helper.continue.1454, label %frame.failure.0
helper.continue.1454:
  br label %local.descriptor.checked.1435
local.descriptor.inactive.1434:
  br label %local.descriptor.checked.1435
local.descriptor.checked.1435:
  %local.is.active.1455 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1455, label %local.descriptor.active.1456, label %local.descriptor.inactive.1457
local.descriptor.active.1456:
  %local.check.offset.1459 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1460 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1461 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1462 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1463 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1464 = load i32, ptr %context.field.1463, align 4
  %stack.sub.1467 = sub i32 %local.check.owner.end.1462, %local.check.offset.1459
  %descriptor.owner.inside.1465 = icmp ule i32 %local.check.owner.end.1462, %context.value.1464
  %descriptor.offset.inside.1466 = icmp ule i32 %local.check.offset.1459, %local.check.owner.end.1462
  %descriptor.extent.inside.1468 = icmp ule i32 %local.check.extent.1460, %stack.sub.1467
  %descriptor.payload.inside.1469 = icmp ule i32 %local.check.payload.1461, %local.check.extent.1460
  %descriptor.owner.offset.valid.1470 = and i1 %descriptor.owner.inside.1465, %descriptor.offset.inside.1466
  %descriptor.range.inside.1472 = and i1 %descriptor.owner.offset.valid.1470, %descriptor.extent.inside.1468
  %descriptor.range.valid.1471 = and i1 %descriptor.range.inside.1472, %descriptor.payload.inside.1469
  br i1 %descriptor.range.valid.1471, label %descriptor.valid.1473, label %descriptor.invalid.1474
descriptor.invalid.1474:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1473:
  %descriptor.initialized.status.1475 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1459, i32 %local.check.extent.1460)
  %helper.ok.1476 = icmp eq i32 %descriptor.initialized.status.1475, 0
  br i1 %helper.ok.1476, label %helper.continue.1477, label %frame.failure.0
helper.continue.1477:
  br label %local.descriptor.checked.1458
local.descriptor.inactive.1457:
  br label %local.descriptor.checked.1458
local.descriptor.checked.1458:
  %step.status.1478 = call i32 @al_owning_charge_step(ptr %ctx, i32 12)
  %helper.ok.1479 = icmp eq i32 %step.status.1478, 0
  br i1 %helper.ok.1479, label %helper.continue.1480, label %frame.failure.0
helper.continue.1480:
  store i1 true, ptr %local.active.20, align 1
  store i32 %if.value.offset.1342, ptr %local.offset.21, align 4
  store i32 %if.value.extent.1343, ptr %local.extent.22, align 4
  store i32 %if.value.payload.1344, ptr %local.payload.23, align 4
  store i32 %if.value.owner.end.1345, ptr %local.owner.end.24, align 4
  store i32 8, ptr %local.type.25, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %if.value.offset.1342, i32 20, i32 %if.value.payload.1344, i32 %if.value.owner.end.1345, i32 %if.value.extent.1343)
  %context.field.1481 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1482 = load i32, ptr %context.field.1481, align 4
  %runtime.ok.1483 = icmp eq i32 %context.value.1482, 0
  br i1 %runtime.ok.1483, label %runtime.continue.1484, label %frame.failure.0
runtime.continue.1484:
  %local.is.active.1485 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1485, label %local.descriptor.active.1486, label %local.descriptor.inactive.1487
local.descriptor.active.1486:
  %local.check.offset.1489 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1490 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1491 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1492 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1493 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1494 = load i32, ptr %context.field.1493, align 4
  %stack.sub.1497 = sub i32 %local.check.owner.end.1492, %local.check.offset.1489
  %descriptor.owner.inside.1495 = icmp ule i32 %local.check.owner.end.1492, %context.value.1494
  %descriptor.offset.inside.1496 = icmp ule i32 %local.check.offset.1489, %local.check.owner.end.1492
  %descriptor.extent.inside.1498 = icmp ule i32 %local.check.extent.1490, %stack.sub.1497
  %descriptor.payload.inside.1499 = icmp ule i32 %local.check.payload.1491, %local.check.extent.1490
  %descriptor.owner.offset.valid.1500 = and i1 %descriptor.owner.inside.1495, %descriptor.offset.inside.1496
  %descriptor.range.inside.1502 = and i1 %descriptor.owner.offset.valid.1500, %descriptor.extent.inside.1498
  %descriptor.range.valid.1501 = and i1 %descriptor.range.inside.1502, %descriptor.payload.inside.1499
  br i1 %descriptor.range.valid.1501, label %descriptor.valid.1503, label %descriptor.invalid.1504
descriptor.invalid.1504:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1503:
  %descriptor.initialized.status.1505 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1489, i32 %local.check.extent.1490)
  %helper.ok.1506 = icmp eq i32 %descriptor.initialized.status.1505, 0
  br i1 %helper.ok.1506, label %helper.continue.1507, label %frame.failure.0
helper.continue.1507:
  br label %local.descriptor.checked.1488
local.descriptor.inactive.1487:
  br label %local.descriptor.checked.1488
local.descriptor.checked.1488:
  %local.is.active.1508 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1508, label %local.descriptor.active.1509, label %local.descriptor.inactive.1510
local.descriptor.active.1509:
  %local.check.offset.1512 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1513 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1514 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1515 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1516 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1517 = load i32, ptr %context.field.1516, align 4
  %stack.sub.1520 = sub i32 %local.check.owner.end.1515, %local.check.offset.1512
  %descriptor.owner.inside.1518 = icmp ule i32 %local.check.owner.end.1515, %context.value.1517
  %descriptor.offset.inside.1519 = icmp ule i32 %local.check.offset.1512, %local.check.owner.end.1515
  %descriptor.extent.inside.1521 = icmp ule i32 %local.check.extent.1513, %stack.sub.1520
  %descriptor.payload.inside.1522 = icmp ule i32 %local.check.payload.1514, %local.check.extent.1513
  %descriptor.owner.offset.valid.1523 = and i1 %descriptor.owner.inside.1518, %descriptor.offset.inside.1519
  %descriptor.range.inside.1525 = and i1 %descriptor.owner.offset.valid.1523, %descriptor.extent.inside.1521
  %descriptor.range.valid.1524 = and i1 %descriptor.range.inside.1525, %descriptor.payload.inside.1522
  br i1 %descriptor.range.valid.1524, label %descriptor.valid.1526, label %descriptor.invalid.1527
descriptor.invalid.1527:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1526:
  %descriptor.initialized.status.1528 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1512, i32 %local.check.extent.1513)
  %helper.ok.1529 = icmp eq i32 %descriptor.initialized.status.1528, 0
  br i1 %helper.ok.1529, label %helper.continue.1530, label %frame.failure.0
helper.continue.1530:
  br label %local.descriptor.checked.1511
local.descriptor.inactive.1510:
  br label %local.descriptor.checked.1511
local.descriptor.checked.1511:
  %local.is.active.1531 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1531, label %local.descriptor.active.1532, label %local.descriptor.inactive.1533
local.descriptor.active.1532:
  %local.check.offset.1535 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1536 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1537 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1538 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1539 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1540 = load i32, ptr %context.field.1539, align 4
  %stack.sub.1543 = sub i32 %local.check.owner.end.1538, %local.check.offset.1535
  %descriptor.owner.inside.1541 = icmp ule i32 %local.check.owner.end.1538, %context.value.1540
  %descriptor.offset.inside.1542 = icmp ule i32 %local.check.offset.1535, %local.check.owner.end.1538
  %descriptor.extent.inside.1544 = icmp ule i32 %local.check.extent.1536, %stack.sub.1543
  %descriptor.payload.inside.1545 = icmp ule i32 %local.check.payload.1537, %local.check.extent.1536
  %descriptor.owner.offset.valid.1546 = and i1 %descriptor.owner.inside.1541, %descriptor.offset.inside.1542
  %descriptor.range.inside.1548 = and i1 %descriptor.owner.offset.valid.1546, %descriptor.extent.inside.1544
  %descriptor.range.valid.1547 = and i1 %descriptor.range.inside.1548, %descriptor.payload.inside.1545
  br i1 %descriptor.range.valid.1547, label %descriptor.valid.1549, label %descriptor.invalid.1550
descriptor.invalid.1550:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1549:
  %descriptor.initialized.status.1551 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1535, i32 %local.check.extent.1536)
  %helper.ok.1552 = icmp eq i32 %descriptor.initialized.status.1551, 0
  br i1 %helper.ok.1552, label %helper.continue.1553, label %frame.failure.0
helper.continue.1553:
  br label %local.descriptor.checked.1534
local.descriptor.inactive.1533:
  br label %local.descriptor.checked.1534
local.descriptor.checked.1534:
  %local.is.active.1554 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1554, label %local.descriptor.active.1555, label %local.descriptor.inactive.1556
local.descriptor.active.1555:
  %local.check.offset.1558 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1559 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1560 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1561 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1562 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1563 = load i32, ptr %context.field.1562, align 4
  %stack.sub.1566 = sub i32 %local.check.owner.end.1561, %local.check.offset.1558
  %descriptor.owner.inside.1564 = icmp ule i32 %local.check.owner.end.1561, %context.value.1563
  %descriptor.offset.inside.1565 = icmp ule i32 %local.check.offset.1558, %local.check.owner.end.1561
  %descriptor.extent.inside.1567 = icmp ule i32 %local.check.extent.1559, %stack.sub.1566
  %descriptor.payload.inside.1568 = icmp ule i32 %local.check.payload.1560, %local.check.extent.1559
  %descriptor.owner.offset.valid.1569 = and i1 %descriptor.owner.inside.1564, %descriptor.offset.inside.1565
  %descriptor.range.inside.1571 = and i1 %descriptor.owner.offset.valid.1569, %descriptor.extent.inside.1567
  %descriptor.range.valid.1570 = and i1 %descriptor.range.inside.1571, %descriptor.payload.inside.1568
  br i1 %descriptor.range.valid.1570, label %descriptor.valid.1572, label %descriptor.invalid.1573
descriptor.invalid.1573:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1572:
  %descriptor.initialized.status.1574 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1558, i32 %local.check.extent.1559)
  %helper.ok.1575 = icmp eq i32 %descriptor.initialized.status.1574, 0
  br i1 %helper.ok.1575, label %helper.continue.1576, label %frame.failure.0
helper.continue.1576:
  br label %local.descriptor.checked.1557
local.descriptor.inactive.1556:
  br label %local.descriptor.checked.1557
local.descriptor.checked.1557:
  %local.is.active.1577 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1577, label %local.descriptor.active.1578, label %local.descriptor.inactive.1579
local.descriptor.active.1578:
  %local.check.offset.1581 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1582 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1583 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1584 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1585 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1586 = load i32, ptr %context.field.1585, align 4
  %stack.sub.1589 = sub i32 %local.check.owner.end.1584, %local.check.offset.1581
  %descriptor.owner.inside.1587 = icmp ule i32 %local.check.owner.end.1584, %context.value.1586
  %descriptor.offset.inside.1588 = icmp ule i32 %local.check.offset.1581, %local.check.owner.end.1584
  %descriptor.extent.inside.1590 = icmp ule i32 %local.check.extent.1582, %stack.sub.1589
  %descriptor.payload.inside.1591 = icmp ule i32 %local.check.payload.1583, %local.check.extent.1582
  %descriptor.owner.offset.valid.1592 = and i1 %descriptor.owner.inside.1587, %descriptor.offset.inside.1588
  %descriptor.range.inside.1594 = and i1 %descriptor.owner.offset.valid.1592, %descriptor.extent.inside.1590
  %descriptor.range.valid.1593 = and i1 %descriptor.range.inside.1594, %descriptor.payload.inside.1591
  br i1 %descriptor.range.valid.1593, label %descriptor.valid.1595, label %descriptor.invalid.1596
descriptor.invalid.1596:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1595:
  %descriptor.initialized.status.1597 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1581, i32 %local.check.extent.1582)
  %helper.ok.1598 = icmp eq i32 %descriptor.initialized.status.1597, 0
  br i1 %helper.ok.1598, label %helper.continue.1599, label %frame.failure.0
helper.continue.1599:
  br label %local.descriptor.checked.1580
local.descriptor.inactive.1579:
  br label %local.descriptor.checked.1580
local.descriptor.checked.1580:
  %step.status.1600 = call i32 @al_owning_charge_step(ptr %ctx, i32 13)
  %helper.ok.1601 = icmp eq i32 %step.status.1600, 0
  br i1 %helper.ok.1601, label %helper.continue.1602, label %frame.failure.0
helper.continue.1602:
  %local.resolved.offset.1603 = load i32, ptr %local.offset.21, align 4
  %local.resolved.extent.1604 = load i32, ptr %local.extent.22, align 4
  %local.resolved.payload.1605 = load i32, ptr %local.payload.23, align 4
  %local.resolved.owner.end.1606 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1607 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1608 = load i32, ptr %context.field.1607, align 4
  %stack.sub.1611 = sub i32 %local.resolved.owner.end.1606, %local.resolved.offset.1603
  %descriptor.owner.inside.1609 = icmp ule i32 %local.resolved.owner.end.1606, %context.value.1608
  %descriptor.offset.inside.1610 = icmp ule i32 %local.resolved.offset.1603, %local.resolved.owner.end.1606
  %descriptor.extent.inside.1612 = icmp ule i32 %local.resolved.extent.1604, %stack.sub.1611
  %descriptor.payload.inside.1613 = icmp ule i32 %local.resolved.payload.1605, %local.resolved.extent.1604
  %descriptor.owner.offset.valid.1614 = and i1 %descriptor.owner.inside.1609, %descriptor.offset.inside.1610
  %descriptor.range.inside.1616 = and i1 %descriptor.owner.offset.valid.1614, %descriptor.extent.inside.1612
  %descriptor.range.valid.1615 = and i1 %descriptor.range.inside.1616, %descriptor.payload.inside.1613
  %descriptor.type.valid.1617 = icmp eq i32 8, 8
  %descriptor.valid.1618 = and i1 %descriptor.range.valid.1615, %descriptor.type.valid.1617
  br i1 %descriptor.valid.1618, label %descriptor.valid.1619, label %descriptor.invalid.1620
descriptor.invalid.1620:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1619:
  %descriptor.initialized.status.1621 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1603, i32 %local.resolved.extent.1604)
  %helper.ok.1622 = icmp eq i32 %descriptor.initialized.status.1621, 0
  br i1 %helper.ok.1622, label %helper.continue.1623, label %frame.failure.0
helper.continue.1623:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %local.resolved.offset.1603, i32 20, i32 %local.resolved.payload.1605, i32 %local.resolved.owner.end.1606, i32 %local.resolved.extent.1604)
  %context.field.1624 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1625 = load i32, ptr %context.field.1624, align 4
  %runtime.ok.1626 = icmp eq i32 %context.value.1625, 0
  br i1 %runtime.ok.1626, label %runtime.continue.1627, label %frame.failure.0
runtime.continue.1627:
  %context.field.1628 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1629 = load i32, ptr %context.field.1628, align 4
  %stack.sub.1632 = sub i32 %local.resolved.owner.end.1606, %local.resolved.offset.1603
  %descriptor.owner.inside.1630 = icmp ule i32 %local.resolved.owner.end.1606, %context.value.1629
  %descriptor.offset.inside.1631 = icmp ule i32 %local.resolved.offset.1603, %local.resolved.owner.end.1606
  %descriptor.extent.inside.1633 = icmp ule i32 %local.resolved.extent.1604, %stack.sub.1632
  %descriptor.payload.inside.1634 = icmp ule i32 %local.resolved.payload.1605, %local.resolved.extent.1604
  %descriptor.owner.offset.valid.1635 = and i1 %descriptor.owner.inside.1630, %descriptor.offset.inside.1631
  %descriptor.range.inside.1637 = and i1 %descriptor.owner.offset.valid.1635, %descriptor.extent.inside.1633
  %descriptor.range.valid.1636 = and i1 %descriptor.range.inside.1637, %descriptor.payload.inside.1634
  %descriptor.type.valid.1638 = icmp eq i32 8, 8
  %descriptor.valid.1639 = and i1 %descriptor.range.valid.1636, %descriptor.type.valid.1638
  br i1 %descriptor.valid.1639, label %descriptor.valid.1640, label %descriptor.invalid.1641
descriptor.invalid.1641:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1640:
  %descriptor.initialized.status.1642 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1603, i32 %local.resolved.extent.1604)
  %helper.ok.1643 = icmp eq i32 %descriptor.initialized.status.1642, 0
  br i1 %helper.ok.1643, label %helper.continue.1644, label %frame.failure.0
helper.continue.1644:
  %local.is.active.1645 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1645, label %local.descriptor.active.1646, label %local.descriptor.inactive.1647
local.descriptor.active.1646:
  %local.check.offset.1649 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1650 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1651 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1652 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1653 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1654 = load i32, ptr %context.field.1653, align 4
  %stack.sub.1657 = sub i32 %local.check.owner.end.1652, %local.check.offset.1649
  %descriptor.owner.inside.1655 = icmp ule i32 %local.check.owner.end.1652, %context.value.1654
  %descriptor.offset.inside.1656 = icmp ule i32 %local.check.offset.1649, %local.check.owner.end.1652
  %descriptor.extent.inside.1658 = icmp ule i32 %local.check.extent.1650, %stack.sub.1657
  %descriptor.payload.inside.1659 = icmp ule i32 %local.check.payload.1651, %local.check.extent.1650
  %descriptor.owner.offset.valid.1660 = and i1 %descriptor.owner.inside.1655, %descriptor.offset.inside.1656
  %descriptor.range.inside.1662 = and i1 %descriptor.owner.offset.valid.1660, %descriptor.extent.inside.1658
  %descriptor.range.valid.1661 = and i1 %descriptor.range.inside.1662, %descriptor.payload.inside.1659
  br i1 %descriptor.range.valid.1661, label %descriptor.valid.1663, label %descriptor.invalid.1664
descriptor.invalid.1664:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1663:
  %descriptor.initialized.status.1665 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1649, i32 %local.check.extent.1650)
  %helper.ok.1666 = icmp eq i32 %descriptor.initialized.status.1665, 0
  br i1 %helper.ok.1666, label %helper.continue.1667, label %frame.failure.0
helper.continue.1667:
  br label %local.descriptor.checked.1648
local.descriptor.inactive.1647:
  br label %local.descriptor.checked.1648
local.descriptor.checked.1648:
  %local.is.active.1668 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1668, label %local.descriptor.active.1669, label %local.descriptor.inactive.1670
local.descriptor.active.1669:
  %local.check.offset.1672 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1673 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1674 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1675 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1676 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1677 = load i32, ptr %context.field.1676, align 4
  %stack.sub.1680 = sub i32 %local.check.owner.end.1675, %local.check.offset.1672
  %descriptor.owner.inside.1678 = icmp ule i32 %local.check.owner.end.1675, %context.value.1677
  %descriptor.offset.inside.1679 = icmp ule i32 %local.check.offset.1672, %local.check.owner.end.1675
  %descriptor.extent.inside.1681 = icmp ule i32 %local.check.extent.1673, %stack.sub.1680
  %descriptor.payload.inside.1682 = icmp ule i32 %local.check.payload.1674, %local.check.extent.1673
  %descriptor.owner.offset.valid.1683 = and i1 %descriptor.owner.inside.1678, %descriptor.offset.inside.1679
  %descriptor.range.inside.1685 = and i1 %descriptor.owner.offset.valid.1683, %descriptor.extent.inside.1681
  %descriptor.range.valid.1684 = and i1 %descriptor.range.inside.1685, %descriptor.payload.inside.1682
  br i1 %descriptor.range.valid.1684, label %descriptor.valid.1686, label %descriptor.invalid.1687
descriptor.invalid.1687:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1686:
  %descriptor.initialized.status.1688 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1672, i32 %local.check.extent.1673)
  %helper.ok.1689 = icmp eq i32 %descriptor.initialized.status.1688, 0
  br i1 %helper.ok.1689, label %helper.continue.1690, label %frame.failure.0
helper.continue.1690:
  br label %local.descriptor.checked.1671
local.descriptor.inactive.1670:
  br label %local.descriptor.checked.1671
local.descriptor.checked.1671:
  %local.is.active.1691 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1691, label %local.descriptor.active.1692, label %local.descriptor.inactive.1693
local.descriptor.active.1692:
  %local.check.offset.1695 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1696 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1697 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1698 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1699 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1700 = load i32, ptr %context.field.1699, align 4
  %stack.sub.1703 = sub i32 %local.check.owner.end.1698, %local.check.offset.1695
  %descriptor.owner.inside.1701 = icmp ule i32 %local.check.owner.end.1698, %context.value.1700
  %descriptor.offset.inside.1702 = icmp ule i32 %local.check.offset.1695, %local.check.owner.end.1698
  %descriptor.extent.inside.1704 = icmp ule i32 %local.check.extent.1696, %stack.sub.1703
  %descriptor.payload.inside.1705 = icmp ule i32 %local.check.payload.1697, %local.check.extent.1696
  %descriptor.owner.offset.valid.1706 = and i1 %descriptor.owner.inside.1701, %descriptor.offset.inside.1702
  %descriptor.range.inside.1708 = and i1 %descriptor.owner.offset.valid.1706, %descriptor.extent.inside.1704
  %descriptor.range.valid.1707 = and i1 %descriptor.range.inside.1708, %descriptor.payload.inside.1705
  br i1 %descriptor.range.valid.1707, label %descriptor.valid.1709, label %descriptor.invalid.1710
descriptor.invalid.1710:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1709:
  %descriptor.initialized.status.1711 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1695, i32 %local.check.extent.1696)
  %helper.ok.1712 = icmp eq i32 %descriptor.initialized.status.1711, 0
  br i1 %helper.ok.1712, label %helper.continue.1713, label %frame.failure.0
helper.continue.1713:
  br label %local.descriptor.checked.1694
local.descriptor.inactive.1693:
  br label %local.descriptor.checked.1694
local.descriptor.checked.1694:
  %local.is.active.1714 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1714, label %local.descriptor.active.1715, label %local.descriptor.inactive.1716
local.descriptor.active.1715:
  %local.check.offset.1718 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1719 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1720 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1721 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1722 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1723 = load i32, ptr %context.field.1722, align 4
  %stack.sub.1726 = sub i32 %local.check.owner.end.1721, %local.check.offset.1718
  %descriptor.owner.inside.1724 = icmp ule i32 %local.check.owner.end.1721, %context.value.1723
  %descriptor.offset.inside.1725 = icmp ule i32 %local.check.offset.1718, %local.check.owner.end.1721
  %descriptor.extent.inside.1727 = icmp ule i32 %local.check.extent.1719, %stack.sub.1726
  %descriptor.payload.inside.1728 = icmp ule i32 %local.check.payload.1720, %local.check.extent.1719
  %descriptor.owner.offset.valid.1729 = and i1 %descriptor.owner.inside.1724, %descriptor.offset.inside.1725
  %descriptor.range.inside.1731 = and i1 %descriptor.owner.offset.valid.1729, %descriptor.extent.inside.1727
  %descriptor.range.valid.1730 = and i1 %descriptor.range.inside.1731, %descriptor.payload.inside.1728
  br i1 %descriptor.range.valid.1730, label %descriptor.valid.1732, label %descriptor.invalid.1733
descriptor.invalid.1733:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1732:
  %descriptor.initialized.status.1734 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1718, i32 %local.check.extent.1719)
  %helper.ok.1735 = icmp eq i32 %descriptor.initialized.status.1734, 0
  br i1 %helper.ok.1735, label %helper.continue.1736, label %frame.failure.0
helper.continue.1736:
  br label %local.descriptor.checked.1717
local.descriptor.inactive.1716:
  br label %local.descriptor.checked.1717
local.descriptor.checked.1717:
  %local.is.active.1737 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1737, label %local.descriptor.active.1738, label %local.descriptor.inactive.1739
local.descriptor.active.1738:
  %local.check.offset.1741 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1742 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1743 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1744 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1745 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1746 = load i32, ptr %context.field.1745, align 4
  %stack.sub.1749 = sub i32 %local.check.owner.end.1744, %local.check.offset.1741
  %descriptor.owner.inside.1747 = icmp ule i32 %local.check.owner.end.1744, %context.value.1746
  %descriptor.offset.inside.1748 = icmp ule i32 %local.check.offset.1741, %local.check.owner.end.1744
  %descriptor.extent.inside.1750 = icmp ule i32 %local.check.extent.1742, %stack.sub.1749
  %descriptor.payload.inside.1751 = icmp ule i32 %local.check.payload.1743, %local.check.extent.1742
  %descriptor.owner.offset.valid.1752 = and i1 %descriptor.owner.inside.1747, %descriptor.offset.inside.1748
  %descriptor.range.inside.1754 = and i1 %descriptor.owner.offset.valid.1752, %descriptor.extent.inside.1750
  %descriptor.range.valid.1753 = and i1 %descriptor.range.inside.1754, %descriptor.payload.inside.1751
  br i1 %descriptor.range.valid.1753, label %descriptor.valid.1755, label %descriptor.invalid.1756
descriptor.invalid.1756:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1755:
  %descriptor.initialized.status.1757 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1741, i32 %local.check.extent.1742)
  %helper.ok.1758 = icmp eq i32 %descriptor.initialized.status.1757, 0
  br i1 %helper.ok.1758, label %helper.continue.1759, label %frame.failure.0
helper.continue.1759:
  br label %local.descriptor.checked.1740
local.descriptor.inactive.1739:
  br label %local.descriptor.checked.1740
local.descriptor.checked.1740:
  %step.status.1760 = call i32 @al_owning_charge_step(ptr %ctx, i32 14)
  %helper.ok.1761 = icmp eq i32 %step.status.1760, 0
  br i1 %helper.ok.1761, label %helper.continue.1762, label %frame.failure.0
helper.continue.1762:
  %field.location.1763 = alloca %AlOwningFieldLocation, align 4
  %field.location.status.1764 = call i32 @al_owning_locate_field(ptr %ctx, ptr @al_owning_layout, i32 2, i32 %local.resolved.offset.1603, i32 %local.resolved.extent.1604, i32 0, i32 15, ptr %field.location.1763)
  %helper.ok.1765 = icmp eq i32 %field.location.status.1764, 0
  br i1 %helper.ok.1765, label %helper.continue.1766, label %frame.failure.0
helper.continue.1766:
  %field.offset.pointer.1767 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.1763, i32 0, i32 0
  %field.offset.1768 = load i32, ptr %field.offset.pointer.1767, align 4
  %field.payload.pointer.1769 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.1763, i32 0, i32 1
  %field.payload.1770 = load i32, ptr %field.payload.pointer.1769, align 4
  %field.extent.pointer.1771 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.1763, i32 0, i32 2
  %field.extent.1772 = load i32, ptr %field.extent.pointer.1771, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 7, i32 9, i32 %local.resolved.offset.1603, i32 %field.extent.1772, i32 %field.payload.1770, i32 %field.offset.1768, i32 %field.extent.1772)
  %context.field.1773 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1774 = load i32, ptr %context.field.1773, align 4
  %runtime.ok.1775 = icmp eq i32 %context.value.1774, 0
  br i1 %runtime.ok.1775, label %runtime.continue.1776, label %frame.failure.0
runtime.continue.1776:
  %context.field.1777 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1778 = load i32, ptr %context.field.1777, align 4
  %stack.sub.1781 = sub i32 %local.resolved.owner.end.1606, %field.offset.1768
  %descriptor.owner.inside.1779 = icmp ule i32 %local.resolved.owner.end.1606, %context.value.1778
  %descriptor.offset.inside.1780 = icmp ule i32 %field.offset.1768, %local.resolved.owner.end.1606
  %descriptor.extent.inside.1782 = icmp ule i32 %field.extent.1772, %stack.sub.1781
  %descriptor.payload.inside.1783 = icmp ule i32 %field.payload.1770, %field.extent.1772
  %descriptor.owner.offset.valid.1784 = and i1 %descriptor.owner.inside.1779, %descriptor.offset.inside.1780
  %descriptor.range.inside.1786 = and i1 %descriptor.owner.offset.valid.1784, %descriptor.extent.inside.1782
  %descriptor.range.valid.1785 = and i1 %descriptor.range.inside.1786, %descriptor.payload.inside.1783
  %descriptor.type.valid.1787 = icmp eq i32 9, 9
  %descriptor.valid.1788 = and i1 %descriptor.range.valid.1785, %descriptor.type.valid.1787
  br i1 %descriptor.valid.1788, label %descriptor.valid.1789, label %descriptor.invalid.1790
descriptor.invalid.1790:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1789:
  %descriptor.initialized.status.1791 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %field.offset.1768, i32 %field.extent.1772)
  %helper.ok.1792 = icmp eq i32 %descriptor.initialized.status.1791, 0
  br i1 %helper.ok.1792, label %helper.continue.1793, label %frame.failure.0
helper.continue.1793:
  %local.is.active.1794 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1794, label %local.descriptor.active.1795, label %local.descriptor.inactive.1796
local.descriptor.active.1795:
  %local.check.offset.1798 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1799 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1800 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1801 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1802 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1803 = load i32, ptr %context.field.1802, align 4
  %stack.sub.1806 = sub i32 %local.check.owner.end.1801, %local.check.offset.1798
  %descriptor.owner.inside.1804 = icmp ule i32 %local.check.owner.end.1801, %context.value.1803
  %descriptor.offset.inside.1805 = icmp ule i32 %local.check.offset.1798, %local.check.owner.end.1801
  %descriptor.extent.inside.1807 = icmp ule i32 %local.check.extent.1799, %stack.sub.1806
  %descriptor.payload.inside.1808 = icmp ule i32 %local.check.payload.1800, %local.check.extent.1799
  %descriptor.owner.offset.valid.1809 = and i1 %descriptor.owner.inside.1804, %descriptor.offset.inside.1805
  %descriptor.range.inside.1811 = and i1 %descriptor.owner.offset.valid.1809, %descriptor.extent.inside.1807
  %descriptor.range.valid.1810 = and i1 %descriptor.range.inside.1811, %descriptor.payload.inside.1808
  br i1 %descriptor.range.valid.1810, label %descriptor.valid.1812, label %descriptor.invalid.1813
descriptor.invalid.1813:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1812:
  %descriptor.initialized.status.1814 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1798, i32 %local.check.extent.1799)
  %helper.ok.1815 = icmp eq i32 %descriptor.initialized.status.1814, 0
  br i1 %helper.ok.1815, label %helper.continue.1816, label %frame.failure.0
helper.continue.1816:
  br label %local.descriptor.checked.1797
local.descriptor.inactive.1796:
  br label %local.descriptor.checked.1797
local.descriptor.checked.1797:
  %local.is.active.1817 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1817, label %local.descriptor.active.1818, label %local.descriptor.inactive.1819
local.descriptor.active.1818:
  %local.check.offset.1821 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1822 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1823 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1824 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1825 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1826 = load i32, ptr %context.field.1825, align 4
  %stack.sub.1829 = sub i32 %local.check.owner.end.1824, %local.check.offset.1821
  %descriptor.owner.inside.1827 = icmp ule i32 %local.check.owner.end.1824, %context.value.1826
  %descriptor.offset.inside.1828 = icmp ule i32 %local.check.offset.1821, %local.check.owner.end.1824
  %descriptor.extent.inside.1830 = icmp ule i32 %local.check.extent.1822, %stack.sub.1829
  %descriptor.payload.inside.1831 = icmp ule i32 %local.check.payload.1823, %local.check.extent.1822
  %descriptor.owner.offset.valid.1832 = and i1 %descriptor.owner.inside.1827, %descriptor.offset.inside.1828
  %descriptor.range.inside.1834 = and i1 %descriptor.owner.offset.valid.1832, %descriptor.extent.inside.1830
  %descriptor.range.valid.1833 = and i1 %descriptor.range.inside.1834, %descriptor.payload.inside.1831
  br i1 %descriptor.range.valid.1833, label %descriptor.valid.1835, label %descriptor.invalid.1836
descriptor.invalid.1836:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1835:
  %descriptor.initialized.status.1837 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1821, i32 %local.check.extent.1822)
  %helper.ok.1838 = icmp eq i32 %descriptor.initialized.status.1837, 0
  br i1 %helper.ok.1838, label %helper.continue.1839, label %frame.failure.0
helper.continue.1839:
  br label %local.descriptor.checked.1820
local.descriptor.inactive.1819:
  br label %local.descriptor.checked.1820
local.descriptor.checked.1820:
  %local.is.active.1840 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1840, label %local.descriptor.active.1841, label %local.descriptor.inactive.1842
local.descriptor.active.1841:
  %local.check.offset.1844 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1845 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1846 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1847 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1848 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1849 = load i32, ptr %context.field.1848, align 4
  %stack.sub.1852 = sub i32 %local.check.owner.end.1847, %local.check.offset.1844
  %descriptor.owner.inside.1850 = icmp ule i32 %local.check.owner.end.1847, %context.value.1849
  %descriptor.offset.inside.1851 = icmp ule i32 %local.check.offset.1844, %local.check.owner.end.1847
  %descriptor.extent.inside.1853 = icmp ule i32 %local.check.extent.1845, %stack.sub.1852
  %descriptor.payload.inside.1854 = icmp ule i32 %local.check.payload.1846, %local.check.extent.1845
  %descriptor.owner.offset.valid.1855 = and i1 %descriptor.owner.inside.1850, %descriptor.offset.inside.1851
  %descriptor.range.inside.1857 = and i1 %descriptor.owner.offset.valid.1855, %descriptor.extent.inside.1853
  %descriptor.range.valid.1856 = and i1 %descriptor.range.inside.1857, %descriptor.payload.inside.1854
  br i1 %descriptor.range.valid.1856, label %descriptor.valid.1858, label %descriptor.invalid.1859
descriptor.invalid.1859:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1858:
  %descriptor.initialized.status.1860 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1844, i32 %local.check.extent.1845)
  %helper.ok.1861 = icmp eq i32 %descriptor.initialized.status.1860, 0
  br i1 %helper.ok.1861, label %helper.continue.1862, label %frame.failure.0
helper.continue.1862:
  br label %local.descriptor.checked.1843
local.descriptor.inactive.1842:
  br label %local.descriptor.checked.1843
local.descriptor.checked.1843:
  %local.is.active.1863 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1863, label %local.descriptor.active.1864, label %local.descriptor.inactive.1865
local.descriptor.active.1864:
  %local.check.offset.1867 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1868 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1869 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1870 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1871 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1872 = load i32, ptr %context.field.1871, align 4
  %stack.sub.1875 = sub i32 %local.check.owner.end.1870, %local.check.offset.1867
  %descriptor.owner.inside.1873 = icmp ule i32 %local.check.owner.end.1870, %context.value.1872
  %descriptor.offset.inside.1874 = icmp ule i32 %local.check.offset.1867, %local.check.owner.end.1870
  %descriptor.extent.inside.1876 = icmp ule i32 %local.check.extent.1868, %stack.sub.1875
  %descriptor.payload.inside.1877 = icmp ule i32 %local.check.payload.1869, %local.check.extent.1868
  %descriptor.owner.offset.valid.1878 = and i1 %descriptor.owner.inside.1873, %descriptor.offset.inside.1874
  %descriptor.range.inside.1880 = and i1 %descriptor.owner.offset.valid.1878, %descriptor.extent.inside.1876
  %descriptor.range.valid.1879 = and i1 %descriptor.range.inside.1880, %descriptor.payload.inside.1877
  br i1 %descriptor.range.valid.1879, label %descriptor.valid.1881, label %descriptor.invalid.1882
descriptor.invalid.1882:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1881:
  %descriptor.initialized.status.1883 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1867, i32 %local.check.extent.1868)
  %helper.ok.1884 = icmp eq i32 %descriptor.initialized.status.1883, 0
  br i1 %helper.ok.1884, label %helper.continue.1885, label %frame.failure.0
helper.continue.1885:
  br label %local.descriptor.checked.1866
local.descriptor.inactive.1865:
  br label %local.descriptor.checked.1866
local.descriptor.checked.1866:
  %local.is.active.1886 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1886, label %local.descriptor.active.1887, label %local.descriptor.inactive.1888
local.descriptor.active.1887:
  %local.check.offset.1890 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1891 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1892 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1893 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1894 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1895 = load i32, ptr %context.field.1894, align 4
  %stack.sub.1898 = sub i32 %local.check.owner.end.1893, %local.check.offset.1890
  %descriptor.owner.inside.1896 = icmp ule i32 %local.check.owner.end.1893, %context.value.1895
  %descriptor.offset.inside.1897 = icmp ule i32 %local.check.offset.1890, %local.check.owner.end.1893
  %descriptor.extent.inside.1899 = icmp ule i32 %local.check.extent.1891, %stack.sub.1898
  %descriptor.payload.inside.1900 = icmp ule i32 %local.check.payload.1892, %local.check.extent.1891
  %descriptor.owner.offset.valid.1901 = and i1 %descriptor.owner.inside.1896, %descriptor.offset.inside.1897
  %descriptor.range.inside.1903 = and i1 %descriptor.owner.offset.valid.1901, %descriptor.extent.inside.1899
  %descriptor.range.valid.1902 = and i1 %descriptor.range.inside.1903, %descriptor.payload.inside.1900
  br i1 %descriptor.range.valid.1902, label %descriptor.valid.1904, label %descriptor.invalid.1905
descriptor.invalid.1905:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1904:
  %descriptor.initialized.status.1906 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1890, i32 %local.check.extent.1891)
  %helper.ok.1907 = icmp eq i32 %descriptor.initialized.status.1906, 0
  br i1 %helper.ok.1907, label %helper.continue.1908, label %frame.failure.0
helper.continue.1908:
  br label %local.descriptor.checked.1889
local.descriptor.inactive.1888:
  br label %local.descriptor.checked.1889
local.descriptor.checked.1889:
  %step.status.1909 = call i32 @al_owning_charge_step(ptr %ctx, i32 16)
  %helper.ok.1910 = icmp eq i32 %step.status.1909, 0
  br i1 %helper.ok.1910, label %helper.continue.1911, label %frame.failure.0
helper.continue.1911:
  %field.location.1912 = alloca %AlOwningFieldLocation, align 4
  %field.location.status.1913 = call i32 @al_owning_locate_field(ptr %ctx, ptr @al_owning_layout, i32 3, i32 %field.offset.1768, i32 %field.extent.1772, i32 0, i32 17, ptr %field.location.1912)
  %helper.ok.1914 = icmp eq i32 %field.location.status.1913, 0
  br i1 %helper.ok.1914, label %helper.continue.1915, label %frame.failure.0
helper.continue.1915:
  %field.offset.pointer.1916 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.1912, i32 0, i32 0
  %field.offset.1917 = load i32, ptr %field.offset.pointer.1916, align 4
  %field.payload.pointer.1918 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.1912, i32 0, i32 1
  %field.payload.1919 = load i32, ptr %field.payload.pointer.1918, align 4
  %field.extent.pointer.1920 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.1912, i32 0, i32 2
  %field.extent.1921 = load i32, ptr %field.extent.pointer.1920, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 7, i32 12, i32 %field.offset.1768, i32 %field.extent.1921, i32 %field.payload.1919, i32 %field.offset.1917, i32 %field.extent.1921)
  %context.field.1922 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1923 = load i32, ptr %context.field.1922, align 4
  %runtime.ok.1924 = icmp eq i32 %context.value.1923, 0
  br i1 %runtime.ok.1924, label %runtime.continue.1925, label %frame.failure.0
runtime.continue.1925:
  %context.field.1926 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1927 = load i32, ptr %context.field.1926, align 4
  %stack.sub.1930 = sub i32 %local.resolved.owner.end.1606, %field.offset.1917
  %descriptor.owner.inside.1928 = icmp ule i32 %local.resolved.owner.end.1606, %context.value.1927
  %descriptor.offset.inside.1929 = icmp ule i32 %field.offset.1917, %local.resolved.owner.end.1606
  %descriptor.extent.inside.1931 = icmp ule i32 %field.extent.1921, %stack.sub.1930
  %descriptor.payload.inside.1932 = icmp ule i32 %field.payload.1919, %field.extent.1921
  %descriptor.owner.offset.valid.1933 = and i1 %descriptor.owner.inside.1928, %descriptor.offset.inside.1929
  %descriptor.range.inside.1935 = and i1 %descriptor.owner.offset.valid.1933, %descriptor.extent.inside.1931
  %descriptor.range.valid.1934 = and i1 %descriptor.range.inside.1935, %descriptor.payload.inside.1932
  %descriptor.type.valid.1936 = icmp eq i32 12, 12
  %descriptor.valid.1937 = and i1 %descriptor.range.valid.1934, %descriptor.type.valid.1936
  br i1 %descriptor.valid.1937, label %descriptor.valid.1938, label %descriptor.invalid.1939
descriptor.invalid.1939:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1938:
  %descriptor.initialized.status.1940 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %field.offset.1917, i32 %field.extent.1921)
  %helper.ok.1941 = icmp eq i32 %descriptor.initialized.status.1940, 0
  br i1 %helper.ok.1941, label %helper.continue.1942, label %frame.failure.0
helper.continue.1942:
  %local.is.active.1943 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1943, label %local.descriptor.active.1944, label %local.descriptor.inactive.1945
local.descriptor.active.1944:
  %local.check.offset.1947 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1948 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1949 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1950 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1951 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1952 = load i32, ptr %context.field.1951, align 4
  %stack.sub.1955 = sub i32 %local.check.owner.end.1950, %local.check.offset.1947
  %descriptor.owner.inside.1953 = icmp ule i32 %local.check.owner.end.1950, %context.value.1952
  %descriptor.offset.inside.1954 = icmp ule i32 %local.check.offset.1947, %local.check.owner.end.1950
  %descriptor.extent.inside.1956 = icmp ule i32 %local.check.extent.1948, %stack.sub.1955
  %descriptor.payload.inside.1957 = icmp ule i32 %local.check.payload.1949, %local.check.extent.1948
  %descriptor.owner.offset.valid.1958 = and i1 %descriptor.owner.inside.1953, %descriptor.offset.inside.1954
  %descriptor.range.inside.1960 = and i1 %descriptor.owner.offset.valid.1958, %descriptor.extent.inside.1956
  %descriptor.range.valid.1959 = and i1 %descriptor.range.inside.1960, %descriptor.payload.inside.1957
  br i1 %descriptor.range.valid.1959, label %descriptor.valid.1961, label %descriptor.invalid.1962
descriptor.invalid.1962:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1961:
  %descriptor.initialized.status.1963 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1947, i32 %local.check.extent.1948)
  %helper.ok.1964 = icmp eq i32 %descriptor.initialized.status.1963, 0
  br i1 %helper.ok.1964, label %helper.continue.1965, label %frame.failure.0
helper.continue.1965:
  br label %local.descriptor.checked.1946
local.descriptor.inactive.1945:
  br label %local.descriptor.checked.1946
local.descriptor.checked.1946:
  %local.is.active.1966 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1966, label %local.descriptor.active.1967, label %local.descriptor.inactive.1968
local.descriptor.active.1967:
  %local.check.offset.1970 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1971 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1972 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1973 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1974 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1975 = load i32, ptr %context.field.1974, align 4
  %stack.sub.1978 = sub i32 %local.check.owner.end.1973, %local.check.offset.1970
  %descriptor.owner.inside.1976 = icmp ule i32 %local.check.owner.end.1973, %context.value.1975
  %descriptor.offset.inside.1977 = icmp ule i32 %local.check.offset.1970, %local.check.owner.end.1973
  %descriptor.extent.inside.1979 = icmp ule i32 %local.check.extent.1971, %stack.sub.1978
  %descriptor.payload.inside.1980 = icmp ule i32 %local.check.payload.1972, %local.check.extent.1971
  %descriptor.owner.offset.valid.1981 = and i1 %descriptor.owner.inside.1976, %descriptor.offset.inside.1977
  %descriptor.range.inside.1983 = and i1 %descriptor.owner.offset.valid.1981, %descriptor.extent.inside.1979
  %descriptor.range.valid.1982 = and i1 %descriptor.range.inside.1983, %descriptor.payload.inside.1980
  br i1 %descriptor.range.valid.1982, label %descriptor.valid.1984, label %descriptor.invalid.1985
descriptor.invalid.1985:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1984:
  %descriptor.initialized.status.1986 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1970, i32 %local.check.extent.1971)
  %helper.ok.1987 = icmp eq i32 %descriptor.initialized.status.1986, 0
  br i1 %helper.ok.1987, label %helper.continue.1988, label %frame.failure.0
helper.continue.1988:
  br label %local.descriptor.checked.1969
local.descriptor.inactive.1968:
  br label %local.descriptor.checked.1969
local.descriptor.checked.1969:
  %local.is.active.1989 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1989, label %local.descriptor.active.1990, label %local.descriptor.inactive.1991
local.descriptor.active.1990:
  %local.check.offset.1993 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1994 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1995 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1996 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1997 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1998 = load i32, ptr %context.field.1997, align 4
  %stack.sub.2001 = sub i32 %local.check.owner.end.1996, %local.check.offset.1993
  %descriptor.owner.inside.1999 = icmp ule i32 %local.check.owner.end.1996, %context.value.1998
  %descriptor.offset.inside.2000 = icmp ule i32 %local.check.offset.1993, %local.check.owner.end.1996
  %descriptor.extent.inside.2002 = icmp ule i32 %local.check.extent.1994, %stack.sub.2001
  %descriptor.payload.inside.2003 = icmp ule i32 %local.check.payload.1995, %local.check.extent.1994
  %descriptor.owner.offset.valid.2004 = and i1 %descriptor.owner.inside.1999, %descriptor.offset.inside.2000
  %descriptor.range.inside.2006 = and i1 %descriptor.owner.offset.valid.2004, %descriptor.extent.inside.2002
  %descriptor.range.valid.2005 = and i1 %descriptor.range.inside.2006, %descriptor.payload.inside.2003
  br i1 %descriptor.range.valid.2005, label %descriptor.valid.2007, label %descriptor.invalid.2008
descriptor.invalid.2008:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2007:
  %descriptor.initialized.status.2009 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1993, i32 %local.check.extent.1994)
  %helper.ok.2010 = icmp eq i32 %descriptor.initialized.status.2009, 0
  br i1 %helper.ok.2010, label %helper.continue.2011, label %frame.failure.0
helper.continue.2011:
  br label %local.descriptor.checked.1992
local.descriptor.inactive.1991:
  br label %local.descriptor.checked.1992
local.descriptor.checked.1992:
  %local.is.active.2012 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2012, label %local.descriptor.active.2013, label %local.descriptor.inactive.2014
local.descriptor.active.2013:
  %local.check.offset.2016 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2017 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2018 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2019 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2020 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2021 = load i32, ptr %context.field.2020, align 4
  %stack.sub.2024 = sub i32 %local.check.owner.end.2019, %local.check.offset.2016
  %descriptor.owner.inside.2022 = icmp ule i32 %local.check.owner.end.2019, %context.value.2021
  %descriptor.offset.inside.2023 = icmp ule i32 %local.check.offset.2016, %local.check.owner.end.2019
  %descriptor.extent.inside.2025 = icmp ule i32 %local.check.extent.2017, %stack.sub.2024
  %descriptor.payload.inside.2026 = icmp ule i32 %local.check.payload.2018, %local.check.extent.2017
  %descriptor.owner.offset.valid.2027 = and i1 %descriptor.owner.inside.2022, %descriptor.offset.inside.2023
  %descriptor.range.inside.2029 = and i1 %descriptor.owner.offset.valid.2027, %descriptor.extent.inside.2025
  %descriptor.range.valid.2028 = and i1 %descriptor.range.inside.2029, %descriptor.payload.inside.2026
  br i1 %descriptor.range.valid.2028, label %descriptor.valid.2030, label %descriptor.invalid.2031
descriptor.invalid.2031:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2030:
  %descriptor.initialized.status.2032 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2016, i32 %local.check.extent.2017)
  %helper.ok.2033 = icmp eq i32 %descriptor.initialized.status.2032, 0
  br i1 %helper.ok.2033, label %helper.continue.2034, label %frame.failure.0
helper.continue.2034:
  br label %local.descriptor.checked.2015
local.descriptor.inactive.2014:
  br label %local.descriptor.checked.2015
local.descriptor.checked.2015:
  %local.is.active.2035 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2035, label %local.descriptor.active.2036, label %local.descriptor.inactive.2037
local.descriptor.active.2036:
  %local.check.offset.2039 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2040 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2041 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2042 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2043 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2044 = load i32, ptr %context.field.2043, align 4
  %stack.sub.2047 = sub i32 %local.check.owner.end.2042, %local.check.offset.2039
  %descriptor.owner.inside.2045 = icmp ule i32 %local.check.owner.end.2042, %context.value.2044
  %descriptor.offset.inside.2046 = icmp ule i32 %local.check.offset.2039, %local.check.owner.end.2042
  %descriptor.extent.inside.2048 = icmp ule i32 %local.check.extent.2040, %stack.sub.2047
  %descriptor.payload.inside.2049 = icmp ule i32 %local.check.payload.2041, %local.check.extent.2040
  %descriptor.owner.offset.valid.2050 = and i1 %descriptor.owner.inside.2045, %descriptor.offset.inside.2046
  %descriptor.range.inside.2052 = and i1 %descriptor.owner.offset.valid.2050, %descriptor.extent.inside.2048
  %descriptor.range.valid.2051 = and i1 %descriptor.range.inside.2052, %descriptor.payload.inside.2049
  br i1 %descriptor.range.valid.2051, label %descriptor.valid.2053, label %descriptor.invalid.2054
descriptor.invalid.2054:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2053:
  %descriptor.initialized.status.2055 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2039, i32 %local.check.extent.2040)
  %helper.ok.2056 = icmp eq i32 %descriptor.initialized.status.2055, 0
  br i1 %helper.ok.2056, label %helper.continue.2057, label %frame.failure.0
helper.continue.2057:
  br label %local.descriptor.checked.2038
local.descriptor.inactive.2037:
  br label %local.descriptor.checked.2038
local.descriptor.checked.2038:
  %step.status.2058 = call i32 @al_owning_charge_step(ptr %ctx, i32 18)
  %helper.ok.2059 = icmp eq i32 %step.status.2058, 0
  br i1 %helper.ok.2059, label %helper.continue.2060, label %frame.failure.0
helper.continue.2060:
  %string.length.units.2061 = alloca i32, align 4
  %string.length.status.2062 = call i32 @al_owning_string_length(ptr %ctx, i32 %field.offset.1917, i32 %field.extent.1921, i32 19, ptr %string.length.units.2061)
  %helper.ok.2063 = icmp eq i32 %string.length.status.2062, 0
  br i1 %helper.ok.2063, label %helper.continue.2064, label %frame.failure.0
helper.continue.2064:
  %string.length.value.2065 = load i32, ptr %string.length.units.2061, align 4
  %string.length.int.2066 = zext i32 %string.length.value.2065 to i64
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 12, i32 %field.offset.1917, i32 %field.extent.1921, i32 %field.payload.1919, i32 0, i32 0)
  %context.field.2067 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2068 = load i32, ptr %context.field.2067, align 4
  %runtime.ok.2069 = icmp eq i32 %context.value.2068, 0
  br i1 %runtime.ok.2069, label %runtime.continue.2070, label %frame.failure.0
runtime.continue.2070:
  %context.field.2071 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2072 = load i32, ptr %context.field.2071, align 4
  %stack.offset.2073 = add i32 %context.value.2072, 8
  %reserve.status.2074 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.2073, i32 20)
  %reserve.ok.2075 = icmp eq i32 %reserve.status.2074, 0
  br i1 %reserve.ok.2075, label %reserve.continue.2076, label %frame.failure.0
reserve.continue.2076:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.2072, i64 %string.length.int.2066, i32 1)
  %context.field.2077 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2078 = load i32, ptr %context.field.2077, align 4
  %runtime.ok.2079 = icmp eq i32 %context.value.2078, 0
  br i1 %runtime.ok.2079, label %runtime.continue.2080, label %frame.failure.0
runtime.continue.2080:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.2081 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2082 = load i32, ptr %context.field.2081, align 4
  %runtime.ok.2083 = icmp eq i32 %context.value.2082, 0
  br i1 %runtime.ok.2083, label %runtime.continue.2084, label %frame.failure.0
runtime.continue.2084:
  %stack.offset.2085 = add i32 %context.value.2072, 8
  %context.field.2086 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2087 = load i32, ptr %context.field.2086, align 4
  %stack.sub.2090 = sub i32 %stack.offset.2085, %context.value.2072
  %descriptor.owner.inside.2088 = icmp ule i32 %stack.offset.2085, %context.value.2087
  %descriptor.offset.inside.2089 = icmp ule i32 %context.value.2072, %stack.offset.2085
  %descriptor.extent.inside.2091 = icmp ule i32 8, %stack.sub.2090
  %descriptor.payload.inside.2092 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.2093 = and i1 %descriptor.owner.inside.2088, %descriptor.offset.inside.2089
  %descriptor.range.inside.2095 = and i1 %descriptor.owner.offset.valid.2093, %descriptor.extent.inside.2091
  %descriptor.range.valid.2094 = and i1 %descriptor.range.inside.2095, %descriptor.payload.inside.2092
  %descriptor.type.valid.2096 = icmp eq i32 1, 1
  %descriptor.valid.2097 = and i1 %descriptor.range.valid.2094, %descriptor.type.valid.2096
  br i1 %descriptor.valid.2097, label %descriptor.valid.2098, label %descriptor.invalid.2099
descriptor.invalid.2099:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2098:
  %descriptor.initialized.status.2100 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.2072, i32 8)
  %helper.ok.2101 = icmp eq i32 %descriptor.initialized.status.2100, 0
  br i1 %helper.ok.2101, label %helper.continue.2102, label %frame.failure.0
helper.continue.2102:
  %local.is.active.2103 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2103, label %local.descriptor.active.2104, label %local.descriptor.inactive.2105
local.descriptor.active.2104:
  %local.check.offset.2107 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2108 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2109 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2110 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2111 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2112 = load i32, ptr %context.field.2111, align 4
  %stack.sub.2115 = sub i32 %local.check.owner.end.2110, %local.check.offset.2107
  %descriptor.owner.inside.2113 = icmp ule i32 %local.check.owner.end.2110, %context.value.2112
  %descriptor.offset.inside.2114 = icmp ule i32 %local.check.offset.2107, %local.check.owner.end.2110
  %descriptor.extent.inside.2116 = icmp ule i32 %local.check.extent.2108, %stack.sub.2115
  %descriptor.payload.inside.2117 = icmp ule i32 %local.check.payload.2109, %local.check.extent.2108
  %descriptor.owner.offset.valid.2118 = and i1 %descriptor.owner.inside.2113, %descriptor.offset.inside.2114
  %descriptor.range.inside.2120 = and i1 %descriptor.owner.offset.valid.2118, %descriptor.extent.inside.2116
  %descriptor.range.valid.2119 = and i1 %descriptor.range.inside.2120, %descriptor.payload.inside.2117
  br i1 %descriptor.range.valid.2119, label %descriptor.valid.2121, label %descriptor.invalid.2122
descriptor.invalid.2122:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2121:
  %descriptor.initialized.status.2123 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2107, i32 %local.check.extent.2108)
  %helper.ok.2124 = icmp eq i32 %descriptor.initialized.status.2123, 0
  br i1 %helper.ok.2124, label %helper.continue.2125, label %frame.failure.0
helper.continue.2125:
  br label %local.descriptor.checked.2106
local.descriptor.inactive.2105:
  br label %local.descriptor.checked.2106
local.descriptor.checked.2106:
  %local.is.active.2126 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2126, label %local.descriptor.active.2127, label %local.descriptor.inactive.2128
local.descriptor.active.2127:
  %local.check.offset.2130 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2131 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2132 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2133 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2134 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2135 = load i32, ptr %context.field.2134, align 4
  %stack.sub.2138 = sub i32 %local.check.owner.end.2133, %local.check.offset.2130
  %descriptor.owner.inside.2136 = icmp ule i32 %local.check.owner.end.2133, %context.value.2135
  %descriptor.offset.inside.2137 = icmp ule i32 %local.check.offset.2130, %local.check.owner.end.2133
  %descriptor.extent.inside.2139 = icmp ule i32 %local.check.extent.2131, %stack.sub.2138
  %descriptor.payload.inside.2140 = icmp ule i32 %local.check.payload.2132, %local.check.extent.2131
  %descriptor.owner.offset.valid.2141 = and i1 %descriptor.owner.inside.2136, %descriptor.offset.inside.2137
  %descriptor.range.inside.2143 = and i1 %descriptor.owner.offset.valid.2141, %descriptor.extent.inside.2139
  %descriptor.range.valid.2142 = and i1 %descriptor.range.inside.2143, %descriptor.payload.inside.2140
  br i1 %descriptor.range.valid.2142, label %descriptor.valid.2144, label %descriptor.invalid.2145
descriptor.invalid.2145:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2144:
  %descriptor.initialized.status.2146 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2130, i32 %local.check.extent.2131)
  %helper.ok.2147 = icmp eq i32 %descriptor.initialized.status.2146, 0
  br i1 %helper.ok.2147, label %helper.continue.2148, label %frame.failure.0
helper.continue.2148:
  br label %local.descriptor.checked.2129
local.descriptor.inactive.2128:
  br label %local.descriptor.checked.2129
local.descriptor.checked.2129:
  %local.is.active.2149 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2149, label %local.descriptor.active.2150, label %local.descriptor.inactive.2151
local.descriptor.active.2150:
  %local.check.offset.2153 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2154 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2155 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2156 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2157 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2158 = load i32, ptr %context.field.2157, align 4
  %stack.sub.2161 = sub i32 %local.check.owner.end.2156, %local.check.offset.2153
  %descriptor.owner.inside.2159 = icmp ule i32 %local.check.owner.end.2156, %context.value.2158
  %descriptor.offset.inside.2160 = icmp ule i32 %local.check.offset.2153, %local.check.owner.end.2156
  %descriptor.extent.inside.2162 = icmp ule i32 %local.check.extent.2154, %stack.sub.2161
  %descriptor.payload.inside.2163 = icmp ule i32 %local.check.payload.2155, %local.check.extent.2154
  %descriptor.owner.offset.valid.2164 = and i1 %descriptor.owner.inside.2159, %descriptor.offset.inside.2160
  %descriptor.range.inside.2166 = and i1 %descriptor.owner.offset.valid.2164, %descriptor.extent.inside.2162
  %descriptor.range.valid.2165 = and i1 %descriptor.range.inside.2166, %descriptor.payload.inside.2163
  br i1 %descriptor.range.valid.2165, label %descriptor.valid.2167, label %descriptor.invalid.2168
descriptor.invalid.2168:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2167:
  %descriptor.initialized.status.2169 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2153, i32 %local.check.extent.2154)
  %helper.ok.2170 = icmp eq i32 %descriptor.initialized.status.2169, 0
  br i1 %helper.ok.2170, label %helper.continue.2171, label %frame.failure.0
helper.continue.2171:
  br label %local.descriptor.checked.2152
local.descriptor.inactive.2151:
  br label %local.descriptor.checked.2152
local.descriptor.checked.2152:
  %local.is.active.2172 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2172, label %local.descriptor.active.2173, label %local.descriptor.inactive.2174
local.descriptor.active.2173:
  %local.check.offset.2176 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2177 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2178 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2179 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2180 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2181 = load i32, ptr %context.field.2180, align 4
  %stack.sub.2184 = sub i32 %local.check.owner.end.2179, %local.check.offset.2176
  %descriptor.owner.inside.2182 = icmp ule i32 %local.check.owner.end.2179, %context.value.2181
  %descriptor.offset.inside.2183 = icmp ule i32 %local.check.offset.2176, %local.check.owner.end.2179
  %descriptor.extent.inside.2185 = icmp ule i32 %local.check.extent.2177, %stack.sub.2184
  %descriptor.payload.inside.2186 = icmp ule i32 %local.check.payload.2178, %local.check.extent.2177
  %descriptor.owner.offset.valid.2187 = and i1 %descriptor.owner.inside.2182, %descriptor.offset.inside.2183
  %descriptor.range.inside.2189 = and i1 %descriptor.owner.offset.valid.2187, %descriptor.extent.inside.2185
  %descriptor.range.valid.2188 = and i1 %descriptor.range.inside.2189, %descriptor.payload.inside.2186
  br i1 %descriptor.range.valid.2188, label %descriptor.valid.2190, label %descriptor.invalid.2191
descriptor.invalid.2191:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2190:
  %descriptor.initialized.status.2192 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2176, i32 %local.check.extent.2177)
  %helper.ok.2193 = icmp eq i32 %descriptor.initialized.status.2192, 0
  br i1 %helper.ok.2193, label %helper.continue.2194, label %frame.failure.0
helper.continue.2194:
  br label %local.descriptor.checked.2175
local.descriptor.inactive.2174:
  br label %local.descriptor.checked.2175
local.descriptor.checked.2175:
  %local.is.active.2195 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2195, label %local.descriptor.active.2196, label %local.descriptor.inactive.2197
local.descriptor.active.2196:
  %local.check.offset.2199 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2200 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2201 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2202 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2203 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2204 = load i32, ptr %context.field.2203, align 4
  %stack.sub.2207 = sub i32 %local.check.owner.end.2202, %local.check.offset.2199
  %descriptor.owner.inside.2205 = icmp ule i32 %local.check.owner.end.2202, %context.value.2204
  %descriptor.offset.inside.2206 = icmp ule i32 %local.check.offset.2199, %local.check.owner.end.2202
  %descriptor.extent.inside.2208 = icmp ule i32 %local.check.extent.2200, %stack.sub.2207
  %descriptor.payload.inside.2209 = icmp ule i32 %local.check.payload.2201, %local.check.extent.2200
  %descriptor.owner.offset.valid.2210 = and i1 %descriptor.owner.inside.2205, %descriptor.offset.inside.2206
  %descriptor.range.inside.2212 = and i1 %descriptor.owner.offset.valid.2210, %descriptor.extent.inside.2208
  %descriptor.range.valid.2211 = and i1 %descriptor.range.inside.2212, %descriptor.payload.inside.2209
  br i1 %descriptor.range.valid.2211, label %descriptor.valid.2213, label %descriptor.invalid.2214
descriptor.invalid.2214:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2213:
  %descriptor.initialized.status.2215 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2199, i32 %local.check.extent.2200)
  %helper.ok.2216 = icmp eq i32 %descriptor.initialized.status.2215, 0
  br i1 %helper.ok.2216, label %helper.continue.2217, label %frame.failure.0
helper.continue.2217:
  br label %local.descriptor.checked.2198
local.descriptor.inactive.2197:
  br label %local.descriptor.checked.2198
local.descriptor.checked.2198:
  %step.status.2218 = call i32 @al_owning_charge_step(ptr %ctx, i32 21)
  %helper.ok.2219 = icmp eq i32 %step.status.2218, 0
  br i1 %helper.ok.2219, label %helper.continue.2220, label %frame.failure.0
helper.continue.2220:
  store i1 true, ptr %local.active.26, align 1
  store i32 %context.value.2072, ptr %local.offset.27, align 4
  store i32 8, ptr %local.extent.28, align 4
  store i32 8, ptr %local.payload.29, align 4
  store i32 %stack.offset.2085, ptr %local.owner.end.30, align 4
  store i32 1, ptr %local.type.31, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %context.value.2072, i32 20, i32 8, i32 %stack.offset.2085, i32 8)
  %context.field.2221 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2222 = load i32, ptr %context.field.2221, align 4
  %runtime.ok.2223 = icmp eq i32 %context.value.2222, 0
  br i1 %runtime.ok.2223, label %runtime.continue.2224, label %frame.failure.0
runtime.continue.2224:
  %local.is.active.2225 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2225, label %local.descriptor.active.2226, label %local.descriptor.inactive.2227
local.descriptor.active.2226:
  %local.check.offset.2229 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2230 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2231 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2232 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2233 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2234 = load i32, ptr %context.field.2233, align 4
  %stack.sub.2237 = sub i32 %local.check.owner.end.2232, %local.check.offset.2229
  %descriptor.owner.inside.2235 = icmp ule i32 %local.check.owner.end.2232, %context.value.2234
  %descriptor.offset.inside.2236 = icmp ule i32 %local.check.offset.2229, %local.check.owner.end.2232
  %descriptor.extent.inside.2238 = icmp ule i32 %local.check.extent.2230, %stack.sub.2237
  %descriptor.payload.inside.2239 = icmp ule i32 %local.check.payload.2231, %local.check.extent.2230
  %descriptor.owner.offset.valid.2240 = and i1 %descriptor.owner.inside.2235, %descriptor.offset.inside.2236
  %descriptor.range.inside.2242 = and i1 %descriptor.owner.offset.valid.2240, %descriptor.extent.inside.2238
  %descriptor.range.valid.2241 = and i1 %descriptor.range.inside.2242, %descriptor.payload.inside.2239
  br i1 %descriptor.range.valid.2241, label %descriptor.valid.2243, label %descriptor.invalid.2244
descriptor.invalid.2244:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2243:
  %descriptor.initialized.status.2245 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2229, i32 %local.check.extent.2230)
  %helper.ok.2246 = icmp eq i32 %descriptor.initialized.status.2245, 0
  br i1 %helper.ok.2246, label %helper.continue.2247, label %frame.failure.0
helper.continue.2247:
  br label %local.descriptor.checked.2228
local.descriptor.inactive.2227:
  br label %local.descriptor.checked.2228
local.descriptor.checked.2228:
  %local.is.active.2248 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2248, label %local.descriptor.active.2249, label %local.descriptor.inactive.2250
local.descriptor.active.2249:
  %local.check.offset.2252 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2253 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2254 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2255 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2256 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2257 = load i32, ptr %context.field.2256, align 4
  %stack.sub.2260 = sub i32 %local.check.owner.end.2255, %local.check.offset.2252
  %descriptor.owner.inside.2258 = icmp ule i32 %local.check.owner.end.2255, %context.value.2257
  %descriptor.offset.inside.2259 = icmp ule i32 %local.check.offset.2252, %local.check.owner.end.2255
  %descriptor.extent.inside.2261 = icmp ule i32 %local.check.extent.2253, %stack.sub.2260
  %descriptor.payload.inside.2262 = icmp ule i32 %local.check.payload.2254, %local.check.extent.2253
  %descriptor.owner.offset.valid.2263 = and i1 %descriptor.owner.inside.2258, %descriptor.offset.inside.2259
  %descriptor.range.inside.2265 = and i1 %descriptor.owner.offset.valid.2263, %descriptor.extent.inside.2261
  %descriptor.range.valid.2264 = and i1 %descriptor.range.inside.2265, %descriptor.payload.inside.2262
  br i1 %descriptor.range.valid.2264, label %descriptor.valid.2266, label %descriptor.invalid.2267
descriptor.invalid.2267:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2266:
  %descriptor.initialized.status.2268 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2252, i32 %local.check.extent.2253)
  %helper.ok.2269 = icmp eq i32 %descriptor.initialized.status.2268, 0
  br i1 %helper.ok.2269, label %helper.continue.2270, label %frame.failure.0
helper.continue.2270:
  br label %local.descriptor.checked.2251
local.descriptor.inactive.2250:
  br label %local.descriptor.checked.2251
local.descriptor.checked.2251:
  %local.is.active.2271 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2271, label %local.descriptor.active.2272, label %local.descriptor.inactive.2273
local.descriptor.active.2272:
  %local.check.offset.2275 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2276 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2277 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2278 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2279 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2280 = load i32, ptr %context.field.2279, align 4
  %stack.sub.2283 = sub i32 %local.check.owner.end.2278, %local.check.offset.2275
  %descriptor.owner.inside.2281 = icmp ule i32 %local.check.owner.end.2278, %context.value.2280
  %descriptor.offset.inside.2282 = icmp ule i32 %local.check.offset.2275, %local.check.owner.end.2278
  %descriptor.extent.inside.2284 = icmp ule i32 %local.check.extent.2276, %stack.sub.2283
  %descriptor.payload.inside.2285 = icmp ule i32 %local.check.payload.2277, %local.check.extent.2276
  %descriptor.owner.offset.valid.2286 = and i1 %descriptor.owner.inside.2281, %descriptor.offset.inside.2282
  %descriptor.range.inside.2288 = and i1 %descriptor.owner.offset.valid.2286, %descriptor.extent.inside.2284
  %descriptor.range.valid.2287 = and i1 %descriptor.range.inside.2288, %descriptor.payload.inside.2285
  br i1 %descriptor.range.valid.2287, label %descriptor.valid.2289, label %descriptor.invalid.2290
descriptor.invalid.2290:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2289:
  %descriptor.initialized.status.2291 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2275, i32 %local.check.extent.2276)
  %helper.ok.2292 = icmp eq i32 %descriptor.initialized.status.2291, 0
  br i1 %helper.ok.2292, label %helper.continue.2293, label %frame.failure.0
helper.continue.2293:
  br label %local.descriptor.checked.2274
local.descriptor.inactive.2273:
  br label %local.descriptor.checked.2274
local.descriptor.checked.2274:
  %local.is.active.2294 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2294, label %local.descriptor.active.2295, label %local.descriptor.inactive.2296
local.descriptor.active.2295:
  %local.check.offset.2298 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2299 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2300 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2301 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2302 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2303 = load i32, ptr %context.field.2302, align 4
  %stack.sub.2306 = sub i32 %local.check.owner.end.2301, %local.check.offset.2298
  %descriptor.owner.inside.2304 = icmp ule i32 %local.check.owner.end.2301, %context.value.2303
  %descriptor.offset.inside.2305 = icmp ule i32 %local.check.offset.2298, %local.check.owner.end.2301
  %descriptor.extent.inside.2307 = icmp ule i32 %local.check.extent.2299, %stack.sub.2306
  %descriptor.payload.inside.2308 = icmp ule i32 %local.check.payload.2300, %local.check.extent.2299
  %descriptor.owner.offset.valid.2309 = and i1 %descriptor.owner.inside.2304, %descriptor.offset.inside.2305
  %descriptor.range.inside.2311 = and i1 %descriptor.owner.offset.valid.2309, %descriptor.extent.inside.2307
  %descriptor.range.valid.2310 = and i1 %descriptor.range.inside.2311, %descriptor.payload.inside.2308
  br i1 %descriptor.range.valid.2310, label %descriptor.valid.2312, label %descriptor.invalid.2313
descriptor.invalid.2313:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2312:
  %descriptor.initialized.status.2314 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2298, i32 %local.check.extent.2299)
  %helper.ok.2315 = icmp eq i32 %descriptor.initialized.status.2314, 0
  br i1 %helper.ok.2315, label %helper.continue.2316, label %frame.failure.0
helper.continue.2316:
  br label %local.descriptor.checked.2297
local.descriptor.inactive.2296:
  br label %local.descriptor.checked.2297
local.descriptor.checked.2297:
  %local.is.active.2317 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2317, label %local.descriptor.active.2318, label %local.descriptor.inactive.2319
local.descriptor.active.2318:
  %local.check.offset.2321 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2322 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2323 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2324 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2325 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2326 = load i32, ptr %context.field.2325, align 4
  %stack.sub.2329 = sub i32 %local.check.owner.end.2324, %local.check.offset.2321
  %descriptor.owner.inside.2327 = icmp ule i32 %local.check.owner.end.2324, %context.value.2326
  %descriptor.offset.inside.2328 = icmp ule i32 %local.check.offset.2321, %local.check.owner.end.2324
  %descriptor.extent.inside.2330 = icmp ule i32 %local.check.extent.2322, %stack.sub.2329
  %descriptor.payload.inside.2331 = icmp ule i32 %local.check.payload.2323, %local.check.extent.2322
  %descriptor.owner.offset.valid.2332 = and i1 %descriptor.owner.inside.2327, %descriptor.offset.inside.2328
  %descriptor.range.inside.2334 = and i1 %descriptor.owner.offset.valid.2332, %descriptor.extent.inside.2330
  %descriptor.range.valid.2333 = and i1 %descriptor.range.inside.2334, %descriptor.payload.inside.2331
  br i1 %descriptor.range.valid.2333, label %descriptor.valid.2335, label %descriptor.invalid.2336
descriptor.invalid.2336:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2335:
  %descriptor.initialized.status.2337 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2321, i32 %local.check.extent.2322)
  %helper.ok.2338 = icmp eq i32 %descriptor.initialized.status.2337, 0
  br i1 %helper.ok.2338, label %helper.continue.2339, label %frame.failure.0
helper.continue.2339:
  br label %local.descriptor.checked.2320
local.descriptor.inactive.2319:
  br label %local.descriptor.checked.2320
local.descriptor.checked.2320:
  %step.status.2340 = call i32 @al_owning_charge_step(ptr %ctx, i32 22)
  %helper.ok.2341 = icmp eq i32 %step.status.2340, 0
  br i1 %helper.ok.2341, label %helper.continue.2342, label %frame.failure.0
helper.continue.2342:
  %local.resolved.offset.2343 = load i32, ptr %local.offset.21, align 4
  %local.resolved.extent.2344 = load i32, ptr %local.extent.22, align 4
  %local.resolved.payload.2345 = load i32, ptr %local.payload.23, align 4
  %local.resolved.owner.end.2346 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2347 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2348 = load i32, ptr %context.field.2347, align 4
  %stack.sub.2351 = sub i32 %local.resolved.owner.end.2346, %local.resolved.offset.2343
  %descriptor.owner.inside.2349 = icmp ule i32 %local.resolved.owner.end.2346, %context.value.2348
  %descriptor.offset.inside.2350 = icmp ule i32 %local.resolved.offset.2343, %local.resolved.owner.end.2346
  %descriptor.extent.inside.2352 = icmp ule i32 %local.resolved.extent.2344, %stack.sub.2351
  %descriptor.payload.inside.2353 = icmp ule i32 %local.resolved.payload.2345, %local.resolved.extent.2344
  %descriptor.owner.offset.valid.2354 = and i1 %descriptor.owner.inside.2349, %descriptor.offset.inside.2350
  %descriptor.range.inside.2356 = and i1 %descriptor.owner.offset.valid.2354, %descriptor.extent.inside.2352
  %descriptor.range.valid.2355 = and i1 %descriptor.range.inside.2356, %descriptor.payload.inside.2353
  %descriptor.type.valid.2357 = icmp eq i32 8, 8
  %descriptor.valid.2358 = and i1 %descriptor.range.valid.2355, %descriptor.type.valid.2357
  br i1 %descriptor.valid.2358, label %descriptor.valid.2359, label %descriptor.invalid.2360
descriptor.invalid.2360:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2359:
  %descriptor.initialized.status.2361 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.2343, i32 %local.resolved.extent.2344)
  %helper.ok.2362 = icmp eq i32 %descriptor.initialized.status.2361, 0
  br i1 %helper.ok.2362, label %helper.continue.2363, label %frame.failure.0
helper.continue.2363:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %local.resolved.offset.2343, i32 20, i32 %local.resolved.payload.2345, i32 %local.resolved.owner.end.2346, i32 %local.resolved.extent.2344)
  %context.field.2364 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2365 = load i32, ptr %context.field.2364, align 4
  %runtime.ok.2366 = icmp eq i32 %context.value.2365, 0
  br i1 %runtime.ok.2366, label %runtime.continue.2367, label %frame.failure.0
runtime.continue.2367:
  %context.field.2368 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2369 = load i32, ptr %context.field.2368, align 4
  %stack.sub.2372 = sub i32 %local.resolved.owner.end.2346, %local.resolved.offset.2343
  %descriptor.owner.inside.2370 = icmp ule i32 %local.resolved.owner.end.2346, %context.value.2369
  %descriptor.offset.inside.2371 = icmp ule i32 %local.resolved.offset.2343, %local.resolved.owner.end.2346
  %descriptor.extent.inside.2373 = icmp ule i32 %local.resolved.extent.2344, %stack.sub.2372
  %descriptor.payload.inside.2374 = icmp ule i32 %local.resolved.payload.2345, %local.resolved.extent.2344
  %descriptor.owner.offset.valid.2375 = and i1 %descriptor.owner.inside.2370, %descriptor.offset.inside.2371
  %descriptor.range.inside.2377 = and i1 %descriptor.owner.offset.valid.2375, %descriptor.extent.inside.2373
  %descriptor.range.valid.2376 = and i1 %descriptor.range.inside.2377, %descriptor.payload.inside.2374
  %descriptor.type.valid.2378 = icmp eq i32 8, 8
  %descriptor.valid.2379 = and i1 %descriptor.range.valid.2376, %descriptor.type.valid.2378
  br i1 %descriptor.valid.2379, label %descriptor.valid.2380, label %descriptor.invalid.2381
descriptor.invalid.2381:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2380:
  %descriptor.initialized.status.2382 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.2343, i32 %local.resolved.extent.2344)
  %helper.ok.2383 = icmp eq i32 %descriptor.initialized.status.2382, 0
  br i1 %helper.ok.2383, label %helper.continue.2384, label %frame.failure.0
helper.continue.2384:
  %local.is.active.2385 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2385, label %local.descriptor.active.2386, label %local.descriptor.inactive.2387
local.descriptor.active.2386:
  %local.check.offset.2389 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2390 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2391 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2392 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2393 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2394 = load i32, ptr %context.field.2393, align 4
  %stack.sub.2397 = sub i32 %local.check.owner.end.2392, %local.check.offset.2389
  %descriptor.owner.inside.2395 = icmp ule i32 %local.check.owner.end.2392, %context.value.2394
  %descriptor.offset.inside.2396 = icmp ule i32 %local.check.offset.2389, %local.check.owner.end.2392
  %descriptor.extent.inside.2398 = icmp ule i32 %local.check.extent.2390, %stack.sub.2397
  %descriptor.payload.inside.2399 = icmp ule i32 %local.check.payload.2391, %local.check.extent.2390
  %descriptor.owner.offset.valid.2400 = and i1 %descriptor.owner.inside.2395, %descriptor.offset.inside.2396
  %descriptor.range.inside.2402 = and i1 %descriptor.owner.offset.valid.2400, %descriptor.extent.inside.2398
  %descriptor.range.valid.2401 = and i1 %descriptor.range.inside.2402, %descriptor.payload.inside.2399
  br i1 %descriptor.range.valid.2401, label %descriptor.valid.2403, label %descriptor.invalid.2404
descriptor.invalid.2404:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2403:
  %descriptor.initialized.status.2405 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2389, i32 %local.check.extent.2390)
  %helper.ok.2406 = icmp eq i32 %descriptor.initialized.status.2405, 0
  br i1 %helper.ok.2406, label %helper.continue.2407, label %frame.failure.0
helper.continue.2407:
  br label %local.descriptor.checked.2388
local.descriptor.inactive.2387:
  br label %local.descriptor.checked.2388
local.descriptor.checked.2388:
  %local.is.active.2408 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2408, label %local.descriptor.active.2409, label %local.descriptor.inactive.2410
local.descriptor.active.2409:
  %local.check.offset.2412 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2413 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2414 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2415 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2416 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2417 = load i32, ptr %context.field.2416, align 4
  %stack.sub.2420 = sub i32 %local.check.owner.end.2415, %local.check.offset.2412
  %descriptor.owner.inside.2418 = icmp ule i32 %local.check.owner.end.2415, %context.value.2417
  %descriptor.offset.inside.2419 = icmp ule i32 %local.check.offset.2412, %local.check.owner.end.2415
  %descriptor.extent.inside.2421 = icmp ule i32 %local.check.extent.2413, %stack.sub.2420
  %descriptor.payload.inside.2422 = icmp ule i32 %local.check.payload.2414, %local.check.extent.2413
  %descriptor.owner.offset.valid.2423 = and i1 %descriptor.owner.inside.2418, %descriptor.offset.inside.2419
  %descriptor.range.inside.2425 = and i1 %descriptor.owner.offset.valid.2423, %descriptor.extent.inside.2421
  %descriptor.range.valid.2424 = and i1 %descriptor.range.inside.2425, %descriptor.payload.inside.2422
  br i1 %descriptor.range.valid.2424, label %descriptor.valid.2426, label %descriptor.invalid.2427
descriptor.invalid.2427:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2426:
  %descriptor.initialized.status.2428 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2412, i32 %local.check.extent.2413)
  %helper.ok.2429 = icmp eq i32 %descriptor.initialized.status.2428, 0
  br i1 %helper.ok.2429, label %helper.continue.2430, label %frame.failure.0
helper.continue.2430:
  br label %local.descriptor.checked.2411
local.descriptor.inactive.2410:
  br label %local.descriptor.checked.2411
local.descriptor.checked.2411:
  %local.is.active.2431 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2431, label %local.descriptor.active.2432, label %local.descriptor.inactive.2433
local.descriptor.active.2432:
  %local.check.offset.2435 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2436 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2437 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2438 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2439 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2440 = load i32, ptr %context.field.2439, align 4
  %stack.sub.2443 = sub i32 %local.check.owner.end.2438, %local.check.offset.2435
  %descriptor.owner.inside.2441 = icmp ule i32 %local.check.owner.end.2438, %context.value.2440
  %descriptor.offset.inside.2442 = icmp ule i32 %local.check.offset.2435, %local.check.owner.end.2438
  %descriptor.extent.inside.2444 = icmp ule i32 %local.check.extent.2436, %stack.sub.2443
  %descriptor.payload.inside.2445 = icmp ule i32 %local.check.payload.2437, %local.check.extent.2436
  %descriptor.owner.offset.valid.2446 = and i1 %descriptor.owner.inside.2441, %descriptor.offset.inside.2442
  %descriptor.range.inside.2448 = and i1 %descriptor.owner.offset.valid.2446, %descriptor.extent.inside.2444
  %descriptor.range.valid.2447 = and i1 %descriptor.range.inside.2448, %descriptor.payload.inside.2445
  br i1 %descriptor.range.valid.2447, label %descriptor.valid.2449, label %descriptor.invalid.2450
descriptor.invalid.2450:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2449:
  %descriptor.initialized.status.2451 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2435, i32 %local.check.extent.2436)
  %helper.ok.2452 = icmp eq i32 %descriptor.initialized.status.2451, 0
  br i1 %helper.ok.2452, label %helper.continue.2453, label %frame.failure.0
helper.continue.2453:
  br label %local.descriptor.checked.2434
local.descriptor.inactive.2433:
  br label %local.descriptor.checked.2434
local.descriptor.checked.2434:
  %local.is.active.2454 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2454, label %local.descriptor.active.2455, label %local.descriptor.inactive.2456
local.descriptor.active.2455:
  %local.check.offset.2458 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2459 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2460 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2461 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2462 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2463 = load i32, ptr %context.field.2462, align 4
  %stack.sub.2466 = sub i32 %local.check.owner.end.2461, %local.check.offset.2458
  %descriptor.owner.inside.2464 = icmp ule i32 %local.check.owner.end.2461, %context.value.2463
  %descriptor.offset.inside.2465 = icmp ule i32 %local.check.offset.2458, %local.check.owner.end.2461
  %descriptor.extent.inside.2467 = icmp ule i32 %local.check.extent.2459, %stack.sub.2466
  %descriptor.payload.inside.2468 = icmp ule i32 %local.check.payload.2460, %local.check.extent.2459
  %descriptor.owner.offset.valid.2469 = and i1 %descriptor.owner.inside.2464, %descriptor.offset.inside.2465
  %descriptor.range.inside.2471 = and i1 %descriptor.owner.offset.valid.2469, %descriptor.extent.inside.2467
  %descriptor.range.valid.2470 = and i1 %descriptor.range.inside.2471, %descriptor.payload.inside.2468
  br i1 %descriptor.range.valid.2470, label %descriptor.valid.2472, label %descriptor.invalid.2473
descriptor.invalid.2473:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2472:
  %descriptor.initialized.status.2474 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2458, i32 %local.check.extent.2459)
  %helper.ok.2475 = icmp eq i32 %descriptor.initialized.status.2474, 0
  br i1 %helper.ok.2475, label %helper.continue.2476, label %frame.failure.0
helper.continue.2476:
  br label %local.descriptor.checked.2457
local.descriptor.inactive.2456:
  br label %local.descriptor.checked.2457
local.descriptor.checked.2457:
  %local.is.active.2477 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2477, label %local.descriptor.active.2478, label %local.descriptor.inactive.2479
local.descriptor.active.2478:
  %local.check.offset.2481 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2482 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2483 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2484 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2485 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2486 = load i32, ptr %context.field.2485, align 4
  %stack.sub.2489 = sub i32 %local.check.owner.end.2484, %local.check.offset.2481
  %descriptor.owner.inside.2487 = icmp ule i32 %local.check.owner.end.2484, %context.value.2486
  %descriptor.offset.inside.2488 = icmp ule i32 %local.check.offset.2481, %local.check.owner.end.2484
  %descriptor.extent.inside.2490 = icmp ule i32 %local.check.extent.2482, %stack.sub.2489
  %descriptor.payload.inside.2491 = icmp ule i32 %local.check.payload.2483, %local.check.extent.2482
  %descriptor.owner.offset.valid.2492 = and i1 %descriptor.owner.inside.2487, %descriptor.offset.inside.2488
  %descriptor.range.inside.2494 = and i1 %descriptor.owner.offset.valid.2492, %descriptor.extent.inside.2490
  %descriptor.range.valid.2493 = and i1 %descriptor.range.inside.2494, %descriptor.payload.inside.2491
  br i1 %descriptor.range.valid.2493, label %descriptor.valid.2495, label %descriptor.invalid.2496
descriptor.invalid.2496:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2495:
  %descriptor.initialized.status.2497 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2481, i32 %local.check.extent.2482)
  %helper.ok.2498 = icmp eq i32 %descriptor.initialized.status.2497, 0
  br i1 %helper.ok.2498, label %helper.continue.2499, label %frame.failure.0
helper.continue.2499:
  br label %local.descriptor.checked.2480
local.descriptor.inactive.2479:
  br label %local.descriptor.checked.2480
local.descriptor.checked.2480:
  %step.status.2500 = call i32 @al_owning_charge_step(ptr %ctx, i32 23)
  %helper.ok.2501 = icmp eq i32 %step.status.2500, 0
  br i1 %helper.ok.2501, label %helper.continue.2502, label %frame.failure.0
helper.continue.2502:
  %local.resolved.offset.2503 = load i32, ptr %local.offset.27, align 4
  %local.resolved.extent.2504 = load i32, ptr %local.extent.28, align 4
  %local.resolved.payload.2505 = load i32, ptr %local.payload.29, align 4
  %local.resolved.owner.end.2506 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2507 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2508 = load i32, ptr %context.field.2507, align 4
  %stack.sub.2511 = sub i32 %local.resolved.owner.end.2506, %local.resolved.offset.2503
  %descriptor.owner.inside.2509 = icmp ule i32 %local.resolved.owner.end.2506, %context.value.2508
  %descriptor.offset.inside.2510 = icmp ule i32 %local.resolved.offset.2503, %local.resolved.owner.end.2506
  %descriptor.extent.inside.2512 = icmp ule i32 %local.resolved.extent.2504, %stack.sub.2511
  %descriptor.payload.inside.2513 = icmp ule i32 %local.resolved.payload.2505, %local.resolved.extent.2504
  %descriptor.owner.offset.valid.2514 = and i1 %descriptor.owner.inside.2509, %descriptor.offset.inside.2510
  %descriptor.range.inside.2516 = and i1 %descriptor.owner.offset.valid.2514, %descriptor.extent.inside.2512
  %descriptor.range.valid.2515 = and i1 %descriptor.range.inside.2516, %descriptor.payload.inside.2513
  %descriptor.type.valid.2517 = icmp eq i32 1, 1
  %descriptor.valid.2518 = and i1 %descriptor.range.valid.2515, %descriptor.type.valid.2517
  br i1 %descriptor.valid.2518, label %descriptor.valid.2519, label %descriptor.invalid.2520
descriptor.invalid.2520:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2519:
  %descriptor.initialized.status.2521 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.2503, i32 %local.resolved.extent.2504)
  %helper.ok.2522 = icmp eq i32 %descriptor.initialized.status.2521, 0
  br i1 %helper.ok.2522, label %helper.continue.2523, label %frame.failure.0
helper.continue.2523:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %local.resolved.offset.2503, i32 20, i32 %local.resolved.payload.2505, i32 %local.resolved.owner.end.2506, i32 %local.resolved.extent.2504)
  %context.field.2524 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2525 = load i32, ptr %context.field.2524, align 4
  %runtime.ok.2526 = icmp eq i32 %context.value.2525, 0
  br i1 %runtime.ok.2526, label %runtime.continue.2527, label %frame.failure.0
runtime.continue.2527:
  %context.field.2528 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2529 = load i32, ptr %context.field.2528, align 4
  %stack.sub.2532 = sub i32 %local.resolved.owner.end.2346, %local.resolved.offset.2343
  %descriptor.owner.inside.2530 = icmp ule i32 %local.resolved.owner.end.2346, %context.value.2529
  %descriptor.offset.inside.2531 = icmp ule i32 %local.resolved.offset.2343, %local.resolved.owner.end.2346
  %descriptor.extent.inside.2533 = icmp ule i32 %local.resolved.extent.2344, %stack.sub.2532
  %descriptor.payload.inside.2534 = icmp ule i32 %local.resolved.payload.2345, %local.resolved.extent.2344
  %descriptor.owner.offset.valid.2535 = and i1 %descriptor.owner.inside.2530, %descriptor.offset.inside.2531
  %descriptor.range.inside.2537 = and i1 %descriptor.owner.offset.valid.2535, %descriptor.extent.inside.2533
  %descriptor.range.valid.2536 = and i1 %descriptor.range.inside.2537, %descriptor.payload.inside.2534
  %descriptor.type.valid.2538 = icmp eq i32 8, 8
  %descriptor.valid.2539 = and i1 %descriptor.range.valid.2536, %descriptor.type.valid.2538
  br i1 %descriptor.valid.2539, label %descriptor.valid.2540, label %descriptor.invalid.2541
descriptor.invalid.2541:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2540:
  %descriptor.initialized.status.2542 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.2343, i32 %local.resolved.extent.2344)
  %helper.ok.2543 = icmp eq i32 %descriptor.initialized.status.2542, 0
  br i1 %helper.ok.2543, label %helper.continue.2544, label %frame.failure.0
helper.continue.2544:
  %context.field.2545 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2546 = load i32, ptr %context.field.2545, align 4
  %stack.sub.2549 = sub i32 %local.resolved.owner.end.2506, %local.resolved.offset.2503
  %descriptor.owner.inside.2547 = icmp ule i32 %local.resolved.owner.end.2506, %context.value.2546
  %descriptor.offset.inside.2548 = icmp ule i32 %local.resolved.offset.2503, %local.resolved.owner.end.2506
  %descriptor.extent.inside.2550 = icmp ule i32 %local.resolved.extent.2504, %stack.sub.2549
  %descriptor.payload.inside.2551 = icmp ule i32 %local.resolved.payload.2505, %local.resolved.extent.2504
  %descriptor.owner.offset.valid.2552 = and i1 %descriptor.owner.inside.2547, %descriptor.offset.inside.2548
  %descriptor.range.inside.2554 = and i1 %descriptor.owner.offset.valid.2552, %descriptor.extent.inside.2550
  %descriptor.range.valid.2553 = and i1 %descriptor.range.inside.2554, %descriptor.payload.inside.2551
  %descriptor.type.valid.2555 = icmp eq i32 1, 1
  %descriptor.valid.2556 = and i1 %descriptor.range.valid.2553, %descriptor.type.valid.2555
  br i1 %descriptor.valid.2556, label %descriptor.valid.2557, label %descriptor.invalid.2558
descriptor.invalid.2558:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2557:
  %descriptor.initialized.status.2559 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.2503, i32 %local.resolved.extent.2504)
  %helper.ok.2560 = icmp eq i32 %descriptor.initialized.status.2559, 0
  br i1 %helper.ok.2560, label %helper.continue.2561, label %frame.failure.0
helper.continue.2561:
  %local.is.active.2562 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2562, label %local.descriptor.active.2563, label %local.descriptor.inactive.2564
local.descriptor.active.2563:
  %local.check.offset.2566 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2567 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2568 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2569 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2570 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2571 = load i32, ptr %context.field.2570, align 4
  %stack.sub.2574 = sub i32 %local.check.owner.end.2569, %local.check.offset.2566
  %descriptor.owner.inside.2572 = icmp ule i32 %local.check.owner.end.2569, %context.value.2571
  %descriptor.offset.inside.2573 = icmp ule i32 %local.check.offset.2566, %local.check.owner.end.2569
  %descriptor.extent.inside.2575 = icmp ule i32 %local.check.extent.2567, %stack.sub.2574
  %descriptor.payload.inside.2576 = icmp ule i32 %local.check.payload.2568, %local.check.extent.2567
  %descriptor.owner.offset.valid.2577 = and i1 %descriptor.owner.inside.2572, %descriptor.offset.inside.2573
  %descriptor.range.inside.2579 = and i1 %descriptor.owner.offset.valid.2577, %descriptor.extent.inside.2575
  %descriptor.range.valid.2578 = and i1 %descriptor.range.inside.2579, %descriptor.payload.inside.2576
  br i1 %descriptor.range.valid.2578, label %descriptor.valid.2580, label %descriptor.invalid.2581
descriptor.invalid.2581:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2580:
  %descriptor.initialized.status.2582 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2566, i32 %local.check.extent.2567)
  %helper.ok.2583 = icmp eq i32 %descriptor.initialized.status.2582, 0
  br i1 %helper.ok.2583, label %helper.continue.2584, label %frame.failure.0
helper.continue.2584:
  br label %local.descriptor.checked.2565
local.descriptor.inactive.2564:
  br label %local.descriptor.checked.2565
local.descriptor.checked.2565:
  %local.is.active.2585 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2585, label %local.descriptor.active.2586, label %local.descriptor.inactive.2587
local.descriptor.active.2586:
  %local.check.offset.2589 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2590 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2591 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2592 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2593 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2594 = load i32, ptr %context.field.2593, align 4
  %stack.sub.2597 = sub i32 %local.check.owner.end.2592, %local.check.offset.2589
  %descriptor.owner.inside.2595 = icmp ule i32 %local.check.owner.end.2592, %context.value.2594
  %descriptor.offset.inside.2596 = icmp ule i32 %local.check.offset.2589, %local.check.owner.end.2592
  %descriptor.extent.inside.2598 = icmp ule i32 %local.check.extent.2590, %stack.sub.2597
  %descriptor.payload.inside.2599 = icmp ule i32 %local.check.payload.2591, %local.check.extent.2590
  %descriptor.owner.offset.valid.2600 = and i1 %descriptor.owner.inside.2595, %descriptor.offset.inside.2596
  %descriptor.range.inside.2602 = and i1 %descriptor.owner.offset.valid.2600, %descriptor.extent.inside.2598
  %descriptor.range.valid.2601 = and i1 %descriptor.range.inside.2602, %descriptor.payload.inside.2599
  br i1 %descriptor.range.valid.2601, label %descriptor.valid.2603, label %descriptor.invalid.2604
descriptor.invalid.2604:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2603:
  %descriptor.initialized.status.2605 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2589, i32 %local.check.extent.2590)
  %helper.ok.2606 = icmp eq i32 %descriptor.initialized.status.2605, 0
  br i1 %helper.ok.2606, label %helper.continue.2607, label %frame.failure.0
helper.continue.2607:
  br label %local.descriptor.checked.2588
local.descriptor.inactive.2587:
  br label %local.descriptor.checked.2588
local.descriptor.checked.2588:
  %local.is.active.2608 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2608, label %local.descriptor.active.2609, label %local.descriptor.inactive.2610
local.descriptor.active.2609:
  %local.check.offset.2612 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2613 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2614 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2615 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2616 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2617 = load i32, ptr %context.field.2616, align 4
  %stack.sub.2620 = sub i32 %local.check.owner.end.2615, %local.check.offset.2612
  %descriptor.owner.inside.2618 = icmp ule i32 %local.check.owner.end.2615, %context.value.2617
  %descriptor.offset.inside.2619 = icmp ule i32 %local.check.offset.2612, %local.check.owner.end.2615
  %descriptor.extent.inside.2621 = icmp ule i32 %local.check.extent.2613, %stack.sub.2620
  %descriptor.payload.inside.2622 = icmp ule i32 %local.check.payload.2614, %local.check.extent.2613
  %descriptor.owner.offset.valid.2623 = and i1 %descriptor.owner.inside.2618, %descriptor.offset.inside.2619
  %descriptor.range.inside.2625 = and i1 %descriptor.owner.offset.valid.2623, %descriptor.extent.inside.2621
  %descriptor.range.valid.2624 = and i1 %descriptor.range.inside.2625, %descriptor.payload.inside.2622
  br i1 %descriptor.range.valid.2624, label %descriptor.valid.2626, label %descriptor.invalid.2627
descriptor.invalid.2627:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2626:
  %descriptor.initialized.status.2628 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2612, i32 %local.check.extent.2613)
  %helper.ok.2629 = icmp eq i32 %descriptor.initialized.status.2628, 0
  br i1 %helper.ok.2629, label %helper.continue.2630, label %frame.failure.0
helper.continue.2630:
  br label %local.descriptor.checked.2611
local.descriptor.inactive.2610:
  br label %local.descriptor.checked.2611
local.descriptor.checked.2611:
  %local.is.active.2631 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2631, label %local.descriptor.active.2632, label %local.descriptor.inactive.2633
local.descriptor.active.2632:
  %local.check.offset.2635 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2636 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2637 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2638 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2639 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2640 = load i32, ptr %context.field.2639, align 4
  %stack.sub.2643 = sub i32 %local.check.owner.end.2638, %local.check.offset.2635
  %descriptor.owner.inside.2641 = icmp ule i32 %local.check.owner.end.2638, %context.value.2640
  %descriptor.offset.inside.2642 = icmp ule i32 %local.check.offset.2635, %local.check.owner.end.2638
  %descriptor.extent.inside.2644 = icmp ule i32 %local.check.extent.2636, %stack.sub.2643
  %descriptor.payload.inside.2645 = icmp ule i32 %local.check.payload.2637, %local.check.extent.2636
  %descriptor.owner.offset.valid.2646 = and i1 %descriptor.owner.inside.2641, %descriptor.offset.inside.2642
  %descriptor.range.inside.2648 = and i1 %descriptor.owner.offset.valid.2646, %descriptor.extent.inside.2644
  %descriptor.range.valid.2647 = and i1 %descriptor.range.inside.2648, %descriptor.payload.inside.2645
  br i1 %descriptor.range.valid.2647, label %descriptor.valid.2649, label %descriptor.invalid.2650
descriptor.invalid.2650:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2649:
  %descriptor.initialized.status.2651 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2635, i32 %local.check.extent.2636)
  %helper.ok.2652 = icmp eq i32 %descriptor.initialized.status.2651, 0
  br i1 %helper.ok.2652, label %helper.continue.2653, label %frame.failure.0
helper.continue.2653:
  br label %local.descriptor.checked.2634
local.descriptor.inactive.2633:
  br label %local.descriptor.checked.2634
local.descriptor.checked.2634:
  %local.is.active.2654 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2654, label %local.descriptor.active.2655, label %local.descriptor.inactive.2656
local.descriptor.active.2655:
  %local.check.offset.2658 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2659 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2660 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2661 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2662 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2663 = load i32, ptr %context.field.2662, align 4
  %stack.sub.2666 = sub i32 %local.check.owner.end.2661, %local.check.offset.2658
  %descriptor.owner.inside.2664 = icmp ule i32 %local.check.owner.end.2661, %context.value.2663
  %descriptor.offset.inside.2665 = icmp ule i32 %local.check.offset.2658, %local.check.owner.end.2661
  %descriptor.extent.inside.2667 = icmp ule i32 %local.check.extent.2659, %stack.sub.2666
  %descriptor.payload.inside.2668 = icmp ule i32 %local.check.payload.2660, %local.check.extent.2659
  %descriptor.owner.offset.valid.2669 = and i1 %descriptor.owner.inside.2664, %descriptor.offset.inside.2665
  %descriptor.range.inside.2671 = and i1 %descriptor.owner.offset.valid.2669, %descriptor.extent.inside.2667
  %descriptor.range.valid.2670 = and i1 %descriptor.range.inside.2671, %descriptor.payload.inside.2668
  br i1 %descriptor.range.valid.2670, label %descriptor.valid.2672, label %descriptor.invalid.2673
descriptor.invalid.2673:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2672:
  %descriptor.initialized.status.2674 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2658, i32 %local.check.extent.2659)
  %helper.ok.2675 = icmp eq i32 %descriptor.initialized.status.2674, 0
  br i1 %helper.ok.2675, label %helper.continue.2676, label %frame.failure.0
helper.continue.2676:
  br label %local.descriptor.checked.2657
local.descriptor.inactive.2656:
  br label %local.descriptor.checked.2657
local.descriptor.checked.2657:
  store i1 false, ptr %local.active.26, align 1
  store i32 0, ptr %local.offset.27, align 4
  store i32 0, ptr %local.extent.28, align 4
  store i32 0, ptr %local.payload.29, align 4
  store i32 0, ptr %local.owner.end.30, align 4
  store i32 0, ptr %local.type.31, align 4
  store i1 false, ptr %local.active.20, align 1
  store i32 0, ptr %local.offset.21, align 4
  store i32 0, ptr %local.extent.22, align 4
  store i32 0, ptr %local.payload.23, align 4
  store i32 0, ptr %local.owner.end.24, align 4
  store i32 0, ptr %local.type.25, align 4
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %descriptor.element.2677 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.2678 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.2677, i32 0, i32 0
  store i32 8, ptr %descriptor.field.2678, align 4
  %descriptor.field.2679 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.2677, i32 0, i32 1
  store i32 %local.resolved.offset.2343, ptr %descriptor.field.2679, align 4
  %descriptor.field.2680 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.2677, i32 0, i32 2
  store i32 %local.resolved.extent.2344, ptr %descriptor.field.2680, align 4
  %descriptor.field.2681 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.2677, i32 0, i32 3
  store i32 %local.resolved.payload.2345, ptr %descriptor.field.2681, align 4
  %descriptor.field.2682 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.2677, i32 0, i32 4
  store i32 %local.resolved.owner.end.2346, ptr %descriptor.field.2682, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %local.resolved.offset.2343, i32 20, i32 %local.resolved.payload.2345, i32 %local.resolved.owner.end.2346, i32 %local.resolved.extent.2344)
  %context.field.2683 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2684 = load i32, ptr %context.field.2683, align 4
  %runtime.ok.2685 = icmp eq i32 %context.value.2684, 0
  br i1 %runtime.ok.2685, label %runtime.continue.2686, label %frame.failure.0
runtime.continue.2686:
  %descriptor.element.2687 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 1
  %descriptor.field.2688 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.2687, i32 0, i32 0
  store i32 1, ptr %descriptor.field.2688, align 4
  %descriptor.field.2689 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.2687, i32 0, i32 1
  store i32 %local.resolved.offset.2503, ptr %descriptor.field.2689, align 4
  %descriptor.field.2690 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.2687, i32 0, i32 2
  store i32 %local.resolved.extent.2504, ptr %descriptor.field.2690, align 4
  %descriptor.field.2691 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.2687, i32 0, i32 3
  store i32 %local.resolved.payload.2505, ptr %descriptor.field.2691, align 4
  %descriptor.field.2692 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.2687, i32 0, i32 4
  store i32 %local.resolved.owner.end.2506, ptr %descriptor.field.2692, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %local.resolved.offset.2503, i32 20, i32 %local.resolved.payload.2505, i32 %local.resolved.owner.end.2506, i32 %local.resolved.extent.2504)
  %context.field.2693 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2694 = load i32, ptr %context.field.2693, align 4
  %runtime.ok.2695 = icmp eq i32 %context.value.2694, 0
  br i1 %runtime.ok.2695, label %runtime.continue.2696, label %frame.failure.0
runtime.continue.2696:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.33, i32 0, i32 0, i32 0)
  %context.field.2697 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.2698 = load i32, ptr %context.field.2697, align 4
  %context.field.2699 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.2700 = load i32, ptr %context.field.2699, align 4
  %context.field.2701 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.2702 = load i32, ptr %context.field.2701, align 4
  %stack.offset.2703 = add i32 %context.value.35, %context.value.37
  %stack.offset.2704 = add i32 %context.value.2698, %context.value.2700
  %stack.sub.2705 = sub i32 %stack.offset.2703, %stack.offset.2704
  %stack.sub.2706 = sub i32 %context.value.37, %context.value.2700
  %stack.sub.2707 = sub i32 %context.value.2702, %context.value.39
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.2705, i32 %stack.sub.2706)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.2707)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 3
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 3, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %entry.input.descriptors.10 = alloca [3 x %AlOwningDescriptor], align 4
  %input.extent.pointer.11 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.12 = load i32, ptr %input.extent.pointer.11, align 4
  %host.pointer.13 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.14 = alloca i32, align 4
  %input.measured.extent.pointer.15 = alloca i32, align 4
  %input.measure.status.16 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 2, ptr %host.pointer.13, i32 %input.host.extent.12, i32 0, i32 24, ptr %input.payload.pointer.14, ptr %input.measured.extent.pointer.15)
  %helper.ok.17 = icmp eq i32 %input.measure.status.16, 0
  br i1 %helper.ok.17, label %helper.continue.18, label %entry.failure.0
helper.continue.18:
  %input.measured.payload.19 = load i32, ptr %input.payload.pointer.14, align 4
  %input.measured.extent.20 = load i32, ptr %input.measured.extent.pointer.15, align 4
  %input.extent.exact.21 = icmp eq i32 %input.measured.extent.20, %input.host.extent.12
  br i1 %input.extent.exact.21, label %input.extent.exact.22, label %input.extent.invalid.23
input.extent.invalid.23:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 24, i32 %input.measured.extent.20, i32 %input.host.extent.12)
  br label %entry.failure.0
input.extent.exact.22:
  %stack.offset.24 = add i32 0, %input.host.extent.12
  %input.extent.pointer.25 = getelementptr inbounds i32, ptr %input.extents, i32 1
  %input.host.extent.26 = load i32, ptr %input.extent.pointer.25, align 4
  %host.pointer.27 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.24
  %input.payload.pointer.28 = alloca i32, align 4
  %input.measured.extent.pointer.29 = alloca i32, align 4
  %input.measure.status.30 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 2, ptr %host.pointer.27, i32 %input.host.extent.26, i32 0, i32 25, ptr %input.payload.pointer.28, ptr %input.measured.extent.pointer.29)
  %helper.ok.31 = icmp eq i32 %input.measure.status.30, 0
  br i1 %helper.ok.31, label %helper.continue.32, label %entry.failure.0
helper.continue.32:
  %input.measured.payload.33 = load i32, ptr %input.payload.pointer.28, align 4
  %input.measured.extent.34 = load i32, ptr %input.measured.extent.pointer.29, align 4
  %input.extent.exact.35 = icmp eq i32 %input.measured.extent.34, %input.host.extent.26
  br i1 %input.extent.exact.35, label %input.extent.exact.36, label %input.extent.invalid.37
input.extent.invalid.37:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 25, i32 %input.measured.extent.34, i32 %input.host.extent.26)
  br label %entry.failure.0
input.extent.exact.36:
  %stack.offset.38 = add i32 %stack.offset.24, %input.host.extent.26
  %input.extent.pointer.39 = getelementptr inbounds i32, ptr %input.extents, i32 2
  %input.host.extent.40 = load i32, ptr %input.extent.pointer.39, align 4
  %host.pointer.41 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.38
  %input.payload.pointer.42 = alloca i32, align 4
  %input.measured.extent.pointer.43 = alloca i32, align 4
  %input.measure.status.44 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 1, ptr %host.pointer.41, i32 %input.host.extent.40, i32 0, i32 26, ptr %input.payload.pointer.42, ptr %input.measured.extent.pointer.43)
  %helper.ok.45 = icmp eq i32 %input.measure.status.44, 0
  br i1 %helper.ok.45, label %helper.continue.46, label %entry.failure.0
helper.continue.46:
  %input.measured.payload.47 = load i32, ptr %input.payload.pointer.42, align 4
  %input.measured.extent.48 = load i32, ptr %input.measured.extent.pointer.43, align 4
  %input.extent.exact.49 = icmp eq i32 %input.measured.extent.48, %input.host.extent.40
  br i1 %input.extent.exact.49, label %input.extent.exact.50, label %input.extent.invalid.51
input.extent.invalid.51:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 26, i32 %input.measured.extent.48, i32 %input.host.extent.40)
  br label %entry.failure.0
input.extent.exact.50:
  %stack.offset.52 = add i32 %stack.offset.38, %input.host.extent.40
  %input.total.exact.53 = icmp eq i32 %stack.offset.52, %input.bytes
  br i1 %input.total.exact.53, label %input.valid.54, label %input.invalid.55
input.invalid.55:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.52, i32 %input.bytes)
  br label %entry.failure.0
input.valid.54:
  %reserve.status.56 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.52, i32 27)
  %reserve.ok.57 = icmp eq i32 %reserve.status.56, 0
  br i1 %reserve.ok.57, label %reserve.continue.58, label %entry.failure.0
reserve.continue.58:
  %host.pointer.59 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.60 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.59, i32 %input.host.extent.12, i32 0, i32 %input.measured.payload.19, i32 %input.host.extent.12, i32 8, i32 28)
  %helper.ok.61 = icmp eq i32 %input.copy.status.60, 0
  br i1 %helper.ok.61, label %helper.continue.62, label %entry.failure.0
helper.continue.62:
  %stack.offset.63 = add i32 0, %input.host.extent.12
  %descriptor.element.64 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.10, i32 0
  %descriptor.field.65 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.64, i32 0, i32 0
  store i32 8, ptr %descriptor.field.65, align 4
  %descriptor.field.66 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.64, i32 0, i32 1
  store i32 0, ptr %descriptor.field.66, align 4
  %descriptor.field.67 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.64, i32 0, i32 2
  store i32 %input.host.extent.12, ptr %descriptor.field.67, align 4
  %descriptor.field.68 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.64, i32 0, i32 3
  store i32 %input.measured.payload.19, ptr %descriptor.field.68, align 4
  %descriptor.field.69 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.64, i32 0, i32 4
  store i32 %stack.offset.63, ptr %descriptor.field.69, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 0, i32 20, i32 %input.measured.payload.19, i32 %stack.offset.63, i32 %input.host.extent.12)
  %context.field.70 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.71 = load i32, ptr %context.field.70, align 4
  %runtime.ok.72 = icmp eq i32 %context.value.71, 0
  br i1 %runtime.ok.72, label %runtime.continue.73, label %entry.failure.0
runtime.continue.73:
  %host.pointer.74 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.24
  %input.copy.status.75 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.24, ptr %host.pointer.74, i32 %input.host.extent.26, i32 0, i32 %input.measured.payload.33, i32 %input.host.extent.26, i32 8, i32 29)
  %helper.ok.76 = icmp eq i32 %input.copy.status.75, 0
  br i1 %helper.ok.76, label %helper.continue.77, label %entry.failure.0
helper.continue.77:
  %stack.offset.78 = add i32 %stack.offset.24, %input.host.extent.26
  %descriptor.element.79 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.10, i32 1
  %descriptor.field.80 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 0
  store i32 8, ptr %descriptor.field.80, align 4
  %descriptor.field.81 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 1
  store i32 %stack.offset.24, ptr %descriptor.field.81, align 4
  %descriptor.field.82 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 2
  store i32 %input.host.extent.26, ptr %descriptor.field.82, align 4
  %descriptor.field.83 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 3
  store i32 %input.measured.payload.33, ptr %descriptor.field.83, align 4
  %descriptor.field.84 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 4
  store i32 %stack.offset.78, ptr %descriptor.field.84, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %stack.offset.24, i32 20, i32 %input.measured.payload.33, i32 %stack.offset.78, i32 %input.host.extent.26)
  %context.field.85 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.86 = load i32, ptr %context.field.85, align 4
  %runtime.ok.87 = icmp eq i32 %context.value.86, 0
  br i1 %runtime.ok.87, label %runtime.continue.88, label %entry.failure.0
runtime.continue.88:
  %host.pointer.89 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.38
  %input.copy.status.90 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.38, ptr %host.pointer.89, i32 %input.host.extent.40, i32 0, i32 %input.measured.payload.47, i32 %input.host.extent.40, i32 2, i32 30)
  %helper.ok.91 = icmp eq i32 %input.copy.status.90, 0
  br i1 %helper.ok.91, label %helper.continue.92, label %entry.failure.0
helper.continue.92:
  %stack.offset.93 = add i32 %stack.offset.38, %input.host.extent.40
  %descriptor.element.94 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.10, i32 2
  %descriptor.field.95 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.94, i32 0, i32 0
  store i32 2, ptr %descriptor.field.95, align 4
  %descriptor.field.96 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.94, i32 0, i32 1
  store i32 %stack.offset.38, ptr %descriptor.field.96, align 4
  %descriptor.field.97 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.94, i32 0, i32 2
  store i32 %input.host.extent.40, ptr %descriptor.field.97, align 4
  %descriptor.field.98 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.94, i32 0, i32 3
  store i32 %input.measured.payload.47, ptr %descriptor.field.98, align 4
  %descriptor.field.99 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.94, i32 0, i32 4
  store i32 %stack.offset.93, ptr %descriptor.field.99, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 2, i32 %stack.offset.38, i32 20, i32 %input.measured.payload.47, i32 %stack.offset.93, i32 %input.host.extent.40)
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %runtime.ok.102 = icmp eq i32 %context.value.101, 0
  br i1 %runtime.ok.102, label %runtime.continue.103, label %entry.failure.0
runtime.continue.103:
  %entry.output.descriptors.104 = alloca [2 x %AlOwningDescriptor], align 4
  %entry.body.status.105 = call i32 @agentlang_entry_frame(ptr %ctx, ptr %entry.input.descriptors.10, ptr %entry.output.descriptors.104, i32 31)
  %entry.body.ok.106 = icmp eq i32 %entry.body.status.105, 0
  br i1 %entry.body.ok.106, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.107 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.104, i32 0
  %descriptor.field.108 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.107, i32 0, i32 0
  %descriptor.value.109 = load i32, ptr %descriptor.field.108, align 4
  %descriptor.field.110 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.107, i32 0, i32 1
  %descriptor.value.111 = load i32, ptr %descriptor.field.110, align 4
  %descriptor.field.112 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.107, i32 0, i32 2
  %descriptor.value.113 = load i32, ptr %descriptor.field.112, align 4
  %descriptor.field.114 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.107, i32 0, i32 3
  %descriptor.value.115 = load i32, ptr %descriptor.field.114, align 4
  %descriptor.field.116 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.107, i32 0, i32 4
  %descriptor.value.117 = load i32, ptr %descriptor.field.116, align 4
  %entry.output.type.valid.118 = icmp eq i32 %descriptor.value.109, 8
  br i1 %entry.output.type.valid.118, label %entry.output.type.ok.119, label %entry.output.type.invalid.120
entry.output.type.invalid.120:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.119:
  %context.field.121 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.122 = load i32, ptr %context.field.121, align 4
  %stack.sub.125 = sub i32 %descriptor.value.117, %descriptor.value.111
  %descriptor.owner.inside.123 = icmp ule i32 %descriptor.value.117, %context.value.122
  %descriptor.offset.inside.124 = icmp ule i32 %descriptor.value.111, %descriptor.value.117
  %descriptor.extent.inside.126 = icmp ule i32 %descriptor.value.113, %stack.sub.125
  %descriptor.payload.inside.127 = icmp ule i32 %descriptor.value.115, %descriptor.value.113
  %descriptor.owner.offset.valid.128 = and i1 %descriptor.owner.inside.123, %descriptor.offset.inside.124
  %descriptor.range.inside.130 = and i1 %descriptor.owner.offset.valid.128, %descriptor.extent.inside.126
  %descriptor.range.valid.129 = and i1 %descriptor.range.inside.130, %descriptor.payload.inside.127
  %descriptor.type.valid.131 = icmp eq i32 8, 8
  %descriptor.valid.132 = and i1 %descriptor.range.valid.129, %descriptor.type.valid.131
  br i1 %descriptor.valid.132, label %descriptor.valid.133, label %descriptor.invalid.134
descriptor.invalid.134:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.133:
  %descriptor.initialized.status.135 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.111, i32 %descriptor.value.113)
  %helper.ok.136 = icmp eq i32 %descriptor.initialized.status.135, 0
  br i1 %helper.ok.136, label %helper.continue.137, label %entry.failure.0
helper.continue.137:
  %entry.output.size.i64.138 = zext i32 %descriptor.value.113 to i64
  %entry.output.total.i64.139 = add i64 0, %entry.output.size.i64.138
  %descriptor.element.140 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.104, i32 1
  %descriptor.field.141 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.140, i32 0, i32 0
  %descriptor.value.142 = load i32, ptr %descriptor.field.141, align 4
  %descriptor.field.143 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.140, i32 0, i32 1
  %descriptor.value.144 = load i32, ptr %descriptor.field.143, align 4
  %descriptor.field.145 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.140, i32 0, i32 2
  %descriptor.value.146 = load i32, ptr %descriptor.field.145, align 4
  %descriptor.field.147 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.140, i32 0, i32 3
  %descriptor.value.148 = load i32, ptr %descriptor.field.147, align 4
  %descriptor.field.149 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.140, i32 0, i32 4
  %descriptor.value.150 = load i32, ptr %descriptor.field.149, align 4
  %entry.output.type.valid.151 = icmp eq i32 %descriptor.value.142, 1
  br i1 %entry.output.type.valid.151, label %entry.output.type.ok.152, label %entry.output.type.invalid.153
entry.output.type.invalid.153:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.152:
  %context.field.154 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.155 = load i32, ptr %context.field.154, align 4
  %stack.sub.158 = sub i32 %descriptor.value.150, %descriptor.value.144
  %descriptor.owner.inside.156 = icmp ule i32 %descriptor.value.150, %context.value.155
  %descriptor.offset.inside.157 = icmp ule i32 %descriptor.value.144, %descriptor.value.150
  %descriptor.extent.inside.159 = icmp ule i32 %descriptor.value.146, %stack.sub.158
  %descriptor.payload.inside.160 = icmp ule i32 %descriptor.value.148, %descriptor.value.146
  %descriptor.owner.offset.valid.161 = and i1 %descriptor.owner.inside.156, %descriptor.offset.inside.157
  %descriptor.range.inside.163 = and i1 %descriptor.owner.offset.valid.161, %descriptor.extent.inside.159
  %descriptor.range.valid.162 = and i1 %descriptor.range.inside.163, %descriptor.payload.inside.160
  %descriptor.type.valid.164 = icmp eq i32 1, 1
  %descriptor.valid.165 = and i1 %descriptor.range.valid.162, %descriptor.type.valid.164
  br i1 %descriptor.valid.165, label %descriptor.valid.166, label %descriptor.invalid.167
descriptor.invalid.167:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.166:
  %descriptor.initialized.status.168 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.144, i32 %descriptor.value.146)
  %helper.ok.169 = icmp eq i32 %descriptor.initialized.status.168, 0
  br i1 %helper.ok.169, label %helper.continue.170, label %entry.failure.0
helper.continue.170:
  %entry.output.size.i64.171 = zext i32 %descriptor.value.146 to i64
  %entry.output.total.i64.172 = add i64 %entry.output.total.i64.139, %entry.output.size.i64.171
  %entry.retained.capacity.i64.173 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.174 = icmp ule i64 %entry.output.total.i64.172, 4294967295
  %entry.retained.required.truncated.175 = trunc i64 %entry.output.total.i64.172 to i32
  %entry.retained.required.176 = select i1 %entry.retained.required.fits.u32.174, i32 %entry.retained.required.truncated.175, i32 4294967295
  %entry.retained.capacity.ok.177 = icmp ule i64 %entry.output.total.i64.172, %entry.retained.capacity.i64.173
  br i1 %entry.retained.capacity.ok.177, label %entry.retained.capacity.ready.178, label %entry.retained.capacity.failure.179
entry.retained.capacity.failure.179:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.176, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.178:
  %host.pointer.180 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.181 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.180, i32 %stack.sub.181, i32 %descriptor.value.111, i32 %descriptor.value.113, i32 8)
  %context.field.182 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.183 = load i32, ptr %context.field.182, align 4
  %runtime.ok.184 = icmp eq i32 %context.value.183, 0
  br i1 %runtime.ok.184, label %runtime.continue.185, label %entry.failure.0
runtime.continue.185:
  %stack.offset.186 = add i32 0, %descriptor.value.113
  %host.pointer.187 = getelementptr inbounds i8, ptr %retained, i32 %stack.offset.186
  %stack.sub.188 = sub i32 %retained.capacity, %stack.offset.186
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.187, i32 %stack.sub.188, i32 %descriptor.value.144, i32 %descriptor.value.146, i32 1)
  %context.field.189 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.190 = load i32, ptr %context.field.189, align 4
  %runtime.ok.191 = icmp eq i32 %context.value.190, 0
  br i1 %runtime.ok.191, label %runtime.continue.192, label %entry.failure.0
runtime.continue.192:
  %stack.offset.193 = add i32 %stack.offset.186, %descriptor.value.146
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.194 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.195 = load i32, ptr %context.field.194, align 4
  %context.field.196 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.197 = load i32, ptr %context.field.196, align 4
  %stack.sub.198 = sub i32 0, %context.value.195
  %stack.sub.199 = sub i32 0, %context.value.197
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.198, i32 %stack.sub.199)
  %context.field.200 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.201 = load i32, ptr %context.field.200, align 4
  %runtime.ok.202 = icmp eq i32 %context.value.201, 0
  br i1 %runtime.ok.202, label %runtime.continue.203, label %entry.failure.0
runtime.continue.203:
  br label %entry.return.status
entry.failure.0:
  %context.field.204 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.205 = load i32, ptr %context.field.204, align 4
  %context.field.206 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.207 = load i32, ptr %context.field.206, align 4
  %context.field.208 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.209 = load i32, ptr %context.field.208, align 4
  %stack.offset.210 = add i32 %context.value.205, %context.value.207
  %stack.sub.211 = sub i32 0, %stack.offset.210
  %stack.sub.212 = sub i32 0, %context.value.207
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.211, i32 %stack.sub.212)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.209)
  br label %entry.return.status
entry.return.status:
  %context.field.213 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.214 = load i32, ptr %context.field.213, align 4
  ret i32 %context.value.214
}


%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [4 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8 }, %AlOwningTypeDescriptor { i32 4, i32 5, i32 0, i32 2, i32 16, i32 16, i32 16, i32 16 }, %AlOwningTypeDescriptor { i32 4, i32 6, i32 2, i32 1, i32 8, i32 8, i32 8, i32 8 }, %AlOwningTypeDescriptor { i32 4, i32 7, i32 3, i32 2, i32 24, i32 24, i32 24, i32 24 }], align 4
@al_owning_fields = private constant [5 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 2, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 1, i32 8, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 1, ptr @al_owning_types, i32 4, ptr @al_owning_fields, i32 5 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %step.status.13 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.14 = icmp eq i32 %step.status.13, 0
  br i1 %helper.ok.14, label %helper.continue.15, label %frame.failure.0
helper.continue.15:
  %call.results.16 = alloca [1 x %AlOwningDescriptor], align 4
  %callee.status.17 = call i32 @agentlang_word_0000(ptr %ctx, ptr null, ptr %call.results.16, i32 2)
  %helper.ok.18 = icmp eq i32 %callee.status.17, 0
  br i1 %helper.ok.18, label %helper.continue.19, label %frame.failure.0
helper.continue.19:
  %descriptor.element.20 = getelementptr inbounds %AlOwningDescriptor, ptr %call.results.16, i32 0
  %descriptor.field.21 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.20, i32 0, i32 0
  %descriptor.value.22 = load i32, ptr %descriptor.field.21, align 4
  %descriptor.field.23 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.20, i32 0, i32 1
  %descriptor.value.24 = load i32, ptr %descriptor.field.23, align 4
  %descriptor.field.25 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.20, i32 0, i32 2
  %descriptor.value.26 = load i32, ptr %descriptor.field.25, align 4
  %descriptor.field.27 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.20, i32 0, i32 3
  %descriptor.value.28 = load i32, ptr %descriptor.field.27, align 4
  %descriptor.field.29 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.20, i32 0, i32 4
  %descriptor.value.30 = load i32, ptr %descriptor.field.29, align 4
  %callee.result.type.valid.31 = icmp eq i32 %descriptor.value.22, 7
  br i1 %callee.result.type.valid.31, label %callee.result.type.ok.32, label %frame.failure.0
callee.result.type.ok.32:
  %context.field.33 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.34 = load i32, ptr %context.field.33, align 4
  %stack.sub.37 = sub i32 %descriptor.value.30, %descriptor.value.24
  %descriptor.owner.inside.35 = icmp ule i32 %descriptor.value.30, %context.value.34
  %descriptor.offset.inside.36 = icmp ule i32 %descriptor.value.24, %descriptor.value.30
  %descriptor.extent.inside.38 = icmp ule i32 %descriptor.value.26, %stack.sub.37
  %descriptor.payload.inside.39 = icmp ule i32 %descriptor.value.28, %descriptor.value.26
  %descriptor.owner.offset.valid.40 = and i1 %descriptor.owner.inside.35, %descriptor.offset.inside.36
  %descriptor.range.inside.42 = and i1 %descriptor.owner.offset.valid.40, %descriptor.extent.inside.38
  %descriptor.range.valid.41 = and i1 %descriptor.range.inside.42, %descriptor.payload.inside.39
  %descriptor.type.valid.43 = icmp eq i32 7, 7
  %descriptor.valid.44 = and i1 %descriptor.range.valid.41, %descriptor.type.valid.43
  br i1 %descriptor.valid.44, label %descriptor.valid.45, label %descriptor.invalid.46
descriptor.invalid.46:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.45:
  %descriptor.initialized.status.47 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.24, i32 %descriptor.value.26)
  %helper.ok.48 = icmp eq i32 %descriptor.initialized.status.47, 0
  br i1 %helper.ok.48, label %helper.continue.49, label %frame.failure.0
helper.continue.49:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 7, i32 %descriptor.value.24, i32 20, i32 %descriptor.value.28, i32 %descriptor.value.30, i32 %descriptor.value.26)
  %context.field.50 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.51 = load i32, ptr %context.field.50, align 4
  %runtime.ok.52 = icmp eq i32 %context.value.51, 0
  br i1 %runtime.ok.52, label %runtime.continue.53, label %frame.failure.0
runtime.continue.53:
  %context.field.54 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.55 = load i32, ptr %context.field.54, align 4
  %stack.sub.58 = sub i32 %descriptor.value.30, %descriptor.value.24
  %descriptor.owner.inside.56 = icmp ule i32 %descriptor.value.30, %context.value.55
  %descriptor.offset.inside.57 = icmp ule i32 %descriptor.value.24, %descriptor.value.30
  %descriptor.extent.inside.59 = icmp ule i32 %descriptor.value.26, %stack.sub.58
  %descriptor.payload.inside.60 = icmp ule i32 %descriptor.value.28, %descriptor.value.26
  %descriptor.owner.offset.valid.61 = and i1 %descriptor.owner.inside.56, %descriptor.offset.inside.57
  %descriptor.range.inside.63 = and i1 %descriptor.owner.offset.valid.61, %descriptor.extent.inside.59
  %descriptor.range.valid.62 = and i1 %descriptor.range.inside.63, %descriptor.payload.inside.60
  %descriptor.type.valid.64 = icmp eq i32 7, 7
  %descriptor.valid.65 = and i1 %descriptor.range.valid.62, %descriptor.type.valid.64
  br i1 %descriptor.valid.65, label %descriptor.valid.66, label %descriptor.invalid.67
descriptor.invalid.67:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.66:
  %descriptor.initialized.status.68 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.24, i32 %descriptor.value.26)
  %helper.ok.69 = icmp eq i32 %descriptor.initialized.status.68, 0
  br i1 %helper.ok.69, label %helper.continue.70, label %frame.failure.0
helper.continue.70:
  %descriptor.element.71 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.72 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.71, i32 0, i32 0
  store i32 7, ptr %descriptor.field.72, align 4
  %descriptor.field.73 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.71, i32 0, i32 1
  store i32 %descriptor.value.24, ptr %descriptor.field.73, align 4
  %descriptor.field.74 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.71, i32 0, i32 2
  store i32 %descriptor.value.26, ptr %descriptor.field.74, align 4
  %descriptor.field.75 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.71, i32 0, i32 3
  store i32 %descriptor.value.28, ptr %descriptor.field.75, align 4
  %descriptor.field.76 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.71, i32 0, i32 4
  store i32 %descriptor.value.30, ptr %descriptor.field.76, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 7, i32 %descriptor.value.24, i32 20, i32 %descriptor.value.28, i32 %descriptor.value.30, i32 %descriptor.value.26)
  %context.field.77 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.78 = load i32, ptr %context.field.77, align 4
  %runtime.ok.79 = icmp eq i32 %context.value.78, 0
  br i1 %runtime.ok.79, label %runtime.continue.80, label %frame.failure.0
runtime.continue.80:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.81 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.82 = load i32, ptr %context.field.81, align 4
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %context.field.85 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.86 = load i32, ptr %context.field.85, align 4
  %stack.offset.87 = add i32 %context.value.5, %context.value.7
  %stack.offset.88 = add i32 %context.value.82, %context.value.84
  %stack.sub.89 = sub i32 %stack.offset.87, %stack.offset.88
  %stack.sub.90 = sub i32 %context.value.7, %context.value.84
  %stack.sub.91 = sub i32 %context.value.86, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.89, i32 %stack.sub.90)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.91)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %local.active.2 = alloca i1, align 1
  %local.offset.3 = alloca i32, align 4
  %local.extent.4 = alloca i32, align 4
  %local.payload.5 = alloca i32, align 4
  %local.owner.end.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %local.active.8 = alloca i1, align 1
  %local.offset.9 = alloca i32, align 4
  %local.extent.10 = alloca i32, align 4
  %local.payload.11 = alloca i32, align 4
  %local.owner.end.12 = alloca i32, align 4
  %local.type.13 = alloca i32, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  %local.active.14 = alloca i1, align 1
  %local.offset.15 = alloca i32, align 4
  %local.extent.16 = alloca i32, align 4
  %local.payload.17 = alloca i32, align 4
  %local.owner.end.18 = alloca i32, align 4
  %local.type.19 = alloca i32, align 4
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  %context.field.20 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.21 = load i32, ptr %context.field.20, align 4
  %context.field.22 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.23 = load i32, ptr %context.field.22, align 4
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %frame.entered.28 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.29 = icmp eq i32 %frame.entered.28, 0
  br i1 %frame.enter.ok.29, label %frame.enter.continue.30, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.30:
  %step.status.31 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.32 = icmp eq i32 %step.status.31, 0
  br i1 %helper.ok.32, label %helper.continue.33, label %frame.failure.0
helper.continue.33:
  %context.field.34 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.35 = load i32, ptr %context.field.34, align 4
  %stack.offset.36 = add i32 %context.value.35, 8
  %reserve.status.37 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.36, i32 4)
  %reserve.ok.38 = icmp eq i32 %reserve.status.37, 0
  br i1 %reserve.ok.38, label %reserve.continue.39, label %frame.failure.0
reserve.continue.39:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.35, i64 5, i32 1)
  %context.field.40 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.41 = load i32, ptr %context.field.40, align 4
  %runtime.ok.42 = icmp eq i32 %context.value.41, 0
  br i1 %runtime.ok.42, label %runtime.continue.43, label %frame.failure.0
runtime.continue.43:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.44 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.45 = load i32, ptr %context.field.44, align 4
  %runtime.ok.46 = icmp eq i32 %context.value.45, 0
  br i1 %runtime.ok.46, label %runtime.continue.47, label %frame.failure.0
runtime.continue.47:
  %context.field.48 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.49 = load i32, ptr %context.field.48, align 4
  %stack.sub.52 = sub i32 %stack.offset.36, %context.value.35
  %descriptor.owner.inside.50 = icmp ule i32 %stack.offset.36, %context.value.49
  %descriptor.offset.inside.51 = icmp ule i32 %context.value.35, %stack.offset.36
  %descriptor.extent.inside.53 = icmp ule i32 8, %stack.sub.52
  %descriptor.payload.inside.54 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.55 = and i1 %descriptor.owner.inside.50, %descriptor.offset.inside.51
  %descriptor.range.inside.57 = and i1 %descriptor.owner.offset.valid.55, %descriptor.extent.inside.53
  %descriptor.range.valid.56 = and i1 %descriptor.range.inside.57, %descriptor.payload.inside.54
  %descriptor.type.valid.58 = icmp eq i32 1, 1
  %descriptor.valid.59 = and i1 %descriptor.range.valid.56, %descriptor.type.valid.58
  br i1 %descriptor.valid.59, label %descriptor.valid.60, label %descriptor.invalid.61
descriptor.invalid.61:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.60:
  %descriptor.initialized.status.62 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.35, i32 8)
  %helper.ok.63 = icmp eq i32 %descriptor.initialized.status.62, 0
  br i1 %helper.ok.63, label %helper.continue.64, label %frame.failure.0
helper.continue.64:
  %local.is.active.65 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.65, label %local.descriptor.active.66, label %local.descriptor.inactive.67
local.descriptor.active.66:
  %local.check.offset.69 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.70 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.71 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.72 = load i32, ptr %local.owner.end.6, align 4
  %context.field.73 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.74 = load i32, ptr %context.field.73, align 4
  %stack.sub.77 = sub i32 %local.check.owner.end.72, %local.check.offset.69
  %descriptor.owner.inside.75 = icmp ule i32 %local.check.owner.end.72, %context.value.74
  %descriptor.offset.inside.76 = icmp ule i32 %local.check.offset.69, %local.check.owner.end.72
  %descriptor.extent.inside.78 = icmp ule i32 %local.check.extent.70, %stack.sub.77
  %descriptor.payload.inside.79 = icmp ule i32 %local.check.payload.71, %local.check.extent.70
  %descriptor.owner.offset.valid.80 = and i1 %descriptor.owner.inside.75, %descriptor.offset.inside.76
  %descriptor.range.inside.82 = and i1 %descriptor.owner.offset.valid.80, %descriptor.extent.inside.78
  %descriptor.range.valid.81 = and i1 %descriptor.range.inside.82, %descriptor.payload.inside.79
  br i1 %descriptor.range.valid.81, label %descriptor.valid.83, label %descriptor.invalid.84
descriptor.invalid.84:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.83:
  %descriptor.initialized.status.85 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.69, i32 %local.check.extent.70)
  %helper.ok.86 = icmp eq i32 %descriptor.initialized.status.85, 0
  br i1 %helper.ok.86, label %helper.continue.87, label %frame.failure.0
helper.continue.87:
  br label %local.descriptor.checked.68
local.descriptor.inactive.67:
  br label %local.descriptor.checked.68
local.descriptor.checked.68:
  %local.is.active.88 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.88, label %local.descriptor.active.89, label %local.descriptor.inactive.90
local.descriptor.active.89:
  %local.check.offset.92 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.93 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.94 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.95 = load i32, ptr %local.owner.end.12, align 4
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %stack.sub.100 = sub i32 %local.check.owner.end.95, %local.check.offset.92
  %descriptor.owner.inside.98 = icmp ule i32 %local.check.owner.end.95, %context.value.97
  %descriptor.offset.inside.99 = icmp ule i32 %local.check.offset.92, %local.check.owner.end.95
  %descriptor.extent.inside.101 = icmp ule i32 %local.check.extent.93, %stack.sub.100
  %descriptor.payload.inside.102 = icmp ule i32 %local.check.payload.94, %local.check.extent.93
  %descriptor.owner.offset.valid.103 = and i1 %descriptor.owner.inside.98, %descriptor.offset.inside.99
  %descriptor.range.inside.105 = and i1 %descriptor.owner.offset.valid.103, %descriptor.extent.inside.101
  %descriptor.range.valid.104 = and i1 %descriptor.range.inside.105, %descriptor.payload.inside.102
  br i1 %descriptor.range.valid.104, label %descriptor.valid.106, label %descriptor.invalid.107
descriptor.invalid.107:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.106:
  %descriptor.initialized.status.108 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.92, i32 %local.check.extent.93)
  %helper.ok.109 = icmp eq i32 %descriptor.initialized.status.108, 0
  br i1 %helper.ok.109, label %helper.continue.110, label %frame.failure.0
helper.continue.110:
  br label %local.descriptor.checked.91
local.descriptor.inactive.90:
  br label %local.descriptor.checked.91
local.descriptor.checked.91:
  %local.is.active.111 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.111, label %local.descriptor.active.112, label %local.descriptor.inactive.113
local.descriptor.active.112:
  %local.check.offset.115 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.116 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.117 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.118 = load i32, ptr %local.owner.end.18, align 4
  %context.field.119 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.120 = load i32, ptr %context.field.119, align 4
  %stack.sub.123 = sub i32 %local.check.owner.end.118, %local.check.offset.115
  %descriptor.owner.inside.121 = icmp ule i32 %local.check.owner.end.118, %context.value.120
  %descriptor.offset.inside.122 = icmp ule i32 %local.check.offset.115, %local.check.owner.end.118
  %descriptor.extent.inside.124 = icmp ule i32 %local.check.extent.116, %stack.sub.123
  %descriptor.payload.inside.125 = icmp ule i32 %local.check.payload.117, %local.check.extent.116
  %descriptor.owner.offset.valid.126 = and i1 %descriptor.owner.inside.121, %descriptor.offset.inside.122
  %descriptor.range.inside.128 = and i1 %descriptor.owner.offset.valid.126, %descriptor.extent.inside.124
  %descriptor.range.valid.127 = and i1 %descriptor.range.inside.128, %descriptor.payload.inside.125
  br i1 %descriptor.range.valid.127, label %descriptor.valid.129, label %descriptor.invalid.130
descriptor.invalid.130:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.129:
  %descriptor.initialized.status.131 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.115, i32 %local.check.extent.116)
  %helper.ok.132 = icmp eq i32 %descriptor.initialized.status.131, 0
  br i1 %helper.ok.132, label %helper.continue.133, label %frame.failure.0
helper.continue.133:
  br label %local.descriptor.checked.114
local.descriptor.inactive.113:
  br label %local.descriptor.checked.114
local.descriptor.checked.114:
  %step.status.134 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.135 = icmp eq i32 %step.status.134, 0
  br i1 %helper.ok.135, label %helper.continue.136, label %frame.failure.0
helper.continue.136:
  %context.field.137 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.138 = load i32, ptr %context.field.137, align 4
  %stack.offset.139 = add i32 %context.value.138, 8
  %reserve.status.140 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.139, i32 6)
  %reserve.ok.141 = icmp eq i32 %reserve.status.140, 0
  br i1 %reserve.ok.141, label %reserve.continue.142, label %frame.failure.0
reserve.continue.142:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.138, i64 70, i32 1)
  %context.field.143 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.144 = load i32, ptr %context.field.143, align 4
  %runtime.ok.145 = icmp eq i32 %context.value.144, 0
  br i1 %runtime.ok.145, label %runtime.continue.146, label %frame.failure.0
runtime.continue.146:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.147 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.148 = load i32, ptr %context.field.147, align 4
  %runtime.ok.149 = icmp eq i32 %context.value.148, 0
  br i1 %runtime.ok.149, label %runtime.continue.150, label %frame.failure.0
runtime.continue.150:
  %context.field.151 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.152 = load i32, ptr %context.field.151, align 4
  %stack.sub.155 = sub i32 %stack.offset.36, %context.value.35
  %descriptor.owner.inside.153 = icmp ule i32 %stack.offset.36, %context.value.152
  %descriptor.offset.inside.154 = icmp ule i32 %context.value.35, %stack.offset.36
  %descriptor.extent.inside.156 = icmp ule i32 8, %stack.sub.155
  %descriptor.payload.inside.157 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.158 = and i1 %descriptor.owner.inside.153, %descriptor.offset.inside.154
  %descriptor.range.inside.160 = and i1 %descriptor.owner.offset.valid.158, %descriptor.extent.inside.156
  %descriptor.range.valid.159 = and i1 %descriptor.range.inside.160, %descriptor.payload.inside.157
  %descriptor.type.valid.161 = icmp eq i32 1, 1
  %descriptor.valid.162 = and i1 %descriptor.range.valid.159, %descriptor.type.valid.161
  br i1 %descriptor.valid.162, label %descriptor.valid.163, label %descriptor.invalid.164
descriptor.invalid.164:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.163:
  %descriptor.initialized.status.165 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.35, i32 8)
  %helper.ok.166 = icmp eq i32 %descriptor.initialized.status.165, 0
  br i1 %helper.ok.166, label %helper.continue.167, label %frame.failure.0
helper.continue.167:
  %context.field.168 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.169 = load i32, ptr %context.field.168, align 4
  %stack.sub.172 = sub i32 %stack.offset.139, %context.value.138
  %descriptor.owner.inside.170 = icmp ule i32 %stack.offset.139, %context.value.169
  %descriptor.offset.inside.171 = icmp ule i32 %context.value.138, %stack.offset.139
  %descriptor.extent.inside.173 = icmp ule i32 8, %stack.sub.172
  %descriptor.payload.inside.174 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.175 = and i1 %descriptor.owner.inside.170, %descriptor.offset.inside.171
  %descriptor.range.inside.177 = and i1 %descriptor.owner.offset.valid.175, %descriptor.extent.inside.173
  %descriptor.range.valid.176 = and i1 %descriptor.range.inside.177, %descriptor.payload.inside.174
  %descriptor.type.valid.178 = icmp eq i32 1, 1
  %descriptor.valid.179 = and i1 %descriptor.range.valid.176, %descriptor.type.valid.178
  br i1 %descriptor.valid.179, label %descriptor.valid.180, label %descriptor.invalid.181
descriptor.invalid.181:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.180:
  %descriptor.initialized.status.182 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.138, i32 8)
  %helper.ok.183 = icmp eq i32 %descriptor.initialized.status.182, 0
  br i1 %helper.ok.183, label %helper.continue.184, label %frame.failure.0
helper.continue.184:
  %local.is.active.185 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.185, label %local.descriptor.active.186, label %local.descriptor.inactive.187
local.descriptor.active.186:
  %local.check.offset.189 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.190 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.191 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.192 = load i32, ptr %local.owner.end.6, align 4
  %context.field.193 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.194 = load i32, ptr %context.field.193, align 4
  %stack.sub.197 = sub i32 %local.check.owner.end.192, %local.check.offset.189
  %descriptor.owner.inside.195 = icmp ule i32 %local.check.owner.end.192, %context.value.194
  %descriptor.offset.inside.196 = icmp ule i32 %local.check.offset.189, %local.check.owner.end.192
  %descriptor.extent.inside.198 = icmp ule i32 %local.check.extent.190, %stack.sub.197
  %descriptor.payload.inside.199 = icmp ule i32 %local.check.payload.191, %local.check.extent.190
  %descriptor.owner.offset.valid.200 = and i1 %descriptor.owner.inside.195, %descriptor.offset.inside.196
  %descriptor.range.inside.202 = and i1 %descriptor.owner.offset.valid.200, %descriptor.extent.inside.198
  %descriptor.range.valid.201 = and i1 %descriptor.range.inside.202, %descriptor.payload.inside.199
  br i1 %descriptor.range.valid.201, label %descriptor.valid.203, label %descriptor.invalid.204
descriptor.invalid.204:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.203:
  %descriptor.initialized.status.205 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.189, i32 %local.check.extent.190)
  %helper.ok.206 = icmp eq i32 %descriptor.initialized.status.205, 0
  br i1 %helper.ok.206, label %helper.continue.207, label %frame.failure.0
helper.continue.207:
  br label %local.descriptor.checked.188
local.descriptor.inactive.187:
  br label %local.descriptor.checked.188
local.descriptor.checked.188:
  %local.is.active.208 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.208, label %local.descriptor.active.209, label %local.descriptor.inactive.210
local.descriptor.active.209:
  %local.check.offset.212 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.213 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.214 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.215 = load i32, ptr %local.owner.end.12, align 4
  %context.field.216 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.217 = load i32, ptr %context.field.216, align 4
  %stack.sub.220 = sub i32 %local.check.owner.end.215, %local.check.offset.212
  %descriptor.owner.inside.218 = icmp ule i32 %local.check.owner.end.215, %context.value.217
  %descriptor.offset.inside.219 = icmp ule i32 %local.check.offset.212, %local.check.owner.end.215
  %descriptor.extent.inside.221 = icmp ule i32 %local.check.extent.213, %stack.sub.220
  %descriptor.payload.inside.222 = icmp ule i32 %local.check.payload.214, %local.check.extent.213
  %descriptor.owner.offset.valid.223 = and i1 %descriptor.owner.inside.218, %descriptor.offset.inside.219
  %descriptor.range.inside.225 = and i1 %descriptor.owner.offset.valid.223, %descriptor.extent.inside.221
  %descriptor.range.valid.224 = and i1 %descriptor.range.inside.225, %descriptor.payload.inside.222
  br i1 %descriptor.range.valid.224, label %descriptor.valid.226, label %descriptor.invalid.227
descriptor.invalid.227:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.226:
  %descriptor.initialized.status.228 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.212, i32 %local.check.extent.213)
  %helper.ok.229 = icmp eq i32 %descriptor.initialized.status.228, 0
  br i1 %helper.ok.229, label %helper.continue.230, label %frame.failure.0
helper.continue.230:
  br label %local.descriptor.checked.211
local.descriptor.inactive.210:
  br label %local.descriptor.checked.211
local.descriptor.checked.211:
  %local.is.active.231 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.231, label %local.descriptor.active.232, label %local.descriptor.inactive.233
local.descriptor.active.232:
  %local.check.offset.235 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.236 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.237 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.238 = load i32, ptr %local.owner.end.18, align 4
  %context.field.239 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.240 = load i32, ptr %context.field.239, align 4
  %stack.sub.243 = sub i32 %local.check.owner.end.238, %local.check.offset.235
  %descriptor.owner.inside.241 = icmp ule i32 %local.check.owner.end.238, %context.value.240
  %descriptor.offset.inside.242 = icmp ule i32 %local.check.offset.235, %local.check.owner.end.238
  %descriptor.extent.inside.244 = icmp ule i32 %local.check.extent.236, %stack.sub.243
  %descriptor.payload.inside.245 = icmp ule i32 %local.check.payload.237, %local.check.extent.236
  %descriptor.owner.offset.valid.246 = and i1 %descriptor.owner.inside.241, %descriptor.offset.inside.242
  %descriptor.range.inside.248 = and i1 %descriptor.owner.offset.valid.246, %descriptor.extent.inside.244
  %descriptor.range.valid.247 = and i1 %descriptor.range.inside.248, %descriptor.payload.inside.245
  br i1 %descriptor.range.valid.247, label %descriptor.valid.249, label %descriptor.invalid.250
descriptor.invalid.250:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.249:
  %descriptor.initialized.status.251 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.235, i32 %local.check.extent.236)
  %helper.ok.252 = icmp eq i32 %descriptor.initialized.status.251, 0
  br i1 %helper.ok.252, label %helper.continue.253, label %frame.failure.0
helper.continue.253:
  br label %local.descriptor.checked.234
local.descriptor.inactive.233:
  br label %local.descriptor.checked.234
local.descriptor.checked.234:
  %step.status.254 = call i32 @al_owning_charge_step(ptr %ctx, i32 7)
  %helper.ok.255 = icmp eq i32 %step.status.254, 0
  br i1 %helper.ok.255, label %helper.continue.256, label %frame.failure.0
helper.continue.256:
  %call.arguments.257 = alloca [2 x %AlOwningDescriptor], align 4
  %descriptor.element.258 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.257, i32 0
  %descriptor.field.259 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.258, i32 0, i32 0
  store i32 1, ptr %descriptor.field.259, align 4
  %descriptor.field.260 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.258, i32 0, i32 1
  store i32 %context.value.35, ptr %descriptor.field.260, align 4
  %descriptor.field.261 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.258, i32 0, i32 2
  store i32 8, ptr %descriptor.field.261, align 4
  %descriptor.field.262 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.258, i32 0, i32 3
  store i32 8, ptr %descriptor.field.262, align 4
  %descriptor.field.263 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.258, i32 0, i32 4
  store i32 %stack.offset.36, ptr %descriptor.field.263, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %context.value.35, i32 20, i32 8, i32 %stack.offset.36, i32 8)
  %context.field.264 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.265 = load i32, ptr %context.field.264, align 4
  %runtime.ok.266 = icmp eq i32 %context.value.265, 0
  br i1 %runtime.ok.266, label %runtime.continue.267, label %frame.failure.0
runtime.continue.267:
  %descriptor.element.268 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.257, i32 1
  %descriptor.field.269 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.268, i32 0, i32 0
  store i32 1, ptr %descriptor.field.269, align 4
  %descriptor.field.270 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.268, i32 0, i32 1
  store i32 %context.value.138, ptr %descriptor.field.270, align 4
  %descriptor.field.271 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.268, i32 0, i32 2
  store i32 8, ptr %descriptor.field.271, align 4
  %descriptor.field.272 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.268, i32 0, i32 3
  store i32 8, ptr %descriptor.field.272, align 4
  %descriptor.field.273 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.268, i32 0, i32 4
  store i32 %stack.offset.139, ptr %descriptor.field.273, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %context.value.138, i32 20, i32 8, i32 %stack.offset.139, i32 8)
  %context.field.274 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.275 = load i32, ptr %context.field.274, align 4
  %runtime.ok.276 = icmp eq i32 %context.value.275, 0
  br i1 %runtime.ok.276, label %runtime.continue.277, label %frame.failure.0
runtime.continue.277:
  %call.results.278 = alloca [1 x %AlOwningDescriptor], align 4
  %callee.status.279 = call i32 @agentlang_word_0001(ptr %ctx, ptr %call.arguments.257, ptr %call.results.278, i32 8)
  %helper.ok.280 = icmp eq i32 %callee.status.279, 0
  br i1 %helper.ok.280, label %helper.continue.281, label %frame.failure.0
helper.continue.281:
  %descriptor.element.282 = getelementptr inbounds %AlOwningDescriptor, ptr %call.results.278, i32 0
  %descriptor.field.283 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.282, i32 0, i32 0
  %descriptor.value.284 = load i32, ptr %descriptor.field.283, align 4
  %descriptor.field.285 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.282, i32 0, i32 1
  %descriptor.value.286 = load i32, ptr %descriptor.field.285, align 4
  %descriptor.field.287 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.282, i32 0, i32 2
  %descriptor.value.288 = load i32, ptr %descriptor.field.287, align 4
  %descriptor.field.289 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.282, i32 0, i32 3
  %descriptor.value.290 = load i32, ptr %descriptor.field.289, align 4
  %descriptor.field.291 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.282, i32 0, i32 4
  %descriptor.value.292 = load i32, ptr %descriptor.field.291, align 4
  %callee.result.type.valid.293 = icmp eq i32 %descriptor.value.284, 5
  br i1 %callee.result.type.valid.293, label %callee.result.type.ok.294, label %frame.failure.0
callee.result.type.ok.294:
  %context.field.295 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.296 = load i32, ptr %context.field.295, align 4
  %stack.sub.299 = sub i32 %descriptor.value.292, %descriptor.value.286
  %descriptor.owner.inside.297 = icmp ule i32 %descriptor.value.292, %context.value.296
  %descriptor.offset.inside.298 = icmp ule i32 %descriptor.value.286, %descriptor.value.292
  %descriptor.extent.inside.300 = icmp ule i32 %descriptor.value.288, %stack.sub.299
  %descriptor.payload.inside.301 = icmp ule i32 %descriptor.value.290, %descriptor.value.288
  %descriptor.owner.offset.valid.302 = and i1 %descriptor.owner.inside.297, %descriptor.offset.inside.298
  %descriptor.range.inside.304 = and i1 %descriptor.owner.offset.valid.302, %descriptor.extent.inside.300
  %descriptor.range.valid.303 = and i1 %descriptor.range.inside.304, %descriptor.payload.inside.301
  %descriptor.type.valid.305 = icmp eq i32 5, 5
  %descriptor.valid.306 = and i1 %descriptor.range.valid.303, %descriptor.type.valid.305
  br i1 %descriptor.valid.306, label %descriptor.valid.307, label %descriptor.invalid.308
descriptor.invalid.308:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.307:
  %descriptor.initialized.status.309 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.286, i32 %descriptor.value.288)
  %helper.ok.310 = icmp eq i32 %descriptor.initialized.status.309, 0
  br i1 %helper.ok.310, label %helper.continue.311, label %frame.failure.0
helper.continue.311:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.286, i32 20, i32 %descriptor.value.290, i32 %descriptor.value.292, i32 %descriptor.value.288)
  %context.field.312 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.313 = load i32, ptr %context.field.312, align 4
  %runtime.ok.314 = icmp eq i32 %context.value.313, 0
  br i1 %runtime.ok.314, label %runtime.continue.315, label %frame.failure.0
runtime.continue.315:
  %context.field.316 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.317 = load i32, ptr %context.field.316, align 4
  %stack.sub.320 = sub i32 %descriptor.value.292, %descriptor.value.286
  %descriptor.owner.inside.318 = icmp ule i32 %descriptor.value.292, %context.value.317
  %descriptor.offset.inside.319 = icmp ule i32 %descriptor.value.286, %descriptor.value.292
  %descriptor.extent.inside.321 = icmp ule i32 %descriptor.value.288, %stack.sub.320
  %descriptor.payload.inside.322 = icmp ule i32 %descriptor.value.290, %descriptor.value.288
  %descriptor.owner.offset.valid.323 = and i1 %descriptor.owner.inside.318, %descriptor.offset.inside.319
  %descriptor.range.inside.325 = and i1 %descriptor.owner.offset.valid.323, %descriptor.extent.inside.321
  %descriptor.range.valid.324 = and i1 %descriptor.range.inside.325, %descriptor.payload.inside.322
  %descriptor.type.valid.326 = icmp eq i32 5, 5
  %descriptor.valid.327 = and i1 %descriptor.range.valid.324, %descriptor.type.valid.326
  br i1 %descriptor.valid.327, label %descriptor.valid.328, label %descriptor.invalid.329
descriptor.invalid.329:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.328:
  %descriptor.initialized.status.330 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.286, i32 %descriptor.value.288)
  %helper.ok.331 = icmp eq i32 %descriptor.initialized.status.330, 0
  br i1 %helper.ok.331, label %helper.continue.332, label %frame.failure.0
helper.continue.332:
  %local.is.active.333 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.333, label %local.descriptor.active.334, label %local.descriptor.inactive.335
local.descriptor.active.334:
  %local.check.offset.337 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.338 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.339 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.340 = load i32, ptr %local.owner.end.6, align 4
  %context.field.341 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.342 = load i32, ptr %context.field.341, align 4
  %stack.sub.345 = sub i32 %local.check.owner.end.340, %local.check.offset.337
  %descriptor.owner.inside.343 = icmp ule i32 %local.check.owner.end.340, %context.value.342
  %descriptor.offset.inside.344 = icmp ule i32 %local.check.offset.337, %local.check.owner.end.340
  %descriptor.extent.inside.346 = icmp ule i32 %local.check.extent.338, %stack.sub.345
  %descriptor.payload.inside.347 = icmp ule i32 %local.check.payload.339, %local.check.extent.338
  %descriptor.owner.offset.valid.348 = and i1 %descriptor.owner.inside.343, %descriptor.offset.inside.344
  %descriptor.range.inside.350 = and i1 %descriptor.owner.offset.valid.348, %descriptor.extent.inside.346
  %descriptor.range.valid.349 = and i1 %descriptor.range.inside.350, %descriptor.payload.inside.347
  br i1 %descriptor.range.valid.349, label %descriptor.valid.351, label %descriptor.invalid.352
descriptor.invalid.352:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.351:
  %descriptor.initialized.status.353 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.337, i32 %local.check.extent.338)
  %helper.ok.354 = icmp eq i32 %descriptor.initialized.status.353, 0
  br i1 %helper.ok.354, label %helper.continue.355, label %frame.failure.0
helper.continue.355:
  br label %local.descriptor.checked.336
local.descriptor.inactive.335:
  br label %local.descriptor.checked.336
local.descriptor.checked.336:
  %local.is.active.356 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.356, label %local.descriptor.active.357, label %local.descriptor.inactive.358
local.descriptor.active.357:
  %local.check.offset.360 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.361 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.362 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.363 = load i32, ptr %local.owner.end.12, align 4
  %context.field.364 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.365 = load i32, ptr %context.field.364, align 4
  %stack.sub.368 = sub i32 %local.check.owner.end.363, %local.check.offset.360
  %descriptor.owner.inside.366 = icmp ule i32 %local.check.owner.end.363, %context.value.365
  %descriptor.offset.inside.367 = icmp ule i32 %local.check.offset.360, %local.check.owner.end.363
  %descriptor.extent.inside.369 = icmp ule i32 %local.check.extent.361, %stack.sub.368
  %descriptor.payload.inside.370 = icmp ule i32 %local.check.payload.362, %local.check.extent.361
  %descriptor.owner.offset.valid.371 = and i1 %descriptor.owner.inside.366, %descriptor.offset.inside.367
  %descriptor.range.inside.373 = and i1 %descriptor.owner.offset.valid.371, %descriptor.extent.inside.369
  %descriptor.range.valid.372 = and i1 %descriptor.range.inside.373, %descriptor.payload.inside.370
  br i1 %descriptor.range.valid.372, label %descriptor.valid.374, label %descriptor.invalid.375
descriptor.invalid.375:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.374:
  %descriptor.initialized.status.376 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.360, i32 %local.check.extent.361)
  %helper.ok.377 = icmp eq i32 %descriptor.initialized.status.376, 0
  br i1 %helper.ok.377, label %helper.continue.378, label %frame.failure.0
helper.continue.378:
  br label %local.descriptor.checked.359
local.descriptor.inactive.358:
  br label %local.descriptor.checked.359
local.descriptor.checked.359:
  %local.is.active.379 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.379, label %local.descriptor.active.380, label %local.descriptor.inactive.381
local.descriptor.active.380:
  %local.check.offset.383 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.384 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.385 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.386 = load i32, ptr %local.owner.end.18, align 4
  %context.field.387 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.388 = load i32, ptr %context.field.387, align 4
  %stack.sub.391 = sub i32 %local.check.owner.end.386, %local.check.offset.383
  %descriptor.owner.inside.389 = icmp ule i32 %local.check.owner.end.386, %context.value.388
  %descriptor.offset.inside.390 = icmp ule i32 %local.check.offset.383, %local.check.owner.end.386
  %descriptor.extent.inside.392 = icmp ule i32 %local.check.extent.384, %stack.sub.391
  %descriptor.payload.inside.393 = icmp ule i32 %local.check.payload.385, %local.check.extent.384
  %descriptor.owner.offset.valid.394 = and i1 %descriptor.owner.inside.389, %descriptor.offset.inside.390
  %descriptor.range.inside.396 = and i1 %descriptor.owner.offset.valid.394, %descriptor.extent.inside.392
  %descriptor.range.valid.395 = and i1 %descriptor.range.inside.396, %descriptor.payload.inside.393
  br i1 %descriptor.range.valid.395, label %descriptor.valid.397, label %descriptor.invalid.398
descriptor.invalid.398:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.397:
  %descriptor.initialized.status.399 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.383, i32 %local.check.extent.384)
  %helper.ok.400 = icmp eq i32 %descriptor.initialized.status.399, 0
  br i1 %helper.ok.400, label %helper.continue.401, label %frame.failure.0
helper.continue.401:
  br label %local.descriptor.checked.382
local.descriptor.inactive.381:
  br label %local.descriptor.checked.382
local.descriptor.checked.382:
  %step.status.402 = call i32 @al_owning_charge_step(ptr %ctx, i32 9)
  %helper.ok.403 = icmp eq i32 %step.status.402, 0
  br i1 %helper.ok.403, label %helper.continue.404, label %frame.failure.0
helper.continue.404:
  store i1 true, ptr %local.active.2, align 1
  store i32 %descriptor.value.286, ptr %local.offset.3, align 4
  store i32 %descriptor.value.288, ptr %local.extent.4, align 4
  store i32 %descriptor.value.290, ptr %local.payload.5, align 4
  store i32 %descriptor.value.292, ptr %local.owner.end.6, align 4
  store i32 5, ptr %local.type.7, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.286, i32 20, i32 %descriptor.value.290, i32 %descriptor.value.292, i32 %descriptor.value.288)
  %context.field.405 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.406 = load i32, ptr %context.field.405, align 4
  %runtime.ok.407 = icmp eq i32 %context.value.406, 0
  br i1 %runtime.ok.407, label %runtime.continue.408, label %frame.failure.0
runtime.continue.408:
  %local.is.active.409 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.409, label %local.descriptor.active.410, label %local.descriptor.inactive.411
local.descriptor.active.410:
  %local.check.offset.413 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.414 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.415 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.416 = load i32, ptr %local.owner.end.6, align 4
  %context.field.417 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.418 = load i32, ptr %context.field.417, align 4
  %stack.sub.421 = sub i32 %local.check.owner.end.416, %local.check.offset.413
  %descriptor.owner.inside.419 = icmp ule i32 %local.check.owner.end.416, %context.value.418
  %descriptor.offset.inside.420 = icmp ule i32 %local.check.offset.413, %local.check.owner.end.416
  %descriptor.extent.inside.422 = icmp ule i32 %local.check.extent.414, %stack.sub.421
  %descriptor.payload.inside.423 = icmp ule i32 %local.check.payload.415, %local.check.extent.414
  %descriptor.owner.offset.valid.424 = and i1 %descriptor.owner.inside.419, %descriptor.offset.inside.420
  %descriptor.range.inside.426 = and i1 %descriptor.owner.offset.valid.424, %descriptor.extent.inside.422
  %descriptor.range.valid.425 = and i1 %descriptor.range.inside.426, %descriptor.payload.inside.423
  br i1 %descriptor.range.valid.425, label %descriptor.valid.427, label %descriptor.invalid.428
descriptor.invalid.428:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.427:
  %descriptor.initialized.status.429 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.413, i32 %local.check.extent.414)
  %helper.ok.430 = icmp eq i32 %descriptor.initialized.status.429, 0
  br i1 %helper.ok.430, label %helper.continue.431, label %frame.failure.0
helper.continue.431:
  br label %local.descriptor.checked.412
local.descriptor.inactive.411:
  br label %local.descriptor.checked.412
local.descriptor.checked.412:
  %local.is.active.432 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.432, label %local.descriptor.active.433, label %local.descriptor.inactive.434
local.descriptor.active.433:
  %local.check.offset.436 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.437 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.438 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.439 = load i32, ptr %local.owner.end.12, align 4
  %context.field.440 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.441 = load i32, ptr %context.field.440, align 4
  %stack.sub.444 = sub i32 %local.check.owner.end.439, %local.check.offset.436
  %descriptor.owner.inside.442 = icmp ule i32 %local.check.owner.end.439, %context.value.441
  %descriptor.offset.inside.443 = icmp ule i32 %local.check.offset.436, %local.check.owner.end.439
  %descriptor.extent.inside.445 = icmp ule i32 %local.check.extent.437, %stack.sub.444
  %descriptor.payload.inside.446 = icmp ule i32 %local.check.payload.438, %local.check.extent.437
  %descriptor.owner.offset.valid.447 = and i1 %descriptor.owner.inside.442, %descriptor.offset.inside.443
  %descriptor.range.inside.449 = and i1 %descriptor.owner.offset.valid.447, %descriptor.extent.inside.445
  %descriptor.range.valid.448 = and i1 %descriptor.range.inside.449, %descriptor.payload.inside.446
  br i1 %descriptor.range.valid.448, label %descriptor.valid.450, label %descriptor.invalid.451
descriptor.invalid.451:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.450:
  %descriptor.initialized.status.452 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.436, i32 %local.check.extent.437)
  %helper.ok.453 = icmp eq i32 %descriptor.initialized.status.452, 0
  br i1 %helper.ok.453, label %helper.continue.454, label %frame.failure.0
helper.continue.454:
  br label %local.descriptor.checked.435
local.descriptor.inactive.434:
  br label %local.descriptor.checked.435
local.descriptor.checked.435:
  %local.is.active.455 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.455, label %local.descriptor.active.456, label %local.descriptor.inactive.457
local.descriptor.active.456:
  %local.check.offset.459 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.460 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.461 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.462 = load i32, ptr %local.owner.end.18, align 4
  %context.field.463 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.464 = load i32, ptr %context.field.463, align 4
  %stack.sub.467 = sub i32 %local.check.owner.end.462, %local.check.offset.459
  %descriptor.owner.inside.465 = icmp ule i32 %local.check.owner.end.462, %context.value.464
  %descriptor.offset.inside.466 = icmp ule i32 %local.check.offset.459, %local.check.owner.end.462
  %descriptor.extent.inside.468 = icmp ule i32 %local.check.extent.460, %stack.sub.467
  %descriptor.payload.inside.469 = icmp ule i32 %local.check.payload.461, %local.check.extent.460
  %descriptor.owner.offset.valid.470 = and i1 %descriptor.owner.inside.465, %descriptor.offset.inside.466
  %descriptor.range.inside.472 = and i1 %descriptor.owner.offset.valid.470, %descriptor.extent.inside.468
  %descriptor.range.valid.471 = and i1 %descriptor.range.inside.472, %descriptor.payload.inside.469
  br i1 %descriptor.range.valid.471, label %descriptor.valid.473, label %descriptor.invalid.474
descriptor.invalid.474:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.473:
  %descriptor.initialized.status.475 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.459, i32 %local.check.extent.460)
  %helper.ok.476 = icmp eq i32 %descriptor.initialized.status.475, 0
  br i1 %helper.ok.476, label %helper.continue.477, label %frame.failure.0
helper.continue.477:
  br label %local.descriptor.checked.458
local.descriptor.inactive.457:
  br label %local.descriptor.checked.458
local.descriptor.checked.458:
  %step.status.478 = call i32 @al_owning_charge_step(ptr %ctx, i32 10)
  %helper.ok.479 = icmp eq i32 %step.status.478, 0
  br i1 %helper.ok.479, label %helper.continue.480, label %frame.failure.0
helper.continue.480:
  %context.field.481 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.482 = load i32, ptr %context.field.481, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  %step.status.483 = call i32 @al_owning_charge_step(ptr %ctx, i32 11)
  %helper.ok.484 = icmp eq i32 %step.status.483, 0
  br i1 %helper.ok.484, label %helper.continue.485, label %frame.failure.0
helper.continue.485:
  %context.field.486 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.487 = load i32, ptr %context.field.486, align 4
  %stack.offset.488 = add i32 %context.value.487, 8
  %reserve.status.489 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.488, i32 12)
  %reserve.ok.490 = icmp eq i32 %reserve.status.489, 0
  br i1 %reserve.ok.490, label %reserve.continue.491, label %frame.failure.0
reserve.continue.491:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.487, i64 10, i32 1)
  %context.field.492 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.493 = load i32, ptr %context.field.492, align 4
  %runtime.ok.494 = icmp eq i32 %context.value.493, 0
  br i1 %runtime.ok.494, label %runtime.continue.495, label %frame.failure.0
runtime.continue.495:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.496 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.497 = load i32, ptr %context.field.496, align 4
  %runtime.ok.498 = icmp eq i32 %context.value.497, 0
  br i1 %runtime.ok.498, label %runtime.continue.499, label %frame.failure.0
runtime.continue.499:
  %context.field.500 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.501 = load i32, ptr %context.field.500, align 4
  %stack.sub.504 = sub i32 %stack.offset.488, %context.value.487
  %descriptor.owner.inside.502 = icmp ule i32 %stack.offset.488, %context.value.501
  %descriptor.offset.inside.503 = icmp ule i32 %context.value.487, %stack.offset.488
  %descriptor.extent.inside.505 = icmp ule i32 8, %stack.sub.504
  %descriptor.payload.inside.506 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.507 = and i1 %descriptor.owner.inside.502, %descriptor.offset.inside.503
  %descriptor.range.inside.509 = and i1 %descriptor.owner.offset.valid.507, %descriptor.extent.inside.505
  %descriptor.range.valid.508 = and i1 %descriptor.range.inside.509, %descriptor.payload.inside.506
  %descriptor.type.valid.510 = icmp eq i32 1, 1
  %descriptor.valid.511 = and i1 %descriptor.range.valid.508, %descriptor.type.valid.510
  br i1 %descriptor.valid.511, label %descriptor.valid.512, label %descriptor.invalid.513
descriptor.invalid.513:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.512:
  %descriptor.initialized.status.514 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.487, i32 8)
  %helper.ok.515 = icmp eq i32 %descriptor.initialized.status.514, 0
  br i1 %helper.ok.515, label %helper.continue.516, label %frame.failure.0
helper.continue.516:
  %local.is.active.517 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.517, label %local.descriptor.active.518, label %local.descriptor.inactive.519
local.descriptor.active.518:
  %local.check.offset.521 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.522 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.523 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.524 = load i32, ptr %local.owner.end.6, align 4
  %context.field.525 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.526 = load i32, ptr %context.field.525, align 4
  %stack.sub.529 = sub i32 %local.check.owner.end.524, %local.check.offset.521
  %descriptor.owner.inside.527 = icmp ule i32 %local.check.owner.end.524, %context.value.526
  %descriptor.offset.inside.528 = icmp ule i32 %local.check.offset.521, %local.check.owner.end.524
  %descriptor.extent.inside.530 = icmp ule i32 %local.check.extent.522, %stack.sub.529
  %descriptor.payload.inside.531 = icmp ule i32 %local.check.payload.523, %local.check.extent.522
  %descriptor.owner.offset.valid.532 = and i1 %descriptor.owner.inside.527, %descriptor.offset.inside.528
  %descriptor.range.inside.534 = and i1 %descriptor.owner.offset.valid.532, %descriptor.extent.inside.530
  %descriptor.range.valid.533 = and i1 %descriptor.range.inside.534, %descriptor.payload.inside.531
  br i1 %descriptor.range.valid.533, label %descriptor.valid.535, label %descriptor.invalid.536
descriptor.invalid.536:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.535:
  %descriptor.initialized.status.537 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.521, i32 %local.check.extent.522)
  %helper.ok.538 = icmp eq i32 %descriptor.initialized.status.537, 0
  br i1 %helper.ok.538, label %helper.continue.539, label %frame.failure.0
helper.continue.539:
  br label %local.descriptor.checked.520
local.descriptor.inactive.519:
  br label %local.descriptor.checked.520
local.descriptor.checked.520:
  %local.is.active.540 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.540, label %local.descriptor.active.541, label %local.descriptor.inactive.542
local.descriptor.active.541:
  %local.check.offset.544 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.545 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.546 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.547 = load i32, ptr %local.owner.end.12, align 4
  %context.field.548 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.549 = load i32, ptr %context.field.548, align 4
  %stack.sub.552 = sub i32 %local.check.owner.end.547, %local.check.offset.544
  %descriptor.owner.inside.550 = icmp ule i32 %local.check.owner.end.547, %context.value.549
  %descriptor.offset.inside.551 = icmp ule i32 %local.check.offset.544, %local.check.owner.end.547
  %descriptor.extent.inside.553 = icmp ule i32 %local.check.extent.545, %stack.sub.552
  %descriptor.payload.inside.554 = icmp ule i32 %local.check.payload.546, %local.check.extent.545
  %descriptor.owner.offset.valid.555 = and i1 %descriptor.owner.inside.550, %descriptor.offset.inside.551
  %descriptor.range.inside.557 = and i1 %descriptor.owner.offset.valid.555, %descriptor.extent.inside.553
  %descriptor.range.valid.556 = and i1 %descriptor.range.inside.557, %descriptor.payload.inside.554
  br i1 %descriptor.range.valid.556, label %descriptor.valid.558, label %descriptor.invalid.559
descriptor.invalid.559:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.558:
  %descriptor.initialized.status.560 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.544, i32 %local.check.extent.545)
  %helper.ok.561 = icmp eq i32 %descriptor.initialized.status.560, 0
  br i1 %helper.ok.561, label %helper.continue.562, label %frame.failure.0
helper.continue.562:
  br label %local.descriptor.checked.543
local.descriptor.inactive.542:
  br label %local.descriptor.checked.543
local.descriptor.checked.543:
  %local.is.active.563 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.563, label %local.descriptor.active.564, label %local.descriptor.inactive.565
local.descriptor.active.564:
  %local.check.offset.567 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.568 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.569 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.570 = load i32, ptr %local.owner.end.18, align 4
  %context.field.571 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.572 = load i32, ptr %context.field.571, align 4
  %stack.sub.575 = sub i32 %local.check.owner.end.570, %local.check.offset.567
  %descriptor.owner.inside.573 = icmp ule i32 %local.check.owner.end.570, %context.value.572
  %descriptor.offset.inside.574 = icmp ule i32 %local.check.offset.567, %local.check.owner.end.570
  %descriptor.extent.inside.576 = icmp ule i32 %local.check.extent.568, %stack.sub.575
  %descriptor.payload.inside.577 = icmp ule i32 %local.check.payload.569, %local.check.extent.568
  %descriptor.owner.offset.valid.578 = and i1 %descriptor.owner.inside.573, %descriptor.offset.inside.574
  %descriptor.range.inside.580 = and i1 %descriptor.owner.offset.valid.578, %descriptor.extent.inside.576
  %descriptor.range.valid.579 = and i1 %descriptor.range.inside.580, %descriptor.payload.inside.577
  br i1 %descriptor.range.valid.579, label %descriptor.valid.581, label %descriptor.invalid.582
descriptor.invalid.582:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.581:
  %descriptor.initialized.status.583 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.567, i32 %local.check.extent.568)
  %helper.ok.584 = icmp eq i32 %descriptor.initialized.status.583, 0
  br i1 %helper.ok.584, label %helper.continue.585, label %frame.failure.0
helper.continue.585:
  br label %local.descriptor.checked.566
local.descriptor.inactive.565:
  br label %local.descriptor.checked.566
local.descriptor.checked.566:
  %step.status.586 = call i32 @al_owning_charge_step(ptr %ctx, i32 13)
  %helper.ok.587 = icmp eq i32 %step.status.586, 0
  br i1 %helper.ok.587, label %helper.continue.588, label %frame.failure.0
helper.continue.588:
  store i1 true, ptr %local.active.8, align 1
  store i32 %context.value.487, ptr %local.offset.9, align 4
  store i32 8, ptr %local.extent.10, align 4
  store i32 8, ptr %local.payload.11, align 4
  store i32 %stack.offset.488, ptr %local.owner.end.12, align 4
  store i32 1, ptr %local.type.13, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %context.value.487, i32 20, i32 8, i32 %stack.offset.488, i32 8)
  %context.field.589 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.590 = load i32, ptr %context.field.589, align 4
  %runtime.ok.591 = icmp eq i32 %context.value.590, 0
  br i1 %runtime.ok.591, label %runtime.continue.592, label %frame.failure.0
runtime.continue.592:
  %local.is.active.593 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.593, label %local.descriptor.active.594, label %local.descriptor.inactive.595
local.descriptor.active.594:
  %local.check.offset.597 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.598 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.599 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.600 = load i32, ptr %local.owner.end.6, align 4
  %context.field.601 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.602 = load i32, ptr %context.field.601, align 4
  %stack.sub.605 = sub i32 %local.check.owner.end.600, %local.check.offset.597
  %descriptor.owner.inside.603 = icmp ule i32 %local.check.owner.end.600, %context.value.602
  %descriptor.offset.inside.604 = icmp ule i32 %local.check.offset.597, %local.check.owner.end.600
  %descriptor.extent.inside.606 = icmp ule i32 %local.check.extent.598, %stack.sub.605
  %descriptor.payload.inside.607 = icmp ule i32 %local.check.payload.599, %local.check.extent.598
  %descriptor.owner.offset.valid.608 = and i1 %descriptor.owner.inside.603, %descriptor.offset.inside.604
  %descriptor.range.inside.610 = and i1 %descriptor.owner.offset.valid.608, %descriptor.extent.inside.606
  %descriptor.range.valid.609 = and i1 %descriptor.range.inside.610, %descriptor.payload.inside.607
  br i1 %descriptor.range.valid.609, label %descriptor.valid.611, label %descriptor.invalid.612
descriptor.invalid.612:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.611:
  %descriptor.initialized.status.613 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.597, i32 %local.check.extent.598)
  %helper.ok.614 = icmp eq i32 %descriptor.initialized.status.613, 0
  br i1 %helper.ok.614, label %helper.continue.615, label %frame.failure.0
helper.continue.615:
  br label %local.descriptor.checked.596
local.descriptor.inactive.595:
  br label %local.descriptor.checked.596
local.descriptor.checked.596:
  %local.is.active.616 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.616, label %local.descriptor.active.617, label %local.descriptor.inactive.618
local.descriptor.active.617:
  %local.check.offset.620 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.621 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.622 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.623 = load i32, ptr %local.owner.end.12, align 4
  %context.field.624 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.625 = load i32, ptr %context.field.624, align 4
  %stack.sub.628 = sub i32 %local.check.owner.end.623, %local.check.offset.620
  %descriptor.owner.inside.626 = icmp ule i32 %local.check.owner.end.623, %context.value.625
  %descriptor.offset.inside.627 = icmp ule i32 %local.check.offset.620, %local.check.owner.end.623
  %descriptor.extent.inside.629 = icmp ule i32 %local.check.extent.621, %stack.sub.628
  %descriptor.payload.inside.630 = icmp ule i32 %local.check.payload.622, %local.check.extent.621
  %descriptor.owner.offset.valid.631 = and i1 %descriptor.owner.inside.626, %descriptor.offset.inside.627
  %descriptor.range.inside.633 = and i1 %descriptor.owner.offset.valid.631, %descriptor.extent.inside.629
  %descriptor.range.valid.632 = and i1 %descriptor.range.inside.633, %descriptor.payload.inside.630
  br i1 %descriptor.range.valid.632, label %descriptor.valid.634, label %descriptor.invalid.635
descriptor.invalid.635:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.634:
  %descriptor.initialized.status.636 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.620, i32 %local.check.extent.621)
  %helper.ok.637 = icmp eq i32 %descriptor.initialized.status.636, 0
  br i1 %helper.ok.637, label %helper.continue.638, label %frame.failure.0
helper.continue.638:
  br label %local.descriptor.checked.619
local.descriptor.inactive.618:
  br label %local.descriptor.checked.619
local.descriptor.checked.619:
  %local.is.active.639 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.639, label %local.descriptor.active.640, label %local.descriptor.inactive.641
local.descriptor.active.640:
  %local.check.offset.643 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.644 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.645 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.646 = load i32, ptr %local.owner.end.18, align 4
  %context.field.647 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.648 = load i32, ptr %context.field.647, align 4
  %stack.sub.651 = sub i32 %local.check.owner.end.646, %local.check.offset.643
  %descriptor.owner.inside.649 = icmp ule i32 %local.check.owner.end.646, %context.value.648
  %descriptor.offset.inside.650 = icmp ule i32 %local.check.offset.643, %local.check.owner.end.646
  %descriptor.extent.inside.652 = icmp ule i32 %local.check.extent.644, %stack.sub.651
  %descriptor.payload.inside.653 = icmp ule i32 %local.check.payload.645, %local.check.extent.644
  %descriptor.owner.offset.valid.654 = and i1 %descriptor.owner.inside.649, %descriptor.offset.inside.650
  %descriptor.range.inside.656 = and i1 %descriptor.owner.offset.valid.654, %descriptor.extent.inside.652
  %descriptor.range.valid.655 = and i1 %descriptor.range.inside.656, %descriptor.payload.inside.653
  br i1 %descriptor.range.valid.655, label %descriptor.valid.657, label %descriptor.invalid.658
descriptor.invalid.658:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.657:
  %descriptor.initialized.status.659 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.643, i32 %local.check.extent.644)
  %helper.ok.660 = icmp eq i32 %descriptor.initialized.status.659, 0
  br i1 %helper.ok.660, label %helper.continue.661, label %frame.failure.0
helper.continue.661:
  br label %local.descriptor.checked.642
local.descriptor.inactive.641:
  br label %local.descriptor.checked.642
local.descriptor.checked.642:
  %step.status.662 = call i32 @al_owning_charge_step(ptr %ctx, i32 14)
  %helper.ok.663 = icmp eq i32 %step.status.662, 0
  br i1 %helper.ok.663, label %helper.continue.664, label %frame.failure.0
helper.continue.664:
  %local.resolved.offset.665 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.666 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.667 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.668 = load i32, ptr %local.owner.end.6, align 4
  %context.field.669 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.670 = load i32, ptr %context.field.669, align 4
  %stack.sub.673 = sub i32 %local.resolved.owner.end.668, %local.resolved.offset.665
  %descriptor.owner.inside.671 = icmp ule i32 %local.resolved.owner.end.668, %context.value.670
  %descriptor.offset.inside.672 = icmp ule i32 %local.resolved.offset.665, %local.resolved.owner.end.668
  %descriptor.extent.inside.674 = icmp ule i32 %local.resolved.extent.666, %stack.sub.673
  %descriptor.payload.inside.675 = icmp ule i32 %local.resolved.payload.667, %local.resolved.extent.666
  %descriptor.owner.offset.valid.676 = and i1 %descriptor.owner.inside.671, %descriptor.offset.inside.672
  %descriptor.range.inside.678 = and i1 %descriptor.owner.offset.valid.676, %descriptor.extent.inside.674
  %descriptor.range.valid.677 = and i1 %descriptor.range.inside.678, %descriptor.payload.inside.675
  %descriptor.type.valid.679 = icmp eq i32 5, 5
  %descriptor.valid.680 = and i1 %descriptor.range.valid.677, %descriptor.type.valid.679
  br i1 %descriptor.valid.680, label %descriptor.valid.681, label %descriptor.invalid.682
descriptor.invalid.682:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.681:
  %descriptor.initialized.status.683 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.665, i32 %local.resolved.extent.666)
  %helper.ok.684 = icmp eq i32 %descriptor.initialized.status.683, 0
  br i1 %helper.ok.684, label %helper.continue.685, label %frame.failure.0
helper.continue.685:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %local.resolved.offset.665, i32 20, i32 %local.resolved.payload.667, i32 %local.resolved.owner.end.668, i32 %local.resolved.extent.666)
  %context.field.686 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.687 = load i32, ptr %context.field.686, align 4
  %runtime.ok.688 = icmp eq i32 %context.value.687, 0
  br i1 %runtime.ok.688, label %runtime.continue.689, label %frame.failure.0
runtime.continue.689:
  %context.field.690 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.691 = load i32, ptr %context.field.690, align 4
  %stack.sub.694 = sub i32 %local.resolved.owner.end.668, %local.resolved.offset.665
  %descriptor.owner.inside.692 = icmp ule i32 %local.resolved.owner.end.668, %context.value.691
  %descriptor.offset.inside.693 = icmp ule i32 %local.resolved.offset.665, %local.resolved.owner.end.668
  %descriptor.extent.inside.695 = icmp ule i32 %local.resolved.extent.666, %stack.sub.694
  %descriptor.payload.inside.696 = icmp ule i32 %local.resolved.payload.667, %local.resolved.extent.666
  %descriptor.owner.offset.valid.697 = and i1 %descriptor.owner.inside.692, %descriptor.offset.inside.693
  %descriptor.range.inside.699 = and i1 %descriptor.owner.offset.valid.697, %descriptor.extent.inside.695
  %descriptor.range.valid.698 = and i1 %descriptor.range.inside.699, %descriptor.payload.inside.696
  %descriptor.type.valid.700 = icmp eq i32 5, 5
  %descriptor.valid.701 = and i1 %descriptor.range.valid.698, %descriptor.type.valid.700
  br i1 %descriptor.valid.701, label %descriptor.valid.702, label %descriptor.invalid.703
descriptor.invalid.703:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.702:
  %descriptor.initialized.status.704 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.665, i32 %local.resolved.extent.666)
  %helper.ok.705 = icmp eq i32 %descriptor.initialized.status.704, 0
  br i1 %helper.ok.705, label %helper.continue.706, label %frame.failure.0
helper.continue.706:
  %local.is.active.707 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.707, label %local.descriptor.active.708, label %local.descriptor.inactive.709
local.descriptor.active.708:
  %local.check.offset.711 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.712 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.713 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.714 = load i32, ptr %local.owner.end.6, align 4
  %context.field.715 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.716 = load i32, ptr %context.field.715, align 4
  %stack.sub.719 = sub i32 %local.check.owner.end.714, %local.check.offset.711
  %descriptor.owner.inside.717 = icmp ule i32 %local.check.owner.end.714, %context.value.716
  %descriptor.offset.inside.718 = icmp ule i32 %local.check.offset.711, %local.check.owner.end.714
  %descriptor.extent.inside.720 = icmp ule i32 %local.check.extent.712, %stack.sub.719
  %descriptor.payload.inside.721 = icmp ule i32 %local.check.payload.713, %local.check.extent.712
  %descriptor.owner.offset.valid.722 = and i1 %descriptor.owner.inside.717, %descriptor.offset.inside.718
  %descriptor.range.inside.724 = and i1 %descriptor.owner.offset.valid.722, %descriptor.extent.inside.720
  %descriptor.range.valid.723 = and i1 %descriptor.range.inside.724, %descriptor.payload.inside.721
  br i1 %descriptor.range.valid.723, label %descriptor.valid.725, label %descriptor.invalid.726
descriptor.invalid.726:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.725:
  %descriptor.initialized.status.727 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.711, i32 %local.check.extent.712)
  %helper.ok.728 = icmp eq i32 %descriptor.initialized.status.727, 0
  br i1 %helper.ok.728, label %helper.continue.729, label %frame.failure.0
helper.continue.729:
  br label %local.descriptor.checked.710
local.descriptor.inactive.709:
  br label %local.descriptor.checked.710
local.descriptor.checked.710:
  %local.is.active.730 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.730, label %local.descriptor.active.731, label %local.descriptor.inactive.732
local.descriptor.active.731:
  %local.check.offset.734 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.735 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.736 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.737 = load i32, ptr %local.owner.end.12, align 4
  %context.field.738 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.739 = load i32, ptr %context.field.738, align 4
  %stack.sub.742 = sub i32 %local.check.owner.end.737, %local.check.offset.734
  %descriptor.owner.inside.740 = icmp ule i32 %local.check.owner.end.737, %context.value.739
  %descriptor.offset.inside.741 = icmp ule i32 %local.check.offset.734, %local.check.owner.end.737
  %descriptor.extent.inside.743 = icmp ule i32 %local.check.extent.735, %stack.sub.742
  %descriptor.payload.inside.744 = icmp ule i32 %local.check.payload.736, %local.check.extent.735
  %descriptor.owner.offset.valid.745 = and i1 %descriptor.owner.inside.740, %descriptor.offset.inside.741
  %descriptor.range.inside.747 = and i1 %descriptor.owner.offset.valid.745, %descriptor.extent.inside.743
  %descriptor.range.valid.746 = and i1 %descriptor.range.inside.747, %descriptor.payload.inside.744
  br i1 %descriptor.range.valid.746, label %descriptor.valid.748, label %descriptor.invalid.749
descriptor.invalid.749:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.748:
  %descriptor.initialized.status.750 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.734, i32 %local.check.extent.735)
  %helper.ok.751 = icmp eq i32 %descriptor.initialized.status.750, 0
  br i1 %helper.ok.751, label %helper.continue.752, label %frame.failure.0
helper.continue.752:
  br label %local.descriptor.checked.733
local.descriptor.inactive.732:
  br label %local.descriptor.checked.733
local.descriptor.checked.733:
  %local.is.active.753 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.753, label %local.descriptor.active.754, label %local.descriptor.inactive.755
local.descriptor.active.754:
  %local.check.offset.757 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.758 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.759 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.760 = load i32, ptr %local.owner.end.18, align 4
  %context.field.761 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.762 = load i32, ptr %context.field.761, align 4
  %stack.sub.765 = sub i32 %local.check.owner.end.760, %local.check.offset.757
  %descriptor.owner.inside.763 = icmp ule i32 %local.check.owner.end.760, %context.value.762
  %descriptor.offset.inside.764 = icmp ule i32 %local.check.offset.757, %local.check.owner.end.760
  %descriptor.extent.inside.766 = icmp ule i32 %local.check.extent.758, %stack.sub.765
  %descriptor.payload.inside.767 = icmp ule i32 %local.check.payload.759, %local.check.extent.758
  %descriptor.owner.offset.valid.768 = and i1 %descriptor.owner.inside.763, %descriptor.offset.inside.764
  %descriptor.range.inside.770 = and i1 %descriptor.owner.offset.valid.768, %descriptor.extent.inside.766
  %descriptor.range.valid.769 = and i1 %descriptor.range.inside.770, %descriptor.payload.inside.767
  br i1 %descriptor.range.valid.769, label %descriptor.valid.771, label %descriptor.invalid.772
descriptor.invalid.772:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.771:
  %descriptor.initialized.status.773 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.757, i32 %local.check.extent.758)
  %helper.ok.774 = icmp eq i32 %descriptor.initialized.status.773, 0
  br i1 %helper.ok.774, label %helper.continue.775, label %frame.failure.0
helper.continue.775:
  br label %local.descriptor.checked.756
local.descriptor.inactive.755:
  br label %local.descriptor.checked.756
local.descriptor.checked.756:
  %step.status.776 = call i32 @al_owning_charge_step(ptr %ctx, i32 15)
  %helper.ok.777 = icmp eq i32 %step.status.776, 0
  br i1 %helper.ok.777, label %helper.continue.778, label %frame.failure.0
helper.continue.778:
  store i1 true, ptr %local.active.14, align 1
  store i32 %local.resolved.offset.665, ptr %local.offset.15, align 4
  store i32 %local.resolved.extent.666, ptr %local.extent.16, align 4
  store i32 %local.resolved.payload.667, ptr %local.payload.17, align 4
  store i32 %local.resolved.owner.end.668, ptr %local.owner.end.18, align 4
  store i32 5, ptr %local.type.19, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %local.resolved.offset.665, i32 20, i32 %local.resolved.payload.667, i32 %local.resolved.owner.end.668, i32 %local.resolved.extent.666)
  %context.field.779 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.780 = load i32, ptr %context.field.779, align 4
  %runtime.ok.781 = icmp eq i32 %context.value.780, 0
  br i1 %runtime.ok.781, label %runtime.continue.782, label %frame.failure.0
runtime.continue.782:
  %local.is.active.783 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.783, label %local.descriptor.active.784, label %local.descriptor.inactive.785
local.descriptor.active.784:
  %local.check.offset.787 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.788 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.789 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.790 = load i32, ptr %local.owner.end.6, align 4
  %context.field.791 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.792 = load i32, ptr %context.field.791, align 4
  %stack.sub.795 = sub i32 %local.check.owner.end.790, %local.check.offset.787
  %descriptor.owner.inside.793 = icmp ule i32 %local.check.owner.end.790, %context.value.792
  %descriptor.offset.inside.794 = icmp ule i32 %local.check.offset.787, %local.check.owner.end.790
  %descriptor.extent.inside.796 = icmp ule i32 %local.check.extent.788, %stack.sub.795
  %descriptor.payload.inside.797 = icmp ule i32 %local.check.payload.789, %local.check.extent.788
  %descriptor.owner.offset.valid.798 = and i1 %descriptor.owner.inside.793, %descriptor.offset.inside.794
  %descriptor.range.inside.800 = and i1 %descriptor.owner.offset.valid.798, %descriptor.extent.inside.796
  %descriptor.range.valid.799 = and i1 %descriptor.range.inside.800, %descriptor.payload.inside.797
  br i1 %descriptor.range.valid.799, label %descriptor.valid.801, label %descriptor.invalid.802
descriptor.invalid.802:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.801:
  %descriptor.initialized.status.803 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.787, i32 %local.check.extent.788)
  %helper.ok.804 = icmp eq i32 %descriptor.initialized.status.803, 0
  br i1 %helper.ok.804, label %helper.continue.805, label %frame.failure.0
helper.continue.805:
  br label %local.descriptor.checked.786
local.descriptor.inactive.785:
  br label %local.descriptor.checked.786
local.descriptor.checked.786:
  %local.is.active.806 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.806, label %local.descriptor.active.807, label %local.descriptor.inactive.808
local.descriptor.active.807:
  %local.check.offset.810 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.811 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.812 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.813 = load i32, ptr %local.owner.end.12, align 4
  %context.field.814 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.815 = load i32, ptr %context.field.814, align 4
  %stack.sub.818 = sub i32 %local.check.owner.end.813, %local.check.offset.810
  %descriptor.owner.inside.816 = icmp ule i32 %local.check.owner.end.813, %context.value.815
  %descriptor.offset.inside.817 = icmp ule i32 %local.check.offset.810, %local.check.owner.end.813
  %descriptor.extent.inside.819 = icmp ule i32 %local.check.extent.811, %stack.sub.818
  %descriptor.payload.inside.820 = icmp ule i32 %local.check.payload.812, %local.check.extent.811
  %descriptor.owner.offset.valid.821 = and i1 %descriptor.owner.inside.816, %descriptor.offset.inside.817
  %descriptor.range.inside.823 = and i1 %descriptor.owner.offset.valid.821, %descriptor.extent.inside.819
  %descriptor.range.valid.822 = and i1 %descriptor.range.inside.823, %descriptor.payload.inside.820
  br i1 %descriptor.range.valid.822, label %descriptor.valid.824, label %descriptor.invalid.825
descriptor.invalid.825:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.824:
  %descriptor.initialized.status.826 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.810, i32 %local.check.extent.811)
  %helper.ok.827 = icmp eq i32 %descriptor.initialized.status.826, 0
  br i1 %helper.ok.827, label %helper.continue.828, label %frame.failure.0
helper.continue.828:
  br label %local.descriptor.checked.809
local.descriptor.inactive.808:
  br label %local.descriptor.checked.809
local.descriptor.checked.809:
  %local.is.active.829 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.829, label %local.descriptor.active.830, label %local.descriptor.inactive.831
local.descriptor.active.830:
  %local.check.offset.833 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.834 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.835 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.836 = load i32, ptr %local.owner.end.18, align 4
  %context.field.837 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.838 = load i32, ptr %context.field.837, align 4
  %stack.sub.841 = sub i32 %local.check.owner.end.836, %local.check.offset.833
  %descriptor.owner.inside.839 = icmp ule i32 %local.check.owner.end.836, %context.value.838
  %descriptor.offset.inside.840 = icmp ule i32 %local.check.offset.833, %local.check.owner.end.836
  %descriptor.extent.inside.842 = icmp ule i32 %local.check.extent.834, %stack.sub.841
  %descriptor.payload.inside.843 = icmp ule i32 %local.check.payload.835, %local.check.extent.834
  %descriptor.owner.offset.valid.844 = and i1 %descriptor.owner.inside.839, %descriptor.offset.inside.840
  %descriptor.range.inside.846 = and i1 %descriptor.owner.offset.valid.844, %descriptor.extent.inside.842
  %descriptor.range.valid.845 = and i1 %descriptor.range.inside.846, %descriptor.payload.inside.843
  br i1 %descriptor.range.valid.845, label %descriptor.valid.847, label %descriptor.invalid.848
descriptor.invalid.848:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.847:
  %descriptor.initialized.status.849 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.833, i32 %local.check.extent.834)
  %helper.ok.850 = icmp eq i32 %descriptor.initialized.status.849, 0
  br i1 %helper.ok.850, label %helper.continue.851, label %frame.failure.0
helper.continue.851:
  br label %local.descriptor.checked.832
local.descriptor.inactive.831:
  br label %local.descriptor.checked.832
local.descriptor.checked.832:
  %step.status.852 = call i32 @al_owning_charge_step(ptr %ctx, i32 16)
  %helper.ok.853 = icmp eq i32 %step.status.852, 0
  br i1 %helper.ok.853, label %helper.continue.854, label %frame.failure.0
helper.continue.854:
  %local.resolved.offset.855 = load i32, ptr %local.offset.9, align 4
  %local.resolved.extent.856 = load i32, ptr %local.extent.10, align 4
  %local.resolved.payload.857 = load i32, ptr %local.payload.11, align 4
  %local.resolved.owner.end.858 = load i32, ptr %local.owner.end.12, align 4
  %context.field.859 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.860 = load i32, ptr %context.field.859, align 4
  %stack.sub.863 = sub i32 %local.resolved.owner.end.858, %local.resolved.offset.855
  %descriptor.owner.inside.861 = icmp ule i32 %local.resolved.owner.end.858, %context.value.860
  %descriptor.offset.inside.862 = icmp ule i32 %local.resolved.offset.855, %local.resolved.owner.end.858
  %descriptor.extent.inside.864 = icmp ule i32 %local.resolved.extent.856, %stack.sub.863
  %descriptor.payload.inside.865 = icmp ule i32 %local.resolved.payload.857, %local.resolved.extent.856
  %descriptor.owner.offset.valid.866 = and i1 %descriptor.owner.inside.861, %descriptor.offset.inside.862
  %descriptor.range.inside.868 = and i1 %descriptor.owner.offset.valid.866, %descriptor.extent.inside.864
  %descriptor.range.valid.867 = and i1 %descriptor.range.inside.868, %descriptor.payload.inside.865
  %descriptor.type.valid.869 = icmp eq i32 1, 1
  %descriptor.valid.870 = and i1 %descriptor.range.valid.867, %descriptor.type.valid.869
  br i1 %descriptor.valid.870, label %descriptor.valid.871, label %descriptor.invalid.872
descriptor.invalid.872:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.871:
  %descriptor.initialized.status.873 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.855, i32 %local.resolved.extent.856)
  %helper.ok.874 = icmp eq i32 %descriptor.initialized.status.873, 0
  br i1 %helper.ok.874, label %helper.continue.875, label %frame.failure.0
helper.continue.875:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %local.resolved.offset.855, i32 20, i32 %local.resolved.payload.857, i32 %local.resolved.owner.end.858, i32 %local.resolved.extent.856)
  %context.field.876 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.877 = load i32, ptr %context.field.876, align 4
  %runtime.ok.878 = icmp eq i32 %context.value.877, 0
  br i1 %runtime.ok.878, label %runtime.continue.879, label %frame.failure.0
runtime.continue.879:
  %context.field.880 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.881 = load i32, ptr %context.field.880, align 4
  %stack.sub.884 = sub i32 %local.resolved.owner.end.858, %local.resolved.offset.855
  %descriptor.owner.inside.882 = icmp ule i32 %local.resolved.owner.end.858, %context.value.881
  %descriptor.offset.inside.883 = icmp ule i32 %local.resolved.offset.855, %local.resolved.owner.end.858
  %descriptor.extent.inside.885 = icmp ule i32 %local.resolved.extent.856, %stack.sub.884
  %descriptor.payload.inside.886 = icmp ule i32 %local.resolved.payload.857, %local.resolved.extent.856
  %descriptor.owner.offset.valid.887 = and i1 %descriptor.owner.inside.882, %descriptor.offset.inside.883
  %descriptor.range.inside.889 = and i1 %descriptor.owner.offset.valid.887, %descriptor.extent.inside.885
  %descriptor.range.valid.888 = and i1 %descriptor.range.inside.889, %descriptor.payload.inside.886
  %descriptor.type.valid.890 = icmp eq i32 1, 1
  %descriptor.valid.891 = and i1 %descriptor.range.valid.888, %descriptor.type.valid.890
  br i1 %descriptor.valid.891, label %descriptor.valid.892, label %descriptor.invalid.893
descriptor.invalid.893:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.892:
  %descriptor.initialized.status.894 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.855, i32 %local.resolved.extent.856)
  %helper.ok.895 = icmp eq i32 %descriptor.initialized.status.894, 0
  br i1 %helper.ok.895, label %helper.continue.896, label %frame.failure.0
helper.continue.896:
  %local.is.active.897 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.897, label %local.descriptor.active.898, label %local.descriptor.inactive.899
local.descriptor.active.898:
  %local.check.offset.901 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.902 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.903 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.904 = load i32, ptr %local.owner.end.6, align 4
  %context.field.905 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.906 = load i32, ptr %context.field.905, align 4
  %stack.sub.909 = sub i32 %local.check.owner.end.904, %local.check.offset.901
  %descriptor.owner.inside.907 = icmp ule i32 %local.check.owner.end.904, %context.value.906
  %descriptor.offset.inside.908 = icmp ule i32 %local.check.offset.901, %local.check.owner.end.904
  %descriptor.extent.inside.910 = icmp ule i32 %local.check.extent.902, %stack.sub.909
  %descriptor.payload.inside.911 = icmp ule i32 %local.check.payload.903, %local.check.extent.902
  %descriptor.owner.offset.valid.912 = and i1 %descriptor.owner.inside.907, %descriptor.offset.inside.908
  %descriptor.range.inside.914 = and i1 %descriptor.owner.offset.valid.912, %descriptor.extent.inside.910
  %descriptor.range.valid.913 = and i1 %descriptor.range.inside.914, %descriptor.payload.inside.911
  br i1 %descriptor.range.valid.913, label %descriptor.valid.915, label %descriptor.invalid.916
descriptor.invalid.916:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.915:
  %descriptor.initialized.status.917 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.901, i32 %local.check.extent.902)
  %helper.ok.918 = icmp eq i32 %descriptor.initialized.status.917, 0
  br i1 %helper.ok.918, label %helper.continue.919, label %frame.failure.0
helper.continue.919:
  br label %local.descriptor.checked.900
local.descriptor.inactive.899:
  br label %local.descriptor.checked.900
local.descriptor.checked.900:
  %local.is.active.920 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.920, label %local.descriptor.active.921, label %local.descriptor.inactive.922
local.descriptor.active.921:
  %local.check.offset.924 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.925 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.926 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.927 = load i32, ptr %local.owner.end.12, align 4
  %context.field.928 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.929 = load i32, ptr %context.field.928, align 4
  %stack.sub.932 = sub i32 %local.check.owner.end.927, %local.check.offset.924
  %descriptor.owner.inside.930 = icmp ule i32 %local.check.owner.end.927, %context.value.929
  %descriptor.offset.inside.931 = icmp ule i32 %local.check.offset.924, %local.check.owner.end.927
  %descriptor.extent.inside.933 = icmp ule i32 %local.check.extent.925, %stack.sub.932
  %descriptor.payload.inside.934 = icmp ule i32 %local.check.payload.926, %local.check.extent.925
  %descriptor.owner.offset.valid.935 = and i1 %descriptor.owner.inside.930, %descriptor.offset.inside.931
  %descriptor.range.inside.937 = and i1 %descriptor.owner.offset.valid.935, %descriptor.extent.inside.933
  %descriptor.range.valid.936 = and i1 %descriptor.range.inside.937, %descriptor.payload.inside.934
  br i1 %descriptor.range.valid.936, label %descriptor.valid.938, label %descriptor.invalid.939
descriptor.invalid.939:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.938:
  %descriptor.initialized.status.940 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.924, i32 %local.check.extent.925)
  %helper.ok.941 = icmp eq i32 %descriptor.initialized.status.940, 0
  br i1 %helper.ok.941, label %helper.continue.942, label %frame.failure.0
helper.continue.942:
  br label %local.descriptor.checked.923
local.descriptor.inactive.922:
  br label %local.descriptor.checked.923
local.descriptor.checked.923:
  %local.is.active.943 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.943, label %local.descriptor.active.944, label %local.descriptor.inactive.945
local.descriptor.active.944:
  %local.check.offset.947 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.948 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.949 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.950 = load i32, ptr %local.owner.end.18, align 4
  %context.field.951 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.952 = load i32, ptr %context.field.951, align 4
  %stack.sub.955 = sub i32 %local.check.owner.end.950, %local.check.offset.947
  %descriptor.owner.inside.953 = icmp ule i32 %local.check.owner.end.950, %context.value.952
  %descriptor.offset.inside.954 = icmp ule i32 %local.check.offset.947, %local.check.owner.end.950
  %descriptor.extent.inside.956 = icmp ule i32 %local.check.extent.948, %stack.sub.955
  %descriptor.payload.inside.957 = icmp ule i32 %local.check.payload.949, %local.check.extent.948
  %descriptor.owner.offset.valid.958 = and i1 %descriptor.owner.inside.953, %descriptor.offset.inside.954
  %descriptor.range.inside.960 = and i1 %descriptor.owner.offset.valid.958, %descriptor.extent.inside.956
  %descriptor.range.valid.959 = and i1 %descriptor.range.inside.960, %descriptor.payload.inside.957
  br i1 %descriptor.range.valid.959, label %descriptor.valid.961, label %descriptor.invalid.962
descriptor.invalid.962:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.961:
  %descriptor.initialized.status.963 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.947, i32 %local.check.extent.948)
  %helper.ok.964 = icmp eq i32 %descriptor.initialized.status.963, 0
  br i1 %helper.ok.964, label %helper.continue.965, label %frame.failure.0
helper.continue.965:
  br label %local.descriptor.checked.946
local.descriptor.inactive.945:
  br label %local.descriptor.checked.946
local.descriptor.checked.946:
  %step.status.966 = call i32 @al_owning_charge_step(ptr %ctx, i32 17)
  %helper.ok.967 = icmp eq i32 %step.status.966, 0
  br i1 %helper.ok.967, label %helper.continue.968, label %frame.failure.0
helper.continue.968:
  %local.resolved.offset.969 = load i32, ptr %local.offset.15, align 4
  %local.resolved.extent.970 = load i32, ptr %local.extent.16, align 4
  %local.resolved.payload.971 = load i32, ptr %local.payload.17, align 4
  %local.resolved.owner.end.972 = load i32, ptr %local.owner.end.18, align 4
  %context.field.973 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.974 = load i32, ptr %context.field.973, align 4
  %stack.sub.977 = sub i32 %local.resolved.owner.end.972, %local.resolved.offset.969
  %descriptor.owner.inside.975 = icmp ule i32 %local.resolved.owner.end.972, %context.value.974
  %descriptor.offset.inside.976 = icmp ule i32 %local.resolved.offset.969, %local.resolved.owner.end.972
  %descriptor.extent.inside.978 = icmp ule i32 %local.resolved.extent.970, %stack.sub.977
  %descriptor.payload.inside.979 = icmp ule i32 %local.resolved.payload.971, %local.resolved.extent.970
  %descriptor.owner.offset.valid.980 = and i1 %descriptor.owner.inside.975, %descriptor.offset.inside.976
  %descriptor.range.inside.982 = and i1 %descriptor.owner.offset.valid.980, %descriptor.extent.inside.978
  %descriptor.range.valid.981 = and i1 %descriptor.range.inside.982, %descriptor.payload.inside.979
  %descriptor.type.valid.983 = icmp eq i32 5, 5
  %descriptor.valid.984 = and i1 %descriptor.range.valid.981, %descriptor.type.valid.983
  br i1 %descriptor.valid.984, label %descriptor.valid.985, label %descriptor.invalid.986
descriptor.invalid.986:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.985:
  %descriptor.initialized.status.987 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.969, i32 %local.resolved.extent.970)
  %helper.ok.988 = icmp eq i32 %descriptor.initialized.status.987, 0
  br i1 %helper.ok.988, label %helper.continue.989, label %frame.failure.0
helper.continue.989:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %local.resolved.offset.969, i32 20, i32 %local.resolved.payload.971, i32 %local.resolved.owner.end.972, i32 %local.resolved.extent.970)
  %context.field.990 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.991 = load i32, ptr %context.field.990, align 4
  %runtime.ok.992 = icmp eq i32 %context.value.991, 0
  br i1 %runtime.ok.992, label %runtime.continue.993, label %frame.failure.0
runtime.continue.993:
  %context.field.994 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.995 = load i32, ptr %context.field.994, align 4
  %stack.sub.998 = sub i32 %local.resolved.owner.end.858, %local.resolved.offset.855
  %descriptor.owner.inside.996 = icmp ule i32 %local.resolved.owner.end.858, %context.value.995
  %descriptor.offset.inside.997 = icmp ule i32 %local.resolved.offset.855, %local.resolved.owner.end.858
  %descriptor.extent.inside.999 = icmp ule i32 %local.resolved.extent.856, %stack.sub.998
  %descriptor.payload.inside.1000 = icmp ule i32 %local.resolved.payload.857, %local.resolved.extent.856
  %descriptor.owner.offset.valid.1001 = and i1 %descriptor.owner.inside.996, %descriptor.offset.inside.997
  %descriptor.range.inside.1003 = and i1 %descriptor.owner.offset.valid.1001, %descriptor.extent.inside.999
  %descriptor.range.valid.1002 = and i1 %descriptor.range.inside.1003, %descriptor.payload.inside.1000
  %descriptor.type.valid.1004 = icmp eq i32 1, 1
  %descriptor.valid.1005 = and i1 %descriptor.range.valid.1002, %descriptor.type.valid.1004
  br i1 %descriptor.valid.1005, label %descriptor.valid.1006, label %descriptor.invalid.1007
descriptor.invalid.1007:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1006:
  %descriptor.initialized.status.1008 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.855, i32 %local.resolved.extent.856)
  %helper.ok.1009 = icmp eq i32 %descriptor.initialized.status.1008, 0
  br i1 %helper.ok.1009, label %helper.continue.1010, label %frame.failure.0
helper.continue.1010:
  %context.field.1011 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1012 = load i32, ptr %context.field.1011, align 4
  %stack.sub.1015 = sub i32 %local.resolved.owner.end.972, %local.resolved.offset.969
  %descriptor.owner.inside.1013 = icmp ule i32 %local.resolved.owner.end.972, %context.value.1012
  %descriptor.offset.inside.1014 = icmp ule i32 %local.resolved.offset.969, %local.resolved.owner.end.972
  %descriptor.extent.inside.1016 = icmp ule i32 %local.resolved.extent.970, %stack.sub.1015
  %descriptor.payload.inside.1017 = icmp ule i32 %local.resolved.payload.971, %local.resolved.extent.970
  %descriptor.owner.offset.valid.1018 = and i1 %descriptor.owner.inside.1013, %descriptor.offset.inside.1014
  %descriptor.range.inside.1020 = and i1 %descriptor.owner.offset.valid.1018, %descriptor.extent.inside.1016
  %descriptor.range.valid.1019 = and i1 %descriptor.range.inside.1020, %descriptor.payload.inside.1017
  %descriptor.type.valid.1021 = icmp eq i32 5, 5
  %descriptor.valid.1022 = and i1 %descriptor.range.valid.1019, %descriptor.type.valid.1021
  br i1 %descriptor.valid.1022, label %descriptor.valid.1023, label %descriptor.invalid.1024
descriptor.invalid.1024:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1023:
  %descriptor.initialized.status.1025 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.969, i32 %local.resolved.extent.970)
  %helper.ok.1026 = icmp eq i32 %descriptor.initialized.status.1025, 0
  br i1 %helper.ok.1026, label %helper.continue.1027, label %frame.failure.0
helper.continue.1027:
  %local.is.active.1028 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1028, label %local.descriptor.active.1029, label %local.descriptor.inactive.1030
local.descriptor.active.1029:
  %local.check.offset.1032 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1033 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1034 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1035 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1036 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1037 = load i32, ptr %context.field.1036, align 4
  %stack.sub.1040 = sub i32 %local.check.owner.end.1035, %local.check.offset.1032
  %descriptor.owner.inside.1038 = icmp ule i32 %local.check.owner.end.1035, %context.value.1037
  %descriptor.offset.inside.1039 = icmp ule i32 %local.check.offset.1032, %local.check.owner.end.1035
  %descriptor.extent.inside.1041 = icmp ule i32 %local.check.extent.1033, %stack.sub.1040
  %descriptor.payload.inside.1042 = icmp ule i32 %local.check.payload.1034, %local.check.extent.1033
  %descriptor.owner.offset.valid.1043 = and i1 %descriptor.owner.inside.1038, %descriptor.offset.inside.1039
  %descriptor.range.inside.1045 = and i1 %descriptor.owner.offset.valid.1043, %descriptor.extent.inside.1041
  %descriptor.range.valid.1044 = and i1 %descriptor.range.inside.1045, %descriptor.payload.inside.1042
  br i1 %descriptor.range.valid.1044, label %descriptor.valid.1046, label %descriptor.invalid.1047
descriptor.invalid.1047:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1046:
  %descriptor.initialized.status.1048 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1032, i32 %local.check.extent.1033)
  %helper.ok.1049 = icmp eq i32 %descriptor.initialized.status.1048, 0
  br i1 %helper.ok.1049, label %helper.continue.1050, label %frame.failure.0
helper.continue.1050:
  br label %local.descriptor.checked.1031
local.descriptor.inactive.1030:
  br label %local.descriptor.checked.1031
local.descriptor.checked.1031:
  %local.is.active.1051 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1051, label %local.descriptor.active.1052, label %local.descriptor.inactive.1053
local.descriptor.active.1052:
  %local.check.offset.1055 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1056 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1057 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1058 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1059 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1060 = load i32, ptr %context.field.1059, align 4
  %stack.sub.1063 = sub i32 %local.check.owner.end.1058, %local.check.offset.1055
  %descriptor.owner.inside.1061 = icmp ule i32 %local.check.owner.end.1058, %context.value.1060
  %descriptor.offset.inside.1062 = icmp ule i32 %local.check.offset.1055, %local.check.owner.end.1058
  %descriptor.extent.inside.1064 = icmp ule i32 %local.check.extent.1056, %stack.sub.1063
  %descriptor.payload.inside.1065 = icmp ule i32 %local.check.payload.1057, %local.check.extent.1056
  %descriptor.owner.offset.valid.1066 = and i1 %descriptor.owner.inside.1061, %descriptor.offset.inside.1062
  %descriptor.range.inside.1068 = and i1 %descriptor.owner.offset.valid.1066, %descriptor.extent.inside.1064
  %descriptor.range.valid.1067 = and i1 %descriptor.range.inside.1068, %descriptor.payload.inside.1065
  br i1 %descriptor.range.valid.1067, label %descriptor.valid.1069, label %descriptor.invalid.1070
descriptor.invalid.1070:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1069:
  %descriptor.initialized.status.1071 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1055, i32 %local.check.extent.1056)
  %helper.ok.1072 = icmp eq i32 %descriptor.initialized.status.1071, 0
  br i1 %helper.ok.1072, label %helper.continue.1073, label %frame.failure.0
helper.continue.1073:
  br label %local.descriptor.checked.1054
local.descriptor.inactive.1053:
  br label %local.descriptor.checked.1054
local.descriptor.checked.1054:
  %local.is.active.1074 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1074, label %local.descriptor.active.1075, label %local.descriptor.inactive.1076
local.descriptor.active.1075:
  %local.check.offset.1078 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1079 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1080 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1081 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1082 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1083 = load i32, ptr %context.field.1082, align 4
  %stack.sub.1086 = sub i32 %local.check.owner.end.1081, %local.check.offset.1078
  %descriptor.owner.inside.1084 = icmp ule i32 %local.check.owner.end.1081, %context.value.1083
  %descriptor.offset.inside.1085 = icmp ule i32 %local.check.offset.1078, %local.check.owner.end.1081
  %descriptor.extent.inside.1087 = icmp ule i32 %local.check.extent.1079, %stack.sub.1086
  %descriptor.payload.inside.1088 = icmp ule i32 %local.check.payload.1080, %local.check.extent.1079
  %descriptor.owner.offset.valid.1089 = and i1 %descriptor.owner.inside.1084, %descriptor.offset.inside.1085
  %descriptor.range.inside.1091 = and i1 %descriptor.owner.offset.valid.1089, %descriptor.extent.inside.1087
  %descriptor.range.valid.1090 = and i1 %descriptor.range.inside.1091, %descriptor.payload.inside.1088
  br i1 %descriptor.range.valid.1090, label %descriptor.valid.1092, label %descriptor.invalid.1093
descriptor.invalid.1093:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1092:
  %descriptor.initialized.status.1094 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1078, i32 %local.check.extent.1079)
  %helper.ok.1095 = icmp eq i32 %descriptor.initialized.status.1094, 0
  br i1 %helper.ok.1095, label %helper.continue.1096, label %frame.failure.0
helper.continue.1096:
  br label %local.descriptor.checked.1077
local.descriptor.inactive.1076:
  br label %local.descriptor.checked.1077
local.descriptor.checked.1077:
  %step.status.1097 = call i32 @al_owning_charge_step(ptr %ctx, i32 18)
  %helper.ok.1098 = icmp eq i32 %step.status.1097, 0
  br i1 %helper.ok.1098, label %helper.continue.1099, label %frame.failure.0
helper.continue.1099:
  %stack.offset.1100 = add i32 0, %local.resolved.payload.857
  %stack.offset.1101 = add i32 %stack.offset.1100, %local.resolved.payload.971
  %stack.offset.1102 = add i32 0, %local.resolved.extent.856
  %stack.offset.1103 = add i32 %stack.offset.1102, %local.resolved.extent.970
  %context.field.1104 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1105 = load i32, ptr %context.field.1104, align 4
  %stack.offset.1106 = add i32 %context.value.1105, %stack.offset.1103
  %reserve.status.1107 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1106, i32 19)
  %reserve.ok.1108 = icmp eq i32 %reserve.status.1107, 0
  br i1 %reserve.ok.1108, label %reserve.continue.1109, label %frame.failure.0
reserve.continue.1109:
  %stack.offset.1110 = add i32 %context.value.1105, 0
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.1110, i32 %local.resolved.offset.855, i32 %local.resolved.extent.856, i32 %local.resolved.payload.857, i32 1, i32 6)
  %context.field.1111 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1112 = load i32, ptr %context.field.1111, align 4
  %runtime.ok.1113 = icmp eq i32 %context.value.1112, 0
  br i1 %runtime.ok.1113, label %runtime.continue.1114, label %frame.failure.0
runtime.continue.1114:
  %stack.offset.1115 = add i32 0, %local.resolved.extent.856
  %stack.offset.1116 = add i32 %context.value.1105, %stack.offset.1115
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.1116, i32 %local.resolved.offset.969, i32 %local.resolved.extent.970, i32 %local.resolved.payload.971, i32 5, i32 6)
  %context.field.1117 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1118 = load i32, ptr %context.field.1117, align 4
  %runtime.ok.1119 = icmp eq i32 %context.value.1118, 0
  br i1 %runtime.ok.1119, label %runtime.continue.1120, label %frame.failure.0
runtime.continue.1120:
  %stack.offset.1121 = add i32 %stack.offset.1115, %local.resolved.extent.970
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 7, i32 %context.value.1105, i32 %stack.offset.1103, i32 %stack.offset.1101, i32 0, i32 0)
  %context.field.1122 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1123 = load i32, ptr %context.field.1122, align 4
  %runtime.ok.1124 = icmp eq i32 %context.value.1123, 0
  br i1 %runtime.ok.1124, label %runtime.continue.1125, label %frame.failure.0
runtime.continue.1125:
  %context.field.1126 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1127 = load i32, ptr %context.field.1126, align 4
  %stack.sub.1130 = sub i32 %stack.offset.1106, %context.value.1105
  %descriptor.owner.inside.1128 = icmp ule i32 %stack.offset.1106, %context.value.1127
  %descriptor.offset.inside.1129 = icmp ule i32 %context.value.1105, %stack.offset.1106
  %descriptor.extent.inside.1131 = icmp ule i32 %stack.offset.1103, %stack.sub.1130
  %descriptor.payload.inside.1132 = icmp ule i32 %stack.offset.1101, %stack.offset.1103
  %descriptor.owner.offset.valid.1133 = and i1 %descriptor.owner.inside.1128, %descriptor.offset.inside.1129
  %descriptor.range.inside.1135 = and i1 %descriptor.owner.offset.valid.1133, %descriptor.extent.inside.1131
  %descriptor.range.valid.1134 = and i1 %descriptor.range.inside.1135, %descriptor.payload.inside.1132
  %descriptor.type.valid.1136 = icmp eq i32 7, 7
  %descriptor.valid.1137 = and i1 %descriptor.range.valid.1134, %descriptor.type.valid.1136
  br i1 %descriptor.valid.1137, label %descriptor.valid.1138, label %descriptor.invalid.1139
descriptor.invalid.1139:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1138:
  %descriptor.initialized.status.1140 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.1105, i32 %stack.offset.1103)
  %helper.ok.1141 = icmp eq i32 %descriptor.initialized.status.1140, 0
  br i1 %helper.ok.1141, label %helper.continue.1142, label %frame.failure.0
helper.continue.1142:
  %local.is.active.1143 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1143, label %local.descriptor.active.1144, label %local.descriptor.inactive.1145
local.descriptor.active.1144:
  %local.check.offset.1147 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1148 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1149 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1150 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1151 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1152 = load i32, ptr %context.field.1151, align 4
  %stack.sub.1155 = sub i32 %local.check.owner.end.1150, %local.check.offset.1147
  %descriptor.owner.inside.1153 = icmp ule i32 %local.check.owner.end.1150, %context.value.1152
  %descriptor.offset.inside.1154 = icmp ule i32 %local.check.offset.1147, %local.check.owner.end.1150
  %descriptor.extent.inside.1156 = icmp ule i32 %local.check.extent.1148, %stack.sub.1155
  %descriptor.payload.inside.1157 = icmp ule i32 %local.check.payload.1149, %local.check.extent.1148
  %descriptor.owner.offset.valid.1158 = and i1 %descriptor.owner.inside.1153, %descriptor.offset.inside.1154
  %descriptor.range.inside.1160 = and i1 %descriptor.owner.offset.valid.1158, %descriptor.extent.inside.1156
  %descriptor.range.valid.1159 = and i1 %descriptor.range.inside.1160, %descriptor.payload.inside.1157
  br i1 %descriptor.range.valid.1159, label %descriptor.valid.1161, label %descriptor.invalid.1162
descriptor.invalid.1162:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1161:
  %descriptor.initialized.status.1163 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1147, i32 %local.check.extent.1148)
  %helper.ok.1164 = icmp eq i32 %descriptor.initialized.status.1163, 0
  br i1 %helper.ok.1164, label %helper.continue.1165, label %frame.failure.0
helper.continue.1165:
  br label %local.descriptor.checked.1146
local.descriptor.inactive.1145:
  br label %local.descriptor.checked.1146
local.descriptor.checked.1146:
  %local.is.active.1166 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1166, label %local.descriptor.active.1167, label %local.descriptor.inactive.1168
local.descriptor.active.1167:
  %local.check.offset.1170 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1171 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1172 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1173 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1174 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1175 = load i32, ptr %context.field.1174, align 4
  %stack.sub.1178 = sub i32 %local.check.owner.end.1173, %local.check.offset.1170
  %descriptor.owner.inside.1176 = icmp ule i32 %local.check.owner.end.1173, %context.value.1175
  %descriptor.offset.inside.1177 = icmp ule i32 %local.check.offset.1170, %local.check.owner.end.1173
  %descriptor.extent.inside.1179 = icmp ule i32 %local.check.extent.1171, %stack.sub.1178
  %descriptor.payload.inside.1180 = icmp ule i32 %local.check.payload.1172, %local.check.extent.1171
  %descriptor.owner.offset.valid.1181 = and i1 %descriptor.owner.inside.1176, %descriptor.offset.inside.1177
  %descriptor.range.inside.1183 = and i1 %descriptor.owner.offset.valid.1181, %descriptor.extent.inside.1179
  %descriptor.range.valid.1182 = and i1 %descriptor.range.inside.1183, %descriptor.payload.inside.1180
  br i1 %descriptor.range.valid.1182, label %descriptor.valid.1184, label %descriptor.invalid.1185
descriptor.invalid.1185:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1184:
  %descriptor.initialized.status.1186 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1170, i32 %local.check.extent.1171)
  %helper.ok.1187 = icmp eq i32 %descriptor.initialized.status.1186, 0
  br i1 %helper.ok.1187, label %helper.continue.1188, label %frame.failure.0
helper.continue.1188:
  br label %local.descriptor.checked.1169
local.descriptor.inactive.1168:
  br label %local.descriptor.checked.1169
local.descriptor.checked.1169:
  %local.is.active.1189 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1189, label %local.descriptor.active.1190, label %local.descriptor.inactive.1191
local.descriptor.active.1190:
  %local.check.offset.1193 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1194 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1195 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1196 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1197 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1198 = load i32, ptr %context.field.1197, align 4
  %stack.sub.1201 = sub i32 %local.check.owner.end.1196, %local.check.offset.1193
  %descriptor.owner.inside.1199 = icmp ule i32 %local.check.owner.end.1196, %context.value.1198
  %descriptor.offset.inside.1200 = icmp ule i32 %local.check.offset.1193, %local.check.owner.end.1196
  %descriptor.extent.inside.1202 = icmp ule i32 %local.check.extent.1194, %stack.sub.1201
  %descriptor.payload.inside.1203 = icmp ule i32 %local.check.payload.1195, %local.check.extent.1194
  %descriptor.owner.offset.valid.1204 = and i1 %descriptor.owner.inside.1199, %descriptor.offset.inside.1200
  %descriptor.range.inside.1206 = and i1 %descriptor.owner.offset.valid.1204, %descriptor.extent.inside.1202
  %descriptor.range.valid.1205 = and i1 %descriptor.range.inside.1206, %descriptor.payload.inside.1203
  br i1 %descriptor.range.valid.1205, label %descriptor.valid.1207, label %descriptor.invalid.1208
descriptor.invalid.1208:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1207:
  %descriptor.initialized.status.1209 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1193, i32 %local.check.extent.1194)
  %helper.ok.1210 = icmp eq i32 %descriptor.initialized.status.1209, 0
  br i1 %helper.ok.1210, label %helper.continue.1211, label %frame.failure.0
helper.continue.1211:
  br label %local.descriptor.checked.1192
local.descriptor.inactive.1191:
  br label %local.descriptor.checked.1192
local.descriptor.checked.1192:
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  %context.field.1212 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1213 = load i32, ptr %context.field.1212, align 4
  %stack.sub.1216 = sub i32 %stack.offset.1106, %context.value.1105
  %descriptor.owner.inside.1214 = icmp ule i32 %stack.offset.1106, %context.value.1213
  %descriptor.offset.inside.1215 = icmp ule i32 %context.value.1105, %stack.offset.1106
  %descriptor.extent.inside.1217 = icmp ule i32 %stack.offset.1103, %stack.sub.1216
  %descriptor.payload.inside.1218 = icmp ule i32 %stack.offset.1101, %stack.offset.1103
  %descriptor.owner.offset.valid.1219 = and i1 %descriptor.owner.inside.1214, %descriptor.offset.inside.1215
  %descriptor.range.inside.1221 = and i1 %descriptor.owner.offset.valid.1219, %descriptor.extent.inside.1217
  %descriptor.range.valid.1220 = and i1 %descriptor.range.inside.1221, %descriptor.payload.inside.1218
  %descriptor.type.valid.1222 = icmp eq i32 7, 7
  %descriptor.valid.1223 = and i1 %descriptor.range.valid.1220, %descriptor.type.valid.1222
  br i1 %descriptor.valid.1223, label %descriptor.valid.1224, label %descriptor.invalid.1225
descriptor.invalid.1225:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1224:
  %descriptor.initialized.status.1226 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.1105, i32 %stack.offset.1103)
  %helper.ok.1227 = icmp eq i32 %descriptor.initialized.status.1226, 0
  br i1 %helper.ok.1227, label %helper.continue.1228, label %frame.failure.0
helper.continue.1228:
  %local.is.active.1229 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1229, label %local.descriptor.active.1230, label %local.descriptor.inactive.1231
local.descriptor.active.1230:
  %local.check.offset.1233 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1234 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1235 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1236 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1237 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1238 = load i32, ptr %context.field.1237, align 4
  %stack.sub.1241 = sub i32 %local.check.owner.end.1236, %local.check.offset.1233
  %descriptor.owner.inside.1239 = icmp ule i32 %local.check.owner.end.1236, %context.value.1238
  %descriptor.offset.inside.1240 = icmp ule i32 %local.check.offset.1233, %local.check.owner.end.1236
  %descriptor.extent.inside.1242 = icmp ule i32 %local.check.extent.1234, %stack.sub.1241
  %descriptor.payload.inside.1243 = icmp ule i32 %local.check.payload.1235, %local.check.extent.1234
  %descriptor.owner.offset.valid.1244 = and i1 %descriptor.owner.inside.1239, %descriptor.offset.inside.1240
  %descriptor.range.inside.1246 = and i1 %descriptor.owner.offset.valid.1244, %descriptor.extent.inside.1242
  %descriptor.range.valid.1245 = and i1 %descriptor.range.inside.1246, %descriptor.payload.inside.1243
  br i1 %descriptor.range.valid.1245, label %descriptor.valid.1247, label %descriptor.invalid.1248
descriptor.invalid.1248:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1247:
  %descriptor.initialized.status.1249 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1233, i32 %local.check.extent.1234)
  %helper.ok.1250 = icmp eq i32 %descriptor.initialized.status.1249, 0
  br i1 %helper.ok.1250, label %helper.continue.1251, label %frame.failure.0
helper.continue.1251:
  br label %local.descriptor.checked.1232
local.descriptor.inactive.1231:
  br label %local.descriptor.checked.1232
local.descriptor.checked.1232:
  %local.is.active.1252 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1252, label %local.descriptor.active.1253, label %local.descriptor.inactive.1254
local.descriptor.active.1253:
  %local.check.offset.1256 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1257 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1258 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1259 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1260 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1261 = load i32, ptr %context.field.1260, align 4
  %stack.sub.1264 = sub i32 %local.check.owner.end.1259, %local.check.offset.1256
  %descriptor.owner.inside.1262 = icmp ule i32 %local.check.owner.end.1259, %context.value.1261
  %descriptor.offset.inside.1263 = icmp ule i32 %local.check.offset.1256, %local.check.owner.end.1259
  %descriptor.extent.inside.1265 = icmp ule i32 %local.check.extent.1257, %stack.sub.1264
  %descriptor.payload.inside.1266 = icmp ule i32 %local.check.payload.1258, %local.check.extent.1257
  %descriptor.owner.offset.valid.1267 = and i1 %descriptor.owner.inside.1262, %descriptor.offset.inside.1263
  %descriptor.range.inside.1269 = and i1 %descriptor.owner.offset.valid.1267, %descriptor.extent.inside.1265
  %descriptor.range.valid.1268 = and i1 %descriptor.range.inside.1269, %descriptor.payload.inside.1266
  br i1 %descriptor.range.valid.1268, label %descriptor.valid.1270, label %descriptor.invalid.1271
descriptor.invalid.1271:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1270:
  %descriptor.initialized.status.1272 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1256, i32 %local.check.extent.1257)
  %helper.ok.1273 = icmp eq i32 %descriptor.initialized.status.1272, 0
  br i1 %helper.ok.1273, label %helper.continue.1274, label %frame.failure.0
helper.continue.1274:
  br label %local.descriptor.checked.1255
local.descriptor.inactive.1254:
  br label %local.descriptor.checked.1255
local.descriptor.checked.1255:
  %local.is.active.1275 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1275, label %local.descriptor.active.1276, label %local.descriptor.inactive.1277
local.descriptor.active.1276:
  %local.check.offset.1279 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1280 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1281 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1282 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1283 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1284 = load i32, ptr %context.field.1283, align 4
  %stack.sub.1287 = sub i32 %local.check.owner.end.1282, %local.check.offset.1279
  %descriptor.owner.inside.1285 = icmp ule i32 %local.check.owner.end.1282, %context.value.1284
  %descriptor.offset.inside.1286 = icmp ule i32 %local.check.offset.1279, %local.check.owner.end.1282
  %descriptor.extent.inside.1288 = icmp ule i32 %local.check.extent.1280, %stack.sub.1287
  %descriptor.payload.inside.1289 = icmp ule i32 %local.check.payload.1281, %local.check.extent.1280
  %descriptor.owner.offset.valid.1290 = and i1 %descriptor.owner.inside.1285, %descriptor.offset.inside.1286
  %descriptor.range.inside.1292 = and i1 %descriptor.owner.offset.valid.1290, %descriptor.extent.inside.1288
  %descriptor.range.valid.1291 = and i1 %descriptor.range.inside.1292, %descriptor.payload.inside.1289
  br i1 %descriptor.range.valid.1291, label %descriptor.valid.1293, label %descriptor.invalid.1294
descriptor.invalid.1294:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1293:
  %descriptor.initialized.status.1295 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1279, i32 %local.check.extent.1280)
  %helper.ok.1296 = icmp eq i32 %descriptor.initialized.status.1295, 0
  br i1 %helper.ok.1296, label %helper.continue.1297, label %frame.failure.0
helper.continue.1297:
  br label %local.descriptor.checked.1278
local.descriptor.inactive.1277:
  br label %local.descriptor.checked.1278
local.descriptor.checked.1278:
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %descriptor.element.1298 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.1299 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1298, i32 0, i32 0
  store i32 7, ptr %descriptor.field.1299, align 4
  %descriptor.field.1300 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1298, i32 0, i32 1
  store i32 %context.value.1105, ptr %descriptor.field.1300, align 4
  %descriptor.field.1301 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1298, i32 0, i32 2
  store i32 %stack.offset.1103, ptr %descriptor.field.1301, align 4
  %descriptor.field.1302 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1298, i32 0, i32 3
  store i32 %stack.offset.1101, ptr %descriptor.field.1302, align 4
  %descriptor.field.1303 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1298, i32 0, i32 4
  store i32 %stack.offset.1106, ptr %descriptor.field.1303, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 7, i32 %context.value.1105, i32 20, i32 %stack.offset.1101, i32 %stack.offset.1106, i32 %stack.offset.1103)
  %context.field.1304 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1305 = load i32, ptr %context.field.1304, align 4
  %runtime.ok.1306 = icmp eq i32 %context.value.1305, 0
  br i1 %runtime.ok.1306, label %runtime.continue.1307, label %frame.failure.0
runtime.continue.1307:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.21, i32 0, i32 0, i32 0)
  %context.field.1308 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.1309 = load i32, ptr %context.field.1308, align 4
  %context.field.1310 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.1311 = load i32, ptr %context.field.1310, align 4
  %context.field.1312 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.1313 = load i32, ptr %context.field.1312, align 4
  %stack.offset.1314 = add i32 %context.value.23, %context.value.25
  %stack.offset.1315 = add i32 %context.value.1309, %context.value.1311
  %stack.sub.1316 = sub i32 %stack.offset.1314, %stack.offset.1315
  %stack.sub.1317 = sub i32 %context.value.25, %context.value.1311
  %stack.sub.1318 = sub i32 %context.value.1313, %context.value.27
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1316, i32 %stack.sub.1317)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.1318)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0001(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %local.active.2 = alloca i1, align 1
  %local.offset.3 = alloca i32, align 4
  %local.extent.4 = alloca i32, align 4
  %local.payload.5 = alloca i32, align 4
  %local.owner.end.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %local.active.8 = alloca i1, align 1
  %local.offset.9 = alloca i32, align 4
  %local.extent.10 = alloca i32, align 4
  %local.payload.11 = alloca i32, align 4
  %local.owner.end.12 = alloca i32, align 4
  %local.type.13 = alloca i32, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  %local.active.14 = alloca i1, align 1
  %local.offset.15 = alloca i32, align 4
  %local.extent.16 = alloca i32, align 4
  %local.payload.17 = alloca i32, align 4
  %local.owner.end.18 = alloca i32, align 4
  %local.type.19 = alloca i32, align 4
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  %local.active.20 = alloca i1, align 1
  %local.offset.21 = alloca i32, align 4
  %local.extent.22 = alloca i32, align 4
  %local.payload.23 = alloca i32, align 4
  %local.owner.end.24 = alloca i32, align 4
  %local.type.25 = alloca i32, align 4
  store i1 false, ptr %local.active.20, align 1
  store i32 0, ptr %local.offset.21, align 4
  store i32 0, ptr %local.extent.22, align 4
  store i32 0, ptr %local.payload.23, align 4
  store i32 0, ptr %local.owner.end.24, align 4
  store i32 0, ptr %local.type.25, align 4
  %local.active.26 = alloca i1, align 1
  %local.offset.27 = alloca i32, align 4
  %local.extent.28 = alloca i32, align 4
  %local.payload.29 = alloca i32, align 4
  %local.owner.end.30 = alloca i32, align 4
  %local.type.31 = alloca i32, align 4
  store i1 false, ptr %local.active.26, align 1
  store i32 0, ptr %local.offset.27, align 4
  store i32 0, ptr %local.extent.28, align 4
  store i32 0, ptr %local.payload.29, align 4
  store i32 0, ptr %local.owner.end.30, align 4
  store i32 0, ptr %local.type.31, align 4
  %local.active.32 = alloca i1, align 1
  %local.offset.33 = alloca i32, align 4
  %local.extent.34 = alloca i32, align 4
  %local.payload.35 = alloca i32, align 4
  %local.owner.end.36 = alloca i32, align 4
  %local.type.37 = alloca i32, align 4
  store i1 false, ptr %local.active.32, align 1
  store i32 0, ptr %local.offset.33, align 4
  store i32 0, ptr %local.extent.34, align 4
  store i32 0, ptr %local.payload.35, align 4
  store i32 0, ptr %local.owner.end.36, align 4
  store i32 0, ptr %local.type.37, align 4
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %context.field.40 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.41 = load i32, ptr %context.field.40, align 4
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %context.field.44 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.45 = load i32, ptr %context.field.44, align 4
  %frame.entered.46 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.47 = icmp eq i32 %frame.entered.46, 0
  br i1 %frame.enter.ok.47, label %frame.enter.continue.48, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.48:
  %descriptor.element.49 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 0
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 1
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %descriptor.field.54 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 2
  %descriptor.value.55 = load i32, ptr %descriptor.field.54, align 4
  %descriptor.field.56 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 3
  %descriptor.value.57 = load i32, ptr %descriptor.field.56, align 4
  %descriptor.field.58 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 4
  %descriptor.value.59 = load i32, ptr %descriptor.field.58, align 4
  %argument.type.valid.60 = icmp eq i32 %descriptor.value.51, 1
  br i1 %argument.type.valid.60, label %argument.type.ok.61, label %frame.failure.0
argument.type.ok.61:
  %context.field.62 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.63 = load i32, ptr %context.field.62, align 4
  %stack.sub.66 = sub i32 %descriptor.value.59, %descriptor.value.53
  %descriptor.owner.inside.64 = icmp ule i32 %descriptor.value.59, %context.value.63
  %descriptor.offset.inside.65 = icmp ule i32 %descriptor.value.53, %descriptor.value.59
  %descriptor.extent.inside.67 = icmp ule i32 %descriptor.value.55, %stack.sub.66
  %descriptor.payload.inside.68 = icmp ule i32 %descriptor.value.57, %descriptor.value.55
  %descriptor.owner.offset.valid.69 = and i1 %descriptor.owner.inside.64, %descriptor.offset.inside.65
  %descriptor.range.inside.71 = and i1 %descriptor.owner.offset.valid.69, %descriptor.extent.inside.67
  %descriptor.range.valid.70 = and i1 %descriptor.range.inside.71, %descriptor.payload.inside.68
  %descriptor.type.valid.72 = icmp eq i32 1, 1
  %descriptor.valid.73 = and i1 %descriptor.range.valid.70, %descriptor.type.valid.72
  br i1 %descriptor.valid.73, label %descriptor.valid.74, label %descriptor.invalid.75
descriptor.invalid.75:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.74:
  %descriptor.initialized.status.76 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.53, i32 %descriptor.value.55)
  %helper.ok.77 = icmp eq i32 %descriptor.initialized.status.76, 0
  br i1 %helper.ok.77, label %helper.continue.78, label %frame.failure.0
helper.continue.78:
  %descriptor.element.79 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.80 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 0
  %descriptor.value.81 = load i32, ptr %descriptor.field.80, align 4
  %descriptor.field.82 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 1
  %descriptor.value.83 = load i32, ptr %descriptor.field.82, align 4
  %descriptor.field.84 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 2
  %descriptor.value.85 = load i32, ptr %descriptor.field.84, align 4
  %descriptor.field.86 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 3
  %descriptor.value.87 = load i32, ptr %descriptor.field.86, align 4
  %descriptor.field.88 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 4
  %descriptor.value.89 = load i32, ptr %descriptor.field.88, align 4
  %argument.type.valid.90 = icmp eq i32 %descriptor.value.81, 1
  br i1 %argument.type.valid.90, label %argument.type.ok.91, label %frame.failure.0
argument.type.ok.91:
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %stack.sub.96 = sub i32 %descriptor.value.89, %descriptor.value.83
  %descriptor.owner.inside.94 = icmp ule i32 %descriptor.value.89, %context.value.93
  %descriptor.offset.inside.95 = icmp ule i32 %descriptor.value.83, %descriptor.value.89
  %descriptor.extent.inside.97 = icmp ule i32 %descriptor.value.85, %stack.sub.96
  %descriptor.payload.inside.98 = icmp ule i32 %descriptor.value.87, %descriptor.value.85
  %descriptor.owner.offset.valid.99 = and i1 %descriptor.owner.inside.94, %descriptor.offset.inside.95
  %descriptor.range.inside.101 = and i1 %descriptor.owner.offset.valid.99, %descriptor.extent.inside.97
  %descriptor.range.valid.100 = and i1 %descriptor.range.inside.101, %descriptor.payload.inside.98
  %descriptor.type.valid.102 = icmp eq i32 1, 1
  %descriptor.valid.103 = and i1 %descriptor.range.valid.100, %descriptor.type.valid.102
  br i1 %descriptor.valid.103, label %descriptor.valid.104, label %descriptor.invalid.105
descriptor.invalid.105:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.104:
  %descriptor.initialized.status.106 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.83, i32 %descriptor.value.85)
  %helper.ok.107 = icmp eq i32 %descriptor.initialized.status.106, 0
  br i1 %helper.ok.107, label %helper.continue.108, label %frame.failure.0
helper.continue.108:
  %step.status.109 = call i32 @al_owning_charge_step(ptr %ctx, i32 20)
  %helper.ok.110 = icmp eq i32 %step.status.109, 0
  br i1 %helper.ok.110, label %helper.continue.111, label %frame.failure.0
helper.continue.111:
  store i1 true, ptr %local.active.2, align 1
  store i32 %descriptor.value.83, ptr %local.offset.3, align 4
  store i32 %descriptor.value.85, ptr %local.extent.4, align 4
  store i32 %descriptor.value.87, ptr %local.payload.5, align 4
  store i32 %descriptor.value.89, ptr %local.owner.end.6, align 4
  store i32 1, ptr %local.type.7, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %descriptor.value.83, i32 20, i32 %descriptor.value.87, i32 %descriptor.value.89, i32 %descriptor.value.85)
  %context.field.112 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.113 = load i32, ptr %context.field.112, align 4
  %runtime.ok.114 = icmp eq i32 %context.value.113, 0
  br i1 %runtime.ok.114, label %runtime.continue.115, label %frame.failure.0
runtime.continue.115:
  %context.field.116 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.117 = load i32, ptr %context.field.116, align 4
  %stack.sub.120 = sub i32 %descriptor.value.59, %descriptor.value.53
  %descriptor.owner.inside.118 = icmp ule i32 %descriptor.value.59, %context.value.117
  %descriptor.offset.inside.119 = icmp ule i32 %descriptor.value.53, %descriptor.value.59
  %descriptor.extent.inside.121 = icmp ule i32 %descriptor.value.55, %stack.sub.120
  %descriptor.payload.inside.122 = icmp ule i32 %descriptor.value.57, %descriptor.value.55
  %descriptor.owner.offset.valid.123 = and i1 %descriptor.owner.inside.118, %descriptor.offset.inside.119
  %descriptor.range.inside.125 = and i1 %descriptor.owner.offset.valid.123, %descriptor.extent.inside.121
  %descriptor.range.valid.124 = and i1 %descriptor.range.inside.125, %descriptor.payload.inside.122
  %descriptor.type.valid.126 = icmp eq i32 1, 1
  %descriptor.valid.127 = and i1 %descriptor.range.valid.124, %descriptor.type.valid.126
  br i1 %descriptor.valid.127, label %descriptor.valid.128, label %descriptor.invalid.129
descriptor.invalid.129:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.128:
  %descriptor.initialized.status.130 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.53, i32 %descriptor.value.55)
  %helper.ok.131 = icmp eq i32 %descriptor.initialized.status.130, 0
  br i1 %helper.ok.131, label %helper.continue.132, label %frame.failure.0
helper.continue.132:
  %local.is.active.133 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.133, label %local.descriptor.active.134, label %local.descriptor.inactive.135
local.descriptor.active.134:
  %local.check.offset.137 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.138 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.139 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.140 = load i32, ptr %local.owner.end.6, align 4
  %context.field.141 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.142 = load i32, ptr %context.field.141, align 4
  %stack.sub.145 = sub i32 %local.check.owner.end.140, %local.check.offset.137
  %descriptor.owner.inside.143 = icmp ule i32 %local.check.owner.end.140, %context.value.142
  %descriptor.offset.inside.144 = icmp ule i32 %local.check.offset.137, %local.check.owner.end.140
  %descriptor.extent.inside.146 = icmp ule i32 %local.check.extent.138, %stack.sub.145
  %descriptor.payload.inside.147 = icmp ule i32 %local.check.payload.139, %local.check.extent.138
  %descriptor.owner.offset.valid.148 = and i1 %descriptor.owner.inside.143, %descriptor.offset.inside.144
  %descriptor.range.inside.150 = and i1 %descriptor.owner.offset.valid.148, %descriptor.extent.inside.146
  %descriptor.range.valid.149 = and i1 %descriptor.range.inside.150, %descriptor.payload.inside.147
  br i1 %descriptor.range.valid.149, label %descriptor.valid.151, label %descriptor.invalid.152
descriptor.invalid.152:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.151:
  %descriptor.initialized.status.153 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.137, i32 %local.check.extent.138)
  %helper.ok.154 = icmp eq i32 %descriptor.initialized.status.153, 0
  br i1 %helper.ok.154, label %helper.continue.155, label %frame.failure.0
helper.continue.155:
  br label %local.descriptor.checked.136
local.descriptor.inactive.135:
  br label %local.descriptor.checked.136
local.descriptor.checked.136:
  %local.is.active.156 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.156, label %local.descriptor.active.157, label %local.descriptor.inactive.158
local.descriptor.active.157:
  %local.check.offset.160 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.161 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.162 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.163 = load i32, ptr %local.owner.end.12, align 4
  %context.field.164 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.165 = load i32, ptr %context.field.164, align 4
  %stack.sub.168 = sub i32 %local.check.owner.end.163, %local.check.offset.160
  %descriptor.owner.inside.166 = icmp ule i32 %local.check.owner.end.163, %context.value.165
  %descriptor.offset.inside.167 = icmp ule i32 %local.check.offset.160, %local.check.owner.end.163
  %descriptor.extent.inside.169 = icmp ule i32 %local.check.extent.161, %stack.sub.168
  %descriptor.payload.inside.170 = icmp ule i32 %local.check.payload.162, %local.check.extent.161
  %descriptor.owner.offset.valid.171 = and i1 %descriptor.owner.inside.166, %descriptor.offset.inside.167
  %descriptor.range.inside.173 = and i1 %descriptor.owner.offset.valid.171, %descriptor.extent.inside.169
  %descriptor.range.valid.172 = and i1 %descriptor.range.inside.173, %descriptor.payload.inside.170
  br i1 %descriptor.range.valid.172, label %descriptor.valid.174, label %descriptor.invalid.175
descriptor.invalid.175:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.174:
  %descriptor.initialized.status.176 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.160, i32 %local.check.extent.161)
  %helper.ok.177 = icmp eq i32 %descriptor.initialized.status.176, 0
  br i1 %helper.ok.177, label %helper.continue.178, label %frame.failure.0
helper.continue.178:
  br label %local.descriptor.checked.159
local.descriptor.inactive.158:
  br label %local.descriptor.checked.159
local.descriptor.checked.159:
  %local.is.active.179 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.179, label %local.descriptor.active.180, label %local.descriptor.inactive.181
local.descriptor.active.180:
  %local.check.offset.183 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.184 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.185 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.186 = load i32, ptr %local.owner.end.18, align 4
  %context.field.187 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.188 = load i32, ptr %context.field.187, align 4
  %stack.sub.191 = sub i32 %local.check.owner.end.186, %local.check.offset.183
  %descriptor.owner.inside.189 = icmp ule i32 %local.check.owner.end.186, %context.value.188
  %descriptor.offset.inside.190 = icmp ule i32 %local.check.offset.183, %local.check.owner.end.186
  %descriptor.extent.inside.192 = icmp ule i32 %local.check.extent.184, %stack.sub.191
  %descriptor.payload.inside.193 = icmp ule i32 %local.check.payload.185, %local.check.extent.184
  %descriptor.owner.offset.valid.194 = and i1 %descriptor.owner.inside.189, %descriptor.offset.inside.190
  %descriptor.range.inside.196 = and i1 %descriptor.owner.offset.valid.194, %descriptor.extent.inside.192
  %descriptor.range.valid.195 = and i1 %descriptor.range.inside.196, %descriptor.payload.inside.193
  br i1 %descriptor.range.valid.195, label %descriptor.valid.197, label %descriptor.invalid.198
descriptor.invalid.198:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.197:
  %descriptor.initialized.status.199 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.183, i32 %local.check.extent.184)
  %helper.ok.200 = icmp eq i32 %descriptor.initialized.status.199, 0
  br i1 %helper.ok.200, label %helper.continue.201, label %frame.failure.0
helper.continue.201:
  br label %local.descriptor.checked.182
local.descriptor.inactive.181:
  br label %local.descriptor.checked.182
local.descriptor.checked.182:
  %local.is.active.202 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.202, label %local.descriptor.active.203, label %local.descriptor.inactive.204
local.descriptor.active.203:
  %local.check.offset.206 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.207 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.208 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.209 = load i32, ptr %local.owner.end.24, align 4
  %context.field.210 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.211 = load i32, ptr %context.field.210, align 4
  %stack.sub.214 = sub i32 %local.check.owner.end.209, %local.check.offset.206
  %descriptor.owner.inside.212 = icmp ule i32 %local.check.owner.end.209, %context.value.211
  %descriptor.offset.inside.213 = icmp ule i32 %local.check.offset.206, %local.check.owner.end.209
  %descriptor.extent.inside.215 = icmp ule i32 %local.check.extent.207, %stack.sub.214
  %descriptor.payload.inside.216 = icmp ule i32 %local.check.payload.208, %local.check.extent.207
  %descriptor.owner.offset.valid.217 = and i1 %descriptor.owner.inside.212, %descriptor.offset.inside.213
  %descriptor.range.inside.219 = and i1 %descriptor.owner.offset.valid.217, %descriptor.extent.inside.215
  %descriptor.range.valid.218 = and i1 %descriptor.range.inside.219, %descriptor.payload.inside.216
  br i1 %descriptor.range.valid.218, label %descriptor.valid.220, label %descriptor.invalid.221
descriptor.invalid.221:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.220:
  %descriptor.initialized.status.222 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.206, i32 %local.check.extent.207)
  %helper.ok.223 = icmp eq i32 %descriptor.initialized.status.222, 0
  br i1 %helper.ok.223, label %helper.continue.224, label %frame.failure.0
helper.continue.224:
  br label %local.descriptor.checked.205
local.descriptor.inactive.204:
  br label %local.descriptor.checked.205
local.descriptor.checked.205:
  %local.is.active.225 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.225, label %local.descriptor.active.226, label %local.descriptor.inactive.227
local.descriptor.active.226:
  %local.check.offset.229 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.230 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.231 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.232 = load i32, ptr %local.owner.end.30, align 4
  %context.field.233 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.234 = load i32, ptr %context.field.233, align 4
  %stack.sub.237 = sub i32 %local.check.owner.end.232, %local.check.offset.229
  %descriptor.owner.inside.235 = icmp ule i32 %local.check.owner.end.232, %context.value.234
  %descriptor.offset.inside.236 = icmp ule i32 %local.check.offset.229, %local.check.owner.end.232
  %descriptor.extent.inside.238 = icmp ule i32 %local.check.extent.230, %stack.sub.237
  %descriptor.payload.inside.239 = icmp ule i32 %local.check.payload.231, %local.check.extent.230
  %descriptor.owner.offset.valid.240 = and i1 %descriptor.owner.inside.235, %descriptor.offset.inside.236
  %descriptor.range.inside.242 = and i1 %descriptor.owner.offset.valid.240, %descriptor.extent.inside.238
  %descriptor.range.valid.241 = and i1 %descriptor.range.inside.242, %descriptor.payload.inside.239
  br i1 %descriptor.range.valid.241, label %descriptor.valid.243, label %descriptor.invalid.244
descriptor.invalid.244:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.243:
  %descriptor.initialized.status.245 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.229, i32 %local.check.extent.230)
  %helper.ok.246 = icmp eq i32 %descriptor.initialized.status.245, 0
  br i1 %helper.ok.246, label %helper.continue.247, label %frame.failure.0
helper.continue.247:
  br label %local.descriptor.checked.228
local.descriptor.inactive.227:
  br label %local.descriptor.checked.228
local.descriptor.checked.228:
  %local.is.active.248 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.248, label %local.descriptor.active.249, label %local.descriptor.inactive.250
local.descriptor.active.249:
  %local.check.offset.252 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.253 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.254 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.255 = load i32, ptr %local.owner.end.36, align 4
  %context.field.256 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.257 = load i32, ptr %context.field.256, align 4
  %stack.sub.260 = sub i32 %local.check.owner.end.255, %local.check.offset.252
  %descriptor.owner.inside.258 = icmp ule i32 %local.check.owner.end.255, %context.value.257
  %descriptor.offset.inside.259 = icmp ule i32 %local.check.offset.252, %local.check.owner.end.255
  %descriptor.extent.inside.261 = icmp ule i32 %local.check.extent.253, %stack.sub.260
  %descriptor.payload.inside.262 = icmp ule i32 %local.check.payload.254, %local.check.extent.253
  %descriptor.owner.offset.valid.263 = and i1 %descriptor.owner.inside.258, %descriptor.offset.inside.259
  %descriptor.range.inside.265 = and i1 %descriptor.owner.offset.valid.263, %descriptor.extent.inside.261
  %descriptor.range.valid.264 = and i1 %descriptor.range.inside.265, %descriptor.payload.inside.262
  br i1 %descriptor.range.valid.264, label %descriptor.valid.266, label %descriptor.invalid.267
descriptor.invalid.267:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.266:
  %descriptor.initialized.status.268 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.252, i32 %local.check.extent.253)
  %helper.ok.269 = icmp eq i32 %descriptor.initialized.status.268, 0
  br i1 %helper.ok.269, label %helper.continue.270, label %frame.failure.0
helper.continue.270:
  br label %local.descriptor.checked.251
local.descriptor.inactive.250:
  br label %local.descriptor.checked.251
local.descriptor.checked.251:
  %step.status.271 = call i32 @al_owning_charge_step(ptr %ctx, i32 21)
  %helper.ok.272 = icmp eq i32 %step.status.271, 0
  br i1 %helper.ok.272, label %helper.continue.273, label %frame.failure.0
helper.continue.273:
  store i1 true, ptr %local.active.8, align 1
  store i32 %descriptor.value.53, ptr %local.offset.9, align 4
  store i32 %descriptor.value.55, ptr %local.extent.10, align 4
  store i32 %descriptor.value.57, ptr %local.payload.11, align 4
  store i32 %descriptor.value.59, ptr %local.owner.end.12, align 4
  store i32 1, ptr %local.type.13, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %descriptor.value.53, i32 20, i32 %descriptor.value.57, i32 %descriptor.value.59, i32 %descriptor.value.55)
  %context.field.274 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.275 = load i32, ptr %context.field.274, align 4
  %runtime.ok.276 = icmp eq i32 %context.value.275, 0
  br i1 %runtime.ok.276, label %runtime.continue.277, label %frame.failure.0
runtime.continue.277:
  %local.is.active.278 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.278, label %local.descriptor.active.279, label %local.descriptor.inactive.280
local.descriptor.active.279:
  %local.check.offset.282 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.283 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.284 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.285 = load i32, ptr %local.owner.end.6, align 4
  %context.field.286 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.287 = load i32, ptr %context.field.286, align 4
  %stack.sub.290 = sub i32 %local.check.owner.end.285, %local.check.offset.282
  %descriptor.owner.inside.288 = icmp ule i32 %local.check.owner.end.285, %context.value.287
  %descriptor.offset.inside.289 = icmp ule i32 %local.check.offset.282, %local.check.owner.end.285
  %descriptor.extent.inside.291 = icmp ule i32 %local.check.extent.283, %stack.sub.290
  %descriptor.payload.inside.292 = icmp ule i32 %local.check.payload.284, %local.check.extent.283
  %descriptor.owner.offset.valid.293 = and i1 %descriptor.owner.inside.288, %descriptor.offset.inside.289
  %descriptor.range.inside.295 = and i1 %descriptor.owner.offset.valid.293, %descriptor.extent.inside.291
  %descriptor.range.valid.294 = and i1 %descriptor.range.inside.295, %descriptor.payload.inside.292
  br i1 %descriptor.range.valid.294, label %descriptor.valid.296, label %descriptor.invalid.297
descriptor.invalid.297:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.296:
  %descriptor.initialized.status.298 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.282, i32 %local.check.extent.283)
  %helper.ok.299 = icmp eq i32 %descriptor.initialized.status.298, 0
  br i1 %helper.ok.299, label %helper.continue.300, label %frame.failure.0
helper.continue.300:
  br label %local.descriptor.checked.281
local.descriptor.inactive.280:
  br label %local.descriptor.checked.281
local.descriptor.checked.281:
  %local.is.active.301 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.301, label %local.descriptor.active.302, label %local.descriptor.inactive.303
local.descriptor.active.302:
  %local.check.offset.305 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.306 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.307 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.308 = load i32, ptr %local.owner.end.12, align 4
  %context.field.309 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.310 = load i32, ptr %context.field.309, align 4
  %stack.sub.313 = sub i32 %local.check.owner.end.308, %local.check.offset.305
  %descriptor.owner.inside.311 = icmp ule i32 %local.check.owner.end.308, %context.value.310
  %descriptor.offset.inside.312 = icmp ule i32 %local.check.offset.305, %local.check.owner.end.308
  %descriptor.extent.inside.314 = icmp ule i32 %local.check.extent.306, %stack.sub.313
  %descriptor.payload.inside.315 = icmp ule i32 %local.check.payload.307, %local.check.extent.306
  %descriptor.owner.offset.valid.316 = and i1 %descriptor.owner.inside.311, %descriptor.offset.inside.312
  %descriptor.range.inside.318 = and i1 %descriptor.owner.offset.valid.316, %descriptor.extent.inside.314
  %descriptor.range.valid.317 = and i1 %descriptor.range.inside.318, %descriptor.payload.inside.315
  br i1 %descriptor.range.valid.317, label %descriptor.valid.319, label %descriptor.invalid.320
descriptor.invalid.320:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.319:
  %descriptor.initialized.status.321 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.305, i32 %local.check.extent.306)
  %helper.ok.322 = icmp eq i32 %descriptor.initialized.status.321, 0
  br i1 %helper.ok.322, label %helper.continue.323, label %frame.failure.0
helper.continue.323:
  br label %local.descriptor.checked.304
local.descriptor.inactive.303:
  br label %local.descriptor.checked.304
local.descriptor.checked.304:
  %local.is.active.324 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.324, label %local.descriptor.active.325, label %local.descriptor.inactive.326
local.descriptor.active.325:
  %local.check.offset.328 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.329 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.330 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.331 = load i32, ptr %local.owner.end.18, align 4
  %context.field.332 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.333 = load i32, ptr %context.field.332, align 4
  %stack.sub.336 = sub i32 %local.check.owner.end.331, %local.check.offset.328
  %descriptor.owner.inside.334 = icmp ule i32 %local.check.owner.end.331, %context.value.333
  %descriptor.offset.inside.335 = icmp ule i32 %local.check.offset.328, %local.check.owner.end.331
  %descriptor.extent.inside.337 = icmp ule i32 %local.check.extent.329, %stack.sub.336
  %descriptor.payload.inside.338 = icmp ule i32 %local.check.payload.330, %local.check.extent.329
  %descriptor.owner.offset.valid.339 = and i1 %descriptor.owner.inside.334, %descriptor.offset.inside.335
  %descriptor.range.inside.341 = and i1 %descriptor.owner.offset.valid.339, %descriptor.extent.inside.337
  %descriptor.range.valid.340 = and i1 %descriptor.range.inside.341, %descriptor.payload.inside.338
  br i1 %descriptor.range.valid.340, label %descriptor.valid.342, label %descriptor.invalid.343
descriptor.invalid.343:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.342:
  %descriptor.initialized.status.344 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.328, i32 %local.check.extent.329)
  %helper.ok.345 = icmp eq i32 %descriptor.initialized.status.344, 0
  br i1 %helper.ok.345, label %helper.continue.346, label %frame.failure.0
helper.continue.346:
  br label %local.descriptor.checked.327
local.descriptor.inactive.326:
  br label %local.descriptor.checked.327
local.descriptor.checked.327:
  %local.is.active.347 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.347, label %local.descriptor.active.348, label %local.descriptor.inactive.349
local.descriptor.active.348:
  %local.check.offset.351 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.352 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.353 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.354 = load i32, ptr %local.owner.end.24, align 4
  %context.field.355 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.356 = load i32, ptr %context.field.355, align 4
  %stack.sub.359 = sub i32 %local.check.owner.end.354, %local.check.offset.351
  %descriptor.owner.inside.357 = icmp ule i32 %local.check.owner.end.354, %context.value.356
  %descriptor.offset.inside.358 = icmp ule i32 %local.check.offset.351, %local.check.owner.end.354
  %descriptor.extent.inside.360 = icmp ule i32 %local.check.extent.352, %stack.sub.359
  %descriptor.payload.inside.361 = icmp ule i32 %local.check.payload.353, %local.check.extent.352
  %descriptor.owner.offset.valid.362 = and i1 %descriptor.owner.inside.357, %descriptor.offset.inside.358
  %descriptor.range.inside.364 = and i1 %descriptor.owner.offset.valid.362, %descriptor.extent.inside.360
  %descriptor.range.valid.363 = and i1 %descriptor.range.inside.364, %descriptor.payload.inside.361
  br i1 %descriptor.range.valid.363, label %descriptor.valid.365, label %descriptor.invalid.366
descriptor.invalid.366:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.365:
  %descriptor.initialized.status.367 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.351, i32 %local.check.extent.352)
  %helper.ok.368 = icmp eq i32 %descriptor.initialized.status.367, 0
  br i1 %helper.ok.368, label %helper.continue.369, label %frame.failure.0
helper.continue.369:
  br label %local.descriptor.checked.350
local.descriptor.inactive.349:
  br label %local.descriptor.checked.350
local.descriptor.checked.350:
  %local.is.active.370 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.370, label %local.descriptor.active.371, label %local.descriptor.inactive.372
local.descriptor.active.371:
  %local.check.offset.374 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.375 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.376 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.377 = load i32, ptr %local.owner.end.30, align 4
  %context.field.378 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.379 = load i32, ptr %context.field.378, align 4
  %stack.sub.382 = sub i32 %local.check.owner.end.377, %local.check.offset.374
  %descriptor.owner.inside.380 = icmp ule i32 %local.check.owner.end.377, %context.value.379
  %descriptor.offset.inside.381 = icmp ule i32 %local.check.offset.374, %local.check.owner.end.377
  %descriptor.extent.inside.383 = icmp ule i32 %local.check.extent.375, %stack.sub.382
  %descriptor.payload.inside.384 = icmp ule i32 %local.check.payload.376, %local.check.extent.375
  %descriptor.owner.offset.valid.385 = and i1 %descriptor.owner.inside.380, %descriptor.offset.inside.381
  %descriptor.range.inside.387 = and i1 %descriptor.owner.offset.valid.385, %descriptor.extent.inside.383
  %descriptor.range.valid.386 = and i1 %descriptor.range.inside.387, %descriptor.payload.inside.384
  br i1 %descriptor.range.valid.386, label %descriptor.valid.388, label %descriptor.invalid.389
descriptor.invalid.389:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.388:
  %descriptor.initialized.status.390 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.374, i32 %local.check.extent.375)
  %helper.ok.391 = icmp eq i32 %descriptor.initialized.status.390, 0
  br i1 %helper.ok.391, label %helper.continue.392, label %frame.failure.0
helper.continue.392:
  br label %local.descriptor.checked.373
local.descriptor.inactive.372:
  br label %local.descriptor.checked.373
local.descriptor.checked.373:
  %local.is.active.393 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.393, label %local.descriptor.active.394, label %local.descriptor.inactive.395
local.descriptor.active.394:
  %local.check.offset.397 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.398 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.399 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.400 = load i32, ptr %local.owner.end.36, align 4
  %context.field.401 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.402 = load i32, ptr %context.field.401, align 4
  %stack.sub.405 = sub i32 %local.check.owner.end.400, %local.check.offset.397
  %descriptor.owner.inside.403 = icmp ule i32 %local.check.owner.end.400, %context.value.402
  %descriptor.offset.inside.404 = icmp ule i32 %local.check.offset.397, %local.check.owner.end.400
  %descriptor.extent.inside.406 = icmp ule i32 %local.check.extent.398, %stack.sub.405
  %descriptor.payload.inside.407 = icmp ule i32 %local.check.payload.399, %local.check.extent.398
  %descriptor.owner.offset.valid.408 = and i1 %descriptor.owner.inside.403, %descriptor.offset.inside.404
  %descriptor.range.inside.410 = and i1 %descriptor.owner.offset.valid.408, %descriptor.extent.inside.406
  %descriptor.range.valid.409 = and i1 %descriptor.range.inside.410, %descriptor.payload.inside.407
  br i1 %descriptor.range.valid.409, label %descriptor.valid.411, label %descriptor.invalid.412
descriptor.invalid.412:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.411:
  %descriptor.initialized.status.413 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.397, i32 %local.check.extent.398)
  %helper.ok.414 = icmp eq i32 %descriptor.initialized.status.413, 0
  br i1 %helper.ok.414, label %helper.continue.415, label %frame.failure.0
helper.continue.415:
  br label %local.descriptor.checked.396
local.descriptor.inactive.395:
  br label %local.descriptor.checked.396
local.descriptor.checked.396:
  %step.status.416 = call i32 @al_owning_charge_step(ptr %ctx, i32 22)
  %helper.ok.417 = icmp eq i32 %step.status.416, 0
  br i1 %helper.ok.417, label %helper.continue.418, label %frame.failure.0
helper.continue.418:
  %context.field.419 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.420 = load i32, ptr %context.field.419, align 4
  store i1 false, ptr %local.active.20, align 1
  store i32 0, ptr %local.offset.21, align 4
  store i32 0, ptr %local.extent.22, align 4
  store i32 0, ptr %local.payload.23, align 4
  store i32 0, ptr %local.owner.end.24, align 4
  store i32 0, ptr %local.type.25, align 4
  %step.status.421 = call i32 @al_owning_charge_step(ptr %ctx, i32 23)
  %helper.ok.422 = icmp eq i32 %step.status.421, 0
  br i1 %helper.ok.422, label %helper.continue.423, label %frame.failure.0
helper.continue.423:
  %local.resolved.offset.424 = load i32, ptr %local.offset.9, align 4
  %local.resolved.extent.425 = load i32, ptr %local.extent.10, align 4
  %local.resolved.payload.426 = load i32, ptr %local.payload.11, align 4
  %local.resolved.owner.end.427 = load i32, ptr %local.owner.end.12, align 4
  %context.field.428 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.429 = load i32, ptr %context.field.428, align 4
  %stack.sub.432 = sub i32 %local.resolved.owner.end.427, %local.resolved.offset.424
  %descriptor.owner.inside.430 = icmp ule i32 %local.resolved.owner.end.427, %context.value.429
  %descriptor.offset.inside.431 = icmp ule i32 %local.resolved.offset.424, %local.resolved.owner.end.427
  %descriptor.extent.inside.433 = icmp ule i32 %local.resolved.extent.425, %stack.sub.432
  %descriptor.payload.inside.434 = icmp ule i32 %local.resolved.payload.426, %local.resolved.extent.425
  %descriptor.owner.offset.valid.435 = and i1 %descriptor.owner.inside.430, %descriptor.offset.inside.431
  %descriptor.range.inside.437 = and i1 %descriptor.owner.offset.valid.435, %descriptor.extent.inside.433
  %descriptor.range.valid.436 = and i1 %descriptor.range.inside.437, %descriptor.payload.inside.434
  %descriptor.type.valid.438 = icmp eq i32 1, 1
  %descriptor.valid.439 = and i1 %descriptor.range.valid.436, %descriptor.type.valid.438
  br i1 %descriptor.valid.439, label %descriptor.valid.440, label %descriptor.invalid.441
descriptor.invalid.441:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.440:
  %descriptor.initialized.status.442 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.424, i32 %local.resolved.extent.425)
  %helper.ok.443 = icmp eq i32 %descriptor.initialized.status.442, 0
  br i1 %helper.ok.443, label %helper.continue.444, label %frame.failure.0
helper.continue.444:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %local.resolved.offset.424, i32 20, i32 %local.resolved.payload.426, i32 %local.resolved.owner.end.427, i32 %local.resolved.extent.425)
  %context.field.445 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.446 = load i32, ptr %context.field.445, align 4
  %runtime.ok.447 = icmp eq i32 %context.value.446, 0
  br i1 %runtime.ok.447, label %runtime.continue.448, label %frame.failure.0
runtime.continue.448:
  %context.field.449 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.450 = load i32, ptr %context.field.449, align 4
  %stack.sub.453 = sub i32 %local.resolved.owner.end.427, %local.resolved.offset.424
  %descriptor.owner.inside.451 = icmp ule i32 %local.resolved.owner.end.427, %context.value.450
  %descriptor.offset.inside.452 = icmp ule i32 %local.resolved.offset.424, %local.resolved.owner.end.427
  %descriptor.extent.inside.454 = icmp ule i32 %local.resolved.extent.425, %stack.sub.453
  %descriptor.payload.inside.455 = icmp ule i32 %local.resolved.payload.426, %local.resolved.extent.425
  %descriptor.owner.offset.valid.456 = and i1 %descriptor.owner.inside.451, %descriptor.offset.inside.452
  %descriptor.range.inside.458 = and i1 %descriptor.owner.offset.valid.456, %descriptor.extent.inside.454
  %descriptor.range.valid.457 = and i1 %descriptor.range.inside.458, %descriptor.payload.inside.455
  %descriptor.type.valid.459 = icmp eq i32 1, 1
  %descriptor.valid.460 = and i1 %descriptor.range.valid.457, %descriptor.type.valid.459
  br i1 %descriptor.valid.460, label %descriptor.valid.461, label %descriptor.invalid.462
descriptor.invalid.462:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.461:
  %descriptor.initialized.status.463 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.424, i32 %local.resolved.extent.425)
  %helper.ok.464 = icmp eq i32 %descriptor.initialized.status.463, 0
  br i1 %helper.ok.464, label %helper.continue.465, label %frame.failure.0
helper.continue.465:
  %local.is.active.466 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.466, label %local.descriptor.active.467, label %local.descriptor.inactive.468
local.descriptor.active.467:
  %local.check.offset.470 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.471 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.472 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.473 = load i32, ptr %local.owner.end.6, align 4
  %context.field.474 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.475 = load i32, ptr %context.field.474, align 4
  %stack.sub.478 = sub i32 %local.check.owner.end.473, %local.check.offset.470
  %descriptor.owner.inside.476 = icmp ule i32 %local.check.owner.end.473, %context.value.475
  %descriptor.offset.inside.477 = icmp ule i32 %local.check.offset.470, %local.check.owner.end.473
  %descriptor.extent.inside.479 = icmp ule i32 %local.check.extent.471, %stack.sub.478
  %descriptor.payload.inside.480 = icmp ule i32 %local.check.payload.472, %local.check.extent.471
  %descriptor.owner.offset.valid.481 = and i1 %descriptor.owner.inside.476, %descriptor.offset.inside.477
  %descriptor.range.inside.483 = and i1 %descriptor.owner.offset.valid.481, %descriptor.extent.inside.479
  %descriptor.range.valid.482 = and i1 %descriptor.range.inside.483, %descriptor.payload.inside.480
  br i1 %descriptor.range.valid.482, label %descriptor.valid.484, label %descriptor.invalid.485
descriptor.invalid.485:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.484:
  %descriptor.initialized.status.486 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.470, i32 %local.check.extent.471)
  %helper.ok.487 = icmp eq i32 %descriptor.initialized.status.486, 0
  br i1 %helper.ok.487, label %helper.continue.488, label %frame.failure.0
helper.continue.488:
  br label %local.descriptor.checked.469
local.descriptor.inactive.468:
  br label %local.descriptor.checked.469
local.descriptor.checked.469:
  %local.is.active.489 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.489, label %local.descriptor.active.490, label %local.descriptor.inactive.491
local.descriptor.active.490:
  %local.check.offset.493 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.494 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.495 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.496 = load i32, ptr %local.owner.end.12, align 4
  %context.field.497 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.498 = load i32, ptr %context.field.497, align 4
  %stack.sub.501 = sub i32 %local.check.owner.end.496, %local.check.offset.493
  %descriptor.owner.inside.499 = icmp ule i32 %local.check.owner.end.496, %context.value.498
  %descriptor.offset.inside.500 = icmp ule i32 %local.check.offset.493, %local.check.owner.end.496
  %descriptor.extent.inside.502 = icmp ule i32 %local.check.extent.494, %stack.sub.501
  %descriptor.payload.inside.503 = icmp ule i32 %local.check.payload.495, %local.check.extent.494
  %descriptor.owner.offset.valid.504 = and i1 %descriptor.owner.inside.499, %descriptor.offset.inside.500
  %descriptor.range.inside.506 = and i1 %descriptor.owner.offset.valid.504, %descriptor.extent.inside.502
  %descriptor.range.valid.505 = and i1 %descriptor.range.inside.506, %descriptor.payload.inside.503
  br i1 %descriptor.range.valid.505, label %descriptor.valid.507, label %descriptor.invalid.508
descriptor.invalid.508:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.507:
  %descriptor.initialized.status.509 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.493, i32 %local.check.extent.494)
  %helper.ok.510 = icmp eq i32 %descriptor.initialized.status.509, 0
  br i1 %helper.ok.510, label %helper.continue.511, label %frame.failure.0
helper.continue.511:
  br label %local.descriptor.checked.492
local.descriptor.inactive.491:
  br label %local.descriptor.checked.492
local.descriptor.checked.492:
  %local.is.active.512 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.512, label %local.descriptor.active.513, label %local.descriptor.inactive.514
local.descriptor.active.513:
  %local.check.offset.516 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.517 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.518 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.519 = load i32, ptr %local.owner.end.18, align 4
  %context.field.520 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.521 = load i32, ptr %context.field.520, align 4
  %stack.sub.524 = sub i32 %local.check.owner.end.519, %local.check.offset.516
  %descriptor.owner.inside.522 = icmp ule i32 %local.check.owner.end.519, %context.value.521
  %descriptor.offset.inside.523 = icmp ule i32 %local.check.offset.516, %local.check.owner.end.519
  %descriptor.extent.inside.525 = icmp ule i32 %local.check.extent.517, %stack.sub.524
  %descriptor.payload.inside.526 = icmp ule i32 %local.check.payload.518, %local.check.extent.517
  %descriptor.owner.offset.valid.527 = and i1 %descriptor.owner.inside.522, %descriptor.offset.inside.523
  %descriptor.range.inside.529 = and i1 %descriptor.owner.offset.valid.527, %descriptor.extent.inside.525
  %descriptor.range.valid.528 = and i1 %descriptor.range.inside.529, %descriptor.payload.inside.526
  br i1 %descriptor.range.valid.528, label %descriptor.valid.530, label %descriptor.invalid.531
descriptor.invalid.531:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.530:
  %descriptor.initialized.status.532 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.516, i32 %local.check.extent.517)
  %helper.ok.533 = icmp eq i32 %descriptor.initialized.status.532, 0
  br i1 %helper.ok.533, label %helper.continue.534, label %frame.failure.0
helper.continue.534:
  br label %local.descriptor.checked.515
local.descriptor.inactive.514:
  br label %local.descriptor.checked.515
local.descriptor.checked.515:
  %local.is.active.535 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.535, label %local.descriptor.active.536, label %local.descriptor.inactive.537
local.descriptor.active.536:
  %local.check.offset.539 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.540 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.541 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.542 = load i32, ptr %local.owner.end.24, align 4
  %context.field.543 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.544 = load i32, ptr %context.field.543, align 4
  %stack.sub.547 = sub i32 %local.check.owner.end.542, %local.check.offset.539
  %descriptor.owner.inside.545 = icmp ule i32 %local.check.owner.end.542, %context.value.544
  %descriptor.offset.inside.546 = icmp ule i32 %local.check.offset.539, %local.check.owner.end.542
  %descriptor.extent.inside.548 = icmp ule i32 %local.check.extent.540, %stack.sub.547
  %descriptor.payload.inside.549 = icmp ule i32 %local.check.payload.541, %local.check.extent.540
  %descriptor.owner.offset.valid.550 = and i1 %descriptor.owner.inside.545, %descriptor.offset.inside.546
  %descriptor.range.inside.552 = and i1 %descriptor.owner.offset.valid.550, %descriptor.extent.inside.548
  %descriptor.range.valid.551 = and i1 %descriptor.range.inside.552, %descriptor.payload.inside.549
  br i1 %descriptor.range.valid.551, label %descriptor.valid.553, label %descriptor.invalid.554
descriptor.invalid.554:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.553:
  %descriptor.initialized.status.555 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.539, i32 %local.check.extent.540)
  %helper.ok.556 = icmp eq i32 %descriptor.initialized.status.555, 0
  br i1 %helper.ok.556, label %helper.continue.557, label %frame.failure.0
helper.continue.557:
  br label %local.descriptor.checked.538
local.descriptor.inactive.537:
  br label %local.descriptor.checked.538
local.descriptor.checked.538:
  %local.is.active.558 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.558, label %local.descriptor.active.559, label %local.descriptor.inactive.560
local.descriptor.active.559:
  %local.check.offset.562 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.563 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.564 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.565 = load i32, ptr %local.owner.end.30, align 4
  %context.field.566 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.567 = load i32, ptr %context.field.566, align 4
  %stack.sub.570 = sub i32 %local.check.owner.end.565, %local.check.offset.562
  %descriptor.owner.inside.568 = icmp ule i32 %local.check.owner.end.565, %context.value.567
  %descriptor.offset.inside.569 = icmp ule i32 %local.check.offset.562, %local.check.owner.end.565
  %descriptor.extent.inside.571 = icmp ule i32 %local.check.extent.563, %stack.sub.570
  %descriptor.payload.inside.572 = icmp ule i32 %local.check.payload.564, %local.check.extent.563
  %descriptor.owner.offset.valid.573 = and i1 %descriptor.owner.inside.568, %descriptor.offset.inside.569
  %descriptor.range.inside.575 = and i1 %descriptor.owner.offset.valid.573, %descriptor.extent.inside.571
  %descriptor.range.valid.574 = and i1 %descriptor.range.inside.575, %descriptor.payload.inside.572
  br i1 %descriptor.range.valid.574, label %descriptor.valid.576, label %descriptor.invalid.577
descriptor.invalid.577:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.576:
  %descriptor.initialized.status.578 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.562, i32 %local.check.extent.563)
  %helper.ok.579 = icmp eq i32 %descriptor.initialized.status.578, 0
  br i1 %helper.ok.579, label %helper.continue.580, label %frame.failure.0
helper.continue.580:
  br label %local.descriptor.checked.561
local.descriptor.inactive.560:
  br label %local.descriptor.checked.561
local.descriptor.checked.561:
  %local.is.active.581 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.581, label %local.descriptor.active.582, label %local.descriptor.inactive.583
local.descriptor.active.582:
  %local.check.offset.585 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.586 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.587 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.588 = load i32, ptr %local.owner.end.36, align 4
  %context.field.589 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.590 = load i32, ptr %context.field.589, align 4
  %stack.sub.593 = sub i32 %local.check.owner.end.588, %local.check.offset.585
  %descriptor.owner.inside.591 = icmp ule i32 %local.check.owner.end.588, %context.value.590
  %descriptor.offset.inside.592 = icmp ule i32 %local.check.offset.585, %local.check.owner.end.588
  %descriptor.extent.inside.594 = icmp ule i32 %local.check.extent.586, %stack.sub.593
  %descriptor.payload.inside.595 = icmp ule i32 %local.check.payload.587, %local.check.extent.586
  %descriptor.owner.offset.valid.596 = and i1 %descriptor.owner.inside.591, %descriptor.offset.inside.592
  %descriptor.range.inside.598 = and i1 %descriptor.owner.offset.valid.596, %descriptor.extent.inside.594
  %descriptor.range.valid.597 = and i1 %descriptor.range.inside.598, %descriptor.payload.inside.595
  br i1 %descriptor.range.valid.597, label %descriptor.valid.599, label %descriptor.invalid.600
descriptor.invalid.600:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.599:
  %descriptor.initialized.status.601 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.585, i32 %local.check.extent.586)
  %helper.ok.602 = icmp eq i32 %descriptor.initialized.status.601, 0
  br i1 %helper.ok.602, label %helper.continue.603, label %frame.failure.0
helper.continue.603:
  br label %local.descriptor.checked.584
local.descriptor.inactive.583:
  br label %local.descriptor.checked.584
local.descriptor.checked.584:
  %step.status.604 = call i32 @al_owning_charge_step(ptr %ctx, i32 24)
  %helper.ok.605 = icmp eq i32 %step.status.604, 0
  br i1 %helper.ok.605, label %helper.continue.606, label %frame.failure.0
helper.continue.606:
  store i1 true, ptr %local.active.20, align 1
  store i32 %local.resolved.offset.424, ptr %local.offset.21, align 4
  store i32 %local.resolved.extent.425, ptr %local.extent.22, align 4
  store i32 %local.resolved.payload.426, ptr %local.payload.23, align 4
  store i32 %local.resolved.owner.end.427, ptr %local.owner.end.24, align 4
  store i32 1, ptr %local.type.25, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %local.resolved.offset.424, i32 20, i32 %local.resolved.payload.426, i32 %local.resolved.owner.end.427, i32 %local.resolved.extent.425)
  %context.field.607 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.608 = load i32, ptr %context.field.607, align 4
  %runtime.ok.609 = icmp eq i32 %context.value.608, 0
  br i1 %runtime.ok.609, label %runtime.continue.610, label %frame.failure.0
runtime.continue.610:
  %local.is.active.611 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.611, label %local.descriptor.active.612, label %local.descriptor.inactive.613
local.descriptor.active.612:
  %local.check.offset.615 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.616 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.617 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.618 = load i32, ptr %local.owner.end.6, align 4
  %context.field.619 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.620 = load i32, ptr %context.field.619, align 4
  %stack.sub.623 = sub i32 %local.check.owner.end.618, %local.check.offset.615
  %descriptor.owner.inside.621 = icmp ule i32 %local.check.owner.end.618, %context.value.620
  %descriptor.offset.inside.622 = icmp ule i32 %local.check.offset.615, %local.check.owner.end.618
  %descriptor.extent.inside.624 = icmp ule i32 %local.check.extent.616, %stack.sub.623
  %descriptor.payload.inside.625 = icmp ule i32 %local.check.payload.617, %local.check.extent.616
  %descriptor.owner.offset.valid.626 = and i1 %descriptor.owner.inside.621, %descriptor.offset.inside.622
  %descriptor.range.inside.628 = and i1 %descriptor.owner.offset.valid.626, %descriptor.extent.inside.624
  %descriptor.range.valid.627 = and i1 %descriptor.range.inside.628, %descriptor.payload.inside.625
  br i1 %descriptor.range.valid.627, label %descriptor.valid.629, label %descriptor.invalid.630
descriptor.invalid.630:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.629:
  %descriptor.initialized.status.631 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.615, i32 %local.check.extent.616)
  %helper.ok.632 = icmp eq i32 %descriptor.initialized.status.631, 0
  br i1 %helper.ok.632, label %helper.continue.633, label %frame.failure.0
helper.continue.633:
  br label %local.descriptor.checked.614
local.descriptor.inactive.613:
  br label %local.descriptor.checked.614
local.descriptor.checked.614:
  %local.is.active.634 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.634, label %local.descriptor.active.635, label %local.descriptor.inactive.636
local.descriptor.active.635:
  %local.check.offset.638 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.639 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.640 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.641 = load i32, ptr %local.owner.end.12, align 4
  %context.field.642 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.643 = load i32, ptr %context.field.642, align 4
  %stack.sub.646 = sub i32 %local.check.owner.end.641, %local.check.offset.638
  %descriptor.owner.inside.644 = icmp ule i32 %local.check.owner.end.641, %context.value.643
  %descriptor.offset.inside.645 = icmp ule i32 %local.check.offset.638, %local.check.owner.end.641
  %descriptor.extent.inside.647 = icmp ule i32 %local.check.extent.639, %stack.sub.646
  %descriptor.payload.inside.648 = icmp ule i32 %local.check.payload.640, %local.check.extent.639
  %descriptor.owner.offset.valid.649 = and i1 %descriptor.owner.inside.644, %descriptor.offset.inside.645
  %descriptor.range.inside.651 = and i1 %descriptor.owner.offset.valid.649, %descriptor.extent.inside.647
  %descriptor.range.valid.650 = and i1 %descriptor.range.inside.651, %descriptor.payload.inside.648
  br i1 %descriptor.range.valid.650, label %descriptor.valid.652, label %descriptor.invalid.653
descriptor.invalid.653:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.652:
  %descriptor.initialized.status.654 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.638, i32 %local.check.extent.639)
  %helper.ok.655 = icmp eq i32 %descriptor.initialized.status.654, 0
  br i1 %helper.ok.655, label %helper.continue.656, label %frame.failure.0
helper.continue.656:
  br label %local.descriptor.checked.637
local.descriptor.inactive.636:
  br label %local.descriptor.checked.637
local.descriptor.checked.637:
  %local.is.active.657 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.657, label %local.descriptor.active.658, label %local.descriptor.inactive.659
local.descriptor.active.658:
  %local.check.offset.661 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.662 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.663 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.664 = load i32, ptr %local.owner.end.18, align 4
  %context.field.665 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.666 = load i32, ptr %context.field.665, align 4
  %stack.sub.669 = sub i32 %local.check.owner.end.664, %local.check.offset.661
  %descriptor.owner.inside.667 = icmp ule i32 %local.check.owner.end.664, %context.value.666
  %descriptor.offset.inside.668 = icmp ule i32 %local.check.offset.661, %local.check.owner.end.664
  %descriptor.extent.inside.670 = icmp ule i32 %local.check.extent.662, %stack.sub.669
  %descriptor.payload.inside.671 = icmp ule i32 %local.check.payload.663, %local.check.extent.662
  %descriptor.owner.offset.valid.672 = and i1 %descriptor.owner.inside.667, %descriptor.offset.inside.668
  %descriptor.range.inside.674 = and i1 %descriptor.owner.offset.valid.672, %descriptor.extent.inside.670
  %descriptor.range.valid.673 = and i1 %descriptor.range.inside.674, %descriptor.payload.inside.671
  br i1 %descriptor.range.valid.673, label %descriptor.valid.675, label %descriptor.invalid.676
descriptor.invalid.676:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.675:
  %descriptor.initialized.status.677 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.661, i32 %local.check.extent.662)
  %helper.ok.678 = icmp eq i32 %descriptor.initialized.status.677, 0
  br i1 %helper.ok.678, label %helper.continue.679, label %frame.failure.0
helper.continue.679:
  br label %local.descriptor.checked.660
local.descriptor.inactive.659:
  br label %local.descriptor.checked.660
local.descriptor.checked.660:
  %local.is.active.680 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.680, label %local.descriptor.active.681, label %local.descriptor.inactive.682
local.descriptor.active.681:
  %local.check.offset.684 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.685 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.686 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.687 = load i32, ptr %local.owner.end.24, align 4
  %context.field.688 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.689 = load i32, ptr %context.field.688, align 4
  %stack.sub.692 = sub i32 %local.check.owner.end.687, %local.check.offset.684
  %descriptor.owner.inside.690 = icmp ule i32 %local.check.owner.end.687, %context.value.689
  %descriptor.offset.inside.691 = icmp ule i32 %local.check.offset.684, %local.check.owner.end.687
  %descriptor.extent.inside.693 = icmp ule i32 %local.check.extent.685, %stack.sub.692
  %descriptor.payload.inside.694 = icmp ule i32 %local.check.payload.686, %local.check.extent.685
  %descriptor.owner.offset.valid.695 = and i1 %descriptor.owner.inside.690, %descriptor.offset.inside.691
  %descriptor.range.inside.697 = and i1 %descriptor.owner.offset.valid.695, %descriptor.extent.inside.693
  %descriptor.range.valid.696 = and i1 %descriptor.range.inside.697, %descriptor.payload.inside.694
  br i1 %descriptor.range.valid.696, label %descriptor.valid.698, label %descriptor.invalid.699
descriptor.invalid.699:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.698:
  %descriptor.initialized.status.700 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.684, i32 %local.check.extent.685)
  %helper.ok.701 = icmp eq i32 %descriptor.initialized.status.700, 0
  br i1 %helper.ok.701, label %helper.continue.702, label %frame.failure.0
helper.continue.702:
  br label %local.descriptor.checked.683
local.descriptor.inactive.682:
  br label %local.descriptor.checked.683
local.descriptor.checked.683:
  %local.is.active.703 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.703, label %local.descriptor.active.704, label %local.descriptor.inactive.705
local.descriptor.active.704:
  %local.check.offset.707 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.708 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.709 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.710 = load i32, ptr %local.owner.end.30, align 4
  %context.field.711 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.712 = load i32, ptr %context.field.711, align 4
  %stack.sub.715 = sub i32 %local.check.owner.end.710, %local.check.offset.707
  %descriptor.owner.inside.713 = icmp ule i32 %local.check.owner.end.710, %context.value.712
  %descriptor.offset.inside.714 = icmp ule i32 %local.check.offset.707, %local.check.owner.end.710
  %descriptor.extent.inside.716 = icmp ule i32 %local.check.extent.708, %stack.sub.715
  %descriptor.payload.inside.717 = icmp ule i32 %local.check.payload.709, %local.check.extent.708
  %descriptor.owner.offset.valid.718 = and i1 %descriptor.owner.inside.713, %descriptor.offset.inside.714
  %descriptor.range.inside.720 = and i1 %descriptor.owner.offset.valid.718, %descriptor.extent.inside.716
  %descriptor.range.valid.719 = and i1 %descriptor.range.inside.720, %descriptor.payload.inside.717
  br i1 %descriptor.range.valid.719, label %descriptor.valid.721, label %descriptor.invalid.722
descriptor.invalid.722:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.721:
  %descriptor.initialized.status.723 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.707, i32 %local.check.extent.708)
  %helper.ok.724 = icmp eq i32 %descriptor.initialized.status.723, 0
  br i1 %helper.ok.724, label %helper.continue.725, label %frame.failure.0
helper.continue.725:
  br label %local.descriptor.checked.706
local.descriptor.inactive.705:
  br label %local.descriptor.checked.706
local.descriptor.checked.706:
  %local.is.active.726 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.726, label %local.descriptor.active.727, label %local.descriptor.inactive.728
local.descriptor.active.727:
  %local.check.offset.730 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.731 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.732 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.733 = load i32, ptr %local.owner.end.36, align 4
  %context.field.734 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.735 = load i32, ptr %context.field.734, align 4
  %stack.sub.738 = sub i32 %local.check.owner.end.733, %local.check.offset.730
  %descriptor.owner.inside.736 = icmp ule i32 %local.check.owner.end.733, %context.value.735
  %descriptor.offset.inside.737 = icmp ule i32 %local.check.offset.730, %local.check.owner.end.733
  %descriptor.extent.inside.739 = icmp ule i32 %local.check.extent.731, %stack.sub.738
  %descriptor.payload.inside.740 = icmp ule i32 %local.check.payload.732, %local.check.extent.731
  %descriptor.owner.offset.valid.741 = and i1 %descriptor.owner.inside.736, %descriptor.offset.inside.737
  %descriptor.range.inside.743 = and i1 %descriptor.owner.offset.valid.741, %descriptor.extent.inside.739
  %descriptor.range.valid.742 = and i1 %descriptor.range.inside.743, %descriptor.payload.inside.740
  br i1 %descriptor.range.valid.742, label %descriptor.valid.744, label %descriptor.invalid.745
descriptor.invalid.745:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.744:
  %descriptor.initialized.status.746 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.730, i32 %local.check.extent.731)
  %helper.ok.747 = icmp eq i32 %descriptor.initialized.status.746, 0
  br i1 %helper.ok.747, label %helper.continue.748, label %frame.failure.0
helper.continue.748:
  br label %local.descriptor.checked.729
local.descriptor.inactive.728:
  br label %local.descriptor.checked.729
local.descriptor.checked.729:
  %step.status.749 = call i32 @al_owning_charge_step(ptr %ctx, i32 25)
  %helper.ok.750 = icmp eq i32 %step.status.749, 0
  br i1 %helper.ok.750, label %helper.continue.751, label %frame.failure.0
helper.continue.751:
  %local.resolved.offset.752 = load i32, ptr %local.offset.21, align 4
  %local.resolved.extent.753 = load i32, ptr %local.extent.22, align 4
  %local.resolved.payload.754 = load i32, ptr %local.payload.23, align 4
  %local.resolved.owner.end.755 = load i32, ptr %local.owner.end.24, align 4
  %context.field.756 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.757 = load i32, ptr %context.field.756, align 4
  %stack.sub.760 = sub i32 %local.resolved.owner.end.755, %local.resolved.offset.752
  %descriptor.owner.inside.758 = icmp ule i32 %local.resolved.owner.end.755, %context.value.757
  %descriptor.offset.inside.759 = icmp ule i32 %local.resolved.offset.752, %local.resolved.owner.end.755
  %descriptor.extent.inside.761 = icmp ule i32 %local.resolved.extent.753, %stack.sub.760
  %descriptor.payload.inside.762 = icmp ule i32 %local.resolved.payload.754, %local.resolved.extent.753
  %descriptor.owner.offset.valid.763 = and i1 %descriptor.owner.inside.758, %descriptor.offset.inside.759
  %descriptor.range.inside.765 = and i1 %descriptor.owner.offset.valid.763, %descriptor.extent.inside.761
  %descriptor.range.valid.764 = and i1 %descriptor.range.inside.765, %descriptor.payload.inside.762
  %descriptor.type.valid.766 = icmp eq i32 1, 1
  %descriptor.valid.767 = and i1 %descriptor.range.valid.764, %descriptor.type.valid.766
  br i1 %descriptor.valid.767, label %descriptor.valid.768, label %descriptor.invalid.769
descriptor.invalid.769:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.768:
  %descriptor.initialized.status.770 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.752, i32 %local.resolved.extent.753)
  %helper.ok.771 = icmp eq i32 %descriptor.initialized.status.770, 0
  br i1 %helper.ok.771, label %helper.continue.772, label %frame.failure.0
helper.continue.772:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %local.resolved.offset.752, i32 20, i32 %local.resolved.payload.754, i32 %local.resolved.owner.end.755, i32 %local.resolved.extent.753)
  %context.field.773 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.774 = load i32, ptr %context.field.773, align 4
  %runtime.ok.775 = icmp eq i32 %context.value.774, 0
  br i1 %runtime.ok.775, label %runtime.continue.776, label %frame.failure.0
runtime.continue.776:
  %context.field.777 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.778 = load i32, ptr %context.field.777, align 4
  %stack.sub.781 = sub i32 %local.resolved.owner.end.755, %local.resolved.offset.752
  %descriptor.owner.inside.779 = icmp ule i32 %local.resolved.owner.end.755, %context.value.778
  %descriptor.offset.inside.780 = icmp ule i32 %local.resolved.offset.752, %local.resolved.owner.end.755
  %descriptor.extent.inside.782 = icmp ule i32 %local.resolved.extent.753, %stack.sub.781
  %descriptor.payload.inside.783 = icmp ule i32 %local.resolved.payload.754, %local.resolved.extent.753
  %descriptor.owner.offset.valid.784 = and i1 %descriptor.owner.inside.779, %descriptor.offset.inside.780
  %descriptor.range.inside.786 = and i1 %descriptor.owner.offset.valid.784, %descriptor.extent.inside.782
  %descriptor.range.valid.785 = and i1 %descriptor.range.inside.786, %descriptor.payload.inside.783
  %descriptor.type.valid.787 = icmp eq i32 1, 1
  %descriptor.valid.788 = and i1 %descriptor.range.valid.785, %descriptor.type.valid.787
  br i1 %descriptor.valid.788, label %descriptor.valid.789, label %descriptor.invalid.790
descriptor.invalid.790:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.789:
  %descriptor.initialized.status.791 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.752, i32 %local.resolved.extent.753)
  %helper.ok.792 = icmp eq i32 %descriptor.initialized.status.791, 0
  br i1 %helper.ok.792, label %helper.continue.793, label %frame.failure.0
helper.continue.793:
  %local.is.active.794 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.794, label %local.descriptor.active.795, label %local.descriptor.inactive.796
local.descriptor.active.795:
  %local.check.offset.798 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.799 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.800 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.801 = load i32, ptr %local.owner.end.6, align 4
  %context.field.802 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.803 = load i32, ptr %context.field.802, align 4
  %stack.sub.806 = sub i32 %local.check.owner.end.801, %local.check.offset.798
  %descriptor.owner.inside.804 = icmp ule i32 %local.check.owner.end.801, %context.value.803
  %descriptor.offset.inside.805 = icmp ule i32 %local.check.offset.798, %local.check.owner.end.801
  %descriptor.extent.inside.807 = icmp ule i32 %local.check.extent.799, %stack.sub.806
  %descriptor.payload.inside.808 = icmp ule i32 %local.check.payload.800, %local.check.extent.799
  %descriptor.owner.offset.valid.809 = and i1 %descriptor.owner.inside.804, %descriptor.offset.inside.805
  %descriptor.range.inside.811 = and i1 %descriptor.owner.offset.valid.809, %descriptor.extent.inside.807
  %descriptor.range.valid.810 = and i1 %descriptor.range.inside.811, %descriptor.payload.inside.808
  br i1 %descriptor.range.valid.810, label %descriptor.valid.812, label %descriptor.invalid.813
descriptor.invalid.813:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.812:
  %descriptor.initialized.status.814 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.798, i32 %local.check.extent.799)
  %helper.ok.815 = icmp eq i32 %descriptor.initialized.status.814, 0
  br i1 %helper.ok.815, label %helper.continue.816, label %frame.failure.0
helper.continue.816:
  br label %local.descriptor.checked.797
local.descriptor.inactive.796:
  br label %local.descriptor.checked.797
local.descriptor.checked.797:
  %local.is.active.817 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.817, label %local.descriptor.active.818, label %local.descriptor.inactive.819
local.descriptor.active.818:
  %local.check.offset.821 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.822 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.823 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.824 = load i32, ptr %local.owner.end.12, align 4
  %context.field.825 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.826 = load i32, ptr %context.field.825, align 4
  %stack.sub.829 = sub i32 %local.check.owner.end.824, %local.check.offset.821
  %descriptor.owner.inside.827 = icmp ule i32 %local.check.owner.end.824, %context.value.826
  %descriptor.offset.inside.828 = icmp ule i32 %local.check.offset.821, %local.check.owner.end.824
  %descriptor.extent.inside.830 = icmp ule i32 %local.check.extent.822, %stack.sub.829
  %descriptor.payload.inside.831 = icmp ule i32 %local.check.payload.823, %local.check.extent.822
  %descriptor.owner.offset.valid.832 = and i1 %descriptor.owner.inside.827, %descriptor.offset.inside.828
  %descriptor.range.inside.834 = and i1 %descriptor.owner.offset.valid.832, %descriptor.extent.inside.830
  %descriptor.range.valid.833 = and i1 %descriptor.range.inside.834, %descriptor.payload.inside.831
  br i1 %descriptor.range.valid.833, label %descriptor.valid.835, label %descriptor.invalid.836
descriptor.invalid.836:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.835:
  %descriptor.initialized.status.837 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.821, i32 %local.check.extent.822)
  %helper.ok.838 = icmp eq i32 %descriptor.initialized.status.837, 0
  br i1 %helper.ok.838, label %helper.continue.839, label %frame.failure.0
helper.continue.839:
  br label %local.descriptor.checked.820
local.descriptor.inactive.819:
  br label %local.descriptor.checked.820
local.descriptor.checked.820:
  %local.is.active.840 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.840, label %local.descriptor.active.841, label %local.descriptor.inactive.842
local.descriptor.active.841:
  %local.check.offset.844 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.845 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.846 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.847 = load i32, ptr %local.owner.end.18, align 4
  %context.field.848 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.849 = load i32, ptr %context.field.848, align 4
  %stack.sub.852 = sub i32 %local.check.owner.end.847, %local.check.offset.844
  %descriptor.owner.inside.850 = icmp ule i32 %local.check.owner.end.847, %context.value.849
  %descriptor.offset.inside.851 = icmp ule i32 %local.check.offset.844, %local.check.owner.end.847
  %descriptor.extent.inside.853 = icmp ule i32 %local.check.extent.845, %stack.sub.852
  %descriptor.payload.inside.854 = icmp ule i32 %local.check.payload.846, %local.check.extent.845
  %descriptor.owner.offset.valid.855 = and i1 %descriptor.owner.inside.850, %descriptor.offset.inside.851
  %descriptor.range.inside.857 = and i1 %descriptor.owner.offset.valid.855, %descriptor.extent.inside.853
  %descriptor.range.valid.856 = and i1 %descriptor.range.inside.857, %descriptor.payload.inside.854
  br i1 %descriptor.range.valid.856, label %descriptor.valid.858, label %descriptor.invalid.859
descriptor.invalid.859:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.858:
  %descriptor.initialized.status.860 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.844, i32 %local.check.extent.845)
  %helper.ok.861 = icmp eq i32 %descriptor.initialized.status.860, 0
  br i1 %helper.ok.861, label %helper.continue.862, label %frame.failure.0
helper.continue.862:
  br label %local.descriptor.checked.843
local.descriptor.inactive.842:
  br label %local.descriptor.checked.843
local.descriptor.checked.843:
  %local.is.active.863 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.863, label %local.descriptor.active.864, label %local.descriptor.inactive.865
local.descriptor.active.864:
  %local.check.offset.867 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.868 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.869 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.870 = load i32, ptr %local.owner.end.24, align 4
  %context.field.871 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.872 = load i32, ptr %context.field.871, align 4
  %stack.sub.875 = sub i32 %local.check.owner.end.870, %local.check.offset.867
  %descriptor.owner.inside.873 = icmp ule i32 %local.check.owner.end.870, %context.value.872
  %descriptor.offset.inside.874 = icmp ule i32 %local.check.offset.867, %local.check.owner.end.870
  %descriptor.extent.inside.876 = icmp ule i32 %local.check.extent.868, %stack.sub.875
  %descriptor.payload.inside.877 = icmp ule i32 %local.check.payload.869, %local.check.extent.868
  %descriptor.owner.offset.valid.878 = and i1 %descriptor.owner.inside.873, %descriptor.offset.inside.874
  %descriptor.range.inside.880 = and i1 %descriptor.owner.offset.valid.878, %descriptor.extent.inside.876
  %descriptor.range.valid.879 = and i1 %descriptor.range.inside.880, %descriptor.payload.inside.877
  br i1 %descriptor.range.valid.879, label %descriptor.valid.881, label %descriptor.invalid.882
descriptor.invalid.882:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.881:
  %descriptor.initialized.status.883 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.867, i32 %local.check.extent.868)
  %helper.ok.884 = icmp eq i32 %descriptor.initialized.status.883, 0
  br i1 %helper.ok.884, label %helper.continue.885, label %frame.failure.0
helper.continue.885:
  br label %local.descriptor.checked.866
local.descriptor.inactive.865:
  br label %local.descriptor.checked.866
local.descriptor.checked.866:
  %local.is.active.886 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.886, label %local.descriptor.active.887, label %local.descriptor.inactive.888
local.descriptor.active.887:
  %local.check.offset.890 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.891 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.892 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.893 = load i32, ptr %local.owner.end.30, align 4
  %context.field.894 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.895 = load i32, ptr %context.field.894, align 4
  %stack.sub.898 = sub i32 %local.check.owner.end.893, %local.check.offset.890
  %descriptor.owner.inside.896 = icmp ule i32 %local.check.owner.end.893, %context.value.895
  %descriptor.offset.inside.897 = icmp ule i32 %local.check.offset.890, %local.check.owner.end.893
  %descriptor.extent.inside.899 = icmp ule i32 %local.check.extent.891, %stack.sub.898
  %descriptor.payload.inside.900 = icmp ule i32 %local.check.payload.892, %local.check.extent.891
  %descriptor.owner.offset.valid.901 = and i1 %descriptor.owner.inside.896, %descriptor.offset.inside.897
  %descriptor.range.inside.903 = and i1 %descriptor.owner.offset.valid.901, %descriptor.extent.inside.899
  %descriptor.range.valid.902 = and i1 %descriptor.range.inside.903, %descriptor.payload.inside.900
  br i1 %descriptor.range.valid.902, label %descriptor.valid.904, label %descriptor.invalid.905
descriptor.invalid.905:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.904:
  %descriptor.initialized.status.906 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.890, i32 %local.check.extent.891)
  %helper.ok.907 = icmp eq i32 %descriptor.initialized.status.906, 0
  br i1 %helper.ok.907, label %helper.continue.908, label %frame.failure.0
helper.continue.908:
  br label %local.descriptor.checked.889
local.descriptor.inactive.888:
  br label %local.descriptor.checked.889
local.descriptor.checked.889:
  %local.is.active.909 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.909, label %local.descriptor.active.910, label %local.descriptor.inactive.911
local.descriptor.active.910:
  %local.check.offset.913 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.914 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.915 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.916 = load i32, ptr %local.owner.end.36, align 4
  %context.field.917 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.918 = load i32, ptr %context.field.917, align 4
  %stack.sub.921 = sub i32 %local.check.owner.end.916, %local.check.offset.913
  %descriptor.owner.inside.919 = icmp ule i32 %local.check.owner.end.916, %context.value.918
  %descriptor.offset.inside.920 = icmp ule i32 %local.check.offset.913, %local.check.owner.end.916
  %descriptor.extent.inside.922 = icmp ule i32 %local.check.extent.914, %stack.sub.921
  %descriptor.payload.inside.923 = icmp ule i32 %local.check.payload.915, %local.check.extent.914
  %descriptor.owner.offset.valid.924 = and i1 %descriptor.owner.inside.919, %descriptor.offset.inside.920
  %descriptor.range.inside.926 = and i1 %descriptor.owner.offset.valid.924, %descriptor.extent.inside.922
  %descriptor.range.valid.925 = and i1 %descriptor.range.inside.926, %descriptor.payload.inside.923
  br i1 %descriptor.range.valid.925, label %descriptor.valid.927, label %descriptor.invalid.928
descriptor.invalid.928:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.927:
  %descriptor.initialized.status.929 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.913, i32 %local.check.extent.914)
  %helper.ok.930 = icmp eq i32 %descriptor.initialized.status.929, 0
  br i1 %helper.ok.930, label %helper.continue.931, label %frame.failure.0
helper.continue.931:
  br label %local.descriptor.checked.912
local.descriptor.inactive.911:
  br label %local.descriptor.checked.912
local.descriptor.checked.912:
  %step.status.932 = call i32 @al_owning_charge_step(ptr %ctx, i32 26)
  %helper.ok.933 = icmp eq i32 %step.status.932, 0
  br i1 %helper.ok.933, label %helper.continue.934, label %frame.failure.0
helper.continue.934:
  %stack.offset.935 = add i32 0, %local.resolved.payload.754
  %stack.offset.936 = add i32 0, %local.resolved.extent.753
  %context.field.937 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.938 = load i32, ptr %context.field.937, align 4
  %stack.offset.939 = add i32 %context.value.938, %stack.offset.936
  %reserve.status.940 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.939, i32 27)
  %reserve.ok.941 = icmp eq i32 %reserve.status.940, 0
  br i1 %reserve.ok.941, label %reserve.continue.942, label %frame.failure.0
reserve.continue.942:
  %stack.offset.943 = add i32 %context.value.938, 0
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.943, i32 %local.resolved.offset.752, i32 %local.resolved.extent.753, i32 %local.resolved.payload.754, i32 1, i32 6)
  %context.field.944 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.945 = load i32, ptr %context.field.944, align 4
  %runtime.ok.946 = icmp eq i32 %context.value.945, 0
  br i1 %runtime.ok.946, label %runtime.continue.947, label %frame.failure.0
runtime.continue.947:
  %stack.offset.948 = add i32 0, %local.resolved.extent.753
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 6, i32 %context.value.938, i32 %stack.offset.936, i32 %stack.offset.935, i32 0, i32 0)
  %context.field.949 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.950 = load i32, ptr %context.field.949, align 4
  %runtime.ok.951 = icmp eq i32 %context.value.950, 0
  br i1 %runtime.ok.951, label %runtime.continue.952, label %frame.failure.0
runtime.continue.952:
  %context.field.953 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.954 = load i32, ptr %context.field.953, align 4
  %stack.sub.957 = sub i32 %stack.offset.939, %context.value.938
  %descriptor.owner.inside.955 = icmp ule i32 %stack.offset.939, %context.value.954
  %descriptor.offset.inside.956 = icmp ule i32 %context.value.938, %stack.offset.939
  %descriptor.extent.inside.958 = icmp ule i32 %stack.offset.936, %stack.sub.957
  %descriptor.payload.inside.959 = icmp ule i32 %stack.offset.935, %stack.offset.936
  %descriptor.owner.offset.valid.960 = and i1 %descriptor.owner.inside.955, %descriptor.offset.inside.956
  %descriptor.range.inside.962 = and i1 %descriptor.owner.offset.valid.960, %descriptor.extent.inside.958
  %descriptor.range.valid.961 = and i1 %descriptor.range.inside.962, %descriptor.payload.inside.959
  %descriptor.type.valid.963 = icmp eq i32 6, 6
  %descriptor.valid.964 = and i1 %descriptor.range.valid.961, %descriptor.type.valid.963
  br i1 %descriptor.valid.964, label %descriptor.valid.965, label %descriptor.invalid.966
descriptor.invalid.966:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.965:
  %descriptor.initialized.status.967 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.938, i32 %stack.offset.936)
  %helper.ok.968 = icmp eq i32 %descriptor.initialized.status.967, 0
  br i1 %helper.ok.968, label %helper.continue.969, label %frame.failure.0
helper.continue.969:
  %local.is.active.970 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.970, label %local.descriptor.active.971, label %local.descriptor.inactive.972
local.descriptor.active.971:
  %local.check.offset.974 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.975 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.976 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.977 = load i32, ptr %local.owner.end.6, align 4
  %context.field.978 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.979 = load i32, ptr %context.field.978, align 4
  %stack.sub.982 = sub i32 %local.check.owner.end.977, %local.check.offset.974
  %descriptor.owner.inside.980 = icmp ule i32 %local.check.owner.end.977, %context.value.979
  %descriptor.offset.inside.981 = icmp ule i32 %local.check.offset.974, %local.check.owner.end.977
  %descriptor.extent.inside.983 = icmp ule i32 %local.check.extent.975, %stack.sub.982
  %descriptor.payload.inside.984 = icmp ule i32 %local.check.payload.976, %local.check.extent.975
  %descriptor.owner.offset.valid.985 = and i1 %descriptor.owner.inside.980, %descriptor.offset.inside.981
  %descriptor.range.inside.987 = and i1 %descriptor.owner.offset.valid.985, %descriptor.extent.inside.983
  %descriptor.range.valid.986 = and i1 %descriptor.range.inside.987, %descriptor.payload.inside.984
  br i1 %descriptor.range.valid.986, label %descriptor.valid.988, label %descriptor.invalid.989
descriptor.invalid.989:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.988:
  %descriptor.initialized.status.990 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.974, i32 %local.check.extent.975)
  %helper.ok.991 = icmp eq i32 %descriptor.initialized.status.990, 0
  br i1 %helper.ok.991, label %helper.continue.992, label %frame.failure.0
helper.continue.992:
  br label %local.descriptor.checked.973
local.descriptor.inactive.972:
  br label %local.descriptor.checked.973
local.descriptor.checked.973:
  %local.is.active.993 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.993, label %local.descriptor.active.994, label %local.descriptor.inactive.995
local.descriptor.active.994:
  %local.check.offset.997 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.998 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.999 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1000 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1001 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1002 = load i32, ptr %context.field.1001, align 4
  %stack.sub.1005 = sub i32 %local.check.owner.end.1000, %local.check.offset.997
  %descriptor.owner.inside.1003 = icmp ule i32 %local.check.owner.end.1000, %context.value.1002
  %descriptor.offset.inside.1004 = icmp ule i32 %local.check.offset.997, %local.check.owner.end.1000
  %descriptor.extent.inside.1006 = icmp ule i32 %local.check.extent.998, %stack.sub.1005
  %descriptor.payload.inside.1007 = icmp ule i32 %local.check.payload.999, %local.check.extent.998
  %descriptor.owner.offset.valid.1008 = and i1 %descriptor.owner.inside.1003, %descriptor.offset.inside.1004
  %descriptor.range.inside.1010 = and i1 %descriptor.owner.offset.valid.1008, %descriptor.extent.inside.1006
  %descriptor.range.valid.1009 = and i1 %descriptor.range.inside.1010, %descriptor.payload.inside.1007
  br i1 %descriptor.range.valid.1009, label %descriptor.valid.1011, label %descriptor.invalid.1012
descriptor.invalid.1012:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1011:
  %descriptor.initialized.status.1013 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.997, i32 %local.check.extent.998)
  %helper.ok.1014 = icmp eq i32 %descriptor.initialized.status.1013, 0
  br i1 %helper.ok.1014, label %helper.continue.1015, label %frame.failure.0
helper.continue.1015:
  br label %local.descriptor.checked.996
local.descriptor.inactive.995:
  br label %local.descriptor.checked.996
local.descriptor.checked.996:
  %local.is.active.1016 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1016, label %local.descriptor.active.1017, label %local.descriptor.inactive.1018
local.descriptor.active.1017:
  %local.check.offset.1020 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1021 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1022 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1023 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1024 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1025 = load i32, ptr %context.field.1024, align 4
  %stack.sub.1028 = sub i32 %local.check.owner.end.1023, %local.check.offset.1020
  %descriptor.owner.inside.1026 = icmp ule i32 %local.check.owner.end.1023, %context.value.1025
  %descriptor.offset.inside.1027 = icmp ule i32 %local.check.offset.1020, %local.check.owner.end.1023
  %descriptor.extent.inside.1029 = icmp ule i32 %local.check.extent.1021, %stack.sub.1028
  %descriptor.payload.inside.1030 = icmp ule i32 %local.check.payload.1022, %local.check.extent.1021
  %descriptor.owner.offset.valid.1031 = and i1 %descriptor.owner.inside.1026, %descriptor.offset.inside.1027
  %descriptor.range.inside.1033 = and i1 %descriptor.owner.offset.valid.1031, %descriptor.extent.inside.1029
  %descriptor.range.valid.1032 = and i1 %descriptor.range.inside.1033, %descriptor.payload.inside.1030
  br i1 %descriptor.range.valid.1032, label %descriptor.valid.1034, label %descriptor.invalid.1035
descriptor.invalid.1035:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1034:
  %descriptor.initialized.status.1036 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1020, i32 %local.check.extent.1021)
  %helper.ok.1037 = icmp eq i32 %descriptor.initialized.status.1036, 0
  br i1 %helper.ok.1037, label %helper.continue.1038, label %frame.failure.0
helper.continue.1038:
  br label %local.descriptor.checked.1019
local.descriptor.inactive.1018:
  br label %local.descriptor.checked.1019
local.descriptor.checked.1019:
  %local.is.active.1039 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1039, label %local.descriptor.active.1040, label %local.descriptor.inactive.1041
local.descriptor.active.1040:
  %local.check.offset.1043 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1044 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1045 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1046 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1047 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1048 = load i32, ptr %context.field.1047, align 4
  %stack.sub.1051 = sub i32 %local.check.owner.end.1046, %local.check.offset.1043
  %descriptor.owner.inside.1049 = icmp ule i32 %local.check.owner.end.1046, %context.value.1048
  %descriptor.offset.inside.1050 = icmp ule i32 %local.check.offset.1043, %local.check.owner.end.1046
  %descriptor.extent.inside.1052 = icmp ule i32 %local.check.extent.1044, %stack.sub.1051
  %descriptor.payload.inside.1053 = icmp ule i32 %local.check.payload.1045, %local.check.extent.1044
  %descriptor.owner.offset.valid.1054 = and i1 %descriptor.owner.inside.1049, %descriptor.offset.inside.1050
  %descriptor.range.inside.1056 = and i1 %descriptor.owner.offset.valid.1054, %descriptor.extent.inside.1052
  %descriptor.range.valid.1055 = and i1 %descriptor.range.inside.1056, %descriptor.payload.inside.1053
  br i1 %descriptor.range.valid.1055, label %descriptor.valid.1057, label %descriptor.invalid.1058
descriptor.invalid.1058:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1057:
  %descriptor.initialized.status.1059 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1043, i32 %local.check.extent.1044)
  %helper.ok.1060 = icmp eq i32 %descriptor.initialized.status.1059, 0
  br i1 %helper.ok.1060, label %helper.continue.1061, label %frame.failure.0
helper.continue.1061:
  br label %local.descriptor.checked.1042
local.descriptor.inactive.1041:
  br label %local.descriptor.checked.1042
local.descriptor.checked.1042:
  %local.is.active.1062 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1062, label %local.descriptor.active.1063, label %local.descriptor.inactive.1064
local.descriptor.active.1063:
  %local.check.offset.1066 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1067 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1068 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1069 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1070 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1071 = load i32, ptr %context.field.1070, align 4
  %stack.sub.1074 = sub i32 %local.check.owner.end.1069, %local.check.offset.1066
  %descriptor.owner.inside.1072 = icmp ule i32 %local.check.owner.end.1069, %context.value.1071
  %descriptor.offset.inside.1073 = icmp ule i32 %local.check.offset.1066, %local.check.owner.end.1069
  %descriptor.extent.inside.1075 = icmp ule i32 %local.check.extent.1067, %stack.sub.1074
  %descriptor.payload.inside.1076 = icmp ule i32 %local.check.payload.1068, %local.check.extent.1067
  %descriptor.owner.offset.valid.1077 = and i1 %descriptor.owner.inside.1072, %descriptor.offset.inside.1073
  %descriptor.range.inside.1079 = and i1 %descriptor.owner.offset.valid.1077, %descriptor.extent.inside.1075
  %descriptor.range.valid.1078 = and i1 %descriptor.range.inside.1079, %descriptor.payload.inside.1076
  br i1 %descriptor.range.valid.1078, label %descriptor.valid.1080, label %descriptor.invalid.1081
descriptor.invalid.1081:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1080:
  %descriptor.initialized.status.1082 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1066, i32 %local.check.extent.1067)
  %helper.ok.1083 = icmp eq i32 %descriptor.initialized.status.1082, 0
  br i1 %helper.ok.1083, label %helper.continue.1084, label %frame.failure.0
helper.continue.1084:
  br label %local.descriptor.checked.1065
local.descriptor.inactive.1064:
  br label %local.descriptor.checked.1065
local.descriptor.checked.1065:
  %local.is.active.1085 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1085, label %local.descriptor.active.1086, label %local.descriptor.inactive.1087
local.descriptor.active.1086:
  %local.check.offset.1089 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1090 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1091 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1092 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1093 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1094 = load i32, ptr %context.field.1093, align 4
  %stack.sub.1097 = sub i32 %local.check.owner.end.1092, %local.check.offset.1089
  %descriptor.owner.inside.1095 = icmp ule i32 %local.check.owner.end.1092, %context.value.1094
  %descriptor.offset.inside.1096 = icmp ule i32 %local.check.offset.1089, %local.check.owner.end.1092
  %descriptor.extent.inside.1098 = icmp ule i32 %local.check.extent.1090, %stack.sub.1097
  %descriptor.payload.inside.1099 = icmp ule i32 %local.check.payload.1091, %local.check.extent.1090
  %descriptor.owner.offset.valid.1100 = and i1 %descriptor.owner.inside.1095, %descriptor.offset.inside.1096
  %descriptor.range.inside.1102 = and i1 %descriptor.owner.offset.valid.1100, %descriptor.extent.inside.1098
  %descriptor.range.valid.1101 = and i1 %descriptor.range.inside.1102, %descriptor.payload.inside.1099
  br i1 %descriptor.range.valid.1101, label %descriptor.valid.1103, label %descriptor.invalid.1104
descriptor.invalid.1104:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1103:
  %descriptor.initialized.status.1105 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1089, i32 %local.check.extent.1090)
  %helper.ok.1106 = icmp eq i32 %descriptor.initialized.status.1105, 0
  br i1 %helper.ok.1106, label %helper.continue.1107, label %frame.failure.0
helper.continue.1107:
  br label %local.descriptor.checked.1088
local.descriptor.inactive.1087:
  br label %local.descriptor.checked.1088
local.descriptor.checked.1088:
  store i1 false, ptr %local.active.20, align 1
  store i32 0, ptr %local.offset.21, align 4
  store i32 0, ptr %local.extent.22, align 4
  store i32 0, ptr %local.payload.23, align 4
  store i32 0, ptr %local.owner.end.24, align 4
  store i32 0, ptr %local.type.25, align 4
  %context.field.1108 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1109 = load i32, ptr %context.field.1108, align 4
  %stack.sub.1112 = sub i32 %stack.offset.939, %context.value.938
  %descriptor.owner.inside.1110 = icmp ule i32 %stack.offset.939, %context.value.1109
  %descriptor.offset.inside.1111 = icmp ule i32 %context.value.938, %stack.offset.939
  %descriptor.extent.inside.1113 = icmp ule i32 %stack.offset.936, %stack.sub.1112
  %descriptor.payload.inside.1114 = icmp ule i32 %stack.offset.935, %stack.offset.936
  %descriptor.owner.offset.valid.1115 = and i1 %descriptor.owner.inside.1110, %descriptor.offset.inside.1111
  %descriptor.range.inside.1117 = and i1 %descriptor.owner.offset.valid.1115, %descriptor.extent.inside.1113
  %descriptor.range.valid.1116 = and i1 %descriptor.range.inside.1117, %descriptor.payload.inside.1114
  %descriptor.type.valid.1118 = icmp eq i32 6, 6
  %descriptor.valid.1119 = and i1 %descriptor.range.valid.1116, %descriptor.type.valid.1118
  br i1 %descriptor.valid.1119, label %descriptor.valid.1120, label %descriptor.invalid.1121
descriptor.invalid.1121:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1120:
  %descriptor.initialized.status.1122 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.938, i32 %stack.offset.936)
  %helper.ok.1123 = icmp eq i32 %descriptor.initialized.status.1122, 0
  br i1 %helper.ok.1123, label %helper.continue.1124, label %frame.failure.0
helper.continue.1124:
  %local.is.active.1125 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1125, label %local.descriptor.active.1126, label %local.descriptor.inactive.1127
local.descriptor.active.1126:
  %local.check.offset.1129 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1130 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1131 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1132 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1133 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1134 = load i32, ptr %context.field.1133, align 4
  %stack.sub.1137 = sub i32 %local.check.owner.end.1132, %local.check.offset.1129
  %descriptor.owner.inside.1135 = icmp ule i32 %local.check.owner.end.1132, %context.value.1134
  %descriptor.offset.inside.1136 = icmp ule i32 %local.check.offset.1129, %local.check.owner.end.1132
  %descriptor.extent.inside.1138 = icmp ule i32 %local.check.extent.1130, %stack.sub.1137
  %descriptor.payload.inside.1139 = icmp ule i32 %local.check.payload.1131, %local.check.extent.1130
  %descriptor.owner.offset.valid.1140 = and i1 %descriptor.owner.inside.1135, %descriptor.offset.inside.1136
  %descriptor.range.inside.1142 = and i1 %descriptor.owner.offset.valid.1140, %descriptor.extent.inside.1138
  %descriptor.range.valid.1141 = and i1 %descriptor.range.inside.1142, %descriptor.payload.inside.1139
  br i1 %descriptor.range.valid.1141, label %descriptor.valid.1143, label %descriptor.invalid.1144
descriptor.invalid.1144:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1143:
  %descriptor.initialized.status.1145 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1129, i32 %local.check.extent.1130)
  %helper.ok.1146 = icmp eq i32 %descriptor.initialized.status.1145, 0
  br i1 %helper.ok.1146, label %helper.continue.1147, label %frame.failure.0
helper.continue.1147:
  br label %local.descriptor.checked.1128
local.descriptor.inactive.1127:
  br label %local.descriptor.checked.1128
local.descriptor.checked.1128:
  %local.is.active.1148 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1148, label %local.descriptor.active.1149, label %local.descriptor.inactive.1150
local.descriptor.active.1149:
  %local.check.offset.1152 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1153 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1154 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1155 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1156 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1157 = load i32, ptr %context.field.1156, align 4
  %stack.sub.1160 = sub i32 %local.check.owner.end.1155, %local.check.offset.1152
  %descriptor.owner.inside.1158 = icmp ule i32 %local.check.owner.end.1155, %context.value.1157
  %descriptor.offset.inside.1159 = icmp ule i32 %local.check.offset.1152, %local.check.owner.end.1155
  %descriptor.extent.inside.1161 = icmp ule i32 %local.check.extent.1153, %stack.sub.1160
  %descriptor.payload.inside.1162 = icmp ule i32 %local.check.payload.1154, %local.check.extent.1153
  %descriptor.owner.offset.valid.1163 = and i1 %descriptor.owner.inside.1158, %descriptor.offset.inside.1159
  %descriptor.range.inside.1165 = and i1 %descriptor.owner.offset.valid.1163, %descriptor.extent.inside.1161
  %descriptor.range.valid.1164 = and i1 %descriptor.range.inside.1165, %descriptor.payload.inside.1162
  br i1 %descriptor.range.valid.1164, label %descriptor.valid.1166, label %descriptor.invalid.1167
descriptor.invalid.1167:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1166:
  %descriptor.initialized.status.1168 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1152, i32 %local.check.extent.1153)
  %helper.ok.1169 = icmp eq i32 %descriptor.initialized.status.1168, 0
  br i1 %helper.ok.1169, label %helper.continue.1170, label %frame.failure.0
helper.continue.1170:
  br label %local.descriptor.checked.1151
local.descriptor.inactive.1150:
  br label %local.descriptor.checked.1151
local.descriptor.checked.1151:
  %local.is.active.1171 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1171, label %local.descriptor.active.1172, label %local.descriptor.inactive.1173
local.descriptor.active.1172:
  %local.check.offset.1175 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1176 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1177 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1178 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1179 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1180 = load i32, ptr %context.field.1179, align 4
  %stack.sub.1183 = sub i32 %local.check.owner.end.1178, %local.check.offset.1175
  %descriptor.owner.inside.1181 = icmp ule i32 %local.check.owner.end.1178, %context.value.1180
  %descriptor.offset.inside.1182 = icmp ule i32 %local.check.offset.1175, %local.check.owner.end.1178
  %descriptor.extent.inside.1184 = icmp ule i32 %local.check.extent.1176, %stack.sub.1183
  %descriptor.payload.inside.1185 = icmp ule i32 %local.check.payload.1177, %local.check.extent.1176
  %descriptor.owner.offset.valid.1186 = and i1 %descriptor.owner.inside.1181, %descriptor.offset.inside.1182
  %descriptor.range.inside.1188 = and i1 %descriptor.owner.offset.valid.1186, %descriptor.extent.inside.1184
  %descriptor.range.valid.1187 = and i1 %descriptor.range.inside.1188, %descriptor.payload.inside.1185
  br i1 %descriptor.range.valid.1187, label %descriptor.valid.1189, label %descriptor.invalid.1190
descriptor.invalid.1190:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1189:
  %descriptor.initialized.status.1191 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1175, i32 %local.check.extent.1176)
  %helper.ok.1192 = icmp eq i32 %descriptor.initialized.status.1191, 0
  br i1 %helper.ok.1192, label %helper.continue.1193, label %frame.failure.0
helper.continue.1193:
  br label %local.descriptor.checked.1174
local.descriptor.inactive.1173:
  br label %local.descriptor.checked.1174
local.descriptor.checked.1174:
  %local.is.active.1194 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1194, label %local.descriptor.active.1195, label %local.descriptor.inactive.1196
local.descriptor.active.1195:
  %local.check.offset.1198 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1199 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1200 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1201 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1202 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1203 = load i32, ptr %context.field.1202, align 4
  %stack.sub.1206 = sub i32 %local.check.owner.end.1201, %local.check.offset.1198
  %descriptor.owner.inside.1204 = icmp ule i32 %local.check.owner.end.1201, %context.value.1203
  %descriptor.offset.inside.1205 = icmp ule i32 %local.check.offset.1198, %local.check.owner.end.1201
  %descriptor.extent.inside.1207 = icmp ule i32 %local.check.extent.1199, %stack.sub.1206
  %descriptor.payload.inside.1208 = icmp ule i32 %local.check.payload.1200, %local.check.extent.1199
  %descriptor.owner.offset.valid.1209 = and i1 %descriptor.owner.inside.1204, %descriptor.offset.inside.1205
  %descriptor.range.inside.1211 = and i1 %descriptor.owner.offset.valid.1209, %descriptor.extent.inside.1207
  %descriptor.range.valid.1210 = and i1 %descriptor.range.inside.1211, %descriptor.payload.inside.1208
  br i1 %descriptor.range.valid.1210, label %descriptor.valid.1212, label %descriptor.invalid.1213
descriptor.invalid.1213:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1212:
  %descriptor.initialized.status.1214 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1198, i32 %local.check.extent.1199)
  %helper.ok.1215 = icmp eq i32 %descriptor.initialized.status.1214, 0
  br i1 %helper.ok.1215, label %helper.continue.1216, label %frame.failure.0
helper.continue.1216:
  br label %local.descriptor.checked.1197
local.descriptor.inactive.1196:
  br label %local.descriptor.checked.1197
local.descriptor.checked.1197:
  %local.is.active.1217 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1217, label %local.descriptor.active.1218, label %local.descriptor.inactive.1219
local.descriptor.active.1218:
  %local.check.offset.1221 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1222 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1223 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1224 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1225 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1226 = load i32, ptr %context.field.1225, align 4
  %stack.sub.1229 = sub i32 %local.check.owner.end.1224, %local.check.offset.1221
  %descriptor.owner.inside.1227 = icmp ule i32 %local.check.owner.end.1224, %context.value.1226
  %descriptor.offset.inside.1228 = icmp ule i32 %local.check.offset.1221, %local.check.owner.end.1224
  %descriptor.extent.inside.1230 = icmp ule i32 %local.check.extent.1222, %stack.sub.1229
  %descriptor.payload.inside.1231 = icmp ule i32 %local.check.payload.1223, %local.check.extent.1222
  %descriptor.owner.offset.valid.1232 = and i1 %descriptor.owner.inside.1227, %descriptor.offset.inside.1228
  %descriptor.range.inside.1234 = and i1 %descriptor.owner.offset.valid.1232, %descriptor.extent.inside.1230
  %descriptor.range.valid.1233 = and i1 %descriptor.range.inside.1234, %descriptor.payload.inside.1231
  br i1 %descriptor.range.valid.1233, label %descriptor.valid.1235, label %descriptor.invalid.1236
descriptor.invalid.1236:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1235:
  %descriptor.initialized.status.1237 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1221, i32 %local.check.extent.1222)
  %helper.ok.1238 = icmp eq i32 %descriptor.initialized.status.1237, 0
  br i1 %helper.ok.1238, label %helper.continue.1239, label %frame.failure.0
helper.continue.1239:
  br label %local.descriptor.checked.1220
local.descriptor.inactive.1219:
  br label %local.descriptor.checked.1220
local.descriptor.checked.1220:
  %local.is.active.1240 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1240, label %local.descriptor.active.1241, label %local.descriptor.inactive.1242
local.descriptor.active.1241:
  %local.check.offset.1244 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1245 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1246 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1247 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1248 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1249 = load i32, ptr %context.field.1248, align 4
  %stack.sub.1252 = sub i32 %local.check.owner.end.1247, %local.check.offset.1244
  %descriptor.owner.inside.1250 = icmp ule i32 %local.check.owner.end.1247, %context.value.1249
  %descriptor.offset.inside.1251 = icmp ule i32 %local.check.offset.1244, %local.check.owner.end.1247
  %descriptor.extent.inside.1253 = icmp ule i32 %local.check.extent.1245, %stack.sub.1252
  %descriptor.payload.inside.1254 = icmp ule i32 %local.check.payload.1246, %local.check.extent.1245
  %descriptor.owner.offset.valid.1255 = and i1 %descriptor.owner.inside.1250, %descriptor.offset.inside.1251
  %descriptor.range.inside.1257 = and i1 %descriptor.owner.offset.valid.1255, %descriptor.extent.inside.1253
  %descriptor.range.valid.1256 = and i1 %descriptor.range.inside.1257, %descriptor.payload.inside.1254
  br i1 %descriptor.range.valid.1256, label %descriptor.valid.1258, label %descriptor.invalid.1259
descriptor.invalid.1259:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1258:
  %descriptor.initialized.status.1260 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1244, i32 %local.check.extent.1245)
  %helper.ok.1261 = icmp eq i32 %descriptor.initialized.status.1260, 0
  br i1 %helper.ok.1261, label %helper.continue.1262, label %frame.failure.0
helper.continue.1262:
  br label %local.descriptor.checked.1243
local.descriptor.inactive.1242:
  br label %local.descriptor.checked.1243
local.descriptor.checked.1243:
  %step.status.1263 = call i32 @al_owning_charge_step(ptr %ctx, i32 28)
  %helper.ok.1264 = icmp eq i32 %step.status.1263, 0
  br i1 %helper.ok.1264, label %helper.continue.1265, label %frame.failure.0
helper.continue.1265:
  store i1 true, ptr %local.active.14, align 1
  store i32 %context.value.938, ptr %local.offset.15, align 4
  store i32 %stack.offset.936, ptr %local.extent.16, align 4
  store i32 %stack.offset.935, ptr %local.payload.17, align 4
  store i32 %stack.offset.939, ptr %local.owner.end.18, align 4
  store i32 6, ptr %local.type.19, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %context.value.938, i32 20, i32 %stack.offset.935, i32 %stack.offset.939, i32 %stack.offset.936)
  %context.field.1266 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1267 = load i32, ptr %context.field.1266, align 4
  %runtime.ok.1268 = icmp eq i32 %context.value.1267, 0
  br i1 %runtime.ok.1268, label %runtime.continue.1269, label %frame.failure.0
runtime.continue.1269:
  %local.is.active.1270 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1270, label %local.descriptor.active.1271, label %local.descriptor.inactive.1272
local.descriptor.active.1271:
  %local.check.offset.1274 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1275 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1276 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1277 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1278 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1279 = load i32, ptr %context.field.1278, align 4
  %stack.sub.1282 = sub i32 %local.check.owner.end.1277, %local.check.offset.1274
  %descriptor.owner.inside.1280 = icmp ule i32 %local.check.owner.end.1277, %context.value.1279
  %descriptor.offset.inside.1281 = icmp ule i32 %local.check.offset.1274, %local.check.owner.end.1277
  %descriptor.extent.inside.1283 = icmp ule i32 %local.check.extent.1275, %stack.sub.1282
  %descriptor.payload.inside.1284 = icmp ule i32 %local.check.payload.1276, %local.check.extent.1275
  %descriptor.owner.offset.valid.1285 = and i1 %descriptor.owner.inside.1280, %descriptor.offset.inside.1281
  %descriptor.range.inside.1287 = and i1 %descriptor.owner.offset.valid.1285, %descriptor.extent.inside.1283
  %descriptor.range.valid.1286 = and i1 %descriptor.range.inside.1287, %descriptor.payload.inside.1284
  br i1 %descriptor.range.valid.1286, label %descriptor.valid.1288, label %descriptor.invalid.1289
descriptor.invalid.1289:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1288:
  %descriptor.initialized.status.1290 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1274, i32 %local.check.extent.1275)
  %helper.ok.1291 = icmp eq i32 %descriptor.initialized.status.1290, 0
  br i1 %helper.ok.1291, label %helper.continue.1292, label %frame.failure.0
helper.continue.1292:
  br label %local.descriptor.checked.1273
local.descriptor.inactive.1272:
  br label %local.descriptor.checked.1273
local.descriptor.checked.1273:
  %local.is.active.1293 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1293, label %local.descriptor.active.1294, label %local.descriptor.inactive.1295
local.descriptor.active.1294:
  %local.check.offset.1297 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1298 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1299 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1300 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1301 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1302 = load i32, ptr %context.field.1301, align 4
  %stack.sub.1305 = sub i32 %local.check.owner.end.1300, %local.check.offset.1297
  %descriptor.owner.inside.1303 = icmp ule i32 %local.check.owner.end.1300, %context.value.1302
  %descriptor.offset.inside.1304 = icmp ule i32 %local.check.offset.1297, %local.check.owner.end.1300
  %descriptor.extent.inside.1306 = icmp ule i32 %local.check.extent.1298, %stack.sub.1305
  %descriptor.payload.inside.1307 = icmp ule i32 %local.check.payload.1299, %local.check.extent.1298
  %descriptor.owner.offset.valid.1308 = and i1 %descriptor.owner.inside.1303, %descriptor.offset.inside.1304
  %descriptor.range.inside.1310 = and i1 %descriptor.owner.offset.valid.1308, %descriptor.extent.inside.1306
  %descriptor.range.valid.1309 = and i1 %descriptor.range.inside.1310, %descriptor.payload.inside.1307
  br i1 %descriptor.range.valid.1309, label %descriptor.valid.1311, label %descriptor.invalid.1312
descriptor.invalid.1312:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1311:
  %descriptor.initialized.status.1313 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1297, i32 %local.check.extent.1298)
  %helper.ok.1314 = icmp eq i32 %descriptor.initialized.status.1313, 0
  br i1 %helper.ok.1314, label %helper.continue.1315, label %frame.failure.0
helper.continue.1315:
  br label %local.descriptor.checked.1296
local.descriptor.inactive.1295:
  br label %local.descriptor.checked.1296
local.descriptor.checked.1296:
  %local.is.active.1316 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1316, label %local.descriptor.active.1317, label %local.descriptor.inactive.1318
local.descriptor.active.1317:
  %local.check.offset.1320 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1321 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1322 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1323 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1324 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1325 = load i32, ptr %context.field.1324, align 4
  %stack.sub.1328 = sub i32 %local.check.owner.end.1323, %local.check.offset.1320
  %descriptor.owner.inside.1326 = icmp ule i32 %local.check.owner.end.1323, %context.value.1325
  %descriptor.offset.inside.1327 = icmp ule i32 %local.check.offset.1320, %local.check.owner.end.1323
  %descriptor.extent.inside.1329 = icmp ule i32 %local.check.extent.1321, %stack.sub.1328
  %descriptor.payload.inside.1330 = icmp ule i32 %local.check.payload.1322, %local.check.extent.1321
  %descriptor.owner.offset.valid.1331 = and i1 %descriptor.owner.inside.1326, %descriptor.offset.inside.1327
  %descriptor.range.inside.1333 = and i1 %descriptor.owner.offset.valid.1331, %descriptor.extent.inside.1329
  %descriptor.range.valid.1332 = and i1 %descriptor.range.inside.1333, %descriptor.payload.inside.1330
  br i1 %descriptor.range.valid.1332, label %descriptor.valid.1334, label %descriptor.invalid.1335
descriptor.invalid.1335:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1334:
  %descriptor.initialized.status.1336 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1320, i32 %local.check.extent.1321)
  %helper.ok.1337 = icmp eq i32 %descriptor.initialized.status.1336, 0
  br i1 %helper.ok.1337, label %helper.continue.1338, label %frame.failure.0
helper.continue.1338:
  br label %local.descriptor.checked.1319
local.descriptor.inactive.1318:
  br label %local.descriptor.checked.1319
local.descriptor.checked.1319:
  %local.is.active.1339 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1339, label %local.descriptor.active.1340, label %local.descriptor.inactive.1341
local.descriptor.active.1340:
  %local.check.offset.1343 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1344 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1345 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1346 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1347 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1348 = load i32, ptr %context.field.1347, align 4
  %stack.sub.1351 = sub i32 %local.check.owner.end.1346, %local.check.offset.1343
  %descriptor.owner.inside.1349 = icmp ule i32 %local.check.owner.end.1346, %context.value.1348
  %descriptor.offset.inside.1350 = icmp ule i32 %local.check.offset.1343, %local.check.owner.end.1346
  %descriptor.extent.inside.1352 = icmp ule i32 %local.check.extent.1344, %stack.sub.1351
  %descriptor.payload.inside.1353 = icmp ule i32 %local.check.payload.1345, %local.check.extent.1344
  %descriptor.owner.offset.valid.1354 = and i1 %descriptor.owner.inside.1349, %descriptor.offset.inside.1350
  %descriptor.range.inside.1356 = and i1 %descriptor.owner.offset.valid.1354, %descriptor.extent.inside.1352
  %descriptor.range.valid.1355 = and i1 %descriptor.range.inside.1356, %descriptor.payload.inside.1353
  br i1 %descriptor.range.valid.1355, label %descriptor.valid.1357, label %descriptor.invalid.1358
descriptor.invalid.1358:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1357:
  %descriptor.initialized.status.1359 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1343, i32 %local.check.extent.1344)
  %helper.ok.1360 = icmp eq i32 %descriptor.initialized.status.1359, 0
  br i1 %helper.ok.1360, label %helper.continue.1361, label %frame.failure.0
helper.continue.1361:
  br label %local.descriptor.checked.1342
local.descriptor.inactive.1341:
  br label %local.descriptor.checked.1342
local.descriptor.checked.1342:
  %local.is.active.1362 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1362, label %local.descriptor.active.1363, label %local.descriptor.inactive.1364
local.descriptor.active.1363:
  %local.check.offset.1366 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1367 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1368 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1369 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1370 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1371 = load i32, ptr %context.field.1370, align 4
  %stack.sub.1374 = sub i32 %local.check.owner.end.1369, %local.check.offset.1366
  %descriptor.owner.inside.1372 = icmp ule i32 %local.check.owner.end.1369, %context.value.1371
  %descriptor.offset.inside.1373 = icmp ule i32 %local.check.offset.1366, %local.check.owner.end.1369
  %descriptor.extent.inside.1375 = icmp ule i32 %local.check.extent.1367, %stack.sub.1374
  %descriptor.payload.inside.1376 = icmp ule i32 %local.check.payload.1368, %local.check.extent.1367
  %descriptor.owner.offset.valid.1377 = and i1 %descriptor.owner.inside.1372, %descriptor.offset.inside.1373
  %descriptor.range.inside.1379 = and i1 %descriptor.owner.offset.valid.1377, %descriptor.extent.inside.1375
  %descriptor.range.valid.1378 = and i1 %descriptor.range.inside.1379, %descriptor.payload.inside.1376
  br i1 %descriptor.range.valid.1378, label %descriptor.valid.1380, label %descriptor.invalid.1381
descriptor.invalid.1381:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1380:
  %descriptor.initialized.status.1382 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1366, i32 %local.check.extent.1367)
  %helper.ok.1383 = icmp eq i32 %descriptor.initialized.status.1382, 0
  br i1 %helper.ok.1383, label %helper.continue.1384, label %frame.failure.0
helper.continue.1384:
  br label %local.descriptor.checked.1365
local.descriptor.inactive.1364:
  br label %local.descriptor.checked.1365
local.descriptor.checked.1365:
  %local.is.active.1385 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1385, label %local.descriptor.active.1386, label %local.descriptor.inactive.1387
local.descriptor.active.1386:
  %local.check.offset.1389 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1390 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1391 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1392 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1393 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1394 = load i32, ptr %context.field.1393, align 4
  %stack.sub.1397 = sub i32 %local.check.owner.end.1392, %local.check.offset.1389
  %descriptor.owner.inside.1395 = icmp ule i32 %local.check.owner.end.1392, %context.value.1394
  %descriptor.offset.inside.1396 = icmp ule i32 %local.check.offset.1389, %local.check.owner.end.1392
  %descriptor.extent.inside.1398 = icmp ule i32 %local.check.extent.1390, %stack.sub.1397
  %descriptor.payload.inside.1399 = icmp ule i32 %local.check.payload.1391, %local.check.extent.1390
  %descriptor.owner.offset.valid.1400 = and i1 %descriptor.owner.inside.1395, %descriptor.offset.inside.1396
  %descriptor.range.inside.1402 = and i1 %descriptor.owner.offset.valid.1400, %descriptor.extent.inside.1398
  %descriptor.range.valid.1401 = and i1 %descriptor.range.inside.1402, %descriptor.payload.inside.1399
  br i1 %descriptor.range.valid.1401, label %descriptor.valid.1403, label %descriptor.invalid.1404
descriptor.invalid.1404:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1403:
  %descriptor.initialized.status.1405 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1389, i32 %local.check.extent.1390)
  %helper.ok.1406 = icmp eq i32 %descriptor.initialized.status.1405, 0
  br i1 %helper.ok.1406, label %helper.continue.1407, label %frame.failure.0
helper.continue.1407:
  br label %local.descriptor.checked.1388
local.descriptor.inactive.1387:
  br label %local.descriptor.checked.1388
local.descriptor.checked.1388:
  %step.status.1408 = call i32 @al_owning_charge_step(ptr %ctx, i32 29)
  %helper.ok.1409 = icmp eq i32 %step.status.1408, 0
  br i1 %helper.ok.1409, label %helper.continue.1410, label %frame.failure.0
helper.continue.1410:
  %context.field.1411 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1412 = load i32, ptr %context.field.1411, align 4
  store i1 false, ptr %local.active.26, align 1
  store i32 0, ptr %local.offset.27, align 4
  store i32 0, ptr %local.extent.28, align 4
  store i32 0, ptr %local.payload.29, align 4
  store i32 0, ptr %local.owner.end.30, align 4
  store i32 0, ptr %local.type.31, align 4
  store i1 false, ptr %local.active.32, align 1
  store i32 0, ptr %local.offset.33, align 4
  store i32 0, ptr %local.extent.34, align 4
  store i32 0, ptr %local.payload.35, align 4
  store i32 0, ptr %local.owner.end.36, align 4
  store i32 0, ptr %local.type.37, align 4
  %step.status.1413 = call i32 @al_owning_charge_step(ptr %ctx, i32 30)
  %helper.ok.1414 = icmp eq i32 %step.status.1413, 0
  br i1 %helper.ok.1414, label %helper.continue.1415, label %frame.failure.0
helper.continue.1415:
  %local.resolved.offset.1416 = load i32, ptr %local.offset.15, align 4
  %local.resolved.extent.1417 = load i32, ptr %local.extent.16, align 4
  %local.resolved.payload.1418 = load i32, ptr %local.payload.17, align 4
  %local.resolved.owner.end.1419 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1420 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1421 = load i32, ptr %context.field.1420, align 4
  %stack.sub.1424 = sub i32 %local.resolved.owner.end.1419, %local.resolved.offset.1416
  %descriptor.owner.inside.1422 = icmp ule i32 %local.resolved.owner.end.1419, %context.value.1421
  %descriptor.offset.inside.1423 = icmp ule i32 %local.resolved.offset.1416, %local.resolved.owner.end.1419
  %descriptor.extent.inside.1425 = icmp ule i32 %local.resolved.extent.1417, %stack.sub.1424
  %descriptor.payload.inside.1426 = icmp ule i32 %local.resolved.payload.1418, %local.resolved.extent.1417
  %descriptor.owner.offset.valid.1427 = and i1 %descriptor.owner.inside.1422, %descriptor.offset.inside.1423
  %descriptor.range.inside.1429 = and i1 %descriptor.owner.offset.valid.1427, %descriptor.extent.inside.1425
  %descriptor.range.valid.1428 = and i1 %descriptor.range.inside.1429, %descriptor.payload.inside.1426
  %descriptor.type.valid.1430 = icmp eq i32 6, 6
  %descriptor.valid.1431 = and i1 %descriptor.range.valid.1428, %descriptor.type.valid.1430
  br i1 %descriptor.valid.1431, label %descriptor.valid.1432, label %descriptor.invalid.1433
descriptor.invalid.1433:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1432:
  %descriptor.initialized.status.1434 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1416, i32 %local.resolved.extent.1417)
  %helper.ok.1435 = icmp eq i32 %descriptor.initialized.status.1434, 0
  br i1 %helper.ok.1435, label %helper.continue.1436, label %frame.failure.0
helper.continue.1436:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %local.resolved.offset.1416, i32 20, i32 %local.resolved.payload.1418, i32 %local.resolved.owner.end.1419, i32 %local.resolved.extent.1417)
  %context.field.1437 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1438 = load i32, ptr %context.field.1437, align 4
  %runtime.ok.1439 = icmp eq i32 %context.value.1438, 0
  br i1 %runtime.ok.1439, label %runtime.continue.1440, label %frame.failure.0
runtime.continue.1440:
  %context.field.1441 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1442 = load i32, ptr %context.field.1441, align 4
  %stack.sub.1445 = sub i32 %local.resolved.owner.end.1419, %local.resolved.offset.1416
  %descriptor.owner.inside.1443 = icmp ule i32 %local.resolved.owner.end.1419, %context.value.1442
  %descriptor.offset.inside.1444 = icmp ule i32 %local.resolved.offset.1416, %local.resolved.owner.end.1419
  %descriptor.extent.inside.1446 = icmp ule i32 %local.resolved.extent.1417, %stack.sub.1445
  %descriptor.payload.inside.1447 = icmp ule i32 %local.resolved.payload.1418, %local.resolved.extent.1417
  %descriptor.owner.offset.valid.1448 = and i1 %descriptor.owner.inside.1443, %descriptor.offset.inside.1444
  %descriptor.range.inside.1450 = and i1 %descriptor.owner.offset.valid.1448, %descriptor.extent.inside.1446
  %descriptor.range.valid.1449 = and i1 %descriptor.range.inside.1450, %descriptor.payload.inside.1447
  %descriptor.type.valid.1451 = icmp eq i32 6, 6
  %descriptor.valid.1452 = and i1 %descriptor.range.valid.1449, %descriptor.type.valid.1451
  br i1 %descriptor.valid.1452, label %descriptor.valid.1453, label %descriptor.invalid.1454
descriptor.invalid.1454:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1453:
  %descriptor.initialized.status.1455 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1416, i32 %local.resolved.extent.1417)
  %helper.ok.1456 = icmp eq i32 %descriptor.initialized.status.1455, 0
  br i1 %helper.ok.1456, label %helper.continue.1457, label %frame.failure.0
helper.continue.1457:
  %local.is.active.1458 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1458, label %local.descriptor.active.1459, label %local.descriptor.inactive.1460
local.descriptor.active.1459:
  %local.check.offset.1462 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1463 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1464 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1465 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1466 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1467 = load i32, ptr %context.field.1466, align 4
  %stack.sub.1470 = sub i32 %local.check.owner.end.1465, %local.check.offset.1462
  %descriptor.owner.inside.1468 = icmp ule i32 %local.check.owner.end.1465, %context.value.1467
  %descriptor.offset.inside.1469 = icmp ule i32 %local.check.offset.1462, %local.check.owner.end.1465
  %descriptor.extent.inside.1471 = icmp ule i32 %local.check.extent.1463, %stack.sub.1470
  %descriptor.payload.inside.1472 = icmp ule i32 %local.check.payload.1464, %local.check.extent.1463
  %descriptor.owner.offset.valid.1473 = and i1 %descriptor.owner.inside.1468, %descriptor.offset.inside.1469
  %descriptor.range.inside.1475 = and i1 %descriptor.owner.offset.valid.1473, %descriptor.extent.inside.1471
  %descriptor.range.valid.1474 = and i1 %descriptor.range.inside.1475, %descriptor.payload.inside.1472
  br i1 %descriptor.range.valid.1474, label %descriptor.valid.1476, label %descriptor.invalid.1477
descriptor.invalid.1477:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1476:
  %descriptor.initialized.status.1478 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1462, i32 %local.check.extent.1463)
  %helper.ok.1479 = icmp eq i32 %descriptor.initialized.status.1478, 0
  br i1 %helper.ok.1479, label %helper.continue.1480, label %frame.failure.0
helper.continue.1480:
  br label %local.descriptor.checked.1461
local.descriptor.inactive.1460:
  br label %local.descriptor.checked.1461
local.descriptor.checked.1461:
  %local.is.active.1481 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1481, label %local.descriptor.active.1482, label %local.descriptor.inactive.1483
local.descriptor.active.1482:
  %local.check.offset.1485 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1486 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1487 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1488 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1489 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1490 = load i32, ptr %context.field.1489, align 4
  %stack.sub.1493 = sub i32 %local.check.owner.end.1488, %local.check.offset.1485
  %descriptor.owner.inside.1491 = icmp ule i32 %local.check.owner.end.1488, %context.value.1490
  %descriptor.offset.inside.1492 = icmp ule i32 %local.check.offset.1485, %local.check.owner.end.1488
  %descriptor.extent.inside.1494 = icmp ule i32 %local.check.extent.1486, %stack.sub.1493
  %descriptor.payload.inside.1495 = icmp ule i32 %local.check.payload.1487, %local.check.extent.1486
  %descriptor.owner.offset.valid.1496 = and i1 %descriptor.owner.inside.1491, %descriptor.offset.inside.1492
  %descriptor.range.inside.1498 = and i1 %descriptor.owner.offset.valid.1496, %descriptor.extent.inside.1494
  %descriptor.range.valid.1497 = and i1 %descriptor.range.inside.1498, %descriptor.payload.inside.1495
  br i1 %descriptor.range.valid.1497, label %descriptor.valid.1499, label %descriptor.invalid.1500
descriptor.invalid.1500:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1499:
  %descriptor.initialized.status.1501 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1485, i32 %local.check.extent.1486)
  %helper.ok.1502 = icmp eq i32 %descriptor.initialized.status.1501, 0
  br i1 %helper.ok.1502, label %helper.continue.1503, label %frame.failure.0
helper.continue.1503:
  br label %local.descriptor.checked.1484
local.descriptor.inactive.1483:
  br label %local.descriptor.checked.1484
local.descriptor.checked.1484:
  %local.is.active.1504 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1504, label %local.descriptor.active.1505, label %local.descriptor.inactive.1506
local.descriptor.active.1505:
  %local.check.offset.1508 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1509 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1510 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1511 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1512 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1513 = load i32, ptr %context.field.1512, align 4
  %stack.sub.1516 = sub i32 %local.check.owner.end.1511, %local.check.offset.1508
  %descriptor.owner.inside.1514 = icmp ule i32 %local.check.owner.end.1511, %context.value.1513
  %descriptor.offset.inside.1515 = icmp ule i32 %local.check.offset.1508, %local.check.owner.end.1511
  %descriptor.extent.inside.1517 = icmp ule i32 %local.check.extent.1509, %stack.sub.1516
  %descriptor.payload.inside.1518 = icmp ule i32 %local.check.payload.1510, %local.check.extent.1509
  %descriptor.owner.offset.valid.1519 = and i1 %descriptor.owner.inside.1514, %descriptor.offset.inside.1515
  %descriptor.range.inside.1521 = and i1 %descriptor.owner.offset.valid.1519, %descriptor.extent.inside.1517
  %descriptor.range.valid.1520 = and i1 %descriptor.range.inside.1521, %descriptor.payload.inside.1518
  br i1 %descriptor.range.valid.1520, label %descriptor.valid.1522, label %descriptor.invalid.1523
descriptor.invalid.1523:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1522:
  %descriptor.initialized.status.1524 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1508, i32 %local.check.extent.1509)
  %helper.ok.1525 = icmp eq i32 %descriptor.initialized.status.1524, 0
  br i1 %helper.ok.1525, label %helper.continue.1526, label %frame.failure.0
helper.continue.1526:
  br label %local.descriptor.checked.1507
local.descriptor.inactive.1506:
  br label %local.descriptor.checked.1507
local.descriptor.checked.1507:
  %local.is.active.1527 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1527, label %local.descriptor.active.1528, label %local.descriptor.inactive.1529
local.descriptor.active.1528:
  %local.check.offset.1531 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1532 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1533 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1534 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1535 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1536 = load i32, ptr %context.field.1535, align 4
  %stack.sub.1539 = sub i32 %local.check.owner.end.1534, %local.check.offset.1531
  %descriptor.owner.inside.1537 = icmp ule i32 %local.check.owner.end.1534, %context.value.1536
  %descriptor.offset.inside.1538 = icmp ule i32 %local.check.offset.1531, %local.check.owner.end.1534
  %descriptor.extent.inside.1540 = icmp ule i32 %local.check.extent.1532, %stack.sub.1539
  %descriptor.payload.inside.1541 = icmp ule i32 %local.check.payload.1533, %local.check.extent.1532
  %descriptor.owner.offset.valid.1542 = and i1 %descriptor.owner.inside.1537, %descriptor.offset.inside.1538
  %descriptor.range.inside.1544 = and i1 %descriptor.owner.offset.valid.1542, %descriptor.extent.inside.1540
  %descriptor.range.valid.1543 = and i1 %descriptor.range.inside.1544, %descriptor.payload.inside.1541
  br i1 %descriptor.range.valid.1543, label %descriptor.valid.1545, label %descriptor.invalid.1546
descriptor.invalid.1546:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1545:
  %descriptor.initialized.status.1547 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1531, i32 %local.check.extent.1532)
  %helper.ok.1548 = icmp eq i32 %descriptor.initialized.status.1547, 0
  br i1 %helper.ok.1548, label %helper.continue.1549, label %frame.failure.0
helper.continue.1549:
  br label %local.descriptor.checked.1530
local.descriptor.inactive.1529:
  br label %local.descriptor.checked.1530
local.descriptor.checked.1530:
  %local.is.active.1550 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1550, label %local.descriptor.active.1551, label %local.descriptor.inactive.1552
local.descriptor.active.1551:
  %local.check.offset.1554 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1555 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1556 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1557 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1558 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1559 = load i32, ptr %context.field.1558, align 4
  %stack.sub.1562 = sub i32 %local.check.owner.end.1557, %local.check.offset.1554
  %descriptor.owner.inside.1560 = icmp ule i32 %local.check.owner.end.1557, %context.value.1559
  %descriptor.offset.inside.1561 = icmp ule i32 %local.check.offset.1554, %local.check.owner.end.1557
  %descriptor.extent.inside.1563 = icmp ule i32 %local.check.extent.1555, %stack.sub.1562
  %descriptor.payload.inside.1564 = icmp ule i32 %local.check.payload.1556, %local.check.extent.1555
  %descriptor.owner.offset.valid.1565 = and i1 %descriptor.owner.inside.1560, %descriptor.offset.inside.1561
  %descriptor.range.inside.1567 = and i1 %descriptor.owner.offset.valid.1565, %descriptor.extent.inside.1563
  %descriptor.range.valid.1566 = and i1 %descriptor.range.inside.1567, %descriptor.payload.inside.1564
  br i1 %descriptor.range.valid.1566, label %descriptor.valid.1568, label %descriptor.invalid.1569
descriptor.invalid.1569:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1568:
  %descriptor.initialized.status.1570 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1554, i32 %local.check.extent.1555)
  %helper.ok.1571 = icmp eq i32 %descriptor.initialized.status.1570, 0
  br i1 %helper.ok.1571, label %helper.continue.1572, label %frame.failure.0
helper.continue.1572:
  br label %local.descriptor.checked.1553
local.descriptor.inactive.1552:
  br label %local.descriptor.checked.1553
local.descriptor.checked.1553:
  %local.is.active.1573 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1573, label %local.descriptor.active.1574, label %local.descriptor.inactive.1575
local.descriptor.active.1574:
  %local.check.offset.1577 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1578 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1579 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1580 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1581 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1582 = load i32, ptr %context.field.1581, align 4
  %stack.sub.1585 = sub i32 %local.check.owner.end.1580, %local.check.offset.1577
  %descriptor.owner.inside.1583 = icmp ule i32 %local.check.owner.end.1580, %context.value.1582
  %descriptor.offset.inside.1584 = icmp ule i32 %local.check.offset.1577, %local.check.owner.end.1580
  %descriptor.extent.inside.1586 = icmp ule i32 %local.check.extent.1578, %stack.sub.1585
  %descriptor.payload.inside.1587 = icmp ule i32 %local.check.payload.1579, %local.check.extent.1578
  %descriptor.owner.offset.valid.1588 = and i1 %descriptor.owner.inside.1583, %descriptor.offset.inside.1584
  %descriptor.range.inside.1590 = and i1 %descriptor.owner.offset.valid.1588, %descriptor.extent.inside.1586
  %descriptor.range.valid.1589 = and i1 %descriptor.range.inside.1590, %descriptor.payload.inside.1587
  br i1 %descriptor.range.valid.1589, label %descriptor.valid.1591, label %descriptor.invalid.1592
descriptor.invalid.1592:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1591:
  %descriptor.initialized.status.1593 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1577, i32 %local.check.extent.1578)
  %helper.ok.1594 = icmp eq i32 %descriptor.initialized.status.1593, 0
  br i1 %helper.ok.1594, label %helper.continue.1595, label %frame.failure.0
helper.continue.1595:
  br label %local.descriptor.checked.1576
local.descriptor.inactive.1575:
  br label %local.descriptor.checked.1576
local.descriptor.checked.1576:
  %step.status.1596 = call i32 @al_owning_charge_step(ptr %ctx, i32 31)
  %helper.ok.1597 = icmp eq i32 %step.status.1596, 0
  br i1 %helper.ok.1597, label %helper.continue.1598, label %frame.failure.0
helper.continue.1598:
  store i1 true, ptr %local.active.26, align 1
  store i32 %local.resolved.offset.1416, ptr %local.offset.27, align 4
  store i32 %local.resolved.extent.1417, ptr %local.extent.28, align 4
  store i32 %local.resolved.payload.1418, ptr %local.payload.29, align 4
  store i32 %local.resolved.owner.end.1419, ptr %local.owner.end.30, align 4
  store i32 6, ptr %local.type.31, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %local.resolved.offset.1416, i32 20, i32 %local.resolved.payload.1418, i32 %local.resolved.owner.end.1419, i32 %local.resolved.extent.1417)
  %context.field.1599 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1600 = load i32, ptr %context.field.1599, align 4
  %runtime.ok.1601 = icmp eq i32 %context.value.1600, 0
  br i1 %runtime.ok.1601, label %runtime.continue.1602, label %frame.failure.0
runtime.continue.1602:
  %local.is.active.1603 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1603, label %local.descriptor.active.1604, label %local.descriptor.inactive.1605
local.descriptor.active.1604:
  %local.check.offset.1607 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1608 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1609 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1610 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1611 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1612 = load i32, ptr %context.field.1611, align 4
  %stack.sub.1615 = sub i32 %local.check.owner.end.1610, %local.check.offset.1607
  %descriptor.owner.inside.1613 = icmp ule i32 %local.check.owner.end.1610, %context.value.1612
  %descriptor.offset.inside.1614 = icmp ule i32 %local.check.offset.1607, %local.check.owner.end.1610
  %descriptor.extent.inside.1616 = icmp ule i32 %local.check.extent.1608, %stack.sub.1615
  %descriptor.payload.inside.1617 = icmp ule i32 %local.check.payload.1609, %local.check.extent.1608
  %descriptor.owner.offset.valid.1618 = and i1 %descriptor.owner.inside.1613, %descriptor.offset.inside.1614
  %descriptor.range.inside.1620 = and i1 %descriptor.owner.offset.valid.1618, %descriptor.extent.inside.1616
  %descriptor.range.valid.1619 = and i1 %descriptor.range.inside.1620, %descriptor.payload.inside.1617
  br i1 %descriptor.range.valid.1619, label %descriptor.valid.1621, label %descriptor.invalid.1622
descriptor.invalid.1622:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1621:
  %descriptor.initialized.status.1623 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1607, i32 %local.check.extent.1608)
  %helper.ok.1624 = icmp eq i32 %descriptor.initialized.status.1623, 0
  br i1 %helper.ok.1624, label %helper.continue.1625, label %frame.failure.0
helper.continue.1625:
  br label %local.descriptor.checked.1606
local.descriptor.inactive.1605:
  br label %local.descriptor.checked.1606
local.descriptor.checked.1606:
  %local.is.active.1626 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1626, label %local.descriptor.active.1627, label %local.descriptor.inactive.1628
local.descriptor.active.1627:
  %local.check.offset.1630 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1631 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1632 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1633 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1634 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1635 = load i32, ptr %context.field.1634, align 4
  %stack.sub.1638 = sub i32 %local.check.owner.end.1633, %local.check.offset.1630
  %descriptor.owner.inside.1636 = icmp ule i32 %local.check.owner.end.1633, %context.value.1635
  %descriptor.offset.inside.1637 = icmp ule i32 %local.check.offset.1630, %local.check.owner.end.1633
  %descriptor.extent.inside.1639 = icmp ule i32 %local.check.extent.1631, %stack.sub.1638
  %descriptor.payload.inside.1640 = icmp ule i32 %local.check.payload.1632, %local.check.extent.1631
  %descriptor.owner.offset.valid.1641 = and i1 %descriptor.owner.inside.1636, %descriptor.offset.inside.1637
  %descriptor.range.inside.1643 = and i1 %descriptor.owner.offset.valid.1641, %descriptor.extent.inside.1639
  %descriptor.range.valid.1642 = and i1 %descriptor.range.inside.1643, %descriptor.payload.inside.1640
  br i1 %descriptor.range.valid.1642, label %descriptor.valid.1644, label %descriptor.invalid.1645
descriptor.invalid.1645:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1644:
  %descriptor.initialized.status.1646 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1630, i32 %local.check.extent.1631)
  %helper.ok.1647 = icmp eq i32 %descriptor.initialized.status.1646, 0
  br i1 %helper.ok.1647, label %helper.continue.1648, label %frame.failure.0
helper.continue.1648:
  br label %local.descriptor.checked.1629
local.descriptor.inactive.1628:
  br label %local.descriptor.checked.1629
local.descriptor.checked.1629:
  %local.is.active.1649 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1649, label %local.descriptor.active.1650, label %local.descriptor.inactive.1651
local.descriptor.active.1650:
  %local.check.offset.1653 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1654 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1655 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1656 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1657 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1658 = load i32, ptr %context.field.1657, align 4
  %stack.sub.1661 = sub i32 %local.check.owner.end.1656, %local.check.offset.1653
  %descriptor.owner.inside.1659 = icmp ule i32 %local.check.owner.end.1656, %context.value.1658
  %descriptor.offset.inside.1660 = icmp ule i32 %local.check.offset.1653, %local.check.owner.end.1656
  %descriptor.extent.inside.1662 = icmp ule i32 %local.check.extent.1654, %stack.sub.1661
  %descriptor.payload.inside.1663 = icmp ule i32 %local.check.payload.1655, %local.check.extent.1654
  %descriptor.owner.offset.valid.1664 = and i1 %descriptor.owner.inside.1659, %descriptor.offset.inside.1660
  %descriptor.range.inside.1666 = and i1 %descriptor.owner.offset.valid.1664, %descriptor.extent.inside.1662
  %descriptor.range.valid.1665 = and i1 %descriptor.range.inside.1666, %descriptor.payload.inside.1663
  br i1 %descriptor.range.valid.1665, label %descriptor.valid.1667, label %descriptor.invalid.1668
descriptor.invalid.1668:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1667:
  %descriptor.initialized.status.1669 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1653, i32 %local.check.extent.1654)
  %helper.ok.1670 = icmp eq i32 %descriptor.initialized.status.1669, 0
  br i1 %helper.ok.1670, label %helper.continue.1671, label %frame.failure.0
helper.continue.1671:
  br label %local.descriptor.checked.1652
local.descriptor.inactive.1651:
  br label %local.descriptor.checked.1652
local.descriptor.checked.1652:
  %local.is.active.1672 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1672, label %local.descriptor.active.1673, label %local.descriptor.inactive.1674
local.descriptor.active.1673:
  %local.check.offset.1676 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1677 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1678 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1679 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1680 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1681 = load i32, ptr %context.field.1680, align 4
  %stack.sub.1684 = sub i32 %local.check.owner.end.1679, %local.check.offset.1676
  %descriptor.owner.inside.1682 = icmp ule i32 %local.check.owner.end.1679, %context.value.1681
  %descriptor.offset.inside.1683 = icmp ule i32 %local.check.offset.1676, %local.check.owner.end.1679
  %descriptor.extent.inside.1685 = icmp ule i32 %local.check.extent.1677, %stack.sub.1684
  %descriptor.payload.inside.1686 = icmp ule i32 %local.check.payload.1678, %local.check.extent.1677
  %descriptor.owner.offset.valid.1687 = and i1 %descriptor.owner.inside.1682, %descriptor.offset.inside.1683
  %descriptor.range.inside.1689 = and i1 %descriptor.owner.offset.valid.1687, %descriptor.extent.inside.1685
  %descriptor.range.valid.1688 = and i1 %descriptor.range.inside.1689, %descriptor.payload.inside.1686
  br i1 %descriptor.range.valid.1688, label %descriptor.valid.1690, label %descriptor.invalid.1691
descriptor.invalid.1691:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1690:
  %descriptor.initialized.status.1692 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1676, i32 %local.check.extent.1677)
  %helper.ok.1693 = icmp eq i32 %descriptor.initialized.status.1692, 0
  br i1 %helper.ok.1693, label %helper.continue.1694, label %frame.failure.0
helper.continue.1694:
  br label %local.descriptor.checked.1675
local.descriptor.inactive.1674:
  br label %local.descriptor.checked.1675
local.descriptor.checked.1675:
  %local.is.active.1695 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1695, label %local.descriptor.active.1696, label %local.descriptor.inactive.1697
local.descriptor.active.1696:
  %local.check.offset.1699 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1700 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1701 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1702 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1703 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1704 = load i32, ptr %context.field.1703, align 4
  %stack.sub.1707 = sub i32 %local.check.owner.end.1702, %local.check.offset.1699
  %descriptor.owner.inside.1705 = icmp ule i32 %local.check.owner.end.1702, %context.value.1704
  %descriptor.offset.inside.1706 = icmp ule i32 %local.check.offset.1699, %local.check.owner.end.1702
  %descriptor.extent.inside.1708 = icmp ule i32 %local.check.extent.1700, %stack.sub.1707
  %descriptor.payload.inside.1709 = icmp ule i32 %local.check.payload.1701, %local.check.extent.1700
  %descriptor.owner.offset.valid.1710 = and i1 %descriptor.owner.inside.1705, %descriptor.offset.inside.1706
  %descriptor.range.inside.1712 = and i1 %descriptor.owner.offset.valid.1710, %descriptor.extent.inside.1708
  %descriptor.range.valid.1711 = and i1 %descriptor.range.inside.1712, %descriptor.payload.inside.1709
  br i1 %descriptor.range.valid.1711, label %descriptor.valid.1713, label %descriptor.invalid.1714
descriptor.invalid.1714:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1713:
  %descriptor.initialized.status.1715 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1699, i32 %local.check.extent.1700)
  %helper.ok.1716 = icmp eq i32 %descriptor.initialized.status.1715, 0
  br i1 %helper.ok.1716, label %helper.continue.1717, label %frame.failure.0
helper.continue.1717:
  br label %local.descriptor.checked.1698
local.descriptor.inactive.1697:
  br label %local.descriptor.checked.1698
local.descriptor.checked.1698:
  %local.is.active.1718 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1718, label %local.descriptor.active.1719, label %local.descriptor.inactive.1720
local.descriptor.active.1719:
  %local.check.offset.1722 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1723 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1724 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1725 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1726 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1727 = load i32, ptr %context.field.1726, align 4
  %stack.sub.1730 = sub i32 %local.check.owner.end.1725, %local.check.offset.1722
  %descriptor.owner.inside.1728 = icmp ule i32 %local.check.owner.end.1725, %context.value.1727
  %descriptor.offset.inside.1729 = icmp ule i32 %local.check.offset.1722, %local.check.owner.end.1725
  %descriptor.extent.inside.1731 = icmp ule i32 %local.check.extent.1723, %stack.sub.1730
  %descriptor.payload.inside.1732 = icmp ule i32 %local.check.payload.1724, %local.check.extent.1723
  %descriptor.owner.offset.valid.1733 = and i1 %descriptor.owner.inside.1728, %descriptor.offset.inside.1729
  %descriptor.range.inside.1735 = and i1 %descriptor.owner.offset.valid.1733, %descriptor.extent.inside.1731
  %descriptor.range.valid.1734 = and i1 %descriptor.range.inside.1735, %descriptor.payload.inside.1732
  br i1 %descriptor.range.valid.1734, label %descriptor.valid.1736, label %descriptor.invalid.1737
descriptor.invalid.1737:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1736:
  %descriptor.initialized.status.1738 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1722, i32 %local.check.extent.1723)
  %helper.ok.1739 = icmp eq i32 %descriptor.initialized.status.1738, 0
  br i1 %helper.ok.1739, label %helper.continue.1740, label %frame.failure.0
helper.continue.1740:
  br label %local.descriptor.checked.1721
local.descriptor.inactive.1720:
  br label %local.descriptor.checked.1721
local.descriptor.checked.1721:
  %step.status.1741 = call i32 @al_owning_charge_step(ptr %ctx, i32 32)
  %helper.ok.1742 = icmp eq i32 %step.status.1741, 0
  br i1 %helper.ok.1742, label %helper.continue.1743, label %frame.failure.0
helper.continue.1743:
  %local.resolved.offset.1744 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.1745 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.1746 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.1747 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1748 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1749 = load i32, ptr %context.field.1748, align 4
  %stack.sub.1752 = sub i32 %local.resolved.owner.end.1747, %local.resolved.offset.1744
  %descriptor.owner.inside.1750 = icmp ule i32 %local.resolved.owner.end.1747, %context.value.1749
  %descriptor.offset.inside.1751 = icmp ule i32 %local.resolved.offset.1744, %local.resolved.owner.end.1747
  %descriptor.extent.inside.1753 = icmp ule i32 %local.resolved.extent.1745, %stack.sub.1752
  %descriptor.payload.inside.1754 = icmp ule i32 %local.resolved.payload.1746, %local.resolved.extent.1745
  %descriptor.owner.offset.valid.1755 = and i1 %descriptor.owner.inside.1750, %descriptor.offset.inside.1751
  %descriptor.range.inside.1757 = and i1 %descriptor.owner.offset.valid.1755, %descriptor.extent.inside.1753
  %descriptor.range.valid.1756 = and i1 %descriptor.range.inside.1757, %descriptor.payload.inside.1754
  %descriptor.type.valid.1758 = icmp eq i32 1, 1
  %descriptor.valid.1759 = and i1 %descriptor.range.valid.1756, %descriptor.type.valid.1758
  br i1 %descriptor.valid.1759, label %descriptor.valid.1760, label %descriptor.invalid.1761
descriptor.invalid.1761:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1760:
  %descriptor.initialized.status.1762 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1744, i32 %local.resolved.extent.1745)
  %helper.ok.1763 = icmp eq i32 %descriptor.initialized.status.1762, 0
  br i1 %helper.ok.1763, label %helper.continue.1764, label %frame.failure.0
helper.continue.1764:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %local.resolved.offset.1744, i32 20, i32 %local.resolved.payload.1746, i32 %local.resolved.owner.end.1747, i32 %local.resolved.extent.1745)
  %context.field.1765 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1766 = load i32, ptr %context.field.1765, align 4
  %runtime.ok.1767 = icmp eq i32 %context.value.1766, 0
  br i1 %runtime.ok.1767, label %runtime.continue.1768, label %frame.failure.0
runtime.continue.1768:
  %context.field.1769 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1770 = load i32, ptr %context.field.1769, align 4
  %stack.sub.1773 = sub i32 %local.resolved.owner.end.1747, %local.resolved.offset.1744
  %descriptor.owner.inside.1771 = icmp ule i32 %local.resolved.owner.end.1747, %context.value.1770
  %descriptor.offset.inside.1772 = icmp ule i32 %local.resolved.offset.1744, %local.resolved.owner.end.1747
  %descriptor.extent.inside.1774 = icmp ule i32 %local.resolved.extent.1745, %stack.sub.1773
  %descriptor.payload.inside.1775 = icmp ule i32 %local.resolved.payload.1746, %local.resolved.extent.1745
  %descriptor.owner.offset.valid.1776 = and i1 %descriptor.owner.inside.1771, %descriptor.offset.inside.1772
  %descriptor.range.inside.1778 = and i1 %descriptor.owner.offset.valid.1776, %descriptor.extent.inside.1774
  %descriptor.range.valid.1777 = and i1 %descriptor.range.inside.1778, %descriptor.payload.inside.1775
  %descriptor.type.valid.1779 = icmp eq i32 1, 1
  %descriptor.valid.1780 = and i1 %descriptor.range.valid.1777, %descriptor.type.valid.1779
  br i1 %descriptor.valid.1780, label %descriptor.valid.1781, label %descriptor.invalid.1782
descriptor.invalid.1782:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1781:
  %descriptor.initialized.status.1783 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1744, i32 %local.resolved.extent.1745)
  %helper.ok.1784 = icmp eq i32 %descriptor.initialized.status.1783, 0
  br i1 %helper.ok.1784, label %helper.continue.1785, label %frame.failure.0
helper.continue.1785:
  %local.is.active.1786 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1786, label %local.descriptor.active.1787, label %local.descriptor.inactive.1788
local.descriptor.active.1787:
  %local.check.offset.1790 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1791 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1792 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1793 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1794 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1795 = load i32, ptr %context.field.1794, align 4
  %stack.sub.1798 = sub i32 %local.check.owner.end.1793, %local.check.offset.1790
  %descriptor.owner.inside.1796 = icmp ule i32 %local.check.owner.end.1793, %context.value.1795
  %descriptor.offset.inside.1797 = icmp ule i32 %local.check.offset.1790, %local.check.owner.end.1793
  %descriptor.extent.inside.1799 = icmp ule i32 %local.check.extent.1791, %stack.sub.1798
  %descriptor.payload.inside.1800 = icmp ule i32 %local.check.payload.1792, %local.check.extent.1791
  %descriptor.owner.offset.valid.1801 = and i1 %descriptor.owner.inside.1796, %descriptor.offset.inside.1797
  %descriptor.range.inside.1803 = and i1 %descriptor.owner.offset.valid.1801, %descriptor.extent.inside.1799
  %descriptor.range.valid.1802 = and i1 %descriptor.range.inside.1803, %descriptor.payload.inside.1800
  br i1 %descriptor.range.valid.1802, label %descriptor.valid.1804, label %descriptor.invalid.1805
descriptor.invalid.1805:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1804:
  %descriptor.initialized.status.1806 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1790, i32 %local.check.extent.1791)
  %helper.ok.1807 = icmp eq i32 %descriptor.initialized.status.1806, 0
  br i1 %helper.ok.1807, label %helper.continue.1808, label %frame.failure.0
helper.continue.1808:
  br label %local.descriptor.checked.1789
local.descriptor.inactive.1788:
  br label %local.descriptor.checked.1789
local.descriptor.checked.1789:
  %local.is.active.1809 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1809, label %local.descriptor.active.1810, label %local.descriptor.inactive.1811
local.descriptor.active.1810:
  %local.check.offset.1813 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1814 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1815 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1816 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1817 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1818 = load i32, ptr %context.field.1817, align 4
  %stack.sub.1821 = sub i32 %local.check.owner.end.1816, %local.check.offset.1813
  %descriptor.owner.inside.1819 = icmp ule i32 %local.check.owner.end.1816, %context.value.1818
  %descriptor.offset.inside.1820 = icmp ule i32 %local.check.offset.1813, %local.check.owner.end.1816
  %descriptor.extent.inside.1822 = icmp ule i32 %local.check.extent.1814, %stack.sub.1821
  %descriptor.payload.inside.1823 = icmp ule i32 %local.check.payload.1815, %local.check.extent.1814
  %descriptor.owner.offset.valid.1824 = and i1 %descriptor.owner.inside.1819, %descriptor.offset.inside.1820
  %descriptor.range.inside.1826 = and i1 %descriptor.owner.offset.valid.1824, %descriptor.extent.inside.1822
  %descriptor.range.valid.1825 = and i1 %descriptor.range.inside.1826, %descriptor.payload.inside.1823
  br i1 %descriptor.range.valid.1825, label %descriptor.valid.1827, label %descriptor.invalid.1828
descriptor.invalid.1828:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1827:
  %descriptor.initialized.status.1829 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1813, i32 %local.check.extent.1814)
  %helper.ok.1830 = icmp eq i32 %descriptor.initialized.status.1829, 0
  br i1 %helper.ok.1830, label %helper.continue.1831, label %frame.failure.0
helper.continue.1831:
  br label %local.descriptor.checked.1812
local.descriptor.inactive.1811:
  br label %local.descriptor.checked.1812
local.descriptor.checked.1812:
  %local.is.active.1832 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1832, label %local.descriptor.active.1833, label %local.descriptor.inactive.1834
local.descriptor.active.1833:
  %local.check.offset.1836 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1837 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1838 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1839 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1840 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1841 = load i32, ptr %context.field.1840, align 4
  %stack.sub.1844 = sub i32 %local.check.owner.end.1839, %local.check.offset.1836
  %descriptor.owner.inside.1842 = icmp ule i32 %local.check.owner.end.1839, %context.value.1841
  %descriptor.offset.inside.1843 = icmp ule i32 %local.check.offset.1836, %local.check.owner.end.1839
  %descriptor.extent.inside.1845 = icmp ule i32 %local.check.extent.1837, %stack.sub.1844
  %descriptor.payload.inside.1846 = icmp ule i32 %local.check.payload.1838, %local.check.extent.1837
  %descriptor.owner.offset.valid.1847 = and i1 %descriptor.owner.inside.1842, %descriptor.offset.inside.1843
  %descriptor.range.inside.1849 = and i1 %descriptor.owner.offset.valid.1847, %descriptor.extent.inside.1845
  %descriptor.range.valid.1848 = and i1 %descriptor.range.inside.1849, %descriptor.payload.inside.1846
  br i1 %descriptor.range.valid.1848, label %descriptor.valid.1850, label %descriptor.invalid.1851
descriptor.invalid.1851:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1850:
  %descriptor.initialized.status.1852 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1836, i32 %local.check.extent.1837)
  %helper.ok.1853 = icmp eq i32 %descriptor.initialized.status.1852, 0
  br i1 %helper.ok.1853, label %helper.continue.1854, label %frame.failure.0
helper.continue.1854:
  br label %local.descriptor.checked.1835
local.descriptor.inactive.1834:
  br label %local.descriptor.checked.1835
local.descriptor.checked.1835:
  %local.is.active.1855 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1855, label %local.descriptor.active.1856, label %local.descriptor.inactive.1857
local.descriptor.active.1856:
  %local.check.offset.1859 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1860 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1861 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1862 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1863 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1864 = load i32, ptr %context.field.1863, align 4
  %stack.sub.1867 = sub i32 %local.check.owner.end.1862, %local.check.offset.1859
  %descriptor.owner.inside.1865 = icmp ule i32 %local.check.owner.end.1862, %context.value.1864
  %descriptor.offset.inside.1866 = icmp ule i32 %local.check.offset.1859, %local.check.owner.end.1862
  %descriptor.extent.inside.1868 = icmp ule i32 %local.check.extent.1860, %stack.sub.1867
  %descriptor.payload.inside.1869 = icmp ule i32 %local.check.payload.1861, %local.check.extent.1860
  %descriptor.owner.offset.valid.1870 = and i1 %descriptor.owner.inside.1865, %descriptor.offset.inside.1866
  %descriptor.range.inside.1872 = and i1 %descriptor.owner.offset.valid.1870, %descriptor.extent.inside.1868
  %descriptor.range.valid.1871 = and i1 %descriptor.range.inside.1872, %descriptor.payload.inside.1869
  br i1 %descriptor.range.valid.1871, label %descriptor.valid.1873, label %descriptor.invalid.1874
descriptor.invalid.1874:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1873:
  %descriptor.initialized.status.1875 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1859, i32 %local.check.extent.1860)
  %helper.ok.1876 = icmp eq i32 %descriptor.initialized.status.1875, 0
  br i1 %helper.ok.1876, label %helper.continue.1877, label %frame.failure.0
helper.continue.1877:
  br label %local.descriptor.checked.1858
local.descriptor.inactive.1857:
  br label %local.descriptor.checked.1858
local.descriptor.checked.1858:
  %local.is.active.1878 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1878, label %local.descriptor.active.1879, label %local.descriptor.inactive.1880
local.descriptor.active.1879:
  %local.check.offset.1882 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1883 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1884 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1885 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1886 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1887 = load i32, ptr %context.field.1886, align 4
  %stack.sub.1890 = sub i32 %local.check.owner.end.1885, %local.check.offset.1882
  %descriptor.owner.inside.1888 = icmp ule i32 %local.check.owner.end.1885, %context.value.1887
  %descriptor.offset.inside.1889 = icmp ule i32 %local.check.offset.1882, %local.check.owner.end.1885
  %descriptor.extent.inside.1891 = icmp ule i32 %local.check.extent.1883, %stack.sub.1890
  %descriptor.payload.inside.1892 = icmp ule i32 %local.check.payload.1884, %local.check.extent.1883
  %descriptor.owner.offset.valid.1893 = and i1 %descriptor.owner.inside.1888, %descriptor.offset.inside.1889
  %descriptor.range.inside.1895 = and i1 %descriptor.owner.offset.valid.1893, %descriptor.extent.inside.1891
  %descriptor.range.valid.1894 = and i1 %descriptor.range.inside.1895, %descriptor.payload.inside.1892
  br i1 %descriptor.range.valid.1894, label %descriptor.valid.1896, label %descriptor.invalid.1897
descriptor.invalid.1897:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1896:
  %descriptor.initialized.status.1898 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1882, i32 %local.check.extent.1883)
  %helper.ok.1899 = icmp eq i32 %descriptor.initialized.status.1898, 0
  br i1 %helper.ok.1899, label %helper.continue.1900, label %frame.failure.0
helper.continue.1900:
  br label %local.descriptor.checked.1881
local.descriptor.inactive.1880:
  br label %local.descriptor.checked.1881
local.descriptor.checked.1881:
  %local.is.active.1901 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1901, label %local.descriptor.active.1902, label %local.descriptor.inactive.1903
local.descriptor.active.1902:
  %local.check.offset.1905 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1906 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1907 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1908 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1909 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1910 = load i32, ptr %context.field.1909, align 4
  %stack.sub.1913 = sub i32 %local.check.owner.end.1908, %local.check.offset.1905
  %descriptor.owner.inside.1911 = icmp ule i32 %local.check.owner.end.1908, %context.value.1910
  %descriptor.offset.inside.1912 = icmp ule i32 %local.check.offset.1905, %local.check.owner.end.1908
  %descriptor.extent.inside.1914 = icmp ule i32 %local.check.extent.1906, %stack.sub.1913
  %descriptor.payload.inside.1915 = icmp ule i32 %local.check.payload.1907, %local.check.extent.1906
  %descriptor.owner.offset.valid.1916 = and i1 %descriptor.owner.inside.1911, %descriptor.offset.inside.1912
  %descriptor.range.inside.1918 = and i1 %descriptor.owner.offset.valid.1916, %descriptor.extent.inside.1914
  %descriptor.range.valid.1917 = and i1 %descriptor.range.inside.1918, %descriptor.payload.inside.1915
  br i1 %descriptor.range.valid.1917, label %descriptor.valid.1919, label %descriptor.invalid.1920
descriptor.invalid.1920:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1919:
  %descriptor.initialized.status.1921 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1905, i32 %local.check.extent.1906)
  %helper.ok.1922 = icmp eq i32 %descriptor.initialized.status.1921, 0
  br i1 %helper.ok.1922, label %helper.continue.1923, label %frame.failure.0
helper.continue.1923:
  br label %local.descriptor.checked.1904
local.descriptor.inactive.1903:
  br label %local.descriptor.checked.1904
local.descriptor.checked.1904:
  %step.status.1924 = call i32 @al_owning_charge_step(ptr %ctx, i32 33)
  %helper.ok.1925 = icmp eq i32 %step.status.1924, 0
  br i1 %helper.ok.1925, label %helper.continue.1926, label %frame.failure.0
helper.continue.1926:
  store i1 true, ptr %local.active.32, align 1
  store i32 %local.resolved.offset.1744, ptr %local.offset.33, align 4
  store i32 %local.resolved.extent.1745, ptr %local.extent.34, align 4
  store i32 %local.resolved.payload.1746, ptr %local.payload.35, align 4
  store i32 %local.resolved.owner.end.1747, ptr %local.owner.end.36, align 4
  store i32 1, ptr %local.type.37, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %local.resolved.offset.1744, i32 20, i32 %local.resolved.payload.1746, i32 %local.resolved.owner.end.1747, i32 %local.resolved.extent.1745)
  %context.field.1927 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1928 = load i32, ptr %context.field.1927, align 4
  %runtime.ok.1929 = icmp eq i32 %context.value.1928, 0
  br i1 %runtime.ok.1929, label %runtime.continue.1930, label %frame.failure.0
runtime.continue.1930:
  %local.is.active.1931 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1931, label %local.descriptor.active.1932, label %local.descriptor.inactive.1933
local.descriptor.active.1932:
  %local.check.offset.1935 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1936 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1937 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1938 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1939 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1940 = load i32, ptr %context.field.1939, align 4
  %stack.sub.1943 = sub i32 %local.check.owner.end.1938, %local.check.offset.1935
  %descriptor.owner.inside.1941 = icmp ule i32 %local.check.owner.end.1938, %context.value.1940
  %descriptor.offset.inside.1942 = icmp ule i32 %local.check.offset.1935, %local.check.owner.end.1938
  %descriptor.extent.inside.1944 = icmp ule i32 %local.check.extent.1936, %stack.sub.1943
  %descriptor.payload.inside.1945 = icmp ule i32 %local.check.payload.1937, %local.check.extent.1936
  %descriptor.owner.offset.valid.1946 = and i1 %descriptor.owner.inside.1941, %descriptor.offset.inside.1942
  %descriptor.range.inside.1948 = and i1 %descriptor.owner.offset.valid.1946, %descriptor.extent.inside.1944
  %descriptor.range.valid.1947 = and i1 %descriptor.range.inside.1948, %descriptor.payload.inside.1945
  br i1 %descriptor.range.valid.1947, label %descriptor.valid.1949, label %descriptor.invalid.1950
descriptor.invalid.1950:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1949:
  %descriptor.initialized.status.1951 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1935, i32 %local.check.extent.1936)
  %helper.ok.1952 = icmp eq i32 %descriptor.initialized.status.1951, 0
  br i1 %helper.ok.1952, label %helper.continue.1953, label %frame.failure.0
helper.continue.1953:
  br label %local.descriptor.checked.1934
local.descriptor.inactive.1933:
  br label %local.descriptor.checked.1934
local.descriptor.checked.1934:
  %local.is.active.1954 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1954, label %local.descriptor.active.1955, label %local.descriptor.inactive.1956
local.descriptor.active.1955:
  %local.check.offset.1958 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1959 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1960 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1961 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1962 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1963 = load i32, ptr %context.field.1962, align 4
  %stack.sub.1966 = sub i32 %local.check.owner.end.1961, %local.check.offset.1958
  %descriptor.owner.inside.1964 = icmp ule i32 %local.check.owner.end.1961, %context.value.1963
  %descriptor.offset.inside.1965 = icmp ule i32 %local.check.offset.1958, %local.check.owner.end.1961
  %descriptor.extent.inside.1967 = icmp ule i32 %local.check.extent.1959, %stack.sub.1966
  %descriptor.payload.inside.1968 = icmp ule i32 %local.check.payload.1960, %local.check.extent.1959
  %descriptor.owner.offset.valid.1969 = and i1 %descriptor.owner.inside.1964, %descriptor.offset.inside.1965
  %descriptor.range.inside.1971 = and i1 %descriptor.owner.offset.valid.1969, %descriptor.extent.inside.1967
  %descriptor.range.valid.1970 = and i1 %descriptor.range.inside.1971, %descriptor.payload.inside.1968
  br i1 %descriptor.range.valid.1970, label %descriptor.valid.1972, label %descriptor.invalid.1973
descriptor.invalid.1973:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1972:
  %descriptor.initialized.status.1974 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1958, i32 %local.check.extent.1959)
  %helper.ok.1975 = icmp eq i32 %descriptor.initialized.status.1974, 0
  br i1 %helper.ok.1975, label %helper.continue.1976, label %frame.failure.0
helper.continue.1976:
  br label %local.descriptor.checked.1957
local.descriptor.inactive.1956:
  br label %local.descriptor.checked.1957
local.descriptor.checked.1957:
  %local.is.active.1977 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1977, label %local.descriptor.active.1978, label %local.descriptor.inactive.1979
local.descriptor.active.1978:
  %local.check.offset.1981 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1982 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1983 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1984 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1985 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1986 = load i32, ptr %context.field.1985, align 4
  %stack.sub.1989 = sub i32 %local.check.owner.end.1984, %local.check.offset.1981
  %descriptor.owner.inside.1987 = icmp ule i32 %local.check.owner.end.1984, %context.value.1986
  %descriptor.offset.inside.1988 = icmp ule i32 %local.check.offset.1981, %local.check.owner.end.1984
  %descriptor.extent.inside.1990 = icmp ule i32 %local.check.extent.1982, %stack.sub.1989
  %descriptor.payload.inside.1991 = icmp ule i32 %local.check.payload.1983, %local.check.extent.1982
  %descriptor.owner.offset.valid.1992 = and i1 %descriptor.owner.inside.1987, %descriptor.offset.inside.1988
  %descriptor.range.inside.1994 = and i1 %descriptor.owner.offset.valid.1992, %descriptor.extent.inside.1990
  %descriptor.range.valid.1993 = and i1 %descriptor.range.inside.1994, %descriptor.payload.inside.1991
  br i1 %descriptor.range.valid.1993, label %descriptor.valid.1995, label %descriptor.invalid.1996
descriptor.invalid.1996:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1995:
  %descriptor.initialized.status.1997 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1981, i32 %local.check.extent.1982)
  %helper.ok.1998 = icmp eq i32 %descriptor.initialized.status.1997, 0
  br i1 %helper.ok.1998, label %helper.continue.1999, label %frame.failure.0
helper.continue.1999:
  br label %local.descriptor.checked.1980
local.descriptor.inactive.1979:
  br label %local.descriptor.checked.1980
local.descriptor.checked.1980:
  %local.is.active.2000 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2000, label %local.descriptor.active.2001, label %local.descriptor.inactive.2002
local.descriptor.active.2001:
  %local.check.offset.2004 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2005 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2006 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2007 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2008 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2009 = load i32, ptr %context.field.2008, align 4
  %stack.sub.2012 = sub i32 %local.check.owner.end.2007, %local.check.offset.2004
  %descriptor.owner.inside.2010 = icmp ule i32 %local.check.owner.end.2007, %context.value.2009
  %descriptor.offset.inside.2011 = icmp ule i32 %local.check.offset.2004, %local.check.owner.end.2007
  %descriptor.extent.inside.2013 = icmp ule i32 %local.check.extent.2005, %stack.sub.2012
  %descriptor.payload.inside.2014 = icmp ule i32 %local.check.payload.2006, %local.check.extent.2005
  %descriptor.owner.offset.valid.2015 = and i1 %descriptor.owner.inside.2010, %descriptor.offset.inside.2011
  %descriptor.range.inside.2017 = and i1 %descriptor.owner.offset.valid.2015, %descriptor.extent.inside.2013
  %descriptor.range.valid.2016 = and i1 %descriptor.range.inside.2017, %descriptor.payload.inside.2014
  br i1 %descriptor.range.valid.2016, label %descriptor.valid.2018, label %descriptor.invalid.2019
descriptor.invalid.2019:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2018:
  %descriptor.initialized.status.2020 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2004, i32 %local.check.extent.2005)
  %helper.ok.2021 = icmp eq i32 %descriptor.initialized.status.2020, 0
  br i1 %helper.ok.2021, label %helper.continue.2022, label %frame.failure.0
helper.continue.2022:
  br label %local.descriptor.checked.2003
local.descriptor.inactive.2002:
  br label %local.descriptor.checked.2003
local.descriptor.checked.2003:
  %local.is.active.2023 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2023, label %local.descriptor.active.2024, label %local.descriptor.inactive.2025
local.descriptor.active.2024:
  %local.check.offset.2027 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2028 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2029 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2030 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2031 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2032 = load i32, ptr %context.field.2031, align 4
  %stack.sub.2035 = sub i32 %local.check.owner.end.2030, %local.check.offset.2027
  %descriptor.owner.inside.2033 = icmp ule i32 %local.check.owner.end.2030, %context.value.2032
  %descriptor.offset.inside.2034 = icmp ule i32 %local.check.offset.2027, %local.check.owner.end.2030
  %descriptor.extent.inside.2036 = icmp ule i32 %local.check.extent.2028, %stack.sub.2035
  %descriptor.payload.inside.2037 = icmp ule i32 %local.check.payload.2029, %local.check.extent.2028
  %descriptor.owner.offset.valid.2038 = and i1 %descriptor.owner.inside.2033, %descriptor.offset.inside.2034
  %descriptor.range.inside.2040 = and i1 %descriptor.owner.offset.valid.2038, %descriptor.extent.inside.2036
  %descriptor.range.valid.2039 = and i1 %descriptor.range.inside.2040, %descriptor.payload.inside.2037
  br i1 %descriptor.range.valid.2039, label %descriptor.valid.2041, label %descriptor.invalid.2042
descriptor.invalid.2042:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2041:
  %descriptor.initialized.status.2043 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2027, i32 %local.check.extent.2028)
  %helper.ok.2044 = icmp eq i32 %descriptor.initialized.status.2043, 0
  br i1 %helper.ok.2044, label %helper.continue.2045, label %frame.failure.0
helper.continue.2045:
  br label %local.descriptor.checked.2026
local.descriptor.inactive.2025:
  br label %local.descriptor.checked.2026
local.descriptor.checked.2026:
  %local.is.active.2046 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2046, label %local.descriptor.active.2047, label %local.descriptor.inactive.2048
local.descriptor.active.2047:
  %local.check.offset.2050 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2051 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2052 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2053 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2054 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2055 = load i32, ptr %context.field.2054, align 4
  %stack.sub.2058 = sub i32 %local.check.owner.end.2053, %local.check.offset.2050
  %descriptor.owner.inside.2056 = icmp ule i32 %local.check.owner.end.2053, %context.value.2055
  %descriptor.offset.inside.2057 = icmp ule i32 %local.check.offset.2050, %local.check.owner.end.2053
  %descriptor.extent.inside.2059 = icmp ule i32 %local.check.extent.2051, %stack.sub.2058
  %descriptor.payload.inside.2060 = icmp ule i32 %local.check.payload.2052, %local.check.extent.2051
  %descriptor.owner.offset.valid.2061 = and i1 %descriptor.owner.inside.2056, %descriptor.offset.inside.2057
  %descriptor.range.inside.2063 = and i1 %descriptor.owner.offset.valid.2061, %descriptor.extent.inside.2059
  %descriptor.range.valid.2062 = and i1 %descriptor.range.inside.2063, %descriptor.payload.inside.2060
  br i1 %descriptor.range.valid.2062, label %descriptor.valid.2064, label %descriptor.invalid.2065
descriptor.invalid.2065:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2064:
  %descriptor.initialized.status.2066 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2050, i32 %local.check.extent.2051)
  %helper.ok.2067 = icmp eq i32 %descriptor.initialized.status.2066, 0
  br i1 %helper.ok.2067, label %helper.continue.2068, label %frame.failure.0
helper.continue.2068:
  br label %local.descriptor.checked.2049
local.descriptor.inactive.2048:
  br label %local.descriptor.checked.2049
local.descriptor.checked.2049:
  %step.status.2069 = call i32 @al_owning_charge_step(ptr %ctx, i32 34)
  %helper.ok.2070 = icmp eq i32 %step.status.2069, 0
  br i1 %helper.ok.2070, label %helper.continue.2071, label %frame.failure.0
helper.continue.2071:
  %local.resolved.offset.2072 = load i32, ptr %local.offset.27, align 4
  %local.resolved.extent.2073 = load i32, ptr %local.extent.28, align 4
  %local.resolved.payload.2074 = load i32, ptr %local.payload.29, align 4
  %local.resolved.owner.end.2075 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2076 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2077 = load i32, ptr %context.field.2076, align 4
  %stack.sub.2080 = sub i32 %local.resolved.owner.end.2075, %local.resolved.offset.2072
  %descriptor.owner.inside.2078 = icmp ule i32 %local.resolved.owner.end.2075, %context.value.2077
  %descriptor.offset.inside.2079 = icmp ule i32 %local.resolved.offset.2072, %local.resolved.owner.end.2075
  %descriptor.extent.inside.2081 = icmp ule i32 %local.resolved.extent.2073, %stack.sub.2080
  %descriptor.payload.inside.2082 = icmp ule i32 %local.resolved.payload.2074, %local.resolved.extent.2073
  %descriptor.owner.offset.valid.2083 = and i1 %descriptor.owner.inside.2078, %descriptor.offset.inside.2079
  %descriptor.range.inside.2085 = and i1 %descriptor.owner.offset.valid.2083, %descriptor.extent.inside.2081
  %descriptor.range.valid.2084 = and i1 %descriptor.range.inside.2085, %descriptor.payload.inside.2082
  %descriptor.type.valid.2086 = icmp eq i32 6, 6
  %descriptor.valid.2087 = and i1 %descriptor.range.valid.2084, %descriptor.type.valid.2086
  br i1 %descriptor.valid.2087, label %descriptor.valid.2088, label %descriptor.invalid.2089
descriptor.invalid.2089:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2088:
  %descriptor.initialized.status.2090 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.2072, i32 %local.resolved.extent.2073)
  %helper.ok.2091 = icmp eq i32 %descriptor.initialized.status.2090, 0
  br i1 %helper.ok.2091, label %helper.continue.2092, label %frame.failure.0
helper.continue.2092:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %local.resolved.offset.2072, i32 20, i32 %local.resolved.payload.2074, i32 %local.resolved.owner.end.2075, i32 %local.resolved.extent.2073)
  %context.field.2093 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2094 = load i32, ptr %context.field.2093, align 4
  %runtime.ok.2095 = icmp eq i32 %context.value.2094, 0
  br i1 %runtime.ok.2095, label %runtime.continue.2096, label %frame.failure.0
runtime.continue.2096:
  %context.field.2097 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2098 = load i32, ptr %context.field.2097, align 4
  %stack.sub.2101 = sub i32 %local.resolved.owner.end.2075, %local.resolved.offset.2072
  %descriptor.owner.inside.2099 = icmp ule i32 %local.resolved.owner.end.2075, %context.value.2098
  %descriptor.offset.inside.2100 = icmp ule i32 %local.resolved.offset.2072, %local.resolved.owner.end.2075
  %descriptor.extent.inside.2102 = icmp ule i32 %local.resolved.extent.2073, %stack.sub.2101
  %descriptor.payload.inside.2103 = icmp ule i32 %local.resolved.payload.2074, %local.resolved.extent.2073
  %descriptor.owner.offset.valid.2104 = and i1 %descriptor.owner.inside.2099, %descriptor.offset.inside.2100
  %descriptor.range.inside.2106 = and i1 %descriptor.owner.offset.valid.2104, %descriptor.extent.inside.2102
  %descriptor.range.valid.2105 = and i1 %descriptor.range.inside.2106, %descriptor.payload.inside.2103
  %descriptor.type.valid.2107 = icmp eq i32 6, 6
  %descriptor.valid.2108 = and i1 %descriptor.range.valid.2105, %descriptor.type.valid.2107
  br i1 %descriptor.valid.2108, label %descriptor.valid.2109, label %descriptor.invalid.2110
descriptor.invalid.2110:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2109:
  %descriptor.initialized.status.2111 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.2072, i32 %local.resolved.extent.2073)
  %helper.ok.2112 = icmp eq i32 %descriptor.initialized.status.2111, 0
  br i1 %helper.ok.2112, label %helper.continue.2113, label %frame.failure.0
helper.continue.2113:
  %local.is.active.2114 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2114, label %local.descriptor.active.2115, label %local.descriptor.inactive.2116
local.descriptor.active.2115:
  %local.check.offset.2118 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2119 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2120 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2121 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2122 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2123 = load i32, ptr %context.field.2122, align 4
  %stack.sub.2126 = sub i32 %local.check.owner.end.2121, %local.check.offset.2118
  %descriptor.owner.inside.2124 = icmp ule i32 %local.check.owner.end.2121, %context.value.2123
  %descriptor.offset.inside.2125 = icmp ule i32 %local.check.offset.2118, %local.check.owner.end.2121
  %descriptor.extent.inside.2127 = icmp ule i32 %local.check.extent.2119, %stack.sub.2126
  %descriptor.payload.inside.2128 = icmp ule i32 %local.check.payload.2120, %local.check.extent.2119
  %descriptor.owner.offset.valid.2129 = and i1 %descriptor.owner.inside.2124, %descriptor.offset.inside.2125
  %descriptor.range.inside.2131 = and i1 %descriptor.owner.offset.valid.2129, %descriptor.extent.inside.2127
  %descriptor.range.valid.2130 = and i1 %descriptor.range.inside.2131, %descriptor.payload.inside.2128
  br i1 %descriptor.range.valid.2130, label %descriptor.valid.2132, label %descriptor.invalid.2133
descriptor.invalid.2133:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2132:
  %descriptor.initialized.status.2134 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2118, i32 %local.check.extent.2119)
  %helper.ok.2135 = icmp eq i32 %descriptor.initialized.status.2134, 0
  br i1 %helper.ok.2135, label %helper.continue.2136, label %frame.failure.0
helper.continue.2136:
  br label %local.descriptor.checked.2117
local.descriptor.inactive.2116:
  br label %local.descriptor.checked.2117
local.descriptor.checked.2117:
  %local.is.active.2137 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2137, label %local.descriptor.active.2138, label %local.descriptor.inactive.2139
local.descriptor.active.2138:
  %local.check.offset.2141 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2142 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2143 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2144 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2145 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2146 = load i32, ptr %context.field.2145, align 4
  %stack.sub.2149 = sub i32 %local.check.owner.end.2144, %local.check.offset.2141
  %descriptor.owner.inside.2147 = icmp ule i32 %local.check.owner.end.2144, %context.value.2146
  %descriptor.offset.inside.2148 = icmp ule i32 %local.check.offset.2141, %local.check.owner.end.2144
  %descriptor.extent.inside.2150 = icmp ule i32 %local.check.extent.2142, %stack.sub.2149
  %descriptor.payload.inside.2151 = icmp ule i32 %local.check.payload.2143, %local.check.extent.2142
  %descriptor.owner.offset.valid.2152 = and i1 %descriptor.owner.inside.2147, %descriptor.offset.inside.2148
  %descriptor.range.inside.2154 = and i1 %descriptor.owner.offset.valid.2152, %descriptor.extent.inside.2150
  %descriptor.range.valid.2153 = and i1 %descriptor.range.inside.2154, %descriptor.payload.inside.2151
  br i1 %descriptor.range.valid.2153, label %descriptor.valid.2155, label %descriptor.invalid.2156
descriptor.invalid.2156:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2155:
  %descriptor.initialized.status.2157 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2141, i32 %local.check.extent.2142)
  %helper.ok.2158 = icmp eq i32 %descriptor.initialized.status.2157, 0
  br i1 %helper.ok.2158, label %helper.continue.2159, label %frame.failure.0
helper.continue.2159:
  br label %local.descriptor.checked.2140
local.descriptor.inactive.2139:
  br label %local.descriptor.checked.2140
local.descriptor.checked.2140:
  %local.is.active.2160 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2160, label %local.descriptor.active.2161, label %local.descriptor.inactive.2162
local.descriptor.active.2161:
  %local.check.offset.2164 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2165 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2166 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2167 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2168 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2169 = load i32, ptr %context.field.2168, align 4
  %stack.sub.2172 = sub i32 %local.check.owner.end.2167, %local.check.offset.2164
  %descriptor.owner.inside.2170 = icmp ule i32 %local.check.owner.end.2167, %context.value.2169
  %descriptor.offset.inside.2171 = icmp ule i32 %local.check.offset.2164, %local.check.owner.end.2167
  %descriptor.extent.inside.2173 = icmp ule i32 %local.check.extent.2165, %stack.sub.2172
  %descriptor.payload.inside.2174 = icmp ule i32 %local.check.payload.2166, %local.check.extent.2165
  %descriptor.owner.offset.valid.2175 = and i1 %descriptor.owner.inside.2170, %descriptor.offset.inside.2171
  %descriptor.range.inside.2177 = and i1 %descriptor.owner.offset.valid.2175, %descriptor.extent.inside.2173
  %descriptor.range.valid.2176 = and i1 %descriptor.range.inside.2177, %descriptor.payload.inside.2174
  br i1 %descriptor.range.valid.2176, label %descriptor.valid.2178, label %descriptor.invalid.2179
descriptor.invalid.2179:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2178:
  %descriptor.initialized.status.2180 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2164, i32 %local.check.extent.2165)
  %helper.ok.2181 = icmp eq i32 %descriptor.initialized.status.2180, 0
  br i1 %helper.ok.2181, label %helper.continue.2182, label %frame.failure.0
helper.continue.2182:
  br label %local.descriptor.checked.2163
local.descriptor.inactive.2162:
  br label %local.descriptor.checked.2163
local.descriptor.checked.2163:
  %local.is.active.2183 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2183, label %local.descriptor.active.2184, label %local.descriptor.inactive.2185
local.descriptor.active.2184:
  %local.check.offset.2187 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2188 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2189 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2190 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2191 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2192 = load i32, ptr %context.field.2191, align 4
  %stack.sub.2195 = sub i32 %local.check.owner.end.2190, %local.check.offset.2187
  %descriptor.owner.inside.2193 = icmp ule i32 %local.check.owner.end.2190, %context.value.2192
  %descriptor.offset.inside.2194 = icmp ule i32 %local.check.offset.2187, %local.check.owner.end.2190
  %descriptor.extent.inside.2196 = icmp ule i32 %local.check.extent.2188, %stack.sub.2195
  %descriptor.payload.inside.2197 = icmp ule i32 %local.check.payload.2189, %local.check.extent.2188
  %descriptor.owner.offset.valid.2198 = and i1 %descriptor.owner.inside.2193, %descriptor.offset.inside.2194
  %descriptor.range.inside.2200 = and i1 %descriptor.owner.offset.valid.2198, %descriptor.extent.inside.2196
  %descriptor.range.valid.2199 = and i1 %descriptor.range.inside.2200, %descriptor.payload.inside.2197
  br i1 %descriptor.range.valid.2199, label %descriptor.valid.2201, label %descriptor.invalid.2202
descriptor.invalid.2202:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2201:
  %descriptor.initialized.status.2203 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2187, i32 %local.check.extent.2188)
  %helper.ok.2204 = icmp eq i32 %descriptor.initialized.status.2203, 0
  br i1 %helper.ok.2204, label %helper.continue.2205, label %frame.failure.0
helper.continue.2205:
  br label %local.descriptor.checked.2186
local.descriptor.inactive.2185:
  br label %local.descriptor.checked.2186
local.descriptor.checked.2186:
  %local.is.active.2206 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2206, label %local.descriptor.active.2207, label %local.descriptor.inactive.2208
local.descriptor.active.2207:
  %local.check.offset.2210 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2211 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2212 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2213 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2214 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2215 = load i32, ptr %context.field.2214, align 4
  %stack.sub.2218 = sub i32 %local.check.owner.end.2213, %local.check.offset.2210
  %descriptor.owner.inside.2216 = icmp ule i32 %local.check.owner.end.2213, %context.value.2215
  %descriptor.offset.inside.2217 = icmp ule i32 %local.check.offset.2210, %local.check.owner.end.2213
  %descriptor.extent.inside.2219 = icmp ule i32 %local.check.extent.2211, %stack.sub.2218
  %descriptor.payload.inside.2220 = icmp ule i32 %local.check.payload.2212, %local.check.extent.2211
  %descriptor.owner.offset.valid.2221 = and i1 %descriptor.owner.inside.2216, %descriptor.offset.inside.2217
  %descriptor.range.inside.2223 = and i1 %descriptor.owner.offset.valid.2221, %descriptor.extent.inside.2219
  %descriptor.range.valid.2222 = and i1 %descriptor.range.inside.2223, %descriptor.payload.inside.2220
  br i1 %descriptor.range.valid.2222, label %descriptor.valid.2224, label %descriptor.invalid.2225
descriptor.invalid.2225:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2224:
  %descriptor.initialized.status.2226 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2210, i32 %local.check.extent.2211)
  %helper.ok.2227 = icmp eq i32 %descriptor.initialized.status.2226, 0
  br i1 %helper.ok.2227, label %helper.continue.2228, label %frame.failure.0
helper.continue.2228:
  br label %local.descriptor.checked.2209
local.descriptor.inactive.2208:
  br label %local.descriptor.checked.2209
local.descriptor.checked.2209:
  %local.is.active.2229 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2229, label %local.descriptor.active.2230, label %local.descriptor.inactive.2231
local.descriptor.active.2230:
  %local.check.offset.2233 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2234 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2235 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2236 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2237 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2238 = load i32, ptr %context.field.2237, align 4
  %stack.sub.2241 = sub i32 %local.check.owner.end.2236, %local.check.offset.2233
  %descriptor.owner.inside.2239 = icmp ule i32 %local.check.owner.end.2236, %context.value.2238
  %descriptor.offset.inside.2240 = icmp ule i32 %local.check.offset.2233, %local.check.owner.end.2236
  %descriptor.extent.inside.2242 = icmp ule i32 %local.check.extent.2234, %stack.sub.2241
  %descriptor.payload.inside.2243 = icmp ule i32 %local.check.payload.2235, %local.check.extent.2234
  %descriptor.owner.offset.valid.2244 = and i1 %descriptor.owner.inside.2239, %descriptor.offset.inside.2240
  %descriptor.range.inside.2246 = and i1 %descriptor.owner.offset.valid.2244, %descriptor.extent.inside.2242
  %descriptor.range.valid.2245 = and i1 %descriptor.range.inside.2246, %descriptor.payload.inside.2243
  br i1 %descriptor.range.valid.2245, label %descriptor.valid.2247, label %descriptor.invalid.2248
descriptor.invalid.2248:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2247:
  %descriptor.initialized.status.2249 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2233, i32 %local.check.extent.2234)
  %helper.ok.2250 = icmp eq i32 %descriptor.initialized.status.2249, 0
  br i1 %helper.ok.2250, label %helper.continue.2251, label %frame.failure.0
helper.continue.2251:
  br label %local.descriptor.checked.2232
local.descriptor.inactive.2231:
  br label %local.descriptor.checked.2232
local.descriptor.checked.2232:
  %step.status.2252 = call i32 @al_owning_charge_step(ptr %ctx, i32 35)
  %helper.ok.2253 = icmp eq i32 %step.status.2252, 0
  br i1 %helper.ok.2253, label %helper.continue.2254, label %frame.failure.0
helper.continue.2254:
  %local.resolved.offset.2255 = load i32, ptr %local.offset.33, align 4
  %local.resolved.extent.2256 = load i32, ptr %local.extent.34, align 4
  %local.resolved.payload.2257 = load i32, ptr %local.payload.35, align 4
  %local.resolved.owner.end.2258 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2259 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2260 = load i32, ptr %context.field.2259, align 4
  %stack.sub.2263 = sub i32 %local.resolved.owner.end.2258, %local.resolved.offset.2255
  %descriptor.owner.inside.2261 = icmp ule i32 %local.resolved.owner.end.2258, %context.value.2260
  %descriptor.offset.inside.2262 = icmp ule i32 %local.resolved.offset.2255, %local.resolved.owner.end.2258
  %descriptor.extent.inside.2264 = icmp ule i32 %local.resolved.extent.2256, %stack.sub.2263
  %descriptor.payload.inside.2265 = icmp ule i32 %local.resolved.payload.2257, %local.resolved.extent.2256
  %descriptor.owner.offset.valid.2266 = and i1 %descriptor.owner.inside.2261, %descriptor.offset.inside.2262
  %descriptor.range.inside.2268 = and i1 %descriptor.owner.offset.valid.2266, %descriptor.extent.inside.2264
  %descriptor.range.valid.2267 = and i1 %descriptor.range.inside.2268, %descriptor.payload.inside.2265
  %descriptor.type.valid.2269 = icmp eq i32 1, 1
  %descriptor.valid.2270 = and i1 %descriptor.range.valid.2267, %descriptor.type.valid.2269
  br i1 %descriptor.valid.2270, label %descriptor.valid.2271, label %descriptor.invalid.2272
descriptor.invalid.2272:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2271:
  %descriptor.initialized.status.2273 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.2255, i32 %local.resolved.extent.2256)
  %helper.ok.2274 = icmp eq i32 %descriptor.initialized.status.2273, 0
  br i1 %helper.ok.2274, label %helper.continue.2275, label %frame.failure.0
helper.continue.2275:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %local.resolved.offset.2255, i32 20, i32 %local.resolved.payload.2257, i32 %local.resolved.owner.end.2258, i32 %local.resolved.extent.2256)
  %context.field.2276 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2277 = load i32, ptr %context.field.2276, align 4
  %runtime.ok.2278 = icmp eq i32 %context.value.2277, 0
  br i1 %runtime.ok.2278, label %runtime.continue.2279, label %frame.failure.0
runtime.continue.2279:
  %context.field.2280 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2281 = load i32, ptr %context.field.2280, align 4
  %stack.sub.2284 = sub i32 %local.resolved.owner.end.2075, %local.resolved.offset.2072
  %descriptor.owner.inside.2282 = icmp ule i32 %local.resolved.owner.end.2075, %context.value.2281
  %descriptor.offset.inside.2283 = icmp ule i32 %local.resolved.offset.2072, %local.resolved.owner.end.2075
  %descriptor.extent.inside.2285 = icmp ule i32 %local.resolved.extent.2073, %stack.sub.2284
  %descriptor.payload.inside.2286 = icmp ule i32 %local.resolved.payload.2074, %local.resolved.extent.2073
  %descriptor.owner.offset.valid.2287 = and i1 %descriptor.owner.inside.2282, %descriptor.offset.inside.2283
  %descriptor.range.inside.2289 = and i1 %descriptor.owner.offset.valid.2287, %descriptor.extent.inside.2285
  %descriptor.range.valid.2288 = and i1 %descriptor.range.inside.2289, %descriptor.payload.inside.2286
  %descriptor.type.valid.2290 = icmp eq i32 6, 6
  %descriptor.valid.2291 = and i1 %descriptor.range.valid.2288, %descriptor.type.valid.2290
  br i1 %descriptor.valid.2291, label %descriptor.valid.2292, label %descriptor.invalid.2293
descriptor.invalid.2293:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2292:
  %descriptor.initialized.status.2294 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.2072, i32 %local.resolved.extent.2073)
  %helper.ok.2295 = icmp eq i32 %descriptor.initialized.status.2294, 0
  br i1 %helper.ok.2295, label %helper.continue.2296, label %frame.failure.0
helper.continue.2296:
  %context.field.2297 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2298 = load i32, ptr %context.field.2297, align 4
  %stack.sub.2301 = sub i32 %local.resolved.owner.end.2258, %local.resolved.offset.2255
  %descriptor.owner.inside.2299 = icmp ule i32 %local.resolved.owner.end.2258, %context.value.2298
  %descriptor.offset.inside.2300 = icmp ule i32 %local.resolved.offset.2255, %local.resolved.owner.end.2258
  %descriptor.extent.inside.2302 = icmp ule i32 %local.resolved.extent.2256, %stack.sub.2301
  %descriptor.payload.inside.2303 = icmp ule i32 %local.resolved.payload.2257, %local.resolved.extent.2256
  %descriptor.owner.offset.valid.2304 = and i1 %descriptor.owner.inside.2299, %descriptor.offset.inside.2300
  %descriptor.range.inside.2306 = and i1 %descriptor.owner.offset.valid.2304, %descriptor.extent.inside.2302
  %descriptor.range.valid.2305 = and i1 %descriptor.range.inside.2306, %descriptor.payload.inside.2303
  %descriptor.type.valid.2307 = icmp eq i32 1, 1
  %descriptor.valid.2308 = and i1 %descriptor.range.valid.2305, %descriptor.type.valid.2307
  br i1 %descriptor.valid.2308, label %descriptor.valid.2309, label %descriptor.invalid.2310
descriptor.invalid.2310:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2309:
  %descriptor.initialized.status.2311 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.2255, i32 %local.resolved.extent.2256)
  %helper.ok.2312 = icmp eq i32 %descriptor.initialized.status.2311, 0
  br i1 %helper.ok.2312, label %helper.continue.2313, label %frame.failure.0
helper.continue.2313:
  %local.is.active.2314 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2314, label %local.descriptor.active.2315, label %local.descriptor.inactive.2316
local.descriptor.active.2315:
  %local.check.offset.2318 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2319 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2320 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2321 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2322 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2323 = load i32, ptr %context.field.2322, align 4
  %stack.sub.2326 = sub i32 %local.check.owner.end.2321, %local.check.offset.2318
  %descriptor.owner.inside.2324 = icmp ule i32 %local.check.owner.end.2321, %context.value.2323
  %descriptor.offset.inside.2325 = icmp ule i32 %local.check.offset.2318, %local.check.owner.end.2321
  %descriptor.extent.inside.2327 = icmp ule i32 %local.check.extent.2319, %stack.sub.2326
  %descriptor.payload.inside.2328 = icmp ule i32 %local.check.payload.2320, %local.check.extent.2319
  %descriptor.owner.offset.valid.2329 = and i1 %descriptor.owner.inside.2324, %descriptor.offset.inside.2325
  %descriptor.range.inside.2331 = and i1 %descriptor.owner.offset.valid.2329, %descriptor.extent.inside.2327
  %descriptor.range.valid.2330 = and i1 %descriptor.range.inside.2331, %descriptor.payload.inside.2328
  br i1 %descriptor.range.valid.2330, label %descriptor.valid.2332, label %descriptor.invalid.2333
descriptor.invalid.2333:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2332:
  %descriptor.initialized.status.2334 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2318, i32 %local.check.extent.2319)
  %helper.ok.2335 = icmp eq i32 %descriptor.initialized.status.2334, 0
  br i1 %helper.ok.2335, label %helper.continue.2336, label %frame.failure.0
helper.continue.2336:
  br label %local.descriptor.checked.2317
local.descriptor.inactive.2316:
  br label %local.descriptor.checked.2317
local.descriptor.checked.2317:
  %local.is.active.2337 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2337, label %local.descriptor.active.2338, label %local.descriptor.inactive.2339
local.descriptor.active.2338:
  %local.check.offset.2341 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2342 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2343 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2344 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2345 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2346 = load i32, ptr %context.field.2345, align 4
  %stack.sub.2349 = sub i32 %local.check.owner.end.2344, %local.check.offset.2341
  %descriptor.owner.inside.2347 = icmp ule i32 %local.check.owner.end.2344, %context.value.2346
  %descriptor.offset.inside.2348 = icmp ule i32 %local.check.offset.2341, %local.check.owner.end.2344
  %descriptor.extent.inside.2350 = icmp ule i32 %local.check.extent.2342, %stack.sub.2349
  %descriptor.payload.inside.2351 = icmp ule i32 %local.check.payload.2343, %local.check.extent.2342
  %descriptor.owner.offset.valid.2352 = and i1 %descriptor.owner.inside.2347, %descriptor.offset.inside.2348
  %descriptor.range.inside.2354 = and i1 %descriptor.owner.offset.valid.2352, %descriptor.extent.inside.2350
  %descriptor.range.valid.2353 = and i1 %descriptor.range.inside.2354, %descriptor.payload.inside.2351
  br i1 %descriptor.range.valid.2353, label %descriptor.valid.2355, label %descriptor.invalid.2356
descriptor.invalid.2356:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2355:
  %descriptor.initialized.status.2357 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2341, i32 %local.check.extent.2342)
  %helper.ok.2358 = icmp eq i32 %descriptor.initialized.status.2357, 0
  br i1 %helper.ok.2358, label %helper.continue.2359, label %frame.failure.0
helper.continue.2359:
  br label %local.descriptor.checked.2340
local.descriptor.inactive.2339:
  br label %local.descriptor.checked.2340
local.descriptor.checked.2340:
  %local.is.active.2360 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2360, label %local.descriptor.active.2361, label %local.descriptor.inactive.2362
local.descriptor.active.2361:
  %local.check.offset.2364 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2365 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2366 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2367 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2368 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2369 = load i32, ptr %context.field.2368, align 4
  %stack.sub.2372 = sub i32 %local.check.owner.end.2367, %local.check.offset.2364
  %descriptor.owner.inside.2370 = icmp ule i32 %local.check.owner.end.2367, %context.value.2369
  %descriptor.offset.inside.2371 = icmp ule i32 %local.check.offset.2364, %local.check.owner.end.2367
  %descriptor.extent.inside.2373 = icmp ule i32 %local.check.extent.2365, %stack.sub.2372
  %descriptor.payload.inside.2374 = icmp ule i32 %local.check.payload.2366, %local.check.extent.2365
  %descriptor.owner.offset.valid.2375 = and i1 %descriptor.owner.inside.2370, %descriptor.offset.inside.2371
  %descriptor.range.inside.2377 = and i1 %descriptor.owner.offset.valid.2375, %descriptor.extent.inside.2373
  %descriptor.range.valid.2376 = and i1 %descriptor.range.inside.2377, %descriptor.payload.inside.2374
  br i1 %descriptor.range.valid.2376, label %descriptor.valid.2378, label %descriptor.invalid.2379
descriptor.invalid.2379:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2378:
  %descriptor.initialized.status.2380 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2364, i32 %local.check.extent.2365)
  %helper.ok.2381 = icmp eq i32 %descriptor.initialized.status.2380, 0
  br i1 %helper.ok.2381, label %helper.continue.2382, label %frame.failure.0
helper.continue.2382:
  br label %local.descriptor.checked.2363
local.descriptor.inactive.2362:
  br label %local.descriptor.checked.2363
local.descriptor.checked.2363:
  %local.is.active.2383 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2383, label %local.descriptor.active.2384, label %local.descriptor.inactive.2385
local.descriptor.active.2384:
  %local.check.offset.2387 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2388 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2389 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2390 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2391 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2392 = load i32, ptr %context.field.2391, align 4
  %stack.sub.2395 = sub i32 %local.check.owner.end.2390, %local.check.offset.2387
  %descriptor.owner.inside.2393 = icmp ule i32 %local.check.owner.end.2390, %context.value.2392
  %descriptor.offset.inside.2394 = icmp ule i32 %local.check.offset.2387, %local.check.owner.end.2390
  %descriptor.extent.inside.2396 = icmp ule i32 %local.check.extent.2388, %stack.sub.2395
  %descriptor.payload.inside.2397 = icmp ule i32 %local.check.payload.2389, %local.check.extent.2388
  %descriptor.owner.offset.valid.2398 = and i1 %descriptor.owner.inside.2393, %descriptor.offset.inside.2394
  %descriptor.range.inside.2400 = and i1 %descriptor.owner.offset.valid.2398, %descriptor.extent.inside.2396
  %descriptor.range.valid.2399 = and i1 %descriptor.range.inside.2400, %descriptor.payload.inside.2397
  br i1 %descriptor.range.valid.2399, label %descriptor.valid.2401, label %descriptor.invalid.2402
descriptor.invalid.2402:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2401:
  %descriptor.initialized.status.2403 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2387, i32 %local.check.extent.2388)
  %helper.ok.2404 = icmp eq i32 %descriptor.initialized.status.2403, 0
  br i1 %helper.ok.2404, label %helper.continue.2405, label %frame.failure.0
helper.continue.2405:
  br label %local.descriptor.checked.2386
local.descriptor.inactive.2385:
  br label %local.descriptor.checked.2386
local.descriptor.checked.2386:
  %local.is.active.2406 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2406, label %local.descriptor.active.2407, label %local.descriptor.inactive.2408
local.descriptor.active.2407:
  %local.check.offset.2410 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2411 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2412 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2413 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2414 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2415 = load i32, ptr %context.field.2414, align 4
  %stack.sub.2418 = sub i32 %local.check.owner.end.2413, %local.check.offset.2410
  %descriptor.owner.inside.2416 = icmp ule i32 %local.check.owner.end.2413, %context.value.2415
  %descriptor.offset.inside.2417 = icmp ule i32 %local.check.offset.2410, %local.check.owner.end.2413
  %descriptor.extent.inside.2419 = icmp ule i32 %local.check.extent.2411, %stack.sub.2418
  %descriptor.payload.inside.2420 = icmp ule i32 %local.check.payload.2412, %local.check.extent.2411
  %descriptor.owner.offset.valid.2421 = and i1 %descriptor.owner.inside.2416, %descriptor.offset.inside.2417
  %descriptor.range.inside.2423 = and i1 %descriptor.owner.offset.valid.2421, %descriptor.extent.inside.2419
  %descriptor.range.valid.2422 = and i1 %descriptor.range.inside.2423, %descriptor.payload.inside.2420
  br i1 %descriptor.range.valid.2422, label %descriptor.valid.2424, label %descriptor.invalid.2425
descriptor.invalid.2425:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2424:
  %descriptor.initialized.status.2426 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2410, i32 %local.check.extent.2411)
  %helper.ok.2427 = icmp eq i32 %descriptor.initialized.status.2426, 0
  br i1 %helper.ok.2427, label %helper.continue.2428, label %frame.failure.0
helper.continue.2428:
  br label %local.descriptor.checked.2409
local.descriptor.inactive.2408:
  br label %local.descriptor.checked.2409
local.descriptor.checked.2409:
  %local.is.active.2429 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2429, label %local.descriptor.active.2430, label %local.descriptor.inactive.2431
local.descriptor.active.2430:
  %local.check.offset.2433 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2434 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2435 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2436 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2437 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2438 = load i32, ptr %context.field.2437, align 4
  %stack.sub.2441 = sub i32 %local.check.owner.end.2436, %local.check.offset.2433
  %descriptor.owner.inside.2439 = icmp ule i32 %local.check.owner.end.2436, %context.value.2438
  %descriptor.offset.inside.2440 = icmp ule i32 %local.check.offset.2433, %local.check.owner.end.2436
  %descriptor.extent.inside.2442 = icmp ule i32 %local.check.extent.2434, %stack.sub.2441
  %descriptor.payload.inside.2443 = icmp ule i32 %local.check.payload.2435, %local.check.extent.2434
  %descriptor.owner.offset.valid.2444 = and i1 %descriptor.owner.inside.2439, %descriptor.offset.inside.2440
  %descriptor.range.inside.2446 = and i1 %descriptor.owner.offset.valid.2444, %descriptor.extent.inside.2442
  %descriptor.range.valid.2445 = and i1 %descriptor.range.inside.2446, %descriptor.payload.inside.2443
  br i1 %descriptor.range.valid.2445, label %descriptor.valid.2447, label %descriptor.invalid.2448
descriptor.invalid.2448:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2447:
  %descriptor.initialized.status.2449 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2433, i32 %local.check.extent.2434)
  %helper.ok.2450 = icmp eq i32 %descriptor.initialized.status.2449, 0
  br i1 %helper.ok.2450, label %helper.continue.2451, label %frame.failure.0
helper.continue.2451:
  br label %local.descriptor.checked.2432
local.descriptor.inactive.2431:
  br label %local.descriptor.checked.2432
local.descriptor.checked.2432:
  %step.status.2452 = call i32 @al_owning_charge_step(ptr %ctx, i32 36)
  %helper.ok.2453 = icmp eq i32 %step.status.2452, 0
  br i1 %helper.ok.2453, label %helper.continue.2454, label %frame.failure.0
helper.continue.2454:
  %stack.offset.2455 = add i32 0, %local.resolved.payload.2074
  %stack.offset.2456 = add i32 %stack.offset.2455, %local.resolved.payload.2257
  %stack.offset.2457 = add i32 0, %local.resolved.extent.2073
  %stack.offset.2458 = add i32 %stack.offset.2457, %local.resolved.extent.2256
  %context.field.2459 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2460 = load i32, ptr %context.field.2459, align 4
  %stack.offset.2461 = add i32 %context.value.2460, %stack.offset.2458
  %reserve.status.2462 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.2461, i32 37)
  %reserve.ok.2463 = icmp eq i32 %reserve.status.2462, 0
  br i1 %reserve.ok.2463, label %reserve.continue.2464, label %frame.failure.0
reserve.continue.2464:
  %stack.offset.2465 = add i32 %context.value.2460, 0
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.2465, i32 %local.resolved.offset.2072, i32 %local.resolved.extent.2073, i32 %local.resolved.payload.2074, i32 6, i32 6)
  %context.field.2466 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2467 = load i32, ptr %context.field.2466, align 4
  %runtime.ok.2468 = icmp eq i32 %context.value.2467, 0
  br i1 %runtime.ok.2468, label %runtime.continue.2469, label %frame.failure.0
runtime.continue.2469:
  %stack.offset.2470 = add i32 0, %local.resolved.extent.2073
  %stack.offset.2471 = add i32 %context.value.2460, %stack.offset.2470
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.2471, i32 %local.resolved.offset.2255, i32 %local.resolved.extent.2256, i32 %local.resolved.payload.2257, i32 1, i32 6)
  %context.field.2472 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2473 = load i32, ptr %context.field.2472, align 4
  %runtime.ok.2474 = icmp eq i32 %context.value.2473, 0
  br i1 %runtime.ok.2474, label %runtime.continue.2475, label %frame.failure.0
runtime.continue.2475:
  %stack.offset.2476 = add i32 %stack.offset.2470, %local.resolved.extent.2256
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 5, i32 %context.value.2460, i32 %stack.offset.2458, i32 %stack.offset.2456, i32 0, i32 0)
  %context.field.2477 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2478 = load i32, ptr %context.field.2477, align 4
  %runtime.ok.2479 = icmp eq i32 %context.value.2478, 0
  br i1 %runtime.ok.2479, label %runtime.continue.2480, label %frame.failure.0
runtime.continue.2480:
  %context.field.2481 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2482 = load i32, ptr %context.field.2481, align 4
  %stack.sub.2485 = sub i32 %stack.offset.2461, %context.value.2460
  %descriptor.owner.inside.2483 = icmp ule i32 %stack.offset.2461, %context.value.2482
  %descriptor.offset.inside.2484 = icmp ule i32 %context.value.2460, %stack.offset.2461
  %descriptor.extent.inside.2486 = icmp ule i32 %stack.offset.2458, %stack.sub.2485
  %descriptor.payload.inside.2487 = icmp ule i32 %stack.offset.2456, %stack.offset.2458
  %descriptor.owner.offset.valid.2488 = and i1 %descriptor.owner.inside.2483, %descriptor.offset.inside.2484
  %descriptor.range.inside.2490 = and i1 %descriptor.owner.offset.valid.2488, %descriptor.extent.inside.2486
  %descriptor.range.valid.2489 = and i1 %descriptor.range.inside.2490, %descriptor.payload.inside.2487
  %descriptor.type.valid.2491 = icmp eq i32 5, 5
  %descriptor.valid.2492 = and i1 %descriptor.range.valid.2489, %descriptor.type.valid.2491
  br i1 %descriptor.valid.2492, label %descriptor.valid.2493, label %descriptor.invalid.2494
descriptor.invalid.2494:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2493:
  %descriptor.initialized.status.2495 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.2460, i32 %stack.offset.2458)
  %helper.ok.2496 = icmp eq i32 %descriptor.initialized.status.2495, 0
  br i1 %helper.ok.2496, label %helper.continue.2497, label %frame.failure.0
helper.continue.2497:
  %local.is.active.2498 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2498, label %local.descriptor.active.2499, label %local.descriptor.inactive.2500
local.descriptor.active.2499:
  %local.check.offset.2502 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2503 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2504 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2505 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2506 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2507 = load i32, ptr %context.field.2506, align 4
  %stack.sub.2510 = sub i32 %local.check.owner.end.2505, %local.check.offset.2502
  %descriptor.owner.inside.2508 = icmp ule i32 %local.check.owner.end.2505, %context.value.2507
  %descriptor.offset.inside.2509 = icmp ule i32 %local.check.offset.2502, %local.check.owner.end.2505
  %descriptor.extent.inside.2511 = icmp ule i32 %local.check.extent.2503, %stack.sub.2510
  %descriptor.payload.inside.2512 = icmp ule i32 %local.check.payload.2504, %local.check.extent.2503
  %descriptor.owner.offset.valid.2513 = and i1 %descriptor.owner.inside.2508, %descriptor.offset.inside.2509
  %descriptor.range.inside.2515 = and i1 %descriptor.owner.offset.valid.2513, %descriptor.extent.inside.2511
  %descriptor.range.valid.2514 = and i1 %descriptor.range.inside.2515, %descriptor.payload.inside.2512
  br i1 %descriptor.range.valid.2514, label %descriptor.valid.2516, label %descriptor.invalid.2517
descriptor.invalid.2517:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2516:
  %descriptor.initialized.status.2518 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2502, i32 %local.check.extent.2503)
  %helper.ok.2519 = icmp eq i32 %descriptor.initialized.status.2518, 0
  br i1 %helper.ok.2519, label %helper.continue.2520, label %frame.failure.0
helper.continue.2520:
  br label %local.descriptor.checked.2501
local.descriptor.inactive.2500:
  br label %local.descriptor.checked.2501
local.descriptor.checked.2501:
  %local.is.active.2521 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2521, label %local.descriptor.active.2522, label %local.descriptor.inactive.2523
local.descriptor.active.2522:
  %local.check.offset.2525 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2526 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2527 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2528 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2529 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2530 = load i32, ptr %context.field.2529, align 4
  %stack.sub.2533 = sub i32 %local.check.owner.end.2528, %local.check.offset.2525
  %descriptor.owner.inside.2531 = icmp ule i32 %local.check.owner.end.2528, %context.value.2530
  %descriptor.offset.inside.2532 = icmp ule i32 %local.check.offset.2525, %local.check.owner.end.2528
  %descriptor.extent.inside.2534 = icmp ule i32 %local.check.extent.2526, %stack.sub.2533
  %descriptor.payload.inside.2535 = icmp ule i32 %local.check.payload.2527, %local.check.extent.2526
  %descriptor.owner.offset.valid.2536 = and i1 %descriptor.owner.inside.2531, %descriptor.offset.inside.2532
  %descriptor.range.inside.2538 = and i1 %descriptor.owner.offset.valid.2536, %descriptor.extent.inside.2534
  %descriptor.range.valid.2537 = and i1 %descriptor.range.inside.2538, %descriptor.payload.inside.2535
  br i1 %descriptor.range.valid.2537, label %descriptor.valid.2539, label %descriptor.invalid.2540
descriptor.invalid.2540:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2539:
  %descriptor.initialized.status.2541 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2525, i32 %local.check.extent.2526)
  %helper.ok.2542 = icmp eq i32 %descriptor.initialized.status.2541, 0
  br i1 %helper.ok.2542, label %helper.continue.2543, label %frame.failure.0
helper.continue.2543:
  br label %local.descriptor.checked.2524
local.descriptor.inactive.2523:
  br label %local.descriptor.checked.2524
local.descriptor.checked.2524:
  %local.is.active.2544 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2544, label %local.descriptor.active.2545, label %local.descriptor.inactive.2546
local.descriptor.active.2545:
  %local.check.offset.2548 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2549 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2550 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2551 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2552 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2553 = load i32, ptr %context.field.2552, align 4
  %stack.sub.2556 = sub i32 %local.check.owner.end.2551, %local.check.offset.2548
  %descriptor.owner.inside.2554 = icmp ule i32 %local.check.owner.end.2551, %context.value.2553
  %descriptor.offset.inside.2555 = icmp ule i32 %local.check.offset.2548, %local.check.owner.end.2551
  %descriptor.extent.inside.2557 = icmp ule i32 %local.check.extent.2549, %stack.sub.2556
  %descriptor.payload.inside.2558 = icmp ule i32 %local.check.payload.2550, %local.check.extent.2549
  %descriptor.owner.offset.valid.2559 = and i1 %descriptor.owner.inside.2554, %descriptor.offset.inside.2555
  %descriptor.range.inside.2561 = and i1 %descriptor.owner.offset.valid.2559, %descriptor.extent.inside.2557
  %descriptor.range.valid.2560 = and i1 %descriptor.range.inside.2561, %descriptor.payload.inside.2558
  br i1 %descriptor.range.valid.2560, label %descriptor.valid.2562, label %descriptor.invalid.2563
descriptor.invalid.2563:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2562:
  %descriptor.initialized.status.2564 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2548, i32 %local.check.extent.2549)
  %helper.ok.2565 = icmp eq i32 %descriptor.initialized.status.2564, 0
  br i1 %helper.ok.2565, label %helper.continue.2566, label %frame.failure.0
helper.continue.2566:
  br label %local.descriptor.checked.2547
local.descriptor.inactive.2546:
  br label %local.descriptor.checked.2547
local.descriptor.checked.2547:
  %local.is.active.2567 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2567, label %local.descriptor.active.2568, label %local.descriptor.inactive.2569
local.descriptor.active.2568:
  %local.check.offset.2571 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2572 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2573 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2574 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2575 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2576 = load i32, ptr %context.field.2575, align 4
  %stack.sub.2579 = sub i32 %local.check.owner.end.2574, %local.check.offset.2571
  %descriptor.owner.inside.2577 = icmp ule i32 %local.check.owner.end.2574, %context.value.2576
  %descriptor.offset.inside.2578 = icmp ule i32 %local.check.offset.2571, %local.check.owner.end.2574
  %descriptor.extent.inside.2580 = icmp ule i32 %local.check.extent.2572, %stack.sub.2579
  %descriptor.payload.inside.2581 = icmp ule i32 %local.check.payload.2573, %local.check.extent.2572
  %descriptor.owner.offset.valid.2582 = and i1 %descriptor.owner.inside.2577, %descriptor.offset.inside.2578
  %descriptor.range.inside.2584 = and i1 %descriptor.owner.offset.valid.2582, %descriptor.extent.inside.2580
  %descriptor.range.valid.2583 = and i1 %descriptor.range.inside.2584, %descriptor.payload.inside.2581
  br i1 %descriptor.range.valid.2583, label %descriptor.valid.2585, label %descriptor.invalid.2586
descriptor.invalid.2586:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2585:
  %descriptor.initialized.status.2587 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2571, i32 %local.check.extent.2572)
  %helper.ok.2588 = icmp eq i32 %descriptor.initialized.status.2587, 0
  br i1 %helper.ok.2588, label %helper.continue.2589, label %frame.failure.0
helper.continue.2589:
  br label %local.descriptor.checked.2570
local.descriptor.inactive.2569:
  br label %local.descriptor.checked.2570
local.descriptor.checked.2570:
  %local.is.active.2590 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2590, label %local.descriptor.active.2591, label %local.descriptor.inactive.2592
local.descriptor.active.2591:
  %local.check.offset.2594 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2595 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2596 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2597 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2598 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2599 = load i32, ptr %context.field.2598, align 4
  %stack.sub.2602 = sub i32 %local.check.owner.end.2597, %local.check.offset.2594
  %descriptor.owner.inside.2600 = icmp ule i32 %local.check.owner.end.2597, %context.value.2599
  %descriptor.offset.inside.2601 = icmp ule i32 %local.check.offset.2594, %local.check.owner.end.2597
  %descriptor.extent.inside.2603 = icmp ule i32 %local.check.extent.2595, %stack.sub.2602
  %descriptor.payload.inside.2604 = icmp ule i32 %local.check.payload.2596, %local.check.extent.2595
  %descriptor.owner.offset.valid.2605 = and i1 %descriptor.owner.inside.2600, %descriptor.offset.inside.2601
  %descriptor.range.inside.2607 = and i1 %descriptor.owner.offset.valid.2605, %descriptor.extent.inside.2603
  %descriptor.range.valid.2606 = and i1 %descriptor.range.inside.2607, %descriptor.payload.inside.2604
  br i1 %descriptor.range.valid.2606, label %descriptor.valid.2608, label %descriptor.invalid.2609
descriptor.invalid.2609:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2608:
  %descriptor.initialized.status.2610 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2594, i32 %local.check.extent.2595)
  %helper.ok.2611 = icmp eq i32 %descriptor.initialized.status.2610, 0
  br i1 %helper.ok.2611, label %helper.continue.2612, label %frame.failure.0
helper.continue.2612:
  br label %local.descriptor.checked.2593
local.descriptor.inactive.2592:
  br label %local.descriptor.checked.2593
local.descriptor.checked.2593:
  %local.is.active.2613 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2613, label %local.descriptor.active.2614, label %local.descriptor.inactive.2615
local.descriptor.active.2614:
  %local.check.offset.2617 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2618 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2619 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2620 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2621 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2622 = load i32, ptr %context.field.2621, align 4
  %stack.sub.2625 = sub i32 %local.check.owner.end.2620, %local.check.offset.2617
  %descriptor.owner.inside.2623 = icmp ule i32 %local.check.owner.end.2620, %context.value.2622
  %descriptor.offset.inside.2624 = icmp ule i32 %local.check.offset.2617, %local.check.owner.end.2620
  %descriptor.extent.inside.2626 = icmp ule i32 %local.check.extent.2618, %stack.sub.2625
  %descriptor.payload.inside.2627 = icmp ule i32 %local.check.payload.2619, %local.check.extent.2618
  %descriptor.owner.offset.valid.2628 = and i1 %descriptor.owner.inside.2623, %descriptor.offset.inside.2624
  %descriptor.range.inside.2630 = and i1 %descriptor.owner.offset.valid.2628, %descriptor.extent.inside.2626
  %descriptor.range.valid.2629 = and i1 %descriptor.range.inside.2630, %descriptor.payload.inside.2627
  br i1 %descriptor.range.valid.2629, label %descriptor.valid.2631, label %descriptor.invalid.2632
descriptor.invalid.2632:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2631:
  %descriptor.initialized.status.2633 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2617, i32 %local.check.extent.2618)
  %helper.ok.2634 = icmp eq i32 %descriptor.initialized.status.2633, 0
  br i1 %helper.ok.2634, label %helper.continue.2635, label %frame.failure.0
helper.continue.2635:
  br label %local.descriptor.checked.2616
local.descriptor.inactive.2615:
  br label %local.descriptor.checked.2616
local.descriptor.checked.2616:
  store i1 false, ptr %local.active.32, align 1
  store i32 0, ptr %local.offset.33, align 4
  store i32 0, ptr %local.extent.34, align 4
  store i32 0, ptr %local.payload.35, align 4
  store i32 0, ptr %local.owner.end.36, align 4
  store i32 0, ptr %local.type.37, align 4
  store i1 false, ptr %local.active.26, align 1
  store i32 0, ptr %local.offset.27, align 4
  store i32 0, ptr %local.extent.28, align 4
  store i32 0, ptr %local.payload.29, align 4
  store i32 0, ptr %local.owner.end.30, align 4
  store i32 0, ptr %local.type.31, align 4
  %context.field.2636 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2637 = load i32, ptr %context.field.2636, align 4
  %stack.sub.2640 = sub i32 %stack.offset.2461, %context.value.2460
  %descriptor.owner.inside.2638 = icmp ule i32 %stack.offset.2461, %context.value.2637
  %descriptor.offset.inside.2639 = icmp ule i32 %context.value.2460, %stack.offset.2461
  %descriptor.extent.inside.2641 = icmp ule i32 %stack.offset.2458, %stack.sub.2640
  %descriptor.payload.inside.2642 = icmp ule i32 %stack.offset.2456, %stack.offset.2458
  %descriptor.owner.offset.valid.2643 = and i1 %descriptor.owner.inside.2638, %descriptor.offset.inside.2639
  %descriptor.range.inside.2645 = and i1 %descriptor.owner.offset.valid.2643, %descriptor.extent.inside.2641
  %descriptor.range.valid.2644 = and i1 %descriptor.range.inside.2645, %descriptor.payload.inside.2642
  %descriptor.type.valid.2646 = icmp eq i32 5, 5
  %descriptor.valid.2647 = and i1 %descriptor.range.valid.2644, %descriptor.type.valid.2646
  br i1 %descriptor.valid.2647, label %descriptor.valid.2648, label %descriptor.invalid.2649
descriptor.invalid.2649:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2648:
  %descriptor.initialized.status.2650 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.2460, i32 %stack.offset.2458)
  %helper.ok.2651 = icmp eq i32 %descriptor.initialized.status.2650, 0
  br i1 %helper.ok.2651, label %helper.continue.2652, label %frame.failure.0
helper.continue.2652:
  %local.is.active.2653 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2653, label %local.descriptor.active.2654, label %local.descriptor.inactive.2655
local.descriptor.active.2654:
  %local.check.offset.2657 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2658 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2659 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2660 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2661 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2662 = load i32, ptr %context.field.2661, align 4
  %stack.sub.2665 = sub i32 %local.check.owner.end.2660, %local.check.offset.2657
  %descriptor.owner.inside.2663 = icmp ule i32 %local.check.owner.end.2660, %context.value.2662
  %descriptor.offset.inside.2664 = icmp ule i32 %local.check.offset.2657, %local.check.owner.end.2660
  %descriptor.extent.inside.2666 = icmp ule i32 %local.check.extent.2658, %stack.sub.2665
  %descriptor.payload.inside.2667 = icmp ule i32 %local.check.payload.2659, %local.check.extent.2658
  %descriptor.owner.offset.valid.2668 = and i1 %descriptor.owner.inside.2663, %descriptor.offset.inside.2664
  %descriptor.range.inside.2670 = and i1 %descriptor.owner.offset.valid.2668, %descriptor.extent.inside.2666
  %descriptor.range.valid.2669 = and i1 %descriptor.range.inside.2670, %descriptor.payload.inside.2667
  br i1 %descriptor.range.valid.2669, label %descriptor.valid.2671, label %descriptor.invalid.2672
descriptor.invalid.2672:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2671:
  %descriptor.initialized.status.2673 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2657, i32 %local.check.extent.2658)
  %helper.ok.2674 = icmp eq i32 %descriptor.initialized.status.2673, 0
  br i1 %helper.ok.2674, label %helper.continue.2675, label %frame.failure.0
helper.continue.2675:
  br label %local.descriptor.checked.2656
local.descriptor.inactive.2655:
  br label %local.descriptor.checked.2656
local.descriptor.checked.2656:
  %local.is.active.2676 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2676, label %local.descriptor.active.2677, label %local.descriptor.inactive.2678
local.descriptor.active.2677:
  %local.check.offset.2680 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2681 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2682 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2683 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2684 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2685 = load i32, ptr %context.field.2684, align 4
  %stack.sub.2688 = sub i32 %local.check.owner.end.2683, %local.check.offset.2680
  %descriptor.owner.inside.2686 = icmp ule i32 %local.check.owner.end.2683, %context.value.2685
  %descriptor.offset.inside.2687 = icmp ule i32 %local.check.offset.2680, %local.check.owner.end.2683
  %descriptor.extent.inside.2689 = icmp ule i32 %local.check.extent.2681, %stack.sub.2688
  %descriptor.payload.inside.2690 = icmp ule i32 %local.check.payload.2682, %local.check.extent.2681
  %descriptor.owner.offset.valid.2691 = and i1 %descriptor.owner.inside.2686, %descriptor.offset.inside.2687
  %descriptor.range.inside.2693 = and i1 %descriptor.owner.offset.valid.2691, %descriptor.extent.inside.2689
  %descriptor.range.valid.2692 = and i1 %descriptor.range.inside.2693, %descriptor.payload.inside.2690
  br i1 %descriptor.range.valid.2692, label %descriptor.valid.2694, label %descriptor.invalid.2695
descriptor.invalid.2695:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2694:
  %descriptor.initialized.status.2696 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2680, i32 %local.check.extent.2681)
  %helper.ok.2697 = icmp eq i32 %descriptor.initialized.status.2696, 0
  br i1 %helper.ok.2697, label %helper.continue.2698, label %frame.failure.0
helper.continue.2698:
  br label %local.descriptor.checked.2679
local.descriptor.inactive.2678:
  br label %local.descriptor.checked.2679
local.descriptor.checked.2679:
  %local.is.active.2699 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2699, label %local.descriptor.active.2700, label %local.descriptor.inactive.2701
local.descriptor.active.2700:
  %local.check.offset.2703 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2704 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2705 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2706 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2707 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2708 = load i32, ptr %context.field.2707, align 4
  %stack.sub.2711 = sub i32 %local.check.owner.end.2706, %local.check.offset.2703
  %descriptor.owner.inside.2709 = icmp ule i32 %local.check.owner.end.2706, %context.value.2708
  %descriptor.offset.inside.2710 = icmp ule i32 %local.check.offset.2703, %local.check.owner.end.2706
  %descriptor.extent.inside.2712 = icmp ule i32 %local.check.extent.2704, %stack.sub.2711
  %descriptor.payload.inside.2713 = icmp ule i32 %local.check.payload.2705, %local.check.extent.2704
  %descriptor.owner.offset.valid.2714 = and i1 %descriptor.owner.inside.2709, %descriptor.offset.inside.2710
  %descriptor.range.inside.2716 = and i1 %descriptor.owner.offset.valid.2714, %descriptor.extent.inside.2712
  %descriptor.range.valid.2715 = and i1 %descriptor.range.inside.2716, %descriptor.payload.inside.2713
  br i1 %descriptor.range.valid.2715, label %descriptor.valid.2717, label %descriptor.invalid.2718
descriptor.invalid.2718:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2717:
  %descriptor.initialized.status.2719 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2703, i32 %local.check.extent.2704)
  %helper.ok.2720 = icmp eq i32 %descriptor.initialized.status.2719, 0
  br i1 %helper.ok.2720, label %helper.continue.2721, label %frame.failure.0
helper.continue.2721:
  br label %local.descriptor.checked.2702
local.descriptor.inactive.2701:
  br label %local.descriptor.checked.2702
local.descriptor.checked.2702:
  %local.is.active.2722 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2722, label %local.descriptor.active.2723, label %local.descriptor.inactive.2724
local.descriptor.active.2723:
  %local.check.offset.2726 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2727 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2728 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2729 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2730 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2731 = load i32, ptr %context.field.2730, align 4
  %stack.sub.2734 = sub i32 %local.check.owner.end.2729, %local.check.offset.2726
  %descriptor.owner.inside.2732 = icmp ule i32 %local.check.owner.end.2729, %context.value.2731
  %descriptor.offset.inside.2733 = icmp ule i32 %local.check.offset.2726, %local.check.owner.end.2729
  %descriptor.extent.inside.2735 = icmp ule i32 %local.check.extent.2727, %stack.sub.2734
  %descriptor.payload.inside.2736 = icmp ule i32 %local.check.payload.2728, %local.check.extent.2727
  %descriptor.owner.offset.valid.2737 = and i1 %descriptor.owner.inside.2732, %descriptor.offset.inside.2733
  %descriptor.range.inside.2739 = and i1 %descriptor.owner.offset.valid.2737, %descriptor.extent.inside.2735
  %descriptor.range.valid.2738 = and i1 %descriptor.range.inside.2739, %descriptor.payload.inside.2736
  br i1 %descriptor.range.valid.2738, label %descriptor.valid.2740, label %descriptor.invalid.2741
descriptor.invalid.2741:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2740:
  %descriptor.initialized.status.2742 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2726, i32 %local.check.extent.2727)
  %helper.ok.2743 = icmp eq i32 %descriptor.initialized.status.2742, 0
  br i1 %helper.ok.2743, label %helper.continue.2744, label %frame.failure.0
helper.continue.2744:
  br label %local.descriptor.checked.2725
local.descriptor.inactive.2724:
  br label %local.descriptor.checked.2725
local.descriptor.checked.2725:
  %local.is.active.2745 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2745, label %local.descriptor.active.2746, label %local.descriptor.inactive.2747
local.descriptor.active.2746:
  %local.check.offset.2749 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2750 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2751 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2752 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2753 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2754 = load i32, ptr %context.field.2753, align 4
  %stack.sub.2757 = sub i32 %local.check.owner.end.2752, %local.check.offset.2749
  %descriptor.owner.inside.2755 = icmp ule i32 %local.check.owner.end.2752, %context.value.2754
  %descriptor.offset.inside.2756 = icmp ule i32 %local.check.offset.2749, %local.check.owner.end.2752
  %descriptor.extent.inside.2758 = icmp ule i32 %local.check.extent.2750, %stack.sub.2757
  %descriptor.payload.inside.2759 = icmp ule i32 %local.check.payload.2751, %local.check.extent.2750
  %descriptor.owner.offset.valid.2760 = and i1 %descriptor.owner.inside.2755, %descriptor.offset.inside.2756
  %descriptor.range.inside.2762 = and i1 %descriptor.owner.offset.valid.2760, %descriptor.extent.inside.2758
  %descriptor.range.valid.2761 = and i1 %descriptor.range.inside.2762, %descriptor.payload.inside.2759
  br i1 %descriptor.range.valid.2761, label %descriptor.valid.2763, label %descriptor.invalid.2764
descriptor.invalid.2764:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2763:
  %descriptor.initialized.status.2765 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2749, i32 %local.check.extent.2750)
  %helper.ok.2766 = icmp eq i32 %descriptor.initialized.status.2765, 0
  br i1 %helper.ok.2766, label %helper.continue.2767, label %frame.failure.0
helper.continue.2767:
  br label %local.descriptor.checked.2748
local.descriptor.inactive.2747:
  br label %local.descriptor.checked.2748
local.descriptor.checked.2748:
  %local.is.active.2768 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2768, label %local.descriptor.active.2769, label %local.descriptor.inactive.2770
local.descriptor.active.2769:
  %local.check.offset.2772 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2773 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2774 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2775 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2776 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2777 = load i32, ptr %context.field.2776, align 4
  %stack.sub.2780 = sub i32 %local.check.owner.end.2775, %local.check.offset.2772
  %descriptor.owner.inside.2778 = icmp ule i32 %local.check.owner.end.2775, %context.value.2777
  %descriptor.offset.inside.2779 = icmp ule i32 %local.check.offset.2772, %local.check.owner.end.2775
  %descriptor.extent.inside.2781 = icmp ule i32 %local.check.extent.2773, %stack.sub.2780
  %descriptor.payload.inside.2782 = icmp ule i32 %local.check.payload.2774, %local.check.extent.2773
  %descriptor.owner.offset.valid.2783 = and i1 %descriptor.owner.inside.2778, %descriptor.offset.inside.2779
  %descriptor.range.inside.2785 = and i1 %descriptor.owner.offset.valid.2783, %descriptor.extent.inside.2781
  %descriptor.range.valid.2784 = and i1 %descriptor.range.inside.2785, %descriptor.payload.inside.2782
  br i1 %descriptor.range.valid.2784, label %descriptor.valid.2786, label %descriptor.invalid.2787
descriptor.invalid.2787:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2786:
  %descriptor.initialized.status.2788 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2772, i32 %local.check.extent.2773)
  %helper.ok.2789 = icmp eq i32 %descriptor.initialized.status.2788, 0
  br i1 %helper.ok.2789, label %helper.continue.2790, label %frame.failure.0
helper.continue.2790:
  br label %local.descriptor.checked.2771
local.descriptor.inactive.2770:
  br label %local.descriptor.checked.2771
local.descriptor.checked.2771:
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %descriptor.element.2791 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.2792 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.2791, i32 0, i32 0
  store i32 5, ptr %descriptor.field.2792, align 4
  %descriptor.field.2793 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.2791, i32 0, i32 1
  store i32 %context.value.2460, ptr %descriptor.field.2793, align 4
  %descriptor.field.2794 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.2791, i32 0, i32 2
  store i32 %stack.offset.2458, ptr %descriptor.field.2794, align 4
  %descriptor.field.2795 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.2791, i32 0, i32 3
  store i32 %stack.offset.2456, ptr %descriptor.field.2795, align 4
  %descriptor.field.2796 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.2791, i32 0, i32 4
  store i32 %stack.offset.2461, ptr %descriptor.field.2796, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %context.value.2460, i32 20, i32 %stack.offset.2456, i32 %stack.offset.2461, i32 %stack.offset.2458)
  %context.field.2797 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2798 = load i32, ptr %context.field.2797, align 4
  %runtime.ok.2799 = icmp eq i32 %context.value.2798, 0
  br i1 %runtime.ok.2799, label %runtime.continue.2800, label %frame.failure.0
runtime.continue.2800:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.39, i32 0, i32 0, i32 0)
  %context.field.2801 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.2802 = load i32, ptr %context.field.2801, align 4
  %context.field.2803 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.2804 = load i32, ptr %context.field.2803, align 4
  %context.field.2805 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.2806 = load i32, ptr %context.field.2805, align 4
  %stack.offset.2807 = add i32 %context.value.41, %context.value.43
  %stack.offset.2808 = add i32 %context.value.2802, %context.value.2804
  %stack.sub.2809 = sub i32 %stack.offset.2807, %stack.offset.2808
  %stack.sub.2810 = sub i32 %context.value.43, %context.value.2804
  %stack.sub.2811 = sub i32 %context.value.2806, %context.value.45
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.2809, i32 %stack.sub.2810)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.2811)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 0
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 0, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %input.total.exact.10 = icmp eq i32 0, %input.bytes
  br i1 %input.total.exact.10, label %input.valid.11, label %input.invalid.12
input.invalid.12:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 0, i32 %input.bytes)
  br label %entry.failure.0
input.valid.11:
  %reserve.status.13 = call i32 @al_owning_reserve_to(ptr %ctx, i32 0, i32 38)
  %reserve.ok.14 = icmp eq i32 %reserve.status.13, 0
  br i1 %reserve.ok.14, label %reserve.continue.15, label %entry.failure.0
reserve.continue.15:
  %entry.output.descriptors.16 = alloca [1 x %AlOwningDescriptor], align 4
  %entry.body.status.17 = call i32 @agentlang_entry_frame(ptr %ctx, ptr null, ptr %entry.output.descriptors.16, i32 39)
  %entry.body.ok.18 = icmp eq i32 %entry.body.status.17, 0
  br i1 %entry.body.ok.18, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.19 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.16, i32 0
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 0
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 1
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %descriptor.field.24 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 2
  %descriptor.value.25 = load i32, ptr %descriptor.field.24, align 4
  %descriptor.field.26 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 3
  %descriptor.value.27 = load i32, ptr %descriptor.field.26, align 4
  %descriptor.field.28 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 4
  %descriptor.value.29 = load i32, ptr %descriptor.field.28, align 4
  %entry.output.type.valid.30 = icmp eq i32 %descriptor.value.21, 7
  br i1 %entry.output.type.valid.30, label %entry.output.type.ok.31, label %entry.output.type.invalid.32
entry.output.type.invalid.32:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.31:
  %context.field.33 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.34 = load i32, ptr %context.field.33, align 4
  %stack.sub.37 = sub i32 %descriptor.value.29, %descriptor.value.23
  %descriptor.owner.inside.35 = icmp ule i32 %descriptor.value.29, %context.value.34
  %descriptor.offset.inside.36 = icmp ule i32 %descriptor.value.23, %descriptor.value.29
  %descriptor.extent.inside.38 = icmp ule i32 %descriptor.value.25, %stack.sub.37
  %descriptor.payload.inside.39 = icmp ule i32 %descriptor.value.27, %descriptor.value.25
  %descriptor.owner.offset.valid.40 = and i1 %descriptor.owner.inside.35, %descriptor.offset.inside.36
  %descriptor.range.inside.42 = and i1 %descriptor.owner.offset.valid.40, %descriptor.extent.inside.38
  %descriptor.range.valid.41 = and i1 %descriptor.range.inside.42, %descriptor.payload.inside.39
  %descriptor.type.valid.43 = icmp eq i32 7, 7
  %descriptor.valid.44 = and i1 %descriptor.range.valid.41, %descriptor.type.valid.43
  br i1 %descriptor.valid.44, label %descriptor.valid.45, label %descriptor.invalid.46
descriptor.invalid.46:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.45:
  %descriptor.initialized.status.47 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.23, i32 %descriptor.value.25)
  %helper.ok.48 = icmp eq i32 %descriptor.initialized.status.47, 0
  br i1 %helper.ok.48, label %helper.continue.49, label %entry.failure.0
helper.continue.49:
  %entry.output.size.i64.50 = zext i32 %descriptor.value.25 to i64
  %entry.output.total.i64.51 = add i64 0, %entry.output.size.i64.50
  %entry.retained.capacity.i64.52 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.53 = icmp ule i64 %entry.output.total.i64.51, 4294967295
  %entry.retained.required.truncated.54 = trunc i64 %entry.output.total.i64.51 to i32
  %entry.retained.required.55 = select i1 %entry.retained.required.fits.u32.53, i32 %entry.retained.required.truncated.54, i32 4294967295
  %entry.retained.capacity.ok.56 = icmp ule i64 %entry.output.total.i64.51, %entry.retained.capacity.i64.52
  br i1 %entry.retained.capacity.ok.56, label %entry.retained.capacity.ready.57, label %entry.retained.capacity.failure.58
entry.retained.capacity.failure.58:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.55, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.57:
  %host.pointer.59 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.60 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.59, i32 %stack.sub.60, i32 %descriptor.value.23, i32 %descriptor.value.25, i32 7)
  %context.field.61 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.62 = load i32, ptr %context.field.61, align 4
  %runtime.ok.63 = icmp eq i32 %context.value.62, 0
  br i1 %runtime.ok.63, label %runtime.continue.64, label %entry.failure.0
runtime.continue.64:
  %stack.offset.65 = add i32 0, %descriptor.value.25
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.66 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.67 = load i32, ptr %context.field.66, align 4
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %stack.sub.70 = sub i32 0, %context.value.67
  %stack.sub.71 = sub i32 0, %context.value.69
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.70, i32 %stack.sub.71)
  %context.field.72 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.73 = load i32, ptr %context.field.72, align 4
  %runtime.ok.74 = icmp eq i32 %context.value.73, 0
  br i1 %runtime.ok.74, label %runtime.continue.75, label %entry.failure.0
runtime.continue.75:
  br label %entry.return.status
entry.failure.0:
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %context.field.78 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.79 = load i32, ptr %context.field.78, align 4
  %context.field.80 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.81 = load i32, ptr %context.field.80, align 4
  %stack.offset.82 = add i32 %context.value.77, %context.value.79
  %stack.sub.83 = sub i32 0, %stack.offset.82
  %stack.sub.84 = sub i32 0, %context.value.79
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.83, i32 %stack.sub.84)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.81)
  br label %entry.return.status
entry.return.status:
  %context.field.85 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.86 = load i32, ptr %context.field.85, align 4
  ret i32 %context.value.86
}


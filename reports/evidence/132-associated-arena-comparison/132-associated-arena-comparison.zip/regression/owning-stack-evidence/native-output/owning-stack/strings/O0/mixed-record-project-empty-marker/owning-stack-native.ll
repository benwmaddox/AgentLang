%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [4 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8 }, %AlOwningTypeDescriptor { i32 4, i32 4, i32 0, i32 0, i32 0, i32 8, i32 0, i32 8 }, %AlOwningTypeDescriptor { i32 4, i32 10, i32 0, i32 3, i32 4294967295, i32 4294967295, i32 16, i32 16 }, %AlOwningTypeDescriptor { i32 5, i32 12, i32 3, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8 }], align 4
@al_owning_fields = private constant [3 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 1, i32 0, i32 1, i32 0 }, %AlOwningFieldDescriptor { i32 3, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 4294967295, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 1, ptr @al_owning_types, i32 4, ptr @al_owning_fields, i32 3 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 10
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 10, 10
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %step.status.43 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.44 = icmp eq i32 %step.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %frame.failure.0
helper.continue.45:
  %call.arguments.46 = alloca [1 x %AlOwningDescriptor], align 4
  %descriptor.element.47 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.46, i32 0
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 0
  store i32 10, ptr %descriptor.field.48, align 4
  %descriptor.field.49 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.49, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.50, align 4
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.51, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.52, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 10, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.53 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.54 = load i32, ptr %context.field.53, align 4
  %runtime.ok.55 = icmp eq i32 %context.value.54, 0
  br i1 %runtime.ok.55, label %runtime.continue.56, label %frame.failure.0
runtime.continue.56:
  %call.results.57 = alloca [1 x %AlOwningDescriptor], align 4
  %callee.status.58 = call i32 @agentlang_word_0000(ptr %ctx, ptr %call.arguments.46, ptr %call.results.57, i32 2)
  %helper.ok.59 = icmp eq i32 %callee.status.58, 0
  br i1 %helper.ok.59, label %helper.continue.60, label %frame.failure.0
helper.continue.60:
  %descriptor.element.61 = getelementptr inbounds %AlOwningDescriptor, ptr %call.results.57, i32 0
  %descriptor.field.62 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 0
  %descriptor.value.63 = load i32, ptr %descriptor.field.62, align 4
  %descriptor.field.64 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 1
  %descriptor.value.65 = load i32, ptr %descriptor.field.64, align 4
  %descriptor.field.66 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 2
  %descriptor.value.67 = load i32, ptr %descriptor.field.66, align 4
  %descriptor.field.68 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 3
  %descriptor.value.69 = load i32, ptr %descriptor.field.68, align 4
  %descriptor.field.70 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 4
  %descriptor.value.71 = load i32, ptr %descriptor.field.70, align 4
  %callee.result.type.valid.72 = icmp eq i32 %descriptor.value.63, 4
  br i1 %callee.result.type.valid.72, label %callee.result.type.ok.73, label %frame.failure.0
callee.result.type.ok.73:
  %context.field.74 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.75 = load i32, ptr %context.field.74, align 4
  %stack.sub.78 = sub i32 %descriptor.value.71, %descriptor.value.65
  %descriptor.owner.inside.76 = icmp ule i32 %descriptor.value.71, %context.value.75
  %descriptor.offset.inside.77 = icmp ule i32 %descriptor.value.65, %descriptor.value.71
  %descriptor.extent.inside.79 = icmp ule i32 %descriptor.value.67, %stack.sub.78
  %descriptor.payload.inside.80 = icmp ule i32 %descriptor.value.69, %descriptor.value.67
  %descriptor.owner.offset.valid.81 = and i1 %descriptor.owner.inside.76, %descriptor.offset.inside.77
  %descriptor.range.inside.83 = and i1 %descriptor.owner.offset.valid.81, %descriptor.extent.inside.79
  %descriptor.range.valid.82 = and i1 %descriptor.range.inside.83, %descriptor.payload.inside.80
  %descriptor.type.valid.84 = icmp eq i32 4, 4
  %descriptor.valid.85 = and i1 %descriptor.range.valid.82, %descriptor.type.valid.84
  br i1 %descriptor.valid.85, label %descriptor.valid.86, label %descriptor.invalid.87
descriptor.invalid.87:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.86:
  %descriptor.initialized.status.88 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.65, i32 %descriptor.value.67)
  %helper.ok.89 = icmp eq i32 %descriptor.initialized.status.88, 0
  br i1 %helper.ok.89, label %helper.continue.90, label %frame.failure.0
helper.continue.90:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %descriptor.value.65, i32 20, i32 %descriptor.value.69, i32 %descriptor.value.71, i32 %descriptor.value.67)
  %context.field.91 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.92 = load i32, ptr %context.field.91, align 4
  %runtime.ok.93 = icmp eq i32 %context.value.92, 0
  br i1 %runtime.ok.93, label %runtime.continue.94, label %frame.failure.0
runtime.continue.94:
  %context.field.95 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.96 = load i32, ptr %context.field.95, align 4
  %stack.sub.99 = sub i32 %descriptor.value.71, %descriptor.value.65
  %descriptor.owner.inside.97 = icmp ule i32 %descriptor.value.71, %context.value.96
  %descriptor.offset.inside.98 = icmp ule i32 %descriptor.value.65, %descriptor.value.71
  %descriptor.extent.inside.100 = icmp ule i32 %descriptor.value.67, %stack.sub.99
  %descriptor.payload.inside.101 = icmp ule i32 %descriptor.value.69, %descriptor.value.67
  %descriptor.owner.offset.valid.102 = and i1 %descriptor.owner.inside.97, %descriptor.offset.inside.98
  %descriptor.range.inside.104 = and i1 %descriptor.owner.offset.valid.102, %descriptor.extent.inside.100
  %descriptor.range.valid.103 = and i1 %descriptor.range.inside.104, %descriptor.payload.inside.101
  %descriptor.type.valid.105 = icmp eq i32 4, 4
  %descriptor.valid.106 = and i1 %descriptor.range.valid.103, %descriptor.type.valid.105
  br i1 %descriptor.valid.106, label %descriptor.valid.107, label %descriptor.invalid.108
descriptor.invalid.108:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.107:
  %descriptor.initialized.status.109 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.65, i32 %descriptor.value.67)
  %helper.ok.110 = icmp eq i32 %descriptor.initialized.status.109, 0
  br i1 %helper.ok.110, label %helper.continue.111, label %frame.failure.0
helper.continue.111:
  %descriptor.element.112 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.113 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 0
  store i32 4, ptr %descriptor.field.113, align 4
  %descriptor.field.114 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 1
  store i32 %descriptor.value.65, ptr %descriptor.field.114, align 4
  %descriptor.field.115 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 2
  store i32 %descriptor.value.67, ptr %descriptor.field.115, align 4
  %descriptor.field.116 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 3
  store i32 %descriptor.value.69, ptr %descriptor.field.116, align 4
  %descriptor.field.117 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.112, i32 0, i32 4
  store i32 %descriptor.value.71, ptr %descriptor.field.117, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %descriptor.value.65, i32 20, i32 %descriptor.value.69, i32 %descriptor.value.71, i32 %descriptor.value.67)
  %context.field.118 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.119 = load i32, ptr %context.field.118, align 4
  %runtime.ok.120 = icmp eq i32 %context.value.119, 0
  br i1 %runtime.ok.120, label %runtime.continue.121, label %frame.failure.0
runtime.continue.121:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.122 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.123 = load i32, ptr %context.field.122, align 4
  %context.field.124 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.125 = load i32, ptr %context.field.124, align 4
  %context.field.126 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.127 = load i32, ptr %context.field.126, align 4
  %stack.offset.128 = add i32 %context.value.5, %context.value.7
  %stack.offset.129 = add i32 %context.value.123, %context.value.125
  %stack.sub.130 = sub i32 %stack.offset.128, %stack.offset.129
  %stack.sub.131 = sub i32 %context.value.7, %context.value.125
  %stack.sub.132 = sub i32 %context.value.127, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.130, i32 %stack.sub.131)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.132)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %local.active.2 = alloca i1, align 1
  %local.offset.3 = alloca i32, align 4
  %local.extent.4 = alloca i32, align 4
  %local.payload.5 = alloca i32, align 4
  %local.owner.end.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %context.field.14 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.15 = load i32, ptr %context.field.14, align 4
  %frame.entered.16 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.17 = icmp eq i32 %frame.entered.16, 0
  br i1 %frame.enter.ok.17, label %frame.enter.continue.18, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.18:
  %descriptor.element.19 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 0
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 1
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %descriptor.field.24 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 2
  %descriptor.value.25 = load i32, ptr %descriptor.field.24, align 4
  %descriptor.field.26 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 3
  %descriptor.value.27 = load i32, ptr %descriptor.field.26, align 4
  %descriptor.field.28 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 4
  %descriptor.value.29 = load i32, ptr %descriptor.field.28, align 4
  %argument.type.valid.30 = icmp eq i32 %descriptor.value.21, 10
  br i1 %argument.type.valid.30, label %argument.type.ok.31, label %frame.failure.0
argument.type.ok.31:
  %context.field.32 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.33 = load i32, ptr %context.field.32, align 4
  %stack.sub.36 = sub i32 %descriptor.value.29, %descriptor.value.23
  %descriptor.owner.inside.34 = icmp ule i32 %descriptor.value.29, %context.value.33
  %descriptor.offset.inside.35 = icmp ule i32 %descriptor.value.23, %descriptor.value.29
  %descriptor.extent.inside.37 = icmp ule i32 %descriptor.value.25, %stack.sub.36
  %descriptor.payload.inside.38 = icmp ule i32 %descriptor.value.27, %descriptor.value.25
  %descriptor.owner.offset.valid.39 = and i1 %descriptor.owner.inside.34, %descriptor.offset.inside.35
  %descriptor.range.inside.41 = and i1 %descriptor.owner.offset.valid.39, %descriptor.extent.inside.37
  %descriptor.range.valid.40 = and i1 %descriptor.range.inside.41, %descriptor.payload.inside.38
  %descriptor.type.valid.42 = icmp eq i32 10, 10
  %descriptor.valid.43 = and i1 %descriptor.range.valid.40, %descriptor.type.valid.42
  br i1 %descriptor.valid.43, label %descriptor.valid.44, label %descriptor.invalid.45
descriptor.invalid.45:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.44:
  %descriptor.initialized.status.46 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.23, i32 %descriptor.value.25)
  %helper.ok.47 = icmp eq i32 %descriptor.initialized.status.46, 0
  br i1 %helper.ok.47, label %helper.continue.48, label %frame.failure.0
helper.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %helper.ok.50, label %helper.continue.51, label %frame.failure.0
helper.continue.51:
  store i1 true, ptr %local.active.2, align 1
  store i32 %descriptor.value.23, ptr %local.offset.3, align 4
  store i32 %descriptor.value.25, ptr %local.extent.4, align 4
  store i32 %descriptor.value.27, ptr %local.payload.5, align 4
  store i32 %descriptor.value.29, ptr %local.owner.end.6, align 4
  store i32 10, ptr %local.type.7, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 10, i32 %descriptor.value.23, i32 20, i32 %descriptor.value.27, i32 %descriptor.value.29, i32 %descriptor.value.25)
  %context.field.52 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.53 = load i32, ptr %context.field.52, align 4
  %runtime.ok.54 = icmp eq i32 %context.value.53, 0
  br i1 %runtime.ok.54, label %runtime.continue.55, label %frame.failure.0
runtime.continue.55:
  %local.is.active.56 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.56, label %local.descriptor.active.57, label %local.descriptor.inactive.58
local.descriptor.active.57:
  %local.check.offset.60 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.61 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.62 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.63 = load i32, ptr %local.owner.end.6, align 4
  %context.field.64 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.65 = load i32, ptr %context.field.64, align 4
  %stack.sub.68 = sub i32 %local.check.owner.end.63, %local.check.offset.60
  %descriptor.owner.inside.66 = icmp ule i32 %local.check.owner.end.63, %context.value.65
  %descriptor.offset.inside.67 = icmp ule i32 %local.check.offset.60, %local.check.owner.end.63
  %descriptor.extent.inside.69 = icmp ule i32 %local.check.extent.61, %stack.sub.68
  %descriptor.payload.inside.70 = icmp ule i32 %local.check.payload.62, %local.check.extent.61
  %descriptor.owner.offset.valid.71 = and i1 %descriptor.owner.inside.66, %descriptor.offset.inside.67
  %descriptor.range.inside.73 = and i1 %descriptor.owner.offset.valid.71, %descriptor.extent.inside.69
  %descriptor.range.valid.72 = and i1 %descriptor.range.inside.73, %descriptor.payload.inside.70
  br i1 %descriptor.range.valid.72, label %descriptor.valid.74, label %descriptor.invalid.75
descriptor.invalid.75:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.74:
  %descriptor.initialized.status.76 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.60, i32 %local.check.extent.61)
  %helper.ok.77 = icmp eq i32 %descriptor.initialized.status.76, 0
  br i1 %helper.ok.77, label %helper.continue.78, label %frame.failure.0
helper.continue.78:
  br label %local.descriptor.checked.59
local.descriptor.inactive.58:
  br label %local.descriptor.checked.59
local.descriptor.checked.59:
  %step.status.79 = call i32 @al_owning_charge_step(ptr %ctx, i32 4)
  %helper.ok.80 = icmp eq i32 %step.status.79, 0
  br i1 %helper.ok.80, label %helper.continue.81, label %frame.failure.0
helper.continue.81:
  %local.resolved.offset.82 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.83 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.84 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.85 = load i32, ptr %local.owner.end.6, align 4
  %context.field.86 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.87 = load i32, ptr %context.field.86, align 4
  %stack.sub.90 = sub i32 %local.resolved.owner.end.85, %local.resolved.offset.82
  %descriptor.owner.inside.88 = icmp ule i32 %local.resolved.owner.end.85, %context.value.87
  %descriptor.offset.inside.89 = icmp ule i32 %local.resolved.offset.82, %local.resolved.owner.end.85
  %descriptor.extent.inside.91 = icmp ule i32 %local.resolved.extent.83, %stack.sub.90
  %descriptor.payload.inside.92 = icmp ule i32 %local.resolved.payload.84, %local.resolved.extent.83
  %descriptor.owner.offset.valid.93 = and i1 %descriptor.owner.inside.88, %descriptor.offset.inside.89
  %descriptor.range.inside.95 = and i1 %descriptor.owner.offset.valid.93, %descriptor.extent.inside.91
  %descriptor.range.valid.94 = and i1 %descriptor.range.inside.95, %descriptor.payload.inside.92
  %descriptor.type.valid.96 = icmp eq i32 10, 10
  %descriptor.valid.97 = and i1 %descriptor.range.valid.94, %descriptor.type.valid.96
  br i1 %descriptor.valid.97, label %descriptor.valid.98, label %descriptor.invalid.99
descriptor.invalid.99:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.98:
  %descriptor.initialized.status.100 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.82, i32 %local.resolved.extent.83)
  %helper.ok.101 = icmp eq i32 %descriptor.initialized.status.100, 0
  br i1 %helper.ok.101, label %helper.continue.102, label %frame.failure.0
helper.continue.102:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 10, i32 %local.resolved.offset.82, i32 20, i32 %local.resolved.payload.84, i32 %local.resolved.owner.end.85, i32 %local.resolved.extent.83)
  %context.field.103 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.104 = load i32, ptr %context.field.103, align 4
  %runtime.ok.105 = icmp eq i32 %context.value.104, 0
  br i1 %runtime.ok.105, label %runtime.continue.106, label %frame.failure.0
runtime.continue.106:
  %context.field.107 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.108 = load i32, ptr %context.field.107, align 4
  %stack.sub.111 = sub i32 %local.resolved.owner.end.85, %local.resolved.offset.82
  %descriptor.owner.inside.109 = icmp ule i32 %local.resolved.owner.end.85, %context.value.108
  %descriptor.offset.inside.110 = icmp ule i32 %local.resolved.offset.82, %local.resolved.owner.end.85
  %descriptor.extent.inside.112 = icmp ule i32 %local.resolved.extent.83, %stack.sub.111
  %descriptor.payload.inside.113 = icmp ule i32 %local.resolved.payload.84, %local.resolved.extent.83
  %descriptor.owner.offset.valid.114 = and i1 %descriptor.owner.inside.109, %descriptor.offset.inside.110
  %descriptor.range.inside.116 = and i1 %descriptor.owner.offset.valid.114, %descriptor.extent.inside.112
  %descriptor.range.valid.115 = and i1 %descriptor.range.inside.116, %descriptor.payload.inside.113
  %descriptor.type.valid.117 = icmp eq i32 10, 10
  %descriptor.valid.118 = and i1 %descriptor.range.valid.115, %descriptor.type.valid.117
  br i1 %descriptor.valid.118, label %descriptor.valid.119, label %descriptor.invalid.120
descriptor.invalid.120:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.119:
  %descriptor.initialized.status.121 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.82, i32 %local.resolved.extent.83)
  %helper.ok.122 = icmp eq i32 %descriptor.initialized.status.121, 0
  br i1 %helper.ok.122, label %helper.continue.123, label %frame.failure.0
helper.continue.123:
  %local.is.active.124 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.124, label %local.descriptor.active.125, label %local.descriptor.inactive.126
local.descriptor.active.125:
  %local.check.offset.128 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.129 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.130 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.131 = load i32, ptr %local.owner.end.6, align 4
  %context.field.132 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.133 = load i32, ptr %context.field.132, align 4
  %stack.sub.136 = sub i32 %local.check.owner.end.131, %local.check.offset.128
  %descriptor.owner.inside.134 = icmp ule i32 %local.check.owner.end.131, %context.value.133
  %descriptor.offset.inside.135 = icmp ule i32 %local.check.offset.128, %local.check.owner.end.131
  %descriptor.extent.inside.137 = icmp ule i32 %local.check.extent.129, %stack.sub.136
  %descriptor.payload.inside.138 = icmp ule i32 %local.check.payload.130, %local.check.extent.129
  %descriptor.owner.offset.valid.139 = and i1 %descriptor.owner.inside.134, %descriptor.offset.inside.135
  %descriptor.range.inside.141 = and i1 %descriptor.owner.offset.valid.139, %descriptor.extent.inside.137
  %descriptor.range.valid.140 = and i1 %descriptor.range.inside.141, %descriptor.payload.inside.138
  br i1 %descriptor.range.valid.140, label %descriptor.valid.142, label %descriptor.invalid.143
descriptor.invalid.143:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.142:
  %descriptor.initialized.status.144 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.128, i32 %local.check.extent.129)
  %helper.ok.145 = icmp eq i32 %descriptor.initialized.status.144, 0
  br i1 %helper.ok.145, label %helper.continue.146, label %frame.failure.0
helper.continue.146:
  br label %local.descriptor.checked.127
local.descriptor.inactive.126:
  br label %local.descriptor.checked.127
local.descriptor.checked.127:
  %step.status.147 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.148 = icmp eq i32 %step.status.147, 0
  br i1 %helper.ok.148, label %helper.continue.149, label %frame.failure.0
helper.continue.149:
  %field.location.150 = alloca %AlOwningFieldLocation, align 4
  %field.location.status.151 = call i32 @al_owning_locate_field(ptr %ctx, ptr @al_owning_layout, i32 2, i32 %local.resolved.offset.82, i32 %local.resolved.extent.83, i32 0, i32 6, ptr %field.location.150)
  %helper.ok.152 = icmp eq i32 %field.location.status.151, 0
  br i1 %helper.ok.152, label %helper.continue.153, label %frame.failure.0
helper.continue.153:
  %field.offset.pointer.154 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.150, i32 0, i32 0
  %field.offset.155 = load i32, ptr %field.offset.pointer.154, align 4
  %field.payload.pointer.156 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.150, i32 0, i32 1
  %field.payload.157 = load i32, ptr %field.payload.pointer.156, align 4
  %field.extent.pointer.158 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.150, i32 0, i32 2
  %field.extent.159 = load i32, ptr %field.extent.pointer.158, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 7, i32 4, i32 %local.resolved.offset.82, i32 %field.extent.159, i32 %field.payload.157, i32 %field.offset.155, i32 %field.extent.159)
  %context.field.160 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.161 = load i32, ptr %context.field.160, align 4
  %runtime.ok.162 = icmp eq i32 %context.value.161, 0
  br i1 %runtime.ok.162, label %runtime.continue.163, label %frame.failure.0
runtime.continue.163:
  %context.field.164 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.165 = load i32, ptr %context.field.164, align 4
  %stack.sub.168 = sub i32 %local.resolved.owner.end.85, %field.offset.155
  %descriptor.owner.inside.166 = icmp ule i32 %local.resolved.owner.end.85, %context.value.165
  %descriptor.offset.inside.167 = icmp ule i32 %field.offset.155, %local.resolved.owner.end.85
  %descriptor.extent.inside.169 = icmp ule i32 %field.extent.159, %stack.sub.168
  %descriptor.payload.inside.170 = icmp ule i32 %field.payload.157, %field.extent.159
  %descriptor.owner.offset.valid.171 = and i1 %descriptor.owner.inside.166, %descriptor.offset.inside.167
  %descriptor.range.inside.173 = and i1 %descriptor.owner.offset.valid.171, %descriptor.extent.inside.169
  %descriptor.range.valid.172 = and i1 %descriptor.range.inside.173, %descriptor.payload.inside.170
  %descriptor.type.valid.174 = icmp eq i32 4, 4
  %descriptor.valid.175 = and i1 %descriptor.range.valid.172, %descriptor.type.valid.174
  br i1 %descriptor.valid.175, label %descriptor.valid.176, label %descriptor.invalid.177
descriptor.invalid.177:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.176:
  %descriptor.initialized.status.178 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %field.offset.155, i32 %field.extent.159)
  %helper.ok.179 = icmp eq i32 %descriptor.initialized.status.178, 0
  br i1 %helper.ok.179, label %helper.continue.180, label %frame.failure.0
helper.continue.180:
  %local.is.active.181 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.181, label %local.descriptor.active.182, label %local.descriptor.inactive.183
local.descriptor.active.182:
  %local.check.offset.185 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.186 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.187 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.188 = load i32, ptr %local.owner.end.6, align 4
  %context.field.189 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.190 = load i32, ptr %context.field.189, align 4
  %stack.sub.193 = sub i32 %local.check.owner.end.188, %local.check.offset.185
  %descriptor.owner.inside.191 = icmp ule i32 %local.check.owner.end.188, %context.value.190
  %descriptor.offset.inside.192 = icmp ule i32 %local.check.offset.185, %local.check.owner.end.188
  %descriptor.extent.inside.194 = icmp ule i32 %local.check.extent.186, %stack.sub.193
  %descriptor.payload.inside.195 = icmp ule i32 %local.check.payload.187, %local.check.extent.186
  %descriptor.owner.offset.valid.196 = and i1 %descriptor.owner.inside.191, %descriptor.offset.inside.192
  %descriptor.range.inside.198 = and i1 %descriptor.owner.offset.valid.196, %descriptor.extent.inside.194
  %descriptor.range.valid.197 = and i1 %descriptor.range.inside.198, %descriptor.payload.inside.195
  br i1 %descriptor.range.valid.197, label %descriptor.valid.199, label %descriptor.invalid.200
descriptor.invalid.200:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.199:
  %descriptor.initialized.status.201 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.185, i32 %local.check.extent.186)
  %helper.ok.202 = icmp eq i32 %descriptor.initialized.status.201, 0
  br i1 %helper.ok.202, label %helper.continue.203, label %frame.failure.0
helper.continue.203:
  br label %local.descriptor.checked.184
local.descriptor.inactive.183:
  br label %local.descriptor.checked.184
local.descriptor.checked.184:
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %context.field.204 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.205 = load i32, ptr %context.field.204, align 4
  %stack.sub.206 = sub i32 %context.value.205, %context.value.9
  call void @al_owning_record_layout(ptr %ctx, i32 18, i32 0, i32 %context.value.9, i32 %stack.sub.206, i32 0, i32 0, i32 0)
  %context.field.207 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.208 = load i32, ptr %context.field.207, align 4
  %runtime.ok.209 = icmp eq i32 %context.value.208, 0
  br i1 %runtime.ok.209, label %runtime.continue.210, label %frame.failure.0
runtime.continue.210:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.9, i32 0, i32 0, i32 0)
  %context.field.211 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.212 = load i32, ptr %context.field.211, align 4
  %runtime.ok.213 = icmp eq i32 %context.value.212, 0
  br i1 %runtime.ok.213, label %runtime.continue.214, label %frame.failure.0
runtime.continue.214:
  %descriptor.element.215 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.216 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.215, i32 0, i32 0
  store i32 4, ptr %descriptor.field.216, align 4
  %descriptor.field.217 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.215, i32 0, i32 1
  store i32 %field.offset.155, ptr %descriptor.field.217, align 4
  %descriptor.field.218 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.215, i32 0, i32 2
  store i32 %field.extent.159, ptr %descriptor.field.218, align 4
  %descriptor.field.219 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.215, i32 0, i32 3
  store i32 %field.payload.157, ptr %descriptor.field.219, align 4
  %descriptor.field.220 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.215, i32 0, i32 4
  store i32 %local.resolved.owner.end.85, ptr %descriptor.field.220, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %field.offset.155, i32 20, i32 %field.payload.157, i32 %local.resolved.owner.end.85, i32 %field.extent.159)
  %context.field.221 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.222 = load i32, ptr %context.field.221, align 4
  %runtime.ok.223 = icmp eq i32 %context.value.222, 0
  br i1 %runtime.ok.223, label %runtime.continue.224, label %frame.failure.0
runtime.continue.224:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.9, i32 0, i32 0, i32 0)
  %context.field.225 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.226 = load i32, ptr %context.field.225, align 4
  %context.field.227 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.228 = load i32, ptr %context.field.227, align 4
  %context.field.229 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.230 = load i32, ptr %context.field.229, align 4
  %stack.offset.231 = add i32 %context.value.11, %context.value.13
  %stack.offset.232 = add i32 %context.value.226, %context.value.228
  %stack.sub.233 = sub i32 %stack.offset.231, %stack.offset.232
  %stack.sub.234 = sub i32 %context.value.13, %context.value.228
  %stack.sub.235 = sub i32 %context.value.230, %context.value.15
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.233, i32 %stack.sub.234)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.235)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 1
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %entry.input.descriptors.10 = alloca [1 x %AlOwningDescriptor], align 4
  %input.extent.pointer.11 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.12 = load i32, ptr %input.extent.pointer.11, align 4
  %host.pointer.13 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.14 = alloca i32, align 4
  %input.measured.extent.pointer.15 = alloca i32, align 4
  %input.measure.status.16 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 2, ptr %host.pointer.13, i32 %input.host.extent.12, i32 0, i32 7, ptr %input.payload.pointer.14, ptr %input.measured.extent.pointer.15)
  %helper.ok.17 = icmp eq i32 %input.measure.status.16, 0
  br i1 %helper.ok.17, label %helper.continue.18, label %entry.failure.0
helper.continue.18:
  %input.measured.payload.19 = load i32, ptr %input.payload.pointer.14, align 4
  %input.measured.extent.20 = load i32, ptr %input.measured.extent.pointer.15, align 4
  %input.extent.exact.21 = icmp eq i32 %input.measured.extent.20, %input.host.extent.12
  br i1 %input.extent.exact.21, label %input.extent.exact.22, label %input.extent.invalid.23
input.extent.invalid.23:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 7, i32 %input.measured.extent.20, i32 %input.host.extent.12)
  br label %entry.failure.0
input.extent.exact.22:
  %stack.offset.24 = add i32 0, %input.host.extent.12
  %input.total.exact.25 = icmp eq i32 %stack.offset.24, %input.bytes
  br i1 %input.total.exact.25, label %input.valid.26, label %input.invalid.27
input.invalid.27:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.24, i32 %input.bytes)
  br label %entry.failure.0
input.valid.26:
  %reserve.status.28 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.24, i32 8)
  %reserve.ok.29 = icmp eq i32 %reserve.status.28, 0
  br i1 %reserve.ok.29, label %reserve.continue.30, label %entry.failure.0
reserve.continue.30:
  %host.pointer.31 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.32 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.31, i32 %input.host.extent.12, i32 0, i32 %input.measured.payload.19, i32 %input.host.extent.12, i32 10, i32 9)
  %helper.ok.33 = icmp eq i32 %input.copy.status.32, 0
  br i1 %helper.ok.33, label %helper.continue.34, label %entry.failure.0
helper.continue.34:
  %stack.offset.35 = add i32 0, %input.host.extent.12
  %descriptor.element.36 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.10, i32 0
  %descriptor.field.37 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.36, i32 0, i32 0
  store i32 10, ptr %descriptor.field.37, align 4
  %descriptor.field.38 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.36, i32 0, i32 1
  store i32 0, ptr %descriptor.field.38, align 4
  %descriptor.field.39 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.36, i32 0, i32 2
  store i32 %input.host.extent.12, ptr %descriptor.field.39, align 4
  %descriptor.field.40 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.36, i32 0, i32 3
  store i32 %input.measured.payload.19, ptr %descriptor.field.40, align 4
  %descriptor.field.41 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.36, i32 0, i32 4
  store i32 %stack.offset.35, ptr %descriptor.field.41, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 10, i32 0, i32 20, i32 %input.measured.payload.19, i32 %stack.offset.35, i32 %input.host.extent.12)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %entry.failure.0
runtime.continue.45:
  %entry.output.descriptors.46 = alloca [1 x %AlOwningDescriptor], align 4
  %entry.body.status.47 = call i32 @agentlang_entry_frame(ptr %ctx, ptr %entry.input.descriptors.10, ptr %entry.output.descriptors.46, i32 10)
  %entry.body.ok.48 = icmp eq i32 %entry.body.status.47, 0
  br i1 %entry.body.ok.48, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.49 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.46, i32 0
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 0
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 1
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %descriptor.field.54 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 2
  %descriptor.value.55 = load i32, ptr %descriptor.field.54, align 4
  %descriptor.field.56 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 3
  %descriptor.value.57 = load i32, ptr %descriptor.field.56, align 4
  %descriptor.field.58 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 4
  %descriptor.value.59 = load i32, ptr %descriptor.field.58, align 4
  %entry.output.type.valid.60 = icmp eq i32 %descriptor.value.51, 4
  br i1 %entry.output.type.valid.60, label %entry.output.type.ok.61, label %entry.output.type.invalid.62
entry.output.type.invalid.62:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.61:
  %context.field.63 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.64 = load i32, ptr %context.field.63, align 4
  %stack.sub.67 = sub i32 %descriptor.value.59, %descriptor.value.53
  %descriptor.owner.inside.65 = icmp ule i32 %descriptor.value.59, %context.value.64
  %descriptor.offset.inside.66 = icmp ule i32 %descriptor.value.53, %descriptor.value.59
  %descriptor.extent.inside.68 = icmp ule i32 %descriptor.value.55, %stack.sub.67
  %descriptor.payload.inside.69 = icmp ule i32 %descriptor.value.57, %descriptor.value.55
  %descriptor.owner.offset.valid.70 = and i1 %descriptor.owner.inside.65, %descriptor.offset.inside.66
  %descriptor.range.inside.72 = and i1 %descriptor.owner.offset.valid.70, %descriptor.extent.inside.68
  %descriptor.range.valid.71 = and i1 %descriptor.range.inside.72, %descriptor.payload.inside.69
  %descriptor.type.valid.73 = icmp eq i32 4, 4
  %descriptor.valid.74 = and i1 %descriptor.range.valid.71, %descriptor.type.valid.73
  br i1 %descriptor.valid.74, label %descriptor.valid.75, label %descriptor.invalid.76
descriptor.invalid.76:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.75:
  %descriptor.initialized.status.77 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.53, i32 %descriptor.value.55)
  %helper.ok.78 = icmp eq i32 %descriptor.initialized.status.77, 0
  br i1 %helper.ok.78, label %helper.continue.79, label %entry.failure.0
helper.continue.79:
  %entry.output.empty.projection.80 = icmp eq i32 %descriptor.value.55, 0
  %entry.output.serialized.extent.81 = select i1 %entry.output.empty.projection.80, i32 8, i32 %descriptor.value.55
  %entry.output.size.i64.82 = zext i32 %entry.output.serialized.extent.81 to i64
  %entry.output.total.i64.83 = add i64 0, %entry.output.size.i64.82
  %entry.retained.capacity.i64.84 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.85 = icmp ule i64 %entry.output.total.i64.83, 4294967295
  %entry.retained.required.truncated.86 = trunc i64 %entry.output.total.i64.83 to i32
  %entry.retained.required.87 = select i1 %entry.retained.required.fits.u32.85, i32 %entry.retained.required.truncated.86, i32 4294967295
  %entry.retained.capacity.ok.88 = icmp ule i64 %entry.output.total.i64.83, %entry.retained.capacity.i64.84
  br i1 %entry.retained.capacity.ok.88, label %entry.retained.capacity.ready.89, label %entry.retained.capacity.failure.90
entry.retained.capacity.failure.90:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.87, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.89:
  %entry.output.needs.empty.token.91 = icmp eq i32 %descriptor.value.55, 0
  br i1 %entry.output.needs.empty.token.91, label %entry.output.empty.token.92, label %entry.output.empty.keep.93
entry.output.empty.token.92:
  %context.field.95 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.96 = load i32, ptr %context.field.95, align 4
  %stack.offset.97 = add i32 %context.value.96, 8
  %reserve.status.98 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.97, i32 11)
  %reserve.ok.99 = icmp eq i32 %reserve.status.98, 0
  br i1 %reserve.ok.99, label %reserve.continue.100, label %entry.failure.0
reserve.continue.100:
  call void @al_owning_store_token(ptr %ctx, i32 %context.value.96, i32 4)
  %context.field.101 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.102 = load i32, ptr %context.field.101, align 4
  %runtime.ok.103 = icmp eq i32 %context.value.102, 0
  br i1 %runtime.ok.103, label %runtime.continue.104, label %entry.failure.0
runtime.continue.104:
  br label %entry.output.empty.join.94
entry.output.empty.keep.93:
  br label %entry.output.empty.join.94
entry.output.empty.join.94:
  %entry.output.materialized.offset.105 = phi i32 [ %context.value.96, %runtime.continue.104 ], [ %descriptor.value.53, %entry.output.empty.keep.93 ]
  %entry.output.materialized.extent.106 = phi i32 [ 8, %runtime.continue.104 ], [ %descriptor.value.55, %entry.output.empty.keep.93 ]
  %entry.output.materialized.payload.107 = phi i32 [ 0, %runtime.continue.104 ], [ %descriptor.value.57, %entry.output.empty.keep.93 ]
  %entry.output.materialized.owner.end.108 = phi i32 [ %stack.offset.97, %runtime.continue.104 ], [ %descriptor.value.59, %entry.output.empty.keep.93 ]
  %host.pointer.109 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.110 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.109, i32 %stack.sub.110, i32 %entry.output.materialized.offset.105, i32 %entry.output.materialized.extent.106, i32 4)
  %context.field.111 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.112 = load i32, ptr %context.field.111, align 4
  %runtime.ok.113 = icmp eq i32 %context.value.112, 0
  br i1 %runtime.ok.113, label %runtime.continue.114, label %entry.failure.0
runtime.continue.114:
  %stack.offset.115 = add i32 0, %entry.output.materialized.extent.106
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.116 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.117 = load i32, ptr %context.field.116, align 4
  %context.field.118 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.119 = load i32, ptr %context.field.118, align 4
  %stack.sub.120 = sub i32 0, %context.value.117
  %stack.sub.121 = sub i32 0, %context.value.119
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.120, i32 %stack.sub.121)
  %context.field.122 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.123 = load i32, ptr %context.field.122, align 4
  %runtime.ok.124 = icmp eq i32 %context.value.123, 0
  br i1 %runtime.ok.124, label %runtime.continue.125, label %entry.failure.0
runtime.continue.125:
  br label %entry.return.status
entry.failure.0:
  %context.field.126 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.127 = load i32, ptr %context.field.126, align 4
  %context.field.128 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.129 = load i32, ptr %context.field.128, align 4
  %context.field.130 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.131 = load i32, ptr %context.field.130, align 4
  %stack.offset.132 = add i32 %context.value.127, %context.value.129
  %stack.sub.133 = sub i32 0, %stack.offset.132
  %stack.sub.134 = sub i32 0, %context.value.129
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.133, i32 %stack.sub.134)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.131)
  br label %entry.return.status
entry.return.status:
  %context.field.135 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.136 = load i32, ptr %context.field.135, align 4
  ret i32 %context.value.136
}


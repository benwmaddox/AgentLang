%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [1 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 4, i32 4, i32 0, i32 0, i32 0, i32 8, i32 0, i32 8 }], align 4
@al_owning_fields = private constant [1 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 0, i32 0, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 1, ptr @al_owning_types, i32 1, ptr @al_owning_fields, i32 0 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %step.status.13 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.14 = icmp eq i32 %step.status.13, 0
  br i1 %helper.ok.14, label %helper.continue.15, label %frame.failure.0
helper.continue.15:
  %call.results.16 = alloca [1 x %AlOwningDescriptor], align 4
  %callee.status.17 = call i32 @agentlang_word_0000(ptr %ctx, ptr null, ptr %call.results.16, i32 2)
  %helper.ok.18 = icmp eq i32 %callee.status.17, 0
  br i1 %helper.ok.18, label %helper.continue.19, label %frame.failure.0
helper.continue.19:
  %descriptor.element.20 = getelementptr inbounds %AlOwningDescriptor, ptr %call.results.16, i32 0
  %descriptor.field.21 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.20, i32 0, i32 0
  %descriptor.value.22 = load i32, ptr %descriptor.field.21, align 4
  %descriptor.field.23 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.20, i32 0, i32 1
  %descriptor.value.24 = load i32, ptr %descriptor.field.23, align 4
  %descriptor.field.25 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.20, i32 0, i32 2
  %descriptor.value.26 = load i32, ptr %descriptor.field.25, align 4
  %descriptor.field.27 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.20, i32 0, i32 3
  %descriptor.value.28 = load i32, ptr %descriptor.field.27, align 4
  %descriptor.field.29 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.20, i32 0, i32 4
  %descriptor.value.30 = load i32, ptr %descriptor.field.29, align 4
  %callee.result.type.valid.31 = icmp eq i32 %descriptor.value.22, 4
  br i1 %callee.result.type.valid.31, label %callee.result.type.ok.32, label %frame.failure.0
callee.result.type.ok.32:
  %context.field.33 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.34 = load i32, ptr %context.field.33, align 4
  %stack.sub.37 = sub i32 %descriptor.value.30, %descriptor.value.24
  %descriptor.owner.inside.35 = icmp ule i32 %descriptor.value.30, %context.value.34
  %descriptor.offset.inside.36 = icmp ule i32 %descriptor.value.24, %descriptor.value.30
  %descriptor.extent.inside.38 = icmp ule i32 %descriptor.value.26, %stack.sub.37
  %descriptor.payload.inside.39 = icmp ule i32 %descriptor.value.28, %descriptor.value.26
  %descriptor.owner.offset.valid.40 = and i1 %descriptor.owner.inside.35, %descriptor.offset.inside.36
  %descriptor.range.inside.42 = and i1 %descriptor.owner.offset.valid.40, %descriptor.extent.inside.38
  %descriptor.range.valid.41 = and i1 %descriptor.range.inside.42, %descriptor.payload.inside.39
  %descriptor.type.valid.43 = icmp eq i32 4, 4
  %descriptor.valid.44 = and i1 %descriptor.range.valid.41, %descriptor.type.valid.43
  br i1 %descriptor.valid.44, label %descriptor.valid.45, label %descriptor.invalid.46
descriptor.invalid.46:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.45:
  %descriptor.initialized.status.47 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.24, i32 %descriptor.value.26)
  %helper.ok.48 = icmp eq i32 %descriptor.initialized.status.47, 0
  br i1 %helper.ok.48, label %helper.continue.49, label %frame.failure.0
helper.continue.49:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %descriptor.value.24, i32 20, i32 %descriptor.value.28, i32 %descriptor.value.30, i32 %descriptor.value.26)
  %context.field.50 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.51 = load i32, ptr %context.field.50, align 4
  %runtime.ok.52 = icmp eq i32 %context.value.51, 0
  br i1 %runtime.ok.52, label %runtime.continue.53, label %frame.failure.0
runtime.continue.53:
  %context.field.54 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.55 = load i32, ptr %context.field.54, align 4
  %stack.sub.58 = sub i32 %descriptor.value.30, %descriptor.value.24
  %descriptor.owner.inside.56 = icmp ule i32 %descriptor.value.30, %context.value.55
  %descriptor.offset.inside.57 = icmp ule i32 %descriptor.value.24, %descriptor.value.30
  %descriptor.extent.inside.59 = icmp ule i32 %descriptor.value.26, %stack.sub.58
  %descriptor.payload.inside.60 = icmp ule i32 %descriptor.value.28, %descriptor.value.26
  %descriptor.owner.offset.valid.61 = and i1 %descriptor.owner.inside.56, %descriptor.offset.inside.57
  %descriptor.range.inside.63 = and i1 %descriptor.owner.offset.valid.61, %descriptor.extent.inside.59
  %descriptor.range.valid.62 = and i1 %descriptor.range.inside.63, %descriptor.payload.inside.60
  %descriptor.type.valid.64 = icmp eq i32 4, 4
  %descriptor.valid.65 = and i1 %descriptor.range.valid.62, %descriptor.type.valid.64
  br i1 %descriptor.valid.65, label %descriptor.valid.66, label %descriptor.invalid.67
descriptor.invalid.67:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.66:
  %descriptor.initialized.status.68 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.24, i32 %descriptor.value.26)
  %helper.ok.69 = icmp eq i32 %descriptor.initialized.status.68, 0
  br i1 %helper.ok.69, label %helper.continue.70, label %frame.failure.0
helper.continue.70:
  %descriptor.element.71 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.72 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.71, i32 0, i32 0
  store i32 4, ptr %descriptor.field.72, align 4
  %descriptor.field.73 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.71, i32 0, i32 1
  store i32 %descriptor.value.24, ptr %descriptor.field.73, align 4
  %descriptor.field.74 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.71, i32 0, i32 2
  store i32 %descriptor.value.26, ptr %descriptor.field.74, align 4
  %descriptor.field.75 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.71, i32 0, i32 3
  store i32 %descriptor.value.28, ptr %descriptor.field.75, align 4
  %descriptor.field.76 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.71, i32 0, i32 4
  store i32 %descriptor.value.30, ptr %descriptor.field.76, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %descriptor.value.24, i32 20, i32 %descriptor.value.28, i32 %descriptor.value.30, i32 %descriptor.value.26)
  %context.field.77 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.78 = load i32, ptr %context.field.77, align 4
  %runtime.ok.79 = icmp eq i32 %context.value.78, 0
  br i1 %runtime.ok.79, label %runtime.continue.80, label %frame.failure.0
runtime.continue.80:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.81 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.82 = load i32, ptr %context.field.81, align 4
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %context.field.85 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.86 = load i32, ptr %context.field.85, align 4
  %stack.offset.87 = add i32 %context.value.5, %context.value.7
  %stack.offset.88 = add i32 %context.value.82, %context.value.84
  %stack.sub.89 = sub i32 %stack.offset.87, %stack.offset.88
  %stack.sub.90 = sub i32 %context.value.7, %context.value.84
  %stack.sub.91 = sub i32 %context.value.86, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.89, i32 %stack.sub.90)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.91)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %step.status.13 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.14 = icmp eq i32 %step.status.13, 0
  br i1 %helper.ok.14, label %helper.continue.15, label %frame.failure.0
helper.continue.15:
  %context.field.16 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.17 = load i32, ptr %context.field.16, align 4
  %stack.offset.18 = add i32 %context.value.17, 8
  %reserve.status.19 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.18, i32 4)
  %reserve.ok.20 = icmp eq i32 %reserve.status.19, 0
  br i1 %reserve.ok.20, label %reserve.continue.21, label %frame.failure.0
reserve.continue.21:
  call void @al_owning_store_token(ptr %ctx, i32 %context.value.17, i32 4)
  %context.field.22 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.23 = load i32, ptr %context.field.22, align 4
  %runtime.ok.24 = icmp eq i32 %context.value.23, 0
  br i1 %runtime.ok.24, label %runtime.continue.25, label %frame.failure.0
runtime.continue.25:
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 4, i32 %context.value.17, i32 8, i32 0, i32 0, i32 0)
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %runtime.ok.28 = icmp eq i32 %context.value.27, 0
  br i1 %runtime.ok.28, label %runtime.continue.29, label %frame.failure.0
runtime.continue.29:
  %context.field.30 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.31 = load i32, ptr %context.field.30, align 4
  %stack.sub.34 = sub i32 %stack.offset.18, %context.value.17
  %descriptor.owner.inside.32 = icmp ule i32 %stack.offset.18, %context.value.31
  %descriptor.offset.inside.33 = icmp ule i32 %context.value.17, %stack.offset.18
  %descriptor.extent.inside.35 = icmp ule i32 8, %stack.sub.34
  %descriptor.payload.inside.36 = icmp ule i32 0, 8
  %descriptor.owner.offset.valid.37 = and i1 %descriptor.owner.inside.32, %descriptor.offset.inside.33
  %descriptor.range.inside.39 = and i1 %descriptor.owner.offset.valid.37, %descriptor.extent.inside.35
  %descriptor.range.valid.38 = and i1 %descriptor.range.inside.39, %descriptor.payload.inside.36
  %descriptor.type.valid.40 = icmp eq i32 4, 4
  %descriptor.valid.41 = and i1 %descriptor.range.valid.38, %descriptor.type.valid.40
  br i1 %descriptor.valid.41, label %descriptor.valid.42, label %descriptor.invalid.43
descriptor.invalid.43:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.42:
  %descriptor.initialized.status.44 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.17, i32 8)
  %helper.ok.45 = icmp eq i32 %descriptor.initialized.status.44, 0
  br i1 %helper.ok.45, label %helper.continue.46, label %frame.failure.0
helper.continue.46:
  %descriptor.element.47 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 0
  store i32 4, ptr %descriptor.field.48, align 4
  %descriptor.field.49 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 1
  store i32 %context.value.17, ptr %descriptor.field.49, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 2
  store i32 8, ptr %descriptor.field.50, align 4
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 3
  store i32 0, ptr %descriptor.field.51, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 4
  store i32 %stack.offset.18, ptr %descriptor.field.52, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %context.value.17, i32 20, i32 0, i32 %stack.offset.18, i32 8)
  %context.field.53 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.54 = load i32, ptr %context.field.53, align 4
  %runtime.ok.55 = icmp eq i32 %context.value.54, 0
  br i1 %runtime.ok.55, label %runtime.continue.56, label %frame.failure.0
runtime.continue.56:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.57 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.58 = load i32, ptr %context.field.57, align 4
  %context.field.59 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.60 = load i32, ptr %context.field.59, align 4
  %context.field.61 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.62 = load i32, ptr %context.field.61, align 4
  %stack.offset.63 = add i32 %context.value.5, %context.value.7
  %stack.offset.64 = add i32 %context.value.58, %context.value.60
  %stack.sub.65 = sub i32 %stack.offset.63, %stack.offset.64
  %stack.sub.66 = sub i32 %context.value.7, %context.value.60
  %stack.sub.67 = sub i32 %context.value.62, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.65, i32 %stack.sub.66)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.67)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 0
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 0, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %input.total.exact.10 = icmp eq i32 0, %input.bytes
  br i1 %input.total.exact.10, label %input.valid.11, label %input.invalid.12
input.invalid.12:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 0, i32 %input.bytes)
  br label %entry.failure.0
input.valid.11:
  %reserve.status.13 = call i32 @al_owning_reserve_to(ptr %ctx, i32 0, i32 5)
  %reserve.ok.14 = icmp eq i32 %reserve.status.13, 0
  br i1 %reserve.ok.14, label %reserve.continue.15, label %entry.failure.0
reserve.continue.15:
  %entry.output.descriptors.16 = alloca [1 x %AlOwningDescriptor], align 4
  %entry.body.status.17 = call i32 @agentlang_entry_frame(ptr %ctx, ptr null, ptr %entry.output.descriptors.16, i32 6)
  %entry.body.ok.18 = icmp eq i32 %entry.body.status.17, 0
  br i1 %entry.body.ok.18, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.19 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.16, i32 0
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 0
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 1
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %descriptor.field.24 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 2
  %descriptor.value.25 = load i32, ptr %descriptor.field.24, align 4
  %descriptor.field.26 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 3
  %descriptor.value.27 = load i32, ptr %descriptor.field.26, align 4
  %descriptor.field.28 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 4
  %descriptor.value.29 = load i32, ptr %descriptor.field.28, align 4
  %entry.output.type.valid.30 = icmp eq i32 %descriptor.value.21, 4
  br i1 %entry.output.type.valid.30, label %entry.output.type.ok.31, label %entry.output.type.invalid.32
entry.output.type.invalid.32:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.31:
  %context.field.33 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.34 = load i32, ptr %context.field.33, align 4
  %stack.sub.37 = sub i32 %descriptor.value.29, %descriptor.value.23
  %descriptor.owner.inside.35 = icmp ule i32 %descriptor.value.29, %context.value.34
  %descriptor.offset.inside.36 = icmp ule i32 %descriptor.value.23, %descriptor.value.29
  %descriptor.extent.inside.38 = icmp ule i32 %descriptor.value.25, %stack.sub.37
  %descriptor.payload.inside.39 = icmp ule i32 %descriptor.value.27, %descriptor.value.25
  %descriptor.owner.offset.valid.40 = and i1 %descriptor.owner.inside.35, %descriptor.offset.inside.36
  %descriptor.range.inside.42 = and i1 %descriptor.owner.offset.valid.40, %descriptor.extent.inside.38
  %descriptor.range.valid.41 = and i1 %descriptor.range.inside.42, %descriptor.payload.inside.39
  %descriptor.type.valid.43 = icmp eq i32 4, 4
  %descriptor.valid.44 = and i1 %descriptor.range.valid.41, %descriptor.type.valid.43
  br i1 %descriptor.valid.44, label %descriptor.valid.45, label %descriptor.invalid.46
descriptor.invalid.46:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.45:
  %descriptor.initialized.status.47 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.23, i32 %descriptor.value.25)
  %helper.ok.48 = icmp eq i32 %descriptor.initialized.status.47, 0
  br i1 %helper.ok.48, label %helper.continue.49, label %entry.failure.0
helper.continue.49:
  %entry.output.empty.projection.50 = icmp eq i32 %descriptor.value.25, 0
  %entry.output.serialized.extent.51 = select i1 %entry.output.empty.projection.50, i32 8, i32 %descriptor.value.25
  %entry.output.size.i64.52 = zext i32 %entry.output.serialized.extent.51 to i64
  %entry.output.total.i64.53 = add i64 0, %entry.output.size.i64.52
  %entry.retained.capacity.i64.54 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.55 = icmp ule i64 %entry.output.total.i64.53, 4294967295
  %entry.retained.required.truncated.56 = trunc i64 %entry.output.total.i64.53 to i32
  %entry.retained.required.57 = select i1 %entry.retained.required.fits.u32.55, i32 %entry.retained.required.truncated.56, i32 4294967295
  %entry.retained.capacity.ok.58 = icmp ule i64 %entry.output.total.i64.53, %entry.retained.capacity.i64.54
  br i1 %entry.retained.capacity.ok.58, label %entry.retained.capacity.ready.59, label %entry.retained.capacity.failure.60
entry.retained.capacity.failure.60:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.57, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.59:
  %entry.output.needs.empty.token.61 = icmp eq i32 %descriptor.value.25, 0
  br i1 %entry.output.needs.empty.token.61, label %entry.output.empty.token.62, label %entry.output.empty.keep.63
entry.output.empty.token.62:
  %context.field.65 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.66 = load i32, ptr %context.field.65, align 4
  %stack.offset.67 = add i32 %context.value.66, 8
  %reserve.status.68 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.67, i32 7)
  %reserve.ok.69 = icmp eq i32 %reserve.status.68, 0
  br i1 %reserve.ok.69, label %reserve.continue.70, label %entry.failure.0
reserve.continue.70:
  call void @al_owning_store_token(ptr %ctx, i32 %context.value.66, i32 4)
  %context.field.71 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.72 = load i32, ptr %context.field.71, align 4
  %runtime.ok.73 = icmp eq i32 %context.value.72, 0
  br i1 %runtime.ok.73, label %runtime.continue.74, label %entry.failure.0
runtime.continue.74:
  br label %entry.output.empty.join.64
entry.output.empty.keep.63:
  br label %entry.output.empty.join.64
entry.output.empty.join.64:
  %entry.output.materialized.offset.75 = phi i32 [ %context.value.66, %runtime.continue.74 ], [ %descriptor.value.23, %entry.output.empty.keep.63 ]
  %entry.output.materialized.extent.76 = phi i32 [ 8, %runtime.continue.74 ], [ %descriptor.value.25, %entry.output.empty.keep.63 ]
  %entry.output.materialized.payload.77 = phi i32 [ 0, %runtime.continue.74 ], [ %descriptor.value.27, %entry.output.empty.keep.63 ]
  %entry.output.materialized.owner.end.78 = phi i32 [ %stack.offset.67, %runtime.continue.74 ], [ %descriptor.value.29, %entry.output.empty.keep.63 ]
  %host.pointer.79 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.80 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.79, i32 %stack.sub.80, i32 %entry.output.materialized.offset.75, i32 %entry.output.materialized.extent.76, i32 4)
  %context.field.81 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.82 = load i32, ptr %context.field.81, align 4
  %runtime.ok.83 = icmp eq i32 %context.value.82, 0
  br i1 %runtime.ok.83, label %runtime.continue.84, label %entry.failure.0
runtime.continue.84:
  %stack.offset.85 = add i32 0, %entry.output.materialized.extent.76
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.86 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.87 = load i32, ptr %context.field.86, align 4
  %context.field.88 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.89 = load i32, ptr %context.field.88, align 4
  %stack.sub.90 = sub i32 0, %context.value.87
  %stack.sub.91 = sub i32 0, %context.value.89
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.90, i32 %stack.sub.91)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %entry.failure.0
runtime.continue.95:
  br label %entry.return.status
entry.failure.0:
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %context.field.100 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.101 = load i32, ptr %context.field.100, align 4
  %stack.offset.102 = add i32 %context.value.97, %context.value.99
  %stack.sub.103 = sub i32 0, %stack.offset.102
  %stack.sub.104 = sub i32 0, %context.value.99
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.103, i32 %stack.sub.104)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.101)
  br label %entry.return.status
entry.return.status:
  %context.field.105 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.106 = load i32, ptr %context.field.105, align 4
  ret i32 %context.value.106
}


%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [4 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8 }, %AlOwningTypeDescriptor { i32 4, i32 5, i32 0, i32 2, i32 16, i32 16, i32 16, i32 16 }, %AlOwningTypeDescriptor { i32 4, i32 6, i32 2, i32 1, i32 8, i32 8, i32 8, i32 8 }, %AlOwningTypeDescriptor { i32 4, i32 7, i32 3, i32 2, i32 24, i32 24, i32 24, i32 24 }], align 4
@al_owning_fields = private constant [5 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 2, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 1, i32 8, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 1, ptr @al_owning_types, i32 4, ptr @al_owning_fields, i32 5 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 7
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 7, 7
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %descriptor.element.43 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.44 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 0
  %descriptor.value.45 = load i32, ptr %descriptor.field.44, align 4
  %descriptor.field.46 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 1
  %descriptor.value.47 = load i32, ptr %descriptor.field.46, align 4
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 2
  %descriptor.value.49 = load i32, ptr %descriptor.field.48, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 3
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 4
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %argument.type.valid.54 = icmp eq i32 %descriptor.value.45, 1
  br i1 %argument.type.valid.54, label %argument.type.ok.55, label %frame.failure.0
argument.type.ok.55:
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %stack.sub.60 = sub i32 %descriptor.value.53, %descriptor.value.47
  %descriptor.owner.inside.58 = icmp ule i32 %descriptor.value.53, %context.value.57
  %descriptor.offset.inside.59 = icmp ule i32 %descriptor.value.47, %descriptor.value.53
  %descriptor.extent.inside.61 = icmp ule i32 %descriptor.value.49, %stack.sub.60
  %descriptor.payload.inside.62 = icmp ule i32 %descriptor.value.51, %descriptor.value.49
  %descriptor.owner.offset.valid.63 = and i1 %descriptor.owner.inside.58, %descriptor.offset.inside.59
  %descriptor.range.inside.65 = and i1 %descriptor.owner.offset.valid.63, %descriptor.extent.inside.61
  %descriptor.range.valid.64 = and i1 %descriptor.range.inside.65, %descriptor.payload.inside.62
  %descriptor.type.valid.66 = icmp eq i32 1, 1
  %descriptor.valid.67 = and i1 %descriptor.range.valid.64, %descriptor.type.valid.66
  br i1 %descriptor.valid.67, label %descriptor.valid.68, label %descriptor.invalid.69
descriptor.invalid.69:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.68:
  %descriptor.initialized.status.70 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.47, i32 %descriptor.value.49)
  %helper.ok.71 = icmp eq i32 %descriptor.initialized.status.70, 0
  br i1 %helper.ok.71, label %helper.continue.72, label %frame.failure.0
helper.continue.72:
  %step.status.73 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.74 = icmp eq i32 %step.status.73, 0
  br i1 %helper.ok.74, label %helper.continue.75, label %frame.failure.0
helper.continue.75:
  %call.arguments.76 = alloca [2 x %AlOwningDescriptor], align 4
  %descriptor.element.77 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.76, i32 0
  %descriptor.field.78 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 0
  store i32 7, ptr %descriptor.field.78, align 4
  %descriptor.field.79 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.79, align 4
  %descriptor.field.80 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.80, align 4
  %descriptor.field.81 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.81, align 4
  %descriptor.field.82 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.77, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.82, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 7, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %runtime.ok.85 = icmp eq i32 %context.value.84, 0
  br i1 %runtime.ok.85, label %runtime.continue.86, label %frame.failure.0
runtime.continue.86:
  %descriptor.element.87 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.76, i32 1
  %descriptor.field.88 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 0
  store i32 1, ptr %descriptor.field.88, align 4
  %descriptor.field.89 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 1
  store i32 %descriptor.value.47, ptr %descriptor.field.89, align 4
  %descriptor.field.90 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 2
  store i32 %descriptor.value.49, ptr %descriptor.field.90, align 4
  %descriptor.field.91 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 3
  store i32 %descriptor.value.51, ptr %descriptor.field.91, align 4
  %descriptor.field.92 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.87, i32 0, i32 4
  store i32 %descriptor.value.53, ptr %descriptor.field.92, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %descriptor.value.47, i32 20, i32 %descriptor.value.51, i32 %descriptor.value.53, i32 %descriptor.value.49)
  %context.field.93 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.94 = load i32, ptr %context.field.93, align 4
  %runtime.ok.95 = icmp eq i32 %context.value.94, 0
  br i1 %runtime.ok.95, label %runtime.continue.96, label %frame.failure.0
runtime.continue.96:
  %call.results.97 = alloca [1 x %AlOwningDescriptor], align 4
  %callee.status.98 = call i32 @agentlang_word_0000(ptr %ctx, ptr %call.arguments.76, ptr %call.results.97, i32 2)
  %helper.ok.99 = icmp eq i32 %callee.status.98, 0
  br i1 %helper.ok.99, label %helper.continue.100, label %frame.failure.0
helper.continue.100:
  %descriptor.element.101 = getelementptr inbounds %AlOwningDescriptor, ptr %call.results.97, i32 0
  %descriptor.field.102 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.101, i32 0, i32 0
  %descriptor.value.103 = load i32, ptr %descriptor.field.102, align 4
  %descriptor.field.104 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.101, i32 0, i32 1
  %descriptor.value.105 = load i32, ptr %descriptor.field.104, align 4
  %descriptor.field.106 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.101, i32 0, i32 2
  %descriptor.value.107 = load i32, ptr %descriptor.field.106, align 4
  %descriptor.field.108 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.101, i32 0, i32 3
  %descriptor.value.109 = load i32, ptr %descriptor.field.108, align 4
  %descriptor.field.110 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.101, i32 0, i32 4
  %descriptor.value.111 = load i32, ptr %descriptor.field.110, align 4
  %callee.result.type.valid.112 = icmp eq i32 %descriptor.value.103, 1
  br i1 %callee.result.type.valid.112, label %callee.result.type.ok.113, label %frame.failure.0
callee.result.type.ok.113:
  %context.field.114 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.115 = load i32, ptr %context.field.114, align 4
  %stack.sub.118 = sub i32 %descriptor.value.111, %descriptor.value.105
  %descriptor.owner.inside.116 = icmp ule i32 %descriptor.value.111, %context.value.115
  %descriptor.offset.inside.117 = icmp ule i32 %descriptor.value.105, %descriptor.value.111
  %descriptor.extent.inside.119 = icmp ule i32 %descriptor.value.107, %stack.sub.118
  %descriptor.payload.inside.120 = icmp ule i32 %descriptor.value.109, %descriptor.value.107
  %descriptor.owner.offset.valid.121 = and i1 %descriptor.owner.inside.116, %descriptor.offset.inside.117
  %descriptor.range.inside.123 = and i1 %descriptor.owner.offset.valid.121, %descriptor.extent.inside.119
  %descriptor.range.valid.122 = and i1 %descriptor.range.inside.123, %descriptor.payload.inside.120
  %descriptor.type.valid.124 = icmp eq i32 1, 1
  %descriptor.valid.125 = and i1 %descriptor.range.valid.122, %descriptor.type.valid.124
  br i1 %descriptor.valid.125, label %descriptor.valid.126, label %descriptor.invalid.127
descriptor.invalid.127:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.126:
  %descriptor.initialized.status.128 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.105, i32 %descriptor.value.107)
  %helper.ok.129 = icmp eq i32 %descriptor.initialized.status.128, 0
  br i1 %helper.ok.129, label %helper.continue.130, label %frame.failure.0
helper.continue.130:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %descriptor.value.105, i32 20, i32 %descriptor.value.109, i32 %descriptor.value.111, i32 %descriptor.value.107)
  %context.field.131 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.132 = load i32, ptr %context.field.131, align 4
  %runtime.ok.133 = icmp eq i32 %context.value.132, 0
  br i1 %runtime.ok.133, label %runtime.continue.134, label %frame.failure.0
runtime.continue.134:
  %context.field.135 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.136 = load i32, ptr %context.field.135, align 4
  %stack.sub.139 = sub i32 %descriptor.value.111, %descriptor.value.105
  %descriptor.owner.inside.137 = icmp ule i32 %descriptor.value.111, %context.value.136
  %descriptor.offset.inside.138 = icmp ule i32 %descriptor.value.105, %descriptor.value.111
  %descriptor.extent.inside.140 = icmp ule i32 %descriptor.value.107, %stack.sub.139
  %descriptor.payload.inside.141 = icmp ule i32 %descriptor.value.109, %descriptor.value.107
  %descriptor.owner.offset.valid.142 = and i1 %descriptor.owner.inside.137, %descriptor.offset.inside.138
  %descriptor.range.inside.144 = and i1 %descriptor.owner.offset.valid.142, %descriptor.extent.inside.140
  %descriptor.range.valid.143 = and i1 %descriptor.range.inside.144, %descriptor.payload.inside.141
  %descriptor.type.valid.145 = icmp eq i32 1, 1
  %descriptor.valid.146 = and i1 %descriptor.range.valid.143, %descriptor.type.valid.145
  br i1 %descriptor.valid.146, label %descriptor.valid.147, label %descriptor.invalid.148
descriptor.invalid.148:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.147:
  %descriptor.initialized.status.149 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.105, i32 %descriptor.value.107)
  %helper.ok.150 = icmp eq i32 %descriptor.initialized.status.149, 0
  br i1 %helper.ok.150, label %helper.continue.151, label %frame.failure.0
helper.continue.151:
  %descriptor.element.152 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.153 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.152, i32 0, i32 0
  store i32 1, ptr %descriptor.field.153, align 4
  %descriptor.field.154 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.152, i32 0, i32 1
  store i32 %descriptor.value.105, ptr %descriptor.field.154, align 4
  %descriptor.field.155 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.152, i32 0, i32 2
  store i32 %descriptor.value.107, ptr %descriptor.field.155, align 4
  %descriptor.field.156 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.152, i32 0, i32 3
  store i32 %descriptor.value.109, ptr %descriptor.field.156, align 4
  %descriptor.field.157 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.152, i32 0, i32 4
  store i32 %descriptor.value.111, ptr %descriptor.field.157, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %descriptor.value.105, i32 20, i32 %descriptor.value.109, i32 %descriptor.value.111, i32 %descriptor.value.107)
  %context.field.158 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.159 = load i32, ptr %context.field.158, align 4
  %runtime.ok.160 = icmp eq i32 %context.value.159, 0
  br i1 %runtime.ok.160, label %runtime.continue.161, label %frame.failure.0
runtime.continue.161:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.162 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.163 = load i32, ptr %context.field.162, align 4
  %context.field.164 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.165 = load i32, ptr %context.field.164, align 4
  %context.field.166 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.167 = load i32, ptr %context.field.166, align 4
  %stack.offset.168 = add i32 %context.value.5, %context.value.7
  %stack.offset.169 = add i32 %context.value.163, %context.value.165
  %stack.sub.170 = sub i32 %stack.offset.168, %stack.offset.169
  %stack.sub.171 = sub i32 %context.value.7, %context.value.165
  %stack.sub.172 = sub i32 %context.value.167, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.170, i32 %stack.sub.171)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.172)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %local.active.2 = alloca i1, align 1
  %local.offset.3 = alloca i32, align 4
  %local.extent.4 = alloca i32, align 4
  %local.payload.5 = alloca i32, align 4
  %local.owner.end.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %local.active.8 = alloca i1, align 1
  %local.offset.9 = alloca i32, align 4
  %local.extent.10 = alloca i32, align 4
  %local.payload.11 = alloca i32, align 4
  %local.owner.end.12 = alloca i32, align 4
  %local.type.13 = alloca i32, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  %local.active.14 = alloca i1, align 1
  %local.offset.15 = alloca i32, align 4
  %local.extent.16 = alloca i32, align 4
  %local.payload.17 = alloca i32, align 4
  %local.owner.end.18 = alloca i32, align 4
  %local.type.19 = alloca i32, align 4
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  %context.field.20 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.21 = load i32, ptr %context.field.20, align 4
  %context.field.22 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.23 = load i32, ptr %context.field.22, align 4
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %frame.entered.28 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.29 = icmp eq i32 %frame.entered.28, 0
  br i1 %frame.enter.ok.29, label %frame.enter.continue.30, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.30:
  %descriptor.element.31 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.32 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.31, i32 0, i32 0
  %descriptor.value.33 = load i32, ptr %descriptor.field.32, align 4
  %descriptor.field.34 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.31, i32 0, i32 1
  %descriptor.value.35 = load i32, ptr %descriptor.field.34, align 4
  %descriptor.field.36 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.31, i32 0, i32 2
  %descriptor.value.37 = load i32, ptr %descriptor.field.36, align 4
  %descriptor.field.38 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.31, i32 0, i32 3
  %descriptor.value.39 = load i32, ptr %descriptor.field.38, align 4
  %descriptor.field.40 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.31, i32 0, i32 4
  %descriptor.value.41 = load i32, ptr %descriptor.field.40, align 4
  %argument.type.valid.42 = icmp eq i32 %descriptor.value.33, 7
  br i1 %argument.type.valid.42, label %argument.type.ok.43, label %frame.failure.0
argument.type.ok.43:
  %context.field.44 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.45 = load i32, ptr %context.field.44, align 4
  %stack.sub.48 = sub i32 %descriptor.value.41, %descriptor.value.35
  %descriptor.owner.inside.46 = icmp ule i32 %descriptor.value.41, %context.value.45
  %descriptor.offset.inside.47 = icmp ule i32 %descriptor.value.35, %descriptor.value.41
  %descriptor.extent.inside.49 = icmp ule i32 %descriptor.value.37, %stack.sub.48
  %descriptor.payload.inside.50 = icmp ule i32 %descriptor.value.39, %descriptor.value.37
  %descriptor.owner.offset.valid.51 = and i1 %descriptor.owner.inside.46, %descriptor.offset.inside.47
  %descriptor.range.inside.53 = and i1 %descriptor.owner.offset.valid.51, %descriptor.extent.inside.49
  %descriptor.range.valid.52 = and i1 %descriptor.range.inside.53, %descriptor.payload.inside.50
  %descriptor.type.valid.54 = icmp eq i32 7, 7
  %descriptor.valid.55 = and i1 %descriptor.range.valid.52, %descriptor.type.valid.54
  br i1 %descriptor.valid.55, label %descriptor.valid.56, label %descriptor.invalid.57
descriptor.invalid.57:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.56:
  %descriptor.initialized.status.58 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.35, i32 %descriptor.value.37)
  %helper.ok.59 = icmp eq i32 %descriptor.initialized.status.58, 0
  br i1 %helper.ok.59, label %helper.continue.60, label %frame.failure.0
helper.continue.60:
  %descriptor.element.61 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.62 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 0
  %descriptor.value.63 = load i32, ptr %descriptor.field.62, align 4
  %descriptor.field.64 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 1
  %descriptor.value.65 = load i32, ptr %descriptor.field.64, align 4
  %descriptor.field.66 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 2
  %descriptor.value.67 = load i32, ptr %descriptor.field.66, align 4
  %descriptor.field.68 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 3
  %descriptor.value.69 = load i32, ptr %descriptor.field.68, align 4
  %descriptor.field.70 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 4
  %descriptor.value.71 = load i32, ptr %descriptor.field.70, align 4
  %argument.type.valid.72 = icmp eq i32 %descriptor.value.63, 1
  br i1 %argument.type.valid.72, label %argument.type.ok.73, label %frame.failure.0
argument.type.ok.73:
  %context.field.74 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.75 = load i32, ptr %context.field.74, align 4
  %stack.sub.78 = sub i32 %descriptor.value.71, %descriptor.value.65
  %descriptor.owner.inside.76 = icmp ule i32 %descriptor.value.71, %context.value.75
  %descriptor.offset.inside.77 = icmp ule i32 %descriptor.value.65, %descriptor.value.71
  %descriptor.extent.inside.79 = icmp ule i32 %descriptor.value.67, %stack.sub.78
  %descriptor.payload.inside.80 = icmp ule i32 %descriptor.value.69, %descriptor.value.67
  %descriptor.owner.offset.valid.81 = and i1 %descriptor.owner.inside.76, %descriptor.offset.inside.77
  %descriptor.range.inside.83 = and i1 %descriptor.owner.offset.valid.81, %descriptor.extent.inside.79
  %descriptor.range.valid.82 = and i1 %descriptor.range.inside.83, %descriptor.payload.inside.80
  %descriptor.type.valid.84 = icmp eq i32 1, 1
  %descriptor.valid.85 = and i1 %descriptor.range.valid.82, %descriptor.type.valid.84
  br i1 %descriptor.valid.85, label %descriptor.valid.86, label %descriptor.invalid.87
descriptor.invalid.87:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.86:
  %descriptor.initialized.status.88 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.65, i32 %descriptor.value.67)
  %helper.ok.89 = icmp eq i32 %descriptor.initialized.status.88, 0
  br i1 %helper.ok.89, label %helper.continue.90, label %frame.failure.0
helper.continue.90:
  %step.status.91 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.92 = icmp eq i32 %step.status.91, 0
  br i1 %helper.ok.92, label %helper.continue.93, label %frame.failure.0
helper.continue.93:
  store i1 true, ptr %local.active.2, align 1
  store i32 %descriptor.value.65, ptr %local.offset.3, align 4
  store i32 %descriptor.value.67, ptr %local.extent.4, align 4
  store i32 %descriptor.value.69, ptr %local.payload.5, align 4
  store i32 %descriptor.value.71, ptr %local.owner.end.6, align 4
  store i32 1, ptr %local.type.7, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %descriptor.value.65, i32 20, i32 %descriptor.value.69, i32 %descriptor.value.71, i32 %descriptor.value.67)
  %context.field.94 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.95 = load i32, ptr %context.field.94, align 4
  %runtime.ok.96 = icmp eq i32 %context.value.95, 0
  br i1 %runtime.ok.96, label %runtime.continue.97, label %frame.failure.0
runtime.continue.97:
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %stack.sub.102 = sub i32 %descriptor.value.41, %descriptor.value.35
  %descriptor.owner.inside.100 = icmp ule i32 %descriptor.value.41, %context.value.99
  %descriptor.offset.inside.101 = icmp ule i32 %descriptor.value.35, %descriptor.value.41
  %descriptor.extent.inside.103 = icmp ule i32 %descriptor.value.37, %stack.sub.102
  %descriptor.payload.inside.104 = icmp ule i32 %descriptor.value.39, %descriptor.value.37
  %descriptor.owner.offset.valid.105 = and i1 %descriptor.owner.inside.100, %descriptor.offset.inside.101
  %descriptor.range.inside.107 = and i1 %descriptor.owner.offset.valid.105, %descriptor.extent.inside.103
  %descriptor.range.valid.106 = and i1 %descriptor.range.inside.107, %descriptor.payload.inside.104
  %descriptor.type.valid.108 = icmp eq i32 7, 7
  %descriptor.valid.109 = and i1 %descriptor.range.valid.106, %descriptor.type.valid.108
  br i1 %descriptor.valid.109, label %descriptor.valid.110, label %descriptor.invalid.111
descriptor.invalid.111:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.110:
  %descriptor.initialized.status.112 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.35, i32 %descriptor.value.37)
  %helper.ok.113 = icmp eq i32 %descriptor.initialized.status.112, 0
  br i1 %helper.ok.113, label %helper.continue.114, label %frame.failure.0
helper.continue.114:
  %local.is.active.115 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.115, label %local.descriptor.active.116, label %local.descriptor.inactive.117
local.descriptor.active.116:
  %local.check.offset.119 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.120 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.121 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.122 = load i32, ptr %local.owner.end.6, align 4
  %context.field.123 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.124 = load i32, ptr %context.field.123, align 4
  %stack.sub.127 = sub i32 %local.check.owner.end.122, %local.check.offset.119
  %descriptor.owner.inside.125 = icmp ule i32 %local.check.owner.end.122, %context.value.124
  %descriptor.offset.inside.126 = icmp ule i32 %local.check.offset.119, %local.check.owner.end.122
  %descriptor.extent.inside.128 = icmp ule i32 %local.check.extent.120, %stack.sub.127
  %descriptor.payload.inside.129 = icmp ule i32 %local.check.payload.121, %local.check.extent.120
  %descriptor.owner.offset.valid.130 = and i1 %descriptor.owner.inside.125, %descriptor.offset.inside.126
  %descriptor.range.inside.132 = and i1 %descriptor.owner.offset.valid.130, %descriptor.extent.inside.128
  %descriptor.range.valid.131 = and i1 %descriptor.range.inside.132, %descriptor.payload.inside.129
  br i1 %descriptor.range.valid.131, label %descriptor.valid.133, label %descriptor.invalid.134
descriptor.invalid.134:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.133:
  %descriptor.initialized.status.135 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.119, i32 %local.check.extent.120)
  %helper.ok.136 = icmp eq i32 %descriptor.initialized.status.135, 0
  br i1 %helper.ok.136, label %helper.continue.137, label %frame.failure.0
helper.continue.137:
  br label %local.descriptor.checked.118
local.descriptor.inactive.117:
  br label %local.descriptor.checked.118
local.descriptor.checked.118:
  %local.is.active.138 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.138, label %local.descriptor.active.139, label %local.descriptor.inactive.140
local.descriptor.active.139:
  %local.check.offset.142 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.143 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.144 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.145 = load i32, ptr %local.owner.end.12, align 4
  %context.field.146 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.147 = load i32, ptr %context.field.146, align 4
  %stack.sub.150 = sub i32 %local.check.owner.end.145, %local.check.offset.142
  %descriptor.owner.inside.148 = icmp ule i32 %local.check.owner.end.145, %context.value.147
  %descriptor.offset.inside.149 = icmp ule i32 %local.check.offset.142, %local.check.owner.end.145
  %descriptor.extent.inside.151 = icmp ule i32 %local.check.extent.143, %stack.sub.150
  %descriptor.payload.inside.152 = icmp ule i32 %local.check.payload.144, %local.check.extent.143
  %descriptor.owner.offset.valid.153 = and i1 %descriptor.owner.inside.148, %descriptor.offset.inside.149
  %descriptor.range.inside.155 = and i1 %descriptor.owner.offset.valid.153, %descriptor.extent.inside.151
  %descriptor.range.valid.154 = and i1 %descriptor.range.inside.155, %descriptor.payload.inside.152
  br i1 %descriptor.range.valid.154, label %descriptor.valid.156, label %descriptor.invalid.157
descriptor.invalid.157:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.156:
  %descriptor.initialized.status.158 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.142, i32 %local.check.extent.143)
  %helper.ok.159 = icmp eq i32 %descriptor.initialized.status.158, 0
  br i1 %helper.ok.159, label %helper.continue.160, label %frame.failure.0
helper.continue.160:
  br label %local.descriptor.checked.141
local.descriptor.inactive.140:
  br label %local.descriptor.checked.141
local.descriptor.checked.141:
  %local.is.active.161 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.161, label %local.descriptor.active.162, label %local.descriptor.inactive.163
local.descriptor.active.162:
  %local.check.offset.165 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.166 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.167 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.168 = load i32, ptr %local.owner.end.18, align 4
  %context.field.169 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.170 = load i32, ptr %context.field.169, align 4
  %stack.sub.173 = sub i32 %local.check.owner.end.168, %local.check.offset.165
  %descriptor.owner.inside.171 = icmp ule i32 %local.check.owner.end.168, %context.value.170
  %descriptor.offset.inside.172 = icmp ule i32 %local.check.offset.165, %local.check.owner.end.168
  %descriptor.extent.inside.174 = icmp ule i32 %local.check.extent.166, %stack.sub.173
  %descriptor.payload.inside.175 = icmp ule i32 %local.check.payload.167, %local.check.extent.166
  %descriptor.owner.offset.valid.176 = and i1 %descriptor.owner.inside.171, %descriptor.offset.inside.172
  %descriptor.range.inside.178 = and i1 %descriptor.owner.offset.valid.176, %descriptor.extent.inside.174
  %descriptor.range.valid.177 = and i1 %descriptor.range.inside.178, %descriptor.payload.inside.175
  br i1 %descriptor.range.valid.177, label %descriptor.valid.179, label %descriptor.invalid.180
descriptor.invalid.180:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.179:
  %descriptor.initialized.status.181 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.165, i32 %local.check.extent.166)
  %helper.ok.182 = icmp eq i32 %descriptor.initialized.status.181, 0
  br i1 %helper.ok.182, label %helper.continue.183, label %frame.failure.0
helper.continue.183:
  br label %local.descriptor.checked.164
local.descriptor.inactive.163:
  br label %local.descriptor.checked.164
local.descriptor.checked.164:
  %step.status.184 = call i32 @al_owning_charge_step(ptr %ctx, i32 4)
  %helper.ok.185 = icmp eq i32 %step.status.184, 0
  br i1 %helper.ok.185, label %helper.continue.186, label %frame.failure.0
helper.continue.186:
  store i1 true, ptr %local.active.8, align 1
  store i32 %descriptor.value.35, ptr %local.offset.9, align 4
  store i32 %descriptor.value.37, ptr %local.extent.10, align 4
  store i32 %descriptor.value.39, ptr %local.payload.11, align 4
  store i32 %descriptor.value.41, ptr %local.owner.end.12, align 4
  store i32 7, ptr %local.type.13, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 7, i32 %descriptor.value.35, i32 20, i32 %descriptor.value.39, i32 %descriptor.value.41, i32 %descriptor.value.37)
  %context.field.187 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.188 = load i32, ptr %context.field.187, align 4
  %runtime.ok.189 = icmp eq i32 %context.value.188, 0
  br i1 %runtime.ok.189, label %runtime.continue.190, label %frame.failure.0
runtime.continue.190:
  %local.is.active.191 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.191, label %local.descriptor.active.192, label %local.descriptor.inactive.193
local.descriptor.active.192:
  %local.check.offset.195 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.196 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.197 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.198 = load i32, ptr %local.owner.end.6, align 4
  %context.field.199 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.200 = load i32, ptr %context.field.199, align 4
  %stack.sub.203 = sub i32 %local.check.owner.end.198, %local.check.offset.195
  %descriptor.owner.inside.201 = icmp ule i32 %local.check.owner.end.198, %context.value.200
  %descriptor.offset.inside.202 = icmp ule i32 %local.check.offset.195, %local.check.owner.end.198
  %descriptor.extent.inside.204 = icmp ule i32 %local.check.extent.196, %stack.sub.203
  %descriptor.payload.inside.205 = icmp ule i32 %local.check.payload.197, %local.check.extent.196
  %descriptor.owner.offset.valid.206 = and i1 %descriptor.owner.inside.201, %descriptor.offset.inside.202
  %descriptor.range.inside.208 = and i1 %descriptor.owner.offset.valid.206, %descriptor.extent.inside.204
  %descriptor.range.valid.207 = and i1 %descriptor.range.inside.208, %descriptor.payload.inside.205
  br i1 %descriptor.range.valid.207, label %descriptor.valid.209, label %descriptor.invalid.210
descriptor.invalid.210:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.209:
  %descriptor.initialized.status.211 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.195, i32 %local.check.extent.196)
  %helper.ok.212 = icmp eq i32 %descriptor.initialized.status.211, 0
  br i1 %helper.ok.212, label %helper.continue.213, label %frame.failure.0
helper.continue.213:
  br label %local.descriptor.checked.194
local.descriptor.inactive.193:
  br label %local.descriptor.checked.194
local.descriptor.checked.194:
  %local.is.active.214 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.214, label %local.descriptor.active.215, label %local.descriptor.inactive.216
local.descriptor.active.215:
  %local.check.offset.218 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.219 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.220 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.221 = load i32, ptr %local.owner.end.12, align 4
  %context.field.222 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.223 = load i32, ptr %context.field.222, align 4
  %stack.sub.226 = sub i32 %local.check.owner.end.221, %local.check.offset.218
  %descriptor.owner.inside.224 = icmp ule i32 %local.check.owner.end.221, %context.value.223
  %descriptor.offset.inside.225 = icmp ule i32 %local.check.offset.218, %local.check.owner.end.221
  %descriptor.extent.inside.227 = icmp ule i32 %local.check.extent.219, %stack.sub.226
  %descriptor.payload.inside.228 = icmp ule i32 %local.check.payload.220, %local.check.extent.219
  %descriptor.owner.offset.valid.229 = and i1 %descriptor.owner.inside.224, %descriptor.offset.inside.225
  %descriptor.range.inside.231 = and i1 %descriptor.owner.offset.valid.229, %descriptor.extent.inside.227
  %descriptor.range.valid.230 = and i1 %descriptor.range.inside.231, %descriptor.payload.inside.228
  br i1 %descriptor.range.valid.230, label %descriptor.valid.232, label %descriptor.invalid.233
descriptor.invalid.233:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.232:
  %descriptor.initialized.status.234 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.218, i32 %local.check.extent.219)
  %helper.ok.235 = icmp eq i32 %descriptor.initialized.status.234, 0
  br i1 %helper.ok.235, label %helper.continue.236, label %frame.failure.0
helper.continue.236:
  br label %local.descriptor.checked.217
local.descriptor.inactive.216:
  br label %local.descriptor.checked.217
local.descriptor.checked.217:
  %local.is.active.237 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.237, label %local.descriptor.active.238, label %local.descriptor.inactive.239
local.descriptor.active.238:
  %local.check.offset.241 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.242 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.243 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.244 = load i32, ptr %local.owner.end.18, align 4
  %context.field.245 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.246 = load i32, ptr %context.field.245, align 4
  %stack.sub.249 = sub i32 %local.check.owner.end.244, %local.check.offset.241
  %descriptor.owner.inside.247 = icmp ule i32 %local.check.owner.end.244, %context.value.246
  %descriptor.offset.inside.248 = icmp ule i32 %local.check.offset.241, %local.check.owner.end.244
  %descriptor.extent.inside.250 = icmp ule i32 %local.check.extent.242, %stack.sub.249
  %descriptor.payload.inside.251 = icmp ule i32 %local.check.payload.243, %local.check.extent.242
  %descriptor.owner.offset.valid.252 = and i1 %descriptor.owner.inside.247, %descriptor.offset.inside.248
  %descriptor.range.inside.254 = and i1 %descriptor.owner.offset.valid.252, %descriptor.extent.inside.250
  %descriptor.range.valid.253 = and i1 %descriptor.range.inside.254, %descriptor.payload.inside.251
  br i1 %descriptor.range.valid.253, label %descriptor.valid.255, label %descriptor.invalid.256
descriptor.invalid.256:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.255:
  %descriptor.initialized.status.257 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.241, i32 %local.check.extent.242)
  %helper.ok.258 = icmp eq i32 %descriptor.initialized.status.257, 0
  br i1 %helper.ok.258, label %helper.continue.259, label %frame.failure.0
helper.continue.259:
  br label %local.descriptor.checked.240
local.descriptor.inactive.239:
  br label %local.descriptor.checked.240
local.descriptor.checked.240:
  %step.status.260 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.261 = icmp eq i32 %step.status.260, 0
  br i1 %helper.ok.261, label %helper.continue.262, label %frame.failure.0
helper.continue.262:
  %local.resolved.offset.263 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.264 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.265 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.266 = load i32, ptr %local.owner.end.6, align 4
  %context.field.267 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.268 = load i32, ptr %context.field.267, align 4
  %stack.sub.271 = sub i32 %local.resolved.owner.end.266, %local.resolved.offset.263
  %descriptor.owner.inside.269 = icmp ule i32 %local.resolved.owner.end.266, %context.value.268
  %descriptor.offset.inside.270 = icmp ule i32 %local.resolved.offset.263, %local.resolved.owner.end.266
  %descriptor.extent.inside.272 = icmp ule i32 %local.resolved.extent.264, %stack.sub.271
  %descriptor.payload.inside.273 = icmp ule i32 %local.resolved.payload.265, %local.resolved.extent.264
  %descriptor.owner.offset.valid.274 = and i1 %descriptor.owner.inside.269, %descriptor.offset.inside.270
  %descriptor.range.inside.276 = and i1 %descriptor.owner.offset.valid.274, %descriptor.extent.inside.272
  %descriptor.range.valid.275 = and i1 %descriptor.range.inside.276, %descriptor.payload.inside.273
  %descriptor.type.valid.277 = icmp eq i32 1, 1
  %descriptor.valid.278 = and i1 %descriptor.range.valid.275, %descriptor.type.valid.277
  br i1 %descriptor.valid.278, label %descriptor.valid.279, label %descriptor.invalid.280
descriptor.invalid.280:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.279:
  %descriptor.initialized.status.281 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.263, i32 %local.resolved.extent.264)
  %helper.ok.282 = icmp eq i32 %descriptor.initialized.status.281, 0
  br i1 %helper.ok.282, label %helper.continue.283, label %frame.failure.0
helper.continue.283:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %local.resolved.offset.263, i32 20, i32 %local.resolved.payload.265, i32 %local.resolved.owner.end.266, i32 %local.resolved.extent.264)
  %context.field.284 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.285 = load i32, ptr %context.field.284, align 4
  %runtime.ok.286 = icmp eq i32 %context.value.285, 0
  br i1 %runtime.ok.286, label %runtime.continue.287, label %frame.failure.0
runtime.continue.287:
  %context.field.288 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.289 = load i32, ptr %context.field.288, align 4
  %stack.sub.292 = sub i32 %local.resolved.owner.end.266, %local.resolved.offset.263
  %descriptor.owner.inside.290 = icmp ule i32 %local.resolved.owner.end.266, %context.value.289
  %descriptor.offset.inside.291 = icmp ule i32 %local.resolved.offset.263, %local.resolved.owner.end.266
  %descriptor.extent.inside.293 = icmp ule i32 %local.resolved.extent.264, %stack.sub.292
  %descriptor.payload.inside.294 = icmp ule i32 %local.resolved.payload.265, %local.resolved.extent.264
  %descriptor.owner.offset.valid.295 = and i1 %descriptor.owner.inside.290, %descriptor.offset.inside.291
  %descriptor.range.inside.297 = and i1 %descriptor.owner.offset.valid.295, %descriptor.extent.inside.293
  %descriptor.range.valid.296 = and i1 %descriptor.range.inside.297, %descriptor.payload.inside.294
  %descriptor.type.valid.298 = icmp eq i32 1, 1
  %descriptor.valid.299 = and i1 %descriptor.range.valid.296, %descriptor.type.valid.298
  br i1 %descriptor.valid.299, label %descriptor.valid.300, label %descriptor.invalid.301
descriptor.invalid.301:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.300:
  %descriptor.initialized.status.302 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.263, i32 %local.resolved.extent.264)
  %helper.ok.303 = icmp eq i32 %descriptor.initialized.status.302, 0
  br i1 %helper.ok.303, label %helper.continue.304, label %frame.failure.0
helper.continue.304:
  %local.is.active.305 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.305, label %local.descriptor.active.306, label %local.descriptor.inactive.307
local.descriptor.active.306:
  %local.check.offset.309 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.310 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.311 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.312 = load i32, ptr %local.owner.end.6, align 4
  %context.field.313 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.314 = load i32, ptr %context.field.313, align 4
  %stack.sub.317 = sub i32 %local.check.owner.end.312, %local.check.offset.309
  %descriptor.owner.inside.315 = icmp ule i32 %local.check.owner.end.312, %context.value.314
  %descriptor.offset.inside.316 = icmp ule i32 %local.check.offset.309, %local.check.owner.end.312
  %descriptor.extent.inside.318 = icmp ule i32 %local.check.extent.310, %stack.sub.317
  %descriptor.payload.inside.319 = icmp ule i32 %local.check.payload.311, %local.check.extent.310
  %descriptor.owner.offset.valid.320 = and i1 %descriptor.owner.inside.315, %descriptor.offset.inside.316
  %descriptor.range.inside.322 = and i1 %descriptor.owner.offset.valid.320, %descriptor.extent.inside.318
  %descriptor.range.valid.321 = and i1 %descriptor.range.inside.322, %descriptor.payload.inside.319
  br i1 %descriptor.range.valid.321, label %descriptor.valid.323, label %descriptor.invalid.324
descriptor.invalid.324:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.323:
  %descriptor.initialized.status.325 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.309, i32 %local.check.extent.310)
  %helper.ok.326 = icmp eq i32 %descriptor.initialized.status.325, 0
  br i1 %helper.ok.326, label %helper.continue.327, label %frame.failure.0
helper.continue.327:
  br label %local.descriptor.checked.308
local.descriptor.inactive.307:
  br label %local.descriptor.checked.308
local.descriptor.checked.308:
  %local.is.active.328 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.328, label %local.descriptor.active.329, label %local.descriptor.inactive.330
local.descriptor.active.329:
  %local.check.offset.332 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.333 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.334 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.335 = load i32, ptr %local.owner.end.12, align 4
  %context.field.336 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.337 = load i32, ptr %context.field.336, align 4
  %stack.sub.340 = sub i32 %local.check.owner.end.335, %local.check.offset.332
  %descriptor.owner.inside.338 = icmp ule i32 %local.check.owner.end.335, %context.value.337
  %descriptor.offset.inside.339 = icmp ule i32 %local.check.offset.332, %local.check.owner.end.335
  %descriptor.extent.inside.341 = icmp ule i32 %local.check.extent.333, %stack.sub.340
  %descriptor.payload.inside.342 = icmp ule i32 %local.check.payload.334, %local.check.extent.333
  %descriptor.owner.offset.valid.343 = and i1 %descriptor.owner.inside.338, %descriptor.offset.inside.339
  %descriptor.range.inside.345 = and i1 %descriptor.owner.offset.valid.343, %descriptor.extent.inside.341
  %descriptor.range.valid.344 = and i1 %descriptor.range.inside.345, %descriptor.payload.inside.342
  br i1 %descriptor.range.valid.344, label %descriptor.valid.346, label %descriptor.invalid.347
descriptor.invalid.347:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.346:
  %descriptor.initialized.status.348 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.332, i32 %local.check.extent.333)
  %helper.ok.349 = icmp eq i32 %descriptor.initialized.status.348, 0
  br i1 %helper.ok.349, label %helper.continue.350, label %frame.failure.0
helper.continue.350:
  br label %local.descriptor.checked.331
local.descriptor.inactive.330:
  br label %local.descriptor.checked.331
local.descriptor.checked.331:
  %local.is.active.351 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.351, label %local.descriptor.active.352, label %local.descriptor.inactive.353
local.descriptor.active.352:
  %local.check.offset.355 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.356 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.357 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.358 = load i32, ptr %local.owner.end.18, align 4
  %context.field.359 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.360 = load i32, ptr %context.field.359, align 4
  %stack.sub.363 = sub i32 %local.check.owner.end.358, %local.check.offset.355
  %descriptor.owner.inside.361 = icmp ule i32 %local.check.owner.end.358, %context.value.360
  %descriptor.offset.inside.362 = icmp ule i32 %local.check.offset.355, %local.check.owner.end.358
  %descriptor.extent.inside.364 = icmp ule i32 %local.check.extent.356, %stack.sub.363
  %descriptor.payload.inside.365 = icmp ule i32 %local.check.payload.357, %local.check.extent.356
  %descriptor.owner.offset.valid.366 = and i1 %descriptor.owner.inside.361, %descriptor.offset.inside.362
  %descriptor.range.inside.368 = and i1 %descriptor.owner.offset.valid.366, %descriptor.extent.inside.364
  %descriptor.range.valid.367 = and i1 %descriptor.range.inside.368, %descriptor.payload.inside.365
  br i1 %descriptor.range.valid.367, label %descriptor.valid.369, label %descriptor.invalid.370
descriptor.invalid.370:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.369:
  %descriptor.initialized.status.371 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.355, i32 %local.check.extent.356)
  %helper.ok.372 = icmp eq i32 %descriptor.initialized.status.371, 0
  br i1 %helper.ok.372, label %helper.continue.373, label %frame.failure.0
helper.continue.373:
  br label %local.descriptor.checked.354
local.descriptor.inactive.353:
  br label %local.descriptor.checked.354
local.descriptor.checked.354:
  %step.status.374 = call i32 @al_owning_charge_step(ptr %ctx, i32 6)
  %helper.ok.375 = icmp eq i32 %step.status.374, 0
  br i1 %helper.ok.375, label %helper.continue.376, label %frame.failure.0
helper.continue.376:
  %local.resolved.offset.377 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.378 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.379 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.380 = load i32, ptr %local.owner.end.6, align 4
  %context.field.381 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.382 = load i32, ptr %context.field.381, align 4
  %stack.sub.385 = sub i32 %local.resolved.owner.end.380, %local.resolved.offset.377
  %descriptor.owner.inside.383 = icmp ule i32 %local.resolved.owner.end.380, %context.value.382
  %descriptor.offset.inside.384 = icmp ule i32 %local.resolved.offset.377, %local.resolved.owner.end.380
  %descriptor.extent.inside.386 = icmp ule i32 %local.resolved.extent.378, %stack.sub.385
  %descriptor.payload.inside.387 = icmp ule i32 %local.resolved.payload.379, %local.resolved.extent.378
  %descriptor.owner.offset.valid.388 = and i1 %descriptor.owner.inside.383, %descriptor.offset.inside.384
  %descriptor.range.inside.390 = and i1 %descriptor.owner.offset.valid.388, %descriptor.extent.inside.386
  %descriptor.range.valid.389 = and i1 %descriptor.range.inside.390, %descriptor.payload.inside.387
  %descriptor.type.valid.391 = icmp eq i32 1, 1
  %descriptor.valid.392 = and i1 %descriptor.range.valid.389, %descriptor.type.valid.391
  br i1 %descriptor.valid.392, label %descriptor.valid.393, label %descriptor.invalid.394
descriptor.invalid.394:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.393:
  %descriptor.initialized.status.395 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.377, i32 %local.resolved.extent.378)
  %helper.ok.396 = icmp eq i32 %descriptor.initialized.status.395, 0
  br i1 %helper.ok.396, label %helper.continue.397, label %frame.failure.0
helper.continue.397:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %local.resolved.offset.377, i32 20, i32 %local.resolved.payload.379, i32 %local.resolved.owner.end.380, i32 %local.resolved.extent.378)
  %context.field.398 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.399 = load i32, ptr %context.field.398, align 4
  %runtime.ok.400 = icmp eq i32 %context.value.399, 0
  br i1 %runtime.ok.400, label %runtime.continue.401, label %frame.failure.0
runtime.continue.401:
  %context.field.402 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.403 = load i32, ptr %context.field.402, align 4
  %stack.sub.406 = sub i32 %local.resolved.owner.end.266, %local.resolved.offset.263
  %descriptor.owner.inside.404 = icmp ule i32 %local.resolved.owner.end.266, %context.value.403
  %descriptor.offset.inside.405 = icmp ule i32 %local.resolved.offset.263, %local.resolved.owner.end.266
  %descriptor.extent.inside.407 = icmp ule i32 %local.resolved.extent.264, %stack.sub.406
  %descriptor.payload.inside.408 = icmp ule i32 %local.resolved.payload.265, %local.resolved.extent.264
  %descriptor.owner.offset.valid.409 = and i1 %descriptor.owner.inside.404, %descriptor.offset.inside.405
  %descriptor.range.inside.411 = and i1 %descriptor.owner.offset.valid.409, %descriptor.extent.inside.407
  %descriptor.range.valid.410 = and i1 %descriptor.range.inside.411, %descriptor.payload.inside.408
  %descriptor.type.valid.412 = icmp eq i32 1, 1
  %descriptor.valid.413 = and i1 %descriptor.range.valid.410, %descriptor.type.valid.412
  br i1 %descriptor.valid.413, label %descriptor.valid.414, label %descriptor.invalid.415
descriptor.invalid.415:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.414:
  %descriptor.initialized.status.416 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.263, i32 %local.resolved.extent.264)
  %helper.ok.417 = icmp eq i32 %descriptor.initialized.status.416, 0
  br i1 %helper.ok.417, label %helper.continue.418, label %frame.failure.0
helper.continue.418:
  %context.field.419 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.420 = load i32, ptr %context.field.419, align 4
  %stack.sub.423 = sub i32 %local.resolved.owner.end.380, %local.resolved.offset.377
  %descriptor.owner.inside.421 = icmp ule i32 %local.resolved.owner.end.380, %context.value.420
  %descriptor.offset.inside.422 = icmp ule i32 %local.resolved.offset.377, %local.resolved.owner.end.380
  %descriptor.extent.inside.424 = icmp ule i32 %local.resolved.extent.378, %stack.sub.423
  %descriptor.payload.inside.425 = icmp ule i32 %local.resolved.payload.379, %local.resolved.extent.378
  %descriptor.owner.offset.valid.426 = and i1 %descriptor.owner.inside.421, %descriptor.offset.inside.422
  %descriptor.range.inside.428 = and i1 %descriptor.owner.offset.valid.426, %descriptor.extent.inside.424
  %descriptor.range.valid.427 = and i1 %descriptor.range.inside.428, %descriptor.payload.inside.425
  %descriptor.type.valid.429 = icmp eq i32 1, 1
  %descriptor.valid.430 = and i1 %descriptor.range.valid.427, %descriptor.type.valid.429
  br i1 %descriptor.valid.430, label %descriptor.valid.431, label %descriptor.invalid.432
descriptor.invalid.432:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.431:
  %descriptor.initialized.status.433 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.377, i32 %local.resolved.extent.378)
  %helper.ok.434 = icmp eq i32 %descriptor.initialized.status.433, 0
  br i1 %helper.ok.434, label %helper.continue.435, label %frame.failure.0
helper.continue.435:
  %local.is.active.436 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.436, label %local.descriptor.active.437, label %local.descriptor.inactive.438
local.descriptor.active.437:
  %local.check.offset.440 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.441 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.442 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.443 = load i32, ptr %local.owner.end.6, align 4
  %context.field.444 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.445 = load i32, ptr %context.field.444, align 4
  %stack.sub.448 = sub i32 %local.check.owner.end.443, %local.check.offset.440
  %descriptor.owner.inside.446 = icmp ule i32 %local.check.owner.end.443, %context.value.445
  %descriptor.offset.inside.447 = icmp ule i32 %local.check.offset.440, %local.check.owner.end.443
  %descriptor.extent.inside.449 = icmp ule i32 %local.check.extent.441, %stack.sub.448
  %descriptor.payload.inside.450 = icmp ule i32 %local.check.payload.442, %local.check.extent.441
  %descriptor.owner.offset.valid.451 = and i1 %descriptor.owner.inside.446, %descriptor.offset.inside.447
  %descriptor.range.inside.453 = and i1 %descriptor.owner.offset.valid.451, %descriptor.extent.inside.449
  %descriptor.range.valid.452 = and i1 %descriptor.range.inside.453, %descriptor.payload.inside.450
  br i1 %descriptor.range.valid.452, label %descriptor.valid.454, label %descriptor.invalid.455
descriptor.invalid.455:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.454:
  %descriptor.initialized.status.456 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.440, i32 %local.check.extent.441)
  %helper.ok.457 = icmp eq i32 %descriptor.initialized.status.456, 0
  br i1 %helper.ok.457, label %helper.continue.458, label %frame.failure.0
helper.continue.458:
  br label %local.descriptor.checked.439
local.descriptor.inactive.438:
  br label %local.descriptor.checked.439
local.descriptor.checked.439:
  %local.is.active.459 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.459, label %local.descriptor.active.460, label %local.descriptor.inactive.461
local.descriptor.active.460:
  %local.check.offset.463 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.464 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.465 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.466 = load i32, ptr %local.owner.end.12, align 4
  %context.field.467 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.468 = load i32, ptr %context.field.467, align 4
  %stack.sub.471 = sub i32 %local.check.owner.end.466, %local.check.offset.463
  %descriptor.owner.inside.469 = icmp ule i32 %local.check.owner.end.466, %context.value.468
  %descriptor.offset.inside.470 = icmp ule i32 %local.check.offset.463, %local.check.owner.end.466
  %descriptor.extent.inside.472 = icmp ule i32 %local.check.extent.464, %stack.sub.471
  %descriptor.payload.inside.473 = icmp ule i32 %local.check.payload.465, %local.check.extent.464
  %descriptor.owner.offset.valid.474 = and i1 %descriptor.owner.inside.469, %descriptor.offset.inside.470
  %descriptor.range.inside.476 = and i1 %descriptor.owner.offset.valid.474, %descriptor.extent.inside.472
  %descriptor.range.valid.475 = and i1 %descriptor.range.inside.476, %descriptor.payload.inside.473
  br i1 %descriptor.range.valid.475, label %descriptor.valid.477, label %descriptor.invalid.478
descriptor.invalid.478:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.477:
  %descriptor.initialized.status.479 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.463, i32 %local.check.extent.464)
  %helper.ok.480 = icmp eq i32 %descriptor.initialized.status.479, 0
  br i1 %helper.ok.480, label %helper.continue.481, label %frame.failure.0
helper.continue.481:
  br label %local.descriptor.checked.462
local.descriptor.inactive.461:
  br label %local.descriptor.checked.462
local.descriptor.checked.462:
  %local.is.active.482 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.482, label %local.descriptor.active.483, label %local.descriptor.inactive.484
local.descriptor.active.483:
  %local.check.offset.486 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.487 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.488 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.489 = load i32, ptr %local.owner.end.18, align 4
  %context.field.490 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.491 = load i32, ptr %context.field.490, align 4
  %stack.sub.494 = sub i32 %local.check.owner.end.489, %local.check.offset.486
  %descriptor.owner.inside.492 = icmp ule i32 %local.check.owner.end.489, %context.value.491
  %descriptor.offset.inside.493 = icmp ule i32 %local.check.offset.486, %local.check.owner.end.489
  %descriptor.extent.inside.495 = icmp ule i32 %local.check.extent.487, %stack.sub.494
  %descriptor.payload.inside.496 = icmp ule i32 %local.check.payload.488, %local.check.extent.487
  %descriptor.owner.offset.valid.497 = and i1 %descriptor.owner.inside.492, %descriptor.offset.inside.493
  %descriptor.range.inside.499 = and i1 %descriptor.owner.offset.valid.497, %descriptor.extent.inside.495
  %descriptor.range.valid.498 = and i1 %descriptor.range.inside.499, %descriptor.payload.inside.496
  br i1 %descriptor.range.valid.498, label %descriptor.valid.500, label %descriptor.invalid.501
descriptor.invalid.501:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.500:
  %descriptor.initialized.status.502 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.486, i32 %local.check.extent.487)
  %helper.ok.503 = icmp eq i32 %descriptor.initialized.status.502, 0
  br i1 %helper.ok.503, label %helper.continue.504, label %frame.failure.0
helper.continue.504:
  br label %local.descriptor.checked.485
local.descriptor.inactive.484:
  br label %local.descriptor.checked.485
local.descriptor.checked.485:
  %step.status.505 = call i32 @al_owning_charge_step(ptr %ctx, i32 7)
  %helper.ok.506 = icmp eq i32 %step.status.505, 0
  br i1 %helper.ok.506, label %helper.continue.507, label %frame.failure.0
helper.continue.507:
  %context.field.508 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.509 = load i32, ptr %context.field.508, align 4
  %stack.offset.510 = add i32 %context.value.509, 8
  %reserve.status.511 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.510, i32 8)
  %reserve.ok.512 = icmp eq i32 %reserve.status.511, 0
  br i1 %reserve.ok.512, label %reserve.continue.513, label %frame.failure.0
reserve.continue.513:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.509, i64 1, i32 1)
  %context.field.514 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.515 = load i32, ptr %context.field.514, align 4
  %runtime.ok.516 = icmp eq i32 %context.value.515, 0
  br i1 %runtime.ok.516, label %runtime.continue.517, label %frame.failure.0
runtime.continue.517:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.518 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.519 = load i32, ptr %context.field.518, align 4
  %runtime.ok.520 = icmp eq i32 %context.value.519, 0
  br i1 %runtime.ok.520, label %runtime.continue.521, label %frame.failure.0
runtime.continue.521:
  %context.field.522 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.523 = load i32, ptr %context.field.522, align 4
  %stack.sub.526 = sub i32 %local.resolved.owner.end.266, %local.resolved.offset.263
  %descriptor.owner.inside.524 = icmp ule i32 %local.resolved.owner.end.266, %context.value.523
  %descriptor.offset.inside.525 = icmp ule i32 %local.resolved.offset.263, %local.resolved.owner.end.266
  %descriptor.extent.inside.527 = icmp ule i32 %local.resolved.extent.264, %stack.sub.526
  %descriptor.payload.inside.528 = icmp ule i32 %local.resolved.payload.265, %local.resolved.extent.264
  %descriptor.owner.offset.valid.529 = and i1 %descriptor.owner.inside.524, %descriptor.offset.inside.525
  %descriptor.range.inside.531 = and i1 %descriptor.owner.offset.valid.529, %descriptor.extent.inside.527
  %descriptor.range.valid.530 = and i1 %descriptor.range.inside.531, %descriptor.payload.inside.528
  %descriptor.type.valid.532 = icmp eq i32 1, 1
  %descriptor.valid.533 = and i1 %descriptor.range.valid.530, %descriptor.type.valid.532
  br i1 %descriptor.valid.533, label %descriptor.valid.534, label %descriptor.invalid.535
descriptor.invalid.535:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.534:
  %descriptor.initialized.status.536 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.263, i32 %local.resolved.extent.264)
  %helper.ok.537 = icmp eq i32 %descriptor.initialized.status.536, 0
  br i1 %helper.ok.537, label %helper.continue.538, label %frame.failure.0
helper.continue.538:
  %context.field.539 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.540 = load i32, ptr %context.field.539, align 4
  %stack.sub.543 = sub i32 %local.resolved.owner.end.380, %local.resolved.offset.377
  %descriptor.owner.inside.541 = icmp ule i32 %local.resolved.owner.end.380, %context.value.540
  %descriptor.offset.inside.542 = icmp ule i32 %local.resolved.offset.377, %local.resolved.owner.end.380
  %descriptor.extent.inside.544 = icmp ule i32 %local.resolved.extent.378, %stack.sub.543
  %descriptor.payload.inside.545 = icmp ule i32 %local.resolved.payload.379, %local.resolved.extent.378
  %descriptor.owner.offset.valid.546 = and i1 %descriptor.owner.inside.541, %descriptor.offset.inside.542
  %descriptor.range.inside.548 = and i1 %descriptor.owner.offset.valid.546, %descriptor.extent.inside.544
  %descriptor.range.valid.547 = and i1 %descriptor.range.inside.548, %descriptor.payload.inside.545
  %descriptor.type.valid.549 = icmp eq i32 1, 1
  %descriptor.valid.550 = and i1 %descriptor.range.valid.547, %descriptor.type.valid.549
  br i1 %descriptor.valid.550, label %descriptor.valid.551, label %descriptor.invalid.552
descriptor.invalid.552:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.551:
  %descriptor.initialized.status.553 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.377, i32 %local.resolved.extent.378)
  %helper.ok.554 = icmp eq i32 %descriptor.initialized.status.553, 0
  br i1 %helper.ok.554, label %helper.continue.555, label %frame.failure.0
helper.continue.555:
  %context.field.556 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.557 = load i32, ptr %context.field.556, align 4
  %stack.sub.560 = sub i32 %stack.offset.510, %context.value.509
  %descriptor.owner.inside.558 = icmp ule i32 %stack.offset.510, %context.value.557
  %descriptor.offset.inside.559 = icmp ule i32 %context.value.509, %stack.offset.510
  %descriptor.extent.inside.561 = icmp ule i32 8, %stack.sub.560
  %descriptor.payload.inside.562 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.563 = and i1 %descriptor.owner.inside.558, %descriptor.offset.inside.559
  %descriptor.range.inside.565 = and i1 %descriptor.owner.offset.valid.563, %descriptor.extent.inside.561
  %descriptor.range.valid.564 = and i1 %descriptor.range.inside.565, %descriptor.payload.inside.562
  %descriptor.type.valid.566 = icmp eq i32 1, 1
  %descriptor.valid.567 = and i1 %descriptor.range.valid.564, %descriptor.type.valid.566
  br i1 %descriptor.valid.567, label %descriptor.valid.568, label %descriptor.invalid.569
descriptor.invalid.569:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.568:
  %descriptor.initialized.status.570 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.509, i32 8)
  %helper.ok.571 = icmp eq i32 %descriptor.initialized.status.570, 0
  br i1 %helper.ok.571, label %helper.continue.572, label %frame.failure.0
helper.continue.572:
  %local.is.active.573 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.573, label %local.descriptor.active.574, label %local.descriptor.inactive.575
local.descriptor.active.574:
  %local.check.offset.577 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.578 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.579 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.580 = load i32, ptr %local.owner.end.6, align 4
  %context.field.581 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.582 = load i32, ptr %context.field.581, align 4
  %stack.sub.585 = sub i32 %local.check.owner.end.580, %local.check.offset.577
  %descriptor.owner.inside.583 = icmp ule i32 %local.check.owner.end.580, %context.value.582
  %descriptor.offset.inside.584 = icmp ule i32 %local.check.offset.577, %local.check.owner.end.580
  %descriptor.extent.inside.586 = icmp ule i32 %local.check.extent.578, %stack.sub.585
  %descriptor.payload.inside.587 = icmp ule i32 %local.check.payload.579, %local.check.extent.578
  %descriptor.owner.offset.valid.588 = and i1 %descriptor.owner.inside.583, %descriptor.offset.inside.584
  %descriptor.range.inside.590 = and i1 %descriptor.owner.offset.valid.588, %descriptor.extent.inside.586
  %descriptor.range.valid.589 = and i1 %descriptor.range.inside.590, %descriptor.payload.inside.587
  br i1 %descriptor.range.valid.589, label %descriptor.valid.591, label %descriptor.invalid.592
descriptor.invalid.592:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.591:
  %descriptor.initialized.status.593 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.577, i32 %local.check.extent.578)
  %helper.ok.594 = icmp eq i32 %descriptor.initialized.status.593, 0
  br i1 %helper.ok.594, label %helper.continue.595, label %frame.failure.0
helper.continue.595:
  br label %local.descriptor.checked.576
local.descriptor.inactive.575:
  br label %local.descriptor.checked.576
local.descriptor.checked.576:
  %local.is.active.596 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.596, label %local.descriptor.active.597, label %local.descriptor.inactive.598
local.descriptor.active.597:
  %local.check.offset.600 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.601 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.602 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.603 = load i32, ptr %local.owner.end.12, align 4
  %context.field.604 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.605 = load i32, ptr %context.field.604, align 4
  %stack.sub.608 = sub i32 %local.check.owner.end.603, %local.check.offset.600
  %descriptor.owner.inside.606 = icmp ule i32 %local.check.owner.end.603, %context.value.605
  %descriptor.offset.inside.607 = icmp ule i32 %local.check.offset.600, %local.check.owner.end.603
  %descriptor.extent.inside.609 = icmp ule i32 %local.check.extent.601, %stack.sub.608
  %descriptor.payload.inside.610 = icmp ule i32 %local.check.payload.602, %local.check.extent.601
  %descriptor.owner.offset.valid.611 = and i1 %descriptor.owner.inside.606, %descriptor.offset.inside.607
  %descriptor.range.inside.613 = and i1 %descriptor.owner.offset.valid.611, %descriptor.extent.inside.609
  %descriptor.range.valid.612 = and i1 %descriptor.range.inside.613, %descriptor.payload.inside.610
  br i1 %descriptor.range.valid.612, label %descriptor.valid.614, label %descriptor.invalid.615
descriptor.invalid.615:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.614:
  %descriptor.initialized.status.616 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.600, i32 %local.check.extent.601)
  %helper.ok.617 = icmp eq i32 %descriptor.initialized.status.616, 0
  br i1 %helper.ok.617, label %helper.continue.618, label %frame.failure.0
helper.continue.618:
  br label %local.descriptor.checked.599
local.descriptor.inactive.598:
  br label %local.descriptor.checked.599
local.descriptor.checked.599:
  %local.is.active.619 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.619, label %local.descriptor.active.620, label %local.descriptor.inactive.621
local.descriptor.active.620:
  %local.check.offset.623 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.624 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.625 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.626 = load i32, ptr %local.owner.end.18, align 4
  %context.field.627 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.628 = load i32, ptr %context.field.627, align 4
  %stack.sub.631 = sub i32 %local.check.owner.end.626, %local.check.offset.623
  %descriptor.owner.inside.629 = icmp ule i32 %local.check.owner.end.626, %context.value.628
  %descriptor.offset.inside.630 = icmp ule i32 %local.check.offset.623, %local.check.owner.end.626
  %descriptor.extent.inside.632 = icmp ule i32 %local.check.extent.624, %stack.sub.631
  %descriptor.payload.inside.633 = icmp ule i32 %local.check.payload.625, %local.check.extent.624
  %descriptor.owner.offset.valid.634 = and i1 %descriptor.owner.inside.629, %descriptor.offset.inside.630
  %descriptor.range.inside.636 = and i1 %descriptor.owner.offset.valid.634, %descriptor.extent.inside.632
  %descriptor.range.valid.635 = and i1 %descriptor.range.inside.636, %descriptor.payload.inside.633
  br i1 %descriptor.range.valid.635, label %descriptor.valid.637, label %descriptor.invalid.638
descriptor.invalid.638:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.637:
  %descriptor.initialized.status.639 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.623, i32 %local.check.extent.624)
  %helper.ok.640 = icmp eq i32 %descriptor.initialized.status.639, 0
  br i1 %helper.ok.640, label %helper.continue.641, label %frame.failure.0
helper.continue.641:
  br label %local.descriptor.checked.622
local.descriptor.inactive.621:
  br label %local.descriptor.checked.622
local.descriptor.checked.622:
  %step.status.642 = call i32 @al_owning_charge_step(ptr %ctx, i32 9)
  %helper.ok.643 = icmp eq i32 %step.status.642, 0
  br i1 %helper.ok.643, label %helper.continue.644, label %frame.failure.0
helper.continue.644:
  %integer.left.645 = call i64 @al_owning_load_i64(ptr %ctx, i32 %local.resolved.offset.377)
  %context.field.647 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.648 = load i32, ptr %context.field.647, align 4
  %runtime.ok.649 = icmp eq i32 %context.value.648, 0
  br i1 %runtime.ok.649, label %runtime.continue.650, label %frame.failure.0
runtime.continue.650:
  %integer.right.646 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.509)
  %context.field.651 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.652 = load i32, ptr %context.field.651, align 4
  %runtime.ok.653 = icmp eq i32 %context.value.652, 0
  br i1 %runtime.ok.653, label %runtime.continue.654, label %frame.failure.0
runtime.continue.654:
  %integer.checked.655 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %integer.left.645, i64 %integer.right.646)
  %integer.result.656 = extractvalue { i64, i1 } %integer.checked.655, 0
  %integer.overflow.657 = extractvalue { i64, i1 } %integer.checked.655, 1
  br i1 %integer.overflow.657, label %integer.overflow.658, label %integer.valid.659
integer.overflow.658:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 10, i32 0, i32 0)
  br label %frame.failure.0
integer.valid.659:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.509, i32 8, i32 8, i32 0, i32 0)
  %context.field.660 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.661 = load i32, ptr %context.field.660, align 4
  %runtime.ok.662 = icmp eq i32 %context.value.661, 0
  br i1 %runtime.ok.662, label %runtime.continue.663, label %frame.failure.0
runtime.continue.663:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %local.resolved.offset.377, i32 %local.resolved.extent.378, i32 %local.resolved.payload.379, i32 0, i32 0)
  %context.field.664 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.665 = load i32, ptr %context.field.664, align 4
  %runtime.ok.666 = icmp eq i32 %context.value.665, 0
  br i1 %runtime.ok.666, label %runtime.continue.667, label %frame.failure.0
runtime.continue.667:
  %context.field.668 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.669 = load i32, ptr %context.field.668, align 4
  %stack.offset.670 = add i32 %context.value.669, 8
  %reserve.status.671 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.670, i32 11)
  %reserve.ok.672 = icmp eq i32 %reserve.status.671, 0
  br i1 %reserve.ok.672, label %reserve.continue.673, label %frame.failure.0
reserve.continue.673:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.669, i64 %integer.result.656, i32 1)
  %context.field.674 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.675 = load i32, ptr %context.field.674, align 4
  %runtime.ok.676 = icmp eq i32 %context.value.675, 0
  br i1 %runtime.ok.676, label %runtime.continue.677, label %frame.failure.0
runtime.continue.677:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.678 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.679 = load i32, ptr %context.field.678, align 4
  %runtime.ok.680 = icmp eq i32 %context.value.679, 0
  br i1 %runtime.ok.680, label %runtime.continue.681, label %frame.failure.0
runtime.continue.681:
  %stack.offset.682 = add i32 %context.value.669, 8
  %context.field.683 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.684 = load i32, ptr %context.field.683, align 4
  %stack.sub.687 = sub i32 %local.resolved.owner.end.266, %local.resolved.offset.263
  %descriptor.owner.inside.685 = icmp ule i32 %local.resolved.owner.end.266, %context.value.684
  %descriptor.offset.inside.686 = icmp ule i32 %local.resolved.offset.263, %local.resolved.owner.end.266
  %descriptor.extent.inside.688 = icmp ule i32 %local.resolved.extent.264, %stack.sub.687
  %descriptor.payload.inside.689 = icmp ule i32 %local.resolved.payload.265, %local.resolved.extent.264
  %descriptor.owner.offset.valid.690 = and i1 %descriptor.owner.inside.685, %descriptor.offset.inside.686
  %descriptor.range.inside.692 = and i1 %descriptor.owner.offset.valid.690, %descriptor.extent.inside.688
  %descriptor.range.valid.691 = and i1 %descriptor.range.inside.692, %descriptor.payload.inside.689
  %descriptor.type.valid.693 = icmp eq i32 1, 1
  %descriptor.valid.694 = and i1 %descriptor.range.valid.691, %descriptor.type.valid.693
  br i1 %descriptor.valid.694, label %descriptor.valid.695, label %descriptor.invalid.696
descriptor.invalid.696:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.695:
  %descriptor.initialized.status.697 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.263, i32 %local.resolved.extent.264)
  %helper.ok.698 = icmp eq i32 %descriptor.initialized.status.697, 0
  br i1 %helper.ok.698, label %helper.continue.699, label %frame.failure.0
helper.continue.699:
  %context.field.700 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.701 = load i32, ptr %context.field.700, align 4
  %stack.sub.704 = sub i32 %stack.offset.682, %context.value.669
  %descriptor.owner.inside.702 = icmp ule i32 %stack.offset.682, %context.value.701
  %descriptor.offset.inside.703 = icmp ule i32 %context.value.669, %stack.offset.682
  %descriptor.extent.inside.705 = icmp ule i32 8, %stack.sub.704
  %descriptor.payload.inside.706 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.707 = and i1 %descriptor.owner.inside.702, %descriptor.offset.inside.703
  %descriptor.range.inside.709 = and i1 %descriptor.owner.offset.valid.707, %descriptor.extent.inside.705
  %descriptor.range.valid.708 = and i1 %descriptor.range.inside.709, %descriptor.payload.inside.706
  %descriptor.type.valid.710 = icmp eq i32 1, 1
  %descriptor.valid.711 = and i1 %descriptor.range.valid.708, %descriptor.type.valid.710
  br i1 %descriptor.valid.711, label %descriptor.valid.712, label %descriptor.invalid.713
descriptor.invalid.713:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.712:
  %descriptor.initialized.status.714 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.669, i32 8)
  %helper.ok.715 = icmp eq i32 %descriptor.initialized.status.714, 0
  br i1 %helper.ok.715, label %helper.continue.716, label %frame.failure.0
helper.continue.716:
  %local.is.active.717 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.717, label %local.descriptor.active.718, label %local.descriptor.inactive.719
local.descriptor.active.718:
  %local.check.offset.721 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.722 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.723 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.724 = load i32, ptr %local.owner.end.6, align 4
  %context.field.725 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.726 = load i32, ptr %context.field.725, align 4
  %stack.sub.729 = sub i32 %local.check.owner.end.724, %local.check.offset.721
  %descriptor.owner.inside.727 = icmp ule i32 %local.check.owner.end.724, %context.value.726
  %descriptor.offset.inside.728 = icmp ule i32 %local.check.offset.721, %local.check.owner.end.724
  %descriptor.extent.inside.730 = icmp ule i32 %local.check.extent.722, %stack.sub.729
  %descriptor.payload.inside.731 = icmp ule i32 %local.check.payload.723, %local.check.extent.722
  %descriptor.owner.offset.valid.732 = and i1 %descriptor.owner.inside.727, %descriptor.offset.inside.728
  %descriptor.range.inside.734 = and i1 %descriptor.owner.offset.valid.732, %descriptor.extent.inside.730
  %descriptor.range.valid.733 = and i1 %descriptor.range.inside.734, %descriptor.payload.inside.731
  br i1 %descriptor.range.valid.733, label %descriptor.valid.735, label %descriptor.invalid.736
descriptor.invalid.736:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.735:
  %descriptor.initialized.status.737 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.721, i32 %local.check.extent.722)
  %helper.ok.738 = icmp eq i32 %descriptor.initialized.status.737, 0
  br i1 %helper.ok.738, label %helper.continue.739, label %frame.failure.0
helper.continue.739:
  br label %local.descriptor.checked.720
local.descriptor.inactive.719:
  br label %local.descriptor.checked.720
local.descriptor.checked.720:
  %local.is.active.740 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.740, label %local.descriptor.active.741, label %local.descriptor.inactive.742
local.descriptor.active.741:
  %local.check.offset.744 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.745 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.746 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.747 = load i32, ptr %local.owner.end.12, align 4
  %context.field.748 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.749 = load i32, ptr %context.field.748, align 4
  %stack.sub.752 = sub i32 %local.check.owner.end.747, %local.check.offset.744
  %descriptor.owner.inside.750 = icmp ule i32 %local.check.owner.end.747, %context.value.749
  %descriptor.offset.inside.751 = icmp ule i32 %local.check.offset.744, %local.check.owner.end.747
  %descriptor.extent.inside.753 = icmp ule i32 %local.check.extent.745, %stack.sub.752
  %descriptor.payload.inside.754 = icmp ule i32 %local.check.payload.746, %local.check.extent.745
  %descriptor.owner.offset.valid.755 = and i1 %descriptor.owner.inside.750, %descriptor.offset.inside.751
  %descriptor.range.inside.757 = and i1 %descriptor.owner.offset.valid.755, %descriptor.extent.inside.753
  %descriptor.range.valid.756 = and i1 %descriptor.range.inside.757, %descriptor.payload.inside.754
  br i1 %descriptor.range.valid.756, label %descriptor.valid.758, label %descriptor.invalid.759
descriptor.invalid.759:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.758:
  %descriptor.initialized.status.760 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.744, i32 %local.check.extent.745)
  %helper.ok.761 = icmp eq i32 %descriptor.initialized.status.760, 0
  br i1 %helper.ok.761, label %helper.continue.762, label %frame.failure.0
helper.continue.762:
  br label %local.descriptor.checked.743
local.descriptor.inactive.742:
  br label %local.descriptor.checked.743
local.descriptor.checked.743:
  %local.is.active.763 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.763, label %local.descriptor.active.764, label %local.descriptor.inactive.765
local.descriptor.active.764:
  %local.check.offset.767 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.768 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.769 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.770 = load i32, ptr %local.owner.end.18, align 4
  %context.field.771 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.772 = load i32, ptr %context.field.771, align 4
  %stack.sub.775 = sub i32 %local.check.owner.end.770, %local.check.offset.767
  %descriptor.owner.inside.773 = icmp ule i32 %local.check.owner.end.770, %context.value.772
  %descriptor.offset.inside.774 = icmp ule i32 %local.check.offset.767, %local.check.owner.end.770
  %descriptor.extent.inside.776 = icmp ule i32 %local.check.extent.768, %stack.sub.775
  %descriptor.payload.inside.777 = icmp ule i32 %local.check.payload.769, %local.check.extent.768
  %descriptor.owner.offset.valid.778 = and i1 %descriptor.owner.inside.773, %descriptor.offset.inside.774
  %descriptor.range.inside.780 = and i1 %descriptor.owner.offset.valid.778, %descriptor.extent.inside.776
  %descriptor.range.valid.779 = and i1 %descriptor.range.inside.780, %descriptor.payload.inside.777
  br i1 %descriptor.range.valid.779, label %descriptor.valid.781, label %descriptor.invalid.782
descriptor.invalid.782:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.781:
  %descriptor.initialized.status.783 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.767, i32 %local.check.extent.768)
  %helper.ok.784 = icmp eq i32 %descriptor.initialized.status.783, 0
  br i1 %helper.ok.784, label %helper.continue.785, label %frame.failure.0
helper.continue.785:
  br label %local.descriptor.checked.766
local.descriptor.inactive.765:
  br label %local.descriptor.checked.766
local.descriptor.checked.766:
  %step.status.786 = call i32 @al_owning_charge_step(ptr %ctx, i32 12)
  %helper.ok.787 = icmp eq i32 %step.status.786, 0
  br i1 %helper.ok.787, label %helper.continue.788, label %frame.failure.0
helper.continue.788:
  %call.arguments.789 = alloca [2 x %AlOwningDescriptor], align 4
  %descriptor.element.790 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.789, i32 0
  %descriptor.field.791 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.790, i32 0, i32 0
  store i32 1, ptr %descriptor.field.791, align 4
  %descriptor.field.792 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.790, i32 0, i32 1
  store i32 %local.resolved.offset.263, ptr %descriptor.field.792, align 4
  %descriptor.field.793 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.790, i32 0, i32 2
  store i32 %local.resolved.extent.264, ptr %descriptor.field.793, align 4
  %descriptor.field.794 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.790, i32 0, i32 3
  store i32 %local.resolved.payload.265, ptr %descriptor.field.794, align 4
  %descriptor.field.795 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.790, i32 0, i32 4
  store i32 %local.resolved.owner.end.266, ptr %descriptor.field.795, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %local.resolved.offset.263, i32 20, i32 %local.resolved.payload.265, i32 %local.resolved.owner.end.266, i32 %local.resolved.extent.264)
  %context.field.796 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.797 = load i32, ptr %context.field.796, align 4
  %runtime.ok.798 = icmp eq i32 %context.value.797, 0
  br i1 %runtime.ok.798, label %runtime.continue.799, label %frame.failure.0
runtime.continue.799:
  %descriptor.element.800 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.789, i32 1
  %descriptor.field.801 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.800, i32 0, i32 0
  store i32 1, ptr %descriptor.field.801, align 4
  %descriptor.field.802 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.800, i32 0, i32 1
  store i32 %context.value.669, ptr %descriptor.field.802, align 4
  %descriptor.field.803 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.800, i32 0, i32 2
  store i32 8, ptr %descriptor.field.803, align 4
  %descriptor.field.804 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.800, i32 0, i32 3
  store i32 8, ptr %descriptor.field.804, align 4
  %descriptor.field.805 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.800, i32 0, i32 4
  store i32 %stack.offset.682, ptr %descriptor.field.805, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %context.value.669, i32 20, i32 8, i32 %stack.offset.682, i32 8)
  %context.field.806 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.807 = load i32, ptr %context.field.806, align 4
  %runtime.ok.808 = icmp eq i32 %context.value.807, 0
  br i1 %runtime.ok.808, label %runtime.continue.809, label %frame.failure.0
runtime.continue.809:
  %call.results.810 = alloca [1 x %AlOwningDescriptor], align 4
  %callee.status.811 = call i32 @agentlang_word_0001(ptr %ctx, ptr %call.arguments.789, ptr %call.results.810, i32 13)
  %helper.ok.812 = icmp eq i32 %callee.status.811, 0
  br i1 %helper.ok.812, label %helper.continue.813, label %frame.failure.0
helper.continue.813:
  %descriptor.element.814 = getelementptr inbounds %AlOwningDescriptor, ptr %call.results.810, i32 0
  %descriptor.field.815 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.814, i32 0, i32 0
  %descriptor.value.816 = load i32, ptr %descriptor.field.815, align 4
  %descriptor.field.817 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.814, i32 0, i32 1
  %descriptor.value.818 = load i32, ptr %descriptor.field.817, align 4
  %descriptor.field.819 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.814, i32 0, i32 2
  %descriptor.value.820 = load i32, ptr %descriptor.field.819, align 4
  %descriptor.field.821 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.814, i32 0, i32 3
  %descriptor.value.822 = load i32, ptr %descriptor.field.821, align 4
  %descriptor.field.823 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.814, i32 0, i32 4
  %descriptor.value.824 = load i32, ptr %descriptor.field.823, align 4
  %callee.result.type.valid.825 = icmp eq i32 %descriptor.value.816, 5
  br i1 %callee.result.type.valid.825, label %callee.result.type.ok.826, label %frame.failure.0
callee.result.type.ok.826:
  %context.field.827 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.828 = load i32, ptr %context.field.827, align 4
  %stack.sub.831 = sub i32 %descriptor.value.824, %descriptor.value.818
  %descriptor.owner.inside.829 = icmp ule i32 %descriptor.value.824, %context.value.828
  %descriptor.offset.inside.830 = icmp ule i32 %descriptor.value.818, %descriptor.value.824
  %descriptor.extent.inside.832 = icmp ule i32 %descriptor.value.820, %stack.sub.831
  %descriptor.payload.inside.833 = icmp ule i32 %descriptor.value.822, %descriptor.value.820
  %descriptor.owner.offset.valid.834 = and i1 %descriptor.owner.inside.829, %descriptor.offset.inside.830
  %descriptor.range.inside.836 = and i1 %descriptor.owner.offset.valid.834, %descriptor.extent.inside.832
  %descriptor.range.valid.835 = and i1 %descriptor.range.inside.836, %descriptor.payload.inside.833
  %descriptor.type.valid.837 = icmp eq i32 5, 5
  %descriptor.valid.838 = and i1 %descriptor.range.valid.835, %descriptor.type.valid.837
  br i1 %descriptor.valid.838, label %descriptor.valid.839, label %descriptor.invalid.840
descriptor.invalid.840:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.839:
  %descriptor.initialized.status.841 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.818, i32 %descriptor.value.820)
  %helper.ok.842 = icmp eq i32 %descriptor.initialized.status.841, 0
  br i1 %helper.ok.842, label %helper.continue.843, label %frame.failure.0
helper.continue.843:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.818, i32 20, i32 %descriptor.value.822, i32 %descriptor.value.824, i32 %descriptor.value.820)
  %context.field.844 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.845 = load i32, ptr %context.field.844, align 4
  %runtime.ok.846 = icmp eq i32 %context.value.845, 0
  br i1 %runtime.ok.846, label %runtime.continue.847, label %frame.failure.0
runtime.continue.847:
  %context.field.848 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.849 = load i32, ptr %context.field.848, align 4
  %stack.sub.852 = sub i32 %descriptor.value.824, %descriptor.value.818
  %descriptor.owner.inside.850 = icmp ule i32 %descriptor.value.824, %context.value.849
  %descriptor.offset.inside.851 = icmp ule i32 %descriptor.value.818, %descriptor.value.824
  %descriptor.extent.inside.853 = icmp ule i32 %descriptor.value.820, %stack.sub.852
  %descriptor.payload.inside.854 = icmp ule i32 %descriptor.value.822, %descriptor.value.820
  %descriptor.owner.offset.valid.855 = and i1 %descriptor.owner.inside.850, %descriptor.offset.inside.851
  %descriptor.range.inside.857 = and i1 %descriptor.owner.offset.valid.855, %descriptor.extent.inside.853
  %descriptor.range.valid.856 = and i1 %descriptor.range.inside.857, %descriptor.payload.inside.854
  %descriptor.type.valid.858 = icmp eq i32 5, 5
  %descriptor.valid.859 = and i1 %descriptor.range.valid.856, %descriptor.type.valid.858
  br i1 %descriptor.valid.859, label %descriptor.valid.860, label %descriptor.invalid.861
descriptor.invalid.861:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.860:
  %descriptor.initialized.status.862 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.818, i32 %descriptor.value.820)
  %helper.ok.863 = icmp eq i32 %descriptor.initialized.status.862, 0
  br i1 %helper.ok.863, label %helper.continue.864, label %frame.failure.0
helper.continue.864:
  %local.is.active.865 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.865, label %local.descriptor.active.866, label %local.descriptor.inactive.867
local.descriptor.active.866:
  %local.check.offset.869 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.870 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.871 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.872 = load i32, ptr %local.owner.end.6, align 4
  %context.field.873 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.874 = load i32, ptr %context.field.873, align 4
  %stack.sub.877 = sub i32 %local.check.owner.end.872, %local.check.offset.869
  %descriptor.owner.inside.875 = icmp ule i32 %local.check.owner.end.872, %context.value.874
  %descriptor.offset.inside.876 = icmp ule i32 %local.check.offset.869, %local.check.owner.end.872
  %descriptor.extent.inside.878 = icmp ule i32 %local.check.extent.870, %stack.sub.877
  %descriptor.payload.inside.879 = icmp ule i32 %local.check.payload.871, %local.check.extent.870
  %descriptor.owner.offset.valid.880 = and i1 %descriptor.owner.inside.875, %descriptor.offset.inside.876
  %descriptor.range.inside.882 = and i1 %descriptor.owner.offset.valid.880, %descriptor.extent.inside.878
  %descriptor.range.valid.881 = and i1 %descriptor.range.inside.882, %descriptor.payload.inside.879
  br i1 %descriptor.range.valid.881, label %descriptor.valid.883, label %descriptor.invalid.884
descriptor.invalid.884:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.883:
  %descriptor.initialized.status.885 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.869, i32 %local.check.extent.870)
  %helper.ok.886 = icmp eq i32 %descriptor.initialized.status.885, 0
  br i1 %helper.ok.886, label %helper.continue.887, label %frame.failure.0
helper.continue.887:
  br label %local.descriptor.checked.868
local.descriptor.inactive.867:
  br label %local.descriptor.checked.868
local.descriptor.checked.868:
  %local.is.active.888 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.888, label %local.descriptor.active.889, label %local.descriptor.inactive.890
local.descriptor.active.889:
  %local.check.offset.892 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.893 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.894 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.895 = load i32, ptr %local.owner.end.12, align 4
  %context.field.896 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.897 = load i32, ptr %context.field.896, align 4
  %stack.sub.900 = sub i32 %local.check.owner.end.895, %local.check.offset.892
  %descriptor.owner.inside.898 = icmp ule i32 %local.check.owner.end.895, %context.value.897
  %descriptor.offset.inside.899 = icmp ule i32 %local.check.offset.892, %local.check.owner.end.895
  %descriptor.extent.inside.901 = icmp ule i32 %local.check.extent.893, %stack.sub.900
  %descriptor.payload.inside.902 = icmp ule i32 %local.check.payload.894, %local.check.extent.893
  %descriptor.owner.offset.valid.903 = and i1 %descriptor.owner.inside.898, %descriptor.offset.inside.899
  %descriptor.range.inside.905 = and i1 %descriptor.owner.offset.valid.903, %descriptor.extent.inside.901
  %descriptor.range.valid.904 = and i1 %descriptor.range.inside.905, %descriptor.payload.inside.902
  br i1 %descriptor.range.valid.904, label %descriptor.valid.906, label %descriptor.invalid.907
descriptor.invalid.907:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.906:
  %descriptor.initialized.status.908 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.892, i32 %local.check.extent.893)
  %helper.ok.909 = icmp eq i32 %descriptor.initialized.status.908, 0
  br i1 %helper.ok.909, label %helper.continue.910, label %frame.failure.0
helper.continue.910:
  br label %local.descriptor.checked.891
local.descriptor.inactive.890:
  br label %local.descriptor.checked.891
local.descriptor.checked.891:
  %local.is.active.911 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.911, label %local.descriptor.active.912, label %local.descriptor.inactive.913
local.descriptor.active.912:
  %local.check.offset.915 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.916 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.917 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.918 = load i32, ptr %local.owner.end.18, align 4
  %context.field.919 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.920 = load i32, ptr %context.field.919, align 4
  %stack.sub.923 = sub i32 %local.check.owner.end.918, %local.check.offset.915
  %descriptor.owner.inside.921 = icmp ule i32 %local.check.owner.end.918, %context.value.920
  %descriptor.offset.inside.922 = icmp ule i32 %local.check.offset.915, %local.check.owner.end.918
  %descriptor.extent.inside.924 = icmp ule i32 %local.check.extent.916, %stack.sub.923
  %descriptor.payload.inside.925 = icmp ule i32 %local.check.payload.917, %local.check.extent.916
  %descriptor.owner.offset.valid.926 = and i1 %descriptor.owner.inside.921, %descriptor.offset.inside.922
  %descriptor.range.inside.928 = and i1 %descriptor.owner.offset.valid.926, %descriptor.extent.inside.924
  %descriptor.range.valid.927 = and i1 %descriptor.range.inside.928, %descriptor.payload.inside.925
  br i1 %descriptor.range.valid.927, label %descriptor.valid.929, label %descriptor.invalid.930
descriptor.invalid.930:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.929:
  %descriptor.initialized.status.931 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.915, i32 %local.check.extent.916)
  %helper.ok.932 = icmp eq i32 %descriptor.initialized.status.931, 0
  br i1 %helper.ok.932, label %helper.continue.933, label %frame.failure.0
helper.continue.933:
  br label %local.descriptor.checked.914
local.descriptor.inactive.913:
  br label %local.descriptor.checked.914
local.descriptor.checked.914:
  %step.status.934 = call i32 @al_owning_charge_step(ptr %ctx, i32 14)
  %helper.ok.935 = icmp eq i32 %step.status.934, 0
  br i1 %helper.ok.935, label %helper.continue.936, label %frame.failure.0
helper.continue.936:
  store i1 true, ptr %local.active.14, align 1
  store i32 %descriptor.value.818, ptr %local.offset.15, align 4
  store i32 %descriptor.value.820, ptr %local.extent.16, align 4
  store i32 %descriptor.value.822, ptr %local.payload.17, align 4
  store i32 %descriptor.value.824, ptr %local.owner.end.18, align 4
  store i32 5, ptr %local.type.19, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.818, i32 20, i32 %descriptor.value.822, i32 %descriptor.value.824, i32 %descriptor.value.820)
  %context.field.937 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.938 = load i32, ptr %context.field.937, align 4
  %runtime.ok.939 = icmp eq i32 %context.value.938, 0
  br i1 %runtime.ok.939, label %runtime.continue.940, label %frame.failure.0
runtime.continue.940:
  %local.is.active.941 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.941, label %local.descriptor.active.942, label %local.descriptor.inactive.943
local.descriptor.active.942:
  %local.check.offset.945 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.946 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.947 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.948 = load i32, ptr %local.owner.end.6, align 4
  %context.field.949 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.950 = load i32, ptr %context.field.949, align 4
  %stack.sub.953 = sub i32 %local.check.owner.end.948, %local.check.offset.945
  %descriptor.owner.inside.951 = icmp ule i32 %local.check.owner.end.948, %context.value.950
  %descriptor.offset.inside.952 = icmp ule i32 %local.check.offset.945, %local.check.owner.end.948
  %descriptor.extent.inside.954 = icmp ule i32 %local.check.extent.946, %stack.sub.953
  %descriptor.payload.inside.955 = icmp ule i32 %local.check.payload.947, %local.check.extent.946
  %descriptor.owner.offset.valid.956 = and i1 %descriptor.owner.inside.951, %descriptor.offset.inside.952
  %descriptor.range.inside.958 = and i1 %descriptor.owner.offset.valid.956, %descriptor.extent.inside.954
  %descriptor.range.valid.957 = and i1 %descriptor.range.inside.958, %descriptor.payload.inside.955
  br i1 %descriptor.range.valid.957, label %descriptor.valid.959, label %descriptor.invalid.960
descriptor.invalid.960:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.959:
  %descriptor.initialized.status.961 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.945, i32 %local.check.extent.946)
  %helper.ok.962 = icmp eq i32 %descriptor.initialized.status.961, 0
  br i1 %helper.ok.962, label %helper.continue.963, label %frame.failure.0
helper.continue.963:
  br label %local.descriptor.checked.944
local.descriptor.inactive.943:
  br label %local.descriptor.checked.944
local.descriptor.checked.944:
  %local.is.active.964 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.964, label %local.descriptor.active.965, label %local.descriptor.inactive.966
local.descriptor.active.965:
  %local.check.offset.968 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.969 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.970 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.971 = load i32, ptr %local.owner.end.12, align 4
  %context.field.972 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.973 = load i32, ptr %context.field.972, align 4
  %stack.sub.976 = sub i32 %local.check.owner.end.971, %local.check.offset.968
  %descriptor.owner.inside.974 = icmp ule i32 %local.check.owner.end.971, %context.value.973
  %descriptor.offset.inside.975 = icmp ule i32 %local.check.offset.968, %local.check.owner.end.971
  %descriptor.extent.inside.977 = icmp ule i32 %local.check.extent.969, %stack.sub.976
  %descriptor.payload.inside.978 = icmp ule i32 %local.check.payload.970, %local.check.extent.969
  %descriptor.owner.offset.valid.979 = and i1 %descriptor.owner.inside.974, %descriptor.offset.inside.975
  %descriptor.range.inside.981 = and i1 %descriptor.owner.offset.valid.979, %descriptor.extent.inside.977
  %descriptor.range.valid.980 = and i1 %descriptor.range.inside.981, %descriptor.payload.inside.978
  br i1 %descriptor.range.valid.980, label %descriptor.valid.982, label %descriptor.invalid.983
descriptor.invalid.983:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.982:
  %descriptor.initialized.status.984 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.968, i32 %local.check.extent.969)
  %helper.ok.985 = icmp eq i32 %descriptor.initialized.status.984, 0
  br i1 %helper.ok.985, label %helper.continue.986, label %frame.failure.0
helper.continue.986:
  br label %local.descriptor.checked.967
local.descriptor.inactive.966:
  br label %local.descriptor.checked.967
local.descriptor.checked.967:
  %local.is.active.987 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.987, label %local.descriptor.active.988, label %local.descriptor.inactive.989
local.descriptor.active.988:
  %local.check.offset.991 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.992 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.993 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.994 = load i32, ptr %local.owner.end.18, align 4
  %context.field.995 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.996 = load i32, ptr %context.field.995, align 4
  %stack.sub.999 = sub i32 %local.check.owner.end.994, %local.check.offset.991
  %descriptor.owner.inside.997 = icmp ule i32 %local.check.owner.end.994, %context.value.996
  %descriptor.offset.inside.998 = icmp ule i32 %local.check.offset.991, %local.check.owner.end.994
  %descriptor.extent.inside.1000 = icmp ule i32 %local.check.extent.992, %stack.sub.999
  %descriptor.payload.inside.1001 = icmp ule i32 %local.check.payload.993, %local.check.extent.992
  %descriptor.owner.offset.valid.1002 = and i1 %descriptor.owner.inside.997, %descriptor.offset.inside.998
  %descriptor.range.inside.1004 = and i1 %descriptor.owner.offset.valid.1002, %descriptor.extent.inside.1000
  %descriptor.range.valid.1003 = and i1 %descriptor.range.inside.1004, %descriptor.payload.inside.1001
  br i1 %descriptor.range.valid.1003, label %descriptor.valid.1005, label %descriptor.invalid.1006
descriptor.invalid.1006:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1005:
  %descriptor.initialized.status.1007 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.991, i32 %local.check.extent.992)
  %helper.ok.1008 = icmp eq i32 %descriptor.initialized.status.1007, 0
  br i1 %helper.ok.1008, label %helper.continue.1009, label %frame.failure.0
helper.continue.1009:
  br label %local.descriptor.checked.990
local.descriptor.inactive.989:
  br label %local.descriptor.checked.990
local.descriptor.checked.990:
  %step.status.1010 = call i32 @al_owning_charge_step(ptr %ctx, i32 15)
  %helper.ok.1011 = icmp eq i32 %step.status.1010, 0
  br i1 %helper.ok.1011, label %helper.continue.1012, label %frame.failure.0
helper.continue.1012:
  %context.field.1013 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1014 = load i32, ptr %context.field.1013, align 4
  %stack.offset.1015 = add i32 %context.value.1014, 8
  %reserve.status.1016 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1015, i32 16)
  %reserve.ok.1017 = icmp eq i32 %reserve.status.1016, 0
  br i1 %reserve.ok.1017, label %reserve.continue.1018, label %frame.failure.0
reserve.continue.1018:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.1014, i64 1, i32 1)
  %context.field.1019 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1020 = load i32, ptr %context.field.1019, align 4
  %runtime.ok.1021 = icmp eq i32 %context.value.1020, 0
  br i1 %runtime.ok.1021, label %runtime.continue.1022, label %frame.failure.0
runtime.continue.1022:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.1023 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1024 = load i32, ptr %context.field.1023, align 4
  %runtime.ok.1025 = icmp eq i32 %context.value.1024, 0
  br i1 %runtime.ok.1025, label %runtime.continue.1026, label %frame.failure.0
runtime.continue.1026:
  %context.field.1027 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1028 = load i32, ptr %context.field.1027, align 4
  %stack.sub.1031 = sub i32 %stack.offset.1015, %context.value.1014
  %descriptor.owner.inside.1029 = icmp ule i32 %stack.offset.1015, %context.value.1028
  %descriptor.offset.inside.1030 = icmp ule i32 %context.value.1014, %stack.offset.1015
  %descriptor.extent.inside.1032 = icmp ule i32 8, %stack.sub.1031
  %descriptor.payload.inside.1033 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.1034 = and i1 %descriptor.owner.inside.1029, %descriptor.offset.inside.1030
  %descriptor.range.inside.1036 = and i1 %descriptor.owner.offset.valid.1034, %descriptor.extent.inside.1032
  %descriptor.range.valid.1035 = and i1 %descriptor.range.inside.1036, %descriptor.payload.inside.1033
  %descriptor.type.valid.1037 = icmp eq i32 1, 1
  %descriptor.valid.1038 = and i1 %descriptor.range.valid.1035, %descriptor.type.valid.1037
  br i1 %descriptor.valid.1038, label %descriptor.valid.1039, label %descriptor.invalid.1040
descriptor.invalid.1040:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1039:
  %descriptor.initialized.status.1041 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.1014, i32 8)
  %helper.ok.1042 = icmp eq i32 %descriptor.initialized.status.1041, 0
  br i1 %helper.ok.1042, label %helper.continue.1043, label %frame.failure.0
helper.continue.1043:
  %local.is.active.1044 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1044, label %local.descriptor.active.1045, label %local.descriptor.inactive.1046
local.descriptor.active.1045:
  %local.check.offset.1048 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1049 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1050 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1051 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1052 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1053 = load i32, ptr %context.field.1052, align 4
  %stack.sub.1056 = sub i32 %local.check.owner.end.1051, %local.check.offset.1048
  %descriptor.owner.inside.1054 = icmp ule i32 %local.check.owner.end.1051, %context.value.1053
  %descriptor.offset.inside.1055 = icmp ule i32 %local.check.offset.1048, %local.check.owner.end.1051
  %descriptor.extent.inside.1057 = icmp ule i32 %local.check.extent.1049, %stack.sub.1056
  %descriptor.payload.inside.1058 = icmp ule i32 %local.check.payload.1050, %local.check.extent.1049
  %descriptor.owner.offset.valid.1059 = and i1 %descriptor.owner.inside.1054, %descriptor.offset.inside.1055
  %descriptor.range.inside.1061 = and i1 %descriptor.owner.offset.valid.1059, %descriptor.extent.inside.1057
  %descriptor.range.valid.1060 = and i1 %descriptor.range.inside.1061, %descriptor.payload.inside.1058
  br i1 %descriptor.range.valid.1060, label %descriptor.valid.1062, label %descriptor.invalid.1063
descriptor.invalid.1063:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1062:
  %descriptor.initialized.status.1064 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1048, i32 %local.check.extent.1049)
  %helper.ok.1065 = icmp eq i32 %descriptor.initialized.status.1064, 0
  br i1 %helper.ok.1065, label %helper.continue.1066, label %frame.failure.0
helper.continue.1066:
  br label %local.descriptor.checked.1047
local.descriptor.inactive.1046:
  br label %local.descriptor.checked.1047
local.descriptor.checked.1047:
  %local.is.active.1067 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1067, label %local.descriptor.active.1068, label %local.descriptor.inactive.1069
local.descriptor.active.1068:
  %local.check.offset.1071 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1072 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1073 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1074 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1075 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1076 = load i32, ptr %context.field.1075, align 4
  %stack.sub.1079 = sub i32 %local.check.owner.end.1074, %local.check.offset.1071
  %descriptor.owner.inside.1077 = icmp ule i32 %local.check.owner.end.1074, %context.value.1076
  %descriptor.offset.inside.1078 = icmp ule i32 %local.check.offset.1071, %local.check.owner.end.1074
  %descriptor.extent.inside.1080 = icmp ule i32 %local.check.extent.1072, %stack.sub.1079
  %descriptor.payload.inside.1081 = icmp ule i32 %local.check.payload.1073, %local.check.extent.1072
  %descriptor.owner.offset.valid.1082 = and i1 %descriptor.owner.inside.1077, %descriptor.offset.inside.1078
  %descriptor.range.inside.1084 = and i1 %descriptor.owner.offset.valid.1082, %descriptor.extent.inside.1080
  %descriptor.range.valid.1083 = and i1 %descriptor.range.inside.1084, %descriptor.payload.inside.1081
  br i1 %descriptor.range.valid.1083, label %descriptor.valid.1085, label %descriptor.invalid.1086
descriptor.invalid.1086:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1085:
  %descriptor.initialized.status.1087 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1071, i32 %local.check.extent.1072)
  %helper.ok.1088 = icmp eq i32 %descriptor.initialized.status.1087, 0
  br i1 %helper.ok.1088, label %helper.continue.1089, label %frame.failure.0
helper.continue.1089:
  br label %local.descriptor.checked.1070
local.descriptor.inactive.1069:
  br label %local.descriptor.checked.1070
local.descriptor.checked.1070:
  %local.is.active.1090 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1090, label %local.descriptor.active.1091, label %local.descriptor.inactive.1092
local.descriptor.active.1091:
  %local.check.offset.1094 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1095 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1096 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1097 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1098 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1099 = load i32, ptr %context.field.1098, align 4
  %stack.sub.1102 = sub i32 %local.check.owner.end.1097, %local.check.offset.1094
  %descriptor.owner.inside.1100 = icmp ule i32 %local.check.owner.end.1097, %context.value.1099
  %descriptor.offset.inside.1101 = icmp ule i32 %local.check.offset.1094, %local.check.owner.end.1097
  %descriptor.extent.inside.1103 = icmp ule i32 %local.check.extent.1095, %stack.sub.1102
  %descriptor.payload.inside.1104 = icmp ule i32 %local.check.payload.1096, %local.check.extent.1095
  %descriptor.owner.offset.valid.1105 = and i1 %descriptor.owner.inside.1100, %descriptor.offset.inside.1101
  %descriptor.range.inside.1107 = and i1 %descriptor.owner.offset.valid.1105, %descriptor.extent.inside.1103
  %descriptor.range.valid.1106 = and i1 %descriptor.range.inside.1107, %descriptor.payload.inside.1104
  br i1 %descriptor.range.valid.1106, label %descriptor.valid.1108, label %descriptor.invalid.1109
descriptor.invalid.1109:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1108:
  %descriptor.initialized.status.1110 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1094, i32 %local.check.extent.1095)
  %helper.ok.1111 = icmp eq i32 %descriptor.initialized.status.1110, 0
  br i1 %helper.ok.1111, label %helper.continue.1112, label %frame.failure.0
helper.continue.1112:
  br label %local.descriptor.checked.1093
local.descriptor.inactive.1092:
  br label %local.descriptor.checked.1093
local.descriptor.checked.1093:
  %step.status.1113 = call i32 @al_owning_charge_step(ptr %ctx, i32 17)
  %helper.ok.1114 = icmp eq i32 %step.status.1113, 0
  br i1 %helper.ok.1114, label %helper.continue.1115, label %frame.failure.0
helper.continue.1115:
  %context.field.1116 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1117 = load i32, ptr %context.field.1116, align 4
  %stack.offset.1118 = add i32 %context.value.1117, 8
  %reserve.status.1119 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1118, i32 18)
  %reserve.ok.1120 = icmp eq i32 %reserve.status.1119, 0
  br i1 %reserve.ok.1120, label %reserve.continue.1121, label %frame.failure.0
reserve.continue.1121:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.1117, i64 0, i32 1)
  %context.field.1122 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1123 = load i32, ptr %context.field.1122, align 4
  %runtime.ok.1124 = icmp eq i32 %context.value.1123, 0
  br i1 %runtime.ok.1124, label %runtime.continue.1125, label %frame.failure.0
runtime.continue.1125:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.1126 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1127 = load i32, ptr %context.field.1126, align 4
  %runtime.ok.1128 = icmp eq i32 %context.value.1127, 0
  br i1 %runtime.ok.1128, label %runtime.continue.1129, label %frame.failure.0
runtime.continue.1129:
  %context.field.1130 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1131 = load i32, ptr %context.field.1130, align 4
  %stack.sub.1134 = sub i32 %stack.offset.1015, %context.value.1014
  %descriptor.owner.inside.1132 = icmp ule i32 %stack.offset.1015, %context.value.1131
  %descriptor.offset.inside.1133 = icmp ule i32 %context.value.1014, %stack.offset.1015
  %descriptor.extent.inside.1135 = icmp ule i32 8, %stack.sub.1134
  %descriptor.payload.inside.1136 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.1137 = and i1 %descriptor.owner.inside.1132, %descriptor.offset.inside.1133
  %descriptor.range.inside.1139 = and i1 %descriptor.owner.offset.valid.1137, %descriptor.extent.inside.1135
  %descriptor.range.valid.1138 = and i1 %descriptor.range.inside.1139, %descriptor.payload.inside.1136
  %descriptor.type.valid.1140 = icmp eq i32 1, 1
  %descriptor.valid.1141 = and i1 %descriptor.range.valid.1138, %descriptor.type.valid.1140
  br i1 %descriptor.valid.1141, label %descriptor.valid.1142, label %descriptor.invalid.1143
descriptor.invalid.1143:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1142:
  %descriptor.initialized.status.1144 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.1014, i32 8)
  %helper.ok.1145 = icmp eq i32 %descriptor.initialized.status.1144, 0
  br i1 %helper.ok.1145, label %helper.continue.1146, label %frame.failure.0
helper.continue.1146:
  %context.field.1147 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1148 = load i32, ptr %context.field.1147, align 4
  %stack.sub.1151 = sub i32 %stack.offset.1118, %context.value.1117
  %descriptor.owner.inside.1149 = icmp ule i32 %stack.offset.1118, %context.value.1148
  %descriptor.offset.inside.1150 = icmp ule i32 %context.value.1117, %stack.offset.1118
  %descriptor.extent.inside.1152 = icmp ule i32 8, %stack.sub.1151
  %descriptor.payload.inside.1153 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.1154 = and i1 %descriptor.owner.inside.1149, %descriptor.offset.inside.1150
  %descriptor.range.inside.1156 = and i1 %descriptor.owner.offset.valid.1154, %descriptor.extent.inside.1152
  %descriptor.range.valid.1155 = and i1 %descriptor.range.inside.1156, %descriptor.payload.inside.1153
  %descriptor.type.valid.1157 = icmp eq i32 1, 1
  %descriptor.valid.1158 = and i1 %descriptor.range.valid.1155, %descriptor.type.valid.1157
  br i1 %descriptor.valid.1158, label %descriptor.valid.1159, label %descriptor.invalid.1160
descriptor.invalid.1160:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1159:
  %descriptor.initialized.status.1161 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.1117, i32 8)
  %helper.ok.1162 = icmp eq i32 %descriptor.initialized.status.1161, 0
  br i1 %helper.ok.1162, label %helper.continue.1163, label %frame.failure.0
helper.continue.1163:
  %local.is.active.1164 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1164, label %local.descriptor.active.1165, label %local.descriptor.inactive.1166
local.descriptor.active.1165:
  %local.check.offset.1168 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1169 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1170 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1171 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1172 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1173 = load i32, ptr %context.field.1172, align 4
  %stack.sub.1176 = sub i32 %local.check.owner.end.1171, %local.check.offset.1168
  %descriptor.owner.inside.1174 = icmp ule i32 %local.check.owner.end.1171, %context.value.1173
  %descriptor.offset.inside.1175 = icmp ule i32 %local.check.offset.1168, %local.check.owner.end.1171
  %descriptor.extent.inside.1177 = icmp ule i32 %local.check.extent.1169, %stack.sub.1176
  %descriptor.payload.inside.1178 = icmp ule i32 %local.check.payload.1170, %local.check.extent.1169
  %descriptor.owner.offset.valid.1179 = and i1 %descriptor.owner.inside.1174, %descriptor.offset.inside.1175
  %descriptor.range.inside.1181 = and i1 %descriptor.owner.offset.valid.1179, %descriptor.extent.inside.1177
  %descriptor.range.valid.1180 = and i1 %descriptor.range.inside.1181, %descriptor.payload.inside.1178
  br i1 %descriptor.range.valid.1180, label %descriptor.valid.1182, label %descriptor.invalid.1183
descriptor.invalid.1183:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1182:
  %descriptor.initialized.status.1184 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1168, i32 %local.check.extent.1169)
  %helper.ok.1185 = icmp eq i32 %descriptor.initialized.status.1184, 0
  br i1 %helper.ok.1185, label %helper.continue.1186, label %frame.failure.0
helper.continue.1186:
  br label %local.descriptor.checked.1167
local.descriptor.inactive.1166:
  br label %local.descriptor.checked.1167
local.descriptor.checked.1167:
  %local.is.active.1187 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1187, label %local.descriptor.active.1188, label %local.descriptor.inactive.1189
local.descriptor.active.1188:
  %local.check.offset.1191 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1192 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1193 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1194 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1195 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1196 = load i32, ptr %context.field.1195, align 4
  %stack.sub.1199 = sub i32 %local.check.owner.end.1194, %local.check.offset.1191
  %descriptor.owner.inside.1197 = icmp ule i32 %local.check.owner.end.1194, %context.value.1196
  %descriptor.offset.inside.1198 = icmp ule i32 %local.check.offset.1191, %local.check.owner.end.1194
  %descriptor.extent.inside.1200 = icmp ule i32 %local.check.extent.1192, %stack.sub.1199
  %descriptor.payload.inside.1201 = icmp ule i32 %local.check.payload.1193, %local.check.extent.1192
  %descriptor.owner.offset.valid.1202 = and i1 %descriptor.owner.inside.1197, %descriptor.offset.inside.1198
  %descriptor.range.inside.1204 = and i1 %descriptor.owner.offset.valid.1202, %descriptor.extent.inside.1200
  %descriptor.range.valid.1203 = and i1 %descriptor.range.inside.1204, %descriptor.payload.inside.1201
  br i1 %descriptor.range.valid.1203, label %descriptor.valid.1205, label %descriptor.invalid.1206
descriptor.invalid.1206:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1205:
  %descriptor.initialized.status.1207 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1191, i32 %local.check.extent.1192)
  %helper.ok.1208 = icmp eq i32 %descriptor.initialized.status.1207, 0
  br i1 %helper.ok.1208, label %helper.continue.1209, label %frame.failure.0
helper.continue.1209:
  br label %local.descriptor.checked.1190
local.descriptor.inactive.1189:
  br label %local.descriptor.checked.1190
local.descriptor.checked.1190:
  %local.is.active.1210 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1210, label %local.descriptor.active.1211, label %local.descriptor.inactive.1212
local.descriptor.active.1211:
  %local.check.offset.1214 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1215 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1216 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1217 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1218 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1219 = load i32, ptr %context.field.1218, align 4
  %stack.sub.1222 = sub i32 %local.check.owner.end.1217, %local.check.offset.1214
  %descriptor.owner.inside.1220 = icmp ule i32 %local.check.owner.end.1217, %context.value.1219
  %descriptor.offset.inside.1221 = icmp ule i32 %local.check.offset.1214, %local.check.owner.end.1217
  %descriptor.extent.inside.1223 = icmp ule i32 %local.check.extent.1215, %stack.sub.1222
  %descriptor.payload.inside.1224 = icmp ule i32 %local.check.payload.1216, %local.check.extent.1215
  %descriptor.owner.offset.valid.1225 = and i1 %descriptor.owner.inside.1220, %descriptor.offset.inside.1221
  %descriptor.range.inside.1227 = and i1 %descriptor.owner.offset.valid.1225, %descriptor.extent.inside.1223
  %descriptor.range.valid.1226 = and i1 %descriptor.range.inside.1227, %descriptor.payload.inside.1224
  br i1 %descriptor.range.valid.1226, label %descriptor.valid.1228, label %descriptor.invalid.1229
descriptor.invalid.1229:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1228:
  %descriptor.initialized.status.1230 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1214, i32 %local.check.extent.1215)
  %helper.ok.1231 = icmp eq i32 %descriptor.initialized.status.1230, 0
  br i1 %helper.ok.1231, label %helper.continue.1232, label %frame.failure.0
helper.continue.1232:
  br label %local.descriptor.checked.1213
local.descriptor.inactive.1212:
  br label %local.descriptor.checked.1213
local.descriptor.checked.1213:
  %step.status.1233 = call i32 @al_owning_charge_step(ptr %ctx, i32 19)
  %helper.ok.1234 = icmp eq i32 %step.status.1233, 0
  br i1 %helper.ok.1234, label %helper.continue.1235, label %frame.failure.0
helper.continue.1235:
  %integer.left.1236 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.1014)
  %context.field.1238 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1239 = load i32, ptr %context.field.1238, align 4
  %runtime.ok.1240 = icmp eq i32 %context.value.1239, 0
  br i1 %runtime.ok.1240, label %runtime.continue.1241, label %frame.failure.0
runtime.continue.1241:
  %integer.right.1237 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.1117)
  %context.field.1242 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1243 = load i32, ptr %context.field.1242, align 4
  %runtime.ok.1244 = icmp eq i32 %context.value.1243, 0
  br i1 %runtime.ok.1244, label %runtime.continue.1245, label %frame.failure.0
runtime.continue.1245:
  %divide.zero.1246 = icmp eq i64 %integer.right.1237, 0
  br i1 %divide.zero.1246, label %divide.zero.1247, label %divide.nonzero.1248
divide.zero.1247:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 20, i32 0, i32 0)
  br label %frame.failure.0
divide.nonzero.1248:
  %divide.min.1249 = icmp eq i64 %integer.left.1236, -9223372036854775808
  %divide.minusone.1250 = icmp eq i64 %integer.right.1237, -1
  %divide.overflow.1251 = and i1 %divide.min.1249, %divide.minusone.1250
  br i1 %divide.overflow.1251, label %divide.overflow.1252, label %divide.valid.1253
divide.overflow.1252:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 21, i32 0, i32 0)
  br label %frame.failure.0
divide.valid.1253:
  %divide.result.1254 = sdiv i64 %integer.left.1236, %integer.right.1237
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.1117, i32 8, i32 8, i32 0, i32 0)
  %context.field.1255 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1256 = load i32, ptr %context.field.1255, align 4
  %runtime.ok.1257 = icmp eq i32 %context.value.1256, 0
  br i1 %runtime.ok.1257, label %runtime.continue.1258, label %frame.failure.0
runtime.continue.1258:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 1, i32 %context.value.1014, i32 8, i32 8, i32 0, i32 0)
  %context.field.1259 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1260 = load i32, ptr %context.field.1259, align 4
  %runtime.ok.1261 = icmp eq i32 %context.value.1260, 0
  br i1 %runtime.ok.1261, label %runtime.continue.1262, label %frame.failure.0
runtime.continue.1262:
  %context.field.1263 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1264 = load i32, ptr %context.field.1263, align 4
  %stack.offset.1265 = add i32 %context.value.1264, 8
  %reserve.status.1266 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1265, i32 22)
  %reserve.ok.1267 = icmp eq i32 %reserve.status.1266, 0
  br i1 %reserve.ok.1267, label %reserve.continue.1268, label %frame.failure.0
reserve.continue.1268:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.1264, i64 %divide.result.1254, i32 1)
  %context.field.1269 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1270 = load i32, ptr %context.field.1269, align 4
  %runtime.ok.1271 = icmp eq i32 %context.value.1270, 0
  br i1 %runtime.ok.1271, label %runtime.continue.1272, label %frame.failure.0
runtime.continue.1272:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.1273 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1274 = load i32, ptr %context.field.1273, align 4
  %runtime.ok.1275 = icmp eq i32 %context.value.1274, 0
  br i1 %runtime.ok.1275, label %runtime.continue.1276, label %frame.failure.0
runtime.continue.1276:
  %stack.offset.1277 = add i32 %context.value.1264, 8
  %context.field.1278 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1279 = load i32, ptr %context.field.1278, align 4
  %stack.sub.1282 = sub i32 %stack.offset.1277, %context.value.1264
  %descriptor.owner.inside.1280 = icmp ule i32 %stack.offset.1277, %context.value.1279
  %descriptor.offset.inside.1281 = icmp ule i32 %context.value.1264, %stack.offset.1277
  %descriptor.extent.inside.1283 = icmp ule i32 8, %stack.sub.1282
  %descriptor.payload.inside.1284 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.1285 = and i1 %descriptor.owner.inside.1280, %descriptor.offset.inside.1281
  %descriptor.range.inside.1287 = and i1 %descriptor.owner.offset.valid.1285, %descriptor.extent.inside.1283
  %descriptor.range.valid.1286 = and i1 %descriptor.range.inside.1287, %descriptor.payload.inside.1284
  %descriptor.type.valid.1288 = icmp eq i32 1, 1
  %descriptor.valid.1289 = and i1 %descriptor.range.valid.1286, %descriptor.type.valid.1288
  br i1 %descriptor.valid.1289, label %descriptor.valid.1290, label %descriptor.invalid.1291
descriptor.invalid.1291:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1290:
  %descriptor.initialized.status.1292 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.1264, i32 8)
  %helper.ok.1293 = icmp eq i32 %descriptor.initialized.status.1292, 0
  br i1 %helper.ok.1293, label %helper.continue.1294, label %frame.failure.0
helper.continue.1294:
  %local.is.active.1295 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1295, label %local.descriptor.active.1296, label %local.descriptor.inactive.1297
local.descriptor.active.1296:
  %local.check.offset.1299 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1300 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1301 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1302 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1303 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1304 = load i32, ptr %context.field.1303, align 4
  %stack.sub.1307 = sub i32 %local.check.owner.end.1302, %local.check.offset.1299
  %descriptor.owner.inside.1305 = icmp ule i32 %local.check.owner.end.1302, %context.value.1304
  %descriptor.offset.inside.1306 = icmp ule i32 %local.check.offset.1299, %local.check.owner.end.1302
  %descriptor.extent.inside.1308 = icmp ule i32 %local.check.extent.1300, %stack.sub.1307
  %descriptor.payload.inside.1309 = icmp ule i32 %local.check.payload.1301, %local.check.extent.1300
  %descriptor.owner.offset.valid.1310 = and i1 %descriptor.owner.inside.1305, %descriptor.offset.inside.1306
  %descriptor.range.inside.1312 = and i1 %descriptor.owner.offset.valid.1310, %descriptor.extent.inside.1308
  %descriptor.range.valid.1311 = and i1 %descriptor.range.inside.1312, %descriptor.payload.inside.1309
  br i1 %descriptor.range.valid.1311, label %descriptor.valid.1313, label %descriptor.invalid.1314
descriptor.invalid.1314:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1313:
  %descriptor.initialized.status.1315 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1299, i32 %local.check.extent.1300)
  %helper.ok.1316 = icmp eq i32 %descriptor.initialized.status.1315, 0
  br i1 %helper.ok.1316, label %helper.continue.1317, label %frame.failure.0
helper.continue.1317:
  br label %local.descriptor.checked.1298
local.descriptor.inactive.1297:
  br label %local.descriptor.checked.1298
local.descriptor.checked.1298:
  %local.is.active.1318 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1318, label %local.descriptor.active.1319, label %local.descriptor.inactive.1320
local.descriptor.active.1319:
  %local.check.offset.1322 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1323 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1324 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1325 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1326 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1327 = load i32, ptr %context.field.1326, align 4
  %stack.sub.1330 = sub i32 %local.check.owner.end.1325, %local.check.offset.1322
  %descriptor.owner.inside.1328 = icmp ule i32 %local.check.owner.end.1325, %context.value.1327
  %descriptor.offset.inside.1329 = icmp ule i32 %local.check.offset.1322, %local.check.owner.end.1325
  %descriptor.extent.inside.1331 = icmp ule i32 %local.check.extent.1323, %stack.sub.1330
  %descriptor.payload.inside.1332 = icmp ule i32 %local.check.payload.1324, %local.check.extent.1323
  %descriptor.owner.offset.valid.1333 = and i1 %descriptor.owner.inside.1328, %descriptor.offset.inside.1329
  %descriptor.range.inside.1335 = and i1 %descriptor.owner.offset.valid.1333, %descriptor.extent.inside.1331
  %descriptor.range.valid.1334 = and i1 %descriptor.range.inside.1335, %descriptor.payload.inside.1332
  br i1 %descriptor.range.valid.1334, label %descriptor.valid.1336, label %descriptor.invalid.1337
descriptor.invalid.1337:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1336:
  %descriptor.initialized.status.1338 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1322, i32 %local.check.extent.1323)
  %helper.ok.1339 = icmp eq i32 %descriptor.initialized.status.1338, 0
  br i1 %helper.ok.1339, label %helper.continue.1340, label %frame.failure.0
helper.continue.1340:
  br label %local.descriptor.checked.1321
local.descriptor.inactive.1320:
  br label %local.descriptor.checked.1321
local.descriptor.checked.1321:
  %local.is.active.1341 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1341, label %local.descriptor.active.1342, label %local.descriptor.inactive.1343
local.descriptor.active.1342:
  %local.check.offset.1345 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1346 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1347 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1348 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1349 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1350 = load i32, ptr %context.field.1349, align 4
  %stack.sub.1353 = sub i32 %local.check.owner.end.1348, %local.check.offset.1345
  %descriptor.owner.inside.1351 = icmp ule i32 %local.check.owner.end.1348, %context.value.1350
  %descriptor.offset.inside.1352 = icmp ule i32 %local.check.offset.1345, %local.check.owner.end.1348
  %descriptor.extent.inside.1354 = icmp ule i32 %local.check.extent.1346, %stack.sub.1353
  %descriptor.payload.inside.1355 = icmp ule i32 %local.check.payload.1347, %local.check.extent.1346
  %descriptor.owner.offset.valid.1356 = and i1 %descriptor.owner.inside.1351, %descriptor.offset.inside.1352
  %descriptor.range.inside.1358 = and i1 %descriptor.owner.offset.valid.1356, %descriptor.extent.inside.1354
  %descriptor.range.valid.1357 = and i1 %descriptor.range.inside.1358, %descriptor.payload.inside.1355
  br i1 %descriptor.range.valid.1357, label %descriptor.valid.1359, label %descriptor.invalid.1360
descriptor.invalid.1360:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1359:
  %descriptor.initialized.status.1361 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1345, i32 %local.check.extent.1346)
  %helper.ok.1362 = icmp eq i32 %descriptor.initialized.status.1361, 0
  br i1 %helper.ok.1362, label %helper.continue.1363, label %frame.failure.0
helper.continue.1363:
  br label %local.descriptor.checked.1344
local.descriptor.inactive.1343:
  br label %local.descriptor.checked.1344
local.descriptor.checked.1344:
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %descriptor.element.1364 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.1365 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1364, i32 0, i32 0
  store i32 1, ptr %descriptor.field.1365, align 4
  %descriptor.field.1366 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1364, i32 0, i32 1
  store i32 %context.value.1264, ptr %descriptor.field.1366, align 4
  %descriptor.field.1367 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1364, i32 0, i32 2
  store i32 8, ptr %descriptor.field.1367, align 4
  %descriptor.field.1368 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1364, i32 0, i32 3
  store i32 8, ptr %descriptor.field.1368, align 4
  %descriptor.field.1369 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1364, i32 0, i32 4
  store i32 %stack.offset.1277, ptr %descriptor.field.1369, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %context.value.1264, i32 20, i32 8, i32 %stack.offset.1277, i32 8)
  %context.field.1370 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1371 = load i32, ptr %context.field.1370, align 4
  %runtime.ok.1372 = icmp eq i32 %context.value.1371, 0
  br i1 %runtime.ok.1372, label %runtime.continue.1373, label %frame.failure.0
runtime.continue.1373:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.21, i32 0, i32 0, i32 0)
  %context.field.1374 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.1375 = load i32, ptr %context.field.1374, align 4
  %context.field.1376 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.1377 = load i32, ptr %context.field.1376, align 4
  %context.field.1378 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.1379 = load i32, ptr %context.field.1378, align 4
  %stack.offset.1380 = add i32 %context.value.23, %context.value.25
  %stack.offset.1381 = add i32 %context.value.1375, %context.value.1377
  %stack.sub.1382 = sub i32 %stack.offset.1380, %stack.offset.1381
  %stack.sub.1383 = sub i32 %context.value.25, %context.value.1377
  %stack.sub.1384 = sub i32 %context.value.1379, %context.value.27
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1382, i32 %stack.sub.1383)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.1384)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0001(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %local.active.2 = alloca i1, align 1
  %local.offset.3 = alloca i32, align 4
  %local.extent.4 = alloca i32, align 4
  %local.payload.5 = alloca i32, align 4
  %local.owner.end.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %local.active.8 = alloca i1, align 1
  %local.offset.9 = alloca i32, align 4
  %local.extent.10 = alloca i32, align 4
  %local.payload.11 = alloca i32, align 4
  %local.owner.end.12 = alloca i32, align 4
  %local.type.13 = alloca i32, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  %local.active.14 = alloca i1, align 1
  %local.offset.15 = alloca i32, align 4
  %local.extent.16 = alloca i32, align 4
  %local.payload.17 = alloca i32, align 4
  %local.owner.end.18 = alloca i32, align 4
  %local.type.19 = alloca i32, align 4
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  %local.active.20 = alloca i1, align 1
  %local.offset.21 = alloca i32, align 4
  %local.extent.22 = alloca i32, align 4
  %local.payload.23 = alloca i32, align 4
  %local.owner.end.24 = alloca i32, align 4
  %local.type.25 = alloca i32, align 4
  store i1 false, ptr %local.active.20, align 1
  store i32 0, ptr %local.offset.21, align 4
  store i32 0, ptr %local.extent.22, align 4
  store i32 0, ptr %local.payload.23, align 4
  store i32 0, ptr %local.owner.end.24, align 4
  store i32 0, ptr %local.type.25, align 4
  %local.active.26 = alloca i1, align 1
  %local.offset.27 = alloca i32, align 4
  %local.extent.28 = alloca i32, align 4
  %local.payload.29 = alloca i32, align 4
  %local.owner.end.30 = alloca i32, align 4
  %local.type.31 = alloca i32, align 4
  store i1 false, ptr %local.active.26, align 1
  store i32 0, ptr %local.offset.27, align 4
  store i32 0, ptr %local.extent.28, align 4
  store i32 0, ptr %local.payload.29, align 4
  store i32 0, ptr %local.owner.end.30, align 4
  store i32 0, ptr %local.type.31, align 4
  %local.active.32 = alloca i1, align 1
  %local.offset.33 = alloca i32, align 4
  %local.extent.34 = alloca i32, align 4
  %local.payload.35 = alloca i32, align 4
  %local.owner.end.36 = alloca i32, align 4
  %local.type.37 = alloca i32, align 4
  store i1 false, ptr %local.active.32, align 1
  store i32 0, ptr %local.offset.33, align 4
  store i32 0, ptr %local.extent.34, align 4
  store i32 0, ptr %local.payload.35, align 4
  store i32 0, ptr %local.owner.end.36, align 4
  store i32 0, ptr %local.type.37, align 4
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %context.field.40 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.41 = load i32, ptr %context.field.40, align 4
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %context.field.44 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.45 = load i32, ptr %context.field.44, align 4
  %frame.entered.46 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.47 = icmp eq i32 %frame.entered.46, 0
  br i1 %frame.enter.ok.47, label %frame.enter.continue.48, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.48:
  %descriptor.element.49 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 0
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 1
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %descriptor.field.54 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 2
  %descriptor.value.55 = load i32, ptr %descriptor.field.54, align 4
  %descriptor.field.56 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 3
  %descriptor.value.57 = load i32, ptr %descriptor.field.56, align 4
  %descriptor.field.58 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 4
  %descriptor.value.59 = load i32, ptr %descriptor.field.58, align 4
  %argument.type.valid.60 = icmp eq i32 %descriptor.value.51, 1
  br i1 %argument.type.valid.60, label %argument.type.ok.61, label %frame.failure.0
argument.type.ok.61:
  %context.field.62 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.63 = load i32, ptr %context.field.62, align 4
  %stack.sub.66 = sub i32 %descriptor.value.59, %descriptor.value.53
  %descriptor.owner.inside.64 = icmp ule i32 %descriptor.value.59, %context.value.63
  %descriptor.offset.inside.65 = icmp ule i32 %descriptor.value.53, %descriptor.value.59
  %descriptor.extent.inside.67 = icmp ule i32 %descriptor.value.55, %stack.sub.66
  %descriptor.payload.inside.68 = icmp ule i32 %descriptor.value.57, %descriptor.value.55
  %descriptor.owner.offset.valid.69 = and i1 %descriptor.owner.inside.64, %descriptor.offset.inside.65
  %descriptor.range.inside.71 = and i1 %descriptor.owner.offset.valid.69, %descriptor.extent.inside.67
  %descriptor.range.valid.70 = and i1 %descriptor.range.inside.71, %descriptor.payload.inside.68
  %descriptor.type.valid.72 = icmp eq i32 1, 1
  %descriptor.valid.73 = and i1 %descriptor.range.valid.70, %descriptor.type.valid.72
  br i1 %descriptor.valid.73, label %descriptor.valid.74, label %descriptor.invalid.75
descriptor.invalid.75:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.74:
  %descriptor.initialized.status.76 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.53, i32 %descriptor.value.55)
  %helper.ok.77 = icmp eq i32 %descriptor.initialized.status.76, 0
  br i1 %helper.ok.77, label %helper.continue.78, label %frame.failure.0
helper.continue.78:
  %descriptor.element.79 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.80 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 0
  %descriptor.value.81 = load i32, ptr %descriptor.field.80, align 4
  %descriptor.field.82 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 1
  %descriptor.value.83 = load i32, ptr %descriptor.field.82, align 4
  %descriptor.field.84 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 2
  %descriptor.value.85 = load i32, ptr %descriptor.field.84, align 4
  %descriptor.field.86 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 3
  %descriptor.value.87 = load i32, ptr %descriptor.field.86, align 4
  %descriptor.field.88 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 4
  %descriptor.value.89 = load i32, ptr %descriptor.field.88, align 4
  %argument.type.valid.90 = icmp eq i32 %descriptor.value.81, 1
  br i1 %argument.type.valid.90, label %argument.type.ok.91, label %frame.failure.0
argument.type.ok.91:
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %stack.sub.96 = sub i32 %descriptor.value.89, %descriptor.value.83
  %descriptor.owner.inside.94 = icmp ule i32 %descriptor.value.89, %context.value.93
  %descriptor.offset.inside.95 = icmp ule i32 %descriptor.value.83, %descriptor.value.89
  %descriptor.extent.inside.97 = icmp ule i32 %descriptor.value.85, %stack.sub.96
  %descriptor.payload.inside.98 = icmp ule i32 %descriptor.value.87, %descriptor.value.85
  %descriptor.owner.offset.valid.99 = and i1 %descriptor.owner.inside.94, %descriptor.offset.inside.95
  %descriptor.range.inside.101 = and i1 %descriptor.owner.offset.valid.99, %descriptor.extent.inside.97
  %descriptor.range.valid.100 = and i1 %descriptor.range.inside.101, %descriptor.payload.inside.98
  %descriptor.type.valid.102 = icmp eq i32 1, 1
  %descriptor.valid.103 = and i1 %descriptor.range.valid.100, %descriptor.type.valid.102
  br i1 %descriptor.valid.103, label %descriptor.valid.104, label %descriptor.invalid.105
descriptor.invalid.105:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.104:
  %descriptor.initialized.status.106 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.83, i32 %descriptor.value.85)
  %helper.ok.107 = icmp eq i32 %descriptor.initialized.status.106, 0
  br i1 %helper.ok.107, label %helper.continue.108, label %frame.failure.0
helper.continue.108:
  %step.status.109 = call i32 @al_owning_charge_step(ptr %ctx, i32 23)
  %helper.ok.110 = icmp eq i32 %step.status.109, 0
  br i1 %helper.ok.110, label %helper.continue.111, label %frame.failure.0
helper.continue.111:
  store i1 true, ptr %local.active.2, align 1
  store i32 %descriptor.value.83, ptr %local.offset.3, align 4
  store i32 %descriptor.value.85, ptr %local.extent.4, align 4
  store i32 %descriptor.value.87, ptr %local.payload.5, align 4
  store i32 %descriptor.value.89, ptr %local.owner.end.6, align 4
  store i32 1, ptr %local.type.7, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %descriptor.value.83, i32 20, i32 %descriptor.value.87, i32 %descriptor.value.89, i32 %descriptor.value.85)
  %context.field.112 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.113 = load i32, ptr %context.field.112, align 4
  %runtime.ok.114 = icmp eq i32 %context.value.113, 0
  br i1 %runtime.ok.114, label %runtime.continue.115, label %frame.failure.0
runtime.continue.115:
  %context.field.116 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.117 = load i32, ptr %context.field.116, align 4
  %stack.sub.120 = sub i32 %descriptor.value.59, %descriptor.value.53
  %descriptor.owner.inside.118 = icmp ule i32 %descriptor.value.59, %context.value.117
  %descriptor.offset.inside.119 = icmp ule i32 %descriptor.value.53, %descriptor.value.59
  %descriptor.extent.inside.121 = icmp ule i32 %descriptor.value.55, %stack.sub.120
  %descriptor.payload.inside.122 = icmp ule i32 %descriptor.value.57, %descriptor.value.55
  %descriptor.owner.offset.valid.123 = and i1 %descriptor.owner.inside.118, %descriptor.offset.inside.119
  %descriptor.range.inside.125 = and i1 %descriptor.owner.offset.valid.123, %descriptor.extent.inside.121
  %descriptor.range.valid.124 = and i1 %descriptor.range.inside.125, %descriptor.payload.inside.122
  %descriptor.type.valid.126 = icmp eq i32 1, 1
  %descriptor.valid.127 = and i1 %descriptor.range.valid.124, %descriptor.type.valid.126
  br i1 %descriptor.valid.127, label %descriptor.valid.128, label %descriptor.invalid.129
descriptor.invalid.129:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.128:
  %descriptor.initialized.status.130 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.53, i32 %descriptor.value.55)
  %helper.ok.131 = icmp eq i32 %descriptor.initialized.status.130, 0
  br i1 %helper.ok.131, label %helper.continue.132, label %frame.failure.0
helper.continue.132:
  %local.is.active.133 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.133, label %local.descriptor.active.134, label %local.descriptor.inactive.135
local.descriptor.active.134:
  %local.check.offset.137 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.138 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.139 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.140 = load i32, ptr %local.owner.end.6, align 4
  %context.field.141 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.142 = load i32, ptr %context.field.141, align 4
  %stack.sub.145 = sub i32 %local.check.owner.end.140, %local.check.offset.137
  %descriptor.owner.inside.143 = icmp ule i32 %local.check.owner.end.140, %context.value.142
  %descriptor.offset.inside.144 = icmp ule i32 %local.check.offset.137, %local.check.owner.end.140
  %descriptor.extent.inside.146 = icmp ule i32 %local.check.extent.138, %stack.sub.145
  %descriptor.payload.inside.147 = icmp ule i32 %local.check.payload.139, %local.check.extent.138
  %descriptor.owner.offset.valid.148 = and i1 %descriptor.owner.inside.143, %descriptor.offset.inside.144
  %descriptor.range.inside.150 = and i1 %descriptor.owner.offset.valid.148, %descriptor.extent.inside.146
  %descriptor.range.valid.149 = and i1 %descriptor.range.inside.150, %descriptor.payload.inside.147
  br i1 %descriptor.range.valid.149, label %descriptor.valid.151, label %descriptor.invalid.152
descriptor.invalid.152:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.151:
  %descriptor.initialized.status.153 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.137, i32 %local.check.extent.138)
  %helper.ok.154 = icmp eq i32 %descriptor.initialized.status.153, 0
  br i1 %helper.ok.154, label %helper.continue.155, label %frame.failure.0
helper.continue.155:
  br label %local.descriptor.checked.136
local.descriptor.inactive.135:
  br label %local.descriptor.checked.136
local.descriptor.checked.136:
  %local.is.active.156 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.156, label %local.descriptor.active.157, label %local.descriptor.inactive.158
local.descriptor.active.157:
  %local.check.offset.160 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.161 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.162 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.163 = load i32, ptr %local.owner.end.12, align 4
  %context.field.164 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.165 = load i32, ptr %context.field.164, align 4
  %stack.sub.168 = sub i32 %local.check.owner.end.163, %local.check.offset.160
  %descriptor.owner.inside.166 = icmp ule i32 %local.check.owner.end.163, %context.value.165
  %descriptor.offset.inside.167 = icmp ule i32 %local.check.offset.160, %local.check.owner.end.163
  %descriptor.extent.inside.169 = icmp ule i32 %local.check.extent.161, %stack.sub.168
  %descriptor.payload.inside.170 = icmp ule i32 %local.check.payload.162, %local.check.extent.161
  %descriptor.owner.offset.valid.171 = and i1 %descriptor.owner.inside.166, %descriptor.offset.inside.167
  %descriptor.range.inside.173 = and i1 %descriptor.owner.offset.valid.171, %descriptor.extent.inside.169
  %descriptor.range.valid.172 = and i1 %descriptor.range.inside.173, %descriptor.payload.inside.170
  br i1 %descriptor.range.valid.172, label %descriptor.valid.174, label %descriptor.invalid.175
descriptor.invalid.175:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.174:
  %descriptor.initialized.status.176 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.160, i32 %local.check.extent.161)
  %helper.ok.177 = icmp eq i32 %descriptor.initialized.status.176, 0
  br i1 %helper.ok.177, label %helper.continue.178, label %frame.failure.0
helper.continue.178:
  br label %local.descriptor.checked.159
local.descriptor.inactive.158:
  br label %local.descriptor.checked.159
local.descriptor.checked.159:
  %local.is.active.179 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.179, label %local.descriptor.active.180, label %local.descriptor.inactive.181
local.descriptor.active.180:
  %local.check.offset.183 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.184 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.185 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.186 = load i32, ptr %local.owner.end.18, align 4
  %context.field.187 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.188 = load i32, ptr %context.field.187, align 4
  %stack.sub.191 = sub i32 %local.check.owner.end.186, %local.check.offset.183
  %descriptor.owner.inside.189 = icmp ule i32 %local.check.owner.end.186, %context.value.188
  %descriptor.offset.inside.190 = icmp ule i32 %local.check.offset.183, %local.check.owner.end.186
  %descriptor.extent.inside.192 = icmp ule i32 %local.check.extent.184, %stack.sub.191
  %descriptor.payload.inside.193 = icmp ule i32 %local.check.payload.185, %local.check.extent.184
  %descriptor.owner.offset.valid.194 = and i1 %descriptor.owner.inside.189, %descriptor.offset.inside.190
  %descriptor.range.inside.196 = and i1 %descriptor.owner.offset.valid.194, %descriptor.extent.inside.192
  %descriptor.range.valid.195 = and i1 %descriptor.range.inside.196, %descriptor.payload.inside.193
  br i1 %descriptor.range.valid.195, label %descriptor.valid.197, label %descriptor.invalid.198
descriptor.invalid.198:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.197:
  %descriptor.initialized.status.199 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.183, i32 %local.check.extent.184)
  %helper.ok.200 = icmp eq i32 %descriptor.initialized.status.199, 0
  br i1 %helper.ok.200, label %helper.continue.201, label %frame.failure.0
helper.continue.201:
  br label %local.descriptor.checked.182
local.descriptor.inactive.181:
  br label %local.descriptor.checked.182
local.descriptor.checked.182:
  %local.is.active.202 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.202, label %local.descriptor.active.203, label %local.descriptor.inactive.204
local.descriptor.active.203:
  %local.check.offset.206 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.207 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.208 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.209 = load i32, ptr %local.owner.end.24, align 4
  %context.field.210 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.211 = load i32, ptr %context.field.210, align 4
  %stack.sub.214 = sub i32 %local.check.owner.end.209, %local.check.offset.206
  %descriptor.owner.inside.212 = icmp ule i32 %local.check.owner.end.209, %context.value.211
  %descriptor.offset.inside.213 = icmp ule i32 %local.check.offset.206, %local.check.owner.end.209
  %descriptor.extent.inside.215 = icmp ule i32 %local.check.extent.207, %stack.sub.214
  %descriptor.payload.inside.216 = icmp ule i32 %local.check.payload.208, %local.check.extent.207
  %descriptor.owner.offset.valid.217 = and i1 %descriptor.owner.inside.212, %descriptor.offset.inside.213
  %descriptor.range.inside.219 = and i1 %descriptor.owner.offset.valid.217, %descriptor.extent.inside.215
  %descriptor.range.valid.218 = and i1 %descriptor.range.inside.219, %descriptor.payload.inside.216
  br i1 %descriptor.range.valid.218, label %descriptor.valid.220, label %descriptor.invalid.221
descriptor.invalid.221:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.220:
  %descriptor.initialized.status.222 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.206, i32 %local.check.extent.207)
  %helper.ok.223 = icmp eq i32 %descriptor.initialized.status.222, 0
  br i1 %helper.ok.223, label %helper.continue.224, label %frame.failure.0
helper.continue.224:
  br label %local.descriptor.checked.205
local.descriptor.inactive.204:
  br label %local.descriptor.checked.205
local.descriptor.checked.205:
  %local.is.active.225 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.225, label %local.descriptor.active.226, label %local.descriptor.inactive.227
local.descriptor.active.226:
  %local.check.offset.229 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.230 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.231 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.232 = load i32, ptr %local.owner.end.30, align 4
  %context.field.233 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.234 = load i32, ptr %context.field.233, align 4
  %stack.sub.237 = sub i32 %local.check.owner.end.232, %local.check.offset.229
  %descriptor.owner.inside.235 = icmp ule i32 %local.check.owner.end.232, %context.value.234
  %descriptor.offset.inside.236 = icmp ule i32 %local.check.offset.229, %local.check.owner.end.232
  %descriptor.extent.inside.238 = icmp ule i32 %local.check.extent.230, %stack.sub.237
  %descriptor.payload.inside.239 = icmp ule i32 %local.check.payload.231, %local.check.extent.230
  %descriptor.owner.offset.valid.240 = and i1 %descriptor.owner.inside.235, %descriptor.offset.inside.236
  %descriptor.range.inside.242 = and i1 %descriptor.owner.offset.valid.240, %descriptor.extent.inside.238
  %descriptor.range.valid.241 = and i1 %descriptor.range.inside.242, %descriptor.payload.inside.239
  br i1 %descriptor.range.valid.241, label %descriptor.valid.243, label %descriptor.invalid.244
descriptor.invalid.244:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.243:
  %descriptor.initialized.status.245 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.229, i32 %local.check.extent.230)
  %helper.ok.246 = icmp eq i32 %descriptor.initialized.status.245, 0
  br i1 %helper.ok.246, label %helper.continue.247, label %frame.failure.0
helper.continue.247:
  br label %local.descriptor.checked.228
local.descriptor.inactive.227:
  br label %local.descriptor.checked.228
local.descriptor.checked.228:
  %local.is.active.248 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.248, label %local.descriptor.active.249, label %local.descriptor.inactive.250
local.descriptor.active.249:
  %local.check.offset.252 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.253 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.254 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.255 = load i32, ptr %local.owner.end.36, align 4
  %context.field.256 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.257 = load i32, ptr %context.field.256, align 4
  %stack.sub.260 = sub i32 %local.check.owner.end.255, %local.check.offset.252
  %descriptor.owner.inside.258 = icmp ule i32 %local.check.owner.end.255, %context.value.257
  %descriptor.offset.inside.259 = icmp ule i32 %local.check.offset.252, %local.check.owner.end.255
  %descriptor.extent.inside.261 = icmp ule i32 %local.check.extent.253, %stack.sub.260
  %descriptor.payload.inside.262 = icmp ule i32 %local.check.payload.254, %local.check.extent.253
  %descriptor.owner.offset.valid.263 = and i1 %descriptor.owner.inside.258, %descriptor.offset.inside.259
  %descriptor.range.inside.265 = and i1 %descriptor.owner.offset.valid.263, %descriptor.extent.inside.261
  %descriptor.range.valid.264 = and i1 %descriptor.range.inside.265, %descriptor.payload.inside.262
  br i1 %descriptor.range.valid.264, label %descriptor.valid.266, label %descriptor.invalid.267
descriptor.invalid.267:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.266:
  %descriptor.initialized.status.268 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.252, i32 %local.check.extent.253)
  %helper.ok.269 = icmp eq i32 %descriptor.initialized.status.268, 0
  br i1 %helper.ok.269, label %helper.continue.270, label %frame.failure.0
helper.continue.270:
  br label %local.descriptor.checked.251
local.descriptor.inactive.250:
  br label %local.descriptor.checked.251
local.descriptor.checked.251:
  %step.status.271 = call i32 @al_owning_charge_step(ptr %ctx, i32 24)
  %helper.ok.272 = icmp eq i32 %step.status.271, 0
  br i1 %helper.ok.272, label %helper.continue.273, label %frame.failure.0
helper.continue.273:
  store i1 true, ptr %local.active.8, align 1
  store i32 %descriptor.value.53, ptr %local.offset.9, align 4
  store i32 %descriptor.value.55, ptr %local.extent.10, align 4
  store i32 %descriptor.value.57, ptr %local.payload.11, align 4
  store i32 %descriptor.value.59, ptr %local.owner.end.12, align 4
  store i32 1, ptr %local.type.13, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %descriptor.value.53, i32 20, i32 %descriptor.value.57, i32 %descriptor.value.59, i32 %descriptor.value.55)
  %context.field.274 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.275 = load i32, ptr %context.field.274, align 4
  %runtime.ok.276 = icmp eq i32 %context.value.275, 0
  br i1 %runtime.ok.276, label %runtime.continue.277, label %frame.failure.0
runtime.continue.277:
  %local.is.active.278 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.278, label %local.descriptor.active.279, label %local.descriptor.inactive.280
local.descriptor.active.279:
  %local.check.offset.282 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.283 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.284 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.285 = load i32, ptr %local.owner.end.6, align 4
  %context.field.286 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.287 = load i32, ptr %context.field.286, align 4
  %stack.sub.290 = sub i32 %local.check.owner.end.285, %local.check.offset.282
  %descriptor.owner.inside.288 = icmp ule i32 %local.check.owner.end.285, %context.value.287
  %descriptor.offset.inside.289 = icmp ule i32 %local.check.offset.282, %local.check.owner.end.285
  %descriptor.extent.inside.291 = icmp ule i32 %local.check.extent.283, %stack.sub.290
  %descriptor.payload.inside.292 = icmp ule i32 %local.check.payload.284, %local.check.extent.283
  %descriptor.owner.offset.valid.293 = and i1 %descriptor.owner.inside.288, %descriptor.offset.inside.289
  %descriptor.range.inside.295 = and i1 %descriptor.owner.offset.valid.293, %descriptor.extent.inside.291
  %descriptor.range.valid.294 = and i1 %descriptor.range.inside.295, %descriptor.payload.inside.292
  br i1 %descriptor.range.valid.294, label %descriptor.valid.296, label %descriptor.invalid.297
descriptor.invalid.297:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.296:
  %descriptor.initialized.status.298 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.282, i32 %local.check.extent.283)
  %helper.ok.299 = icmp eq i32 %descriptor.initialized.status.298, 0
  br i1 %helper.ok.299, label %helper.continue.300, label %frame.failure.0
helper.continue.300:
  br label %local.descriptor.checked.281
local.descriptor.inactive.280:
  br label %local.descriptor.checked.281
local.descriptor.checked.281:
  %local.is.active.301 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.301, label %local.descriptor.active.302, label %local.descriptor.inactive.303
local.descriptor.active.302:
  %local.check.offset.305 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.306 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.307 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.308 = load i32, ptr %local.owner.end.12, align 4
  %context.field.309 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.310 = load i32, ptr %context.field.309, align 4
  %stack.sub.313 = sub i32 %local.check.owner.end.308, %local.check.offset.305
  %descriptor.owner.inside.311 = icmp ule i32 %local.check.owner.end.308, %context.value.310
  %descriptor.offset.inside.312 = icmp ule i32 %local.check.offset.305, %local.check.owner.end.308
  %descriptor.extent.inside.314 = icmp ule i32 %local.check.extent.306, %stack.sub.313
  %descriptor.payload.inside.315 = icmp ule i32 %local.check.payload.307, %local.check.extent.306
  %descriptor.owner.offset.valid.316 = and i1 %descriptor.owner.inside.311, %descriptor.offset.inside.312
  %descriptor.range.inside.318 = and i1 %descriptor.owner.offset.valid.316, %descriptor.extent.inside.314
  %descriptor.range.valid.317 = and i1 %descriptor.range.inside.318, %descriptor.payload.inside.315
  br i1 %descriptor.range.valid.317, label %descriptor.valid.319, label %descriptor.invalid.320
descriptor.invalid.320:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.319:
  %descriptor.initialized.status.321 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.305, i32 %local.check.extent.306)
  %helper.ok.322 = icmp eq i32 %descriptor.initialized.status.321, 0
  br i1 %helper.ok.322, label %helper.continue.323, label %frame.failure.0
helper.continue.323:
  br label %local.descriptor.checked.304
local.descriptor.inactive.303:
  br label %local.descriptor.checked.304
local.descriptor.checked.304:
  %local.is.active.324 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.324, label %local.descriptor.active.325, label %local.descriptor.inactive.326
local.descriptor.active.325:
  %local.check.offset.328 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.329 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.330 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.331 = load i32, ptr %local.owner.end.18, align 4
  %context.field.332 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.333 = load i32, ptr %context.field.332, align 4
  %stack.sub.336 = sub i32 %local.check.owner.end.331, %local.check.offset.328
  %descriptor.owner.inside.334 = icmp ule i32 %local.check.owner.end.331, %context.value.333
  %descriptor.offset.inside.335 = icmp ule i32 %local.check.offset.328, %local.check.owner.end.331
  %descriptor.extent.inside.337 = icmp ule i32 %local.check.extent.329, %stack.sub.336
  %descriptor.payload.inside.338 = icmp ule i32 %local.check.payload.330, %local.check.extent.329
  %descriptor.owner.offset.valid.339 = and i1 %descriptor.owner.inside.334, %descriptor.offset.inside.335
  %descriptor.range.inside.341 = and i1 %descriptor.owner.offset.valid.339, %descriptor.extent.inside.337
  %descriptor.range.valid.340 = and i1 %descriptor.range.inside.341, %descriptor.payload.inside.338
  br i1 %descriptor.range.valid.340, label %descriptor.valid.342, label %descriptor.invalid.343
descriptor.invalid.343:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.342:
  %descriptor.initialized.status.344 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.328, i32 %local.check.extent.329)
  %helper.ok.345 = icmp eq i32 %descriptor.initialized.status.344, 0
  br i1 %helper.ok.345, label %helper.continue.346, label %frame.failure.0
helper.continue.346:
  br label %local.descriptor.checked.327
local.descriptor.inactive.326:
  br label %local.descriptor.checked.327
local.descriptor.checked.327:
  %local.is.active.347 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.347, label %local.descriptor.active.348, label %local.descriptor.inactive.349
local.descriptor.active.348:
  %local.check.offset.351 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.352 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.353 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.354 = load i32, ptr %local.owner.end.24, align 4
  %context.field.355 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.356 = load i32, ptr %context.field.355, align 4
  %stack.sub.359 = sub i32 %local.check.owner.end.354, %local.check.offset.351
  %descriptor.owner.inside.357 = icmp ule i32 %local.check.owner.end.354, %context.value.356
  %descriptor.offset.inside.358 = icmp ule i32 %local.check.offset.351, %local.check.owner.end.354
  %descriptor.extent.inside.360 = icmp ule i32 %local.check.extent.352, %stack.sub.359
  %descriptor.payload.inside.361 = icmp ule i32 %local.check.payload.353, %local.check.extent.352
  %descriptor.owner.offset.valid.362 = and i1 %descriptor.owner.inside.357, %descriptor.offset.inside.358
  %descriptor.range.inside.364 = and i1 %descriptor.owner.offset.valid.362, %descriptor.extent.inside.360
  %descriptor.range.valid.363 = and i1 %descriptor.range.inside.364, %descriptor.payload.inside.361
  br i1 %descriptor.range.valid.363, label %descriptor.valid.365, label %descriptor.invalid.366
descriptor.invalid.366:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.365:
  %descriptor.initialized.status.367 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.351, i32 %local.check.extent.352)
  %helper.ok.368 = icmp eq i32 %descriptor.initialized.status.367, 0
  br i1 %helper.ok.368, label %helper.continue.369, label %frame.failure.0
helper.continue.369:
  br label %local.descriptor.checked.350
local.descriptor.inactive.349:
  br label %local.descriptor.checked.350
local.descriptor.checked.350:
  %local.is.active.370 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.370, label %local.descriptor.active.371, label %local.descriptor.inactive.372
local.descriptor.active.371:
  %local.check.offset.374 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.375 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.376 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.377 = load i32, ptr %local.owner.end.30, align 4
  %context.field.378 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.379 = load i32, ptr %context.field.378, align 4
  %stack.sub.382 = sub i32 %local.check.owner.end.377, %local.check.offset.374
  %descriptor.owner.inside.380 = icmp ule i32 %local.check.owner.end.377, %context.value.379
  %descriptor.offset.inside.381 = icmp ule i32 %local.check.offset.374, %local.check.owner.end.377
  %descriptor.extent.inside.383 = icmp ule i32 %local.check.extent.375, %stack.sub.382
  %descriptor.payload.inside.384 = icmp ule i32 %local.check.payload.376, %local.check.extent.375
  %descriptor.owner.offset.valid.385 = and i1 %descriptor.owner.inside.380, %descriptor.offset.inside.381
  %descriptor.range.inside.387 = and i1 %descriptor.owner.offset.valid.385, %descriptor.extent.inside.383
  %descriptor.range.valid.386 = and i1 %descriptor.range.inside.387, %descriptor.payload.inside.384
  br i1 %descriptor.range.valid.386, label %descriptor.valid.388, label %descriptor.invalid.389
descriptor.invalid.389:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.388:
  %descriptor.initialized.status.390 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.374, i32 %local.check.extent.375)
  %helper.ok.391 = icmp eq i32 %descriptor.initialized.status.390, 0
  br i1 %helper.ok.391, label %helper.continue.392, label %frame.failure.0
helper.continue.392:
  br label %local.descriptor.checked.373
local.descriptor.inactive.372:
  br label %local.descriptor.checked.373
local.descriptor.checked.373:
  %local.is.active.393 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.393, label %local.descriptor.active.394, label %local.descriptor.inactive.395
local.descriptor.active.394:
  %local.check.offset.397 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.398 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.399 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.400 = load i32, ptr %local.owner.end.36, align 4
  %context.field.401 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.402 = load i32, ptr %context.field.401, align 4
  %stack.sub.405 = sub i32 %local.check.owner.end.400, %local.check.offset.397
  %descriptor.owner.inside.403 = icmp ule i32 %local.check.owner.end.400, %context.value.402
  %descriptor.offset.inside.404 = icmp ule i32 %local.check.offset.397, %local.check.owner.end.400
  %descriptor.extent.inside.406 = icmp ule i32 %local.check.extent.398, %stack.sub.405
  %descriptor.payload.inside.407 = icmp ule i32 %local.check.payload.399, %local.check.extent.398
  %descriptor.owner.offset.valid.408 = and i1 %descriptor.owner.inside.403, %descriptor.offset.inside.404
  %descriptor.range.inside.410 = and i1 %descriptor.owner.offset.valid.408, %descriptor.extent.inside.406
  %descriptor.range.valid.409 = and i1 %descriptor.range.inside.410, %descriptor.payload.inside.407
  br i1 %descriptor.range.valid.409, label %descriptor.valid.411, label %descriptor.invalid.412
descriptor.invalid.412:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.411:
  %descriptor.initialized.status.413 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.397, i32 %local.check.extent.398)
  %helper.ok.414 = icmp eq i32 %descriptor.initialized.status.413, 0
  br i1 %helper.ok.414, label %helper.continue.415, label %frame.failure.0
helper.continue.415:
  br label %local.descriptor.checked.396
local.descriptor.inactive.395:
  br label %local.descriptor.checked.396
local.descriptor.checked.396:
  %step.status.416 = call i32 @al_owning_charge_step(ptr %ctx, i32 25)
  %helper.ok.417 = icmp eq i32 %step.status.416, 0
  br i1 %helper.ok.417, label %helper.continue.418, label %frame.failure.0
helper.continue.418:
  %context.field.419 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.420 = load i32, ptr %context.field.419, align 4
  store i1 false, ptr %local.active.20, align 1
  store i32 0, ptr %local.offset.21, align 4
  store i32 0, ptr %local.extent.22, align 4
  store i32 0, ptr %local.payload.23, align 4
  store i32 0, ptr %local.owner.end.24, align 4
  store i32 0, ptr %local.type.25, align 4
  %step.status.421 = call i32 @al_owning_charge_step(ptr %ctx, i32 26)
  %helper.ok.422 = icmp eq i32 %step.status.421, 0
  br i1 %helper.ok.422, label %helper.continue.423, label %frame.failure.0
helper.continue.423:
  %local.resolved.offset.424 = load i32, ptr %local.offset.9, align 4
  %local.resolved.extent.425 = load i32, ptr %local.extent.10, align 4
  %local.resolved.payload.426 = load i32, ptr %local.payload.11, align 4
  %local.resolved.owner.end.427 = load i32, ptr %local.owner.end.12, align 4
  %context.field.428 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.429 = load i32, ptr %context.field.428, align 4
  %stack.sub.432 = sub i32 %local.resolved.owner.end.427, %local.resolved.offset.424
  %descriptor.owner.inside.430 = icmp ule i32 %local.resolved.owner.end.427, %context.value.429
  %descriptor.offset.inside.431 = icmp ule i32 %local.resolved.offset.424, %local.resolved.owner.end.427
  %descriptor.extent.inside.433 = icmp ule i32 %local.resolved.extent.425, %stack.sub.432
  %descriptor.payload.inside.434 = icmp ule i32 %local.resolved.payload.426, %local.resolved.extent.425
  %descriptor.owner.offset.valid.435 = and i1 %descriptor.owner.inside.430, %descriptor.offset.inside.431
  %descriptor.range.inside.437 = and i1 %descriptor.owner.offset.valid.435, %descriptor.extent.inside.433
  %descriptor.range.valid.436 = and i1 %descriptor.range.inside.437, %descriptor.payload.inside.434
  %descriptor.type.valid.438 = icmp eq i32 1, 1
  %descriptor.valid.439 = and i1 %descriptor.range.valid.436, %descriptor.type.valid.438
  br i1 %descriptor.valid.439, label %descriptor.valid.440, label %descriptor.invalid.441
descriptor.invalid.441:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.440:
  %descriptor.initialized.status.442 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.424, i32 %local.resolved.extent.425)
  %helper.ok.443 = icmp eq i32 %descriptor.initialized.status.442, 0
  br i1 %helper.ok.443, label %helper.continue.444, label %frame.failure.0
helper.continue.444:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %local.resolved.offset.424, i32 20, i32 %local.resolved.payload.426, i32 %local.resolved.owner.end.427, i32 %local.resolved.extent.425)
  %context.field.445 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.446 = load i32, ptr %context.field.445, align 4
  %runtime.ok.447 = icmp eq i32 %context.value.446, 0
  br i1 %runtime.ok.447, label %runtime.continue.448, label %frame.failure.0
runtime.continue.448:
  %context.field.449 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.450 = load i32, ptr %context.field.449, align 4
  %stack.sub.453 = sub i32 %local.resolved.owner.end.427, %local.resolved.offset.424
  %descriptor.owner.inside.451 = icmp ule i32 %local.resolved.owner.end.427, %context.value.450
  %descriptor.offset.inside.452 = icmp ule i32 %local.resolved.offset.424, %local.resolved.owner.end.427
  %descriptor.extent.inside.454 = icmp ule i32 %local.resolved.extent.425, %stack.sub.453
  %descriptor.payload.inside.455 = icmp ule i32 %local.resolved.payload.426, %local.resolved.extent.425
  %descriptor.owner.offset.valid.456 = and i1 %descriptor.owner.inside.451, %descriptor.offset.inside.452
  %descriptor.range.inside.458 = and i1 %descriptor.owner.offset.valid.456, %descriptor.extent.inside.454
  %descriptor.range.valid.457 = and i1 %descriptor.range.inside.458, %descriptor.payload.inside.455
  %descriptor.type.valid.459 = icmp eq i32 1, 1
  %descriptor.valid.460 = and i1 %descriptor.range.valid.457, %descriptor.type.valid.459
  br i1 %descriptor.valid.460, label %descriptor.valid.461, label %descriptor.invalid.462
descriptor.invalid.462:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.461:
  %descriptor.initialized.status.463 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.424, i32 %local.resolved.extent.425)
  %helper.ok.464 = icmp eq i32 %descriptor.initialized.status.463, 0
  br i1 %helper.ok.464, label %helper.continue.465, label %frame.failure.0
helper.continue.465:
  %local.is.active.466 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.466, label %local.descriptor.active.467, label %local.descriptor.inactive.468
local.descriptor.active.467:
  %local.check.offset.470 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.471 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.472 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.473 = load i32, ptr %local.owner.end.6, align 4
  %context.field.474 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.475 = load i32, ptr %context.field.474, align 4
  %stack.sub.478 = sub i32 %local.check.owner.end.473, %local.check.offset.470
  %descriptor.owner.inside.476 = icmp ule i32 %local.check.owner.end.473, %context.value.475
  %descriptor.offset.inside.477 = icmp ule i32 %local.check.offset.470, %local.check.owner.end.473
  %descriptor.extent.inside.479 = icmp ule i32 %local.check.extent.471, %stack.sub.478
  %descriptor.payload.inside.480 = icmp ule i32 %local.check.payload.472, %local.check.extent.471
  %descriptor.owner.offset.valid.481 = and i1 %descriptor.owner.inside.476, %descriptor.offset.inside.477
  %descriptor.range.inside.483 = and i1 %descriptor.owner.offset.valid.481, %descriptor.extent.inside.479
  %descriptor.range.valid.482 = and i1 %descriptor.range.inside.483, %descriptor.payload.inside.480
  br i1 %descriptor.range.valid.482, label %descriptor.valid.484, label %descriptor.invalid.485
descriptor.invalid.485:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.484:
  %descriptor.initialized.status.486 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.470, i32 %local.check.extent.471)
  %helper.ok.487 = icmp eq i32 %descriptor.initialized.status.486, 0
  br i1 %helper.ok.487, label %helper.continue.488, label %frame.failure.0
helper.continue.488:
  br label %local.descriptor.checked.469
local.descriptor.inactive.468:
  br label %local.descriptor.checked.469
local.descriptor.checked.469:
  %local.is.active.489 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.489, label %local.descriptor.active.490, label %local.descriptor.inactive.491
local.descriptor.active.490:
  %local.check.offset.493 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.494 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.495 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.496 = load i32, ptr %local.owner.end.12, align 4
  %context.field.497 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.498 = load i32, ptr %context.field.497, align 4
  %stack.sub.501 = sub i32 %local.check.owner.end.496, %local.check.offset.493
  %descriptor.owner.inside.499 = icmp ule i32 %local.check.owner.end.496, %context.value.498
  %descriptor.offset.inside.500 = icmp ule i32 %local.check.offset.493, %local.check.owner.end.496
  %descriptor.extent.inside.502 = icmp ule i32 %local.check.extent.494, %stack.sub.501
  %descriptor.payload.inside.503 = icmp ule i32 %local.check.payload.495, %local.check.extent.494
  %descriptor.owner.offset.valid.504 = and i1 %descriptor.owner.inside.499, %descriptor.offset.inside.500
  %descriptor.range.inside.506 = and i1 %descriptor.owner.offset.valid.504, %descriptor.extent.inside.502
  %descriptor.range.valid.505 = and i1 %descriptor.range.inside.506, %descriptor.payload.inside.503
  br i1 %descriptor.range.valid.505, label %descriptor.valid.507, label %descriptor.invalid.508
descriptor.invalid.508:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.507:
  %descriptor.initialized.status.509 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.493, i32 %local.check.extent.494)
  %helper.ok.510 = icmp eq i32 %descriptor.initialized.status.509, 0
  br i1 %helper.ok.510, label %helper.continue.511, label %frame.failure.0
helper.continue.511:
  br label %local.descriptor.checked.492
local.descriptor.inactive.491:
  br label %local.descriptor.checked.492
local.descriptor.checked.492:
  %local.is.active.512 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.512, label %local.descriptor.active.513, label %local.descriptor.inactive.514
local.descriptor.active.513:
  %local.check.offset.516 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.517 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.518 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.519 = load i32, ptr %local.owner.end.18, align 4
  %context.field.520 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.521 = load i32, ptr %context.field.520, align 4
  %stack.sub.524 = sub i32 %local.check.owner.end.519, %local.check.offset.516
  %descriptor.owner.inside.522 = icmp ule i32 %local.check.owner.end.519, %context.value.521
  %descriptor.offset.inside.523 = icmp ule i32 %local.check.offset.516, %local.check.owner.end.519
  %descriptor.extent.inside.525 = icmp ule i32 %local.check.extent.517, %stack.sub.524
  %descriptor.payload.inside.526 = icmp ule i32 %local.check.payload.518, %local.check.extent.517
  %descriptor.owner.offset.valid.527 = and i1 %descriptor.owner.inside.522, %descriptor.offset.inside.523
  %descriptor.range.inside.529 = and i1 %descriptor.owner.offset.valid.527, %descriptor.extent.inside.525
  %descriptor.range.valid.528 = and i1 %descriptor.range.inside.529, %descriptor.payload.inside.526
  br i1 %descriptor.range.valid.528, label %descriptor.valid.530, label %descriptor.invalid.531
descriptor.invalid.531:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.530:
  %descriptor.initialized.status.532 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.516, i32 %local.check.extent.517)
  %helper.ok.533 = icmp eq i32 %descriptor.initialized.status.532, 0
  br i1 %helper.ok.533, label %helper.continue.534, label %frame.failure.0
helper.continue.534:
  br label %local.descriptor.checked.515
local.descriptor.inactive.514:
  br label %local.descriptor.checked.515
local.descriptor.checked.515:
  %local.is.active.535 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.535, label %local.descriptor.active.536, label %local.descriptor.inactive.537
local.descriptor.active.536:
  %local.check.offset.539 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.540 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.541 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.542 = load i32, ptr %local.owner.end.24, align 4
  %context.field.543 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.544 = load i32, ptr %context.field.543, align 4
  %stack.sub.547 = sub i32 %local.check.owner.end.542, %local.check.offset.539
  %descriptor.owner.inside.545 = icmp ule i32 %local.check.owner.end.542, %context.value.544
  %descriptor.offset.inside.546 = icmp ule i32 %local.check.offset.539, %local.check.owner.end.542
  %descriptor.extent.inside.548 = icmp ule i32 %local.check.extent.540, %stack.sub.547
  %descriptor.payload.inside.549 = icmp ule i32 %local.check.payload.541, %local.check.extent.540
  %descriptor.owner.offset.valid.550 = and i1 %descriptor.owner.inside.545, %descriptor.offset.inside.546
  %descriptor.range.inside.552 = and i1 %descriptor.owner.offset.valid.550, %descriptor.extent.inside.548
  %descriptor.range.valid.551 = and i1 %descriptor.range.inside.552, %descriptor.payload.inside.549
  br i1 %descriptor.range.valid.551, label %descriptor.valid.553, label %descriptor.invalid.554
descriptor.invalid.554:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.553:
  %descriptor.initialized.status.555 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.539, i32 %local.check.extent.540)
  %helper.ok.556 = icmp eq i32 %descriptor.initialized.status.555, 0
  br i1 %helper.ok.556, label %helper.continue.557, label %frame.failure.0
helper.continue.557:
  br label %local.descriptor.checked.538
local.descriptor.inactive.537:
  br label %local.descriptor.checked.538
local.descriptor.checked.538:
  %local.is.active.558 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.558, label %local.descriptor.active.559, label %local.descriptor.inactive.560
local.descriptor.active.559:
  %local.check.offset.562 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.563 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.564 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.565 = load i32, ptr %local.owner.end.30, align 4
  %context.field.566 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.567 = load i32, ptr %context.field.566, align 4
  %stack.sub.570 = sub i32 %local.check.owner.end.565, %local.check.offset.562
  %descriptor.owner.inside.568 = icmp ule i32 %local.check.owner.end.565, %context.value.567
  %descriptor.offset.inside.569 = icmp ule i32 %local.check.offset.562, %local.check.owner.end.565
  %descriptor.extent.inside.571 = icmp ule i32 %local.check.extent.563, %stack.sub.570
  %descriptor.payload.inside.572 = icmp ule i32 %local.check.payload.564, %local.check.extent.563
  %descriptor.owner.offset.valid.573 = and i1 %descriptor.owner.inside.568, %descriptor.offset.inside.569
  %descriptor.range.inside.575 = and i1 %descriptor.owner.offset.valid.573, %descriptor.extent.inside.571
  %descriptor.range.valid.574 = and i1 %descriptor.range.inside.575, %descriptor.payload.inside.572
  br i1 %descriptor.range.valid.574, label %descriptor.valid.576, label %descriptor.invalid.577
descriptor.invalid.577:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.576:
  %descriptor.initialized.status.578 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.562, i32 %local.check.extent.563)
  %helper.ok.579 = icmp eq i32 %descriptor.initialized.status.578, 0
  br i1 %helper.ok.579, label %helper.continue.580, label %frame.failure.0
helper.continue.580:
  br label %local.descriptor.checked.561
local.descriptor.inactive.560:
  br label %local.descriptor.checked.561
local.descriptor.checked.561:
  %local.is.active.581 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.581, label %local.descriptor.active.582, label %local.descriptor.inactive.583
local.descriptor.active.582:
  %local.check.offset.585 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.586 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.587 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.588 = load i32, ptr %local.owner.end.36, align 4
  %context.field.589 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.590 = load i32, ptr %context.field.589, align 4
  %stack.sub.593 = sub i32 %local.check.owner.end.588, %local.check.offset.585
  %descriptor.owner.inside.591 = icmp ule i32 %local.check.owner.end.588, %context.value.590
  %descriptor.offset.inside.592 = icmp ule i32 %local.check.offset.585, %local.check.owner.end.588
  %descriptor.extent.inside.594 = icmp ule i32 %local.check.extent.586, %stack.sub.593
  %descriptor.payload.inside.595 = icmp ule i32 %local.check.payload.587, %local.check.extent.586
  %descriptor.owner.offset.valid.596 = and i1 %descriptor.owner.inside.591, %descriptor.offset.inside.592
  %descriptor.range.inside.598 = and i1 %descriptor.owner.offset.valid.596, %descriptor.extent.inside.594
  %descriptor.range.valid.597 = and i1 %descriptor.range.inside.598, %descriptor.payload.inside.595
  br i1 %descriptor.range.valid.597, label %descriptor.valid.599, label %descriptor.invalid.600
descriptor.invalid.600:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.599:
  %descriptor.initialized.status.601 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.585, i32 %local.check.extent.586)
  %helper.ok.602 = icmp eq i32 %descriptor.initialized.status.601, 0
  br i1 %helper.ok.602, label %helper.continue.603, label %frame.failure.0
helper.continue.603:
  br label %local.descriptor.checked.584
local.descriptor.inactive.583:
  br label %local.descriptor.checked.584
local.descriptor.checked.584:
  %step.status.604 = call i32 @al_owning_charge_step(ptr %ctx, i32 27)
  %helper.ok.605 = icmp eq i32 %step.status.604, 0
  br i1 %helper.ok.605, label %helper.continue.606, label %frame.failure.0
helper.continue.606:
  store i1 true, ptr %local.active.20, align 1
  store i32 %local.resolved.offset.424, ptr %local.offset.21, align 4
  store i32 %local.resolved.extent.425, ptr %local.extent.22, align 4
  store i32 %local.resolved.payload.426, ptr %local.payload.23, align 4
  store i32 %local.resolved.owner.end.427, ptr %local.owner.end.24, align 4
  store i32 1, ptr %local.type.25, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %local.resolved.offset.424, i32 20, i32 %local.resolved.payload.426, i32 %local.resolved.owner.end.427, i32 %local.resolved.extent.425)
  %context.field.607 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.608 = load i32, ptr %context.field.607, align 4
  %runtime.ok.609 = icmp eq i32 %context.value.608, 0
  br i1 %runtime.ok.609, label %runtime.continue.610, label %frame.failure.0
runtime.continue.610:
  %local.is.active.611 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.611, label %local.descriptor.active.612, label %local.descriptor.inactive.613
local.descriptor.active.612:
  %local.check.offset.615 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.616 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.617 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.618 = load i32, ptr %local.owner.end.6, align 4
  %context.field.619 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.620 = load i32, ptr %context.field.619, align 4
  %stack.sub.623 = sub i32 %local.check.owner.end.618, %local.check.offset.615
  %descriptor.owner.inside.621 = icmp ule i32 %local.check.owner.end.618, %context.value.620
  %descriptor.offset.inside.622 = icmp ule i32 %local.check.offset.615, %local.check.owner.end.618
  %descriptor.extent.inside.624 = icmp ule i32 %local.check.extent.616, %stack.sub.623
  %descriptor.payload.inside.625 = icmp ule i32 %local.check.payload.617, %local.check.extent.616
  %descriptor.owner.offset.valid.626 = and i1 %descriptor.owner.inside.621, %descriptor.offset.inside.622
  %descriptor.range.inside.628 = and i1 %descriptor.owner.offset.valid.626, %descriptor.extent.inside.624
  %descriptor.range.valid.627 = and i1 %descriptor.range.inside.628, %descriptor.payload.inside.625
  br i1 %descriptor.range.valid.627, label %descriptor.valid.629, label %descriptor.invalid.630
descriptor.invalid.630:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.629:
  %descriptor.initialized.status.631 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.615, i32 %local.check.extent.616)
  %helper.ok.632 = icmp eq i32 %descriptor.initialized.status.631, 0
  br i1 %helper.ok.632, label %helper.continue.633, label %frame.failure.0
helper.continue.633:
  br label %local.descriptor.checked.614
local.descriptor.inactive.613:
  br label %local.descriptor.checked.614
local.descriptor.checked.614:
  %local.is.active.634 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.634, label %local.descriptor.active.635, label %local.descriptor.inactive.636
local.descriptor.active.635:
  %local.check.offset.638 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.639 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.640 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.641 = load i32, ptr %local.owner.end.12, align 4
  %context.field.642 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.643 = load i32, ptr %context.field.642, align 4
  %stack.sub.646 = sub i32 %local.check.owner.end.641, %local.check.offset.638
  %descriptor.owner.inside.644 = icmp ule i32 %local.check.owner.end.641, %context.value.643
  %descriptor.offset.inside.645 = icmp ule i32 %local.check.offset.638, %local.check.owner.end.641
  %descriptor.extent.inside.647 = icmp ule i32 %local.check.extent.639, %stack.sub.646
  %descriptor.payload.inside.648 = icmp ule i32 %local.check.payload.640, %local.check.extent.639
  %descriptor.owner.offset.valid.649 = and i1 %descriptor.owner.inside.644, %descriptor.offset.inside.645
  %descriptor.range.inside.651 = and i1 %descriptor.owner.offset.valid.649, %descriptor.extent.inside.647
  %descriptor.range.valid.650 = and i1 %descriptor.range.inside.651, %descriptor.payload.inside.648
  br i1 %descriptor.range.valid.650, label %descriptor.valid.652, label %descriptor.invalid.653
descriptor.invalid.653:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.652:
  %descriptor.initialized.status.654 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.638, i32 %local.check.extent.639)
  %helper.ok.655 = icmp eq i32 %descriptor.initialized.status.654, 0
  br i1 %helper.ok.655, label %helper.continue.656, label %frame.failure.0
helper.continue.656:
  br label %local.descriptor.checked.637
local.descriptor.inactive.636:
  br label %local.descriptor.checked.637
local.descriptor.checked.637:
  %local.is.active.657 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.657, label %local.descriptor.active.658, label %local.descriptor.inactive.659
local.descriptor.active.658:
  %local.check.offset.661 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.662 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.663 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.664 = load i32, ptr %local.owner.end.18, align 4
  %context.field.665 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.666 = load i32, ptr %context.field.665, align 4
  %stack.sub.669 = sub i32 %local.check.owner.end.664, %local.check.offset.661
  %descriptor.owner.inside.667 = icmp ule i32 %local.check.owner.end.664, %context.value.666
  %descriptor.offset.inside.668 = icmp ule i32 %local.check.offset.661, %local.check.owner.end.664
  %descriptor.extent.inside.670 = icmp ule i32 %local.check.extent.662, %stack.sub.669
  %descriptor.payload.inside.671 = icmp ule i32 %local.check.payload.663, %local.check.extent.662
  %descriptor.owner.offset.valid.672 = and i1 %descriptor.owner.inside.667, %descriptor.offset.inside.668
  %descriptor.range.inside.674 = and i1 %descriptor.owner.offset.valid.672, %descriptor.extent.inside.670
  %descriptor.range.valid.673 = and i1 %descriptor.range.inside.674, %descriptor.payload.inside.671
  br i1 %descriptor.range.valid.673, label %descriptor.valid.675, label %descriptor.invalid.676
descriptor.invalid.676:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.675:
  %descriptor.initialized.status.677 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.661, i32 %local.check.extent.662)
  %helper.ok.678 = icmp eq i32 %descriptor.initialized.status.677, 0
  br i1 %helper.ok.678, label %helper.continue.679, label %frame.failure.0
helper.continue.679:
  br label %local.descriptor.checked.660
local.descriptor.inactive.659:
  br label %local.descriptor.checked.660
local.descriptor.checked.660:
  %local.is.active.680 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.680, label %local.descriptor.active.681, label %local.descriptor.inactive.682
local.descriptor.active.681:
  %local.check.offset.684 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.685 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.686 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.687 = load i32, ptr %local.owner.end.24, align 4
  %context.field.688 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.689 = load i32, ptr %context.field.688, align 4
  %stack.sub.692 = sub i32 %local.check.owner.end.687, %local.check.offset.684
  %descriptor.owner.inside.690 = icmp ule i32 %local.check.owner.end.687, %context.value.689
  %descriptor.offset.inside.691 = icmp ule i32 %local.check.offset.684, %local.check.owner.end.687
  %descriptor.extent.inside.693 = icmp ule i32 %local.check.extent.685, %stack.sub.692
  %descriptor.payload.inside.694 = icmp ule i32 %local.check.payload.686, %local.check.extent.685
  %descriptor.owner.offset.valid.695 = and i1 %descriptor.owner.inside.690, %descriptor.offset.inside.691
  %descriptor.range.inside.697 = and i1 %descriptor.owner.offset.valid.695, %descriptor.extent.inside.693
  %descriptor.range.valid.696 = and i1 %descriptor.range.inside.697, %descriptor.payload.inside.694
  br i1 %descriptor.range.valid.696, label %descriptor.valid.698, label %descriptor.invalid.699
descriptor.invalid.699:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.698:
  %descriptor.initialized.status.700 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.684, i32 %local.check.extent.685)
  %helper.ok.701 = icmp eq i32 %descriptor.initialized.status.700, 0
  br i1 %helper.ok.701, label %helper.continue.702, label %frame.failure.0
helper.continue.702:
  br label %local.descriptor.checked.683
local.descriptor.inactive.682:
  br label %local.descriptor.checked.683
local.descriptor.checked.683:
  %local.is.active.703 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.703, label %local.descriptor.active.704, label %local.descriptor.inactive.705
local.descriptor.active.704:
  %local.check.offset.707 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.708 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.709 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.710 = load i32, ptr %local.owner.end.30, align 4
  %context.field.711 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.712 = load i32, ptr %context.field.711, align 4
  %stack.sub.715 = sub i32 %local.check.owner.end.710, %local.check.offset.707
  %descriptor.owner.inside.713 = icmp ule i32 %local.check.owner.end.710, %context.value.712
  %descriptor.offset.inside.714 = icmp ule i32 %local.check.offset.707, %local.check.owner.end.710
  %descriptor.extent.inside.716 = icmp ule i32 %local.check.extent.708, %stack.sub.715
  %descriptor.payload.inside.717 = icmp ule i32 %local.check.payload.709, %local.check.extent.708
  %descriptor.owner.offset.valid.718 = and i1 %descriptor.owner.inside.713, %descriptor.offset.inside.714
  %descriptor.range.inside.720 = and i1 %descriptor.owner.offset.valid.718, %descriptor.extent.inside.716
  %descriptor.range.valid.719 = and i1 %descriptor.range.inside.720, %descriptor.payload.inside.717
  br i1 %descriptor.range.valid.719, label %descriptor.valid.721, label %descriptor.invalid.722
descriptor.invalid.722:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.721:
  %descriptor.initialized.status.723 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.707, i32 %local.check.extent.708)
  %helper.ok.724 = icmp eq i32 %descriptor.initialized.status.723, 0
  br i1 %helper.ok.724, label %helper.continue.725, label %frame.failure.0
helper.continue.725:
  br label %local.descriptor.checked.706
local.descriptor.inactive.705:
  br label %local.descriptor.checked.706
local.descriptor.checked.706:
  %local.is.active.726 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.726, label %local.descriptor.active.727, label %local.descriptor.inactive.728
local.descriptor.active.727:
  %local.check.offset.730 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.731 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.732 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.733 = load i32, ptr %local.owner.end.36, align 4
  %context.field.734 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.735 = load i32, ptr %context.field.734, align 4
  %stack.sub.738 = sub i32 %local.check.owner.end.733, %local.check.offset.730
  %descriptor.owner.inside.736 = icmp ule i32 %local.check.owner.end.733, %context.value.735
  %descriptor.offset.inside.737 = icmp ule i32 %local.check.offset.730, %local.check.owner.end.733
  %descriptor.extent.inside.739 = icmp ule i32 %local.check.extent.731, %stack.sub.738
  %descriptor.payload.inside.740 = icmp ule i32 %local.check.payload.732, %local.check.extent.731
  %descriptor.owner.offset.valid.741 = and i1 %descriptor.owner.inside.736, %descriptor.offset.inside.737
  %descriptor.range.inside.743 = and i1 %descriptor.owner.offset.valid.741, %descriptor.extent.inside.739
  %descriptor.range.valid.742 = and i1 %descriptor.range.inside.743, %descriptor.payload.inside.740
  br i1 %descriptor.range.valid.742, label %descriptor.valid.744, label %descriptor.invalid.745
descriptor.invalid.745:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.744:
  %descriptor.initialized.status.746 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.730, i32 %local.check.extent.731)
  %helper.ok.747 = icmp eq i32 %descriptor.initialized.status.746, 0
  br i1 %helper.ok.747, label %helper.continue.748, label %frame.failure.0
helper.continue.748:
  br label %local.descriptor.checked.729
local.descriptor.inactive.728:
  br label %local.descriptor.checked.729
local.descriptor.checked.729:
  %step.status.749 = call i32 @al_owning_charge_step(ptr %ctx, i32 28)
  %helper.ok.750 = icmp eq i32 %step.status.749, 0
  br i1 %helper.ok.750, label %helper.continue.751, label %frame.failure.0
helper.continue.751:
  %local.resolved.offset.752 = load i32, ptr %local.offset.21, align 4
  %local.resolved.extent.753 = load i32, ptr %local.extent.22, align 4
  %local.resolved.payload.754 = load i32, ptr %local.payload.23, align 4
  %local.resolved.owner.end.755 = load i32, ptr %local.owner.end.24, align 4
  %context.field.756 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.757 = load i32, ptr %context.field.756, align 4
  %stack.sub.760 = sub i32 %local.resolved.owner.end.755, %local.resolved.offset.752
  %descriptor.owner.inside.758 = icmp ule i32 %local.resolved.owner.end.755, %context.value.757
  %descriptor.offset.inside.759 = icmp ule i32 %local.resolved.offset.752, %local.resolved.owner.end.755
  %descriptor.extent.inside.761 = icmp ule i32 %local.resolved.extent.753, %stack.sub.760
  %descriptor.payload.inside.762 = icmp ule i32 %local.resolved.payload.754, %local.resolved.extent.753
  %descriptor.owner.offset.valid.763 = and i1 %descriptor.owner.inside.758, %descriptor.offset.inside.759
  %descriptor.range.inside.765 = and i1 %descriptor.owner.offset.valid.763, %descriptor.extent.inside.761
  %descriptor.range.valid.764 = and i1 %descriptor.range.inside.765, %descriptor.payload.inside.762
  %descriptor.type.valid.766 = icmp eq i32 1, 1
  %descriptor.valid.767 = and i1 %descriptor.range.valid.764, %descriptor.type.valid.766
  br i1 %descriptor.valid.767, label %descriptor.valid.768, label %descriptor.invalid.769
descriptor.invalid.769:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.768:
  %descriptor.initialized.status.770 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.752, i32 %local.resolved.extent.753)
  %helper.ok.771 = icmp eq i32 %descriptor.initialized.status.770, 0
  br i1 %helper.ok.771, label %helper.continue.772, label %frame.failure.0
helper.continue.772:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %local.resolved.offset.752, i32 20, i32 %local.resolved.payload.754, i32 %local.resolved.owner.end.755, i32 %local.resolved.extent.753)
  %context.field.773 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.774 = load i32, ptr %context.field.773, align 4
  %runtime.ok.775 = icmp eq i32 %context.value.774, 0
  br i1 %runtime.ok.775, label %runtime.continue.776, label %frame.failure.0
runtime.continue.776:
  %context.field.777 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.778 = load i32, ptr %context.field.777, align 4
  %stack.sub.781 = sub i32 %local.resolved.owner.end.755, %local.resolved.offset.752
  %descriptor.owner.inside.779 = icmp ule i32 %local.resolved.owner.end.755, %context.value.778
  %descriptor.offset.inside.780 = icmp ule i32 %local.resolved.offset.752, %local.resolved.owner.end.755
  %descriptor.extent.inside.782 = icmp ule i32 %local.resolved.extent.753, %stack.sub.781
  %descriptor.payload.inside.783 = icmp ule i32 %local.resolved.payload.754, %local.resolved.extent.753
  %descriptor.owner.offset.valid.784 = and i1 %descriptor.owner.inside.779, %descriptor.offset.inside.780
  %descriptor.range.inside.786 = and i1 %descriptor.owner.offset.valid.784, %descriptor.extent.inside.782
  %descriptor.range.valid.785 = and i1 %descriptor.range.inside.786, %descriptor.payload.inside.783
  %descriptor.type.valid.787 = icmp eq i32 1, 1
  %descriptor.valid.788 = and i1 %descriptor.range.valid.785, %descriptor.type.valid.787
  br i1 %descriptor.valid.788, label %descriptor.valid.789, label %descriptor.invalid.790
descriptor.invalid.790:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.789:
  %descriptor.initialized.status.791 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.752, i32 %local.resolved.extent.753)
  %helper.ok.792 = icmp eq i32 %descriptor.initialized.status.791, 0
  br i1 %helper.ok.792, label %helper.continue.793, label %frame.failure.0
helper.continue.793:
  %local.is.active.794 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.794, label %local.descriptor.active.795, label %local.descriptor.inactive.796
local.descriptor.active.795:
  %local.check.offset.798 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.799 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.800 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.801 = load i32, ptr %local.owner.end.6, align 4
  %context.field.802 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.803 = load i32, ptr %context.field.802, align 4
  %stack.sub.806 = sub i32 %local.check.owner.end.801, %local.check.offset.798
  %descriptor.owner.inside.804 = icmp ule i32 %local.check.owner.end.801, %context.value.803
  %descriptor.offset.inside.805 = icmp ule i32 %local.check.offset.798, %local.check.owner.end.801
  %descriptor.extent.inside.807 = icmp ule i32 %local.check.extent.799, %stack.sub.806
  %descriptor.payload.inside.808 = icmp ule i32 %local.check.payload.800, %local.check.extent.799
  %descriptor.owner.offset.valid.809 = and i1 %descriptor.owner.inside.804, %descriptor.offset.inside.805
  %descriptor.range.inside.811 = and i1 %descriptor.owner.offset.valid.809, %descriptor.extent.inside.807
  %descriptor.range.valid.810 = and i1 %descriptor.range.inside.811, %descriptor.payload.inside.808
  br i1 %descriptor.range.valid.810, label %descriptor.valid.812, label %descriptor.invalid.813
descriptor.invalid.813:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.812:
  %descriptor.initialized.status.814 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.798, i32 %local.check.extent.799)
  %helper.ok.815 = icmp eq i32 %descriptor.initialized.status.814, 0
  br i1 %helper.ok.815, label %helper.continue.816, label %frame.failure.0
helper.continue.816:
  br label %local.descriptor.checked.797
local.descriptor.inactive.796:
  br label %local.descriptor.checked.797
local.descriptor.checked.797:
  %local.is.active.817 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.817, label %local.descriptor.active.818, label %local.descriptor.inactive.819
local.descriptor.active.818:
  %local.check.offset.821 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.822 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.823 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.824 = load i32, ptr %local.owner.end.12, align 4
  %context.field.825 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.826 = load i32, ptr %context.field.825, align 4
  %stack.sub.829 = sub i32 %local.check.owner.end.824, %local.check.offset.821
  %descriptor.owner.inside.827 = icmp ule i32 %local.check.owner.end.824, %context.value.826
  %descriptor.offset.inside.828 = icmp ule i32 %local.check.offset.821, %local.check.owner.end.824
  %descriptor.extent.inside.830 = icmp ule i32 %local.check.extent.822, %stack.sub.829
  %descriptor.payload.inside.831 = icmp ule i32 %local.check.payload.823, %local.check.extent.822
  %descriptor.owner.offset.valid.832 = and i1 %descriptor.owner.inside.827, %descriptor.offset.inside.828
  %descriptor.range.inside.834 = and i1 %descriptor.owner.offset.valid.832, %descriptor.extent.inside.830
  %descriptor.range.valid.833 = and i1 %descriptor.range.inside.834, %descriptor.payload.inside.831
  br i1 %descriptor.range.valid.833, label %descriptor.valid.835, label %descriptor.invalid.836
descriptor.invalid.836:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.835:
  %descriptor.initialized.status.837 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.821, i32 %local.check.extent.822)
  %helper.ok.838 = icmp eq i32 %descriptor.initialized.status.837, 0
  br i1 %helper.ok.838, label %helper.continue.839, label %frame.failure.0
helper.continue.839:
  br label %local.descriptor.checked.820
local.descriptor.inactive.819:
  br label %local.descriptor.checked.820
local.descriptor.checked.820:
  %local.is.active.840 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.840, label %local.descriptor.active.841, label %local.descriptor.inactive.842
local.descriptor.active.841:
  %local.check.offset.844 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.845 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.846 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.847 = load i32, ptr %local.owner.end.18, align 4
  %context.field.848 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.849 = load i32, ptr %context.field.848, align 4
  %stack.sub.852 = sub i32 %local.check.owner.end.847, %local.check.offset.844
  %descriptor.owner.inside.850 = icmp ule i32 %local.check.owner.end.847, %context.value.849
  %descriptor.offset.inside.851 = icmp ule i32 %local.check.offset.844, %local.check.owner.end.847
  %descriptor.extent.inside.853 = icmp ule i32 %local.check.extent.845, %stack.sub.852
  %descriptor.payload.inside.854 = icmp ule i32 %local.check.payload.846, %local.check.extent.845
  %descriptor.owner.offset.valid.855 = and i1 %descriptor.owner.inside.850, %descriptor.offset.inside.851
  %descriptor.range.inside.857 = and i1 %descriptor.owner.offset.valid.855, %descriptor.extent.inside.853
  %descriptor.range.valid.856 = and i1 %descriptor.range.inside.857, %descriptor.payload.inside.854
  br i1 %descriptor.range.valid.856, label %descriptor.valid.858, label %descriptor.invalid.859
descriptor.invalid.859:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.858:
  %descriptor.initialized.status.860 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.844, i32 %local.check.extent.845)
  %helper.ok.861 = icmp eq i32 %descriptor.initialized.status.860, 0
  br i1 %helper.ok.861, label %helper.continue.862, label %frame.failure.0
helper.continue.862:
  br label %local.descriptor.checked.843
local.descriptor.inactive.842:
  br label %local.descriptor.checked.843
local.descriptor.checked.843:
  %local.is.active.863 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.863, label %local.descriptor.active.864, label %local.descriptor.inactive.865
local.descriptor.active.864:
  %local.check.offset.867 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.868 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.869 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.870 = load i32, ptr %local.owner.end.24, align 4
  %context.field.871 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.872 = load i32, ptr %context.field.871, align 4
  %stack.sub.875 = sub i32 %local.check.owner.end.870, %local.check.offset.867
  %descriptor.owner.inside.873 = icmp ule i32 %local.check.owner.end.870, %context.value.872
  %descriptor.offset.inside.874 = icmp ule i32 %local.check.offset.867, %local.check.owner.end.870
  %descriptor.extent.inside.876 = icmp ule i32 %local.check.extent.868, %stack.sub.875
  %descriptor.payload.inside.877 = icmp ule i32 %local.check.payload.869, %local.check.extent.868
  %descriptor.owner.offset.valid.878 = and i1 %descriptor.owner.inside.873, %descriptor.offset.inside.874
  %descriptor.range.inside.880 = and i1 %descriptor.owner.offset.valid.878, %descriptor.extent.inside.876
  %descriptor.range.valid.879 = and i1 %descriptor.range.inside.880, %descriptor.payload.inside.877
  br i1 %descriptor.range.valid.879, label %descriptor.valid.881, label %descriptor.invalid.882
descriptor.invalid.882:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.881:
  %descriptor.initialized.status.883 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.867, i32 %local.check.extent.868)
  %helper.ok.884 = icmp eq i32 %descriptor.initialized.status.883, 0
  br i1 %helper.ok.884, label %helper.continue.885, label %frame.failure.0
helper.continue.885:
  br label %local.descriptor.checked.866
local.descriptor.inactive.865:
  br label %local.descriptor.checked.866
local.descriptor.checked.866:
  %local.is.active.886 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.886, label %local.descriptor.active.887, label %local.descriptor.inactive.888
local.descriptor.active.887:
  %local.check.offset.890 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.891 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.892 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.893 = load i32, ptr %local.owner.end.30, align 4
  %context.field.894 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.895 = load i32, ptr %context.field.894, align 4
  %stack.sub.898 = sub i32 %local.check.owner.end.893, %local.check.offset.890
  %descriptor.owner.inside.896 = icmp ule i32 %local.check.owner.end.893, %context.value.895
  %descriptor.offset.inside.897 = icmp ule i32 %local.check.offset.890, %local.check.owner.end.893
  %descriptor.extent.inside.899 = icmp ule i32 %local.check.extent.891, %stack.sub.898
  %descriptor.payload.inside.900 = icmp ule i32 %local.check.payload.892, %local.check.extent.891
  %descriptor.owner.offset.valid.901 = and i1 %descriptor.owner.inside.896, %descriptor.offset.inside.897
  %descriptor.range.inside.903 = and i1 %descriptor.owner.offset.valid.901, %descriptor.extent.inside.899
  %descriptor.range.valid.902 = and i1 %descriptor.range.inside.903, %descriptor.payload.inside.900
  br i1 %descriptor.range.valid.902, label %descriptor.valid.904, label %descriptor.invalid.905
descriptor.invalid.905:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.904:
  %descriptor.initialized.status.906 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.890, i32 %local.check.extent.891)
  %helper.ok.907 = icmp eq i32 %descriptor.initialized.status.906, 0
  br i1 %helper.ok.907, label %helper.continue.908, label %frame.failure.0
helper.continue.908:
  br label %local.descriptor.checked.889
local.descriptor.inactive.888:
  br label %local.descriptor.checked.889
local.descriptor.checked.889:
  %local.is.active.909 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.909, label %local.descriptor.active.910, label %local.descriptor.inactive.911
local.descriptor.active.910:
  %local.check.offset.913 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.914 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.915 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.916 = load i32, ptr %local.owner.end.36, align 4
  %context.field.917 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.918 = load i32, ptr %context.field.917, align 4
  %stack.sub.921 = sub i32 %local.check.owner.end.916, %local.check.offset.913
  %descriptor.owner.inside.919 = icmp ule i32 %local.check.owner.end.916, %context.value.918
  %descriptor.offset.inside.920 = icmp ule i32 %local.check.offset.913, %local.check.owner.end.916
  %descriptor.extent.inside.922 = icmp ule i32 %local.check.extent.914, %stack.sub.921
  %descriptor.payload.inside.923 = icmp ule i32 %local.check.payload.915, %local.check.extent.914
  %descriptor.owner.offset.valid.924 = and i1 %descriptor.owner.inside.919, %descriptor.offset.inside.920
  %descriptor.range.inside.926 = and i1 %descriptor.owner.offset.valid.924, %descriptor.extent.inside.922
  %descriptor.range.valid.925 = and i1 %descriptor.range.inside.926, %descriptor.payload.inside.923
  br i1 %descriptor.range.valid.925, label %descriptor.valid.927, label %descriptor.invalid.928
descriptor.invalid.928:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.927:
  %descriptor.initialized.status.929 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.913, i32 %local.check.extent.914)
  %helper.ok.930 = icmp eq i32 %descriptor.initialized.status.929, 0
  br i1 %helper.ok.930, label %helper.continue.931, label %frame.failure.0
helper.continue.931:
  br label %local.descriptor.checked.912
local.descriptor.inactive.911:
  br label %local.descriptor.checked.912
local.descriptor.checked.912:
  %step.status.932 = call i32 @al_owning_charge_step(ptr %ctx, i32 29)
  %helper.ok.933 = icmp eq i32 %step.status.932, 0
  br i1 %helper.ok.933, label %helper.continue.934, label %frame.failure.0
helper.continue.934:
  %stack.offset.935 = add i32 0, %local.resolved.payload.754
  %stack.offset.936 = add i32 0, %local.resolved.extent.753
  %context.field.937 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.938 = load i32, ptr %context.field.937, align 4
  %stack.offset.939 = add i32 %context.value.938, %stack.offset.936
  %reserve.status.940 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.939, i32 30)
  %reserve.ok.941 = icmp eq i32 %reserve.status.940, 0
  br i1 %reserve.ok.941, label %reserve.continue.942, label %frame.failure.0
reserve.continue.942:
  %stack.offset.943 = add i32 %context.value.938, 0
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.943, i32 %local.resolved.offset.752, i32 %local.resolved.extent.753, i32 %local.resolved.payload.754, i32 1, i32 6)
  %context.field.944 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.945 = load i32, ptr %context.field.944, align 4
  %runtime.ok.946 = icmp eq i32 %context.value.945, 0
  br i1 %runtime.ok.946, label %runtime.continue.947, label %frame.failure.0
runtime.continue.947:
  %stack.offset.948 = add i32 0, %local.resolved.extent.753
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 6, i32 %context.value.938, i32 %stack.offset.936, i32 %stack.offset.935, i32 0, i32 0)
  %context.field.949 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.950 = load i32, ptr %context.field.949, align 4
  %runtime.ok.951 = icmp eq i32 %context.value.950, 0
  br i1 %runtime.ok.951, label %runtime.continue.952, label %frame.failure.0
runtime.continue.952:
  %context.field.953 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.954 = load i32, ptr %context.field.953, align 4
  %stack.sub.957 = sub i32 %stack.offset.939, %context.value.938
  %descriptor.owner.inside.955 = icmp ule i32 %stack.offset.939, %context.value.954
  %descriptor.offset.inside.956 = icmp ule i32 %context.value.938, %stack.offset.939
  %descriptor.extent.inside.958 = icmp ule i32 %stack.offset.936, %stack.sub.957
  %descriptor.payload.inside.959 = icmp ule i32 %stack.offset.935, %stack.offset.936
  %descriptor.owner.offset.valid.960 = and i1 %descriptor.owner.inside.955, %descriptor.offset.inside.956
  %descriptor.range.inside.962 = and i1 %descriptor.owner.offset.valid.960, %descriptor.extent.inside.958
  %descriptor.range.valid.961 = and i1 %descriptor.range.inside.962, %descriptor.payload.inside.959
  %descriptor.type.valid.963 = icmp eq i32 6, 6
  %descriptor.valid.964 = and i1 %descriptor.range.valid.961, %descriptor.type.valid.963
  br i1 %descriptor.valid.964, label %descriptor.valid.965, label %descriptor.invalid.966
descriptor.invalid.966:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.965:
  %descriptor.initialized.status.967 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.938, i32 %stack.offset.936)
  %helper.ok.968 = icmp eq i32 %descriptor.initialized.status.967, 0
  br i1 %helper.ok.968, label %helper.continue.969, label %frame.failure.0
helper.continue.969:
  %local.is.active.970 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.970, label %local.descriptor.active.971, label %local.descriptor.inactive.972
local.descriptor.active.971:
  %local.check.offset.974 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.975 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.976 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.977 = load i32, ptr %local.owner.end.6, align 4
  %context.field.978 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.979 = load i32, ptr %context.field.978, align 4
  %stack.sub.982 = sub i32 %local.check.owner.end.977, %local.check.offset.974
  %descriptor.owner.inside.980 = icmp ule i32 %local.check.owner.end.977, %context.value.979
  %descriptor.offset.inside.981 = icmp ule i32 %local.check.offset.974, %local.check.owner.end.977
  %descriptor.extent.inside.983 = icmp ule i32 %local.check.extent.975, %stack.sub.982
  %descriptor.payload.inside.984 = icmp ule i32 %local.check.payload.976, %local.check.extent.975
  %descriptor.owner.offset.valid.985 = and i1 %descriptor.owner.inside.980, %descriptor.offset.inside.981
  %descriptor.range.inside.987 = and i1 %descriptor.owner.offset.valid.985, %descriptor.extent.inside.983
  %descriptor.range.valid.986 = and i1 %descriptor.range.inside.987, %descriptor.payload.inside.984
  br i1 %descriptor.range.valid.986, label %descriptor.valid.988, label %descriptor.invalid.989
descriptor.invalid.989:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.988:
  %descriptor.initialized.status.990 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.974, i32 %local.check.extent.975)
  %helper.ok.991 = icmp eq i32 %descriptor.initialized.status.990, 0
  br i1 %helper.ok.991, label %helper.continue.992, label %frame.failure.0
helper.continue.992:
  br label %local.descriptor.checked.973
local.descriptor.inactive.972:
  br label %local.descriptor.checked.973
local.descriptor.checked.973:
  %local.is.active.993 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.993, label %local.descriptor.active.994, label %local.descriptor.inactive.995
local.descriptor.active.994:
  %local.check.offset.997 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.998 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.999 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1000 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1001 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1002 = load i32, ptr %context.field.1001, align 4
  %stack.sub.1005 = sub i32 %local.check.owner.end.1000, %local.check.offset.997
  %descriptor.owner.inside.1003 = icmp ule i32 %local.check.owner.end.1000, %context.value.1002
  %descriptor.offset.inside.1004 = icmp ule i32 %local.check.offset.997, %local.check.owner.end.1000
  %descriptor.extent.inside.1006 = icmp ule i32 %local.check.extent.998, %stack.sub.1005
  %descriptor.payload.inside.1007 = icmp ule i32 %local.check.payload.999, %local.check.extent.998
  %descriptor.owner.offset.valid.1008 = and i1 %descriptor.owner.inside.1003, %descriptor.offset.inside.1004
  %descriptor.range.inside.1010 = and i1 %descriptor.owner.offset.valid.1008, %descriptor.extent.inside.1006
  %descriptor.range.valid.1009 = and i1 %descriptor.range.inside.1010, %descriptor.payload.inside.1007
  br i1 %descriptor.range.valid.1009, label %descriptor.valid.1011, label %descriptor.invalid.1012
descriptor.invalid.1012:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1011:
  %descriptor.initialized.status.1013 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.997, i32 %local.check.extent.998)
  %helper.ok.1014 = icmp eq i32 %descriptor.initialized.status.1013, 0
  br i1 %helper.ok.1014, label %helper.continue.1015, label %frame.failure.0
helper.continue.1015:
  br label %local.descriptor.checked.996
local.descriptor.inactive.995:
  br label %local.descriptor.checked.996
local.descriptor.checked.996:
  %local.is.active.1016 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1016, label %local.descriptor.active.1017, label %local.descriptor.inactive.1018
local.descriptor.active.1017:
  %local.check.offset.1020 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1021 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1022 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1023 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1024 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1025 = load i32, ptr %context.field.1024, align 4
  %stack.sub.1028 = sub i32 %local.check.owner.end.1023, %local.check.offset.1020
  %descriptor.owner.inside.1026 = icmp ule i32 %local.check.owner.end.1023, %context.value.1025
  %descriptor.offset.inside.1027 = icmp ule i32 %local.check.offset.1020, %local.check.owner.end.1023
  %descriptor.extent.inside.1029 = icmp ule i32 %local.check.extent.1021, %stack.sub.1028
  %descriptor.payload.inside.1030 = icmp ule i32 %local.check.payload.1022, %local.check.extent.1021
  %descriptor.owner.offset.valid.1031 = and i1 %descriptor.owner.inside.1026, %descriptor.offset.inside.1027
  %descriptor.range.inside.1033 = and i1 %descriptor.owner.offset.valid.1031, %descriptor.extent.inside.1029
  %descriptor.range.valid.1032 = and i1 %descriptor.range.inside.1033, %descriptor.payload.inside.1030
  br i1 %descriptor.range.valid.1032, label %descriptor.valid.1034, label %descriptor.invalid.1035
descriptor.invalid.1035:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1034:
  %descriptor.initialized.status.1036 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1020, i32 %local.check.extent.1021)
  %helper.ok.1037 = icmp eq i32 %descriptor.initialized.status.1036, 0
  br i1 %helper.ok.1037, label %helper.continue.1038, label %frame.failure.0
helper.continue.1038:
  br label %local.descriptor.checked.1019
local.descriptor.inactive.1018:
  br label %local.descriptor.checked.1019
local.descriptor.checked.1019:
  %local.is.active.1039 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1039, label %local.descriptor.active.1040, label %local.descriptor.inactive.1041
local.descriptor.active.1040:
  %local.check.offset.1043 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1044 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1045 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1046 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1047 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1048 = load i32, ptr %context.field.1047, align 4
  %stack.sub.1051 = sub i32 %local.check.owner.end.1046, %local.check.offset.1043
  %descriptor.owner.inside.1049 = icmp ule i32 %local.check.owner.end.1046, %context.value.1048
  %descriptor.offset.inside.1050 = icmp ule i32 %local.check.offset.1043, %local.check.owner.end.1046
  %descriptor.extent.inside.1052 = icmp ule i32 %local.check.extent.1044, %stack.sub.1051
  %descriptor.payload.inside.1053 = icmp ule i32 %local.check.payload.1045, %local.check.extent.1044
  %descriptor.owner.offset.valid.1054 = and i1 %descriptor.owner.inside.1049, %descriptor.offset.inside.1050
  %descriptor.range.inside.1056 = and i1 %descriptor.owner.offset.valid.1054, %descriptor.extent.inside.1052
  %descriptor.range.valid.1055 = and i1 %descriptor.range.inside.1056, %descriptor.payload.inside.1053
  br i1 %descriptor.range.valid.1055, label %descriptor.valid.1057, label %descriptor.invalid.1058
descriptor.invalid.1058:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1057:
  %descriptor.initialized.status.1059 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1043, i32 %local.check.extent.1044)
  %helper.ok.1060 = icmp eq i32 %descriptor.initialized.status.1059, 0
  br i1 %helper.ok.1060, label %helper.continue.1061, label %frame.failure.0
helper.continue.1061:
  br label %local.descriptor.checked.1042
local.descriptor.inactive.1041:
  br label %local.descriptor.checked.1042
local.descriptor.checked.1042:
  %local.is.active.1062 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1062, label %local.descriptor.active.1063, label %local.descriptor.inactive.1064
local.descriptor.active.1063:
  %local.check.offset.1066 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1067 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1068 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1069 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1070 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1071 = load i32, ptr %context.field.1070, align 4
  %stack.sub.1074 = sub i32 %local.check.owner.end.1069, %local.check.offset.1066
  %descriptor.owner.inside.1072 = icmp ule i32 %local.check.owner.end.1069, %context.value.1071
  %descriptor.offset.inside.1073 = icmp ule i32 %local.check.offset.1066, %local.check.owner.end.1069
  %descriptor.extent.inside.1075 = icmp ule i32 %local.check.extent.1067, %stack.sub.1074
  %descriptor.payload.inside.1076 = icmp ule i32 %local.check.payload.1068, %local.check.extent.1067
  %descriptor.owner.offset.valid.1077 = and i1 %descriptor.owner.inside.1072, %descriptor.offset.inside.1073
  %descriptor.range.inside.1079 = and i1 %descriptor.owner.offset.valid.1077, %descriptor.extent.inside.1075
  %descriptor.range.valid.1078 = and i1 %descriptor.range.inside.1079, %descriptor.payload.inside.1076
  br i1 %descriptor.range.valid.1078, label %descriptor.valid.1080, label %descriptor.invalid.1081
descriptor.invalid.1081:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1080:
  %descriptor.initialized.status.1082 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1066, i32 %local.check.extent.1067)
  %helper.ok.1083 = icmp eq i32 %descriptor.initialized.status.1082, 0
  br i1 %helper.ok.1083, label %helper.continue.1084, label %frame.failure.0
helper.continue.1084:
  br label %local.descriptor.checked.1065
local.descriptor.inactive.1064:
  br label %local.descriptor.checked.1065
local.descriptor.checked.1065:
  %local.is.active.1085 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1085, label %local.descriptor.active.1086, label %local.descriptor.inactive.1087
local.descriptor.active.1086:
  %local.check.offset.1089 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1090 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1091 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1092 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1093 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1094 = load i32, ptr %context.field.1093, align 4
  %stack.sub.1097 = sub i32 %local.check.owner.end.1092, %local.check.offset.1089
  %descriptor.owner.inside.1095 = icmp ule i32 %local.check.owner.end.1092, %context.value.1094
  %descriptor.offset.inside.1096 = icmp ule i32 %local.check.offset.1089, %local.check.owner.end.1092
  %descriptor.extent.inside.1098 = icmp ule i32 %local.check.extent.1090, %stack.sub.1097
  %descriptor.payload.inside.1099 = icmp ule i32 %local.check.payload.1091, %local.check.extent.1090
  %descriptor.owner.offset.valid.1100 = and i1 %descriptor.owner.inside.1095, %descriptor.offset.inside.1096
  %descriptor.range.inside.1102 = and i1 %descriptor.owner.offset.valid.1100, %descriptor.extent.inside.1098
  %descriptor.range.valid.1101 = and i1 %descriptor.range.inside.1102, %descriptor.payload.inside.1099
  br i1 %descriptor.range.valid.1101, label %descriptor.valid.1103, label %descriptor.invalid.1104
descriptor.invalid.1104:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1103:
  %descriptor.initialized.status.1105 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1089, i32 %local.check.extent.1090)
  %helper.ok.1106 = icmp eq i32 %descriptor.initialized.status.1105, 0
  br i1 %helper.ok.1106, label %helper.continue.1107, label %frame.failure.0
helper.continue.1107:
  br label %local.descriptor.checked.1088
local.descriptor.inactive.1087:
  br label %local.descriptor.checked.1088
local.descriptor.checked.1088:
  store i1 false, ptr %local.active.20, align 1
  store i32 0, ptr %local.offset.21, align 4
  store i32 0, ptr %local.extent.22, align 4
  store i32 0, ptr %local.payload.23, align 4
  store i32 0, ptr %local.owner.end.24, align 4
  store i32 0, ptr %local.type.25, align 4
  %context.field.1108 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1109 = load i32, ptr %context.field.1108, align 4
  %stack.sub.1112 = sub i32 %stack.offset.939, %context.value.938
  %descriptor.owner.inside.1110 = icmp ule i32 %stack.offset.939, %context.value.1109
  %descriptor.offset.inside.1111 = icmp ule i32 %context.value.938, %stack.offset.939
  %descriptor.extent.inside.1113 = icmp ule i32 %stack.offset.936, %stack.sub.1112
  %descriptor.payload.inside.1114 = icmp ule i32 %stack.offset.935, %stack.offset.936
  %descriptor.owner.offset.valid.1115 = and i1 %descriptor.owner.inside.1110, %descriptor.offset.inside.1111
  %descriptor.range.inside.1117 = and i1 %descriptor.owner.offset.valid.1115, %descriptor.extent.inside.1113
  %descriptor.range.valid.1116 = and i1 %descriptor.range.inside.1117, %descriptor.payload.inside.1114
  %descriptor.type.valid.1118 = icmp eq i32 6, 6
  %descriptor.valid.1119 = and i1 %descriptor.range.valid.1116, %descriptor.type.valid.1118
  br i1 %descriptor.valid.1119, label %descriptor.valid.1120, label %descriptor.invalid.1121
descriptor.invalid.1121:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1120:
  %descriptor.initialized.status.1122 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.938, i32 %stack.offset.936)
  %helper.ok.1123 = icmp eq i32 %descriptor.initialized.status.1122, 0
  br i1 %helper.ok.1123, label %helper.continue.1124, label %frame.failure.0
helper.continue.1124:
  %local.is.active.1125 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1125, label %local.descriptor.active.1126, label %local.descriptor.inactive.1127
local.descriptor.active.1126:
  %local.check.offset.1129 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1130 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1131 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1132 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1133 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1134 = load i32, ptr %context.field.1133, align 4
  %stack.sub.1137 = sub i32 %local.check.owner.end.1132, %local.check.offset.1129
  %descriptor.owner.inside.1135 = icmp ule i32 %local.check.owner.end.1132, %context.value.1134
  %descriptor.offset.inside.1136 = icmp ule i32 %local.check.offset.1129, %local.check.owner.end.1132
  %descriptor.extent.inside.1138 = icmp ule i32 %local.check.extent.1130, %stack.sub.1137
  %descriptor.payload.inside.1139 = icmp ule i32 %local.check.payload.1131, %local.check.extent.1130
  %descriptor.owner.offset.valid.1140 = and i1 %descriptor.owner.inside.1135, %descriptor.offset.inside.1136
  %descriptor.range.inside.1142 = and i1 %descriptor.owner.offset.valid.1140, %descriptor.extent.inside.1138
  %descriptor.range.valid.1141 = and i1 %descriptor.range.inside.1142, %descriptor.payload.inside.1139
  br i1 %descriptor.range.valid.1141, label %descriptor.valid.1143, label %descriptor.invalid.1144
descriptor.invalid.1144:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1143:
  %descriptor.initialized.status.1145 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1129, i32 %local.check.extent.1130)
  %helper.ok.1146 = icmp eq i32 %descriptor.initialized.status.1145, 0
  br i1 %helper.ok.1146, label %helper.continue.1147, label %frame.failure.0
helper.continue.1147:
  br label %local.descriptor.checked.1128
local.descriptor.inactive.1127:
  br label %local.descriptor.checked.1128
local.descriptor.checked.1128:
  %local.is.active.1148 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1148, label %local.descriptor.active.1149, label %local.descriptor.inactive.1150
local.descriptor.active.1149:
  %local.check.offset.1152 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1153 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1154 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1155 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1156 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1157 = load i32, ptr %context.field.1156, align 4
  %stack.sub.1160 = sub i32 %local.check.owner.end.1155, %local.check.offset.1152
  %descriptor.owner.inside.1158 = icmp ule i32 %local.check.owner.end.1155, %context.value.1157
  %descriptor.offset.inside.1159 = icmp ule i32 %local.check.offset.1152, %local.check.owner.end.1155
  %descriptor.extent.inside.1161 = icmp ule i32 %local.check.extent.1153, %stack.sub.1160
  %descriptor.payload.inside.1162 = icmp ule i32 %local.check.payload.1154, %local.check.extent.1153
  %descriptor.owner.offset.valid.1163 = and i1 %descriptor.owner.inside.1158, %descriptor.offset.inside.1159
  %descriptor.range.inside.1165 = and i1 %descriptor.owner.offset.valid.1163, %descriptor.extent.inside.1161
  %descriptor.range.valid.1164 = and i1 %descriptor.range.inside.1165, %descriptor.payload.inside.1162
  br i1 %descriptor.range.valid.1164, label %descriptor.valid.1166, label %descriptor.invalid.1167
descriptor.invalid.1167:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1166:
  %descriptor.initialized.status.1168 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1152, i32 %local.check.extent.1153)
  %helper.ok.1169 = icmp eq i32 %descriptor.initialized.status.1168, 0
  br i1 %helper.ok.1169, label %helper.continue.1170, label %frame.failure.0
helper.continue.1170:
  br label %local.descriptor.checked.1151
local.descriptor.inactive.1150:
  br label %local.descriptor.checked.1151
local.descriptor.checked.1151:
  %local.is.active.1171 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1171, label %local.descriptor.active.1172, label %local.descriptor.inactive.1173
local.descriptor.active.1172:
  %local.check.offset.1175 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1176 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1177 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1178 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1179 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1180 = load i32, ptr %context.field.1179, align 4
  %stack.sub.1183 = sub i32 %local.check.owner.end.1178, %local.check.offset.1175
  %descriptor.owner.inside.1181 = icmp ule i32 %local.check.owner.end.1178, %context.value.1180
  %descriptor.offset.inside.1182 = icmp ule i32 %local.check.offset.1175, %local.check.owner.end.1178
  %descriptor.extent.inside.1184 = icmp ule i32 %local.check.extent.1176, %stack.sub.1183
  %descriptor.payload.inside.1185 = icmp ule i32 %local.check.payload.1177, %local.check.extent.1176
  %descriptor.owner.offset.valid.1186 = and i1 %descriptor.owner.inside.1181, %descriptor.offset.inside.1182
  %descriptor.range.inside.1188 = and i1 %descriptor.owner.offset.valid.1186, %descriptor.extent.inside.1184
  %descriptor.range.valid.1187 = and i1 %descriptor.range.inside.1188, %descriptor.payload.inside.1185
  br i1 %descriptor.range.valid.1187, label %descriptor.valid.1189, label %descriptor.invalid.1190
descriptor.invalid.1190:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1189:
  %descriptor.initialized.status.1191 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1175, i32 %local.check.extent.1176)
  %helper.ok.1192 = icmp eq i32 %descriptor.initialized.status.1191, 0
  br i1 %helper.ok.1192, label %helper.continue.1193, label %frame.failure.0
helper.continue.1193:
  br label %local.descriptor.checked.1174
local.descriptor.inactive.1173:
  br label %local.descriptor.checked.1174
local.descriptor.checked.1174:
  %local.is.active.1194 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1194, label %local.descriptor.active.1195, label %local.descriptor.inactive.1196
local.descriptor.active.1195:
  %local.check.offset.1198 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1199 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1200 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1201 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1202 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1203 = load i32, ptr %context.field.1202, align 4
  %stack.sub.1206 = sub i32 %local.check.owner.end.1201, %local.check.offset.1198
  %descriptor.owner.inside.1204 = icmp ule i32 %local.check.owner.end.1201, %context.value.1203
  %descriptor.offset.inside.1205 = icmp ule i32 %local.check.offset.1198, %local.check.owner.end.1201
  %descriptor.extent.inside.1207 = icmp ule i32 %local.check.extent.1199, %stack.sub.1206
  %descriptor.payload.inside.1208 = icmp ule i32 %local.check.payload.1200, %local.check.extent.1199
  %descriptor.owner.offset.valid.1209 = and i1 %descriptor.owner.inside.1204, %descriptor.offset.inside.1205
  %descriptor.range.inside.1211 = and i1 %descriptor.owner.offset.valid.1209, %descriptor.extent.inside.1207
  %descriptor.range.valid.1210 = and i1 %descriptor.range.inside.1211, %descriptor.payload.inside.1208
  br i1 %descriptor.range.valid.1210, label %descriptor.valid.1212, label %descriptor.invalid.1213
descriptor.invalid.1213:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1212:
  %descriptor.initialized.status.1214 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1198, i32 %local.check.extent.1199)
  %helper.ok.1215 = icmp eq i32 %descriptor.initialized.status.1214, 0
  br i1 %helper.ok.1215, label %helper.continue.1216, label %frame.failure.0
helper.continue.1216:
  br label %local.descriptor.checked.1197
local.descriptor.inactive.1196:
  br label %local.descriptor.checked.1197
local.descriptor.checked.1197:
  %local.is.active.1217 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1217, label %local.descriptor.active.1218, label %local.descriptor.inactive.1219
local.descriptor.active.1218:
  %local.check.offset.1221 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1222 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1223 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1224 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1225 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1226 = load i32, ptr %context.field.1225, align 4
  %stack.sub.1229 = sub i32 %local.check.owner.end.1224, %local.check.offset.1221
  %descriptor.owner.inside.1227 = icmp ule i32 %local.check.owner.end.1224, %context.value.1226
  %descriptor.offset.inside.1228 = icmp ule i32 %local.check.offset.1221, %local.check.owner.end.1224
  %descriptor.extent.inside.1230 = icmp ule i32 %local.check.extent.1222, %stack.sub.1229
  %descriptor.payload.inside.1231 = icmp ule i32 %local.check.payload.1223, %local.check.extent.1222
  %descriptor.owner.offset.valid.1232 = and i1 %descriptor.owner.inside.1227, %descriptor.offset.inside.1228
  %descriptor.range.inside.1234 = and i1 %descriptor.owner.offset.valid.1232, %descriptor.extent.inside.1230
  %descriptor.range.valid.1233 = and i1 %descriptor.range.inside.1234, %descriptor.payload.inside.1231
  br i1 %descriptor.range.valid.1233, label %descriptor.valid.1235, label %descriptor.invalid.1236
descriptor.invalid.1236:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1235:
  %descriptor.initialized.status.1237 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1221, i32 %local.check.extent.1222)
  %helper.ok.1238 = icmp eq i32 %descriptor.initialized.status.1237, 0
  br i1 %helper.ok.1238, label %helper.continue.1239, label %frame.failure.0
helper.continue.1239:
  br label %local.descriptor.checked.1220
local.descriptor.inactive.1219:
  br label %local.descriptor.checked.1220
local.descriptor.checked.1220:
  %local.is.active.1240 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1240, label %local.descriptor.active.1241, label %local.descriptor.inactive.1242
local.descriptor.active.1241:
  %local.check.offset.1244 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1245 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1246 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1247 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1248 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1249 = load i32, ptr %context.field.1248, align 4
  %stack.sub.1252 = sub i32 %local.check.owner.end.1247, %local.check.offset.1244
  %descriptor.owner.inside.1250 = icmp ule i32 %local.check.owner.end.1247, %context.value.1249
  %descriptor.offset.inside.1251 = icmp ule i32 %local.check.offset.1244, %local.check.owner.end.1247
  %descriptor.extent.inside.1253 = icmp ule i32 %local.check.extent.1245, %stack.sub.1252
  %descriptor.payload.inside.1254 = icmp ule i32 %local.check.payload.1246, %local.check.extent.1245
  %descriptor.owner.offset.valid.1255 = and i1 %descriptor.owner.inside.1250, %descriptor.offset.inside.1251
  %descriptor.range.inside.1257 = and i1 %descriptor.owner.offset.valid.1255, %descriptor.extent.inside.1253
  %descriptor.range.valid.1256 = and i1 %descriptor.range.inside.1257, %descriptor.payload.inside.1254
  br i1 %descriptor.range.valid.1256, label %descriptor.valid.1258, label %descriptor.invalid.1259
descriptor.invalid.1259:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1258:
  %descriptor.initialized.status.1260 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1244, i32 %local.check.extent.1245)
  %helper.ok.1261 = icmp eq i32 %descriptor.initialized.status.1260, 0
  br i1 %helper.ok.1261, label %helper.continue.1262, label %frame.failure.0
helper.continue.1262:
  br label %local.descriptor.checked.1243
local.descriptor.inactive.1242:
  br label %local.descriptor.checked.1243
local.descriptor.checked.1243:
  %step.status.1263 = call i32 @al_owning_charge_step(ptr %ctx, i32 31)
  %helper.ok.1264 = icmp eq i32 %step.status.1263, 0
  br i1 %helper.ok.1264, label %helper.continue.1265, label %frame.failure.0
helper.continue.1265:
  store i1 true, ptr %local.active.14, align 1
  store i32 %context.value.938, ptr %local.offset.15, align 4
  store i32 %stack.offset.936, ptr %local.extent.16, align 4
  store i32 %stack.offset.935, ptr %local.payload.17, align 4
  store i32 %stack.offset.939, ptr %local.owner.end.18, align 4
  store i32 6, ptr %local.type.19, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %context.value.938, i32 20, i32 %stack.offset.935, i32 %stack.offset.939, i32 %stack.offset.936)
  %context.field.1266 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1267 = load i32, ptr %context.field.1266, align 4
  %runtime.ok.1268 = icmp eq i32 %context.value.1267, 0
  br i1 %runtime.ok.1268, label %runtime.continue.1269, label %frame.failure.0
runtime.continue.1269:
  %local.is.active.1270 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1270, label %local.descriptor.active.1271, label %local.descriptor.inactive.1272
local.descriptor.active.1271:
  %local.check.offset.1274 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1275 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1276 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1277 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1278 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1279 = load i32, ptr %context.field.1278, align 4
  %stack.sub.1282 = sub i32 %local.check.owner.end.1277, %local.check.offset.1274
  %descriptor.owner.inside.1280 = icmp ule i32 %local.check.owner.end.1277, %context.value.1279
  %descriptor.offset.inside.1281 = icmp ule i32 %local.check.offset.1274, %local.check.owner.end.1277
  %descriptor.extent.inside.1283 = icmp ule i32 %local.check.extent.1275, %stack.sub.1282
  %descriptor.payload.inside.1284 = icmp ule i32 %local.check.payload.1276, %local.check.extent.1275
  %descriptor.owner.offset.valid.1285 = and i1 %descriptor.owner.inside.1280, %descriptor.offset.inside.1281
  %descriptor.range.inside.1287 = and i1 %descriptor.owner.offset.valid.1285, %descriptor.extent.inside.1283
  %descriptor.range.valid.1286 = and i1 %descriptor.range.inside.1287, %descriptor.payload.inside.1284
  br i1 %descriptor.range.valid.1286, label %descriptor.valid.1288, label %descriptor.invalid.1289
descriptor.invalid.1289:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1288:
  %descriptor.initialized.status.1290 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1274, i32 %local.check.extent.1275)
  %helper.ok.1291 = icmp eq i32 %descriptor.initialized.status.1290, 0
  br i1 %helper.ok.1291, label %helper.continue.1292, label %frame.failure.0
helper.continue.1292:
  br label %local.descriptor.checked.1273
local.descriptor.inactive.1272:
  br label %local.descriptor.checked.1273
local.descriptor.checked.1273:
  %local.is.active.1293 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1293, label %local.descriptor.active.1294, label %local.descriptor.inactive.1295
local.descriptor.active.1294:
  %local.check.offset.1297 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1298 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1299 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1300 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1301 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1302 = load i32, ptr %context.field.1301, align 4
  %stack.sub.1305 = sub i32 %local.check.owner.end.1300, %local.check.offset.1297
  %descriptor.owner.inside.1303 = icmp ule i32 %local.check.owner.end.1300, %context.value.1302
  %descriptor.offset.inside.1304 = icmp ule i32 %local.check.offset.1297, %local.check.owner.end.1300
  %descriptor.extent.inside.1306 = icmp ule i32 %local.check.extent.1298, %stack.sub.1305
  %descriptor.payload.inside.1307 = icmp ule i32 %local.check.payload.1299, %local.check.extent.1298
  %descriptor.owner.offset.valid.1308 = and i1 %descriptor.owner.inside.1303, %descriptor.offset.inside.1304
  %descriptor.range.inside.1310 = and i1 %descriptor.owner.offset.valid.1308, %descriptor.extent.inside.1306
  %descriptor.range.valid.1309 = and i1 %descriptor.range.inside.1310, %descriptor.payload.inside.1307
  br i1 %descriptor.range.valid.1309, label %descriptor.valid.1311, label %descriptor.invalid.1312
descriptor.invalid.1312:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1311:
  %descriptor.initialized.status.1313 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1297, i32 %local.check.extent.1298)
  %helper.ok.1314 = icmp eq i32 %descriptor.initialized.status.1313, 0
  br i1 %helper.ok.1314, label %helper.continue.1315, label %frame.failure.0
helper.continue.1315:
  br label %local.descriptor.checked.1296
local.descriptor.inactive.1295:
  br label %local.descriptor.checked.1296
local.descriptor.checked.1296:
  %local.is.active.1316 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1316, label %local.descriptor.active.1317, label %local.descriptor.inactive.1318
local.descriptor.active.1317:
  %local.check.offset.1320 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1321 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1322 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1323 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1324 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1325 = load i32, ptr %context.field.1324, align 4
  %stack.sub.1328 = sub i32 %local.check.owner.end.1323, %local.check.offset.1320
  %descriptor.owner.inside.1326 = icmp ule i32 %local.check.owner.end.1323, %context.value.1325
  %descriptor.offset.inside.1327 = icmp ule i32 %local.check.offset.1320, %local.check.owner.end.1323
  %descriptor.extent.inside.1329 = icmp ule i32 %local.check.extent.1321, %stack.sub.1328
  %descriptor.payload.inside.1330 = icmp ule i32 %local.check.payload.1322, %local.check.extent.1321
  %descriptor.owner.offset.valid.1331 = and i1 %descriptor.owner.inside.1326, %descriptor.offset.inside.1327
  %descriptor.range.inside.1333 = and i1 %descriptor.owner.offset.valid.1331, %descriptor.extent.inside.1329
  %descriptor.range.valid.1332 = and i1 %descriptor.range.inside.1333, %descriptor.payload.inside.1330
  br i1 %descriptor.range.valid.1332, label %descriptor.valid.1334, label %descriptor.invalid.1335
descriptor.invalid.1335:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1334:
  %descriptor.initialized.status.1336 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1320, i32 %local.check.extent.1321)
  %helper.ok.1337 = icmp eq i32 %descriptor.initialized.status.1336, 0
  br i1 %helper.ok.1337, label %helper.continue.1338, label %frame.failure.0
helper.continue.1338:
  br label %local.descriptor.checked.1319
local.descriptor.inactive.1318:
  br label %local.descriptor.checked.1319
local.descriptor.checked.1319:
  %local.is.active.1339 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1339, label %local.descriptor.active.1340, label %local.descriptor.inactive.1341
local.descriptor.active.1340:
  %local.check.offset.1343 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1344 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1345 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1346 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1347 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1348 = load i32, ptr %context.field.1347, align 4
  %stack.sub.1351 = sub i32 %local.check.owner.end.1346, %local.check.offset.1343
  %descriptor.owner.inside.1349 = icmp ule i32 %local.check.owner.end.1346, %context.value.1348
  %descriptor.offset.inside.1350 = icmp ule i32 %local.check.offset.1343, %local.check.owner.end.1346
  %descriptor.extent.inside.1352 = icmp ule i32 %local.check.extent.1344, %stack.sub.1351
  %descriptor.payload.inside.1353 = icmp ule i32 %local.check.payload.1345, %local.check.extent.1344
  %descriptor.owner.offset.valid.1354 = and i1 %descriptor.owner.inside.1349, %descriptor.offset.inside.1350
  %descriptor.range.inside.1356 = and i1 %descriptor.owner.offset.valid.1354, %descriptor.extent.inside.1352
  %descriptor.range.valid.1355 = and i1 %descriptor.range.inside.1356, %descriptor.payload.inside.1353
  br i1 %descriptor.range.valid.1355, label %descriptor.valid.1357, label %descriptor.invalid.1358
descriptor.invalid.1358:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1357:
  %descriptor.initialized.status.1359 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1343, i32 %local.check.extent.1344)
  %helper.ok.1360 = icmp eq i32 %descriptor.initialized.status.1359, 0
  br i1 %helper.ok.1360, label %helper.continue.1361, label %frame.failure.0
helper.continue.1361:
  br label %local.descriptor.checked.1342
local.descriptor.inactive.1341:
  br label %local.descriptor.checked.1342
local.descriptor.checked.1342:
  %local.is.active.1362 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1362, label %local.descriptor.active.1363, label %local.descriptor.inactive.1364
local.descriptor.active.1363:
  %local.check.offset.1366 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1367 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1368 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1369 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1370 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1371 = load i32, ptr %context.field.1370, align 4
  %stack.sub.1374 = sub i32 %local.check.owner.end.1369, %local.check.offset.1366
  %descriptor.owner.inside.1372 = icmp ule i32 %local.check.owner.end.1369, %context.value.1371
  %descriptor.offset.inside.1373 = icmp ule i32 %local.check.offset.1366, %local.check.owner.end.1369
  %descriptor.extent.inside.1375 = icmp ule i32 %local.check.extent.1367, %stack.sub.1374
  %descriptor.payload.inside.1376 = icmp ule i32 %local.check.payload.1368, %local.check.extent.1367
  %descriptor.owner.offset.valid.1377 = and i1 %descriptor.owner.inside.1372, %descriptor.offset.inside.1373
  %descriptor.range.inside.1379 = and i1 %descriptor.owner.offset.valid.1377, %descriptor.extent.inside.1375
  %descriptor.range.valid.1378 = and i1 %descriptor.range.inside.1379, %descriptor.payload.inside.1376
  br i1 %descriptor.range.valid.1378, label %descriptor.valid.1380, label %descriptor.invalid.1381
descriptor.invalid.1381:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1380:
  %descriptor.initialized.status.1382 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1366, i32 %local.check.extent.1367)
  %helper.ok.1383 = icmp eq i32 %descriptor.initialized.status.1382, 0
  br i1 %helper.ok.1383, label %helper.continue.1384, label %frame.failure.0
helper.continue.1384:
  br label %local.descriptor.checked.1365
local.descriptor.inactive.1364:
  br label %local.descriptor.checked.1365
local.descriptor.checked.1365:
  %local.is.active.1385 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1385, label %local.descriptor.active.1386, label %local.descriptor.inactive.1387
local.descriptor.active.1386:
  %local.check.offset.1389 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1390 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1391 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1392 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1393 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1394 = load i32, ptr %context.field.1393, align 4
  %stack.sub.1397 = sub i32 %local.check.owner.end.1392, %local.check.offset.1389
  %descriptor.owner.inside.1395 = icmp ule i32 %local.check.owner.end.1392, %context.value.1394
  %descriptor.offset.inside.1396 = icmp ule i32 %local.check.offset.1389, %local.check.owner.end.1392
  %descriptor.extent.inside.1398 = icmp ule i32 %local.check.extent.1390, %stack.sub.1397
  %descriptor.payload.inside.1399 = icmp ule i32 %local.check.payload.1391, %local.check.extent.1390
  %descriptor.owner.offset.valid.1400 = and i1 %descriptor.owner.inside.1395, %descriptor.offset.inside.1396
  %descriptor.range.inside.1402 = and i1 %descriptor.owner.offset.valid.1400, %descriptor.extent.inside.1398
  %descriptor.range.valid.1401 = and i1 %descriptor.range.inside.1402, %descriptor.payload.inside.1399
  br i1 %descriptor.range.valid.1401, label %descriptor.valid.1403, label %descriptor.invalid.1404
descriptor.invalid.1404:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1403:
  %descriptor.initialized.status.1405 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1389, i32 %local.check.extent.1390)
  %helper.ok.1406 = icmp eq i32 %descriptor.initialized.status.1405, 0
  br i1 %helper.ok.1406, label %helper.continue.1407, label %frame.failure.0
helper.continue.1407:
  br label %local.descriptor.checked.1388
local.descriptor.inactive.1387:
  br label %local.descriptor.checked.1388
local.descriptor.checked.1388:
  %step.status.1408 = call i32 @al_owning_charge_step(ptr %ctx, i32 32)
  %helper.ok.1409 = icmp eq i32 %step.status.1408, 0
  br i1 %helper.ok.1409, label %helper.continue.1410, label %frame.failure.0
helper.continue.1410:
  %context.field.1411 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1412 = load i32, ptr %context.field.1411, align 4
  store i1 false, ptr %local.active.26, align 1
  store i32 0, ptr %local.offset.27, align 4
  store i32 0, ptr %local.extent.28, align 4
  store i32 0, ptr %local.payload.29, align 4
  store i32 0, ptr %local.owner.end.30, align 4
  store i32 0, ptr %local.type.31, align 4
  store i1 false, ptr %local.active.32, align 1
  store i32 0, ptr %local.offset.33, align 4
  store i32 0, ptr %local.extent.34, align 4
  store i32 0, ptr %local.payload.35, align 4
  store i32 0, ptr %local.owner.end.36, align 4
  store i32 0, ptr %local.type.37, align 4
  %step.status.1413 = call i32 @al_owning_charge_step(ptr %ctx, i32 33)
  %helper.ok.1414 = icmp eq i32 %step.status.1413, 0
  br i1 %helper.ok.1414, label %helper.continue.1415, label %frame.failure.0
helper.continue.1415:
  %local.resolved.offset.1416 = load i32, ptr %local.offset.15, align 4
  %local.resolved.extent.1417 = load i32, ptr %local.extent.16, align 4
  %local.resolved.payload.1418 = load i32, ptr %local.payload.17, align 4
  %local.resolved.owner.end.1419 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1420 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1421 = load i32, ptr %context.field.1420, align 4
  %stack.sub.1424 = sub i32 %local.resolved.owner.end.1419, %local.resolved.offset.1416
  %descriptor.owner.inside.1422 = icmp ule i32 %local.resolved.owner.end.1419, %context.value.1421
  %descriptor.offset.inside.1423 = icmp ule i32 %local.resolved.offset.1416, %local.resolved.owner.end.1419
  %descriptor.extent.inside.1425 = icmp ule i32 %local.resolved.extent.1417, %stack.sub.1424
  %descriptor.payload.inside.1426 = icmp ule i32 %local.resolved.payload.1418, %local.resolved.extent.1417
  %descriptor.owner.offset.valid.1427 = and i1 %descriptor.owner.inside.1422, %descriptor.offset.inside.1423
  %descriptor.range.inside.1429 = and i1 %descriptor.owner.offset.valid.1427, %descriptor.extent.inside.1425
  %descriptor.range.valid.1428 = and i1 %descriptor.range.inside.1429, %descriptor.payload.inside.1426
  %descriptor.type.valid.1430 = icmp eq i32 6, 6
  %descriptor.valid.1431 = and i1 %descriptor.range.valid.1428, %descriptor.type.valid.1430
  br i1 %descriptor.valid.1431, label %descriptor.valid.1432, label %descriptor.invalid.1433
descriptor.invalid.1433:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1432:
  %descriptor.initialized.status.1434 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1416, i32 %local.resolved.extent.1417)
  %helper.ok.1435 = icmp eq i32 %descriptor.initialized.status.1434, 0
  br i1 %helper.ok.1435, label %helper.continue.1436, label %frame.failure.0
helper.continue.1436:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %local.resolved.offset.1416, i32 20, i32 %local.resolved.payload.1418, i32 %local.resolved.owner.end.1419, i32 %local.resolved.extent.1417)
  %context.field.1437 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1438 = load i32, ptr %context.field.1437, align 4
  %runtime.ok.1439 = icmp eq i32 %context.value.1438, 0
  br i1 %runtime.ok.1439, label %runtime.continue.1440, label %frame.failure.0
runtime.continue.1440:
  %context.field.1441 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1442 = load i32, ptr %context.field.1441, align 4
  %stack.sub.1445 = sub i32 %local.resolved.owner.end.1419, %local.resolved.offset.1416
  %descriptor.owner.inside.1443 = icmp ule i32 %local.resolved.owner.end.1419, %context.value.1442
  %descriptor.offset.inside.1444 = icmp ule i32 %local.resolved.offset.1416, %local.resolved.owner.end.1419
  %descriptor.extent.inside.1446 = icmp ule i32 %local.resolved.extent.1417, %stack.sub.1445
  %descriptor.payload.inside.1447 = icmp ule i32 %local.resolved.payload.1418, %local.resolved.extent.1417
  %descriptor.owner.offset.valid.1448 = and i1 %descriptor.owner.inside.1443, %descriptor.offset.inside.1444
  %descriptor.range.inside.1450 = and i1 %descriptor.owner.offset.valid.1448, %descriptor.extent.inside.1446
  %descriptor.range.valid.1449 = and i1 %descriptor.range.inside.1450, %descriptor.payload.inside.1447
  %descriptor.type.valid.1451 = icmp eq i32 6, 6
  %descriptor.valid.1452 = and i1 %descriptor.range.valid.1449, %descriptor.type.valid.1451
  br i1 %descriptor.valid.1452, label %descriptor.valid.1453, label %descriptor.invalid.1454
descriptor.invalid.1454:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1453:
  %descriptor.initialized.status.1455 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1416, i32 %local.resolved.extent.1417)
  %helper.ok.1456 = icmp eq i32 %descriptor.initialized.status.1455, 0
  br i1 %helper.ok.1456, label %helper.continue.1457, label %frame.failure.0
helper.continue.1457:
  %local.is.active.1458 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1458, label %local.descriptor.active.1459, label %local.descriptor.inactive.1460
local.descriptor.active.1459:
  %local.check.offset.1462 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1463 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1464 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1465 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1466 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1467 = load i32, ptr %context.field.1466, align 4
  %stack.sub.1470 = sub i32 %local.check.owner.end.1465, %local.check.offset.1462
  %descriptor.owner.inside.1468 = icmp ule i32 %local.check.owner.end.1465, %context.value.1467
  %descriptor.offset.inside.1469 = icmp ule i32 %local.check.offset.1462, %local.check.owner.end.1465
  %descriptor.extent.inside.1471 = icmp ule i32 %local.check.extent.1463, %stack.sub.1470
  %descriptor.payload.inside.1472 = icmp ule i32 %local.check.payload.1464, %local.check.extent.1463
  %descriptor.owner.offset.valid.1473 = and i1 %descriptor.owner.inside.1468, %descriptor.offset.inside.1469
  %descriptor.range.inside.1475 = and i1 %descriptor.owner.offset.valid.1473, %descriptor.extent.inside.1471
  %descriptor.range.valid.1474 = and i1 %descriptor.range.inside.1475, %descriptor.payload.inside.1472
  br i1 %descriptor.range.valid.1474, label %descriptor.valid.1476, label %descriptor.invalid.1477
descriptor.invalid.1477:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1476:
  %descriptor.initialized.status.1478 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1462, i32 %local.check.extent.1463)
  %helper.ok.1479 = icmp eq i32 %descriptor.initialized.status.1478, 0
  br i1 %helper.ok.1479, label %helper.continue.1480, label %frame.failure.0
helper.continue.1480:
  br label %local.descriptor.checked.1461
local.descriptor.inactive.1460:
  br label %local.descriptor.checked.1461
local.descriptor.checked.1461:
  %local.is.active.1481 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1481, label %local.descriptor.active.1482, label %local.descriptor.inactive.1483
local.descriptor.active.1482:
  %local.check.offset.1485 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1486 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1487 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1488 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1489 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1490 = load i32, ptr %context.field.1489, align 4
  %stack.sub.1493 = sub i32 %local.check.owner.end.1488, %local.check.offset.1485
  %descriptor.owner.inside.1491 = icmp ule i32 %local.check.owner.end.1488, %context.value.1490
  %descriptor.offset.inside.1492 = icmp ule i32 %local.check.offset.1485, %local.check.owner.end.1488
  %descriptor.extent.inside.1494 = icmp ule i32 %local.check.extent.1486, %stack.sub.1493
  %descriptor.payload.inside.1495 = icmp ule i32 %local.check.payload.1487, %local.check.extent.1486
  %descriptor.owner.offset.valid.1496 = and i1 %descriptor.owner.inside.1491, %descriptor.offset.inside.1492
  %descriptor.range.inside.1498 = and i1 %descriptor.owner.offset.valid.1496, %descriptor.extent.inside.1494
  %descriptor.range.valid.1497 = and i1 %descriptor.range.inside.1498, %descriptor.payload.inside.1495
  br i1 %descriptor.range.valid.1497, label %descriptor.valid.1499, label %descriptor.invalid.1500
descriptor.invalid.1500:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1499:
  %descriptor.initialized.status.1501 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1485, i32 %local.check.extent.1486)
  %helper.ok.1502 = icmp eq i32 %descriptor.initialized.status.1501, 0
  br i1 %helper.ok.1502, label %helper.continue.1503, label %frame.failure.0
helper.continue.1503:
  br label %local.descriptor.checked.1484
local.descriptor.inactive.1483:
  br label %local.descriptor.checked.1484
local.descriptor.checked.1484:
  %local.is.active.1504 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1504, label %local.descriptor.active.1505, label %local.descriptor.inactive.1506
local.descriptor.active.1505:
  %local.check.offset.1508 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1509 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1510 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1511 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1512 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1513 = load i32, ptr %context.field.1512, align 4
  %stack.sub.1516 = sub i32 %local.check.owner.end.1511, %local.check.offset.1508
  %descriptor.owner.inside.1514 = icmp ule i32 %local.check.owner.end.1511, %context.value.1513
  %descriptor.offset.inside.1515 = icmp ule i32 %local.check.offset.1508, %local.check.owner.end.1511
  %descriptor.extent.inside.1517 = icmp ule i32 %local.check.extent.1509, %stack.sub.1516
  %descriptor.payload.inside.1518 = icmp ule i32 %local.check.payload.1510, %local.check.extent.1509
  %descriptor.owner.offset.valid.1519 = and i1 %descriptor.owner.inside.1514, %descriptor.offset.inside.1515
  %descriptor.range.inside.1521 = and i1 %descriptor.owner.offset.valid.1519, %descriptor.extent.inside.1517
  %descriptor.range.valid.1520 = and i1 %descriptor.range.inside.1521, %descriptor.payload.inside.1518
  br i1 %descriptor.range.valid.1520, label %descriptor.valid.1522, label %descriptor.invalid.1523
descriptor.invalid.1523:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1522:
  %descriptor.initialized.status.1524 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1508, i32 %local.check.extent.1509)
  %helper.ok.1525 = icmp eq i32 %descriptor.initialized.status.1524, 0
  br i1 %helper.ok.1525, label %helper.continue.1526, label %frame.failure.0
helper.continue.1526:
  br label %local.descriptor.checked.1507
local.descriptor.inactive.1506:
  br label %local.descriptor.checked.1507
local.descriptor.checked.1507:
  %local.is.active.1527 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1527, label %local.descriptor.active.1528, label %local.descriptor.inactive.1529
local.descriptor.active.1528:
  %local.check.offset.1531 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1532 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1533 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1534 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1535 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1536 = load i32, ptr %context.field.1535, align 4
  %stack.sub.1539 = sub i32 %local.check.owner.end.1534, %local.check.offset.1531
  %descriptor.owner.inside.1537 = icmp ule i32 %local.check.owner.end.1534, %context.value.1536
  %descriptor.offset.inside.1538 = icmp ule i32 %local.check.offset.1531, %local.check.owner.end.1534
  %descriptor.extent.inside.1540 = icmp ule i32 %local.check.extent.1532, %stack.sub.1539
  %descriptor.payload.inside.1541 = icmp ule i32 %local.check.payload.1533, %local.check.extent.1532
  %descriptor.owner.offset.valid.1542 = and i1 %descriptor.owner.inside.1537, %descriptor.offset.inside.1538
  %descriptor.range.inside.1544 = and i1 %descriptor.owner.offset.valid.1542, %descriptor.extent.inside.1540
  %descriptor.range.valid.1543 = and i1 %descriptor.range.inside.1544, %descriptor.payload.inside.1541
  br i1 %descriptor.range.valid.1543, label %descriptor.valid.1545, label %descriptor.invalid.1546
descriptor.invalid.1546:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1545:
  %descriptor.initialized.status.1547 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1531, i32 %local.check.extent.1532)
  %helper.ok.1548 = icmp eq i32 %descriptor.initialized.status.1547, 0
  br i1 %helper.ok.1548, label %helper.continue.1549, label %frame.failure.0
helper.continue.1549:
  br label %local.descriptor.checked.1530
local.descriptor.inactive.1529:
  br label %local.descriptor.checked.1530
local.descriptor.checked.1530:
  %local.is.active.1550 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1550, label %local.descriptor.active.1551, label %local.descriptor.inactive.1552
local.descriptor.active.1551:
  %local.check.offset.1554 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1555 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1556 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1557 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1558 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1559 = load i32, ptr %context.field.1558, align 4
  %stack.sub.1562 = sub i32 %local.check.owner.end.1557, %local.check.offset.1554
  %descriptor.owner.inside.1560 = icmp ule i32 %local.check.owner.end.1557, %context.value.1559
  %descriptor.offset.inside.1561 = icmp ule i32 %local.check.offset.1554, %local.check.owner.end.1557
  %descriptor.extent.inside.1563 = icmp ule i32 %local.check.extent.1555, %stack.sub.1562
  %descriptor.payload.inside.1564 = icmp ule i32 %local.check.payload.1556, %local.check.extent.1555
  %descriptor.owner.offset.valid.1565 = and i1 %descriptor.owner.inside.1560, %descriptor.offset.inside.1561
  %descriptor.range.inside.1567 = and i1 %descriptor.owner.offset.valid.1565, %descriptor.extent.inside.1563
  %descriptor.range.valid.1566 = and i1 %descriptor.range.inside.1567, %descriptor.payload.inside.1564
  br i1 %descriptor.range.valid.1566, label %descriptor.valid.1568, label %descriptor.invalid.1569
descriptor.invalid.1569:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1568:
  %descriptor.initialized.status.1570 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1554, i32 %local.check.extent.1555)
  %helper.ok.1571 = icmp eq i32 %descriptor.initialized.status.1570, 0
  br i1 %helper.ok.1571, label %helper.continue.1572, label %frame.failure.0
helper.continue.1572:
  br label %local.descriptor.checked.1553
local.descriptor.inactive.1552:
  br label %local.descriptor.checked.1553
local.descriptor.checked.1553:
  %local.is.active.1573 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1573, label %local.descriptor.active.1574, label %local.descriptor.inactive.1575
local.descriptor.active.1574:
  %local.check.offset.1577 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1578 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1579 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1580 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1581 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1582 = load i32, ptr %context.field.1581, align 4
  %stack.sub.1585 = sub i32 %local.check.owner.end.1580, %local.check.offset.1577
  %descriptor.owner.inside.1583 = icmp ule i32 %local.check.owner.end.1580, %context.value.1582
  %descriptor.offset.inside.1584 = icmp ule i32 %local.check.offset.1577, %local.check.owner.end.1580
  %descriptor.extent.inside.1586 = icmp ule i32 %local.check.extent.1578, %stack.sub.1585
  %descriptor.payload.inside.1587 = icmp ule i32 %local.check.payload.1579, %local.check.extent.1578
  %descriptor.owner.offset.valid.1588 = and i1 %descriptor.owner.inside.1583, %descriptor.offset.inside.1584
  %descriptor.range.inside.1590 = and i1 %descriptor.owner.offset.valid.1588, %descriptor.extent.inside.1586
  %descriptor.range.valid.1589 = and i1 %descriptor.range.inside.1590, %descriptor.payload.inside.1587
  br i1 %descriptor.range.valid.1589, label %descriptor.valid.1591, label %descriptor.invalid.1592
descriptor.invalid.1592:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1591:
  %descriptor.initialized.status.1593 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1577, i32 %local.check.extent.1578)
  %helper.ok.1594 = icmp eq i32 %descriptor.initialized.status.1593, 0
  br i1 %helper.ok.1594, label %helper.continue.1595, label %frame.failure.0
helper.continue.1595:
  br label %local.descriptor.checked.1576
local.descriptor.inactive.1575:
  br label %local.descriptor.checked.1576
local.descriptor.checked.1576:
  %step.status.1596 = call i32 @al_owning_charge_step(ptr %ctx, i32 34)
  %helper.ok.1597 = icmp eq i32 %step.status.1596, 0
  br i1 %helper.ok.1597, label %helper.continue.1598, label %frame.failure.0
helper.continue.1598:
  store i1 true, ptr %local.active.26, align 1
  store i32 %local.resolved.offset.1416, ptr %local.offset.27, align 4
  store i32 %local.resolved.extent.1417, ptr %local.extent.28, align 4
  store i32 %local.resolved.payload.1418, ptr %local.payload.29, align 4
  store i32 %local.resolved.owner.end.1419, ptr %local.owner.end.30, align 4
  store i32 6, ptr %local.type.31, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %local.resolved.offset.1416, i32 20, i32 %local.resolved.payload.1418, i32 %local.resolved.owner.end.1419, i32 %local.resolved.extent.1417)
  %context.field.1599 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1600 = load i32, ptr %context.field.1599, align 4
  %runtime.ok.1601 = icmp eq i32 %context.value.1600, 0
  br i1 %runtime.ok.1601, label %runtime.continue.1602, label %frame.failure.0
runtime.continue.1602:
  %local.is.active.1603 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1603, label %local.descriptor.active.1604, label %local.descriptor.inactive.1605
local.descriptor.active.1604:
  %local.check.offset.1607 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1608 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1609 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1610 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1611 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1612 = load i32, ptr %context.field.1611, align 4
  %stack.sub.1615 = sub i32 %local.check.owner.end.1610, %local.check.offset.1607
  %descriptor.owner.inside.1613 = icmp ule i32 %local.check.owner.end.1610, %context.value.1612
  %descriptor.offset.inside.1614 = icmp ule i32 %local.check.offset.1607, %local.check.owner.end.1610
  %descriptor.extent.inside.1616 = icmp ule i32 %local.check.extent.1608, %stack.sub.1615
  %descriptor.payload.inside.1617 = icmp ule i32 %local.check.payload.1609, %local.check.extent.1608
  %descriptor.owner.offset.valid.1618 = and i1 %descriptor.owner.inside.1613, %descriptor.offset.inside.1614
  %descriptor.range.inside.1620 = and i1 %descriptor.owner.offset.valid.1618, %descriptor.extent.inside.1616
  %descriptor.range.valid.1619 = and i1 %descriptor.range.inside.1620, %descriptor.payload.inside.1617
  br i1 %descriptor.range.valid.1619, label %descriptor.valid.1621, label %descriptor.invalid.1622
descriptor.invalid.1622:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1621:
  %descriptor.initialized.status.1623 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1607, i32 %local.check.extent.1608)
  %helper.ok.1624 = icmp eq i32 %descriptor.initialized.status.1623, 0
  br i1 %helper.ok.1624, label %helper.continue.1625, label %frame.failure.0
helper.continue.1625:
  br label %local.descriptor.checked.1606
local.descriptor.inactive.1605:
  br label %local.descriptor.checked.1606
local.descriptor.checked.1606:
  %local.is.active.1626 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1626, label %local.descriptor.active.1627, label %local.descriptor.inactive.1628
local.descriptor.active.1627:
  %local.check.offset.1630 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1631 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1632 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1633 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1634 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1635 = load i32, ptr %context.field.1634, align 4
  %stack.sub.1638 = sub i32 %local.check.owner.end.1633, %local.check.offset.1630
  %descriptor.owner.inside.1636 = icmp ule i32 %local.check.owner.end.1633, %context.value.1635
  %descriptor.offset.inside.1637 = icmp ule i32 %local.check.offset.1630, %local.check.owner.end.1633
  %descriptor.extent.inside.1639 = icmp ule i32 %local.check.extent.1631, %stack.sub.1638
  %descriptor.payload.inside.1640 = icmp ule i32 %local.check.payload.1632, %local.check.extent.1631
  %descriptor.owner.offset.valid.1641 = and i1 %descriptor.owner.inside.1636, %descriptor.offset.inside.1637
  %descriptor.range.inside.1643 = and i1 %descriptor.owner.offset.valid.1641, %descriptor.extent.inside.1639
  %descriptor.range.valid.1642 = and i1 %descriptor.range.inside.1643, %descriptor.payload.inside.1640
  br i1 %descriptor.range.valid.1642, label %descriptor.valid.1644, label %descriptor.invalid.1645
descriptor.invalid.1645:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1644:
  %descriptor.initialized.status.1646 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1630, i32 %local.check.extent.1631)
  %helper.ok.1647 = icmp eq i32 %descriptor.initialized.status.1646, 0
  br i1 %helper.ok.1647, label %helper.continue.1648, label %frame.failure.0
helper.continue.1648:
  br label %local.descriptor.checked.1629
local.descriptor.inactive.1628:
  br label %local.descriptor.checked.1629
local.descriptor.checked.1629:
  %local.is.active.1649 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1649, label %local.descriptor.active.1650, label %local.descriptor.inactive.1651
local.descriptor.active.1650:
  %local.check.offset.1653 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1654 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1655 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1656 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1657 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1658 = load i32, ptr %context.field.1657, align 4
  %stack.sub.1661 = sub i32 %local.check.owner.end.1656, %local.check.offset.1653
  %descriptor.owner.inside.1659 = icmp ule i32 %local.check.owner.end.1656, %context.value.1658
  %descriptor.offset.inside.1660 = icmp ule i32 %local.check.offset.1653, %local.check.owner.end.1656
  %descriptor.extent.inside.1662 = icmp ule i32 %local.check.extent.1654, %stack.sub.1661
  %descriptor.payload.inside.1663 = icmp ule i32 %local.check.payload.1655, %local.check.extent.1654
  %descriptor.owner.offset.valid.1664 = and i1 %descriptor.owner.inside.1659, %descriptor.offset.inside.1660
  %descriptor.range.inside.1666 = and i1 %descriptor.owner.offset.valid.1664, %descriptor.extent.inside.1662
  %descriptor.range.valid.1665 = and i1 %descriptor.range.inside.1666, %descriptor.payload.inside.1663
  br i1 %descriptor.range.valid.1665, label %descriptor.valid.1667, label %descriptor.invalid.1668
descriptor.invalid.1668:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1667:
  %descriptor.initialized.status.1669 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1653, i32 %local.check.extent.1654)
  %helper.ok.1670 = icmp eq i32 %descriptor.initialized.status.1669, 0
  br i1 %helper.ok.1670, label %helper.continue.1671, label %frame.failure.0
helper.continue.1671:
  br label %local.descriptor.checked.1652
local.descriptor.inactive.1651:
  br label %local.descriptor.checked.1652
local.descriptor.checked.1652:
  %local.is.active.1672 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1672, label %local.descriptor.active.1673, label %local.descriptor.inactive.1674
local.descriptor.active.1673:
  %local.check.offset.1676 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1677 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1678 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1679 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1680 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1681 = load i32, ptr %context.field.1680, align 4
  %stack.sub.1684 = sub i32 %local.check.owner.end.1679, %local.check.offset.1676
  %descriptor.owner.inside.1682 = icmp ule i32 %local.check.owner.end.1679, %context.value.1681
  %descriptor.offset.inside.1683 = icmp ule i32 %local.check.offset.1676, %local.check.owner.end.1679
  %descriptor.extent.inside.1685 = icmp ule i32 %local.check.extent.1677, %stack.sub.1684
  %descriptor.payload.inside.1686 = icmp ule i32 %local.check.payload.1678, %local.check.extent.1677
  %descriptor.owner.offset.valid.1687 = and i1 %descriptor.owner.inside.1682, %descriptor.offset.inside.1683
  %descriptor.range.inside.1689 = and i1 %descriptor.owner.offset.valid.1687, %descriptor.extent.inside.1685
  %descriptor.range.valid.1688 = and i1 %descriptor.range.inside.1689, %descriptor.payload.inside.1686
  br i1 %descriptor.range.valid.1688, label %descriptor.valid.1690, label %descriptor.invalid.1691
descriptor.invalid.1691:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1690:
  %descriptor.initialized.status.1692 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1676, i32 %local.check.extent.1677)
  %helper.ok.1693 = icmp eq i32 %descriptor.initialized.status.1692, 0
  br i1 %helper.ok.1693, label %helper.continue.1694, label %frame.failure.0
helper.continue.1694:
  br label %local.descriptor.checked.1675
local.descriptor.inactive.1674:
  br label %local.descriptor.checked.1675
local.descriptor.checked.1675:
  %local.is.active.1695 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1695, label %local.descriptor.active.1696, label %local.descriptor.inactive.1697
local.descriptor.active.1696:
  %local.check.offset.1699 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1700 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1701 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1702 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1703 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1704 = load i32, ptr %context.field.1703, align 4
  %stack.sub.1707 = sub i32 %local.check.owner.end.1702, %local.check.offset.1699
  %descriptor.owner.inside.1705 = icmp ule i32 %local.check.owner.end.1702, %context.value.1704
  %descriptor.offset.inside.1706 = icmp ule i32 %local.check.offset.1699, %local.check.owner.end.1702
  %descriptor.extent.inside.1708 = icmp ule i32 %local.check.extent.1700, %stack.sub.1707
  %descriptor.payload.inside.1709 = icmp ule i32 %local.check.payload.1701, %local.check.extent.1700
  %descriptor.owner.offset.valid.1710 = and i1 %descriptor.owner.inside.1705, %descriptor.offset.inside.1706
  %descriptor.range.inside.1712 = and i1 %descriptor.owner.offset.valid.1710, %descriptor.extent.inside.1708
  %descriptor.range.valid.1711 = and i1 %descriptor.range.inside.1712, %descriptor.payload.inside.1709
  br i1 %descriptor.range.valid.1711, label %descriptor.valid.1713, label %descriptor.invalid.1714
descriptor.invalid.1714:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1713:
  %descriptor.initialized.status.1715 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1699, i32 %local.check.extent.1700)
  %helper.ok.1716 = icmp eq i32 %descriptor.initialized.status.1715, 0
  br i1 %helper.ok.1716, label %helper.continue.1717, label %frame.failure.0
helper.continue.1717:
  br label %local.descriptor.checked.1698
local.descriptor.inactive.1697:
  br label %local.descriptor.checked.1698
local.descriptor.checked.1698:
  %local.is.active.1718 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1718, label %local.descriptor.active.1719, label %local.descriptor.inactive.1720
local.descriptor.active.1719:
  %local.check.offset.1722 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1723 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1724 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1725 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1726 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1727 = load i32, ptr %context.field.1726, align 4
  %stack.sub.1730 = sub i32 %local.check.owner.end.1725, %local.check.offset.1722
  %descriptor.owner.inside.1728 = icmp ule i32 %local.check.owner.end.1725, %context.value.1727
  %descriptor.offset.inside.1729 = icmp ule i32 %local.check.offset.1722, %local.check.owner.end.1725
  %descriptor.extent.inside.1731 = icmp ule i32 %local.check.extent.1723, %stack.sub.1730
  %descriptor.payload.inside.1732 = icmp ule i32 %local.check.payload.1724, %local.check.extent.1723
  %descriptor.owner.offset.valid.1733 = and i1 %descriptor.owner.inside.1728, %descriptor.offset.inside.1729
  %descriptor.range.inside.1735 = and i1 %descriptor.owner.offset.valid.1733, %descriptor.extent.inside.1731
  %descriptor.range.valid.1734 = and i1 %descriptor.range.inside.1735, %descriptor.payload.inside.1732
  br i1 %descriptor.range.valid.1734, label %descriptor.valid.1736, label %descriptor.invalid.1737
descriptor.invalid.1737:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1736:
  %descriptor.initialized.status.1738 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1722, i32 %local.check.extent.1723)
  %helper.ok.1739 = icmp eq i32 %descriptor.initialized.status.1738, 0
  br i1 %helper.ok.1739, label %helper.continue.1740, label %frame.failure.0
helper.continue.1740:
  br label %local.descriptor.checked.1721
local.descriptor.inactive.1720:
  br label %local.descriptor.checked.1721
local.descriptor.checked.1721:
  %step.status.1741 = call i32 @al_owning_charge_step(ptr %ctx, i32 35)
  %helper.ok.1742 = icmp eq i32 %step.status.1741, 0
  br i1 %helper.ok.1742, label %helper.continue.1743, label %frame.failure.0
helper.continue.1743:
  %local.resolved.offset.1744 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.1745 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.1746 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.1747 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1748 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1749 = load i32, ptr %context.field.1748, align 4
  %stack.sub.1752 = sub i32 %local.resolved.owner.end.1747, %local.resolved.offset.1744
  %descriptor.owner.inside.1750 = icmp ule i32 %local.resolved.owner.end.1747, %context.value.1749
  %descriptor.offset.inside.1751 = icmp ule i32 %local.resolved.offset.1744, %local.resolved.owner.end.1747
  %descriptor.extent.inside.1753 = icmp ule i32 %local.resolved.extent.1745, %stack.sub.1752
  %descriptor.payload.inside.1754 = icmp ule i32 %local.resolved.payload.1746, %local.resolved.extent.1745
  %descriptor.owner.offset.valid.1755 = and i1 %descriptor.owner.inside.1750, %descriptor.offset.inside.1751
  %descriptor.range.inside.1757 = and i1 %descriptor.owner.offset.valid.1755, %descriptor.extent.inside.1753
  %descriptor.range.valid.1756 = and i1 %descriptor.range.inside.1757, %descriptor.payload.inside.1754
  %descriptor.type.valid.1758 = icmp eq i32 1, 1
  %descriptor.valid.1759 = and i1 %descriptor.range.valid.1756, %descriptor.type.valid.1758
  br i1 %descriptor.valid.1759, label %descriptor.valid.1760, label %descriptor.invalid.1761
descriptor.invalid.1761:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1760:
  %descriptor.initialized.status.1762 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1744, i32 %local.resolved.extent.1745)
  %helper.ok.1763 = icmp eq i32 %descriptor.initialized.status.1762, 0
  br i1 %helper.ok.1763, label %helper.continue.1764, label %frame.failure.0
helper.continue.1764:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %local.resolved.offset.1744, i32 20, i32 %local.resolved.payload.1746, i32 %local.resolved.owner.end.1747, i32 %local.resolved.extent.1745)
  %context.field.1765 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1766 = load i32, ptr %context.field.1765, align 4
  %runtime.ok.1767 = icmp eq i32 %context.value.1766, 0
  br i1 %runtime.ok.1767, label %runtime.continue.1768, label %frame.failure.0
runtime.continue.1768:
  %context.field.1769 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1770 = load i32, ptr %context.field.1769, align 4
  %stack.sub.1773 = sub i32 %local.resolved.owner.end.1747, %local.resolved.offset.1744
  %descriptor.owner.inside.1771 = icmp ule i32 %local.resolved.owner.end.1747, %context.value.1770
  %descriptor.offset.inside.1772 = icmp ule i32 %local.resolved.offset.1744, %local.resolved.owner.end.1747
  %descriptor.extent.inside.1774 = icmp ule i32 %local.resolved.extent.1745, %stack.sub.1773
  %descriptor.payload.inside.1775 = icmp ule i32 %local.resolved.payload.1746, %local.resolved.extent.1745
  %descriptor.owner.offset.valid.1776 = and i1 %descriptor.owner.inside.1771, %descriptor.offset.inside.1772
  %descriptor.range.inside.1778 = and i1 %descriptor.owner.offset.valid.1776, %descriptor.extent.inside.1774
  %descriptor.range.valid.1777 = and i1 %descriptor.range.inside.1778, %descriptor.payload.inside.1775
  %descriptor.type.valid.1779 = icmp eq i32 1, 1
  %descriptor.valid.1780 = and i1 %descriptor.range.valid.1777, %descriptor.type.valid.1779
  br i1 %descriptor.valid.1780, label %descriptor.valid.1781, label %descriptor.invalid.1782
descriptor.invalid.1782:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1781:
  %descriptor.initialized.status.1783 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1744, i32 %local.resolved.extent.1745)
  %helper.ok.1784 = icmp eq i32 %descriptor.initialized.status.1783, 0
  br i1 %helper.ok.1784, label %helper.continue.1785, label %frame.failure.0
helper.continue.1785:
  %local.is.active.1786 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1786, label %local.descriptor.active.1787, label %local.descriptor.inactive.1788
local.descriptor.active.1787:
  %local.check.offset.1790 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1791 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1792 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1793 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1794 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1795 = load i32, ptr %context.field.1794, align 4
  %stack.sub.1798 = sub i32 %local.check.owner.end.1793, %local.check.offset.1790
  %descriptor.owner.inside.1796 = icmp ule i32 %local.check.owner.end.1793, %context.value.1795
  %descriptor.offset.inside.1797 = icmp ule i32 %local.check.offset.1790, %local.check.owner.end.1793
  %descriptor.extent.inside.1799 = icmp ule i32 %local.check.extent.1791, %stack.sub.1798
  %descriptor.payload.inside.1800 = icmp ule i32 %local.check.payload.1792, %local.check.extent.1791
  %descriptor.owner.offset.valid.1801 = and i1 %descriptor.owner.inside.1796, %descriptor.offset.inside.1797
  %descriptor.range.inside.1803 = and i1 %descriptor.owner.offset.valid.1801, %descriptor.extent.inside.1799
  %descriptor.range.valid.1802 = and i1 %descriptor.range.inside.1803, %descriptor.payload.inside.1800
  br i1 %descriptor.range.valid.1802, label %descriptor.valid.1804, label %descriptor.invalid.1805
descriptor.invalid.1805:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1804:
  %descriptor.initialized.status.1806 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1790, i32 %local.check.extent.1791)
  %helper.ok.1807 = icmp eq i32 %descriptor.initialized.status.1806, 0
  br i1 %helper.ok.1807, label %helper.continue.1808, label %frame.failure.0
helper.continue.1808:
  br label %local.descriptor.checked.1789
local.descriptor.inactive.1788:
  br label %local.descriptor.checked.1789
local.descriptor.checked.1789:
  %local.is.active.1809 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1809, label %local.descriptor.active.1810, label %local.descriptor.inactive.1811
local.descriptor.active.1810:
  %local.check.offset.1813 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1814 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1815 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1816 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1817 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1818 = load i32, ptr %context.field.1817, align 4
  %stack.sub.1821 = sub i32 %local.check.owner.end.1816, %local.check.offset.1813
  %descriptor.owner.inside.1819 = icmp ule i32 %local.check.owner.end.1816, %context.value.1818
  %descriptor.offset.inside.1820 = icmp ule i32 %local.check.offset.1813, %local.check.owner.end.1816
  %descriptor.extent.inside.1822 = icmp ule i32 %local.check.extent.1814, %stack.sub.1821
  %descriptor.payload.inside.1823 = icmp ule i32 %local.check.payload.1815, %local.check.extent.1814
  %descriptor.owner.offset.valid.1824 = and i1 %descriptor.owner.inside.1819, %descriptor.offset.inside.1820
  %descriptor.range.inside.1826 = and i1 %descriptor.owner.offset.valid.1824, %descriptor.extent.inside.1822
  %descriptor.range.valid.1825 = and i1 %descriptor.range.inside.1826, %descriptor.payload.inside.1823
  br i1 %descriptor.range.valid.1825, label %descriptor.valid.1827, label %descriptor.invalid.1828
descriptor.invalid.1828:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1827:
  %descriptor.initialized.status.1829 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1813, i32 %local.check.extent.1814)
  %helper.ok.1830 = icmp eq i32 %descriptor.initialized.status.1829, 0
  br i1 %helper.ok.1830, label %helper.continue.1831, label %frame.failure.0
helper.continue.1831:
  br label %local.descriptor.checked.1812
local.descriptor.inactive.1811:
  br label %local.descriptor.checked.1812
local.descriptor.checked.1812:
  %local.is.active.1832 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1832, label %local.descriptor.active.1833, label %local.descriptor.inactive.1834
local.descriptor.active.1833:
  %local.check.offset.1836 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1837 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1838 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1839 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1840 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1841 = load i32, ptr %context.field.1840, align 4
  %stack.sub.1844 = sub i32 %local.check.owner.end.1839, %local.check.offset.1836
  %descriptor.owner.inside.1842 = icmp ule i32 %local.check.owner.end.1839, %context.value.1841
  %descriptor.offset.inside.1843 = icmp ule i32 %local.check.offset.1836, %local.check.owner.end.1839
  %descriptor.extent.inside.1845 = icmp ule i32 %local.check.extent.1837, %stack.sub.1844
  %descriptor.payload.inside.1846 = icmp ule i32 %local.check.payload.1838, %local.check.extent.1837
  %descriptor.owner.offset.valid.1847 = and i1 %descriptor.owner.inside.1842, %descriptor.offset.inside.1843
  %descriptor.range.inside.1849 = and i1 %descriptor.owner.offset.valid.1847, %descriptor.extent.inside.1845
  %descriptor.range.valid.1848 = and i1 %descriptor.range.inside.1849, %descriptor.payload.inside.1846
  br i1 %descriptor.range.valid.1848, label %descriptor.valid.1850, label %descriptor.invalid.1851
descriptor.invalid.1851:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1850:
  %descriptor.initialized.status.1852 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1836, i32 %local.check.extent.1837)
  %helper.ok.1853 = icmp eq i32 %descriptor.initialized.status.1852, 0
  br i1 %helper.ok.1853, label %helper.continue.1854, label %frame.failure.0
helper.continue.1854:
  br label %local.descriptor.checked.1835
local.descriptor.inactive.1834:
  br label %local.descriptor.checked.1835
local.descriptor.checked.1835:
  %local.is.active.1855 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1855, label %local.descriptor.active.1856, label %local.descriptor.inactive.1857
local.descriptor.active.1856:
  %local.check.offset.1859 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1860 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1861 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1862 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1863 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1864 = load i32, ptr %context.field.1863, align 4
  %stack.sub.1867 = sub i32 %local.check.owner.end.1862, %local.check.offset.1859
  %descriptor.owner.inside.1865 = icmp ule i32 %local.check.owner.end.1862, %context.value.1864
  %descriptor.offset.inside.1866 = icmp ule i32 %local.check.offset.1859, %local.check.owner.end.1862
  %descriptor.extent.inside.1868 = icmp ule i32 %local.check.extent.1860, %stack.sub.1867
  %descriptor.payload.inside.1869 = icmp ule i32 %local.check.payload.1861, %local.check.extent.1860
  %descriptor.owner.offset.valid.1870 = and i1 %descriptor.owner.inside.1865, %descriptor.offset.inside.1866
  %descriptor.range.inside.1872 = and i1 %descriptor.owner.offset.valid.1870, %descriptor.extent.inside.1868
  %descriptor.range.valid.1871 = and i1 %descriptor.range.inside.1872, %descriptor.payload.inside.1869
  br i1 %descriptor.range.valid.1871, label %descriptor.valid.1873, label %descriptor.invalid.1874
descriptor.invalid.1874:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1873:
  %descriptor.initialized.status.1875 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1859, i32 %local.check.extent.1860)
  %helper.ok.1876 = icmp eq i32 %descriptor.initialized.status.1875, 0
  br i1 %helper.ok.1876, label %helper.continue.1877, label %frame.failure.0
helper.continue.1877:
  br label %local.descriptor.checked.1858
local.descriptor.inactive.1857:
  br label %local.descriptor.checked.1858
local.descriptor.checked.1858:
  %local.is.active.1878 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1878, label %local.descriptor.active.1879, label %local.descriptor.inactive.1880
local.descriptor.active.1879:
  %local.check.offset.1882 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1883 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1884 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1885 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1886 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1887 = load i32, ptr %context.field.1886, align 4
  %stack.sub.1890 = sub i32 %local.check.owner.end.1885, %local.check.offset.1882
  %descriptor.owner.inside.1888 = icmp ule i32 %local.check.owner.end.1885, %context.value.1887
  %descriptor.offset.inside.1889 = icmp ule i32 %local.check.offset.1882, %local.check.owner.end.1885
  %descriptor.extent.inside.1891 = icmp ule i32 %local.check.extent.1883, %stack.sub.1890
  %descriptor.payload.inside.1892 = icmp ule i32 %local.check.payload.1884, %local.check.extent.1883
  %descriptor.owner.offset.valid.1893 = and i1 %descriptor.owner.inside.1888, %descriptor.offset.inside.1889
  %descriptor.range.inside.1895 = and i1 %descriptor.owner.offset.valid.1893, %descriptor.extent.inside.1891
  %descriptor.range.valid.1894 = and i1 %descriptor.range.inside.1895, %descriptor.payload.inside.1892
  br i1 %descriptor.range.valid.1894, label %descriptor.valid.1896, label %descriptor.invalid.1897
descriptor.invalid.1897:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1896:
  %descriptor.initialized.status.1898 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1882, i32 %local.check.extent.1883)
  %helper.ok.1899 = icmp eq i32 %descriptor.initialized.status.1898, 0
  br i1 %helper.ok.1899, label %helper.continue.1900, label %frame.failure.0
helper.continue.1900:
  br label %local.descriptor.checked.1881
local.descriptor.inactive.1880:
  br label %local.descriptor.checked.1881
local.descriptor.checked.1881:
  %local.is.active.1901 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1901, label %local.descriptor.active.1902, label %local.descriptor.inactive.1903
local.descriptor.active.1902:
  %local.check.offset.1905 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1906 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1907 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1908 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1909 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1910 = load i32, ptr %context.field.1909, align 4
  %stack.sub.1913 = sub i32 %local.check.owner.end.1908, %local.check.offset.1905
  %descriptor.owner.inside.1911 = icmp ule i32 %local.check.owner.end.1908, %context.value.1910
  %descriptor.offset.inside.1912 = icmp ule i32 %local.check.offset.1905, %local.check.owner.end.1908
  %descriptor.extent.inside.1914 = icmp ule i32 %local.check.extent.1906, %stack.sub.1913
  %descriptor.payload.inside.1915 = icmp ule i32 %local.check.payload.1907, %local.check.extent.1906
  %descriptor.owner.offset.valid.1916 = and i1 %descriptor.owner.inside.1911, %descriptor.offset.inside.1912
  %descriptor.range.inside.1918 = and i1 %descriptor.owner.offset.valid.1916, %descriptor.extent.inside.1914
  %descriptor.range.valid.1917 = and i1 %descriptor.range.inside.1918, %descriptor.payload.inside.1915
  br i1 %descriptor.range.valid.1917, label %descriptor.valid.1919, label %descriptor.invalid.1920
descriptor.invalid.1920:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1919:
  %descriptor.initialized.status.1921 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1905, i32 %local.check.extent.1906)
  %helper.ok.1922 = icmp eq i32 %descriptor.initialized.status.1921, 0
  br i1 %helper.ok.1922, label %helper.continue.1923, label %frame.failure.0
helper.continue.1923:
  br label %local.descriptor.checked.1904
local.descriptor.inactive.1903:
  br label %local.descriptor.checked.1904
local.descriptor.checked.1904:
  %step.status.1924 = call i32 @al_owning_charge_step(ptr %ctx, i32 36)
  %helper.ok.1925 = icmp eq i32 %step.status.1924, 0
  br i1 %helper.ok.1925, label %helper.continue.1926, label %frame.failure.0
helper.continue.1926:
  store i1 true, ptr %local.active.32, align 1
  store i32 %local.resolved.offset.1744, ptr %local.offset.33, align 4
  store i32 %local.resolved.extent.1745, ptr %local.extent.34, align 4
  store i32 %local.resolved.payload.1746, ptr %local.payload.35, align 4
  store i32 %local.resolved.owner.end.1747, ptr %local.owner.end.36, align 4
  store i32 1, ptr %local.type.37, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %local.resolved.offset.1744, i32 20, i32 %local.resolved.payload.1746, i32 %local.resolved.owner.end.1747, i32 %local.resolved.extent.1745)
  %context.field.1927 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1928 = load i32, ptr %context.field.1927, align 4
  %runtime.ok.1929 = icmp eq i32 %context.value.1928, 0
  br i1 %runtime.ok.1929, label %runtime.continue.1930, label %frame.failure.0
runtime.continue.1930:
  %local.is.active.1931 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1931, label %local.descriptor.active.1932, label %local.descriptor.inactive.1933
local.descriptor.active.1932:
  %local.check.offset.1935 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1936 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1937 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1938 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1939 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1940 = load i32, ptr %context.field.1939, align 4
  %stack.sub.1943 = sub i32 %local.check.owner.end.1938, %local.check.offset.1935
  %descriptor.owner.inside.1941 = icmp ule i32 %local.check.owner.end.1938, %context.value.1940
  %descriptor.offset.inside.1942 = icmp ule i32 %local.check.offset.1935, %local.check.owner.end.1938
  %descriptor.extent.inside.1944 = icmp ule i32 %local.check.extent.1936, %stack.sub.1943
  %descriptor.payload.inside.1945 = icmp ule i32 %local.check.payload.1937, %local.check.extent.1936
  %descriptor.owner.offset.valid.1946 = and i1 %descriptor.owner.inside.1941, %descriptor.offset.inside.1942
  %descriptor.range.inside.1948 = and i1 %descriptor.owner.offset.valid.1946, %descriptor.extent.inside.1944
  %descriptor.range.valid.1947 = and i1 %descriptor.range.inside.1948, %descriptor.payload.inside.1945
  br i1 %descriptor.range.valid.1947, label %descriptor.valid.1949, label %descriptor.invalid.1950
descriptor.invalid.1950:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1949:
  %descriptor.initialized.status.1951 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1935, i32 %local.check.extent.1936)
  %helper.ok.1952 = icmp eq i32 %descriptor.initialized.status.1951, 0
  br i1 %helper.ok.1952, label %helper.continue.1953, label %frame.failure.0
helper.continue.1953:
  br label %local.descriptor.checked.1934
local.descriptor.inactive.1933:
  br label %local.descriptor.checked.1934
local.descriptor.checked.1934:
  %local.is.active.1954 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1954, label %local.descriptor.active.1955, label %local.descriptor.inactive.1956
local.descriptor.active.1955:
  %local.check.offset.1958 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1959 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1960 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1961 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1962 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1963 = load i32, ptr %context.field.1962, align 4
  %stack.sub.1966 = sub i32 %local.check.owner.end.1961, %local.check.offset.1958
  %descriptor.owner.inside.1964 = icmp ule i32 %local.check.owner.end.1961, %context.value.1963
  %descriptor.offset.inside.1965 = icmp ule i32 %local.check.offset.1958, %local.check.owner.end.1961
  %descriptor.extent.inside.1967 = icmp ule i32 %local.check.extent.1959, %stack.sub.1966
  %descriptor.payload.inside.1968 = icmp ule i32 %local.check.payload.1960, %local.check.extent.1959
  %descriptor.owner.offset.valid.1969 = and i1 %descriptor.owner.inside.1964, %descriptor.offset.inside.1965
  %descriptor.range.inside.1971 = and i1 %descriptor.owner.offset.valid.1969, %descriptor.extent.inside.1967
  %descriptor.range.valid.1970 = and i1 %descriptor.range.inside.1971, %descriptor.payload.inside.1968
  br i1 %descriptor.range.valid.1970, label %descriptor.valid.1972, label %descriptor.invalid.1973
descriptor.invalid.1973:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1972:
  %descriptor.initialized.status.1974 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1958, i32 %local.check.extent.1959)
  %helper.ok.1975 = icmp eq i32 %descriptor.initialized.status.1974, 0
  br i1 %helper.ok.1975, label %helper.continue.1976, label %frame.failure.0
helper.continue.1976:
  br label %local.descriptor.checked.1957
local.descriptor.inactive.1956:
  br label %local.descriptor.checked.1957
local.descriptor.checked.1957:
  %local.is.active.1977 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1977, label %local.descriptor.active.1978, label %local.descriptor.inactive.1979
local.descriptor.active.1978:
  %local.check.offset.1981 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1982 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1983 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1984 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1985 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1986 = load i32, ptr %context.field.1985, align 4
  %stack.sub.1989 = sub i32 %local.check.owner.end.1984, %local.check.offset.1981
  %descriptor.owner.inside.1987 = icmp ule i32 %local.check.owner.end.1984, %context.value.1986
  %descriptor.offset.inside.1988 = icmp ule i32 %local.check.offset.1981, %local.check.owner.end.1984
  %descriptor.extent.inside.1990 = icmp ule i32 %local.check.extent.1982, %stack.sub.1989
  %descriptor.payload.inside.1991 = icmp ule i32 %local.check.payload.1983, %local.check.extent.1982
  %descriptor.owner.offset.valid.1992 = and i1 %descriptor.owner.inside.1987, %descriptor.offset.inside.1988
  %descriptor.range.inside.1994 = and i1 %descriptor.owner.offset.valid.1992, %descriptor.extent.inside.1990
  %descriptor.range.valid.1993 = and i1 %descriptor.range.inside.1994, %descriptor.payload.inside.1991
  br i1 %descriptor.range.valid.1993, label %descriptor.valid.1995, label %descriptor.invalid.1996
descriptor.invalid.1996:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1995:
  %descriptor.initialized.status.1997 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1981, i32 %local.check.extent.1982)
  %helper.ok.1998 = icmp eq i32 %descriptor.initialized.status.1997, 0
  br i1 %helper.ok.1998, label %helper.continue.1999, label %frame.failure.0
helper.continue.1999:
  br label %local.descriptor.checked.1980
local.descriptor.inactive.1979:
  br label %local.descriptor.checked.1980
local.descriptor.checked.1980:
  %local.is.active.2000 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2000, label %local.descriptor.active.2001, label %local.descriptor.inactive.2002
local.descriptor.active.2001:
  %local.check.offset.2004 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2005 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2006 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2007 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2008 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2009 = load i32, ptr %context.field.2008, align 4
  %stack.sub.2012 = sub i32 %local.check.owner.end.2007, %local.check.offset.2004
  %descriptor.owner.inside.2010 = icmp ule i32 %local.check.owner.end.2007, %context.value.2009
  %descriptor.offset.inside.2011 = icmp ule i32 %local.check.offset.2004, %local.check.owner.end.2007
  %descriptor.extent.inside.2013 = icmp ule i32 %local.check.extent.2005, %stack.sub.2012
  %descriptor.payload.inside.2014 = icmp ule i32 %local.check.payload.2006, %local.check.extent.2005
  %descriptor.owner.offset.valid.2015 = and i1 %descriptor.owner.inside.2010, %descriptor.offset.inside.2011
  %descriptor.range.inside.2017 = and i1 %descriptor.owner.offset.valid.2015, %descriptor.extent.inside.2013
  %descriptor.range.valid.2016 = and i1 %descriptor.range.inside.2017, %descriptor.payload.inside.2014
  br i1 %descriptor.range.valid.2016, label %descriptor.valid.2018, label %descriptor.invalid.2019
descriptor.invalid.2019:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2018:
  %descriptor.initialized.status.2020 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2004, i32 %local.check.extent.2005)
  %helper.ok.2021 = icmp eq i32 %descriptor.initialized.status.2020, 0
  br i1 %helper.ok.2021, label %helper.continue.2022, label %frame.failure.0
helper.continue.2022:
  br label %local.descriptor.checked.2003
local.descriptor.inactive.2002:
  br label %local.descriptor.checked.2003
local.descriptor.checked.2003:
  %local.is.active.2023 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2023, label %local.descriptor.active.2024, label %local.descriptor.inactive.2025
local.descriptor.active.2024:
  %local.check.offset.2027 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2028 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2029 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2030 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2031 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2032 = load i32, ptr %context.field.2031, align 4
  %stack.sub.2035 = sub i32 %local.check.owner.end.2030, %local.check.offset.2027
  %descriptor.owner.inside.2033 = icmp ule i32 %local.check.owner.end.2030, %context.value.2032
  %descriptor.offset.inside.2034 = icmp ule i32 %local.check.offset.2027, %local.check.owner.end.2030
  %descriptor.extent.inside.2036 = icmp ule i32 %local.check.extent.2028, %stack.sub.2035
  %descriptor.payload.inside.2037 = icmp ule i32 %local.check.payload.2029, %local.check.extent.2028
  %descriptor.owner.offset.valid.2038 = and i1 %descriptor.owner.inside.2033, %descriptor.offset.inside.2034
  %descriptor.range.inside.2040 = and i1 %descriptor.owner.offset.valid.2038, %descriptor.extent.inside.2036
  %descriptor.range.valid.2039 = and i1 %descriptor.range.inside.2040, %descriptor.payload.inside.2037
  br i1 %descriptor.range.valid.2039, label %descriptor.valid.2041, label %descriptor.invalid.2042
descriptor.invalid.2042:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2041:
  %descriptor.initialized.status.2043 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2027, i32 %local.check.extent.2028)
  %helper.ok.2044 = icmp eq i32 %descriptor.initialized.status.2043, 0
  br i1 %helper.ok.2044, label %helper.continue.2045, label %frame.failure.0
helper.continue.2045:
  br label %local.descriptor.checked.2026
local.descriptor.inactive.2025:
  br label %local.descriptor.checked.2026
local.descriptor.checked.2026:
  %local.is.active.2046 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2046, label %local.descriptor.active.2047, label %local.descriptor.inactive.2048
local.descriptor.active.2047:
  %local.check.offset.2050 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2051 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2052 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2053 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2054 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2055 = load i32, ptr %context.field.2054, align 4
  %stack.sub.2058 = sub i32 %local.check.owner.end.2053, %local.check.offset.2050
  %descriptor.owner.inside.2056 = icmp ule i32 %local.check.owner.end.2053, %context.value.2055
  %descriptor.offset.inside.2057 = icmp ule i32 %local.check.offset.2050, %local.check.owner.end.2053
  %descriptor.extent.inside.2059 = icmp ule i32 %local.check.extent.2051, %stack.sub.2058
  %descriptor.payload.inside.2060 = icmp ule i32 %local.check.payload.2052, %local.check.extent.2051
  %descriptor.owner.offset.valid.2061 = and i1 %descriptor.owner.inside.2056, %descriptor.offset.inside.2057
  %descriptor.range.inside.2063 = and i1 %descriptor.owner.offset.valid.2061, %descriptor.extent.inside.2059
  %descriptor.range.valid.2062 = and i1 %descriptor.range.inside.2063, %descriptor.payload.inside.2060
  br i1 %descriptor.range.valid.2062, label %descriptor.valid.2064, label %descriptor.invalid.2065
descriptor.invalid.2065:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2064:
  %descriptor.initialized.status.2066 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2050, i32 %local.check.extent.2051)
  %helper.ok.2067 = icmp eq i32 %descriptor.initialized.status.2066, 0
  br i1 %helper.ok.2067, label %helper.continue.2068, label %frame.failure.0
helper.continue.2068:
  br label %local.descriptor.checked.2049
local.descriptor.inactive.2048:
  br label %local.descriptor.checked.2049
local.descriptor.checked.2049:
  %step.status.2069 = call i32 @al_owning_charge_step(ptr %ctx, i32 37)
  %helper.ok.2070 = icmp eq i32 %step.status.2069, 0
  br i1 %helper.ok.2070, label %helper.continue.2071, label %frame.failure.0
helper.continue.2071:
  %local.resolved.offset.2072 = load i32, ptr %local.offset.27, align 4
  %local.resolved.extent.2073 = load i32, ptr %local.extent.28, align 4
  %local.resolved.payload.2074 = load i32, ptr %local.payload.29, align 4
  %local.resolved.owner.end.2075 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2076 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2077 = load i32, ptr %context.field.2076, align 4
  %stack.sub.2080 = sub i32 %local.resolved.owner.end.2075, %local.resolved.offset.2072
  %descriptor.owner.inside.2078 = icmp ule i32 %local.resolved.owner.end.2075, %context.value.2077
  %descriptor.offset.inside.2079 = icmp ule i32 %local.resolved.offset.2072, %local.resolved.owner.end.2075
  %descriptor.extent.inside.2081 = icmp ule i32 %local.resolved.extent.2073, %stack.sub.2080
  %descriptor.payload.inside.2082 = icmp ule i32 %local.resolved.payload.2074, %local.resolved.extent.2073
  %descriptor.owner.offset.valid.2083 = and i1 %descriptor.owner.inside.2078, %descriptor.offset.inside.2079
  %descriptor.range.inside.2085 = and i1 %descriptor.owner.offset.valid.2083, %descriptor.extent.inside.2081
  %descriptor.range.valid.2084 = and i1 %descriptor.range.inside.2085, %descriptor.payload.inside.2082
  %descriptor.type.valid.2086 = icmp eq i32 6, 6
  %descriptor.valid.2087 = and i1 %descriptor.range.valid.2084, %descriptor.type.valid.2086
  br i1 %descriptor.valid.2087, label %descriptor.valid.2088, label %descriptor.invalid.2089
descriptor.invalid.2089:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2088:
  %descriptor.initialized.status.2090 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.2072, i32 %local.resolved.extent.2073)
  %helper.ok.2091 = icmp eq i32 %descriptor.initialized.status.2090, 0
  br i1 %helper.ok.2091, label %helper.continue.2092, label %frame.failure.0
helper.continue.2092:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %local.resolved.offset.2072, i32 20, i32 %local.resolved.payload.2074, i32 %local.resolved.owner.end.2075, i32 %local.resolved.extent.2073)
  %context.field.2093 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2094 = load i32, ptr %context.field.2093, align 4
  %runtime.ok.2095 = icmp eq i32 %context.value.2094, 0
  br i1 %runtime.ok.2095, label %runtime.continue.2096, label %frame.failure.0
runtime.continue.2096:
  %context.field.2097 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2098 = load i32, ptr %context.field.2097, align 4
  %stack.sub.2101 = sub i32 %local.resolved.owner.end.2075, %local.resolved.offset.2072
  %descriptor.owner.inside.2099 = icmp ule i32 %local.resolved.owner.end.2075, %context.value.2098
  %descriptor.offset.inside.2100 = icmp ule i32 %local.resolved.offset.2072, %local.resolved.owner.end.2075
  %descriptor.extent.inside.2102 = icmp ule i32 %local.resolved.extent.2073, %stack.sub.2101
  %descriptor.payload.inside.2103 = icmp ule i32 %local.resolved.payload.2074, %local.resolved.extent.2073
  %descriptor.owner.offset.valid.2104 = and i1 %descriptor.owner.inside.2099, %descriptor.offset.inside.2100
  %descriptor.range.inside.2106 = and i1 %descriptor.owner.offset.valid.2104, %descriptor.extent.inside.2102
  %descriptor.range.valid.2105 = and i1 %descriptor.range.inside.2106, %descriptor.payload.inside.2103
  %descriptor.type.valid.2107 = icmp eq i32 6, 6
  %descriptor.valid.2108 = and i1 %descriptor.range.valid.2105, %descriptor.type.valid.2107
  br i1 %descriptor.valid.2108, label %descriptor.valid.2109, label %descriptor.invalid.2110
descriptor.invalid.2110:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2109:
  %descriptor.initialized.status.2111 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.2072, i32 %local.resolved.extent.2073)
  %helper.ok.2112 = icmp eq i32 %descriptor.initialized.status.2111, 0
  br i1 %helper.ok.2112, label %helper.continue.2113, label %frame.failure.0
helper.continue.2113:
  %local.is.active.2114 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2114, label %local.descriptor.active.2115, label %local.descriptor.inactive.2116
local.descriptor.active.2115:
  %local.check.offset.2118 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2119 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2120 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2121 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2122 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2123 = load i32, ptr %context.field.2122, align 4
  %stack.sub.2126 = sub i32 %local.check.owner.end.2121, %local.check.offset.2118
  %descriptor.owner.inside.2124 = icmp ule i32 %local.check.owner.end.2121, %context.value.2123
  %descriptor.offset.inside.2125 = icmp ule i32 %local.check.offset.2118, %local.check.owner.end.2121
  %descriptor.extent.inside.2127 = icmp ule i32 %local.check.extent.2119, %stack.sub.2126
  %descriptor.payload.inside.2128 = icmp ule i32 %local.check.payload.2120, %local.check.extent.2119
  %descriptor.owner.offset.valid.2129 = and i1 %descriptor.owner.inside.2124, %descriptor.offset.inside.2125
  %descriptor.range.inside.2131 = and i1 %descriptor.owner.offset.valid.2129, %descriptor.extent.inside.2127
  %descriptor.range.valid.2130 = and i1 %descriptor.range.inside.2131, %descriptor.payload.inside.2128
  br i1 %descriptor.range.valid.2130, label %descriptor.valid.2132, label %descriptor.invalid.2133
descriptor.invalid.2133:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2132:
  %descriptor.initialized.status.2134 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2118, i32 %local.check.extent.2119)
  %helper.ok.2135 = icmp eq i32 %descriptor.initialized.status.2134, 0
  br i1 %helper.ok.2135, label %helper.continue.2136, label %frame.failure.0
helper.continue.2136:
  br label %local.descriptor.checked.2117
local.descriptor.inactive.2116:
  br label %local.descriptor.checked.2117
local.descriptor.checked.2117:
  %local.is.active.2137 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2137, label %local.descriptor.active.2138, label %local.descriptor.inactive.2139
local.descriptor.active.2138:
  %local.check.offset.2141 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2142 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2143 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2144 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2145 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2146 = load i32, ptr %context.field.2145, align 4
  %stack.sub.2149 = sub i32 %local.check.owner.end.2144, %local.check.offset.2141
  %descriptor.owner.inside.2147 = icmp ule i32 %local.check.owner.end.2144, %context.value.2146
  %descriptor.offset.inside.2148 = icmp ule i32 %local.check.offset.2141, %local.check.owner.end.2144
  %descriptor.extent.inside.2150 = icmp ule i32 %local.check.extent.2142, %stack.sub.2149
  %descriptor.payload.inside.2151 = icmp ule i32 %local.check.payload.2143, %local.check.extent.2142
  %descriptor.owner.offset.valid.2152 = and i1 %descriptor.owner.inside.2147, %descriptor.offset.inside.2148
  %descriptor.range.inside.2154 = and i1 %descriptor.owner.offset.valid.2152, %descriptor.extent.inside.2150
  %descriptor.range.valid.2153 = and i1 %descriptor.range.inside.2154, %descriptor.payload.inside.2151
  br i1 %descriptor.range.valid.2153, label %descriptor.valid.2155, label %descriptor.invalid.2156
descriptor.invalid.2156:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2155:
  %descriptor.initialized.status.2157 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2141, i32 %local.check.extent.2142)
  %helper.ok.2158 = icmp eq i32 %descriptor.initialized.status.2157, 0
  br i1 %helper.ok.2158, label %helper.continue.2159, label %frame.failure.0
helper.continue.2159:
  br label %local.descriptor.checked.2140
local.descriptor.inactive.2139:
  br label %local.descriptor.checked.2140
local.descriptor.checked.2140:
  %local.is.active.2160 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2160, label %local.descriptor.active.2161, label %local.descriptor.inactive.2162
local.descriptor.active.2161:
  %local.check.offset.2164 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2165 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2166 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2167 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2168 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2169 = load i32, ptr %context.field.2168, align 4
  %stack.sub.2172 = sub i32 %local.check.owner.end.2167, %local.check.offset.2164
  %descriptor.owner.inside.2170 = icmp ule i32 %local.check.owner.end.2167, %context.value.2169
  %descriptor.offset.inside.2171 = icmp ule i32 %local.check.offset.2164, %local.check.owner.end.2167
  %descriptor.extent.inside.2173 = icmp ule i32 %local.check.extent.2165, %stack.sub.2172
  %descriptor.payload.inside.2174 = icmp ule i32 %local.check.payload.2166, %local.check.extent.2165
  %descriptor.owner.offset.valid.2175 = and i1 %descriptor.owner.inside.2170, %descriptor.offset.inside.2171
  %descriptor.range.inside.2177 = and i1 %descriptor.owner.offset.valid.2175, %descriptor.extent.inside.2173
  %descriptor.range.valid.2176 = and i1 %descriptor.range.inside.2177, %descriptor.payload.inside.2174
  br i1 %descriptor.range.valid.2176, label %descriptor.valid.2178, label %descriptor.invalid.2179
descriptor.invalid.2179:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2178:
  %descriptor.initialized.status.2180 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2164, i32 %local.check.extent.2165)
  %helper.ok.2181 = icmp eq i32 %descriptor.initialized.status.2180, 0
  br i1 %helper.ok.2181, label %helper.continue.2182, label %frame.failure.0
helper.continue.2182:
  br label %local.descriptor.checked.2163
local.descriptor.inactive.2162:
  br label %local.descriptor.checked.2163
local.descriptor.checked.2163:
  %local.is.active.2183 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2183, label %local.descriptor.active.2184, label %local.descriptor.inactive.2185
local.descriptor.active.2184:
  %local.check.offset.2187 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2188 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2189 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2190 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2191 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2192 = load i32, ptr %context.field.2191, align 4
  %stack.sub.2195 = sub i32 %local.check.owner.end.2190, %local.check.offset.2187
  %descriptor.owner.inside.2193 = icmp ule i32 %local.check.owner.end.2190, %context.value.2192
  %descriptor.offset.inside.2194 = icmp ule i32 %local.check.offset.2187, %local.check.owner.end.2190
  %descriptor.extent.inside.2196 = icmp ule i32 %local.check.extent.2188, %stack.sub.2195
  %descriptor.payload.inside.2197 = icmp ule i32 %local.check.payload.2189, %local.check.extent.2188
  %descriptor.owner.offset.valid.2198 = and i1 %descriptor.owner.inside.2193, %descriptor.offset.inside.2194
  %descriptor.range.inside.2200 = and i1 %descriptor.owner.offset.valid.2198, %descriptor.extent.inside.2196
  %descriptor.range.valid.2199 = and i1 %descriptor.range.inside.2200, %descriptor.payload.inside.2197
  br i1 %descriptor.range.valid.2199, label %descriptor.valid.2201, label %descriptor.invalid.2202
descriptor.invalid.2202:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2201:
  %descriptor.initialized.status.2203 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2187, i32 %local.check.extent.2188)
  %helper.ok.2204 = icmp eq i32 %descriptor.initialized.status.2203, 0
  br i1 %helper.ok.2204, label %helper.continue.2205, label %frame.failure.0
helper.continue.2205:
  br label %local.descriptor.checked.2186
local.descriptor.inactive.2185:
  br label %local.descriptor.checked.2186
local.descriptor.checked.2186:
  %local.is.active.2206 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2206, label %local.descriptor.active.2207, label %local.descriptor.inactive.2208
local.descriptor.active.2207:
  %local.check.offset.2210 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2211 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2212 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2213 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2214 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2215 = load i32, ptr %context.field.2214, align 4
  %stack.sub.2218 = sub i32 %local.check.owner.end.2213, %local.check.offset.2210
  %descriptor.owner.inside.2216 = icmp ule i32 %local.check.owner.end.2213, %context.value.2215
  %descriptor.offset.inside.2217 = icmp ule i32 %local.check.offset.2210, %local.check.owner.end.2213
  %descriptor.extent.inside.2219 = icmp ule i32 %local.check.extent.2211, %stack.sub.2218
  %descriptor.payload.inside.2220 = icmp ule i32 %local.check.payload.2212, %local.check.extent.2211
  %descriptor.owner.offset.valid.2221 = and i1 %descriptor.owner.inside.2216, %descriptor.offset.inside.2217
  %descriptor.range.inside.2223 = and i1 %descriptor.owner.offset.valid.2221, %descriptor.extent.inside.2219
  %descriptor.range.valid.2222 = and i1 %descriptor.range.inside.2223, %descriptor.payload.inside.2220
  br i1 %descriptor.range.valid.2222, label %descriptor.valid.2224, label %descriptor.invalid.2225
descriptor.invalid.2225:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2224:
  %descriptor.initialized.status.2226 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2210, i32 %local.check.extent.2211)
  %helper.ok.2227 = icmp eq i32 %descriptor.initialized.status.2226, 0
  br i1 %helper.ok.2227, label %helper.continue.2228, label %frame.failure.0
helper.continue.2228:
  br label %local.descriptor.checked.2209
local.descriptor.inactive.2208:
  br label %local.descriptor.checked.2209
local.descriptor.checked.2209:
  %local.is.active.2229 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2229, label %local.descriptor.active.2230, label %local.descriptor.inactive.2231
local.descriptor.active.2230:
  %local.check.offset.2233 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2234 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2235 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2236 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2237 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2238 = load i32, ptr %context.field.2237, align 4
  %stack.sub.2241 = sub i32 %local.check.owner.end.2236, %local.check.offset.2233
  %descriptor.owner.inside.2239 = icmp ule i32 %local.check.owner.end.2236, %context.value.2238
  %descriptor.offset.inside.2240 = icmp ule i32 %local.check.offset.2233, %local.check.owner.end.2236
  %descriptor.extent.inside.2242 = icmp ule i32 %local.check.extent.2234, %stack.sub.2241
  %descriptor.payload.inside.2243 = icmp ule i32 %local.check.payload.2235, %local.check.extent.2234
  %descriptor.owner.offset.valid.2244 = and i1 %descriptor.owner.inside.2239, %descriptor.offset.inside.2240
  %descriptor.range.inside.2246 = and i1 %descriptor.owner.offset.valid.2244, %descriptor.extent.inside.2242
  %descriptor.range.valid.2245 = and i1 %descriptor.range.inside.2246, %descriptor.payload.inside.2243
  br i1 %descriptor.range.valid.2245, label %descriptor.valid.2247, label %descriptor.invalid.2248
descriptor.invalid.2248:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2247:
  %descriptor.initialized.status.2249 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2233, i32 %local.check.extent.2234)
  %helper.ok.2250 = icmp eq i32 %descriptor.initialized.status.2249, 0
  br i1 %helper.ok.2250, label %helper.continue.2251, label %frame.failure.0
helper.continue.2251:
  br label %local.descriptor.checked.2232
local.descriptor.inactive.2231:
  br label %local.descriptor.checked.2232
local.descriptor.checked.2232:
  %step.status.2252 = call i32 @al_owning_charge_step(ptr %ctx, i32 38)
  %helper.ok.2253 = icmp eq i32 %step.status.2252, 0
  br i1 %helper.ok.2253, label %helper.continue.2254, label %frame.failure.0
helper.continue.2254:
  %local.resolved.offset.2255 = load i32, ptr %local.offset.33, align 4
  %local.resolved.extent.2256 = load i32, ptr %local.extent.34, align 4
  %local.resolved.payload.2257 = load i32, ptr %local.payload.35, align 4
  %local.resolved.owner.end.2258 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2259 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2260 = load i32, ptr %context.field.2259, align 4
  %stack.sub.2263 = sub i32 %local.resolved.owner.end.2258, %local.resolved.offset.2255
  %descriptor.owner.inside.2261 = icmp ule i32 %local.resolved.owner.end.2258, %context.value.2260
  %descriptor.offset.inside.2262 = icmp ule i32 %local.resolved.offset.2255, %local.resolved.owner.end.2258
  %descriptor.extent.inside.2264 = icmp ule i32 %local.resolved.extent.2256, %stack.sub.2263
  %descriptor.payload.inside.2265 = icmp ule i32 %local.resolved.payload.2257, %local.resolved.extent.2256
  %descriptor.owner.offset.valid.2266 = and i1 %descriptor.owner.inside.2261, %descriptor.offset.inside.2262
  %descriptor.range.inside.2268 = and i1 %descriptor.owner.offset.valid.2266, %descriptor.extent.inside.2264
  %descriptor.range.valid.2267 = and i1 %descriptor.range.inside.2268, %descriptor.payload.inside.2265
  %descriptor.type.valid.2269 = icmp eq i32 1, 1
  %descriptor.valid.2270 = and i1 %descriptor.range.valid.2267, %descriptor.type.valid.2269
  br i1 %descriptor.valid.2270, label %descriptor.valid.2271, label %descriptor.invalid.2272
descriptor.invalid.2272:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2271:
  %descriptor.initialized.status.2273 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.2255, i32 %local.resolved.extent.2256)
  %helper.ok.2274 = icmp eq i32 %descriptor.initialized.status.2273, 0
  br i1 %helper.ok.2274, label %helper.continue.2275, label %frame.failure.0
helper.continue.2275:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %local.resolved.offset.2255, i32 20, i32 %local.resolved.payload.2257, i32 %local.resolved.owner.end.2258, i32 %local.resolved.extent.2256)
  %context.field.2276 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2277 = load i32, ptr %context.field.2276, align 4
  %runtime.ok.2278 = icmp eq i32 %context.value.2277, 0
  br i1 %runtime.ok.2278, label %runtime.continue.2279, label %frame.failure.0
runtime.continue.2279:
  %context.field.2280 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2281 = load i32, ptr %context.field.2280, align 4
  %stack.sub.2284 = sub i32 %local.resolved.owner.end.2075, %local.resolved.offset.2072
  %descriptor.owner.inside.2282 = icmp ule i32 %local.resolved.owner.end.2075, %context.value.2281
  %descriptor.offset.inside.2283 = icmp ule i32 %local.resolved.offset.2072, %local.resolved.owner.end.2075
  %descriptor.extent.inside.2285 = icmp ule i32 %local.resolved.extent.2073, %stack.sub.2284
  %descriptor.payload.inside.2286 = icmp ule i32 %local.resolved.payload.2074, %local.resolved.extent.2073
  %descriptor.owner.offset.valid.2287 = and i1 %descriptor.owner.inside.2282, %descriptor.offset.inside.2283
  %descriptor.range.inside.2289 = and i1 %descriptor.owner.offset.valid.2287, %descriptor.extent.inside.2285
  %descriptor.range.valid.2288 = and i1 %descriptor.range.inside.2289, %descriptor.payload.inside.2286
  %descriptor.type.valid.2290 = icmp eq i32 6, 6
  %descriptor.valid.2291 = and i1 %descriptor.range.valid.2288, %descriptor.type.valid.2290
  br i1 %descriptor.valid.2291, label %descriptor.valid.2292, label %descriptor.invalid.2293
descriptor.invalid.2293:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2292:
  %descriptor.initialized.status.2294 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.2072, i32 %local.resolved.extent.2073)
  %helper.ok.2295 = icmp eq i32 %descriptor.initialized.status.2294, 0
  br i1 %helper.ok.2295, label %helper.continue.2296, label %frame.failure.0
helper.continue.2296:
  %context.field.2297 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2298 = load i32, ptr %context.field.2297, align 4
  %stack.sub.2301 = sub i32 %local.resolved.owner.end.2258, %local.resolved.offset.2255
  %descriptor.owner.inside.2299 = icmp ule i32 %local.resolved.owner.end.2258, %context.value.2298
  %descriptor.offset.inside.2300 = icmp ule i32 %local.resolved.offset.2255, %local.resolved.owner.end.2258
  %descriptor.extent.inside.2302 = icmp ule i32 %local.resolved.extent.2256, %stack.sub.2301
  %descriptor.payload.inside.2303 = icmp ule i32 %local.resolved.payload.2257, %local.resolved.extent.2256
  %descriptor.owner.offset.valid.2304 = and i1 %descriptor.owner.inside.2299, %descriptor.offset.inside.2300
  %descriptor.range.inside.2306 = and i1 %descriptor.owner.offset.valid.2304, %descriptor.extent.inside.2302
  %descriptor.range.valid.2305 = and i1 %descriptor.range.inside.2306, %descriptor.payload.inside.2303
  %descriptor.type.valid.2307 = icmp eq i32 1, 1
  %descriptor.valid.2308 = and i1 %descriptor.range.valid.2305, %descriptor.type.valid.2307
  br i1 %descriptor.valid.2308, label %descriptor.valid.2309, label %descriptor.invalid.2310
descriptor.invalid.2310:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2309:
  %descriptor.initialized.status.2311 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.2255, i32 %local.resolved.extent.2256)
  %helper.ok.2312 = icmp eq i32 %descriptor.initialized.status.2311, 0
  br i1 %helper.ok.2312, label %helper.continue.2313, label %frame.failure.0
helper.continue.2313:
  %local.is.active.2314 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2314, label %local.descriptor.active.2315, label %local.descriptor.inactive.2316
local.descriptor.active.2315:
  %local.check.offset.2318 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2319 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2320 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2321 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2322 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2323 = load i32, ptr %context.field.2322, align 4
  %stack.sub.2326 = sub i32 %local.check.owner.end.2321, %local.check.offset.2318
  %descriptor.owner.inside.2324 = icmp ule i32 %local.check.owner.end.2321, %context.value.2323
  %descriptor.offset.inside.2325 = icmp ule i32 %local.check.offset.2318, %local.check.owner.end.2321
  %descriptor.extent.inside.2327 = icmp ule i32 %local.check.extent.2319, %stack.sub.2326
  %descriptor.payload.inside.2328 = icmp ule i32 %local.check.payload.2320, %local.check.extent.2319
  %descriptor.owner.offset.valid.2329 = and i1 %descriptor.owner.inside.2324, %descriptor.offset.inside.2325
  %descriptor.range.inside.2331 = and i1 %descriptor.owner.offset.valid.2329, %descriptor.extent.inside.2327
  %descriptor.range.valid.2330 = and i1 %descriptor.range.inside.2331, %descriptor.payload.inside.2328
  br i1 %descriptor.range.valid.2330, label %descriptor.valid.2332, label %descriptor.invalid.2333
descriptor.invalid.2333:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2332:
  %descriptor.initialized.status.2334 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2318, i32 %local.check.extent.2319)
  %helper.ok.2335 = icmp eq i32 %descriptor.initialized.status.2334, 0
  br i1 %helper.ok.2335, label %helper.continue.2336, label %frame.failure.0
helper.continue.2336:
  br label %local.descriptor.checked.2317
local.descriptor.inactive.2316:
  br label %local.descriptor.checked.2317
local.descriptor.checked.2317:
  %local.is.active.2337 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2337, label %local.descriptor.active.2338, label %local.descriptor.inactive.2339
local.descriptor.active.2338:
  %local.check.offset.2341 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2342 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2343 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2344 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2345 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2346 = load i32, ptr %context.field.2345, align 4
  %stack.sub.2349 = sub i32 %local.check.owner.end.2344, %local.check.offset.2341
  %descriptor.owner.inside.2347 = icmp ule i32 %local.check.owner.end.2344, %context.value.2346
  %descriptor.offset.inside.2348 = icmp ule i32 %local.check.offset.2341, %local.check.owner.end.2344
  %descriptor.extent.inside.2350 = icmp ule i32 %local.check.extent.2342, %stack.sub.2349
  %descriptor.payload.inside.2351 = icmp ule i32 %local.check.payload.2343, %local.check.extent.2342
  %descriptor.owner.offset.valid.2352 = and i1 %descriptor.owner.inside.2347, %descriptor.offset.inside.2348
  %descriptor.range.inside.2354 = and i1 %descriptor.owner.offset.valid.2352, %descriptor.extent.inside.2350
  %descriptor.range.valid.2353 = and i1 %descriptor.range.inside.2354, %descriptor.payload.inside.2351
  br i1 %descriptor.range.valid.2353, label %descriptor.valid.2355, label %descriptor.invalid.2356
descriptor.invalid.2356:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2355:
  %descriptor.initialized.status.2357 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2341, i32 %local.check.extent.2342)
  %helper.ok.2358 = icmp eq i32 %descriptor.initialized.status.2357, 0
  br i1 %helper.ok.2358, label %helper.continue.2359, label %frame.failure.0
helper.continue.2359:
  br label %local.descriptor.checked.2340
local.descriptor.inactive.2339:
  br label %local.descriptor.checked.2340
local.descriptor.checked.2340:
  %local.is.active.2360 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2360, label %local.descriptor.active.2361, label %local.descriptor.inactive.2362
local.descriptor.active.2361:
  %local.check.offset.2364 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2365 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2366 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2367 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2368 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2369 = load i32, ptr %context.field.2368, align 4
  %stack.sub.2372 = sub i32 %local.check.owner.end.2367, %local.check.offset.2364
  %descriptor.owner.inside.2370 = icmp ule i32 %local.check.owner.end.2367, %context.value.2369
  %descriptor.offset.inside.2371 = icmp ule i32 %local.check.offset.2364, %local.check.owner.end.2367
  %descriptor.extent.inside.2373 = icmp ule i32 %local.check.extent.2365, %stack.sub.2372
  %descriptor.payload.inside.2374 = icmp ule i32 %local.check.payload.2366, %local.check.extent.2365
  %descriptor.owner.offset.valid.2375 = and i1 %descriptor.owner.inside.2370, %descriptor.offset.inside.2371
  %descriptor.range.inside.2377 = and i1 %descriptor.owner.offset.valid.2375, %descriptor.extent.inside.2373
  %descriptor.range.valid.2376 = and i1 %descriptor.range.inside.2377, %descriptor.payload.inside.2374
  br i1 %descriptor.range.valid.2376, label %descriptor.valid.2378, label %descriptor.invalid.2379
descriptor.invalid.2379:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2378:
  %descriptor.initialized.status.2380 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2364, i32 %local.check.extent.2365)
  %helper.ok.2381 = icmp eq i32 %descriptor.initialized.status.2380, 0
  br i1 %helper.ok.2381, label %helper.continue.2382, label %frame.failure.0
helper.continue.2382:
  br label %local.descriptor.checked.2363
local.descriptor.inactive.2362:
  br label %local.descriptor.checked.2363
local.descriptor.checked.2363:
  %local.is.active.2383 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2383, label %local.descriptor.active.2384, label %local.descriptor.inactive.2385
local.descriptor.active.2384:
  %local.check.offset.2387 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2388 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2389 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2390 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2391 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2392 = load i32, ptr %context.field.2391, align 4
  %stack.sub.2395 = sub i32 %local.check.owner.end.2390, %local.check.offset.2387
  %descriptor.owner.inside.2393 = icmp ule i32 %local.check.owner.end.2390, %context.value.2392
  %descriptor.offset.inside.2394 = icmp ule i32 %local.check.offset.2387, %local.check.owner.end.2390
  %descriptor.extent.inside.2396 = icmp ule i32 %local.check.extent.2388, %stack.sub.2395
  %descriptor.payload.inside.2397 = icmp ule i32 %local.check.payload.2389, %local.check.extent.2388
  %descriptor.owner.offset.valid.2398 = and i1 %descriptor.owner.inside.2393, %descriptor.offset.inside.2394
  %descriptor.range.inside.2400 = and i1 %descriptor.owner.offset.valid.2398, %descriptor.extent.inside.2396
  %descriptor.range.valid.2399 = and i1 %descriptor.range.inside.2400, %descriptor.payload.inside.2397
  br i1 %descriptor.range.valid.2399, label %descriptor.valid.2401, label %descriptor.invalid.2402
descriptor.invalid.2402:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2401:
  %descriptor.initialized.status.2403 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2387, i32 %local.check.extent.2388)
  %helper.ok.2404 = icmp eq i32 %descriptor.initialized.status.2403, 0
  br i1 %helper.ok.2404, label %helper.continue.2405, label %frame.failure.0
helper.continue.2405:
  br label %local.descriptor.checked.2386
local.descriptor.inactive.2385:
  br label %local.descriptor.checked.2386
local.descriptor.checked.2386:
  %local.is.active.2406 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2406, label %local.descriptor.active.2407, label %local.descriptor.inactive.2408
local.descriptor.active.2407:
  %local.check.offset.2410 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2411 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2412 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2413 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2414 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2415 = load i32, ptr %context.field.2414, align 4
  %stack.sub.2418 = sub i32 %local.check.owner.end.2413, %local.check.offset.2410
  %descriptor.owner.inside.2416 = icmp ule i32 %local.check.owner.end.2413, %context.value.2415
  %descriptor.offset.inside.2417 = icmp ule i32 %local.check.offset.2410, %local.check.owner.end.2413
  %descriptor.extent.inside.2419 = icmp ule i32 %local.check.extent.2411, %stack.sub.2418
  %descriptor.payload.inside.2420 = icmp ule i32 %local.check.payload.2412, %local.check.extent.2411
  %descriptor.owner.offset.valid.2421 = and i1 %descriptor.owner.inside.2416, %descriptor.offset.inside.2417
  %descriptor.range.inside.2423 = and i1 %descriptor.owner.offset.valid.2421, %descriptor.extent.inside.2419
  %descriptor.range.valid.2422 = and i1 %descriptor.range.inside.2423, %descriptor.payload.inside.2420
  br i1 %descriptor.range.valid.2422, label %descriptor.valid.2424, label %descriptor.invalid.2425
descriptor.invalid.2425:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2424:
  %descriptor.initialized.status.2426 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2410, i32 %local.check.extent.2411)
  %helper.ok.2427 = icmp eq i32 %descriptor.initialized.status.2426, 0
  br i1 %helper.ok.2427, label %helper.continue.2428, label %frame.failure.0
helper.continue.2428:
  br label %local.descriptor.checked.2409
local.descriptor.inactive.2408:
  br label %local.descriptor.checked.2409
local.descriptor.checked.2409:
  %local.is.active.2429 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2429, label %local.descriptor.active.2430, label %local.descriptor.inactive.2431
local.descriptor.active.2430:
  %local.check.offset.2433 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2434 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2435 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2436 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2437 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2438 = load i32, ptr %context.field.2437, align 4
  %stack.sub.2441 = sub i32 %local.check.owner.end.2436, %local.check.offset.2433
  %descriptor.owner.inside.2439 = icmp ule i32 %local.check.owner.end.2436, %context.value.2438
  %descriptor.offset.inside.2440 = icmp ule i32 %local.check.offset.2433, %local.check.owner.end.2436
  %descriptor.extent.inside.2442 = icmp ule i32 %local.check.extent.2434, %stack.sub.2441
  %descriptor.payload.inside.2443 = icmp ule i32 %local.check.payload.2435, %local.check.extent.2434
  %descriptor.owner.offset.valid.2444 = and i1 %descriptor.owner.inside.2439, %descriptor.offset.inside.2440
  %descriptor.range.inside.2446 = and i1 %descriptor.owner.offset.valid.2444, %descriptor.extent.inside.2442
  %descriptor.range.valid.2445 = and i1 %descriptor.range.inside.2446, %descriptor.payload.inside.2443
  br i1 %descriptor.range.valid.2445, label %descriptor.valid.2447, label %descriptor.invalid.2448
descriptor.invalid.2448:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2447:
  %descriptor.initialized.status.2449 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2433, i32 %local.check.extent.2434)
  %helper.ok.2450 = icmp eq i32 %descriptor.initialized.status.2449, 0
  br i1 %helper.ok.2450, label %helper.continue.2451, label %frame.failure.0
helper.continue.2451:
  br label %local.descriptor.checked.2432
local.descriptor.inactive.2431:
  br label %local.descriptor.checked.2432
local.descriptor.checked.2432:
  %step.status.2452 = call i32 @al_owning_charge_step(ptr %ctx, i32 39)
  %helper.ok.2453 = icmp eq i32 %step.status.2452, 0
  br i1 %helper.ok.2453, label %helper.continue.2454, label %frame.failure.0
helper.continue.2454:
  %stack.offset.2455 = add i32 0, %local.resolved.payload.2074
  %stack.offset.2456 = add i32 %stack.offset.2455, %local.resolved.payload.2257
  %stack.offset.2457 = add i32 0, %local.resolved.extent.2073
  %stack.offset.2458 = add i32 %stack.offset.2457, %local.resolved.extent.2256
  %context.field.2459 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2460 = load i32, ptr %context.field.2459, align 4
  %stack.offset.2461 = add i32 %context.value.2460, %stack.offset.2458
  %reserve.status.2462 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.2461, i32 40)
  %reserve.ok.2463 = icmp eq i32 %reserve.status.2462, 0
  br i1 %reserve.ok.2463, label %reserve.continue.2464, label %frame.failure.0
reserve.continue.2464:
  %stack.offset.2465 = add i32 %context.value.2460, 0
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.2465, i32 %local.resolved.offset.2072, i32 %local.resolved.extent.2073, i32 %local.resolved.payload.2074, i32 6, i32 6)
  %context.field.2466 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2467 = load i32, ptr %context.field.2466, align 4
  %runtime.ok.2468 = icmp eq i32 %context.value.2467, 0
  br i1 %runtime.ok.2468, label %runtime.continue.2469, label %frame.failure.0
runtime.continue.2469:
  %stack.offset.2470 = add i32 0, %local.resolved.extent.2073
  %stack.offset.2471 = add i32 %context.value.2460, %stack.offset.2470
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.2471, i32 %local.resolved.offset.2255, i32 %local.resolved.extent.2256, i32 %local.resolved.payload.2257, i32 1, i32 6)
  %context.field.2472 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2473 = load i32, ptr %context.field.2472, align 4
  %runtime.ok.2474 = icmp eq i32 %context.value.2473, 0
  br i1 %runtime.ok.2474, label %runtime.continue.2475, label %frame.failure.0
runtime.continue.2475:
  %stack.offset.2476 = add i32 %stack.offset.2470, %local.resolved.extent.2256
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 5, i32 %context.value.2460, i32 %stack.offset.2458, i32 %stack.offset.2456, i32 0, i32 0)
  %context.field.2477 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2478 = load i32, ptr %context.field.2477, align 4
  %runtime.ok.2479 = icmp eq i32 %context.value.2478, 0
  br i1 %runtime.ok.2479, label %runtime.continue.2480, label %frame.failure.0
runtime.continue.2480:
  %context.field.2481 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2482 = load i32, ptr %context.field.2481, align 4
  %stack.sub.2485 = sub i32 %stack.offset.2461, %context.value.2460
  %descriptor.owner.inside.2483 = icmp ule i32 %stack.offset.2461, %context.value.2482
  %descriptor.offset.inside.2484 = icmp ule i32 %context.value.2460, %stack.offset.2461
  %descriptor.extent.inside.2486 = icmp ule i32 %stack.offset.2458, %stack.sub.2485
  %descriptor.payload.inside.2487 = icmp ule i32 %stack.offset.2456, %stack.offset.2458
  %descriptor.owner.offset.valid.2488 = and i1 %descriptor.owner.inside.2483, %descriptor.offset.inside.2484
  %descriptor.range.inside.2490 = and i1 %descriptor.owner.offset.valid.2488, %descriptor.extent.inside.2486
  %descriptor.range.valid.2489 = and i1 %descriptor.range.inside.2490, %descriptor.payload.inside.2487
  %descriptor.type.valid.2491 = icmp eq i32 5, 5
  %descriptor.valid.2492 = and i1 %descriptor.range.valid.2489, %descriptor.type.valid.2491
  br i1 %descriptor.valid.2492, label %descriptor.valid.2493, label %descriptor.invalid.2494
descriptor.invalid.2494:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2493:
  %descriptor.initialized.status.2495 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.2460, i32 %stack.offset.2458)
  %helper.ok.2496 = icmp eq i32 %descriptor.initialized.status.2495, 0
  br i1 %helper.ok.2496, label %helper.continue.2497, label %frame.failure.0
helper.continue.2497:
  %local.is.active.2498 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2498, label %local.descriptor.active.2499, label %local.descriptor.inactive.2500
local.descriptor.active.2499:
  %local.check.offset.2502 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2503 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2504 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2505 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2506 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2507 = load i32, ptr %context.field.2506, align 4
  %stack.sub.2510 = sub i32 %local.check.owner.end.2505, %local.check.offset.2502
  %descriptor.owner.inside.2508 = icmp ule i32 %local.check.owner.end.2505, %context.value.2507
  %descriptor.offset.inside.2509 = icmp ule i32 %local.check.offset.2502, %local.check.owner.end.2505
  %descriptor.extent.inside.2511 = icmp ule i32 %local.check.extent.2503, %stack.sub.2510
  %descriptor.payload.inside.2512 = icmp ule i32 %local.check.payload.2504, %local.check.extent.2503
  %descriptor.owner.offset.valid.2513 = and i1 %descriptor.owner.inside.2508, %descriptor.offset.inside.2509
  %descriptor.range.inside.2515 = and i1 %descriptor.owner.offset.valid.2513, %descriptor.extent.inside.2511
  %descriptor.range.valid.2514 = and i1 %descriptor.range.inside.2515, %descriptor.payload.inside.2512
  br i1 %descriptor.range.valid.2514, label %descriptor.valid.2516, label %descriptor.invalid.2517
descriptor.invalid.2517:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2516:
  %descriptor.initialized.status.2518 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2502, i32 %local.check.extent.2503)
  %helper.ok.2519 = icmp eq i32 %descriptor.initialized.status.2518, 0
  br i1 %helper.ok.2519, label %helper.continue.2520, label %frame.failure.0
helper.continue.2520:
  br label %local.descriptor.checked.2501
local.descriptor.inactive.2500:
  br label %local.descriptor.checked.2501
local.descriptor.checked.2501:
  %local.is.active.2521 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2521, label %local.descriptor.active.2522, label %local.descriptor.inactive.2523
local.descriptor.active.2522:
  %local.check.offset.2525 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2526 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2527 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2528 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2529 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2530 = load i32, ptr %context.field.2529, align 4
  %stack.sub.2533 = sub i32 %local.check.owner.end.2528, %local.check.offset.2525
  %descriptor.owner.inside.2531 = icmp ule i32 %local.check.owner.end.2528, %context.value.2530
  %descriptor.offset.inside.2532 = icmp ule i32 %local.check.offset.2525, %local.check.owner.end.2528
  %descriptor.extent.inside.2534 = icmp ule i32 %local.check.extent.2526, %stack.sub.2533
  %descriptor.payload.inside.2535 = icmp ule i32 %local.check.payload.2527, %local.check.extent.2526
  %descriptor.owner.offset.valid.2536 = and i1 %descriptor.owner.inside.2531, %descriptor.offset.inside.2532
  %descriptor.range.inside.2538 = and i1 %descriptor.owner.offset.valid.2536, %descriptor.extent.inside.2534
  %descriptor.range.valid.2537 = and i1 %descriptor.range.inside.2538, %descriptor.payload.inside.2535
  br i1 %descriptor.range.valid.2537, label %descriptor.valid.2539, label %descriptor.invalid.2540
descriptor.invalid.2540:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2539:
  %descriptor.initialized.status.2541 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2525, i32 %local.check.extent.2526)
  %helper.ok.2542 = icmp eq i32 %descriptor.initialized.status.2541, 0
  br i1 %helper.ok.2542, label %helper.continue.2543, label %frame.failure.0
helper.continue.2543:
  br label %local.descriptor.checked.2524
local.descriptor.inactive.2523:
  br label %local.descriptor.checked.2524
local.descriptor.checked.2524:
  %local.is.active.2544 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2544, label %local.descriptor.active.2545, label %local.descriptor.inactive.2546
local.descriptor.active.2545:
  %local.check.offset.2548 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2549 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2550 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2551 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2552 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2553 = load i32, ptr %context.field.2552, align 4
  %stack.sub.2556 = sub i32 %local.check.owner.end.2551, %local.check.offset.2548
  %descriptor.owner.inside.2554 = icmp ule i32 %local.check.owner.end.2551, %context.value.2553
  %descriptor.offset.inside.2555 = icmp ule i32 %local.check.offset.2548, %local.check.owner.end.2551
  %descriptor.extent.inside.2557 = icmp ule i32 %local.check.extent.2549, %stack.sub.2556
  %descriptor.payload.inside.2558 = icmp ule i32 %local.check.payload.2550, %local.check.extent.2549
  %descriptor.owner.offset.valid.2559 = and i1 %descriptor.owner.inside.2554, %descriptor.offset.inside.2555
  %descriptor.range.inside.2561 = and i1 %descriptor.owner.offset.valid.2559, %descriptor.extent.inside.2557
  %descriptor.range.valid.2560 = and i1 %descriptor.range.inside.2561, %descriptor.payload.inside.2558
  br i1 %descriptor.range.valid.2560, label %descriptor.valid.2562, label %descriptor.invalid.2563
descriptor.invalid.2563:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2562:
  %descriptor.initialized.status.2564 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2548, i32 %local.check.extent.2549)
  %helper.ok.2565 = icmp eq i32 %descriptor.initialized.status.2564, 0
  br i1 %helper.ok.2565, label %helper.continue.2566, label %frame.failure.0
helper.continue.2566:
  br label %local.descriptor.checked.2547
local.descriptor.inactive.2546:
  br label %local.descriptor.checked.2547
local.descriptor.checked.2547:
  %local.is.active.2567 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2567, label %local.descriptor.active.2568, label %local.descriptor.inactive.2569
local.descriptor.active.2568:
  %local.check.offset.2571 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2572 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2573 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2574 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2575 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2576 = load i32, ptr %context.field.2575, align 4
  %stack.sub.2579 = sub i32 %local.check.owner.end.2574, %local.check.offset.2571
  %descriptor.owner.inside.2577 = icmp ule i32 %local.check.owner.end.2574, %context.value.2576
  %descriptor.offset.inside.2578 = icmp ule i32 %local.check.offset.2571, %local.check.owner.end.2574
  %descriptor.extent.inside.2580 = icmp ule i32 %local.check.extent.2572, %stack.sub.2579
  %descriptor.payload.inside.2581 = icmp ule i32 %local.check.payload.2573, %local.check.extent.2572
  %descriptor.owner.offset.valid.2582 = and i1 %descriptor.owner.inside.2577, %descriptor.offset.inside.2578
  %descriptor.range.inside.2584 = and i1 %descriptor.owner.offset.valid.2582, %descriptor.extent.inside.2580
  %descriptor.range.valid.2583 = and i1 %descriptor.range.inside.2584, %descriptor.payload.inside.2581
  br i1 %descriptor.range.valid.2583, label %descriptor.valid.2585, label %descriptor.invalid.2586
descriptor.invalid.2586:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2585:
  %descriptor.initialized.status.2587 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2571, i32 %local.check.extent.2572)
  %helper.ok.2588 = icmp eq i32 %descriptor.initialized.status.2587, 0
  br i1 %helper.ok.2588, label %helper.continue.2589, label %frame.failure.0
helper.continue.2589:
  br label %local.descriptor.checked.2570
local.descriptor.inactive.2569:
  br label %local.descriptor.checked.2570
local.descriptor.checked.2570:
  %local.is.active.2590 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2590, label %local.descriptor.active.2591, label %local.descriptor.inactive.2592
local.descriptor.active.2591:
  %local.check.offset.2594 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2595 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2596 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2597 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2598 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2599 = load i32, ptr %context.field.2598, align 4
  %stack.sub.2602 = sub i32 %local.check.owner.end.2597, %local.check.offset.2594
  %descriptor.owner.inside.2600 = icmp ule i32 %local.check.owner.end.2597, %context.value.2599
  %descriptor.offset.inside.2601 = icmp ule i32 %local.check.offset.2594, %local.check.owner.end.2597
  %descriptor.extent.inside.2603 = icmp ule i32 %local.check.extent.2595, %stack.sub.2602
  %descriptor.payload.inside.2604 = icmp ule i32 %local.check.payload.2596, %local.check.extent.2595
  %descriptor.owner.offset.valid.2605 = and i1 %descriptor.owner.inside.2600, %descriptor.offset.inside.2601
  %descriptor.range.inside.2607 = and i1 %descriptor.owner.offset.valid.2605, %descriptor.extent.inside.2603
  %descriptor.range.valid.2606 = and i1 %descriptor.range.inside.2607, %descriptor.payload.inside.2604
  br i1 %descriptor.range.valid.2606, label %descriptor.valid.2608, label %descriptor.invalid.2609
descriptor.invalid.2609:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2608:
  %descriptor.initialized.status.2610 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2594, i32 %local.check.extent.2595)
  %helper.ok.2611 = icmp eq i32 %descriptor.initialized.status.2610, 0
  br i1 %helper.ok.2611, label %helper.continue.2612, label %frame.failure.0
helper.continue.2612:
  br label %local.descriptor.checked.2593
local.descriptor.inactive.2592:
  br label %local.descriptor.checked.2593
local.descriptor.checked.2593:
  %local.is.active.2613 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2613, label %local.descriptor.active.2614, label %local.descriptor.inactive.2615
local.descriptor.active.2614:
  %local.check.offset.2617 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2618 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2619 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2620 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2621 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2622 = load i32, ptr %context.field.2621, align 4
  %stack.sub.2625 = sub i32 %local.check.owner.end.2620, %local.check.offset.2617
  %descriptor.owner.inside.2623 = icmp ule i32 %local.check.owner.end.2620, %context.value.2622
  %descriptor.offset.inside.2624 = icmp ule i32 %local.check.offset.2617, %local.check.owner.end.2620
  %descriptor.extent.inside.2626 = icmp ule i32 %local.check.extent.2618, %stack.sub.2625
  %descriptor.payload.inside.2627 = icmp ule i32 %local.check.payload.2619, %local.check.extent.2618
  %descriptor.owner.offset.valid.2628 = and i1 %descriptor.owner.inside.2623, %descriptor.offset.inside.2624
  %descriptor.range.inside.2630 = and i1 %descriptor.owner.offset.valid.2628, %descriptor.extent.inside.2626
  %descriptor.range.valid.2629 = and i1 %descriptor.range.inside.2630, %descriptor.payload.inside.2627
  br i1 %descriptor.range.valid.2629, label %descriptor.valid.2631, label %descriptor.invalid.2632
descriptor.invalid.2632:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2631:
  %descriptor.initialized.status.2633 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2617, i32 %local.check.extent.2618)
  %helper.ok.2634 = icmp eq i32 %descriptor.initialized.status.2633, 0
  br i1 %helper.ok.2634, label %helper.continue.2635, label %frame.failure.0
helper.continue.2635:
  br label %local.descriptor.checked.2616
local.descriptor.inactive.2615:
  br label %local.descriptor.checked.2616
local.descriptor.checked.2616:
  store i1 false, ptr %local.active.32, align 1
  store i32 0, ptr %local.offset.33, align 4
  store i32 0, ptr %local.extent.34, align 4
  store i32 0, ptr %local.payload.35, align 4
  store i32 0, ptr %local.owner.end.36, align 4
  store i32 0, ptr %local.type.37, align 4
  store i1 false, ptr %local.active.26, align 1
  store i32 0, ptr %local.offset.27, align 4
  store i32 0, ptr %local.extent.28, align 4
  store i32 0, ptr %local.payload.29, align 4
  store i32 0, ptr %local.owner.end.30, align 4
  store i32 0, ptr %local.type.31, align 4
  %context.field.2636 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2637 = load i32, ptr %context.field.2636, align 4
  %stack.sub.2640 = sub i32 %stack.offset.2461, %context.value.2460
  %descriptor.owner.inside.2638 = icmp ule i32 %stack.offset.2461, %context.value.2637
  %descriptor.offset.inside.2639 = icmp ule i32 %context.value.2460, %stack.offset.2461
  %descriptor.extent.inside.2641 = icmp ule i32 %stack.offset.2458, %stack.sub.2640
  %descriptor.payload.inside.2642 = icmp ule i32 %stack.offset.2456, %stack.offset.2458
  %descriptor.owner.offset.valid.2643 = and i1 %descriptor.owner.inside.2638, %descriptor.offset.inside.2639
  %descriptor.range.inside.2645 = and i1 %descriptor.owner.offset.valid.2643, %descriptor.extent.inside.2641
  %descriptor.range.valid.2644 = and i1 %descriptor.range.inside.2645, %descriptor.payload.inside.2642
  %descriptor.type.valid.2646 = icmp eq i32 5, 5
  %descriptor.valid.2647 = and i1 %descriptor.range.valid.2644, %descriptor.type.valid.2646
  br i1 %descriptor.valid.2647, label %descriptor.valid.2648, label %descriptor.invalid.2649
descriptor.invalid.2649:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2648:
  %descriptor.initialized.status.2650 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.2460, i32 %stack.offset.2458)
  %helper.ok.2651 = icmp eq i32 %descriptor.initialized.status.2650, 0
  br i1 %helper.ok.2651, label %helper.continue.2652, label %frame.failure.0
helper.continue.2652:
  %local.is.active.2653 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2653, label %local.descriptor.active.2654, label %local.descriptor.inactive.2655
local.descriptor.active.2654:
  %local.check.offset.2657 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2658 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2659 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2660 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2661 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2662 = load i32, ptr %context.field.2661, align 4
  %stack.sub.2665 = sub i32 %local.check.owner.end.2660, %local.check.offset.2657
  %descriptor.owner.inside.2663 = icmp ule i32 %local.check.owner.end.2660, %context.value.2662
  %descriptor.offset.inside.2664 = icmp ule i32 %local.check.offset.2657, %local.check.owner.end.2660
  %descriptor.extent.inside.2666 = icmp ule i32 %local.check.extent.2658, %stack.sub.2665
  %descriptor.payload.inside.2667 = icmp ule i32 %local.check.payload.2659, %local.check.extent.2658
  %descriptor.owner.offset.valid.2668 = and i1 %descriptor.owner.inside.2663, %descriptor.offset.inside.2664
  %descriptor.range.inside.2670 = and i1 %descriptor.owner.offset.valid.2668, %descriptor.extent.inside.2666
  %descriptor.range.valid.2669 = and i1 %descriptor.range.inside.2670, %descriptor.payload.inside.2667
  br i1 %descriptor.range.valid.2669, label %descriptor.valid.2671, label %descriptor.invalid.2672
descriptor.invalid.2672:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2671:
  %descriptor.initialized.status.2673 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2657, i32 %local.check.extent.2658)
  %helper.ok.2674 = icmp eq i32 %descriptor.initialized.status.2673, 0
  br i1 %helper.ok.2674, label %helper.continue.2675, label %frame.failure.0
helper.continue.2675:
  br label %local.descriptor.checked.2656
local.descriptor.inactive.2655:
  br label %local.descriptor.checked.2656
local.descriptor.checked.2656:
  %local.is.active.2676 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2676, label %local.descriptor.active.2677, label %local.descriptor.inactive.2678
local.descriptor.active.2677:
  %local.check.offset.2680 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2681 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2682 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2683 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2684 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2685 = load i32, ptr %context.field.2684, align 4
  %stack.sub.2688 = sub i32 %local.check.owner.end.2683, %local.check.offset.2680
  %descriptor.owner.inside.2686 = icmp ule i32 %local.check.owner.end.2683, %context.value.2685
  %descriptor.offset.inside.2687 = icmp ule i32 %local.check.offset.2680, %local.check.owner.end.2683
  %descriptor.extent.inside.2689 = icmp ule i32 %local.check.extent.2681, %stack.sub.2688
  %descriptor.payload.inside.2690 = icmp ule i32 %local.check.payload.2682, %local.check.extent.2681
  %descriptor.owner.offset.valid.2691 = and i1 %descriptor.owner.inside.2686, %descriptor.offset.inside.2687
  %descriptor.range.inside.2693 = and i1 %descriptor.owner.offset.valid.2691, %descriptor.extent.inside.2689
  %descriptor.range.valid.2692 = and i1 %descriptor.range.inside.2693, %descriptor.payload.inside.2690
  br i1 %descriptor.range.valid.2692, label %descriptor.valid.2694, label %descriptor.invalid.2695
descriptor.invalid.2695:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2694:
  %descriptor.initialized.status.2696 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2680, i32 %local.check.extent.2681)
  %helper.ok.2697 = icmp eq i32 %descriptor.initialized.status.2696, 0
  br i1 %helper.ok.2697, label %helper.continue.2698, label %frame.failure.0
helper.continue.2698:
  br label %local.descriptor.checked.2679
local.descriptor.inactive.2678:
  br label %local.descriptor.checked.2679
local.descriptor.checked.2679:
  %local.is.active.2699 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2699, label %local.descriptor.active.2700, label %local.descriptor.inactive.2701
local.descriptor.active.2700:
  %local.check.offset.2703 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2704 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2705 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2706 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2707 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2708 = load i32, ptr %context.field.2707, align 4
  %stack.sub.2711 = sub i32 %local.check.owner.end.2706, %local.check.offset.2703
  %descriptor.owner.inside.2709 = icmp ule i32 %local.check.owner.end.2706, %context.value.2708
  %descriptor.offset.inside.2710 = icmp ule i32 %local.check.offset.2703, %local.check.owner.end.2706
  %descriptor.extent.inside.2712 = icmp ule i32 %local.check.extent.2704, %stack.sub.2711
  %descriptor.payload.inside.2713 = icmp ule i32 %local.check.payload.2705, %local.check.extent.2704
  %descriptor.owner.offset.valid.2714 = and i1 %descriptor.owner.inside.2709, %descriptor.offset.inside.2710
  %descriptor.range.inside.2716 = and i1 %descriptor.owner.offset.valid.2714, %descriptor.extent.inside.2712
  %descriptor.range.valid.2715 = and i1 %descriptor.range.inside.2716, %descriptor.payload.inside.2713
  br i1 %descriptor.range.valid.2715, label %descriptor.valid.2717, label %descriptor.invalid.2718
descriptor.invalid.2718:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2717:
  %descriptor.initialized.status.2719 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2703, i32 %local.check.extent.2704)
  %helper.ok.2720 = icmp eq i32 %descriptor.initialized.status.2719, 0
  br i1 %helper.ok.2720, label %helper.continue.2721, label %frame.failure.0
helper.continue.2721:
  br label %local.descriptor.checked.2702
local.descriptor.inactive.2701:
  br label %local.descriptor.checked.2702
local.descriptor.checked.2702:
  %local.is.active.2722 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2722, label %local.descriptor.active.2723, label %local.descriptor.inactive.2724
local.descriptor.active.2723:
  %local.check.offset.2726 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2727 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2728 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2729 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2730 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2731 = load i32, ptr %context.field.2730, align 4
  %stack.sub.2734 = sub i32 %local.check.owner.end.2729, %local.check.offset.2726
  %descriptor.owner.inside.2732 = icmp ule i32 %local.check.owner.end.2729, %context.value.2731
  %descriptor.offset.inside.2733 = icmp ule i32 %local.check.offset.2726, %local.check.owner.end.2729
  %descriptor.extent.inside.2735 = icmp ule i32 %local.check.extent.2727, %stack.sub.2734
  %descriptor.payload.inside.2736 = icmp ule i32 %local.check.payload.2728, %local.check.extent.2727
  %descriptor.owner.offset.valid.2737 = and i1 %descriptor.owner.inside.2732, %descriptor.offset.inside.2733
  %descriptor.range.inside.2739 = and i1 %descriptor.owner.offset.valid.2737, %descriptor.extent.inside.2735
  %descriptor.range.valid.2738 = and i1 %descriptor.range.inside.2739, %descriptor.payload.inside.2736
  br i1 %descriptor.range.valid.2738, label %descriptor.valid.2740, label %descriptor.invalid.2741
descriptor.invalid.2741:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2740:
  %descriptor.initialized.status.2742 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2726, i32 %local.check.extent.2727)
  %helper.ok.2743 = icmp eq i32 %descriptor.initialized.status.2742, 0
  br i1 %helper.ok.2743, label %helper.continue.2744, label %frame.failure.0
helper.continue.2744:
  br label %local.descriptor.checked.2725
local.descriptor.inactive.2724:
  br label %local.descriptor.checked.2725
local.descriptor.checked.2725:
  %local.is.active.2745 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2745, label %local.descriptor.active.2746, label %local.descriptor.inactive.2747
local.descriptor.active.2746:
  %local.check.offset.2749 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2750 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2751 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2752 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2753 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2754 = load i32, ptr %context.field.2753, align 4
  %stack.sub.2757 = sub i32 %local.check.owner.end.2752, %local.check.offset.2749
  %descriptor.owner.inside.2755 = icmp ule i32 %local.check.owner.end.2752, %context.value.2754
  %descriptor.offset.inside.2756 = icmp ule i32 %local.check.offset.2749, %local.check.owner.end.2752
  %descriptor.extent.inside.2758 = icmp ule i32 %local.check.extent.2750, %stack.sub.2757
  %descriptor.payload.inside.2759 = icmp ule i32 %local.check.payload.2751, %local.check.extent.2750
  %descriptor.owner.offset.valid.2760 = and i1 %descriptor.owner.inside.2755, %descriptor.offset.inside.2756
  %descriptor.range.inside.2762 = and i1 %descriptor.owner.offset.valid.2760, %descriptor.extent.inside.2758
  %descriptor.range.valid.2761 = and i1 %descriptor.range.inside.2762, %descriptor.payload.inside.2759
  br i1 %descriptor.range.valid.2761, label %descriptor.valid.2763, label %descriptor.invalid.2764
descriptor.invalid.2764:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2763:
  %descriptor.initialized.status.2765 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2749, i32 %local.check.extent.2750)
  %helper.ok.2766 = icmp eq i32 %descriptor.initialized.status.2765, 0
  br i1 %helper.ok.2766, label %helper.continue.2767, label %frame.failure.0
helper.continue.2767:
  br label %local.descriptor.checked.2748
local.descriptor.inactive.2747:
  br label %local.descriptor.checked.2748
local.descriptor.checked.2748:
  %local.is.active.2768 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2768, label %local.descriptor.active.2769, label %local.descriptor.inactive.2770
local.descriptor.active.2769:
  %local.check.offset.2772 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2773 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2774 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2775 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2776 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2777 = load i32, ptr %context.field.2776, align 4
  %stack.sub.2780 = sub i32 %local.check.owner.end.2775, %local.check.offset.2772
  %descriptor.owner.inside.2778 = icmp ule i32 %local.check.owner.end.2775, %context.value.2777
  %descriptor.offset.inside.2779 = icmp ule i32 %local.check.offset.2772, %local.check.owner.end.2775
  %descriptor.extent.inside.2781 = icmp ule i32 %local.check.extent.2773, %stack.sub.2780
  %descriptor.payload.inside.2782 = icmp ule i32 %local.check.payload.2774, %local.check.extent.2773
  %descriptor.owner.offset.valid.2783 = and i1 %descriptor.owner.inside.2778, %descriptor.offset.inside.2779
  %descriptor.range.inside.2785 = and i1 %descriptor.owner.offset.valid.2783, %descriptor.extent.inside.2781
  %descriptor.range.valid.2784 = and i1 %descriptor.range.inside.2785, %descriptor.payload.inside.2782
  br i1 %descriptor.range.valid.2784, label %descriptor.valid.2786, label %descriptor.invalid.2787
descriptor.invalid.2787:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2786:
  %descriptor.initialized.status.2788 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2772, i32 %local.check.extent.2773)
  %helper.ok.2789 = icmp eq i32 %descriptor.initialized.status.2788, 0
  br i1 %helper.ok.2789, label %helper.continue.2790, label %frame.failure.0
helper.continue.2790:
  br label %local.descriptor.checked.2771
local.descriptor.inactive.2770:
  br label %local.descriptor.checked.2771
local.descriptor.checked.2771:
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %descriptor.element.2791 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.2792 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.2791, i32 0, i32 0
  store i32 5, ptr %descriptor.field.2792, align 4
  %descriptor.field.2793 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.2791, i32 0, i32 1
  store i32 %context.value.2460, ptr %descriptor.field.2793, align 4
  %descriptor.field.2794 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.2791, i32 0, i32 2
  store i32 %stack.offset.2458, ptr %descriptor.field.2794, align 4
  %descriptor.field.2795 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.2791, i32 0, i32 3
  store i32 %stack.offset.2456, ptr %descriptor.field.2795, align 4
  %descriptor.field.2796 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.2791, i32 0, i32 4
  store i32 %stack.offset.2461, ptr %descriptor.field.2796, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %context.value.2460, i32 20, i32 %stack.offset.2456, i32 %stack.offset.2461, i32 %stack.offset.2458)
  %context.field.2797 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2798 = load i32, ptr %context.field.2797, align 4
  %runtime.ok.2799 = icmp eq i32 %context.value.2798, 0
  br i1 %runtime.ok.2799, label %runtime.continue.2800, label %frame.failure.0
runtime.continue.2800:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.39, i32 0, i32 0, i32 0)
  %context.field.2801 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.2802 = load i32, ptr %context.field.2801, align 4
  %context.field.2803 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.2804 = load i32, ptr %context.field.2803, align 4
  %context.field.2805 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.2806 = load i32, ptr %context.field.2805, align 4
  %stack.offset.2807 = add i32 %context.value.41, %context.value.43
  %stack.offset.2808 = add i32 %context.value.2802, %context.value.2804
  %stack.sub.2809 = sub i32 %stack.offset.2807, %stack.offset.2808
  %stack.sub.2810 = sub i32 %context.value.43, %context.value.2804
  %stack.sub.2811 = sub i32 %context.value.2806, %context.value.45
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.2809, i32 %stack.sub.2810)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.2811)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 2
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 2, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %entry.input.descriptors.10 = alloca [2 x %AlOwningDescriptor], align 4
  %input.extent.pointer.11 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.12 = load i32, ptr %input.extent.pointer.11, align 4
  %host.pointer.13 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.14 = alloca i32, align 4
  %input.measured.extent.pointer.15 = alloca i32, align 4
  %input.measure.status.16 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 3, ptr %host.pointer.13, i32 %input.host.extent.12, i32 0, i32 41, ptr %input.payload.pointer.14, ptr %input.measured.extent.pointer.15)
  %helper.ok.17 = icmp eq i32 %input.measure.status.16, 0
  br i1 %helper.ok.17, label %helper.continue.18, label %entry.failure.0
helper.continue.18:
  %input.measured.payload.19 = load i32, ptr %input.payload.pointer.14, align 4
  %input.measured.extent.20 = load i32, ptr %input.measured.extent.pointer.15, align 4
  %input.extent.exact.21 = icmp eq i32 %input.measured.extent.20, %input.host.extent.12
  br i1 %input.extent.exact.21, label %input.extent.exact.22, label %input.extent.invalid.23
input.extent.invalid.23:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 41, i32 %input.measured.extent.20, i32 %input.host.extent.12)
  br label %entry.failure.0
input.extent.exact.22:
  %stack.offset.24 = add i32 0, %input.host.extent.12
  %input.extent.pointer.25 = getelementptr inbounds i32, ptr %input.extents, i32 1
  %input.host.extent.26 = load i32, ptr %input.extent.pointer.25, align 4
  %host.pointer.27 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.24
  %input.payload.pointer.28 = alloca i32, align 4
  %input.measured.extent.pointer.29 = alloca i32, align 4
  %input.measure.status.30 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 0, ptr %host.pointer.27, i32 %input.host.extent.26, i32 0, i32 42, ptr %input.payload.pointer.28, ptr %input.measured.extent.pointer.29)
  %helper.ok.31 = icmp eq i32 %input.measure.status.30, 0
  br i1 %helper.ok.31, label %helper.continue.32, label %entry.failure.0
helper.continue.32:
  %input.measured.payload.33 = load i32, ptr %input.payload.pointer.28, align 4
  %input.measured.extent.34 = load i32, ptr %input.measured.extent.pointer.29, align 4
  %input.extent.exact.35 = icmp eq i32 %input.measured.extent.34, %input.host.extent.26
  br i1 %input.extent.exact.35, label %input.extent.exact.36, label %input.extent.invalid.37
input.extent.invalid.37:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 42, i32 %input.measured.extent.34, i32 %input.host.extent.26)
  br label %entry.failure.0
input.extent.exact.36:
  %stack.offset.38 = add i32 %stack.offset.24, %input.host.extent.26
  %input.total.exact.39 = icmp eq i32 %stack.offset.38, %input.bytes
  br i1 %input.total.exact.39, label %input.valid.40, label %input.invalid.41
input.invalid.41:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.38, i32 %input.bytes)
  br label %entry.failure.0
input.valid.40:
  %reserve.status.42 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.38, i32 43)
  %reserve.ok.43 = icmp eq i32 %reserve.status.42, 0
  br i1 %reserve.ok.43, label %reserve.continue.44, label %entry.failure.0
reserve.continue.44:
  %host.pointer.45 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.46 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.45, i32 %input.host.extent.12, i32 0, i32 %input.measured.payload.19, i32 %input.host.extent.12, i32 7, i32 44)
  %helper.ok.47 = icmp eq i32 %input.copy.status.46, 0
  br i1 %helper.ok.47, label %helper.continue.48, label %entry.failure.0
helper.continue.48:
  %stack.offset.49 = add i32 0, %input.host.extent.12
  %descriptor.element.50 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.10, i32 0
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 0
  store i32 7, ptr %descriptor.field.51, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 1
  store i32 0, ptr %descriptor.field.52, align 4
  %descriptor.field.53 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 2
  store i32 %input.host.extent.12, ptr %descriptor.field.53, align 4
  %descriptor.field.54 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 3
  store i32 %input.measured.payload.19, ptr %descriptor.field.54, align 4
  %descriptor.field.55 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 4
  store i32 %stack.offset.49, ptr %descriptor.field.55, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 7, i32 0, i32 20, i32 %input.measured.payload.19, i32 %stack.offset.49, i32 %input.host.extent.12)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %entry.failure.0
runtime.continue.59:
  %host.pointer.60 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.24
  %input.copy.status.61 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.24, ptr %host.pointer.60, i32 %input.host.extent.26, i32 0, i32 %input.measured.payload.33, i32 %input.host.extent.26, i32 1, i32 45)
  %helper.ok.62 = icmp eq i32 %input.copy.status.61, 0
  br i1 %helper.ok.62, label %helper.continue.63, label %entry.failure.0
helper.continue.63:
  %stack.offset.64 = add i32 %stack.offset.24, %input.host.extent.26
  %descriptor.element.65 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.10, i32 1
  %descriptor.field.66 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.65, i32 0, i32 0
  store i32 1, ptr %descriptor.field.66, align 4
  %descriptor.field.67 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.65, i32 0, i32 1
  store i32 %stack.offset.24, ptr %descriptor.field.67, align 4
  %descriptor.field.68 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.65, i32 0, i32 2
  store i32 %input.host.extent.26, ptr %descriptor.field.68, align 4
  %descriptor.field.69 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.65, i32 0, i32 3
  store i32 %input.measured.payload.33, ptr %descriptor.field.69, align 4
  %descriptor.field.70 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.65, i32 0, i32 4
  store i32 %stack.offset.64, ptr %descriptor.field.70, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %stack.offset.24, i32 20, i32 %input.measured.payload.33, i32 %stack.offset.64, i32 %input.host.extent.26)
  %context.field.71 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.72 = load i32, ptr %context.field.71, align 4
  %runtime.ok.73 = icmp eq i32 %context.value.72, 0
  br i1 %runtime.ok.73, label %runtime.continue.74, label %entry.failure.0
runtime.continue.74:
  %entry.output.descriptors.75 = alloca [1 x %AlOwningDescriptor], align 4
  %entry.body.status.76 = call i32 @agentlang_entry_frame(ptr %ctx, ptr %entry.input.descriptors.10, ptr %entry.output.descriptors.75, i32 46)
  %entry.body.ok.77 = icmp eq i32 %entry.body.status.76, 0
  br i1 %entry.body.ok.77, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.78 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.75, i32 0
  %descriptor.field.79 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.78, i32 0, i32 0
  %descriptor.value.80 = load i32, ptr %descriptor.field.79, align 4
  %descriptor.field.81 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.78, i32 0, i32 1
  %descriptor.value.82 = load i32, ptr %descriptor.field.81, align 4
  %descriptor.field.83 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.78, i32 0, i32 2
  %descriptor.value.84 = load i32, ptr %descriptor.field.83, align 4
  %descriptor.field.85 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.78, i32 0, i32 3
  %descriptor.value.86 = load i32, ptr %descriptor.field.85, align 4
  %descriptor.field.87 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.78, i32 0, i32 4
  %descriptor.value.88 = load i32, ptr %descriptor.field.87, align 4
  %entry.output.type.valid.89 = icmp eq i32 %descriptor.value.80, 1
  br i1 %entry.output.type.valid.89, label %entry.output.type.ok.90, label %entry.output.type.invalid.91
entry.output.type.invalid.91:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.90:
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %stack.sub.96 = sub i32 %descriptor.value.88, %descriptor.value.82
  %descriptor.owner.inside.94 = icmp ule i32 %descriptor.value.88, %context.value.93
  %descriptor.offset.inside.95 = icmp ule i32 %descriptor.value.82, %descriptor.value.88
  %descriptor.extent.inside.97 = icmp ule i32 %descriptor.value.84, %stack.sub.96
  %descriptor.payload.inside.98 = icmp ule i32 %descriptor.value.86, %descriptor.value.84
  %descriptor.owner.offset.valid.99 = and i1 %descriptor.owner.inside.94, %descriptor.offset.inside.95
  %descriptor.range.inside.101 = and i1 %descriptor.owner.offset.valid.99, %descriptor.extent.inside.97
  %descriptor.range.valid.100 = and i1 %descriptor.range.inside.101, %descriptor.payload.inside.98
  %descriptor.type.valid.102 = icmp eq i32 1, 1
  %descriptor.valid.103 = and i1 %descriptor.range.valid.100, %descriptor.type.valid.102
  br i1 %descriptor.valid.103, label %descriptor.valid.104, label %descriptor.invalid.105
descriptor.invalid.105:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.104:
  %descriptor.initialized.status.106 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.82, i32 %descriptor.value.84)
  %helper.ok.107 = icmp eq i32 %descriptor.initialized.status.106, 0
  br i1 %helper.ok.107, label %helper.continue.108, label %entry.failure.0
helper.continue.108:
  %entry.output.size.i64.109 = zext i32 %descriptor.value.84 to i64
  %entry.output.total.i64.110 = add i64 0, %entry.output.size.i64.109
  %entry.retained.capacity.i64.111 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.112 = icmp ule i64 %entry.output.total.i64.110, 4294967295
  %entry.retained.required.truncated.113 = trunc i64 %entry.output.total.i64.110 to i32
  %entry.retained.required.114 = select i1 %entry.retained.required.fits.u32.112, i32 %entry.retained.required.truncated.113, i32 4294967295
  %entry.retained.capacity.ok.115 = icmp ule i64 %entry.output.total.i64.110, %entry.retained.capacity.i64.111
  br i1 %entry.retained.capacity.ok.115, label %entry.retained.capacity.ready.116, label %entry.retained.capacity.failure.117
entry.retained.capacity.failure.117:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.114, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.116:
  %host.pointer.118 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.119 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.118, i32 %stack.sub.119, i32 %descriptor.value.82, i32 %descriptor.value.84, i32 1)
  %context.field.120 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.121 = load i32, ptr %context.field.120, align 4
  %runtime.ok.122 = icmp eq i32 %context.value.121, 0
  br i1 %runtime.ok.122, label %runtime.continue.123, label %entry.failure.0
runtime.continue.123:
  %stack.offset.124 = add i32 0, %descriptor.value.84
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.125 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.126 = load i32, ptr %context.field.125, align 4
  %context.field.127 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.128 = load i32, ptr %context.field.127, align 4
  %stack.sub.129 = sub i32 0, %context.value.126
  %stack.sub.130 = sub i32 0, %context.value.128
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.129, i32 %stack.sub.130)
  %context.field.131 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.132 = load i32, ptr %context.field.131, align 4
  %runtime.ok.133 = icmp eq i32 %context.value.132, 0
  br i1 %runtime.ok.133, label %runtime.continue.134, label %entry.failure.0
runtime.continue.134:
  br label %entry.return.status
entry.failure.0:
  %context.field.135 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.136 = load i32, ptr %context.field.135, align 4
  %context.field.137 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.138 = load i32, ptr %context.field.137, align 4
  %context.field.139 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.140 = load i32, ptr %context.field.139, align 4
  %stack.offset.141 = add i32 %context.value.136, %context.value.138
  %stack.sub.142 = sub i32 0, %stack.offset.141
  %stack.sub.143 = sub i32 0, %context.value.138
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.142, i32 %stack.sub.143)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.140)
  br label %entry.return.status
entry.return.status:
  %context.field.144 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.145 = load i32, ptr %context.field.144, align 4
  ret i32 %context.value.145
}


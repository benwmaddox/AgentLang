%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [1 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 5, i32 12, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8 }], align 4
@al_owning_fields = private constant [1 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 0, i32 0, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 1, ptr @al_owning_types, i32 1, ptr @al_owning_fields, i32 0 }, align 8
@al_owning_string_literal_0 = private unnamed_addr constant [16 x i8] c"\01\00\00\00\00\00\00\00\7A\00\00\00\00\00\00\00", align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %local.active.2 = alloca i1, align 1
  %local.offset.3 = alloca i32, align 4
  %local.extent.4 = alloca i32, align 4
  %local.payload.5 = alloca i32, align 4
  %local.owner.end.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %local.active.8 = alloca i1, align 1
  %local.offset.9 = alloca i32, align 4
  %local.extent.10 = alloca i32, align 4
  %local.payload.11 = alloca i32, align 4
  %local.owner.end.12 = alloca i32, align 4
  %local.type.13 = alloca i32, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  %local.active.14 = alloca i1, align 1
  %local.offset.15 = alloca i32, align 4
  %local.extent.16 = alloca i32, align 4
  %local.payload.17 = alloca i32, align 4
  %local.owner.end.18 = alloca i32, align 4
  %local.type.19 = alloca i32, align 4
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  %local.active.20 = alloca i1, align 1
  %local.offset.21 = alloca i32, align 4
  %local.extent.22 = alloca i32, align 4
  %local.payload.23 = alloca i32, align 4
  %local.owner.end.24 = alloca i32, align 4
  %local.type.25 = alloca i32, align 4
  store i1 false, ptr %local.active.20, align 1
  store i32 0, ptr %local.offset.21, align 4
  store i32 0, ptr %local.extent.22, align 4
  store i32 0, ptr %local.payload.23, align 4
  store i32 0, ptr %local.owner.end.24, align 4
  store i32 0, ptr %local.type.25, align 4
  %local.active.26 = alloca i1, align 1
  %local.offset.27 = alloca i32, align 4
  %local.extent.28 = alloca i32, align 4
  %local.payload.29 = alloca i32, align 4
  %local.owner.end.30 = alloca i32, align 4
  %local.type.31 = alloca i32, align 4
  store i1 false, ptr %local.active.26, align 1
  store i32 0, ptr %local.offset.27, align 4
  store i32 0, ptr %local.extent.28, align 4
  store i32 0, ptr %local.payload.29, align 4
  store i32 0, ptr %local.owner.end.30, align 4
  store i32 0, ptr %local.type.31, align 4
  %local.active.32 = alloca i1, align 1
  %local.offset.33 = alloca i32, align 4
  %local.extent.34 = alloca i32, align 4
  %local.payload.35 = alloca i32, align 4
  %local.owner.end.36 = alloca i32, align 4
  %local.type.37 = alloca i32, align 4
  store i1 false, ptr %local.active.32, align 1
  store i32 0, ptr %local.offset.33, align 4
  store i32 0, ptr %local.extent.34, align 4
  store i32 0, ptr %local.payload.35, align 4
  store i32 0, ptr %local.owner.end.36, align 4
  store i32 0, ptr %local.type.37, align 4
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %context.field.40 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.41 = load i32, ptr %context.field.40, align 4
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %context.field.44 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.45 = load i32, ptr %context.field.44, align 4
  %frame.entered.46 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.47 = icmp eq i32 %frame.entered.46, 0
  br i1 %frame.enter.ok.47, label %frame.enter.continue.48, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.48:
  %descriptor.element.49 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 0
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 1
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %descriptor.field.54 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 2
  %descriptor.value.55 = load i32, ptr %descriptor.field.54, align 4
  %descriptor.field.56 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 3
  %descriptor.value.57 = load i32, ptr %descriptor.field.56, align 4
  %descriptor.field.58 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 4
  %descriptor.value.59 = load i32, ptr %descriptor.field.58, align 4
  %argument.type.valid.60 = icmp eq i32 %descriptor.value.51, 12
  br i1 %argument.type.valid.60, label %argument.type.ok.61, label %frame.failure.0
argument.type.ok.61:
  %context.field.62 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.63 = load i32, ptr %context.field.62, align 4
  %stack.sub.66 = sub i32 %descriptor.value.59, %descriptor.value.53
  %descriptor.owner.inside.64 = icmp ule i32 %descriptor.value.59, %context.value.63
  %descriptor.offset.inside.65 = icmp ule i32 %descriptor.value.53, %descriptor.value.59
  %descriptor.extent.inside.67 = icmp ule i32 %descriptor.value.55, %stack.sub.66
  %descriptor.payload.inside.68 = icmp ule i32 %descriptor.value.57, %descriptor.value.55
  %descriptor.owner.offset.valid.69 = and i1 %descriptor.owner.inside.64, %descriptor.offset.inside.65
  %descriptor.range.inside.71 = and i1 %descriptor.owner.offset.valid.69, %descriptor.extent.inside.67
  %descriptor.range.valid.70 = and i1 %descriptor.range.inside.71, %descriptor.payload.inside.68
  %descriptor.type.valid.72 = icmp eq i32 12, 12
  %descriptor.valid.73 = and i1 %descriptor.range.valid.70, %descriptor.type.valid.72
  br i1 %descriptor.valid.73, label %descriptor.valid.74, label %descriptor.invalid.75
descriptor.invalid.75:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.74:
  %descriptor.initialized.status.76 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.53, i32 %descriptor.value.55)
  %helper.ok.77 = icmp eq i32 %descriptor.initialized.status.76, 0
  br i1 %helper.ok.77, label %helper.continue.78, label %frame.failure.0
helper.continue.78:
  %descriptor.element.79 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.80 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 0
  %descriptor.value.81 = load i32, ptr %descriptor.field.80, align 4
  %descriptor.field.82 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 1
  %descriptor.value.83 = load i32, ptr %descriptor.field.82, align 4
  %descriptor.field.84 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 2
  %descriptor.value.85 = load i32, ptr %descriptor.field.84, align 4
  %descriptor.field.86 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 3
  %descriptor.value.87 = load i32, ptr %descriptor.field.86, align 4
  %descriptor.field.88 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.79, i32 0, i32 4
  %descriptor.value.89 = load i32, ptr %descriptor.field.88, align 4
  %argument.type.valid.90 = icmp eq i32 %descriptor.value.81, 12
  br i1 %argument.type.valid.90, label %argument.type.ok.91, label %frame.failure.0
argument.type.ok.91:
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %stack.sub.96 = sub i32 %descriptor.value.89, %descriptor.value.83
  %descriptor.owner.inside.94 = icmp ule i32 %descriptor.value.89, %context.value.93
  %descriptor.offset.inside.95 = icmp ule i32 %descriptor.value.83, %descriptor.value.89
  %descriptor.extent.inside.97 = icmp ule i32 %descriptor.value.85, %stack.sub.96
  %descriptor.payload.inside.98 = icmp ule i32 %descriptor.value.87, %descriptor.value.85
  %descriptor.owner.offset.valid.99 = and i1 %descriptor.owner.inside.94, %descriptor.offset.inside.95
  %descriptor.range.inside.101 = and i1 %descriptor.owner.offset.valid.99, %descriptor.extent.inside.97
  %descriptor.range.valid.100 = and i1 %descriptor.range.inside.101, %descriptor.payload.inside.98
  %descriptor.type.valid.102 = icmp eq i32 12, 12
  %descriptor.valid.103 = and i1 %descriptor.range.valid.100, %descriptor.type.valid.102
  br i1 %descriptor.valid.103, label %descriptor.valid.104, label %descriptor.invalid.105
descriptor.invalid.105:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.104:
  %descriptor.initialized.status.106 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.83, i32 %descriptor.value.85)
  %helper.ok.107 = icmp eq i32 %descriptor.initialized.status.106, 0
  br i1 %helper.ok.107, label %helper.continue.108, label %frame.failure.0
helper.continue.108:
  %descriptor.element.109 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 2
  %descriptor.field.110 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.109, i32 0, i32 0
  %descriptor.value.111 = load i32, ptr %descriptor.field.110, align 4
  %descriptor.field.112 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.109, i32 0, i32 1
  %descriptor.value.113 = load i32, ptr %descriptor.field.112, align 4
  %descriptor.field.114 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.109, i32 0, i32 2
  %descriptor.value.115 = load i32, ptr %descriptor.field.114, align 4
  %descriptor.field.116 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.109, i32 0, i32 3
  %descriptor.value.117 = load i32, ptr %descriptor.field.116, align 4
  %descriptor.field.118 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.109, i32 0, i32 4
  %descriptor.value.119 = load i32, ptr %descriptor.field.118, align 4
  %argument.type.valid.120 = icmp eq i32 %descriptor.value.111, 12
  br i1 %argument.type.valid.120, label %argument.type.ok.121, label %frame.failure.0
argument.type.ok.121:
  %context.field.122 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.123 = load i32, ptr %context.field.122, align 4
  %stack.sub.126 = sub i32 %descriptor.value.119, %descriptor.value.113
  %descriptor.owner.inside.124 = icmp ule i32 %descriptor.value.119, %context.value.123
  %descriptor.offset.inside.125 = icmp ule i32 %descriptor.value.113, %descriptor.value.119
  %descriptor.extent.inside.127 = icmp ule i32 %descriptor.value.115, %stack.sub.126
  %descriptor.payload.inside.128 = icmp ule i32 %descriptor.value.117, %descriptor.value.115
  %descriptor.owner.offset.valid.129 = and i1 %descriptor.owner.inside.124, %descriptor.offset.inside.125
  %descriptor.range.inside.131 = and i1 %descriptor.owner.offset.valid.129, %descriptor.extent.inside.127
  %descriptor.range.valid.130 = and i1 %descriptor.range.inside.131, %descriptor.payload.inside.128
  %descriptor.type.valid.132 = icmp eq i32 12, 12
  %descriptor.valid.133 = and i1 %descriptor.range.valid.130, %descriptor.type.valid.132
  br i1 %descriptor.valid.133, label %descriptor.valid.134, label %descriptor.invalid.135
descriptor.invalid.135:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.134:
  %descriptor.initialized.status.136 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.113, i32 %descriptor.value.115)
  %helper.ok.137 = icmp eq i32 %descriptor.initialized.status.136, 0
  br i1 %helper.ok.137, label %helper.continue.138, label %frame.failure.0
helper.continue.138:
  %descriptor.element.139 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 3
  %descriptor.field.140 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.139, i32 0, i32 0
  %descriptor.value.141 = load i32, ptr %descriptor.field.140, align 4
  %descriptor.field.142 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.139, i32 0, i32 1
  %descriptor.value.143 = load i32, ptr %descriptor.field.142, align 4
  %descriptor.field.144 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.139, i32 0, i32 2
  %descriptor.value.145 = load i32, ptr %descriptor.field.144, align 4
  %descriptor.field.146 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.139, i32 0, i32 3
  %descriptor.value.147 = load i32, ptr %descriptor.field.146, align 4
  %descriptor.field.148 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.139, i32 0, i32 4
  %descriptor.value.149 = load i32, ptr %descriptor.field.148, align 4
  %argument.type.valid.150 = icmp eq i32 %descriptor.value.141, 12
  br i1 %argument.type.valid.150, label %argument.type.ok.151, label %frame.failure.0
argument.type.ok.151:
  %context.field.152 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.153 = load i32, ptr %context.field.152, align 4
  %stack.sub.156 = sub i32 %descriptor.value.149, %descriptor.value.143
  %descriptor.owner.inside.154 = icmp ule i32 %descriptor.value.149, %context.value.153
  %descriptor.offset.inside.155 = icmp ule i32 %descriptor.value.143, %descriptor.value.149
  %descriptor.extent.inside.157 = icmp ule i32 %descriptor.value.145, %stack.sub.156
  %descriptor.payload.inside.158 = icmp ule i32 %descriptor.value.147, %descriptor.value.145
  %descriptor.owner.offset.valid.159 = and i1 %descriptor.owner.inside.154, %descriptor.offset.inside.155
  %descriptor.range.inside.161 = and i1 %descriptor.owner.offset.valid.159, %descriptor.extent.inside.157
  %descriptor.range.valid.160 = and i1 %descriptor.range.inside.161, %descriptor.payload.inside.158
  %descriptor.type.valid.162 = icmp eq i32 12, 12
  %descriptor.valid.163 = and i1 %descriptor.range.valid.160, %descriptor.type.valid.162
  br i1 %descriptor.valid.163, label %descriptor.valid.164, label %descriptor.invalid.165
descriptor.invalid.165:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.164:
  %descriptor.initialized.status.166 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.143, i32 %descriptor.value.145)
  %helper.ok.167 = icmp eq i32 %descriptor.initialized.status.166, 0
  br i1 %helper.ok.167, label %helper.continue.168, label %frame.failure.0
helper.continue.168:
  %descriptor.element.169 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 4
  %descriptor.field.170 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.169, i32 0, i32 0
  %descriptor.value.171 = load i32, ptr %descriptor.field.170, align 4
  %descriptor.field.172 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.169, i32 0, i32 1
  %descriptor.value.173 = load i32, ptr %descriptor.field.172, align 4
  %descriptor.field.174 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.169, i32 0, i32 2
  %descriptor.value.175 = load i32, ptr %descriptor.field.174, align 4
  %descriptor.field.176 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.169, i32 0, i32 3
  %descriptor.value.177 = load i32, ptr %descriptor.field.176, align 4
  %descriptor.field.178 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.169, i32 0, i32 4
  %descriptor.value.179 = load i32, ptr %descriptor.field.178, align 4
  %argument.type.valid.180 = icmp eq i32 %descriptor.value.171, 12
  br i1 %argument.type.valid.180, label %argument.type.ok.181, label %frame.failure.0
argument.type.ok.181:
  %context.field.182 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.183 = load i32, ptr %context.field.182, align 4
  %stack.sub.186 = sub i32 %descriptor.value.179, %descriptor.value.173
  %descriptor.owner.inside.184 = icmp ule i32 %descriptor.value.179, %context.value.183
  %descriptor.offset.inside.185 = icmp ule i32 %descriptor.value.173, %descriptor.value.179
  %descriptor.extent.inside.187 = icmp ule i32 %descriptor.value.175, %stack.sub.186
  %descriptor.payload.inside.188 = icmp ule i32 %descriptor.value.177, %descriptor.value.175
  %descriptor.owner.offset.valid.189 = and i1 %descriptor.owner.inside.184, %descriptor.offset.inside.185
  %descriptor.range.inside.191 = and i1 %descriptor.owner.offset.valid.189, %descriptor.extent.inside.187
  %descriptor.range.valid.190 = and i1 %descriptor.range.inside.191, %descriptor.payload.inside.188
  %descriptor.type.valid.192 = icmp eq i32 12, 12
  %descriptor.valid.193 = and i1 %descriptor.range.valid.190, %descriptor.type.valid.192
  br i1 %descriptor.valid.193, label %descriptor.valid.194, label %descriptor.invalid.195
descriptor.invalid.195:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.194:
  %descriptor.initialized.status.196 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.173, i32 %descriptor.value.175)
  %helper.ok.197 = icmp eq i32 %descriptor.initialized.status.196, 0
  br i1 %helper.ok.197, label %helper.continue.198, label %frame.failure.0
helper.continue.198:
  %descriptor.element.199 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 5
  %descriptor.field.200 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.199, i32 0, i32 0
  %descriptor.value.201 = load i32, ptr %descriptor.field.200, align 4
  %descriptor.field.202 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.199, i32 0, i32 1
  %descriptor.value.203 = load i32, ptr %descriptor.field.202, align 4
  %descriptor.field.204 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.199, i32 0, i32 2
  %descriptor.value.205 = load i32, ptr %descriptor.field.204, align 4
  %descriptor.field.206 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.199, i32 0, i32 3
  %descriptor.value.207 = load i32, ptr %descriptor.field.206, align 4
  %descriptor.field.208 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.199, i32 0, i32 4
  %descriptor.value.209 = load i32, ptr %descriptor.field.208, align 4
  %argument.type.valid.210 = icmp eq i32 %descriptor.value.201, 12
  br i1 %argument.type.valid.210, label %argument.type.ok.211, label %frame.failure.0
argument.type.ok.211:
  %context.field.212 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.213 = load i32, ptr %context.field.212, align 4
  %stack.sub.216 = sub i32 %descriptor.value.209, %descriptor.value.203
  %descriptor.owner.inside.214 = icmp ule i32 %descriptor.value.209, %context.value.213
  %descriptor.offset.inside.215 = icmp ule i32 %descriptor.value.203, %descriptor.value.209
  %descriptor.extent.inside.217 = icmp ule i32 %descriptor.value.205, %stack.sub.216
  %descriptor.payload.inside.218 = icmp ule i32 %descriptor.value.207, %descriptor.value.205
  %descriptor.owner.offset.valid.219 = and i1 %descriptor.owner.inside.214, %descriptor.offset.inside.215
  %descriptor.range.inside.221 = and i1 %descriptor.owner.offset.valid.219, %descriptor.extent.inside.217
  %descriptor.range.valid.220 = and i1 %descriptor.range.inside.221, %descriptor.payload.inside.218
  %descriptor.type.valid.222 = icmp eq i32 12, 12
  %descriptor.valid.223 = and i1 %descriptor.range.valid.220, %descriptor.type.valid.222
  br i1 %descriptor.valid.223, label %descriptor.valid.224, label %descriptor.invalid.225
descriptor.invalid.225:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.224:
  %descriptor.initialized.status.226 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.203, i32 %descriptor.value.205)
  %helper.ok.227 = icmp eq i32 %descriptor.initialized.status.226, 0
  br i1 %helper.ok.227, label %helper.continue.228, label %frame.failure.0
helper.continue.228:
  %step.status.229 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.230 = icmp eq i32 %step.status.229, 0
  br i1 %helper.ok.230, label %helper.continue.231, label %frame.failure.0
helper.continue.231:
  %context.field.232 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.233 = load i32, ptr %context.field.232, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  store i1 false, ptr %local.active.20, align 1
  store i32 0, ptr %local.offset.21, align 4
  store i32 0, ptr %local.extent.22, align 4
  store i32 0, ptr %local.payload.23, align 4
  store i32 0, ptr %local.owner.end.24, align 4
  store i32 0, ptr %local.type.25, align 4
  store i1 false, ptr %local.active.26, align 1
  store i32 0, ptr %local.offset.27, align 4
  store i32 0, ptr %local.extent.28, align 4
  store i32 0, ptr %local.payload.29, align 4
  store i32 0, ptr %local.owner.end.30, align 4
  store i32 0, ptr %local.type.31, align 4
  store i1 false, ptr %local.active.32, align 1
  store i32 0, ptr %local.offset.33, align 4
  store i32 0, ptr %local.extent.34, align 4
  store i32 0, ptr %local.payload.35, align 4
  store i32 0, ptr %local.owner.end.36, align 4
  store i32 0, ptr %local.type.37, align 4
  %step.status.234 = call i32 @al_owning_charge_step(ptr %ctx, i32 2)
  %helper.ok.235 = icmp eq i32 %step.status.234, 0
  br i1 %helper.ok.235, label %helper.continue.236, label %frame.failure.0
helper.continue.236:
  store i1 true, ptr %local.active.2, align 1
  store i32 %descriptor.value.203, ptr %local.offset.3, align 4
  store i32 %descriptor.value.205, ptr %local.extent.4, align 4
  store i32 %descriptor.value.207, ptr %local.payload.5, align 4
  store i32 %descriptor.value.209, ptr %local.owner.end.6, align 4
  store i32 12, ptr %local.type.7, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %descriptor.value.203, i32 20, i32 %descriptor.value.207, i32 %descriptor.value.209, i32 %descriptor.value.205)
  %context.field.237 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.238 = load i32, ptr %context.field.237, align 4
  %runtime.ok.239 = icmp eq i32 %context.value.238, 0
  br i1 %runtime.ok.239, label %runtime.continue.240, label %frame.failure.0
runtime.continue.240:
  %context.field.241 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.242 = load i32, ptr %context.field.241, align 4
  %stack.sub.245 = sub i32 %descriptor.value.59, %descriptor.value.53
  %descriptor.owner.inside.243 = icmp ule i32 %descriptor.value.59, %context.value.242
  %descriptor.offset.inside.244 = icmp ule i32 %descriptor.value.53, %descriptor.value.59
  %descriptor.extent.inside.246 = icmp ule i32 %descriptor.value.55, %stack.sub.245
  %descriptor.payload.inside.247 = icmp ule i32 %descriptor.value.57, %descriptor.value.55
  %descriptor.owner.offset.valid.248 = and i1 %descriptor.owner.inside.243, %descriptor.offset.inside.244
  %descriptor.range.inside.250 = and i1 %descriptor.owner.offset.valid.248, %descriptor.extent.inside.246
  %descriptor.range.valid.249 = and i1 %descriptor.range.inside.250, %descriptor.payload.inside.247
  %descriptor.type.valid.251 = icmp eq i32 12, 12
  %descriptor.valid.252 = and i1 %descriptor.range.valid.249, %descriptor.type.valid.251
  br i1 %descriptor.valid.252, label %descriptor.valid.253, label %descriptor.invalid.254
descriptor.invalid.254:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.253:
  %descriptor.initialized.status.255 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.53, i32 %descriptor.value.55)
  %helper.ok.256 = icmp eq i32 %descriptor.initialized.status.255, 0
  br i1 %helper.ok.256, label %helper.continue.257, label %frame.failure.0
helper.continue.257:
  %context.field.258 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.259 = load i32, ptr %context.field.258, align 4
  %stack.sub.262 = sub i32 %descriptor.value.89, %descriptor.value.83
  %descriptor.owner.inside.260 = icmp ule i32 %descriptor.value.89, %context.value.259
  %descriptor.offset.inside.261 = icmp ule i32 %descriptor.value.83, %descriptor.value.89
  %descriptor.extent.inside.263 = icmp ule i32 %descriptor.value.85, %stack.sub.262
  %descriptor.payload.inside.264 = icmp ule i32 %descriptor.value.87, %descriptor.value.85
  %descriptor.owner.offset.valid.265 = and i1 %descriptor.owner.inside.260, %descriptor.offset.inside.261
  %descriptor.range.inside.267 = and i1 %descriptor.owner.offset.valid.265, %descriptor.extent.inside.263
  %descriptor.range.valid.266 = and i1 %descriptor.range.inside.267, %descriptor.payload.inside.264
  %descriptor.type.valid.268 = icmp eq i32 12, 12
  %descriptor.valid.269 = and i1 %descriptor.range.valid.266, %descriptor.type.valid.268
  br i1 %descriptor.valid.269, label %descriptor.valid.270, label %descriptor.invalid.271
descriptor.invalid.271:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.270:
  %descriptor.initialized.status.272 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.83, i32 %descriptor.value.85)
  %helper.ok.273 = icmp eq i32 %descriptor.initialized.status.272, 0
  br i1 %helper.ok.273, label %helper.continue.274, label %frame.failure.0
helper.continue.274:
  %context.field.275 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.276 = load i32, ptr %context.field.275, align 4
  %stack.sub.279 = sub i32 %descriptor.value.119, %descriptor.value.113
  %descriptor.owner.inside.277 = icmp ule i32 %descriptor.value.119, %context.value.276
  %descriptor.offset.inside.278 = icmp ule i32 %descriptor.value.113, %descriptor.value.119
  %descriptor.extent.inside.280 = icmp ule i32 %descriptor.value.115, %stack.sub.279
  %descriptor.payload.inside.281 = icmp ule i32 %descriptor.value.117, %descriptor.value.115
  %descriptor.owner.offset.valid.282 = and i1 %descriptor.owner.inside.277, %descriptor.offset.inside.278
  %descriptor.range.inside.284 = and i1 %descriptor.owner.offset.valid.282, %descriptor.extent.inside.280
  %descriptor.range.valid.283 = and i1 %descriptor.range.inside.284, %descriptor.payload.inside.281
  %descriptor.type.valid.285 = icmp eq i32 12, 12
  %descriptor.valid.286 = and i1 %descriptor.range.valid.283, %descriptor.type.valid.285
  br i1 %descriptor.valid.286, label %descriptor.valid.287, label %descriptor.invalid.288
descriptor.invalid.288:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.287:
  %descriptor.initialized.status.289 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.113, i32 %descriptor.value.115)
  %helper.ok.290 = icmp eq i32 %descriptor.initialized.status.289, 0
  br i1 %helper.ok.290, label %helper.continue.291, label %frame.failure.0
helper.continue.291:
  %context.field.292 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.293 = load i32, ptr %context.field.292, align 4
  %stack.sub.296 = sub i32 %descriptor.value.149, %descriptor.value.143
  %descriptor.owner.inside.294 = icmp ule i32 %descriptor.value.149, %context.value.293
  %descriptor.offset.inside.295 = icmp ule i32 %descriptor.value.143, %descriptor.value.149
  %descriptor.extent.inside.297 = icmp ule i32 %descriptor.value.145, %stack.sub.296
  %descriptor.payload.inside.298 = icmp ule i32 %descriptor.value.147, %descriptor.value.145
  %descriptor.owner.offset.valid.299 = and i1 %descriptor.owner.inside.294, %descriptor.offset.inside.295
  %descriptor.range.inside.301 = and i1 %descriptor.owner.offset.valid.299, %descriptor.extent.inside.297
  %descriptor.range.valid.300 = and i1 %descriptor.range.inside.301, %descriptor.payload.inside.298
  %descriptor.type.valid.302 = icmp eq i32 12, 12
  %descriptor.valid.303 = and i1 %descriptor.range.valid.300, %descriptor.type.valid.302
  br i1 %descriptor.valid.303, label %descriptor.valid.304, label %descriptor.invalid.305
descriptor.invalid.305:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.304:
  %descriptor.initialized.status.306 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.143, i32 %descriptor.value.145)
  %helper.ok.307 = icmp eq i32 %descriptor.initialized.status.306, 0
  br i1 %helper.ok.307, label %helper.continue.308, label %frame.failure.0
helper.continue.308:
  %context.field.309 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.310 = load i32, ptr %context.field.309, align 4
  %stack.sub.313 = sub i32 %descriptor.value.179, %descriptor.value.173
  %descriptor.owner.inside.311 = icmp ule i32 %descriptor.value.179, %context.value.310
  %descriptor.offset.inside.312 = icmp ule i32 %descriptor.value.173, %descriptor.value.179
  %descriptor.extent.inside.314 = icmp ule i32 %descriptor.value.175, %stack.sub.313
  %descriptor.payload.inside.315 = icmp ule i32 %descriptor.value.177, %descriptor.value.175
  %descriptor.owner.offset.valid.316 = and i1 %descriptor.owner.inside.311, %descriptor.offset.inside.312
  %descriptor.range.inside.318 = and i1 %descriptor.owner.offset.valid.316, %descriptor.extent.inside.314
  %descriptor.range.valid.317 = and i1 %descriptor.range.inside.318, %descriptor.payload.inside.315
  %descriptor.type.valid.319 = icmp eq i32 12, 12
  %descriptor.valid.320 = and i1 %descriptor.range.valid.317, %descriptor.type.valid.319
  br i1 %descriptor.valid.320, label %descriptor.valid.321, label %descriptor.invalid.322
descriptor.invalid.322:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.321:
  %descriptor.initialized.status.323 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.173, i32 %descriptor.value.175)
  %helper.ok.324 = icmp eq i32 %descriptor.initialized.status.323, 0
  br i1 %helper.ok.324, label %helper.continue.325, label %frame.failure.0
helper.continue.325:
  %local.is.active.326 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.326, label %local.descriptor.active.327, label %local.descriptor.inactive.328
local.descriptor.active.327:
  %local.check.offset.330 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.331 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.332 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.333 = load i32, ptr %local.owner.end.6, align 4
  %context.field.334 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.335 = load i32, ptr %context.field.334, align 4
  %stack.sub.338 = sub i32 %local.check.owner.end.333, %local.check.offset.330
  %descriptor.owner.inside.336 = icmp ule i32 %local.check.owner.end.333, %context.value.335
  %descriptor.offset.inside.337 = icmp ule i32 %local.check.offset.330, %local.check.owner.end.333
  %descriptor.extent.inside.339 = icmp ule i32 %local.check.extent.331, %stack.sub.338
  %descriptor.payload.inside.340 = icmp ule i32 %local.check.payload.332, %local.check.extent.331
  %descriptor.owner.offset.valid.341 = and i1 %descriptor.owner.inside.336, %descriptor.offset.inside.337
  %descriptor.range.inside.343 = and i1 %descriptor.owner.offset.valid.341, %descriptor.extent.inside.339
  %descriptor.range.valid.342 = and i1 %descriptor.range.inside.343, %descriptor.payload.inside.340
  br i1 %descriptor.range.valid.342, label %descriptor.valid.344, label %descriptor.invalid.345
descriptor.invalid.345:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.344:
  %descriptor.initialized.status.346 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.330, i32 %local.check.extent.331)
  %helper.ok.347 = icmp eq i32 %descriptor.initialized.status.346, 0
  br i1 %helper.ok.347, label %helper.continue.348, label %frame.failure.0
helper.continue.348:
  br label %local.descriptor.checked.329
local.descriptor.inactive.328:
  br label %local.descriptor.checked.329
local.descriptor.checked.329:
  %local.is.active.349 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.349, label %local.descriptor.active.350, label %local.descriptor.inactive.351
local.descriptor.active.350:
  %local.check.offset.353 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.354 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.355 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.356 = load i32, ptr %local.owner.end.12, align 4
  %context.field.357 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.358 = load i32, ptr %context.field.357, align 4
  %stack.sub.361 = sub i32 %local.check.owner.end.356, %local.check.offset.353
  %descriptor.owner.inside.359 = icmp ule i32 %local.check.owner.end.356, %context.value.358
  %descriptor.offset.inside.360 = icmp ule i32 %local.check.offset.353, %local.check.owner.end.356
  %descriptor.extent.inside.362 = icmp ule i32 %local.check.extent.354, %stack.sub.361
  %descriptor.payload.inside.363 = icmp ule i32 %local.check.payload.355, %local.check.extent.354
  %descriptor.owner.offset.valid.364 = and i1 %descriptor.owner.inside.359, %descriptor.offset.inside.360
  %descriptor.range.inside.366 = and i1 %descriptor.owner.offset.valid.364, %descriptor.extent.inside.362
  %descriptor.range.valid.365 = and i1 %descriptor.range.inside.366, %descriptor.payload.inside.363
  br i1 %descriptor.range.valid.365, label %descriptor.valid.367, label %descriptor.invalid.368
descriptor.invalid.368:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.367:
  %descriptor.initialized.status.369 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.353, i32 %local.check.extent.354)
  %helper.ok.370 = icmp eq i32 %descriptor.initialized.status.369, 0
  br i1 %helper.ok.370, label %helper.continue.371, label %frame.failure.0
helper.continue.371:
  br label %local.descriptor.checked.352
local.descriptor.inactive.351:
  br label %local.descriptor.checked.352
local.descriptor.checked.352:
  %local.is.active.372 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.372, label %local.descriptor.active.373, label %local.descriptor.inactive.374
local.descriptor.active.373:
  %local.check.offset.376 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.377 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.378 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.379 = load i32, ptr %local.owner.end.18, align 4
  %context.field.380 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.381 = load i32, ptr %context.field.380, align 4
  %stack.sub.384 = sub i32 %local.check.owner.end.379, %local.check.offset.376
  %descriptor.owner.inside.382 = icmp ule i32 %local.check.owner.end.379, %context.value.381
  %descriptor.offset.inside.383 = icmp ule i32 %local.check.offset.376, %local.check.owner.end.379
  %descriptor.extent.inside.385 = icmp ule i32 %local.check.extent.377, %stack.sub.384
  %descriptor.payload.inside.386 = icmp ule i32 %local.check.payload.378, %local.check.extent.377
  %descriptor.owner.offset.valid.387 = and i1 %descriptor.owner.inside.382, %descriptor.offset.inside.383
  %descriptor.range.inside.389 = and i1 %descriptor.owner.offset.valid.387, %descriptor.extent.inside.385
  %descriptor.range.valid.388 = and i1 %descriptor.range.inside.389, %descriptor.payload.inside.386
  br i1 %descriptor.range.valid.388, label %descriptor.valid.390, label %descriptor.invalid.391
descriptor.invalid.391:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.390:
  %descriptor.initialized.status.392 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.376, i32 %local.check.extent.377)
  %helper.ok.393 = icmp eq i32 %descriptor.initialized.status.392, 0
  br i1 %helper.ok.393, label %helper.continue.394, label %frame.failure.0
helper.continue.394:
  br label %local.descriptor.checked.375
local.descriptor.inactive.374:
  br label %local.descriptor.checked.375
local.descriptor.checked.375:
  %local.is.active.395 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.395, label %local.descriptor.active.396, label %local.descriptor.inactive.397
local.descriptor.active.396:
  %local.check.offset.399 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.400 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.401 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.402 = load i32, ptr %local.owner.end.24, align 4
  %context.field.403 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.404 = load i32, ptr %context.field.403, align 4
  %stack.sub.407 = sub i32 %local.check.owner.end.402, %local.check.offset.399
  %descriptor.owner.inside.405 = icmp ule i32 %local.check.owner.end.402, %context.value.404
  %descriptor.offset.inside.406 = icmp ule i32 %local.check.offset.399, %local.check.owner.end.402
  %descriptor.extent.inside.408 = icmp ule i32 %local.check.extent.400, %stack.sub.407
  %descriptor.payload.inside.409 = icmp ule i32 %local.check.payload.401, %local.check.extent.400
  %descriptor.owner.offset.valid.410 = and i1 %descriptor.owner.inside.405, %descriptor.offset.inside.406
  %descriptor.range.inside.412 = and i1 %descriptor.owner.offset.valid.410, %descriptor.extent.inside.408
  %descriptor.range.valid.411 = and i1 %descriptor.range.inside.412, %descriptor.payload.inside.409
  br i1 %descriptor.range.valid.411, label %descriptor.valid.413, label %descriptor.invalid.414
descriptor.invalid.414:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.413:
  %descriptor.initialized.status.415 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.399, i32 %local.check.extent.400)
  %helper.ok.416 = icmp eq i32 %descriptor.initialized.status.415, 0
  br i1 %helper.ok.416, label %helper.continue.417, label %frame.failure.0
helper.continue.417:
  br label %local.descriptor.checked.398
local.descriptor.inactive.397:
  br label %local.descriptor.checked.398
local.descriptor.checked.398:
  %local.is.active.418 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.418, label %local.descriptor.active.419, label %local.descriptor.inactive.420
local.descriptor.active.419:
  %local.check.offset.422 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.423 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.424 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.425 = load i32, ptr %local.owner.end.30, align 4
  %context.field.426 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.427 = load i32, ptr %context.field.426, align 4
  %stack.sub.430 = sub i32 %local.check.owner.end.425, %local.check.offset.422
  %descriptor.owner.inside.428 = icmp ule i32 %local.check.owner.end.425, %context.value.427
  %descriptor.offset.inside.429 = icmp ule i32 %local.check.offset.422, %local.check.owner.end.425
  %descriptor.extent.inside.431 = icmp ule i32 %local.check.extent.423, %stack.sub.430
  %descriptor.payload.inside.432 = icmp ule i32 %local.check.payload.424, %local.check.extent.423
  %descriptor.owner.offset.valid.433 = and i1 %descriptor.owner.inside.428, %descriptor.offset.inside.429
  %descriptor.range.inside.435 = and i1 %descriptor.owner.offset.valid.433, %descriptor.extent.inside.431
  %descriptor.range.valid.434 = and i1 %descriptor.range.inside.435, %descriptor.payload.inside.432
  br i1 %descriptor.range.valid.434, label %descriptor.valid.436, label %descriptor.invalid.437
descriptor.invalid.437:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.436:
  %descriptor.initialized.status.438 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.422, i32 %local.check.extent.423)
  %helper.ok.439 = icmp eq i32 %descriptor.initialized.status.438, 0
  br i1 %helper.ok.439, label %helper.continue.440, label %frame.failure.0
helper.continue.440:
  br label %local.descriptor.checked.421
local.descriptor.inactive.420:
  br label %local.descriptor.checked.421
local.descriptor.checked.421:
  %local.is.active.441 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.441, label %local.descriptor.active.442, label %local.descriptor.inactive.443
local.descriptor.active.442:
  %local.check.offset.445 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.446 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.447 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.448 = load i32, ptr %local.owner.end.36, align 4
  %context.field.449 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.450 = load i32, ptr %context.field.449, align 4
  %stack.sub.453 = sub i32 %local.check.owner.end.448, %local.check.offset.445
  %descriptor.owner.inside.451 = icmp ule i32 %local.check.owner.end.448, %context.value.450
  %descriptor.offset.inside.452 = icmp ule i32 %local.check.offset.445, %local.check.owner.end.448
  %descriptor.extent.inside.454 = icmp ule i32 %local.check.extent.446, %stack.sub.453
  %descriptor.payload.inside.455 = icmp ule i32 %local.check.payload.447, %local.check.extent.446
  %descriptor.owner.offset.valid.456 = and i1 %descriptor.owner.inside.451, %descriptor.offset.inside.452
  %descriptor.range.inside.458 = and i1 %descriptor.owner.offset.valid.456, %descriptor.extent.inside.454
  %descriptor.range.valid.457 = and i1 %descriptor.range.inside.458, %descriptor.payload.inside.455
  br i1 %descriptor.range.valid.457, label %descriptor.valid.459, label %descriptor.invalid.460
descriptor.invalid.460:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.459:
  %descriptor.initialized.status.461 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.445, i32 %local.check.extent.446)
  %helper.ok.462 = icmp eq i32 %descriptor.initialized.status.461, 0
  br i1 %helper.ok.462, label %helper.continue.463, label %frame.failure.0
helper.continue.463:
  br label %local.descriptor.checked.444
local.descriptor.inactive.443:
  br label %local.descriptor.checked.444
local.descriptor.checked.444:
  %step.status.464 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.465 = icmp eq i32 %step.status.464, 0
  br i1 %helper.ok.465, label %helper.continue.466, label %frame.failure.0
helper.continue.466:
  store i1 true, ptr %local.active.8, align 1
  store i32 %descriptor.value.173, ptr %local.offset.9, align 4
  store i32 %descriptor.value.175, ptr %local.extent.10, align 4
  store i32 %descriptor.value.177, ptr %local.payload.11, align 4
  store i32 %descriptor.value.179, ptr %local.owner.end.12, align 4
  store i32 12, ptr %local.type.13, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %descriptor.value.173, i32 20, i32 %descriptor.value.177, i32 %descriptor.value.179, i32 %descriptor.value.175)
  %context.field.467 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.468 = load i32, ptr %context.field.467, align 4
  %runtime.ok.469 = icmp eq i32 %context.value.468, 0
  br i1 %runtime.ok.469, label %runtime.continue.470, label %frame.failure.0
runtime.continue.470:
  %context.field.471 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.472 = load i32, ptr %context.field.471, align 4
  %stack.sub.475 = sub i32 %descriptor.value.59, %descriptor.value.53
  %descriptor.owner.inside.473 = icmp ule i32 %descriptor.value.59, %context.value.472
  %descriptor.offset.inside.474 = icmp ule i32 %descriptor.value.53, %descriptor.value.59
  %descriptor.extent.inside.476 = icmp ule i32 %descriptor.value.55, %stack.sub.475
  %descriptor.payload.inside.477 = icmp ule i32 %descriptor.value.57, %descriptor.value.55
  %descriptor.owner.offset.valid.478 = and i1 %descriptor.owner.inside.473, %descriptor.offset.inside.474
  %descriptor.range.inside.480 = and i1 %descriptor.owner.offset.valid.478, %descriptor.extent.inside.476
  %descriptor.range.valid.479 = and i1 %descriptor.range.inside.480, %descriptor.payload.inside.477
  %descriptor.type.valid.481 = icmp eq i32 12, 12
  %descriptor.valid.482 = and i1 %descriptor.range.valid.479, %descriptor.type.valid.481
  br i1 %descriptor.valid.482, label %descriptor.valid.483, label %descriptor.invalid.484
descriptor.invalid.484:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.483:
  %descriptor.initialized.status.485 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.53, i32 %descriptor.value.55)
  %helper.ok.486 = icmp eq i32 %descriptor.initialized.status.485, 0
  br i1 %helper.ok.486, label %helper.continue.487, label %frame.failure.0
helper.continue.487:
  %context.field.488 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.489 = load i32, ptr %context.field.488, align 4
  %stack.sub.492 = sub i32 %descriptor.value.89, %descriptor.value.83
  %descriptor.owner.inside.490 = icmp ule i32 %descriptor.value.89, %context.value.489
  %descriptor.offset.inside.491 = icmp ule i32 %descriptor.value.83, %descriptor.value.89
  %descriptor.extent.inside.493 = icmp ule i32 %descriptor.value.85, %stack.sub.492
  %descriptor.payload.inside.494 = icmp ule i32 %descriptor.value.87, %descriptor.value.85
  %descriptor.owner.offset.valid.495 = and i1 %descriptor.owner.inside.490, %descriptor.offset.inside.491
  %descriptor.range.inside.497 = and i1 %descriptor.owner.offset.valid.495, %descriptor.extent.inside.493
  %descriptor.range.valid.496 = and i1 %descriptor.range.inside.497, %descriptor.payload.inside.494
  %descriptor.type.valid.498 = icmp eq i32 12, 12
  %descriptor.valid.499 = and i1 %descriptor.range.valid.496, %descriptor.type.valid.498
  br i1 %descriptor.valid.499, label %descriptor.valid.500, label %descriptor.invalid.501
descriptor.invalid.501:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.500:
  %descriptor.initialized.status.502 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.83, i32 %descriptor.value.85)
  %helper.ok.503 = icmp eq i32 %descriptor.initialized.status.502, 0
  br i1 %helper.ok.503, label %helper.continue.504, label %frame.failure.0
helper.continue.504:
  %context.field.505 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.506 = load i32, ptr %context.field.505, align 4
  %stack.sub.509 = sub i32 %descriptor.value.119, %descriptor.value.113
  %descriptor.owner.inside.507 = icmp ule i32 %descriptor.value.119, %context.value.506
  %descriptor.offset.inside.508 = icmp ule i32 %descriptor.value.113, %descriptor.value.119
  %descriptor.extent.inside.510 = icmp ule i32 %descriptor.value.115, %stack.sub.509
  %descriptor.payload.inside.511 = icmp ule i32 %descriptor.value.117, %descriptor.value.115
  %descriptor.owner.offset.valid.512 = and i1 %descriptor.owner.inside.507, %descriptor.offset.inside.508
  %descriptor.range.inside.514 = and i1 %descriptor.owner.offset.valid.512, %descriptor.extent.inside.510
  %descriptor.range.valid.513 = and i1 %descriptor.range.inside.514, %descriptor.payload.inside.511
  %descriptor.type.valid.515 = icmp eq i32 12, 12
  %descriptor.valid.516 = and i1 %descriptor.range.valid.513, %descriptor.type.valid.515
  br i1 %descriptor.valid.516, label %descriptor.valid.517, label %descriptor.invalid.518
descriptor.invalid.518:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.517:
  %descriptor.initialized.status.519 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.113, i32 %descriptor.value.115)
  %helper.ok.520 = icmp eq i32 %descriptor.initialized.status.519, 0
  br i1 %helper.ok.520, label %helper.continue.521, label %frame.failure.0
helper.continue.521:
  %context.field.522 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.523 = load i32, ptr %context.field.522, align 4
  %stack.sub.526 = sub i32 %descriptor.value.149, %descriptor.value.143
  %descriptor.owner.inside.524 = icmp ule i32 %descriptor.value.149, %context.value.523
  %descriptor.offset.inside.525 = icmp ule i32 %descriptor.value.143, %descriptor.value.149
  %descriptor.extent.inside.527 = icmp ule i32 %descriptor.value.145, %stack.sub.526
  %descriptor.payload.inside.528 = icmp ule i32 %descriptor.value.147, %descriptor.value.145
  %descriptor.owner.offset.valid.529 = and i1 %descriptor.owner.inside.524, %descriptor.offset.inside.525
  %descriptor.range.inside.531 = and i1 %descriptor.owner.offset.valid.529, %descriptor.extent.inside.527
  %descriptor.range.valid.530 = and i1 %descriptor.range.inside.531, %descriptor.payload.inside.528
  %descriptor.type.valid.532 = icmp eq i32 12, 12
  %descriptor.valid.533 = and i1 %descriptor.range.valid.530, %descriptor.type.valid.532
  br i1 %descriptor.valid.533, label %descriptor.valid.534, label %descriptor.invalid.535
descriptor.invalid.535:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.534:
  %descriptor.initialized.status.536 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.143, i32 %descriptor.value.145)
  %helper.ok.537 = icmp eq i32 %descriptor.initialized.status.536, 0
  br i1 %helper.ok.537, label %helper.continue.538, label %frame.failure.0
helper.continue.538:
  %local.is.active.539 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.539, label %local.descriptor.active.540, label %local.descriptor.inactive.541
local.descriptor.active.540:
  %local.check.offset.543 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.544 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.545 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.546 = load i32, ptr %local.owner.end.6, align 4
  %context.field.547 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.548 = load i32, ptr %context.field.547, align 4
  %stack.sub.551 = sub i32 %local.check.owner.end.546, %local.check.offset.543
  %descriptor.owner.inside.549 = icmp ule i32 %local.check.owner.end.546, %context.value.548
  %descriptor.offset.inside.550 = icmp ule i32 %local.check.offset.543, %local.check.owner.end.546
  %descriptor.extent.inside.552 = icmp ule i32 %local.check.extent.544, %stack.sub.551
  %descriptor.payload.inside.553 = icmp ule i32 %local.check.payload.545, %local.check.extent.544
  %descriptor.owner.offset.valid.554 = and i1 %descriptor.owner.inside.549, %descriptor.offset.inside.550
  %descriptor.range.inside.556 = and i1 %descriptor.owner.offset.valid.554, %descriptor.extent.inside.552
  %descriptor.range.valid.555 = and i1 %descriptor.range.inside.556, %descriptor.payload.inside.553
  br i1 %descriptor.range.valid.555, label %descriptor.valid.557, label %descriptor.invalid.558
descriptor.invalid.558:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.557:
  %descriptor.initialized.status.559 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.543, i32 %local.check.extent.544)
  %helper.ok.560 = icmp eq i32 %descriptor.initialized.status.559, 0
  br i1 %helper.ok.560, label %helper.continue.561, label %frame.failure.0
helper.continue.561:
  br label %local.descriptor.checked.542
local.descriptor.inactive.541:
  br label %local.descriptor.checked.542
local.descriptor.checked.542:
  %local.is.active.562 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.562, label %local.descriptor.active.563, label %local.descriptor.inactive.564
local.descriptor.active.563:
  %local.check.offset.566 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.567 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.568 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.569 = load i32, ptr %local.owner.end.12, align 4
  %context.field.570 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.571 = load i32, ptr %context.field.570, align 4
  %stack.sub.574 = sub i32 %local.check.owner.end.569, %local.check.offset.566
  %descriptor.owner.inside.572 = icmp ule i32 %local.check.owner.end.569, %context.value.571
  %descriptor.offset.inside.573 = icmp ule i32 %local.check.offset.566, %local.check.owner.end.569
  %descriptor.extent.inside.575 = icmp ule i32 %local.check.extent.567, %stack.sub.574
  %descriptor.payload.inside.576 = icmp ule i32 %local.check.payload.568, %local.check.extent.567
  %descriptor.owner.offset.valid.577 = and i1 %descriptor.owner.inside.572, %descriptor.offset.inside.573
  %descriptor.range.inside.579 = and i1 %descriptor.owner.offset.valid.577, %descriptor.extent.inside.575
  %descriptor.range.valid.578 = and i1 %descriptor.range.inside.579, %descriptor.payload.inside.576
  br i1 %descriptor.range.valid.578, label %descriptor.valid.580, label %descriptor.invalid.581
descriptor.invalid.581:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.580:
  %descriptor.initialized.status.582 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.566, i32 %local.check.extent.567)
  %helper.ok.583 = icmp eq i32 %descriptor.initialized.status.582, 0
  br i1 %helper.ok.583, label %helper.continue.584, label %frame.failure.0
helper.continue.584:
  br label %local.descriptor.checked.565
local.descriptor.inactive.564:
  br label %local.descriptor.checked.565
local.descriptor.checked.565:
  %local.is.active.585 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.585, label %local.descriptor.active.586, label %local.descriptor.inactive.587
local.descriptor.active.586:
  %local.check.offset.589 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.590 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.591 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.592 = load i32, ptr %local.owner.end.18, align 4
  %context.field.593 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.594 = load i32, ptr %context.field.593, align 4
  %stack.sub.597 = sub i32 %local.check.owner.end.592, %local.check.offset.589
  %descriptor.owner.inside.595 = icmp ule i32 %local.check.owner.end.592, %context.value.594
  %descriptor.offset.inside.596 = icmp ule i32 %local.check.offset.589, %local.check.owner.end.592
  %descriptor.extent.inside.598 = icmp ule i32 %local.check.extent.590, %stack.sub.597
  %descriptor.payload.inside.599 = icmp ule i32 %local.check.payload.591, %local.check.extent.590
  %descriptor.owner.offset.valid.600 = and i1 %descriptor.owner.inside.595, %descriptor.offset.inside.596
  %descriptor.range.inside.602 = and i1 %descriptor.owner.offset.valid.600, %descriptor.extent.inside.598
  %descriptor.range.valid.601 = and i1 %descriptor.range.inside.602, %descriptor.payload.inside.599
  br i1 %descriptor.range.valid.601, label %descriptor.valid.603, label %descriptor.invalid.604
descriptor.invalid.604:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.603:
  %descriptor.initialized.status.605 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.589, i32 %local.check.extent.590)
  %helper.ok.606 = icmp eq i32 %descriptor.initialized.status.605, 0
  br i1 %helper.ok.606, label %helper.continue.607, label %frame.failure.0
helper.continue.607:
  br label %local.descriptor.checked.588
local.descriptor.inactive.587:
  br label %local.descriptor.checked.588
local.descriptor.checked.588:
  %local.is.active.608 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.608, label %local.descriptor.active.609, label %local.descriptor.inactive.610
local.descriptor.active.609:
  %local.check.offset.612 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.613 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.614 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.615 = load i32, ptr %local.owner.end.24, align 4
  %context.field.616 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.617 = load i32, ptr %context.field.616, align 4
  %stack.sub.620 = sub i32 %local.check.owner.end.615, %local.check.offset.612
  %descriptor.owner.inside.618 = icmp ule i32 %local.check.owner.end.615, %context.value.617
  %descriptor.offset.inside.619 = icmp ule i32 %local.check.offset.612, %local.check.owner.end.615
  %descriptor.extent.inside.621 = icmp ule i32 %local.check.extent.613, %stack.sub.620
  %descriptor.payload.inside.622 = icmp ule i32 %local.check.payload.614, %local.check.extent.613
  %descriptor.owner.offset.valid.623 = and i1 %descriptor.owner.inside.618, %descriptor.offset.inside.619
  %descriptor.range.inside.625 = and i1 %descriptor.owner.offset.valid.623, %descriptor.extent.inside.621
  %descriptor.range.valid.624 = and i1 %descriptor.range.inside.625, %descriptor.payload.inside.622
  br i1 %descriptor.range.valid.624, label %descriptor.valid.626, label %descriptor.invalid.627
descriptor.invalid.627:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.626:
  %descriptor.initialized.status.628 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.612, i32 %local.check.extent.613)
  %helper.ok.629 = icmp eq i32 %descriptor.initialized.status.628, 0
  br i1 %helper.ok.629, label %helper.continue.630, label %frame.failure.0
helper.continue.630:
  br label %local.descriptor.checked.611
local.descriptor.inactive.610:
  br label %local.descriptor.checked.611
local.descriptor.checked.611:
  %local.is.active.631 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.631, label %local.descriptor.active.632, label %local.descriptor.inactive.633
local.descriptor.active.632:
  %local.check.offset.635 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.636 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.637 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.638 = load i32, ptr %local.owner.end.30, align 4
  %context.field.639 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.640 = load i32, ptr %context.field.639, align 4
  %stack.sub.643 = sub i32 %local.check.owner.end.638, %local.check.offset.635
  %descriptor.owner.inside.641 = icmp ule i32 %local.check.owner.end.638, %context.value.640
  %descriptor.offset.inside.642 = icmp ule i32 %local.check.offset.635, %local.check.owner.end.638
  %descriptor.extent.inside.644 = icmp ule i32 %local.check.extent.636, %stack.sub.643
  %descriptor.payload.inside.645 = icmp ule i32 %local.check.payload.637, %local.check.extent.636
  %descriptor.owner.offset.valid.646 = and i1 %descriptor.owner.inside.641, %descriptor.offset.inside.642
  %descriptor.range.inside.648 = and i1 %descriptor.owner.offset.valid.646, %descriptor.extent.inside.644
  %descriptor.range.valid.647 = and i1 %descriptor.range.inside.648, %descriptor.payload.inside.645
  br i1 %descriptor.range.valid.647, label %descriptor.valid.649, label %descriptor.invalid.650
descriptor.invalid.650:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.649:
  %descriptor.initialized.status.651 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.635, i32 %local.check.extent.636)
  %helper.ok.652 = icmp eq i32 %descriptor.initialized.status.651, 0
  br i1 %helper.ok.652, label %helper.continue.653, label %frame.failure.0
helper.continue.653:
  br label %local.descriptor.checked.634
local.descriptor.inactive.633:
  br label %local.descriptor.checked.634
local.descriptor.checked.634:
  %local.is.active.654 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.654, label %local.descriptor.active.655, label %local.descriptor.inactive.656
local.descriptor.active.655:
  %local.check.offset.658 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.659 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.660 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.661 = load i32, ptr %local.owner.end.36, align 4
  %context.field.662 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.663 = load i32, ptr %context.field.662, align 4
  %stack.sub.666 = sub i32 %local.check.owner.end.661, %local.check.offset.658
  %descriptor.owner.inside.664 = icmp ule i32 %local.check.owner.end.661, %context.value.663
  %descriptor.offset.inside.665 = icmp ule i32 %local.check.offset.658, %local.check.owner.end.661
  %descriptor.extent.inside.667 = icmp ule i32 %local.check.extent.659, %stack.sub.666
  %descriptor.payload.inside.668 = icmp ule i32 %local.check.payload.660, %local.check.extent.659
  %descriptor.owner.offset.valid.669 = and i1 %descriptor.owner.inside.664, %descriptor.offset.inside.665
  %descriptor.range.inside.671 = and i1 %descriptor.owner.offset.valid.669, %descriptor.extent.inside.667
  %descriptor.range.valid.670 = and i1 %descriptor.range.inside.671, %descriptor.payload.inside.668
  br i1 %descriptor.range.valid.670, label %descriptor.valid.672, label %descriptor.invalid.673
descriptor.invalid.673:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.672:
  %descriptor.initialized.status.674 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.658, i32 %local.check.extent.659)
  %helper.ok.675 = icmp eq i32 %descriptor.initialized.status.674, 0
  br i1 %helper.ok.675, label %helper.continue.676, label %frame.failure.0
helper.continue.676:
  br label %local.descriptor.checked.657
local.descriptor.inactive.656:
  br label %local.descriptor.checked.657
local.descriptor.checked.657:
  %step.status.677 = call i32 @al_owning_charge_step(ptr %ctx, i32 4)
  %helper.ok.678 = icmp eq i32 %step.status.677, 0
  br i1 %helper.ok.678, label %helper.continue.679, label %frame.failure.0
helper.continue.679:
  store i1 true, ptr %local.active.14, align 1
  store i32 %descriptor.value.143, ptr %local.offset.15, align 4
  store i32 %descriptor.value.145, ptr %local.extent.16, align 4
  store i32 %descriptor.value.147, ptr %local.payload.17, align 4
  store i32 %descriptor.value.149, ptr %local.owner.end.18, align 4
  store i32 12, ptr %local.type.19, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %descriptor.value.143, i32 20, i32 %descriptor.value.147, i32 %descriptor.value.149, i32 %descriptor.value.145)
  %context.field.680 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.681 = load i32, ptr %context.field.680, align 4
  %runtime.ok.682 = icmp eq i32 %context.value.681, 0
  br i1 %runtime.ok.682, label %runtime.continue.683, label %frame.failure.0
runtime.continue.683:
  %context.field.684 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.685 = load i32, ptr %context.field.684, align 4
  %stack.sub.688 = sub i32 %descriptor.value.59, %descriptor.value.53
  %descriptor.owner.inside.686 = icmp ule i32 %descriptor.value.59, %context.value.685
  %descriptor.offset.inside.687 = icmp ule i32 %descriptor.value.53, %descriptor.value.59
  %descriptor.extent.inside.689 = icmp ule i32 %descriptor.value.55, %stack.sub.688
  %descriptor.payload.inside.690 = icmp ule i32 %descriptor.value.57, %descriptor.value.55
  %descriptor.owner.offset.valid.691 = and i1 %descriptor.owner.inside.686, %descriptor.offset.inside.687
  %descriptor.range.inside.693 = and i1 %descriptor.owner.offset.valid.691, %descriptor.extent.inside.689
  %descriptor.range.valid.692 = and i1 %descriptor.range.inside.693, %descriptor.payload.inside.690
  %descriptor.type.valid.694 = icmp eq i32 12, 12
  %descriptor.valid.695 = and i1 %descriptor.range.valid.692, %descriptor.type.valid.694
  br i1 %descriptor.valid.695, label %descriptor.valid.696, label %descriptor.invalid.697
descriptor.invalid.697:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.696:
  %descriptor.initialized.status.698 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.53, i32 %descriptor.value.55)
  %helper.ok.699 = icmp eq i32 %descriptor.initialized.status.698, 0
  br i1 %helper.ok.699, label %helper.continue.700, label %frame.failure.0
helper.continue.700:
  %context.field.701 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.702 = load i32, ptr %context.field.701, align 4
  %stack.sub.705 = sub i32 %descriptor.value.89, %descriptor.value.83
  %descriptor.owner.inside.703 = icmp ule i32 %descriptor.value.89, %context.value.702
  %descriptor.offset.inside.704 = icmp ule i32 %descriptor.value.83, %descriptor.value.89
  %descriptor.extent.inside.706 = icmp ule i32 %descriptor.value.85, %stack.sub.705
  %descriptor.payload.inside.707 = icmp ule i32 %descriptor.value.87, %descriptor.value.85
  %descriptor.owner.offset.valid.708 = and i1 %descriptor.owner.inside.703, %descriptor.offset.inside.704
  %descriptor.range.inside.710 = and i1 %descriptor.owner.offset.valid.708, %descriptor.extent.inside.706
  %descriptor.range.valid.709 = and i1 %descriptor.range.inside.710, %descriptor.payload.inside.707
  %descriptor.type.valid.711 = icmp eq i32 12, 12
  %descriptor.valid.712 = and i1 %descriptor.range.valid.709, %descriptor.type.valid.711
  br i1 %descriptor.valid.712, label %descriptor.valid.713, label %descriptor.invalid.714
descriptor.invalid.714:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.713:
  %descriptor.initialized.status.715 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.83, i32 %descriptor.value.85)
  %helper.ok.716 = icmp eq i32 %descriptor.initialized.status.715, 0
  br i1 %helper.ok.716, label %helper.continue.717, label %frame.failure.0
helper.continue.717:
  %context.field.718 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.719 = load i32, ptr %context.field.718, align 4
  %stack.sub.722 = sub i32 %descriptor.value.119, %descriptor.value.113
  %descriptor.owner.inside.720 = icmp ule i32 %descriptor.value.119, %context.value.719
  %descriptor.offset.inside.721 = icmp ule i32 %descriptor.value.113, %descriptor.value.119
  %descriptor.extent.inside.723 = icmp ule i32 %descriptor.value.115, %stack.sub.722
  %descriptor.payload.inside.724 = icmp ule i32 %descriptor.value.117, %descriptor.value.115
  %descriptor.owner.offset.valid.725 = and i1 %descriptor.owner.inside.720, %descriptor.offset.inside.721
  %descriptor.range.inside.727 = and i1 %descriptor.owner.offset.valid.725, %descriptor.extent.inside.723
  %descriptor.range.valid.726 = and i1 %descriptor.range.inside.727, %descriptor.payload.inside.724
  %descriptor.type.valid.728 = icmp eq i32 12, 12
  %descriptor.valid.729 = and i1 %descriptor.range.valid.726, %descriptor.type.valid.728
  br i1 %descriptor.valid.729, label %descriptor.valid.730, label %descriptor.invalid.731
descriptor.invalid.731:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.730:
  %descriptor.initialized.status.732 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.113, i32 %descriptor.value.115)
  %helper.ok.733 = icmp eq i32 %descriptor.initialized.status.732, 0
  br i1 %helper.ok.733, label %helper.continue.734, label %frame.failure.0
helper.continue.734:
  %local.is.active.735 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.735, label %local.descriptor.active.736, label %local.descriptor.inactive.737
local.descriptor.active.736:
  %local.check.offset.739 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.740 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.741 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.742 = load i32, ptr %local.owner.end.6, align 4
  %context.field.743 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.744 = load i32, ptr %context.field.743, align 4
  %stack.sub.747 = sub i32 %local.check.owner.end.742, %local.check.offset.739
  %descriptor.owner.inside.745 = icmp ule i32 %local.check.owner.end.742, %context.value.744
  %descriptor.offset.inside.746 = icmp ule i32 %local.check.offset.739, %local.check.owner.end.742
  %descriptor.extent.inside.748 = icmp ule i32 %local.check.extent.740, %stack.sub.747
  %descriptor.payload.inside.749 = icmp ule i32 %local.check.payload.741, %local.check.extent.740
  %descriptor.owner.offset.valid.750 = and i1 %descriptor.owner.inside.745, %descriptor.offset.inside.746
  %descriptor.range.inside.752 = and i1 %descriptor.owner.offset.valid.750, %descriptor.extent.inside.748
  %descriptor.range.valid.751 = and i1 %descriptor.range.inside.752, %descriptor.payload.inside.749
  br i1 %descriptor.range.valid.751, label %descriptor.valid.753, label %descriptor.invalid.754
descriptor.invalid.754:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.753:
  %descriptor.initialized.status.755 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.739, i32 %local.check.extent.740)
  %helper.ok.756 = icmp eq i32 %descriptor.initialized.status.755, 0
  br i1 %helper.ok.756, label %helper.continue.757, label %frame.failure.0
helper.continue.757:
  br label %local.descriptor.checked.738
local.descriptor.inactive.737:
  br label %local.descriptor.checked.738
local.descriptor.checked.738:
  %local.is.active.758 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.758, label %local.descriptor.active.759, label %local.descriptor.inactive.760
local.descriptor.active.759:
  %local.check.offset.762 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.763 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.764 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.765 = load i32, ptr %local.owner.end.12, align 4
  %context.field.766 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.767 = load i32, ptr %context.field.766, align 4
  %stack.sub.770 = sub i32 %local.check.owner.end.765, %local.check.offset.762
  %descriptor.owner.inside.768 = icmp ule i32 %local.check.owner.end.765, %context.value.767
  %descriptor.offset.inside.769 = icmp ule i32 %local.check.offset.762, %local.check.owner.end.765
  %descriptor.extent.inside.771 = icmp ule i32 %local.check.extent.763, %stack.sub.770
  %descriptor.payload.inside.772 = icmp ule i32 %local.check.payload.764, %local.check.extent.763
  %descriptor.owner.offset.valid.773 = and i1 %descriptor.owner.inside.768, %descriptor.offset.inside.769
  %descriptor.range.inside.775 = and i1 %descriptor.owner.offset.valid.773, %descriptor.extent.inside.771
  %descriptor.range.valid.774 = and i1 %descriptor.range.inside.775, %descriptor.payload.inside.772
  br i1 %descriptor.range.valid.774, label %descriptor.valid.776, label %descriptor.invalid.777
descriptor.invalid.777:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.776:
  %descriptor.initialized.status.778 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.762, i32 %local.check.extent.763)
  %helper.ok.779 = icmp eq i32 %descriptor.initialized.status.778, 0
  br i1 %helper.ok.779, label %helper.continue.780, label %frame.failure.0
helper.continue.780:
  br label %local.descriptor.checked.761
local.descriptor.inactive.760:
  br label %local.descriptor.checked.761
local.descriptor.checked.761:
  %local.is.active.781 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.781, label %local.descriptor.active.782, label %local.descriptor.inactive.783
local.descriptor.active.782:
  %local.check.offset.785 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.786 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.787 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.788 = load i32, ptr %local.owner.end.18, align 4
  %context.field.789 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.790 = load i32, ptr %context.field.789, align 4
  %stack.sub.793 = sub i32 %local.check.owner.end.788, %local.check.offset.785
  %descriptor.owner.inside.791 = icmp ule i32 %local.check.owner.end.788, %context.value.790
  %descriptor.offset.inside.792 = icmp ule i32 %local.check.offset.785, %local.check.owner.end.788
  %descriptor.extent.inside.794 = icmp ule i32 %local.check.extent.786, %stack.sub.793
  %descriptor.payload.inside.795 = icmp ule i32 %local.check.payload.787, %local.check.extent.786
  %descriptor.owner.offset.valid.796 = and i1 %descriptor.owner.inside.791, %descriptor.offset.inside.792
  %descriptor.range.inside.798 = and i1 %descriptor.owner.offset.valid.796, %descriptor.extent.inside.794
  %descriptor.range.valid.797 = and i1 %descriptor.range.inside.798, %descriptor.payload.inside.795
  br i1 %descriptor.range.valid.797, label %descriptor.valid.799, label %descriptor.invalid.800
descriptor.invalid.800:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.799:
  %descriptor.initialized.status.801 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.785, i32 %local.check.extent.786)
  %helper.ok.802 = icmp eq i32 %descriptor.initialized.status.801, 0
  br i1 %helper.ok.802, label %helper.continue.803, label %frame.failure.0
helper.continue.803:
  br label %local.descriptor.checked.784
local.descriptor.inactive.783:
  br label %local.descriptor.checked.784
local.descriptor.checked.784:
  %local.is.active.804 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.804, label %local.descriptor.active.805, label %local.descriptor.inactive.806
local.descriptor.active.805:
  %local.check.offset.808 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.809 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.810 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.811 = load i32, ptr %local.owner.end.24, align 4
  %context.field.812 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.813 = load i32, ptr %context.field.812, align 4
  %stack.sub.816 = sub i32 %local.check.owner.end.811, %local.check.offset.808
  %descriptor.owner.inside.814 = icmp ule i32 %local.check.owner.end.811, %context.value.813
  %descriptor.offset.inside.815 = icmp ule i32 %local.check.offset.808, %local.check.owner.end.811
  %descriptor.extent.inside.817 = icmp ule i32 %local.check.extent.809, %stack.sub.816
  %descriptor.payload.inside.818 = icmp ule i32 %local.check.payload.810, %local.check.extent.809
  %descriptor.owner.offset.valid.819 = and i1 %descriptor.owner.inside.814, %descriptor.offset.inside.815
  %descriptor.range.inside.821 = and i1 %descriptor.owner.offset.valid.819, %descriptor.extent.inside.817
  %descriptor.range.valid.820 = and i1 %descriptor.range.inside.821, %descriptor.payload.inside.818
  br i1 %descriptor.range.valid.820, label %descriptor.valid.822, label %descriptor.invalid.823
descriptor.invalid.823:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.822:
  %descriptor.initialized.status.824 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.808, i32 %local.check.extent.809)
  %helper.ok.825 = icmp eq i32 %descriptor.initialized.status.824, 0
  br i1 %helper.ok.825, label %helper.continue.826, label %frame.failure.0
helper.continue.826:
  br label %local.descriptor.checked.807
local.descriptor.inactive.806:
  br label %local.descriptor.checked.807
local.descriptor.checked.807:
  %local.is.active.827 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.827, label %local.descriptor.active.828, label %local.descriptor.inactive.829
local.descriptor.active.828:
  %local.check.offset.831 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.832 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.833 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.834 = load i32, ptr %local.owner.end.30, align 4
  %context.field.835 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.836 = load i32, ptr %context.field.835, align 4
  %stack.sub.839 = sub i32 %local.check.owner.end.834, %local.check.offset.831
  %descriptor.owner.inside.837 = icmp ule i32 %local.check.owner.end.834, %context.value.836
  %descriptor.offset.inside.838 = icmp ule i32 %local.check.offset.831, %local.check.owner.end.834
  %descriptor.extent.inside.840 = icmp ule i32 %local.check.extent.832, %stack.sub.839
  %descriptor.payload.inside.841 = icmp ule i32 %local.check.payload.833, %local.check.extent.832
  %descriptor.owner.offset.valid.842 = and i1 %descriptor.owner.inside.837, %descriptor.offset.inside.838
  %descriptor.range.inside.844 = and i1 %descriptor.owner.offset.valid.842, %descriptor.extent.inside.840
  %descriptor.range.valid.843 = and i1 %descriptor.range.inside.844, %descriptor.payload.inside.841
  br i1 %descriptor.range.valid.843, label %descriptor.valid.845, label %descriptor.invalid.846
descriptor.invalid.846:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.845:
  %descriptor.initialized.status.847 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.831, i32 %local.check.extent.832)
  %helper.ok.848 = icmp eq i32 %descriptor.initialized.status.847, 0
  br i1 %helper.ok.848, label %helper.continue.849, label %frame.failure.0
helper.continue.849:
  br label %local.descriptor.checked.830
local.descriptor.inactive.829:
  br label %local.descriptor.checked.830
local.descriptor.checked.830:
  %local.is.active.850 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.850, label %local.descriptor.active.851, label %local.descriptor.inactive.852
local.descriptor.active.851:
  %local.check.offset.854 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.855 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.856 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.857 = load i32, ptr %local.owner.end.36, align 4
  %context.field.858 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.859 = load i32, ptr %context.field.858, align 4
  %stack.sub.862 = sub i32 %local.check.owner.end.857, %local.check.offset.854
  %descriptor.owner.inside.860 = icmp ule i32 %local.check.owner.end.857, %context.value.859
  %descriptor.offset.inside.861 = icmp ule i32 %local.check.offset.854, %local.check.owner.end.857
  %descriptor.extent.inside.863 = icmp ule i32 %local.check.extent.855, %stack.sub.862
  %descriptor.payload.inside.864 = icmp ule i32 %local.check.payload.856, %local.check.extent.855
  %descriptor.owner.offset.valid.865 = and i1 %descriptor.owner.inside.860, %descriptor.offset.inside.861
  %descriptor.range.inside.867 = and i1 %descriptor.owner.offset.valid.865, %descriptor.extent.inside.863
  %descriptor.range.valid.866 = and i1 %descriptor.range.inside.867, %descriptor.payload.inside.864
  br i1 %descriptor.range.valid.866, label %descriptor.valid.868, label %descriptor.invalid.869
descriptor.invalid.869:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.868:
  %descriptor.initialized.status.870 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.854, i32 %local.check.extent.855)
  %helper.ok.871 = icmp eq i32 %descriptor.initialized.status.870, 0
  br i1 %helper.ok.871, label %helper.continue.872, label %frame.failure.0
helper.continue.872:
  br label %local.descriptor.checked.853
local.descriptor.inactive.852:
  br label %local.descriptor.checked.853
local.descriptor.checked.853:
  %step.status.873 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.874 = icmp eq i32 %step.status.873, 0
  br i1 %helper.ok.874, label %helper.continue.875, label %frame.failure.0
helper.continue.875:
  store i1 true, ptr %local.active.20, align 1
  store i32 %descriptor.value.113, ptr %local.offset.21, align 4
  store i32 %descriptor.value.115, ptr %local.extent.22, align 4
  store i32 %descriptor.value.117, ptr %local.payload.23, align 4
  store i32 %descriptor.value.119, ptr %local.owner.end.24, align 4
  store i32 12, ptr %local.type.25, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %descriptor.value.113, i32 20, i32 %descriptor.value.117, i32 %descriptor.value.119, i32 %descriptor.value.115)
  %context.field.876 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.877 = load i32, ptr %context.field.876, align 4
  %runtime.ok.878 = icmp eq i32 %context.value.877, 0
  br i1 %runtime.ok.878, label %runtime.continue.879, label %frame.failure.0
runtime.continue.879:
  %context.field.880 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.881 = load i32, ptr %context.field.880, align 4
  %stack.sub.884 = sub i32 %descriptor.value.59, %descriptor.value.53
  %descriptor.owner.inside.882 = icmp ule i32 %descriptor.value.59, %context.value.881
  %descriptor.offset.inside.883 = icmp ule i32 %descriptor.value.53, %descriptor.value.59
  %descriptor.extent.inside.885 = icmp ule i32 %descriptor.value.55, %stack.sub.884
  %descriptor.payload.inside.886 = icmp ule i32 %descriptor.value.57, %descriptor.value.55
  %descriptor.owner.offset.valid.887 = and i1 %descriptor.owner.inside.882, %descriptor.offset.inside.883
  %descriptor.range.inside.889 = and i1 %descriptor.owner.offset.valid.887, %descriptor.extent.inside.885
  %descriptor.range.valid.888 = and i1 %descriptor.range.inside.889, %descriptor.payload.inside.886
  %descriptor.type.valid.890 = icmp eq i32 12, 12
  %descriptor.valid.891 = and i1 %descriptor.range.valid.888, %descriptor.type.valid.890
  br i1 %descriptor.valid.891, label %descriptor.valid.892, label %descriptor.invalid.893
descriptor.invalid.893:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.892:
  %descriptor.initialized.status.894 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.53, i32 %descriptor.value.55)
  %helper.ok.895 = icmp eq i32 %descriptor.initialized.status.894, 0
  br i1 %helper.ok.895, label %helper.continue.896, label %frame.failure.0
helper.continue.896:
  %context.field.897 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.898 = load i32, ptr %context.field.897, align 4
  %stack.sub.901 = sub i32 %descriptor.value.89, %descriptor.value.83
  %descriptor.owner.inside.899 = icmp ule i32 %descriptor.value.89, %context.value.898
  %descriptor.offset.inside.900 = icmp ule i32 %descriptor.value.83, %descriptor.value.89
  %descriptor.extent.inside.902 = icmp ule i32 %descriptor.value.85, %stack.sub.901
  %descriptor.payload.inside.903 = icmp ule i32 %descriptor.value.87, %descriptor.value.85
  %descriptor.owner.offset.valid.904 = and i1 %descriptor.owner.inside.899, %descriptor.offset.inside.900
  %descriptor.range.inside.906 = and i1 %descriptor.owner.offset.valid.904, %descriptor.extent.inside.902
  %descriptor.range.valid.905 = and i1 %descriptor.range.inside.906, %descriptor.payload.inside.903
  %descriptor.type.valid.907 = icmp eq i32 12, 12
  %descriptor.valid.908 = and i1 %descriptor.range.valid.905, %descriptor.type.valid.907
  br i1 %descriptor.valid.908, label %descriptor.valid.909, label %descriptor.invalid.910
descriptor.invalid.910:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.909:
  %descriptor.initialized.status.911 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.83, i32 %descriptor.value.85)
  %helper.ok.912 = icmp eq i32 %descriptor.initialized.status.911, 0
  br i1 %helper.ok.912, label %helper.continue.913, label %frame.failure.0
helper.continue.913:
  %local.is.active.914 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.914, label %local.descriptor.active.915, label %local.descriptor.inactive.916
local.descriptor.active.915:
  %local.check.offset.918 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.919 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.920 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.921 = load i32, ptr %local.owner.end.6, align 4
  %context.field.922 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.923 = load i32, ptr %context.field.922, align 4
  %stack.sub.926 = sub i32 %local.check.owner.end.921, %local.check.offset.918
  %descriptor.owner.inside.924 = icmp ule i32 %local.check.owner.end.921, %context.value.923
  %descriptor.offset.inside.925 = icmp ule i32 %local.check.offset.918, %local.check.owner.end.921
  %descriptor.extent.inside.927 = icmp ule i32 %local.check.extent.919, %stack.sub.926
  %descriptor.payload.inside.928 = icmp ule i32 %local.check.payload.920, %local.check.extent.919
  %descriptor.owner.offset.valid.929 = and i1 %descriptor.owner.inside.924, %descriptor.offset.inside.925
  %descriptor.range.inside.931 = and i1 %descriptor.owner.offset.valid.929, %descriptor.extent.inside.927
  %descriptor.range.valid.930 = and i1 %descriptor.range.inside.931, %descriptor.payload.inside.928
  br i1 %descriptor.range.valid.930, label %descriptor.valid.932, label %descriptor.invalid.933
descriptor.invalid.933:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.932:
  %descriptor.initialized.status.934 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.918, i32 %local.check.extent.919)
  %helper.ok.935 = icmp eq i32 %descriptor.initialized.status.934, 0
  br i1 %helper.ok.935, label %helper.continue.936, label %frame.failure.0
helper.continue.936:
  br label %local.descriptor.checked.917
local.descriptor.inactive.916:
  br label %local.descriptor.checked.917
local.descriptor.checked.917:
  %local.is.active.937 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.937, label %local.descriptor.active.938, label %local.descriptor.inactive.939
local.descriptor.active.938:
  %local.check.offset.941 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.942 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.943 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.944 = load i32, ptr %local.owner.end.12, align 4
  %context.field.945 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.946 = load i32, ptr %context.field.945, align 4
  %stack.sub.949 = sub i32 %local.check.owner.end.944, %local.check.offset.941
  %descriptor.owner.inside.947 = icmp ule i32 %local.check.owner.end.944, %context.value.946
  %descriptor.offset.inside.948 = icmp ule i32 %local.check.offset.941, %local.check.owner.end.944
  %descriptor.extent.inside.950 = icmp ule i32 %local.check.extent.942, %stack.sub.949
  %descriptor.payload.inside.951 = icmp ule i32 %local.check.payload.943, %local.check.extent.942
  %descriptor.owner.offset.valid.952 = and i1 %descriptor.owner.inside.947, %descriptor.offset.inside.948
  %descriptor.range.inside.954 = and i1 %descriptor.owner.offset.valid.952, %descriptor.extent.inside.950
  %descriptor.range.valid.953 = and i1 %descriptor.range.inside.954, %descriptor.payload.inside.951
  br i1 %descriptor.range.valid.953, label %descriptor.valid.955, label %descriptor.invalid.956
descriptor.invalid.956:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.955:
  %descriptor.initialized.status.957 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.941, i32 %local.check.extent.942)
  %helper.ok.958 = icmp eq i32 %descriptor.initialized.status.957, 0
  br i1 %helper.ok.958, label %helper.continue.959, label %frame.failure.0
helper.continue.959:
  br label %local.descriptor.checked.940
local.descriptor.inactive.939:
  br label %local.descriptor.checked.940
local.descriptor.checked.940:
  %local.is.active.960 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.960, label %local.descriptor.active.961, label %local.descriptor.inactive.962
local.descriptor.active.961:
  %local.check.offset.964 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.965 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.966 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.967 = load i32, ptr %local.owner.end.18, align 4
  %context.field.968 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.969 = load i32, ptr %context.field.968, align 4
  %stack.sub.972 = sub i32 %local.check.owner.end.967, %local.check.offset.964
  %descriptor.owner.inside.970 = icmp ule i32 %local.check.owner.end.967, %context.value.969
  %descriptor.offset.inside.971 = icmp ule i32 %local.check.offset.964, %local.check.owner.end.967
  %descriptor.extent.inside.973 = icmp ule i32 %local.check.extent.965, %stack.sub.972
  %descriptor.payload.inside.974 = icmp ule i32 %local.check.payload.966, %local.check.extent.965
  %descriptor.owner.offset.valid.975 = and i1 %descriptor.owner.inside.970, %descriptor.offset.inside.971
  %descriptor.range.inside.977 = and i1 %descriptor.owner.offset.valid.975, %descriptor.extent.inside.973
  %descriptor.range.valid.976 = and i1 %descriptor.range.inside.977, %descriptor.payload.inside.974
  br i1 %descriptor.range.valid.976, label %descriptor.valid.978, label %descriptor.invalid.979
descriptor.invalid.979:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.978:
  %descriptor.initialized.status.980 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.964, i32 %local.check.extent.965)
  %helper.ok.981 = icmp eq i32 %descriptor.initialized.status.980, 0
  br i1 %helper.ok.981, label %helper.continue.982, label %frame.failure.0
helper.continue.982:
  br label %local.descriptor.checked.963
local.descriptor.inactive.962:
  br label %local.descriptor.checked.963
local.descriptor.checked.963:
  %local.is.active.983 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.983, label %local.descriptor.active.984, label %local.descriptor.inactive.985
local.descriptor.active.984:
  %local.check.offset.987 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.988 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.989 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.990 = load i32, ptr %local.owner.end.24, align 4
  %context.field.991 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.992 = load i32, ptr %context.field.991, align 4
  %stack.sub.995 = sub i32 %local.check.owner.end.990, %local.check.offset.987
  %descriptor.owner.inside.993 = icmp ule i32 %local.check.owner.end.990, %context.value.992
  %descriptor.offset.inside.994 = icmp ule i32 %local.check.offset.987, %local.check.owner.end.990
  %descriptor.extent.inside.996 = icmp ule i32 %local.check.extent.988, %stack.sub.995
  %descriptor.payload.inside.997 = icmp ule i32 %local.check.payload.989, %local.check.extent.988
  %descriptor.owner.offset.valid.998 = and i1 %descriptor.owner.inside.993, %descriptor.offset.inside.994
  %descriptor.range.inside.1000 = and i1 %descriptor.owner.offset.valid.998, %descriptor.extent.inside.996
  %descriptor.range.valid.999 = and i1 %descriptor.range.inside.1000, %descriptor.payload.inside.997
  br i1 %descriptor.range.valid.999, label %descriptor.valid.1001, label %descriptor.invalid.1002
descriptor.invalid.1002:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1001:
  %descriptor.initialized.status.1003 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.987, i32 %local.check.extent.988)
  %helper.ok.1004 = icmp eq i32 %descriptor.initialized.status.1003, 0
  br i1 %helper.ok.1004, label %helper.continue.1005, label %frame.failure.0
helper.continue.1005:
  br label %local.descriptor.checked.986
local.descriptor.inactive.985:
  br label %local.descriptor.checked.986
local.descriptor.checked.986:
  %local.is.active.1006 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1006, label %local.descriptor.active.1007, label %local.descriptor.inactive.1008
local.descriptor.active.1007:
  %local.check.offset.1010 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1011 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1012 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1013 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1014 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1015 = load i32, ptr %context.field.1014, align 4
  %stack.sub.1018 = sub i32 %local.check.owner.end.1013, %local.check.offset.1010
  %descriptor.owner.inside.1016 = icmp ule i32 %local.check.owner.end.1013, %context.value.1015
  %descriptor.offset.inside.1017 = icmp ule i32 %local.check.offset.1010, %local.check.owner.end.1013
  %descriptor.extent.inside.1019 = icmp ule i32 %local.check.extent.1011, %stack.sub.1018
  %descriptor.payload.inside.1020 = icmp ule i32 %local.check.payload.1012, %local.check.extent.1011
  %descriptor.owner.offset.valid.1021 = and i1 %descriptor.owner.inside.1016, %descriptor.offset.inside.1017
  %descriptor.range.inside.1023 = and i1 %descriptor.owner.offset.valid.1021, %descriptor.extent.inside.1019
  %descriptor.range.valid.1022 = and i1 %descriptor.range.inside.1023, %descriptor.payload.inside.1020
  br i1 %descriptor.range.valid.1022, label %descriptor.valid.1024, label %descriptor.invalid.1025
descriptor.invalid.1025:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1024:
  %descriptor.initialized.status.1026 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1010, i32 %local.check.extent.1011)
  %helper.ok.1027 = icmp eq i32 %descriptor.initialized.status.1026, 0
  br i1 %helper.ok.1027, label %helper.continue.1028, label %frame.failure.0
helper.continue.1028:
  br label %local.descriptor.checked.1009
local.descriptor.inactive.1008:
  br label %local.descriptor.checked.1009
local.descriptor.checked.1009:
  %local.is.active.1029 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1029, label %local.descriptor.active.1030, label %local.descriptor.inactive.1031
local.descriptor.active.1030:
  %local.check.offset.1033 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1034 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1035 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1036 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1037 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1038 = load i32, ptr %context.field.1037, align 4
  %stack.sub.1041 = sub i32 %local.check.owner.end.1036, %local.check.offset.1033
  %descriptor.owner.inside.1039 = icmp ule i32 %local.check.owner.end.1036, %context.value.1038
  %descriptor.offset.inside.1040 = icmp ule i32 %local.check.offset.1033, %local.check.owner.end.1036
  %descriptor.extent.inside.1042 = icmp ule i32 %local.check.extent.1034, %stack.sub.1041
  %descriptor.payload.inside.1043 = icmp ule i32 %local.check.payload.1035, %local.check.extent.1034
  %descriptor.owner.offset.valid.1044 = and i1 %descriptor.owner.inside.1039, %descriptor.offset.inside.1040
  %descriptor.range.inside.1046 = and i1 %descriptor.owner.offset.valid.1044, %descriptor.extent.inside.1042
  %descriptor.range.valid.1045 = and i1 %descriptor.range.inside.1046, %descriptor.payload.inside.1043
  br i1 %descriptor.range.valid.1045, label %descriptor.valid.1047, label %descriptor.invalid.1048
descriptor.invalid.1048:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1047:
  %descriptor.initialized.status.1049 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1033, i32 %local.check.extent.1034)
  %helper.ok.1050 = icmp eq i32 %descriptor.initialized.status.1049, 0
  br i1 %helper.ok.1050, label %helper.continue.1051, label %frame.failure.0
helper.continue.1051:
  br label %local.descriptor.checked.1032
local.descriptor.inactive.1031:
  br label %local.descriptor.checked.1032
local.descriptor.checked.1032:
  %step.status.1052 = call i32 @al_owning_charge_step(ptr %ctx, i32 6)
  %helper.ok.1053 = icmp eq i32 %step.status.1052, 0
  br i1 %helper.ok.1053, label %helper.continue.1054, label %frame.failure.0
helper.continue.1054:
  store i1 true, ptr %local.active.26, align 1
  store i32 %descriptor.value.83, ptr %local.offset.27, align 4
  store i32 %descriptor.value.85, ptr %local.extent.28, align 4
  store i32 %descriptor.value.87, ptr %local.payload.29, align 4
  store i32 %descriptor.value.89, ptr %local.owner.end.30, align 4
  store i32 12, ptr %local.type.31, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %descriptor.value.83, i32 20, i32 %descriptor.value.87, i32 %descriptor.value.89, i32 %descriptor.value.85)
  %context.field.1055 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1056 = load i32, ptr %context.field.1055, align 4
  %runtime.ok.1057 = icmp eq i32 %context.value.1056, 0
  br i1 %runtime.ok.1057, label %runtime.continue.1058, label %frame.failure.0
runtime.continue.1058:
  %context.field.1059 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1060 = load i32, ptr %context.field.1059, align 4
  %stack.sub.1063 = sub i32 %descriptor.value.59, %descriptor.value.53
  %descriptor.owner.inside.1061 = icmp ule i32 %descriptor.value.59, %context.value.1060
  %descriptor.offset.inside.1062 = icmp ule i32 %descriptor.value.53, %descriptor.value.59
  %descriptor.extent.inside.1064 = icmp ule i32 %descriptor.value.55, %stack.sub.1063
  %descriptor.payload.inside.1065 = icmp ule i32 %descriptor.value.57, %descriptor.value.55
  %descriptor.owner.offset.valid.1066 = and i1 %descriptor.owner.inside.1061, %descriptor.offset.inside.1062
  %descriptor.range.inside.1068 = and i1 %descriptor.owner.offset.valid.1066, %descriptor.extent.inside.1064
  %descriptor.range.valid.1067 = and i1 %descriptor.range.inside.1068, %descriptor.payload.inside.1065
  %descriptor.type.valid.1069 = icmp eq i32 12, 12
  %descriptor.valid.1070 = and i1 %descriptor.range.valid.1067, %descriptor.type.valid.1069
  br i1 %descriptor.valid.1070, label %descriptor.valid.1071, label %descriptor.invalid.1072
descriptor.invalid.1072:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1071:
  %descriptor.initialized.status.1073 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.53, i32 %descriptor.value.55)
  %helper.ok.1074 = icmp eq i32 %descriptor.initialized.status.1073, 0
  br i1 %helper.ok.1074, label %helper.continue.1075, label %frame.failure.0
helper.continue.1075:
  %local.is.active.1076 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1076, label %local.descriptor.active.1077, label %local.descriptor.inactive.1078
local.descriptor.active.1077:
  %local.check.offset.1080 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1081 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1082 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1083 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1084 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1085 = load i32, ptr %context.field.1084, align 4
  %stack.sub.1088 = sub i32 %local.check.owner.end.1083, %local.check.offset.1080
  %descriptor.owner.inside.1086 = icmp ule i32 %local.check.owner.end.1083, %context.value.1085
  %descriptor.offset.inside.1087 = icmp ule i32 %local.check.offset.1080, %local.check.owner.end.1083
  %descriptor.extent.inside.1089 = icmp ule i32 %local.check.extent.1081, %stack.sub.1088
  %descriptor.payload.inside.1090 = icmp ule i32 %local.check.payload.1082, %local.check.extent.1081
  %descriptor.owner.offset.valid.1091 = and i1 %descriptor.owner.inside.1086, %descriptor.offset.inside.1087
  %descriptor.range.inside.1093 = and i1 %descriptor.owner.offset.valid.1091, %descriptor.extent.inside.1089
  %descriptor.range.valid.1092 = and i1 %descriptor.range.inside.1093, %descriptor.payload.inside.1090
  br i1 %descriptor.range.valid.1092, label %descriptor.valid.1094, label %descriptor.invalid.1095
descriptor.invalid.1095:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1094:
  %descriptor.initialized.status.1096 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1080, i32 %local.check.extent.1081)
  %helper.ok.1097 = icmp eq i32 %descriptor.initialized.status.1096, 0
  br i1 %helper.ok.1097, label %helper.continue.1098, label %frame.failure.0
helper.continue.1098:
  br label %local.descriptor.checked.1079
local.descriptor.inactive.1078:
  br label %local.descriptor.checked.1079
local.descriptor.checked.1079:
  %local.is.active.1099 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1099, label %local.descriptor.active.1100, label %local.descriptor.inactive.1101
local.descriptor.active.1100:
  %local.check.offset.1103 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1104 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1105 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1106 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1107 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1108 = load i32, ptr %context.field.1107, align 4
  %stack.sub.1111 = sub i32 %local.check.owner.end.1106, %local.check.offset.1103
  %descriptor.owner.inside.1109 = icmp ule i32 %local.check.owner.end.1106, %context.value.1108
  %descriptor.offset.inside.1110 = icmp ule i32 %local.check.offset.1103, %local.check.owner.end.1106
  %descriptor.extent.inside.1112 = icmp ule i32 %local.check.extent.1104, %stack.sub.1111
  %descriptor.payload.inside.1113 = icmp ule i32 %local.check.payload.1105, %local.check.extent.1104
  %descriptor.owner.offset.valid.1114 = and i1 %descriptor.owner.inside.1109, %descriptor.offset.inside.1110
  %descriptor.range.inside.1116 = and i1 %descriptor.owner.offset.valid.1114, %descriptor.extent.inside.1112
  %descriptor.range.valid.1115 = and i1 %descriptor.range.inside.1116, %descriptor.payload.inside.1113
  br i1 %descriptor.range.valid.1115, label %descriptor.valid.1117, label %descriptor.invalid.1118
descriptor.invalid.1118:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1117:
  %descriptor.initialized.status.1119 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1103, i32 %local.check.extent.1104)
  %helper.ok.1120 = icmp eq i32 %descriptor.initialized.status.1119, 0
  br i1 %helper.ok.1120, label %helper.continue.1121, label %frame.failure.0
helper.continue.1121:
  br label %local.descriptor.checked.1102
local.descriptor.inactive.1101:
  br label %local.descriptor.checked.1102
local.descriptor.checked.1102:
  %local.is.active.1122 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1122, label %local.descriptor.active.1123, label %local.descriptor.inactive.1124
local.descriptor.active.1123:
  %local.check.offset.1126 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1127 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1128 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1129 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1130 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1131 = load i32, ptr %context.field.1130, align 4
  %stack.sub.1134 = sub i32 %local.check.owner.end.1129, %local.check.offset.1126
  %descriptor.owner.inside.1132 = icmp ule i32 %local.check.owner.end.1129, %context.value.1131
  %descriptor.offset.inside.1133 = icmp ule i32 %local.check.offset.1126, %local.check.owner.end.1129
  %descriptor.extent.inside.1135 = icmp ule i32 %local.check.extent.1127, %stack.sub.1134
  %descriptor.payload.inside.1136 = icmp ule i32 %local.check.payload.1128, %local.check.extent.1127
  %descriptor.owner.offset.valid.1137 = and i1 %descriptor.owner.inside.1132, %descriptor.offset.inside.1133
  %descriptor.range.inside.1139 = and i1 %descriptor.owner.offset.valid.1137, %descriptor.extent.inside.1135
  %descriptor.range.valid.1138 = and i1 %descriptor.range.inside.1139, %descriptor.payload.inside.1136
  br i1 %descriptor.range.valid.1138, label %descriptor.valid.1140, label %descriptor.invalid.1141
descriptor.invalid.1141:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1140:
  %descriptor.initialized.status.1142 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1126, i32 %local.check.extent.1127)
  %helper.ok.1143 = icmp eq i32 %descriptor.initialized.status.1142, 0
  br i1 %helper.ok.1143, label %helper.continue.1144, label %frame.failure.0
helper.continue.1144:
  br label %local.descriptor.checked.1125
local.descriptor.inactive.1124:
  br label %local.descriptor.checked.1125
local.descriptor.checked.1125:
  %local.is.active.1145 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1145, label %local.descriptor.active.1146, label %local.descriptor.inactive.1147
local.descriptor.active.1146:
  %local.check.offset.1149 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1150 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1151 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1152 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1153 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1154 = load i32, ptr %context.field.1153, align 4
  %stack.sub.1157 = sub i32 %local.check.owner.end.1152, %local.check.offset.1149
  %descriptor.owner.inside.1155 = icmp ule i32 %local.check.owner.end.1152, %context.value.1154
  %descriptor.offset.inside.1156 = icmp ule i32 %local.check.offset.1149, %local.check.owner.end.1152
  %descriptor.extent.inside.1158 = icmp ule i32 %local.check.extent.1150, %stack.sub.1157
  %descriptor.payload.inside.1159 = icmp ule i32 %local.check.payload.1151, %local.check.extent.1150
  %descriptor.owner.offset.valid.1160 = and i1 %descriptor.owner.inside.1155, %descriptor.offset.inside.1156
  %descriptor.range.inside.1162 = and i1 %descriptor.owner.offset.valid.1160, %descriptor.extent.inside.1158
  %descriptor.range.valid.1161 = and i1 %descriptor.range.inside.1162, %descriptor.payload.inside.1159
  br i1 %descriptor.range.valid.1161, label %descriptor.valid.1163, label %descriptor.invalid.1164
descriptor.invalid.1164:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1163:
  %descriptor.initialized.status.1165 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1149, i32 %local.check.extent.1150)
  %helper.ok.1166 = icmp eq i32 %descriptor.initialized.status.1165, 0
  br i1 %helper.ok.1166, label %helper.continue.1167, label %frame.failure.0
helper.continue.1167:
  br label %local.descriptor.checked.1148
local.descriptor.inactive.1147:
  br label %local.descriptor.checked.1148
local.descriptor.checked.1148:
  %local.is.active.1168 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1168, label %local.descriptor.active.1169, label %local.descriptor.inactive.1170
local.descriptor.active.1169:
  %local.check.offset.1172 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1173 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1174 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1175 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1176 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1177 = load i32, ptr %context.field.1176, align 4
  %stack.sub.1180 = sub i32 %local.check.owner.end.1175, %local.check.offset.1172
  %descriptor.owner.inside.1178 = icmp ule i32 %local.check.owner.end.1175, %context.value.1177
  %descriptor.offset.inside.1179 = icmp ule i32 %local.check.offset.1172, %local.check.owner.end.1175
  %descriptor.extent.inside.1181 = icmp ule i32 %local.check.extent.1173, %stack.sub.1180
  %descriptor.payload.inside.1182 = icmp ule i32 %local.check.payload.1174, %local.check.extent.1173
  %descriptor.owner.offset.valid.1183 = and i1 %descriptor.owner.inside.1178, %descriptor.offset.inside.1179
  %descriptor.range.inside.1185 = and i1 %descriptor.owner.offset.valid.1183, %descriptor.extent.inside.1181
  %descriptor.range.valid.1184 = and i1 %descriptor.range.inside.1185, %descriptor.payload.inside.1182
  br i1 %descriptor.range.valid.1184, label %descriptor.valid.1186, label %descriptor.invalid.1187
descriptor.invalid.1187:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1186:
  %descriptor.initialized.status.1188 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1172, i32 %local.check.extent.1173)
  %helper.ok.1189 = icmp eq i32 %descriptor.initialized.status.1188, 0
  br i1 %helper.ok.1189, label %helper.continue.1190, label %frame.failure.0
helper.continue.1190:
  br label %local.descriptor.checked.1171
local.descriptor.inactive.1170:
  br label %local.descriptor.checked.1171
local.descriptor.checked.1171:
  %local.is.active.1191 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1191, label %local.descriptor.active.1192, label %local.descriptor.inactive.1193
local.descriptor.active.1192:
  %local.check.offset.1195 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1196 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1197 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1198 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1199 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1200 = load i32, ptr %context.field.1199, align 4
  %stack.sub.1203 = sub i32 %local.check.owner.end.1198, %local.check.offset.1195
  %descriptor.owner.inside.1201 = icmp ule i32 %local.check.owner.end.1198, %context.value.1200
  %descriptor.offset.inside.1202 = icmp ule i32 %local.check.offset.1195, %local.check.owner.end.1198
  %descriptor.extent.inside.1204 = icmp ule i32 %local.check.extent.1196, %stack.sub.1203
  %descriptor.payload.inside.1205 = icmp ule i32 %local.check.payload.1197, %local.check.extent.1196
  %descriptor.owner.offset.valid.1206 = and i1 %descriptor.owner.inside.1201, %descriptor.offset.inside.1202
  %descriptor.range.inside.1208 = and i1 %descriptor.owner.offset.valid.1206, %descriptor.extent.inside.1204
  %descriptor.range.valid.1207 = and i1 %descriptor.range.inside.1208, %descriptor.payload.inside.1205
  br i1 %descriptor.range.valid.1207, label %descriptor.valid.1209, label %descriptor.invalid.1210
descriptor.invalid.1210:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1209:
  %descriptor.initialized.status.1211 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1195, i32 %local.check.extent.1196)
  %helper.ok.1212 = icmp eq i32 %descriptor.initialized.status.1211, 0
  br i1 %helper.ok.1212, label %helper.continue.1213, label %frame.failure.0
helper.continue.1213:
  br label %local.descriptor.checked.1194
local.descriptor.inactive.1193:
  br label %local.descriptor.checked.1194
local.descriptor.checked.1194:
  %step.status.1214 = call i32 @al_owning_charge_step(ptr %ctx, i32 7)
  %helper.ok.1215 = icmp eq i32 %step.status.1214, 0
  br i1 %helper.ok.1215, label %helper.continue.1216, label %frame.failure.0
helper.continue.1216:
  store i1 true, ptr %local.active.32, align 1
  store i32 %descriptor.value.53, ptr %local.offset.33, align 4
  store i32 %descriptor.value.55, ptr %local.extent.34, align 4
  store i32 %descriptor.value.57, ptr %local.payload.35, align 4
  store i32 %descriptor.value.59, ptr %local.owner.end.36, align 4
  store i32 12, ptr %local.type.37, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %descriptor.value.53, i32 20, i32 %descriptor.value.57, i32 %descriptor.value.59, i32 %descriptor.value.55)
  %context.field.1217 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1218 = load i32, ptr %context.field.1217, align 4
  %runtime.ok.1219 = icmp eq i32 %context.value.1218, 0
  br i1 %runtime.ok.1219, label %runtime.continue.1220, label %frame.failure.0
runtime.continue.1220:
  %local.is.active.1221 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1221, label %local.descriptor.active.1222, label %local.descriptor.inactive.1223
local.descriptor.active.1222:
  %local.check.offset.1225 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1226 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1227 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1228 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1229 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1230 = load i32, ptr %context.field.1229, align 4
  %stack.sub.1233 = sub i32 %local.check.owner.end.1228, %local.check.offset.1225
  %descriptor.owner.inside.1231 = icmp ule i32 %local.check.owner.end.1228, %context.value.1230
  %descriptor.offset.inside.1232 = icmp ule i32 %local.check.offset.1225, %local.check.owner.end.1228
  %descriptor.extent.inside.1234 = icmp ule i32 %local.check.extent.1226, %stack.sub.1233
  %descriptor.payload.inside.1235 = icmp ule i32 %local.check.payload.1227, %local.check.extent.1226
  %descriptor.owner.offset.valid.1236 = and i1 %descriptor.owner.inside.1231, %descriptor.offset.inside.1232
  %descriptor.range.inside.1238 = and i1 %descriptor.owner.offset.valid.1236, %descriptor.extent.inside.1234
  %descriptor.range.valid.1237 = and i1 %descriptor.range.inside.1238, %descriptor.payload.inside.1235
  br i1 %descriptor.range.valid.1237, label %descriptor.valid.1239, label %descriptor.invalid.1240
descriptor.invalid.1240:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1239:
  %descriptor.initialized.status.1241 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1225, i32 %local.check.extent.1226)
  %helper.ok.1242 = icmp eq i32 %descriptor.initialized.status.1241, 0
  br i1 %helper.ok.1242, label %helper.continue.1243, label %frame.failure.0
helper.continue.1243:
  br label %local.descriptor.checked.1224
local.descriptor.inactive.1223:
  br label %local.descriptor.checked.1224
local.descriptor.checked.1224:
  %local.is.active.1244 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1244, label %local.descriptor.active.1245, label %local.descriptor.inactive.1246
local.descriptor.active.1245:
  %local.check.offset.1248 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1249 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1250 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1251 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1252 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1253 = load i32, ptr %context.field.1252, align 4
  %stack.sub.1256 = sub i32 %local.check.owner.end.1251, %local.check.offset.1248
  %descriptor.owner.inside.1254 = icmp ule i32 %local.check.owner.end.1251, %context.value.1253
  %descriptor.offset.inside.1255 = icmp ule i32 %local.check.offset.1248, %local.check.owner.end.1251
  %descriptor.extent.inside.1257 = icmp ule i32 %local.check.extent.1249, %stack.sub.1256
  %descriptor.payload.inside.1258 = icmp ule i32 %local.check.payload.1250, %local.check.extent.1249
  %descriptor.owner.offset.valid.1259 = and i1 %descriptor.owner.inside.1254, %descriptor.offset.inside.1255
  %descriptor.range.inside.1261 = and i1 %descriptor.owner.offset.valid.1259, %descriptor.extent.inside.1257
  %descriptor.range.valid.1260 = and i1 %descriptor.range.inside.1261, %descriptor.payload.inside.1258
  br i1 %descriptor.range.valid.1260, label %descriptor.valid.1262, label %descriptor.invalid.1263
descriptor.invalid.1263:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1262:
  %descriptor.initialized.status.1264 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1248, i32 %local.check.extent.1249)
  %helper.ok.1265 = icmp eq i32 %descriptor.initialized.status.1264, 0
  br i1 %helper.ok.1265, label %helper.continue.1266, label %frame.failure.0
helper.continue.1266:
  br label %local.descriptor.checked.1247
local.descriptor.inactive.1246:
  br label %local.descriptor.checked.1247
local.descriptor.checked.1247:
  %local.is.active.1267 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1267, label %local.descriptor.active.1268, label %local.descriptor.inactive.1269
local.descriptor.active.1268:
  %local.check.offset.1271 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1272 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1273 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1274 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1275 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1276 = load i32, ptr %context.field.1275, align 4
  %stack.sub.1279 = sub i32 %local.check.owner.end.1274, %local.check.offset.1271
  %descriptor.owner.inside.1277 = icmp ule i32 %local.check.owner.end.1274, %context.value.1276
  %descriptor.offset.inside.1278 = icmp ule i32 %local.check.offset.1271, %local.check.owner.end.1274
  %descriptor.extent.inside.1280 = icmp ule i32 %local.check.extent.1272, %stack.sub.1279
  %descriptor.payload.inside.1281 = icmp ule i32 %local.check.payload.1273, %local.check.extent.1272
  %descriptor.owner.offset.valid.1282 = and i1 %descriptor.owner.inside.1277, %descriptor.offset.inside.1278
  %descriptor.range.inside.1284 = and i1 %descriptor.owner.offset.valid.1282, %descriptor.extent.inside.1280
  %descriptor.range.valid.1283 = and i1 %descriptor.range.inside.1284, %descriptor.payload.inside.1281
  br i1 %descriptor.range.valid.1283, label %descriptor.valid.1285, label %descriptor.invalid.1286
descriptor.invalid.1286:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1285:
  %descriptor.initialized.status.1287 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1271, i32 %local.check.extent.1272)
  %helper.ok.1288 = icmp eq i32 %descriptor.initialized.status.1287, 0
  br i1 %helper.ok.1288, label %helper.continue.1289, label %frame.failure.0
helper.continue.1289:
  br label %local.descriptor.checked.1270
local.descriptor.inactive.1269:
  br label %local.descriptor.checked.1270
local.descriptor.checked.1270:
  %local.is.active.1290 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1290, label %local.descriptor.active.1291, label %local.descriptor.inactive.1292
local.descriptor.active.1291:
  %local.check.offset.1294 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1295 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1296 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1297 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1298 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1299 = load i32, ptr %context.field.1298, align 4
  %stack.sub.1302 = sub i32 %local.check.owner.end.1297, %local.check.offset.1294
  %descriptor.owner.inside.1300 = icmp ule i32 %local.check.owner.end.1297, %context.value.1299
  %descriptor.offset.inside.1301 = icmp ule i32 %local.check.offset.1294, %local.check.owner.end.1297
  %descriptor.extent.inside.1303 = icmp ule i32 %local.check.extent.1295, %stack.sub.1302
  %descriptor.payload.inside.1304 = icmp ule i32 %local.check.payload.1296, %local.check.extent.1295
  %descriptor.owner.offset.valid.1305 = and i1 %descriptor.owner.inside.1300, %descriptor.offset.inside.1301
  %descriptor.range.inside.1307 = and i1 %descriptor.owner.offset.valid.1305, %descriptor.extent.inside.1303
  %descriptor.range.valid.1306 = and i1 %descriptor.range.inside.1307, %descriptor.payload.inside.1304
  br i1 %descriptor.range.valid.1306, label %descriptor.valid.1308, label %descriptor.invalid.1309
descriptor.invalid.1309:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1308:
  %descriptor.initialized.status.1310 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1294, i32 %local.check.extent.1295)
  %helper.ok.1311 = icmp eq i32 %descriptor.initialized.status.1310, 0
  br i1 %helper.ok.1311, label %helper.continue.1312, label %frame.failure.0
helper.continue.1312:
  br label %local.descriptor.checked.1293
local.descriptor.inactive.1292:
  br label %local.descriptor.checked.1293
local.descriptor.checked.1293:
  %local.is.active.1313 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1313, label %local.descriptor.active.1314, label %local.descriptor.inactive.1315
local.descriptor.active.1314:
  %local.check.offset.1317 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1318 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1319 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1320 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1321 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1322 = load i32, ptr %context.field.1321, align 4
  %stack.sub.1325 = sub i32 %local.check.owner.end.1320, %local.check.offset.1317
  %descriptor.owner.inside.1323 = icmp ule i32 %local.check.owner.end.1320, %context.value.1322
  %descriptor.offset.inside.1324 = icmp ule i32 %local.check.offset.1317, %local.check.owner.end.1320
  %descriptor.extent.inside.1326 = icmp ule i32 %local.check.extent.1318, %stack.sub.1325
  %descriptor.payload.inside.1327 = icmp ule i32 %local.check.payload.1319, %local.check.extent.1318
  %descriptor.owner.offset.valid.1328 = and i1 %descriptor.owner.inside.1323, %descriptor.offset.inside.1324
  %descriptor.range.inside.1330 = and i1 %descriptor.owner.offset.valid.1328, %descriptor.extent.inside.1326
  %descriptor.range.valid.1329 = and i1 %descriptor.range.inside.1330, %descriptor.payload.inside.1327
  br i1 %descriptor.range.valid.1329, label %descriptor.valid.1331, label %descriptor.invalid.1332
descriptor.invalid.1332:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1331:
  %descriptor.initialized.status.1333 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1317, i32 %local.check.extent.1318)
  %helper.ok.1334 = icmp eq i32 %descriptor.initialized.status.1333, 0
  br i1 %helper.ok.1334, label %helper.continue.1335, label %frame.failure.0
helper.continue.1335:
  br label %local.descriptor.checked.1316
local.descriptor.inactive.1315:
  br label %local.descriptor.checked.1316
local.descriptor.checked.1316:
  %local.is.active.1336 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1336, label %local.descriptor.active.1337, label %local.descriptor.inactive.1338
local.descriptor.active.1337:
  %local.check.offset.1340 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1341 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1342 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1343 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1344 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1345 = load i32, ptr %context.field.1344, align 4
  %stack.sub.1348 = sub i32 %local.check.owner.end.1343, %local.check.offset.1340
  %descriptor.owner.inside.1346 = icmp ule i32 %local.check.owner.end.1343, %context.value.1345
  %descriptor.offset.inside.1347 = icmp ule i32 %local.check.offset.1340, %local.check.owner.end.1343
  %descriptor.extent.inside.1349 = icmp ule i32 %local.check.extent.1341, %stack.sub.1348
  %descriptor.payload.inside.1350 = icmp ule i32 %local.check.payload.1342, %local.check.extent.1341
  %descriptor.owner.offset.valid.1351 = and i1 %descriptor.owner.inside.1346, %descriptor.offset.inside.1347
  %descriptor.range.inside.1353 = and i1 %descriptor.owner.offset.valid.1351, %descriptor.extent.inside.1349
  %descriptor.range.valid.1352 = and i1 %descriptor.range.inside.1353, %descriptor.payload.inside.1350
  br i1 %descriptor.range.valid.1352, label %descriptor.valid.1354, label %descriptor.invalid.1355
descriptor.invalid.1355:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1354:
  %descriptor.initialized.status.1356 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1340, i32 %local.check.extent.1341)
  %helper.ok.1357 = icmp eq i32 %descriptor.initialized.status.1356, 0
  br i1 %helper.ok.1357, label %helper.continue.1358, label %frame.failure.0
helper.continue.1358:
  br label %local.descriptor.checked.1339
local.descriptor.inactive.1338:
  br label %local.descriptor.checked.1339
local.descriptor.checked.1339:
  %step.status.1359 = call i32 @al_owning_charge_step(ptr %ctx, i32 8)
  %helper.ok.1360 = icmp eq i32 %step.status.1359, 0
  br i1 %helper.ok.1360, label %helper.continue.1361, label %frame.failure.0
helper.continue.1361:
  %context.field.1362 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1363 = load i32, ptr %context.field.1362, align 4
  %step.status.1364 = call i32 @al_owning_charge_step(ptr %ctx, i32 9)
  %helper.ok.1365 = icmp eq i32 %step.status.1364, 0
  br i1 %helper.ok.1365, label %helper.continue.1366, label %frame.failure.0
helper.continue.1366:
  %local.resolved.offset.1367 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.1368 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.1369 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.1370 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1371 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1372 = load i32, ptr %context.field.1371, align 4
  %stack.sub.1375 = sub i32 %local.resolved.owner.end.1370, %local.resolved.offset.1367
  %descriptor.owner.inside.1373 = icmp ule i32 %local.resolved.owner.end.1370, %context.value.1372
  %descriptor.offset.inside.1374 = icmp ule i32 %local.resolved.offset.1367, %local.resolved.owner.end.1370
  %descriptor.extent.inside.1376 = icmp ule i32 %local.resolved.extent.1368, %stack.sub.1375
  %descriptor.payload.inside.1377 = icmp ule i32 %local.resolved.payload.1369, %local.resolved.extent.1368
  %descriptor.owner.offset.valid.1378 = and i1 %descriptor.owner.inside.1373, %descriptor.offset.inside.1374
  %descriptor.range.inside.1380 = and i1 %descriptor.owner.offset.valid.1378, %descriptor.extent.inside.1376
  %descriptor.range.valid.1379 = and i1 %descriptor.range.inside.1380, %descriptor.payload.inside.1377
  %descriptor.type.valid.1381 = icmp eq i32 12, 12
  %descriptor.valid.1382 = and i1 %descriptor.range.valid.1379, %descriptor.type.valid.1381
  br i1 %descriptor.valid.1382, label %descriptor.valid.1383, label %descriptor.invalid.1384
descriptor.invalid.1384:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1383:
  %descriptor.initialized.status.1385 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1367, i32 %local.resolved.extent.1368)
  %helper.ok.1386 = icmp eq i32 %descriptor.initialized.status.1385, 0
  br i1 %helper.ok.1386, label %helper.continue.1387, label %frame.failure.0
helper.continue.1387:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %local.resolved.offset.1367, i32 20, i32 %local.resolved.payload.1369, i32 %local.resolved.owner.end.1370, i32 %local.resolved.extent.1368)
  %context.field.1388 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1389 = load i32, ptr %context.field.1388, align 4
  %runtime.ok.1390 = icmp eq i32 %context.value.1389, 0
  br i1 %runtime.ok.1390, label %runtime.continue.1391, label %frame.failure.0
runtime.continue.1391:
  %context.field.1392 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1393 = load i32, ptr %context.field.1392, align 4
  %stack.sub.1396 = sub i32 %local.resolved.owner.end.1370, %local.resolved.offset.1367
  %descriptor.owner.inside.1394 = icmp ule i32 %local.resolved.owner.end.1370, %context.value.1393
  %descriptor.offset.inside.1395 = icmp ule i32 %local.resolved.offset.1367, %local.resolved.owner.end.1370
  %descriptor.extent.inside.1397 = icmp ule i32 %local.resolved.extent.1368, %stack.sub.1396
  %descriptor.payload.inside.1398 = icmp ule i32 %local.resolved.payload.1369, %local.resolved.extent.1368
  %descriptor.owner.offset.valid.1399 = and i1 %descriptor.owner.inside.1394, %descriptor.offset.inside.1395
  %descriptor.range.inside.1401 = and i1 %descriptor.owner.offset.valid.1399, %descriptor.extent.inside.1397
  %descriptor.range.valid.1400 = and i1 %descriptor.range.inside.1401, %descriptor.payload.inside.1398
  %descriptor.type.valid.1402 = icmp eq i32 12, 12
  %descriptor.valid.1403 = and i1 %descriptor.range.valid.1400, %descriptor.type.valid.1402
  br i1 %descriptor.valid.1403, label %descriptor.valid.1404, label %descriptor.invalid.1405
descriptor.invalid.1405:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1404:
  %descriptor.initialized.status.1406 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1367, i32 %local.resolved.extent.1368)
  %helper.ok.1407 = icmp eq i32 %descriptor.initialized.status.1406, 0
  br i1 %helper.ok.1407, label %helper.continue.1408, label %frame.failure.0
helper.continue.1408:
  %local.is.active.1409 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1409, label %local.descriptor.active.1410, label %local.descriptor.inactive.1411
local.descriptor.active.1410:
  %local.check.offset.1413 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1414 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1415 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1416 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1417 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1418 = load i32, ptr %context.field.1417, align 4
  %stack.sub.1421 = sub i32 %local.check.owner.end.1416, %local.check.offset.1413
  %descriptor.owner.inside.1419 = icmp ule i32 %local.check.owner.end.1416, %context.value.1418
  %descriptor.offset.inside.1420 = icmp ule i32 %local.check.offset.1413, %local.check.owner.end.1416
  %descriptor.extent.inside.1422 = icmp ule i32 %local.check.extent.1414, %stack.sub.1421
  %descriptor.payload.inside.1423 = icmp ule i32 %local.check.payload.1415, %local.check.extent.1414
  %descriptor.owner.offset.valid.1424 = and i1 %descriptor.owner.inside.1419, %descriptor.offset.inside.1420
  %descriptor.range.inside.1426 = and i1 %descriptor.owner.offset.valid.1424, %descriptor.extent.inside.1422
  %descriptor.range.valid.1425 = and i1 %descriptor.range.inside.1426, %descriptor.payload.inside.1423
  br i1 %descriptor.range.valid.1425, label %descriptor.valid.1427, label %descriptor.invalid.1428
descriptor.invalid.1428:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1427:
  %descriptor.initialized.status.1429 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1413, i32 %local.check.extent.1414)
  %helper.ok.1430 = icmp eq i32 %descriptor.initialized.status.1429, 0
  br i1 %helper.ok.1430, label %helper.continue.1431, label %frame.failure.0
helper.continue.1431:
  br label %local.descriptor.checked.1412
local.descriptor.inactive.1411:
  br label %local.descriptor.checked.1412
local.descriptor.checked.1412:
  %local.is.active.1432 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1432, label %local.descriptor.active.1433, label %local.descriptor.inactive.1434
local.descriptor.active.1433:
  %local.check.offset.1436 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1437 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1438 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1439 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1440 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1441 = load i32, ptr %context.field.1440, align 4
  %stack.sub.1444 = sub i32 %local.check.owner.end.1439, %local.check.offset.1436
  %descriptor.owner.inside.1442 = icmp ule i32 %local.check.owner.end.1439, %context.value.1441
  %descriptor.offset.inside.1443 = icmp ule i32 %local.check.offset.1436, %local.check.owner.end.1439
  %descriptor.extent.inside.1445 = icmp ule i32 %local.check.extent.1437, %stack.sub.1444
  %descriptor.payload.inside.1446 = icmp ule i32 %local.check.payload.1438, %local.check.extent.1437
  %descriptor.owner.offset.valid.1447 = and i1 %descriptor.owner.inside.1442, %descriptor.offset.inside.1443
  %descriptor.range.inside.1449 = and i1 %descriptor.owner.offset.valid.1447, %descriptor.extent.inside.1445
  %descriptor.range.valid.1448 = and i1 %descriptor.range.inside.1449, %descriptor.payload.inside.1446
  br i1 %descriptor.range.valid.1448, label %descriptor.valid.1450, label %descriptor.invalid.1451
descriptor.invalid.1451:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1450:
  %descriptor.initialized.status.1452 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1436, i32 %local.check.extent.1437)
  %helper.ok.1453 = icmp eq i32 %descriptor.initialized.status.1452, 0
  br i1 %helper.ok.1453, label %helper.continue.1454, label %frame.failure.0
helper.continue.1454:
  br label %local.descriptor.checked.1435
local.descriptor.inactive.1434:
  br label %local.descriptor.checked.1435
local.descriptor.checked.1435:
  %local.is.active.1455 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1455, label %local.descriptor.active.1456, label %local.descriptor.inactive.1457
local.descriptor.active.1456:
  %local.check.offset.1459 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1460 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1461 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1462 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1463 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1464 = load i32, ptr %context.field.1463, align 4
  %stack.sub.1467 = sub i32 %local.check.owner.end.1462, %local.check.offset.1459
  %descriptor.owner.inside.1465 = icmp ule i32 %local.check.owner.end.1462, %context.value.1464
  %descriptor.offset.inside.1466 = icmp ule i32 %local.check.offset.1459, %local.check.owner.end.1462
  %descriptor.extent.inside.1468 = icmp ule i32 %local.check.extent.1460, %stack.sub.1467
  %descriptor.payload.inside.1469 = icmp ule i32 %local.check.payload.1461, %local.check.extent.1460
  %descriptor.owner.offset.valid.1470 = and i1 %descriptor.owner.inside.1465, %descriptor.offset.inside.1466
  %descriptor.range.inside.1472 = and i1 %descriptor.owner.offset.valid.1470, %descriptor.extent.inside.1468
  %descriptor.range.valid.1471 = and i1 %descriptor.range.inside.1472, %descriptor.payload.inside.1469
  br i1 %descriptor.range.valid.1471, label %descriptor.valid.1473, label %descriptor.invalid.1474
descriptor.invalid.1474:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1473:
  %descriptor.initialized.status.1475 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1459, i32 %local.check.extent.1460)
  %helper.ok.1476 = icmp eq i32 %descriptor.initialized.status.1475, 0
  br i1 %helper.ok.1476, label %helper.continue.1477, label %frame.failure.0
helper.continue.1477:
  br label %local.descriptor.checked.1458
local.descriptor.inactive.1457:
  br label %local.descriptor.checked.1458
local.descriptor.checked.1458:
  %local.is.active.1478 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1478, label %local.descriptor.active.1479, label %local.descriptor.inactive.1480
local.descriptor.active.1479:
  %local.check.offset.1482 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1483 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1484 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1485 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1486 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1487 = load i32, ptr %context.field.1486, align 4
  %stack.sub.1490 = sub i32 %local.check.owner.end.1485, %local.check.offset.1482
  %descriptor.owner.inside.1488 = icmp ule i32 %local.check.owner.end.1485, %context.value.1487
  %descriptor.offset.inside.1489 = icmp ule i32 %local.check.offset.1482, %local.check.owner.end.1485
  %descriptor.extent.inside.1491 = icmp ule i32 %local.check.extent.1483, %stack.sub.1490
  %descriptor.payload.inside.1492 = icmp ule i32 %local.check.payload.1484, %local.check.extent.1483
  %descriptor.owner.offset.valid.1493 = and i1 %descriptor.owner.inside.1488, %descriptor.offset.inside.1489
  %descriptor.range.inside.1495 = and i1 %descriptor.owner.offset.valid.1493, %descriptor.extent.inside.1491
  %descriptor.range.valid.1494 = and i1 %descriptor.range.inside.1495, %descriptor.payload.inside.1492
  br i1 %descriptor.range.valid.1494, label %descriptor.valid.1496, label %descriptor.invalid.1497
descriptor.invalid.1497:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1496:
  %descriptor.initialized.status.1498 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1482, i32 %local.check.extent.1483)
  %helper.ok.1499 = icmp eq i32 %descriptor.initialized.status.1498, 0
  br i1 %helper.ok.1499, label %helper.continue.1500, label %frame.failure.0
helper.continue.1500:
  br label %local.descriptor.checked.1481
local.descriptor.inactive.1480:
  br label %local.descriptor.checked.1481
local.descriptor.checked.1481:
  %local.is.active.1501 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1501, label %local.descriptor.active.1502, label %local.descriptor.inactive.1503
local.descriptor.active.1502:
  %local.check.offset.1505 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1506 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1507 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1508 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1509 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1510 = load i32, ptr %context.field.1509, align 4
  %stack.sub.1513 = sub i32 %local.check.owner.end.1508, %local.check.offset.1505
  %descriptor.owner.inside.1511 = icmp ule i32 %local.check.owner.end.1508, %context.value.1510
  %descriptor.offset.inside.1512 = icmp ule i32 %local.check.offset.1505, %local.check.owner.end.1508
  %descriptor.extent.inside.1514 = icmp ule i32 %local.check.extent.1506, %stack.sub.1513
  %descriptor.payload.inside.1515 = icmp ule i32 %local.check.payload.1507, %local.check.extent.1506
  %descriptor.owner.offset.valid.1516 = and i1 %descriptor.owner.inside.1511, %descriptor.offset.inside.1512
  %descriptor.range.inside.1518 = and i1 %descriptor.owner.offset.valid.1516, %descriptor.extent.inside.1514
  %descriptor.range.valid.1517 = and i1 %descriptor.range.inside.1518, %descriptor.payload.inside.1515
  br i1 %descriptor.range.valid.1517, label %descriptor.valid.1519, label %descriptor.invalid.1520
descriptor.invalid.1520:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1519:
  %descriptor.initialized.status.1521 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1505, i32 %local.check.extent.1506)
  %helper.ok.1522 = icmp eq i32 %descriptor.initialized.status.1521, 0
  br i1 %helper.ok.1522, label %helper.continue.1523, label %frame.failure.0
helper.continue.1523:
  br label %local.descriptor.checked.1504
local.descriptor.inactive.1503:
  br label %local.descriptor.checked.1504
local.descriptor.checked.1504:
  %local.is.active.1524 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1524, label %local.descriptor.active.1525, label %local.descriptor.inactive.1526
local.descriptor.active.1525:
  %local.check.offset.1528 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1529 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1530 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1531 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1532 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1533 = load i32, ptr %context.field.1532, align 4
  %stack.sub.1536 = sub i32 %local.check.owner.end.1531, %local.check.offset.1528
  %descriptor.owner.inside.1534 = icmp ule i32 %local.check.owner.end.1531, %context.value.1533
  %descriptor.offset.inside.1535 = icmp ule i32 %local.check.offset.1528, %local.check.owner.end.1531
  %descriptor.extent.inside.1537 = icmp ule i32 %local.check.extent.1529, %stack.sub.1536
  %descriptor.payload.inside.1538 = icmp ule i32 %local.check.payload.1530, %local.check.extent.1529
  %descriptor.owner.offset.valid.1539 = and i1 %descriptor.owner.inside.1534, %descriptor.offset.inside.1535
  %descriptor.range.inside.1541 = and i1 %descriptor.owner.offset.valid.1539, %descriptor.extent.inside.1537
  %descriptor.range.valid.1540 = and i1 %descriptor.range.inside.1541, %descriptor.payload.inside.1538
  br i1 %descriptor.range.valid.1540, label %descriptor.valid.1542, label %descriptor.invalid.1543
descriptor.invalid.1543:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1542:
  %descriptor.initialized.status.1544 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1528, i32 %local.check.extent.1529)
  %helper.ok.1545 = icmp eq i32 %descriptor.initialized.status.1544, 0
  br i1 %helper.ok.1545, label %helper.continue.1546, label %frame.failure.0
helper.continue.1546:
  br label %local.descriptor.checked.1527
local.descriptor.inactive.1526:
  br label %local.descriptor.checked.1527
local.descriptor.checked.1527:
  %step.status.1547 = call i32 @al_owning_charge_step(ptr %ctx, i32 10)
  %helper.ok.1548 = icmp eq i32 %step.status.1547, 0
  br i1 %helper.ok.1548, label %helper.continue.1549, label %frame.failure.0
helper.continue.1549:
  %local.resolved.offset.1550 = load i32, ptr %local.offset.9, align 4
  %local.resolved.extent.1551 = load i32, ptr %local.extent.10, align 4
  %local.resolved.payload.1552 = load i32, ptr %local.payload.11, align 4
  %local.resolved.owner.end.1553 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1554 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1555 = load i32, ptr %context.field.1554, align 4
  %stack.sub.1558 = sub i32 %local.resolved.owner.end.1553, %local.resolved.offset.1550
  %descriptor.owner.inside.1556 = icmp ule i32 %local.resolved.owner.end.1553, %context.value.1555
  %descriptor.offset.inside.1557 = icmp ule i32 %local.resolved.offset.1550, %local.resolved.owner.end.1553
  %descriptor.extent.inside.1559 = icmp ule i32 %local.resolved.extent.1551, %stack.sub.1558
  %descriptor.payload.inside.1560 = icmp ule i32 %local.resolved.payload.1552, %local.resolved.extent.1551
  %descriptor.owner.offset.valid.1561 = and i1 %descriptor.owner.inside.1556, %descriptor.offset.inside.1557
  %descriptor.range.inside.1563 = and i1 %descriptor.owner.offset.valid.1561, %descriptor.extent.inside.1559
  %descriptor.range.valid.1562 = and i1 %descriptor.range.inside.1563, %descriptor.payload.inside.1560
  %descriptor.type.valid.1564 = icmp eq i32 12, 12
  %descriptor.valid.1565 = and i1 %descriptor.range.valid.1562, %descriptor.type.valid.1564
  br i1 %descriptor.valid.1565, label %descriptor.valid.1566, label %descriptor.invalid.1567
descriptor.invalid.1567:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1566:
  %descriptor.initialized.status.1568 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1550, i32 %local.resolved.extent.1551)
  %helper.ok.1569 = icmp eq i32 %descriptor.initialized.status.1568, 0
  br i1 %helper.ok.1569, label %helper.continue.1570, label %frame.failure.0
helper.continue.1570:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %local.resolved.offset.1550, i32 20, i32 %local.resolved.payload.1552, i32 %local.resolved.owner.end.1553, i32 %local.resolved.extent.1551)
  %context.field.1571 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1572 = load i32, ptr %context.field.1571, align 4
  %runtime.ok.1573 = icmp eq i32 %context.value.1572, 0
  br i1 %runtime.ok.1573, label %runtime.continue.1574, label %frame.failure.0
runtime.continue.1574:
  %context.field.1575 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1576 = load i32, ptr %context.field.1575, align 4
  %stack.sub.1579 = sub i32 %local.resolved.owner.end.1370, %local.resolved.offset.1367
  %descriptor.owner.inside.1577 = icmp ule i32 %local.resolved.owner.end.1370, %context.value.1576
  %descriptor.offset.inside.1578 = icmp ule i32 %local.resolved.offset.1367, %local.resolved.owner.end.1370
  %descriptor.extent.inside.1580 = icmp ule i32 %local.resolved.extent.1368, %stack.sub.1579
  %descriptor.payload.inside.1581 = icmp ule i32 %local.resolved.payload.1369, %local.resolved.extent.1368
  %descriptor.owner.offset.valid.1582 = and i1 %descriptor.owner.inside.1577, %descriptor.offset.inside.1578
  %descriptor.range.inside.1584 = and i1 %descriptor.owner.offset.valid.1582, %descriptor.extent.inside.1580
  %descriptor.range.valid.1583 = and i1 %descriptor.range.inside.1584, %descriptor.payload.inside.1581
  %descriptor.type.valid.1585 = icmp eq i32 12, 12
  %descriptor.valid.1586 = and i1 %descriptor.range.valid.1583, %descriptor.type.valid.1585
  br i1 %descriptor.valid.1586, label %descriptor.valid.1587, label %descriptor.invalid.1588
descriptor.invalid.1588:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1587:
  %descriptor.initialized.status.1589 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1367, i32 %local.resolved.extent.1368)
  %helper.ok.1590 = icmp eq i32 %descriptor.initialized.status.1589, 0
  br i1 %helper.ok.1590, label %helper.continue.1591, label %frame.failure.0
helper.continue.1591:
  %context.field.1592 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1593 = load i32, ptr %context.field.1592, align 4
  %stack.sub.1596 = sub i32 %local.resolved.owner.end.1553, %local.resolved.offset.1550
  %descriptor.owner.inside.1594 = icmp ule i32 %local.resolved.owner.end.1553, %context.value.1593
  %descriptor.offset.inside.1595 = icmp ule i32 %local.resolved.offset.1550, %local.resolved.owner.end.1553
  %descriptor.extent.inside.1597 = icmp ule i32 %local.resolved.extent.1551, %stack.sub.1596
  %descriptor.payload.inside.1598 = icmp ule i32 %local.resolved.payload.1552, %local.resolved.extent.1551
  %descriptor.owner.offset.valid.1599 = and i1 %descriptor.owner.inside.1594, %descriptor.offset.inside.1595
  %descriptor.range.inside.1601 = and i1 %descriptor.owner.offset.valid.1599, %descriptor.extent.inside.1597
  %descriptor.range.valid.1600 = and i1 %descriptor.range.inside.1601, %descriptor.payload.inside.1598
  %descriptor.type.valid.1602 = icmp eq i32 12, 12
  %descriptor.valid.1603 = and i1 %descriptor.range.valid.1600, %descriptor.type.valid.1602
  br i1 %descriptor.valid.1603, label %descriptor.valid.1604, label %descriptor.invalid.1605
descriptor.invalid.1605:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1604:
  %descriptor.initialized.status.1606 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.1550, i32 %local.resolved.extent.1551)
  %helper.ok.1607 = icmp eq i32 %descriptor.initialized.status.1606, 0
  br i1 %helper.ok.1607, label %helper.continue.1608, label %frame.failure.0
helper.continue.1608:
  %local.is.active.1609 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1609, label %local.descriptor.active.1610, label %local.descriptor.inactive.1611
local.descriptor.active.1610:
  %local.check.offset.1613 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1614 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1615 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1616 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1617 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1618 = load i32, ptr %context.field.1617, align 4
  %stack.sub.1621 = sub i32 %local.check.owner.end.1616, %local.check.offset.1613
  %descriptor.owner.inside.1619 = icmp ule i32 %local.check.owner.end.1616, %context.value.1618
  %descriptor.offset.inside.1620 = icmp ule i32 %local.check.offset.1613, %local.check.owner.end.1616
  %descriptor.extent.inside.1622 = icmp ule i32 %local.check.extent.1614, %stack.sub.1621
  %descriptor.payload.inside.1623 = icmp ule i32 %local.check.payload.1615, %local.check.extent.1614
  %descriptor.owner.offset.valid.1624 = and i1 %descriptor.owner.inside.1619, %descriptor.offset.inside.1620
  %descriptor.range.inside.1626 = and i1 %descriptor.owner.offset.valid.1624, %descriptor.extent.inside.1622
  %descriptor.range.valid.1625 = and i1 %descriptor.range.inside.1626, %descriptor.payload.inside.1623
  br i1 %descriptor.range.valid.1625, label %descriptor.valid.1627, label %descriptor.invalid.1628
descriptor.invalid.1628:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1627:
  %descriptor.initialized.status.1629 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1613, i32 %local.check.extent.1614)
  %helper.ok.1630 = icmp eq i32 %descriptor.initialized.status.1629, 0
  br i1 %helper.ok.1630, label %helper.continue.1631, label %frame.failure.0
helper.continue.1631:
  br label %local.descriptor.checked.1612
local.descriptor.inactive.1611:
  br label %local.descriptor.checked.1612
local.descriptor.checked.1612:
  %local.is.active.1632 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1632, label %local.descriptor.active.1633, label %local.descriptor.inactive.1634
local.descriptor.active.1633:
  %local.check.offset.1636 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1637 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1638 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1639 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1640 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1641 = load i32, ptr %context.field.1640, align 4
  %stack.sub.1644 = sub i32 %local.check.owner.end.1639, %local.check.offset.1636
  %descriptor.owner.inside.1642 = icmp ule i32 %local.check.owner.end.1639, %context.value.1641
  %descriptor.offset.inside.1643 = icmp ule i32 %local.check.offset.1636, %local.check.owner.end.1639
  %descriptor.extent.inside.1645 = icmp ule i32 %local.check.extent.1637, %stack.sub.1644
  %descriptor.payload.inside.1646 = icmp ule i32 %local.check.payload.1638, %local.check.extent.1637
  %descriptor.owner.offset.valid.1647 = and i1 %descriptor.owner.inside.1642, %descriptor.offset.inside.1643
  %descriptor.range.inside.1649 = and i1 %descriptor.owner.offset.valid.1647, %descriptor.extent.inside.1645
  %descriptor.range.valid.1648 = and i1 %descriptor.range.inside.1649, %descriptor.payload.inside.1646
  br i1 %descriptor.range.valid.1648, label %descriptor.valid.1650, label %descriptor.invalid.1651
descriptor.invalid.1651:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1650:
  %descriptor.initialized.status.1652 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1636, i32 %local.check.extent.1637)
  %helper.ok.1653 = icmp eq i32 %descriptor.initialized.status.1652, 0
  br i1 %helper.ok.1653, label %helper.continue.1654, label %frame.failure.0
helper.continue.1654:
  br label %local.descriptor.checked.1635
local.descriptor.inactive.1634:
  br label %local.descriptor.checked.1635
local.descriptor.checked.1635:
  %local.is.active.1655 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1655, label %local.descriptor.active.1656, label %local.descriptor.inactive.1657
local.descriptor.active.1656:
  %local.check.offset.1659 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1660 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1661 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1662 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1663 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1664 = load i32, ptr %context.field.1663, align 4
  %stack.sub.1667 = sub i32 %local.check.owner.end.1662, %local.check.offset.1659
  %descriptor.owner.inside.1665 = icmp ule i32 %local.check.owner.end.1662, %context.value.1664
  %descriptor.offset.inside.1666 = icmp ule i32 %local.check.offset.1659, %local.check.owner.end.1662
  %descriptor.extent.inside.1668 = icmp ule i32 %local.check.extent.1660, %stack.sub.1667
  %descriptor.payload.inside.1669 = icmp ule i32 %local.check.payload.1661, %local.check.extent.1660
  %descriptor.owner.offset.valid.1670 = and i1 %descriptor.owner.inside.1665, %descriptor.offset.inside.1666
  %descriptor.range.inside.1672 = and i1 %descriptor.owner.offset.valid.1670, %descriptor.extent.inside.1668
  %descriptor.range.valid.1671 = and i1 %descriptor.range.inside.1672, %descriptor.payload.inside.1669
  br i1 %descriptor.range.valid.1671, label %descriptor.valid.1673, label %descriptor.invalid.1674
descriptor.invalid.1674:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1673:
  %descriptor.initialized.status.1675 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1659, i32 %local.check.extent.1660)
  %helper.ok.1676 = icmp eq i32 %descriptor.initialized.status.1675, 0
  br i1 %helper.ok.1676, label %helper.continue.1677, label %frame.failure.0
helper.continue.1677:
  br label %local.descriptor.checked.1658
local.descriptor.inactive.1657:
  br label %local.descriptor.checked.1658
local.descriptor.checked.1658:
  %local.is.active.1678 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1678, label %local.descriptor.active.1679, label %local.descriptor.inactive.1680
local.descriptor.active.1679:
  %local.check.offset.1682 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1683 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1684 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1685 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1686 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1687 = load i32, ptr %context.field.1686, align 4
  %stack.sub.1690 = sub i32 %local.check.owner.end.1685, %local.check.offset.1682
  %descriptor.owner.inside.1688 = icmp ule i32 %local.check.owner.end.1685, %context.value.1687
  %descriptor.offset.inside.1689 = icmp ule i32 %local.check.offset.1682, %local.check.owner.end.1685
  %descriptor.extent.inside.1691 = icmp ule i32 %local.check.extent.1683, %stack.sub.1690
  %descriptor.payload.inside.1692 = icmp ule i32 %local.check.payload.1684, %local.check.extent.1683
  %descriptor.owner.offset.valid.1693 = and i1 %descriptor.owner.inside.1688, %descriptor.offset.inside.1689
  %descriptor.range.inside.1695 = and i1 %descriptor.owner.offset.valid.1693, %descriptor.extent.inside.1691
  %descriptor.range.valid.1694 = and i1 %descriptor.range.inside.1695, %descriptor.payload.inside.1692
  br i1 %descriptor.range.valid.1694, label %descriptor.valid.1696, label %descriptor.invalid.1697
descriptor.invalid.1697:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1696:
  %descriptor.initialized.status.1698 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1682, i32 %local.check.extent.1683)
  %helper.ok.1699 = icmp eq i32 %descriptor.initialized.status.1698, 0
  br i1 %helper.ok.1699, label %helper.continue.1700, label %frame.failure.0
helper.continue.1700:
  br label %local.descriptor.checked.1681
local.descriptor.inactive.1680:
  br label %local.descriptor.checked.1681
local.descriptor.checked.1681:
  %local.is.active.1701 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1701, label %local.descriptor.active.1702, label %local.descriptor.inactive.1703
local.descriptor.active.1702:
  %local.check.offset.1705 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1706 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1707 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1708 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1709 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1710 = load i32, ptr %context.field.1709, align 4
  %stack.sub.1713 = sub i32 %local.check.owner.end.1708, %local.check.offset.1705
  %descriptor.owner.inside.1711 = icmp ule i32 %local.check.owner.end.1708, %context.value.1710
  %descriptor.offset.inside.1712 = icmp ule i32 %local.check.offset.1705, %local.check.owner.end.1708
  %descriptor.extent.inside.1714 = icmp ule i32 %local.check.extent.1706, %stack.sub.1713
  %descriptor.payload.inside.1715 = icmp ule i32 %local.check.payload.1707, %local.check.extent.1706
  %descriptor.owner.offset.valid.1716 = and i1 %descriptor.owner.inside.1711, %descriptor.offset.inside.1712
  %descriptor.range.inside.1718 = and i1 %descriptor.owner.offset.valid.1716, %descriptor.extent.inside.1714
  %descriptor.range.valid.1717 = and i1 %descriptor.range.inside.1718, %descriptor.payload.inside.1715
  br i1 %descriptor.range.valid.1717, label %descriptor.valid.1719, label %descriptor.invalid.1720
descriptor.invalid.1720:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1719:
  %descriptor.initialized.status.1721 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1705, i32 %local.check.extent.1706)
  %helper.ok.1722 = icmp eq i32 %descriptor.initialized.status.1721, 0
  br i1 %helper.ok.1722, label %helper.continue.1723, label %frame.failure.0
helper.continue.1723:
  br label %local.descriptor.checked.1704
local.descriptor.inactive.1703:
  br label %local.descriptor.checked.1704
local.descriptor.checked.1704:
  %local.is.active.1724 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1724, label %local.descriptor.active.1725, label %local.descriptor.inactive.1726
local.descriptor.active.1725:
  %local.check.offset.1728 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1729 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1730 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1731 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1732 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1733 = load i32, ptr %context.field.1732, align 4
  %stack.sub.1736 = sub i32 %local.check.owner.end.1731, %local.check.offset.1728
  %descriptor.owner.inside.1734 = icmp ule i32 %local.check.owner.end.1731, %context.value.1733
  %descriptor.offset.inside.1735 = icmp ule i32 %local.check.offset.1728, %local.check.owner.end.1731
  %descriptor.extent.inside.1737 = icmp ule i32 %local.check.extent.1729, %stack.sub.1736
  %descriptor.payload.inside.1738 = icmp ule i32 %local.check.payload.1730, %local.check.extent.1729
  %descriptor.owner.offset.valid.1739 = and i1 %descriptor.owner.inside.1734, %descriptor.offset.inside.1735
  %descriptor.range.inside.1741 = and i1 %descriptor.owner.offset.valid.1739, %descriptor.extent.inside.1737
  %descriptor.range.valid.1740 = and i1 %descriptor.range.inside.1741, %descriptor.payload.inside.1738
  br i1 %descriptor.range.valid.1740, label %descriptor.valid.1742, label %descriptor.invalid.1743
descriptor.invalid.1743:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1742:
  %descriptor.initialized.status.1744 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1728, i32 %local.check.extent.1729)
  %helper.ok.1745 = icmp eq i32 %descriptor.initialized.status.1744, 0
  br i1 %helper.ok.1745, label %helper.continue.1746, label %frame.failure.0
helper.continue.1746:
  br label %local.descriptor.checked.1727
local.descriptor.inactive.1726:
  br label %local.descriptor.checked.1727
local.descriptor.checked.1727:
  %step.status.1747 = call i32 @al_owning_charge_step(ptr %ctx, i32 11)
  %helper.ok.1748 = icmp eq i32 %step.status.1747, 0
  br i1 %helper.ok.1748, label %helper.continue.1749, label %frame.failure.0
helper.continue.1749:
  %context.field.1750 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1751 = load i32, ptr %context.field.1750, align 4
  %string.concat.units.1752 = alloca i32, align 4
  %string.concat.payload.pointer.1753 = alloca i32, align 4
  %string.concat.extent.pointer.1754 = alloca i32, align 4
  %string.concat.plan.status.1755 = call i32 @al_owning_string_concat_plan(ptr %ctx, i32 %local.resolved.offset.1367, i32 %local.resolved.extent.1368, i32 %local.resolved.offset.1550, i32 %local.resolved.extent.1551, i32 12, ptr %string.concat.units.1752, ptr %string.concat.payload.pointer.1753, ptr %string.concat.extent.pointer.1754)
  %helper.ok.1756 = icmp eq i32 %string.concat.plan.status.1755, 0
  br i1 %helper.ok.1756, label %helper.continue.1757, label %frame.failure.0
helper.continue.1757:
  %string.concat.payload.1758 = load i32, ptr %string.concat.payload.pointer.1753, align 4
  %string.concat.extent.1759 = load i32, ptr %string.concat.extent.pointer.1754, align 4
  %stack.offset.1760 = add i32 %context.value.1751, %string.concat.extent.1759
  %reserve.status.1761 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1760, i32 13)
  %reserve.ok.1762 = icmp eq i32 %reserve.status.1761, 0
  br i1 %reserve.ok.1762, label %reserve.continue.1763, label %frame.failure.0
reserve.continue.1763:
  %string.concat.write.status.1764 = call i32 @al_owning_string_concat_write(ptr %ctx, i32 %context.value.1751, i32 %string.concat.extent.1759, i32 %local.resolved.offset.1367, i32 %local.resolved.extent.1368, i32 %local.resolved.offset.1550, i32 %local.resolved.extent.1551, i32 12, i32 12)
  %helper.ok.1765 = icmp eq i32 %string.concat.write.status.1764, 0
  br i1 %helper.ok.1765, label %helper.continue.1766, label %frame.failure.0
helper.continue.1766:
  call void @al_owning_update_live(ptr %ctx, i32 %string.concat.payload.1758, i32 0)
  %context.field.1767 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1768 = load i32, ptr %context.field.1767, align 4
  %runtime.ok.1769 = icmp eq i32 %context.value.1768, 0
  br i1 %runtime.ok.1769, label %runtime.continue.1770, label %frame.failure.0
runtime.continue.1770:
  %context.field.1771 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1772 = load i32, ptr %context.field.1771, align 4
  %stack.sub.1775 = sub i32 %stack.offset.1760, %context.value.1751
  %descriptor.owner.inside.1773 = icmp ule i32 %stack.offset.1760, %context.value.1772
  %descriptor.offset.inside.1774 = icmp ule i32 %context.value.1751, %stack.offset.1760
  %descriptor.extent.inside.1776 = icmp ule i32 %string.concat.extent.1759, %stack.sub.1775
  %descriptor.payload.inside.1777 = icmp ule i32 %string.concat.payload.1758, %string.concat.extent.1759
  %descriptor.owner.offset.valid.1778 = and i1 %descriptor.owner.inside.1773, %descriptor.offset.inside.1774
  %descriptor.range.inside.1780 = and i1 %descriptor.owner.offset.valid.1778, %descriptor.extent.inside.1776
  %descriptor.range.valid.1779 = and i1 %descriptor.range.inside.1780, %descriptor.payload.inside.1777
  %descriptor.type.valid.1781 = icmp eq i32 12, 12
  %descriptor.valid.1782 = and i1 %descriptor.range.valid.1779, %descriptor.type.valid.1781
  br i1 %descriptor.valid.1782, label %descriptor.valid.1783, label %descriptor.invalid.1784
descriptor.invalid.1784:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1783:
  %descriptor.initialized.status.1785 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.1751, i32 %string.concat.extent.1759)
  %helper.ok.1786 = icmp eq i32 %descriptor.initialized.status.1785, 0
  br i1 %helper.ok.1786, label %helper.continue.1787, label %frame.failure.0
helper.continue.1787:
  %local.is.active.1788 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1788, label %local.descriptor.active.1789, label %local.descriptor.inactive.1790
local.descriptor.active.1789:
  %local.check.offset.1792 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1793 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1794 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1795 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1796 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1797 = load i32, ptr %context.field.1796, align 4
  %stack.sub.1800 = sub i32 %local.check.owner.end.1795, %local.check.offset.1792
  %descriptor.owner.inside.1798 = icmp ule i32 %local.check.owner.end.1795, %context.value.1797
  %descriptor.offset.inside.1799 = icmp ule i32 %local.check.offset.1792, %local.check.owner.end.1795
  %descriptor.extent.inside.1801 = icmp ule i32 %local.check.extent.1793, %stack.sub.1800
  %descriptor.payload.inside.1802 = icmp ule i32 %local.check.payload.1794, %local.check.extent.1793
  %descriptor.owner.offset.valid.1803 = and i1 %descriptor.owner.inside.1798, %descriptor.offset.inside.1799
  %descriptor.range.inside.1805 = and i1 %descriptor.owner.offset.valid.1803, %descriptor.extent.inside.1801
  %descriptor.range.valid.1804 = and i1 %descriptor.range.inside.1805, %descriptor.payload.inside.1802
  br i1 %descriptor.range.valid.1804, label %descriptor.valid.1806, label %descriptor.invalid.1807
descriptor.invalid.1807:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1806:
  %descriptor.initialized.status.1808 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1792, i32 %local.check.extent.1793)
  %helper.ok.1809 = icmp eq i32 %descriptor.initialized.status.1808, 0
  br i1 %helper.ok.1809, label %helper.continue.1810, label %frame.failure.0
helper.continue.1810:
  br label %local.descriptor.checked.1791
local.descriptor.inactive.1790:
  br label %local.descriptor.checked.1791
local.descriptor.checked.1791:
  %local.is.active.1811 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1811, label %local.descriptor.active.1812, label %local.descriptor.inactive.1813
local.descriptor.active.1812:
  %local.check.offset.1815 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1816 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1817 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1818 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1819 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1820 = load i32, ptr %context.field.1819, align 4
  %stack.sub.1823 = sub i32 %local.check.owner.end.1818, %local.check.offset.1815
  %descriptor.owner.inside.1821 = icmp ule i32 %local.check.owner.end.1818, %context.value.1820
  %descriptor.offset.inside.1822 = icmp ule i32 %local.check.offset.1815, %local.check.owner.end.1818
  %descriptor.extent.inside.1824 = icmp ule i32 %local.check.extent.1816, %stack.sub.1823
  %descriptor.payload.inside.1825 = icmp ule i32 %local.check.payload.1817, %local.check.extent.1816
  %descriptor.owner.offset.valid.1826 = and i1 %descriptor.owner.inside.1821, %descriptor.offset.inside.1822
  %descriptor.range.inside.1828 = and i1 %descriptor.owner.offset.valid.1826, %descriptor.extent.inside.1824
  %descriptor.range.valid.1827 = and i1 %descriptor.range.inside.1828, %descriptor.payload.inside.1825
  br i1 %descriptor.range.valid.1827, label %descriptor.valid.1829, label %descriptor.invalid.1830
descriptor.invalid.1830:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1829:
  %descriptor.initialized.status.1831 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1815, i32 %local.check.extent.1816)
  %helper.ok.1832 = icmp eq i32 %descriptor.initialized.status.1831, 0
  br i1 %helper.ok.1832, label %helper.continue.1833, label %frame.failure.0
helper.continue.1833:
  br label %local.descriptor.checked.1814
local.descriptor.inactive.1813:
  br label %local.descriptor.checked.1814
local.descriptor.checked.1814:
  %local.is.active.1834 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1834, label %local.descriptor.active.1835, label %local.descriptor.inactive.1836
local.descriptor.active.1835:
  %local.check.offset.1838 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1839 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1840 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1841 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1842 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1843 = load i32, ptr %context.field.1842, align 4
  %stack.sub.1846 = sub i32 %local.check.owner.end.1841, %local.check.offset.1838
  %descriptor.owner.inside.1844 = icmp ule i32 %local.check.owner.end.1841, %context.value.1843
  %descriptor.offset.inside.1845 = icmp ule i32 %local.check.offset.1838, %local.check.owner.end.1841
  %descriptor.extent.inside.1847 = icmp ule i32 %local.check.extent.1839, %stack.sub.1846
  %descriptor.payload.inside.1848 = icmp ule i32 %local.check.payload.1840, %local.check.extent.1839
  %descriptor.owner.offset.valid.1849 = and i1 %descriptor.owner.inside.1844, %descriptor.offset.inside.1845
  %descriptor.range.inside.1851 = and i1 %descriptor.owner.offset.valid.1849, %descriptor.extent.inside.1847
  %descriptor.range.valid.1850 = and i1 %descriptor.range.inside.1851, %descriptor.payload.inside.1848
  br i1 %descriptor.range.valid.1850, label %descriptor.valid.1852, label %descriptor.invalid.1853
descriptor.invalid.1853:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1852:
  %descriptor.initialized.status.1854 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1838, i32 %local.check.extent.1839)
  %helper.ok.1855 = icmp eq i32 %descriptor.initialized.status.1854, 0
  br i1 %helper.ok.1855, label %helper.continue.1856, label %frame.failure.0
helper.continue.1856:
  br label %local.descriptor.checked.1837
local.descriptor.inactive.1836:
  br label %local.descriptor.checked.1837
local.descriptor.checked.1837:
  %local.is.active.1857 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.1857, label %local.descriptor.active.1858, label %local.descriptor.inactive.1859
local.descriptor.active.1858:
  %local.check.offset.1861 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.1862 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.1863 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.1864 = load i32, ptr %local.owner.end.24, align 4
  %context.field.1865 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1866 = load i32, ptr %context.field.1865, align 4
  %stack.sub.1869 = sub i32 %local.check.owner.end.1864, %local.check.offset.1861
  %descriptor.owner.inside.1867 = icmp ule i32 %local.check.owner.end.1864, %context.value.1866
  %descriptor.offset.inside.1868 = icmp ule i32 %local.check.offset.1861, %local.check.owner.end.1864
  %descriptor.extent.inside.1870 = icmp ule i32 %local.check.extent.1862, %stack.sub.1869
  %descriptor.payload.inside.1871 = icmp ule i32 %local.check.payload.1863, %local.check.extent.1862
  %descriptor.owner.offset.valid.1872 = and i1 %descriptor.owner.inside.1867, %descriptor.offset.inside.1868
  %descriptor.range.inside.1874 = and i1 %descriptor.owner.offset.valid.1872, %descriptor.extent.inside.1870
  %descriptor.range.valid.1873 = and i1 %descriptor.range.inside.1874, %descriptor.payload.inside.1871
  br i1 %descriptor.range.valid.1873, label %descriptor.valid.1875, label %descriptor.invalid.1876
descriptor.invalid.1876:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1875:
  %descriptor.initialized.status.1877 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1861, i32 %local.check.extent.1862)
  %helper.ok.1878 = icmp eq i32 %descriptor.initialized.status.1877, 0
  br i1 %helper.ok.1878, label %helper.continue.1879, label %frame.failure.0
helper.continue.1879:
  br label %local.descriptor.checked.1860
local.descriptor.inactive.1859:
  br label %local.descriptor.checked.1860
local.descriptor.checked.1860:
  %local.is.active.1880 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.1880, label %local.descriptor.active.1881, label %local.descriptor.inactive.1882
local.descriptor.active.1881:
  %local.check.offset.1884 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.1885 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.1886 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.1887 = load i32, ptr %local.owner.end.30, align 4
  %context.field.1888 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1889 = load i32, ptr %context.field.1888, align 4
  %stack.sub.1892 = sub i32 %local.check.owner.end.1887, %local.check.offset.1884
  %descriptor.owner.inside.1890 = icmp ule i32 %local.check.owner.end.1887, %context.value.1889
  %descriptor.offset.inside.1891 = icmp ule i32 %local.check.offset.1884, %local.check.owner.end.1887
  %descriptor.extent.inside.1893 = icmp ule i32 %local.check.extent.1885, %stack.sub.1892
  %descriptor.payload.inside.1894 = icmp ule i32 %local.check.payload.1886, %local.check.extent.1885
  %descriptor.owner.offset.valid.1895 = and i1 %descriptor.owner.inside.1890, %descriptor.offset.inside.1891
  %descriptor.range.inside.1897 = and i1 %descriptor.owner.offset.valid.1895, %descriptor.extent.inside.1893
  %descriptor.range.valid.1896 = and i1 %descriptor.range.inside.1897, %descriptor.payload.inside.1894
  br i1 %descriptor.range.valid.1896, label %descriptor.valid.1898, label %descriptor.invalid.1899
descriptor.invalid.1899:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1898:
  %descriptor.initialized.status.1900 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1884, i32 %local.check.extent.1885)
  %helper.ok.1901 = icmp eq i32 %descriptor.initialized.status.1900, 0
  br i1 %helper.ok.1901, label %helper.continue.1902, label %frame.failure.0
helper.continue.1902:
  br label %local.descriptor.checked.1883
local.descriptor.inactive.1882:
  br label %local.descriptor.checked.1883
local.descriptor.checked.1883:
  %local.is.active.1903 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.1903, label %local.descriptor.active.1904, label %local.descriptor.inactive.1905
local.descriptor.active.1904:
  %local.check.offset.1907 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.1908 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.1909 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.1910 = load i32, ptr %local.owner.end.36, align 4
  %context.field.1911 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1912 = load i32, ptr %context.field.1911, align 4
  %stack.sub.1915 = sub i32 %local.check.owner.end.1910, %local.check.offset.1907
  %descriptor.owner.inside.1913 = icmp ule i32 %local.check.owner.end.1910, %context.value.1912
  %descriptor.offset.inside.1914 = icmp ule i32 %local.check.offset.1907, %local.check.owner.end.1910
  %descriptor.extent.inside.1916 = icmp ule i32 %local.check.extent.1908, %stack.sub.1915
  %descriptor.payload.inside.1917 = icmp ule i32 %local.check.payload.1909, %local.check.extent.1908
  %descriptor.owner.offset.valid.1918 = and i1 %descriptor.owner.inside.1913, %descriptor.offset.inside.1914
  %descriptor.range.inside.1920 = and i1 %descriptor.owner.offset.valid.1918, %descriptor.extent.inside.1916
  %descriptor.range.valid.1919 = and i1 %descriptor.range.inside.1920, %descriptor.payload.inside.1917
  br i1 %descriptor.range.valid.1919, label %descriptor.valid.1921, label %descriptor.invalid.1922
descriptor.invalid.1922:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1921:
  %descriptor.initialized.status.1923 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1907, i32 %local.check.extent.1908)
  %helper.ok.1924 = icmp eq i32 %descriptor.initialized.status.1923, 0
  br i1 %helper.ok.1924, label %helper.continue.1925, label %frame.failure.0
helper.continue.1925:
  br label %local.descriptor.checked.1906
local.descriptor.inactive.1905:
  br label %local.descriptor.checked.1906
local.descriptor.checked.1906:
  %step.status.1926 = call i32 @al_owning_charge_step(ptr %ctx, i32 14)
  %helper.ok.1927 = icmp eq i32 %step.status.1926, 0
  br i1 %helper.ok.1927, label %helper.continue.1928, label %frame.failure.0
helper.continue.1928:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 12, i32 %context.value.1751, i32 %string.concat.extent.1759, i32 %string.concat.payload.1758, i32 0, i32 0)
  %context.field.1929 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1930 = load i32, ptr %context.field.1929, align 4
  %runtime.ok.1931 = icmp eq i32 %context.value.1930, 0
  br i1 %runtime.ok.1931, label %runtime.continue.1932, label %frame.failure.0
runtime.continue.1932:
  %local.is.active.1933 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1933, label %local.descriptor.active.1934, label %local.descriptor.inactive.1935
local.descriptor.active.1934:
  %local.check.offset.1937 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1938 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1939 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1940 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1941 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1942 = load i32, ptr %context.field.1941, align 4
  %stack.sub.1945 = sub i32 %local.check.owner.end.1940, %local.check.offset.1937
  %descriptor.owner.inside.1943 = icmp ule i32 %local.check.owner.end.1940, %context.value.1942
  %descriptor.offset.inside.1944 = icmp ule i32 %local.check.offset.1937, %local.check.owner.end.1940
  %descriptor.extent.inside.1946 = icmp ule i32 %local.check.extent.1938, %stack.sub.1945
  %descriptor.payload.inside.1947 = icmp ule i32 %local.check.payload.1939, %local.check.extent.1938
  %descriptor.owner.offset.valid.1948 = and i1 %descriptor.owner.inside.1943, %descriptor.offset.inside.1944
  %descriptor.range.inside.1950 = and i1 %descriptor.owner.offset.valid.1948, %descriptor.extent.inside.1946
  %descriptor.range.valid.1949 = and i1 %descriptor.range.inside.1950, %descriptor.payload.inside.1947
  br i1 %descriptor.range.valid.1949, label %descriptor.valid.1951, label %descriptor.invalid.1952
descriptor.invalid.1952:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1951:
  %descriptor.initialized.status.1953 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1937, i32 %local.check.extent.1938)
  %helper.ok.1954 = icmp eq i32 %descriptor.initialized.status.1953, 0
  br i1 %helper.ok.1954, label %helper.continue.1955, label %frame.failure.0
helper.continue.1955:
  br label %local.descriptor.checked.1936
local.descriptor.inactive.1935:
  br label %local.descriptor.checked.1936
local.descriptor.checked.1936:
  %local.is.active.1956 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.1956, label %local.descriptor.active.1957, label %local.descriptor.inactive.1958
local.descriptor.active.1957:
  %local.check.offset.1960 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.1961 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.1962 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.1963 = load i32, ptr %local.owner.end.12, align 4
  %context.field.1964 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1965 = load i32, ptr %context.field.1964, align 4
  %stack.sub.1968 = sub i32 %local.check.owner.end.1963, %local.check.offset.1960
  %descriptor.owner.inside.1966 = icmp ule i32 %local.check.owner.end.1963, %context.value.1965
  %descriptor.offset.inside.1967 = icmp ule i32 %local.check.offset.1960, %local.check.owner.end.1963
  %descriptor.extent.inside.1969 = icmp ule i32 %local.check.extent.1961, %stack.sub.1968
  %descriptor.payload.inside.1970 = icmp ule i32 %local.check.payload.1962, %local.check.extent.1961
  %descriptor.owner.offset.valid.1971 = and i1 %descriptor.owner.inside.1966, %descriptor.offset.inside.1967
  %descriptor.range.inside.1973 = and i1 %descriptor.owner.offset.valid.1971, %descriptor.extent.inside.1969
  %descriptor.range.valid.1972 = and i1 %descriptor.range.inside.1973, %descriptor.payload.inside.1970
  br i1 %descriptor.range.valid.1972, label %descriptor.valid.1974, label %descriptor.invalid.1975
descriptor.invalid.1975:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1974:
  %descriptor.initialized.status.1976 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1960, i32 %local.check.extent.1961)
  %helper.ok.1977 = icmp eq i32 %descriptor.initialized.status.1976, 0
  br i1 %helper.ok.1977, label %helper.continue.1978, label %frame.failure.0
helper.continue.1978:
  br label %local.descriptor.checked.1959
local.descriptor.inactive.1958:
  br label %local.descriptor.checked.1959
local.descriptor.checked.1959:
  %local.is.active.1979 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.1979, label %local.descriptor.active.1980, label %local.descriptor.inactive.1981
local.descriptor.active.1980:
  %local.check.offset.1983 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.1984 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.1985 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.1986 = load i32, ptr %local.owner.end.18, align 4
  %context.field.1987 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1988 = load i32, ptr %context.field.1987, align 4
  %stack.sub.1991 = sub i32 %local.check.owner.end.1986, %local.check.offset.1983
  %descriptor.owner.inside.1989 = icmp ule i32 %local.check.owner.end.1986, %context.value.1988
  %descriptor.offset.inside.1990 = icmp ule i32 %local.check.offset.1983, %local.check.owner.end.1986
  %descriptor.extent.inside.1992 = icmp ule i32 %local.check.extent.1984, %stack.sub.1991
  %descriptor.payload.inside.1993 = icmp ule i32 %local.check.payload.1985, %local.check.extent.1984
  %descriptor.owner.offset.valid.1994 = and i1 %descriptor.owner.inside.1989, %descriptor.offset.inside.1990
  %descriptor.range.inside.1996 = and i1 %descriptor.owner.offset.valid.1994, %descriptor.extent.inside.1992
  %descriptor.range.valid.1995 = and i1 %descriptor.range.inside.1996, %descriptor.payload.inside.1993
  br i1 %descriptor.range.valid.1995, label %descriptor.valid.1997, label %descriptor.invalid.1998
descriptor.invalid.1998:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1997:
  %descriptor.initialized.status.1999 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1983, i32 %local.check.extent.1984)
  %helper.ok.2000 = icmp eq i32 %descriptor.initialized.status.1999, 0
  br i1 %helper.ok.2000, label %helper.continue.2001, label %frame.failure.0
helper.continue.2001:
  br label %local.descriptor.checked.1982
local.descriptor.inactive.1981:
  br label %local.descriptor.checked.1982
local.descriptor.checked.1982:
  %local.is.active.2002 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2002, label %local.descriptor.active.2003, label %local.descriptor.inactive.2004
local.descriptor.active.2003:
  %local.check.offset.2006 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2007 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2008 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2009 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2010 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2011 = load i32, ptr %context.field.2010, align 4
  %stack.sub.2014 = sub i32 %local.check.owner.end.2009, %local.check.offset.2006
  %descriptor.owner.inside.2012 = icmp ule i32 %local.check.owner.end.2009, %context.value.2011
  %descriptor.offset.inside.2013 = icmp ule i32 %local.check.offset.2006, %local.check.owner.end.2009
  %descriptor.extent.inside.2015 = icmp ule i32 %local.check.extent.2007, %stack.sub.2014
  %descriptor.payload.inside.2016 = icmp ule i32 %local.check.payload.2008, %local.check.extent.2007
  %descriptor.owner.offset.valid.2017 = and i1 %descriptor.owner.inside.2012, %descriptor.offset.inside.2013
  %descriptor.range.inside.2019 = and i1 %descriptor.owner.offset.valid.2017, %descriptor.extent.inside.2015
  %descriptor.range.valid.2018 = and i1 %descriptor.range.inside.2019, %descriptor.payload.inside.2016
  br i1 %descriptor.range.valid.2018, label %descriptor.valid.2020, label %descriptor.invalid.2021
descriptor.invalid.2021:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2020:
  %descriptor.initialized.status.2022 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2006, i32 %local.check.extent.2007)
  %helper.ok.2023 = icmp eq i32 %descriptor.initialized.status.2022, 0
  br i1 %helper.ok.2023, label %helper.continue.2024, label %frame.failure.0
helper.continue.2024:
  br label %local.descriptor.checked.2005
local.descriptor.inactive.2004:
  br label %local.descriptor.checked.2005
local.descriptor.checked.2005:
  %local.is.active.2025 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2025, label %local.descriptor.active.2026, label %local.descriptor.inactive.2027
local.descriptor.active.2026:
  %local.check.offset.2029 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2030 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2031 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2032 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2033 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2034 = load i32, ptr %context.field.2033, align 4
  %stack.sub.2037 = sub i32 %local.check.owner.end.2032, %local.check.offset.2029
  %descriptor.owner.inside.2035 = icmp ule i32 %local.check.owner.end.2032, %context.value.2034
  %descriptor.offset.inside.2036 = icmp ule i32 %local.check.offset.2029, %local.check.owner.end.2032
  %descriptor.extent.inside.2038 = icmp ule i32 %local.check.extent.2030, %stack.sub.2037
  %descriptor.payload.inside.2039 = icmp ule i32 %local.check.payload.2031, %local.check.extent.2030
  %descriptor.owner.offset.valid.2040 = and i1 %descriptor.owner.inside.2035, %descriptor.offset.inside.2036
  %descriptor.range.inside.2042 = and i1 %descriptor.owner.offset.valid.2040, %descriptor.extent.inside.2038
  %descriptor.range.valid.2041 = and i1 %descriptor.range.inside.2042, %descriptor.payload.inside.2039
  br i1 %descriptor.range.valid.2041, label %descriptor.valid.2043, label %descriptor.invalid.2044
descriptor.invalid.2044:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2043:
  %descriptor.initialized.status.2045 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2029, i32 %local.check.extent.2030)
  %helper.ok.2046 = icmp eq i32 %descriptor.initialized.status.2045, 0
  br i1 %helper.ok.2046, label %helper.continue.2047, label %frame.failure.0
helper.continue.2047:
  br label %local.descriptor.checked.2028
local.descriptor.inactive.2027:
  br label %local.descriptor.checked.2028
local.descriptor.checked.2028:
  %local.is.active.2048 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2048, label %local.descriptor.active.2049, label %local.descriptor.inactive.2050
local.descriptor.active.2049:
  %local.check.offset.2052 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2053 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2054 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2055 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2056 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2057 = load i32, ptr %context.field.2056, align 4
  %stack.sub.2060 = sub i32 %local.check.owner.end.2055, %local.check.offset.2052
  %descriptor.owner.inside.2058 = icmp ule i32 %local.check.owner.end.2055, %context.value.2057
  %descriptor.offset.inside.2059 = icmp ule i32 %local.check.offset.2052, %local.check.owner.end.2055
  %descriptor.extent.inside.2061 = icmp ule i32 %local.check.extent.2053, %stack.sub.2060
  %descriptor.payload.inside.2062 = icmp ule i32 %local.check.payload.2054, %local.check.extent.2053
  %descriptor.owner.offset.valid.2063 = and i1 %descriptor.owner.inside.2058, %descriptor.offset.inside.2059
  %descriptor.range.inside.2065 = and i1 %descriptor.owner.offset.valid.2063, %descriptor.extent.inside.2061
  %descriptor.range.valid.2064 = and i1 %descriptor.range.inside.2065, %descriptor.payload.inside.2062
  br i1 %descriptor.range.valid.2064, label %descriptor.valid.2066, label %descriptor.invalid.2067
descriptor.invalid.2067:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2066:
  %descriptor.initialized.status.2068 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2052, i32 %local.check.extent.2053)
  %helper.ok.2069 = icmp eq i32 %descriptor.initialized.status.2068, 0
  br i1 %helper.ok.2069, label %helper.continue.2070, label %frame.failure.0
helper.continue.2070:
  br label %local.descriptor.checked.2051
local.descriptor.inactive.2050:
  br label %local.descriptor.checked.2051
local.descriptor.checked.2051:
  %context.field.2071 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2072 = load i32, ptr %context.field.2071, align 4
  %stack.sub.2073 = sub i32 %context.value.2072, %context.value.1363
  call void @al_owning_record_layout(ptr %ctx, i32 18, i32 0, i32 %context.value.1363, i32 %stack.sub.2073, i32 0, i32 0, i32 0)
  %context.field.2074 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2075 = load i32, ptr %context.field.2074, align 4
  %runtime.ok.2076 = icmp eq i32 %context.value.2075, 0
  br i1 %runtime.ok.2076, label %runtime.continue.2077, label %frame.failure.0
runtime.continue.2077:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.1363, i32 0, i32 0, i32 0)
  %context.field.2078 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2079 = load i32, ptr %context.field.2078, align 4
  %runtime.ok.2080 = icmp eq i32 %context.value.2079, 0
  br i1 %runtime.ok.2080, label %runtime.continue.2081, label %frame.failure.0
runtime.continue.2081:
  %local.is.active.2082 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2082, label %local.descriptor.active.2083, label %local.descriptor.inactive.2084
local.descriptor.active.2083:
  %local.check.offset.2086 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2087 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2088 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2089 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2090 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2091 = load i32, ptr %context.field.2090, align 4
  %stack.sub.2094 = sub i32 %local.check.owner.end.2089, %local.check.offset.2086
  %descriptor.owner.inside.2092 = icmp ule i32 %local.check.owner.end.2089, %context.value.2091
  %descriptor.offset.inside.2093 = icmp ule i32 %local.check.offset.2086, %local.check.owner.end.2089
  %descriptor.extent.inside.2095 = icmp ule i32 %local.check.extent.2087, %stack.sub.2094
  %descriptor.payload.inside.2096 = icmp ule i32 %local.check.payload.2088, %local.check.extent.2087
  %descriptor.owner.offset.valid.2097 = and i1 %descriptor.owner.inside.2092, %descriptor.offset.inside.2093
  %descriptor.range.inside.2099 = and i1 %descriptor.owner.offset.valid.2097, %descriptor.extent.inside.2095
  %descriptor.range.valid.2098 = and i1 %descriptor.range.inside.2099, %descriptor.payload.inside.2096
  br i1 %descriptor.range.valid.2098, label %descriptor.valid.2100, label %descriptor.invalid.2101
descriptor.invalid.2101:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2100:
  %descriptor.initialized.status.2102 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2086, i32 %local.check.extent.2087)
  %helper.ok.2103 = icmp eq i32 %descriptor.initialized.status.2102, 0
  br i1 %helper.ok.2103, label %helper.continue.2104, label %frame.failure.0
helper.continue.2104:
  br label %local.descriptor.checked.2085
local.descriptor.inactive.2084:
  br label %local.descriptor.checked.2085
local.descriptor.checked.2085:
  %local.is.active.2105 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2105, label %local.descriptor.active.2106, label %local.descriptor.inactive.2107
local.descriptor.active.2106:
  %local.check.offset.2109 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2110 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2111 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2112 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2113 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2114 = load i32, ptr %context.field.2113, align 4
  %stack.sub.2117 = sub i32 %local.check.owner.end.2112, %local.check.offset.2109
  %descriptor.owner.inside.2115 = icmp ule i32 %local.check.owner.end.2112, %context.value.2114
  %descriptor.offset.inside.2116 = icmp ule i32 %local.check.offset.2109, %local.check.owner.end.2112
  %descriptor.extent.inside.2118 = icmp ule i32 %local.check.extent.2110, %stack.sub.2117
  %descriptor.payload.inside.2119 = icmp ule i32 %local.check.payload.2111, %local.check.extent.2110
  %descriptor.owner.offset.valid.2120 = and i1 %descriptor.owner.inside.2115, %descriptor.offset.inside.2116
  %descriptor.range.inside.2122 = and i1 %descriptor.owner.offset.valid.2120, %descriptor.extent.inside.2118
  %descriptor.range.valid.2121 = and i1 %descriptor.range.inside.2122, %descriptor.payload.inside.2119
  br i1 %descriptor.range.valid.2121, label %descriptor.valid.2123, label %descriptor.invalid.2124
descriptor.invalid.2124:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2123:
  %descriptor.initialized.status.2125 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2109, i32 %local.check.extent.2110)
  %helper.ok.2126 = icmp eq i32 %descriptor.initialized.status.2125, 0
  br i1 %helper.ok.2126, label %helper.continue.2127, label %frame.failure.0
helper.continue.2127:
  br label %local.descriptor.checked.2108
local.descriptor.inactive.2107:
  br label %local.descriptor.checked.2108
local.descriptor.checked.2108:
  %local.is.active.2128 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2128, label %local.descriptor.active.2129, label %local.descriptor.inactive.2130
local.descriptor.active.2129:
  %local.check.offset.2132 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2133 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2134 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2135 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2136 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2137 = load i32, ptr %context.field.2136, align 4
  %stack.sub.2140 = sub i32 %local.check.owner.end.2135, %local.check.offset.2132
  %descriptor.owner.inside.2138 = icmp ule i32 %local.check.owner.end.2135, %context.value.2137
  %descriptor.offset.inside.2139 = icmp ule i32 %local.check.offset.2132, %local.check.owner.end.2135
  %descriptor.extent.inside.2141 = icmp ule i32 %local.check.extent.2133, %stack.sub.2140
  %descriptor.payload.inside.2142 = icmp ule i32 %local.check.payload.2134, %local.check.extent.2133
  %descriptor.owner.offset.valid.2143 = and i1 %descriptor.owner.inside.2138, %descriptor.offset.inside.2139
  %descriptor.range.inside.2145 = and i1 %descriptor.owner.offset.valid.2143, %descriptor.extent.inside.2141
  %descriptor.range.valid.2144 = and i1 %descriptor.range.inside.2145, %descriptor.payload.inside.2142
  br i1 %descriptor.range.valid.2144, label %descriptor.valid.2146, label %descriptor.invalid.2147
descriptor.invalid.2147:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2146:
  %descriptor.initialized.status.2148 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2132, i32 %local.check.extent.2133)
  %helper.ok.2149 = icmp eq i32 %descriptor.initialized.status.2148, 0
  br i1 %helper.ok.2149, label %helper.continue.2150, label %frame.failure.0
helper.continue.2150:
  br label %local.descriptor.checked.2131
local.descriptor.inactive.2130:
  br label %local.descriptor.checked.2131
local.descriptor.checked.2131:
  %local.is.active.2151 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2151, label %local.descriptor.active.2152, label %local.descriptor.inactive.2153
local.descriptor.active.2152:
  %local.check.offset.2155 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2156 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2157 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2158 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2159 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2160 = load i32, ptr %context.field.2159, align 4
  %stack.sub.2163 = sub i32 %local.check.owner.end.2158, %local.check.offset.2155
  %descriptor.owner.inside.2161 = icmp ule i32 %local.check.owner.end.2158, %context.value.2160
  %descriptor.offset.inside.2162 = icmp ule i32 %local.check.offset.2155, %local.check.owner.end.2158
  %descriptor.extent.inside.2164 = icmp ule i32 %local.check.extent.2156, %stack.sub.2163
  %descriptor.payload.inside.2165 = icmp ule i32 %local.check.payload.2157, %local.check.extent.2156
  %descriptor.owner.offset.valid.2166 = and i1 %descriptor.owner.inside.2161, %descriptor.offset.inside.2162
  %descriptor.range.inside.2168 = and i1 %descriptor.owner.offset.valid.2166, %descriptor.extent.inside.2164
  %descriptor.range.valid.2167 = and i1 %descriptor.range.inside.2168, %descriptor.payload.inside.2165
  br i1 %descriptor.range.valid.2167, label %descriptor.valid.2169, label %descriptor.invalid.2170
descriptor.invalid.2170:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2169:
  %descriptor.initialized.status.2171 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2155, i32 %local.check.extent.2156)
  %helper.ok.2172 = icmp eq i32 %descriptor.initialized.status.2171, 0
  br i1 %helper.ok.2172, label %helper.continue.2173, label %frame.failure.0
helper.continue.2173:
  br label %local.descriptor.checked.2154
local.descriptor.inactive.2153:
  br label %local.descriptor.checked.2154
local.descriptor.checked.2154:
  %local.is.active.2174 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2174, label %local.descriptor.active.2175, label %local.descriptor.inactive.2176
local.descriptor.active.2175:
  %local.check.offset.2178 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2179 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2180 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2181 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2182 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2183 = load i32, ptr %context.field.2182, align 4
  %stack.sub.2186 = sub i32 %local.check.owner.end.2181, %local.check.offset.2178
  %descriptor.owner.inside.2184 = icmp ule i32 %local.check.owner.end.2181, %context.value.2183
  %descriptor.offset.inside.2185 = icmp ule i32 %local.check.offset.2178, %local.check.owner.end.2181
  %descriptor.extent.inside.2187 = icmp ule i32 %local.check.extent.2179, %stack.sub.2186
  %descriptor.payload.inside.2188 = icmp ule i32 %local.check.payload.2180, %local.check.extent.2179
  %descriptor.owner.offset.valid.2189 = and i1 %descriptor.owner.inside.2184, %descriptor.offset.inside.2185
  %descriptor.range.inside.2191 = and i1 %descriptor.owner.offset.valid.2189, %descriptor.extent.inside.2187
  %descriptor.range.valid.2190 = and i1 %descriptor.range.inside.2191, %descriptor.payload.inside.2188
  br i1 %descriptor.range.valid.2190, label %descriptor.valid.2192, label %descriptor.invalid.2193
descriptor.invalid.2193:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2192:
  %descriptor.initialized.status.2194 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2178, i32 %local.check.extent.2179)
  %helper.ok.2195 = icmp eq i32 %descriptor.initialized.status.2194, 0
  br i1 %helper.ok.2195, label %helper.continue.2196, label %frame.failure.0
helper.continue.2196:
  br label %local.descriptor.checked.2177
local.descriptor.inactive.2176:
  br label %local.descriptor.checked.2177
local.descriptor.checked.2177:
  %local.is.active.2197 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2197, label %local.descriptor.active.2198, label %local.descriptor.inactive.2199
local.descriptor.active.2198:
  %local.check.offset.2201 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2202 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2203 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2204 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2205 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2206 = load i32, ptr %context.field.2205, align 4
  %stack.sub.2209 = sub i32 %local.check.owner.end.2204, %local.check.offset.2201
  %descriptor.owner.inside.2207 = icmp ule i32 %local.check.owner.end.2204, %context.value.2206
  %descriptor.offset.inside.2208 = icmp ule i32 %local.check.offset.2201, %local.check.owner.end.2204
  %descriptor.extent.inside.2210 = icmp ule i32 %local.check.extent.2202, %stack.sub.2209
  %descriptor.payload.inside.2211 = icmp ule i32 %local.check.payload.2203, %local.check.extent.2202
  %descriptor.owner.offset.valid.2212 = and i1 %descriptor.owner.inside.2207, %descriptor.offset.inside.2208
  %descriptor.range.inside.2214 = and i1 %descriptor.owner.offset.valid.2212, %descriptor.extent.inside.2210
  %descriptor.range.valid.2213 = and i1 %descriptor.range.inside.2214, %descriptor.payload.inside.2211
  br i1 %descriptor.range.valid.2213, label %descriptor.valid.2215, label %descriptor.invalid.2216
descriptor.invalid.2216:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2215:
  %descriptor.initialized.status.2217 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2201, i32 %local.check.extent.2202)
  %helper.ok.2218 = icmp eq i32 %descriptor.initialized.status.2217, 0
  br i1 %helper.ok.2218, label %helper.continue.2219, label %frame.failure.0
helper.continue.2219:
  br label %local.descriptor.checked.2200
local.descriptor.inactive.2199:
  br label %local.descriptor.checked.2200
local.descriptor.checked.2200:
  %step.status.2220 = call i32 @al_owning_charge_step(ptr %ctx, i32 15)
  %helper.ok.2221 = icmp eq i32 %step.status.2220, 0
  br i1 %helper.ok.2221, label %helper.continue.2222, label %frame.failure.0
helper.continue.2222:
  %context.field.2223 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2224 = load i32, ptr %context.field.2223, align 4
  %stack.offset.2225 = add i32 %context.value.2224, 16
  %reserve.status.2226 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.2225, i32 16)
  %reserve.ok.2227 = icmp eq i32 %reserve.status.2226, 0
  br i1 %reserve.ok.2227, label %reserve.continue.2228, label %frame.failure.0
reserve.continue.2228:
  %literal.status.2229 = call i32 @al_owning_copy_constant(ptr %ctx, i32 %context.value.2224, ptr getelementptr inbounds ([16 x i8], ptr @al_owning_string_literal_0, i64 0, i64 0), i32 16, i32 10, i32 16, i32 12, i32 17)
  %helper.ok.2230 = icmp eq i32 %literal.status.2229, 0
  br i1 %helper.ok.2230, label %helper.continue.2231, label %frame.failure.0
helper.continue.2231:
  %context.field.2232 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2233 = load i32, ptr %context.field.2232, align 4
  %stack.sub.2236 = sub i32 %stack.offset.2225, %context.value.2224
  %descriptor.owner.inside.2234 = icmp ule i32 %stack.offset.2225, %context.value.2233
  %descriptor.offset.inside.2235 = icmp ule i32 %context.value.2224, %stack.offset.2225
  %descriptor.extent.inside.2237 = icmp ule i32 16, %stack.sub.2236
  %descriptor.payload.inside.2238 = icmp ule i32 10, 16
  %descriptor.owner.offset.valid.2239 = and i1 %descriptor.owner.inside.2234, %descriptor.offset.inside.2235
  %descriptor.range.inside.2241 = and i1 %descriptor.owner.offset.valid.2239, %descriptor.extent.inside.2237
  %descriptor.range.valid.2240 = and i1 %descriptor.range.inside.2241, %descriptor.payload.inside.2238
  %descriptor.type.valid.2242 = icmp eq i32 12, 12
  %descriptor.valid.2243 = and i1 %descriptor.range.valid.2240, %descriptor.type.valid.2242
  br i1 %descriptor.valid.2243, label %descriptor.valid.2244, label %descriptor.invalid.2245
descriptor.invalid.2245:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2244:
  %descriptor.initialized.status.2246 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.2224, i32 16)
  %helper.ok.2247 = icmp eq i32 %descriptor.initialized.status.2246, 0
  br i1 %helper.ok.2247, label %helper.continue.2248, label %frame.failure.0
helper.continue.2248:
  %local.is.active.2249 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2249, label %local.descriptor.active.2250, label %local.descriptor.inactive.2251
local.descriptor.active.2250:
  %local.check.offset.2253 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2254 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2255 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2256 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2257 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2258 = load i32, ptr %context.field.2257, align 4
  %stack.sub.2261 = sub i32 %local.check.owner.end.2256, %local.check.offset.2253
  %descriptor.owner.inside.2259 = icmp ule i32 %local.check.owner.end.2256, %context.value.2258
  %descriptor.offset.inside.2260 = icmp ule i32 %local.check.offset.2253, %local.check.owner.end.2256
  %descriptor.extent.inside.2262 = icmp ule i32 %local.check.extent.2254, %stack.sub.2261
  %descriptor.payload.inside.2263 = icmp ule i32 %local.check.payload.2255, %local.check.extent.2254
  %descriptor.owner.offset.valid.2264 = and i1 %descriptor.owner.inside.2259, %descriptor.offset.inside.2260
  %descriptor.range.inside.2266 = and i1 %descriptor.owner.offset.valid.2264, %descriptor.extent.inside.2262
  %descriptor.range.valid.2265 = and i1 %descriptor.range.inside.2266, %descriptor.payload.inside.2263
  br i1 %descriptor.range.valid.2265, label %descriptor.valid.2267, label %descriptor.invalid.2268
descriptor.invalid.2268:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2267:
  %descriptor.initialized.status.2269 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2253, i32 %local.check.extent.2254)
  %helper.ok.2270 = icmp eq i32 %descriptor.initialized.status.2269, 0
  br i1 %helper.ok.2270, label %helper.continue.2271, label %frame.failure.0
helper.continue.2271:
  br label %local.descriptor.checked.2252
local.descriptor.inactive.2251:
  br label %local.descriptor.checked.2252
local.descriptor.checked.2252:
  %local.is.active.2272 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2272, label %local.descriptor.active.2273, label %local.descriptor.inactive.2274
local.descriptor.active.2273:
  %local.check.offset.2276 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2277 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2278 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2279 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2280 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2281 = load i32, ptr %context.field.2280, align 4
  %stack.sub.2284 = sub i32 %local.check.owner.end.2279, %local.check.offset.2276
  %descriptor.owner.inside.2282 = icmp ule i32 %local.check.owner.end.2279, %context.value.2281
  %descriptor.offset.inside.2283 = icmp ule i32 %local.check.offset.2276, %local.check.owner.end.2279
  %descriptor.extent.inside.2285 = icmp ule i32 %local.check.extent.2277, %stack.sub.2284
  %descriptor.payload.inside.2286 = icmp ule i32 %local.check.payload.2278, %local.check.extent.2277
  %descriptor.owner.offset.valid.2287 = and i1 %descriptor.owner.inside.2282, %descriptor.offset.inside.2283
  %descriptor.range.inside.2289 = and i1 %descriptor.owner.offset.valid.2287, %descriptor.extent.inside.2285
  %descriptor.range.valid.2288 = and i1 %descriptor.range.inside.2289, %descriptor.payload.inside.2286
  br i1 %descriptor.range.valid.2288, label %descriptor.valid.2290, label %descriptor.invalid.2291
descriptor.invalid.2291:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2290:
  %descriptor.initialized.status.2292 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2276, i32 %local.check.extent.2277)
  %helper.ok.2293 = icmp eq i32 %descriptor.initialized.status.2292, 0
  br i1 %helper.ok.2293, label %helper.continue.2294, label %frame.failure.0
helper.continue.2294:
  br label %local.descriptor.checked.2275
local.descriptor.inactive.2274:
  br label %local.descriptor.checked.2275
local.descriptor.checked.2275:
  %local.is.active.2295 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2295, label %local.descriptor.active.2296, label %local.descriptor.inactive.2297
local.descriptor.active.2296:
  %local.check.offset.2299 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2300 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2301 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2302 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2303 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2304 = load i32, ptr %context.field.2303, align 4
  %stack.sub.2307 = sub i32 %local.check.owner.end.2302, %local.check.offset.2299
  %descriptor.owner.inside.2305 = icmp ule i32 %local.check.owner.end.2302, %context.value.2304
  %descriptor.offset.inside.2306 = icmp ule i32 %local.check.offset.2299, %local.check.owner.end.2302
  %descriptor.extent.inside.2308 = icmp ule i32 %local.check.extent.2300, %stack.sub.2307
  %descriptor.payload.inside.2309 = icmp ule i32 %local.check.payload.2301, %local.check.extent.2300
  %descriptor.owner.offset.valid.2310 = and i1 %descriptor.owner.inside.2305, %descriptor.offset.inside.2306
  %descriptor.range.inside.2312 = and i1 %descriptor.owner.offset.valid.2310, %descriptor.extent.inside.2308
  %descriptor.range.valid.2311 = and i1 %descriptor.range.inside.2312, %descriptor.payload.inside.2309
  br i1 %descriptor.range.valid.2311, label %descriptor.valid.2313, label %descriptor.invalid.2314
descriptor.invalid.2314:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2313:
  %descriptor.initialized.status.2315 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2299, i32 %local.check.extent.2300)
  %helper.ok.2316 = icmp eq i32 %descriptor.initialized.status.2315, 0
  br i1 %helper.ok.2316, label %helper.continue.2317, label %frame.failure.0
helper.continue.2317:
  br label %local.descriptor.checked.2298
local.descriptor.inactive.2297:
  br label %local.descriptor.checked.2298
local.descriptor.checked.2298:
  %local.is.active.2318 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2318, label %local.descriptor.active.2319, label %local.descriptor.inactive.2320
local.descriptor.active.2319:
  %local.check.offset.2322 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2323 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2324 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2325 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2326 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2327 = load i32, ptr %context.field.2326, align 4
  %stack.sub.2330 = sub i32 %local.check.owner.end.2325, %local.check.offset.2322
  %descriptor.owner.inside.2328 = icmp ule i32 %local.check.owner.end.2325, %context.value.2327
  %descriptor.offset.inside.2329 = icmp ule i32 %local.check.offset.2322, %local.check.owner.end.2325
  %descriptor.extent.inside.2331 = icmp ule i32 %local.check.extent.2323, %stack.sub.2330
  %descriptor.payload.inside.2332 = icmp ule i32 %local.check.payload.2324, %local.check.extent.2323
  %descriptor.owner.offset.valid.2333 = and i1 %descriptor.owner.inside.2328, %descriptor.offset.inside.2329
  %descriptor.range.inside.2335 = and i1 %descriptor.owner.offset.valid.2333, %descriptor.extent.inside.2331
  %descriptor.range.valid.2334 = and i1 %descriptor.range.inside.2335, %descriptor.payload.inside.2332
  br i1 %descriptor.range.valid.2334, label %descriptor.valid.2336, label %descriptor.invalid.2337
descriptor.invalid.2337:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2336:
  %descriptor.initialized.status.2338 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2322, i32 %local.check.extent.2323)
  %helper.ok.2339 = icmp eq i32 %descriptor.initialized.status.2338, 0
  br i1 %helper.ok.2339, label %helper.continue.2340, label %frame.failure.0
helper.continue.2340:
  br label %local.descriptor.checked.2321
local.descriptor.inactive.2320:
  br label %local.descriptor.checked.2321
local.descriptor.checked.2321:
  %local.is.active.2341 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2341, label %local.descriptor.active.2342, label %local.descriptor.inactive.2343
local.descriptor.active.2342:
  %local.check.offset.2345 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2346 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2347 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2348 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2349 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2350 = load i32, ptr %context.field.2349, align 4
  %stack.sub.2353 = sub i32 %local.check.owner.end.2348, %local.check.offset.2345
  %descriptor.owner.inside.2351 = icmp ule i32 %local.check.owner.end.2348, %context.value.2350
  %descriptor.offset.inside.2352 = icmp ule i32 %local.check.offset.2345, %local.check.owner.end.2348
  %descriptor.extent.inside.2354 = icmp ule i32 %local.check.extent.2346, %stack.sub.2353
  %descriptor.payload.inside.2355 = icmp ule i32 %local.check.payload.2347, %local.check.extent.2346
  %descriptor.owner.offset.valid.2356 = and i1 %descriptor.owner.inside.2351, %descriptor.offset.inside.2352
  %descriptor.range.inside.2358 = and i1 %descriptor.owner.offset.valid.2356, %descriptor.extent.inside.2354
  %descriptor.range.valid.2357 = and i1 %descriptor.range.inside.2358, %descriptor.payload.inside.2355
  br i1 %descriptor.range.valid.2357, label %descriptor.valid.2359, label %descriptor.invalid.2360
descriptor.invalid.2360:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2359:
  %descriptor.initialized.status.2361 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2345, i32 %local.check.extent.2346)
  %helper.ok.2362 = icmp eq i32 %descriptor.initialized.status.2361, 0
  br i1 %helper.ok.2362, label %helper.continue.2363, label %frame.failure.0
helper.continue.2363:
  br label %local.descriptor.checked.2344
local.descriptor.inactive.2343:
  br label %local.descriptor.checked.2344
local.descriptor.checked.2344:
  %local.is.active.2364 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2364, label %local.descriptor.active.2365, label %local.descriptor.inactive.2366
local.descriptor.active.2365:
  %local.check.offset.2368 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2369 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2370 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2371 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2372 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2373 = load i32, ptr %context.field.2372, align 4
  %stack.sub.2376 = sub i32 %local.check.owner.end.2371, %local.check.offset.2368
  %descriptor.owner.inside.2374 = icmp ule i32 %local.check.owner.end.2371, %context.value.2373
  %descriptor.offset.inside.2375 = icmp ule i32 %local.check.offset.2368, %local.check.owner.end.2371
  %descriptor.extent.inside.2377 = icmp ule i32 %local.check.extent.2369, %stack.sub.2376
  %descriptor.payload.inside.2378 = icmp ule i32 %local.check.payload.2370, %local.check.extent.2369
  %descriptor.owner.offset.valid.2379 = and i1 %descriptor.owner.inside.2374, %descriptor.offset.inside.2375
  %descriptor.range.inside.2381 = and i1 %descriptor.owner.offset.valid.2379, %descriptor.extent.inside.2377
  %descriptor.range.valid.2380 = and i1 %descriptor.range.inside.2381, %descriptor.payload.inside.2378
  br i1 %descriptor.range.valid.2380, label %descriptor.valid.2382, label %descriptor.invalid.2383
descriptor.invalid.2383:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2382:
  %descriptor.initialized.status.2384 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2368, i32 %local.check.extent.2369)
  %helper.ok.2385 = icmp eq i32 %descriptor.initialized.status.2384, 0
  br i1 %helper.ok.2385, label %helper.continue.2386, label %frame.failure.0
helper.continue.2386:
  br label %local.descriptor.checked.2367
local.descriptor.inactive.2366:
  br label %local.descriptor.checked.2367
local.descriptor.checked.2367:
  %step.status.2387 = call i32 @al_owning_charge_step(ptr %ctx, i32 18)
  %helper.ok.2388 = icmp eq i32 %step.status.2387, 0
  br i1 %helper.ok.2388, label %helper.continue.2389, label %frame.failure.0
helper.continue.2389:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 12, i32 %context.value.2224, i32 16, i32 10, i32 0, i32 0)
  %context.field.2390 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2391 = load i32, ptr %context.field.2390, align 4
  %runtime.ok.2392 = icmp eq i32 %context.value.2391, 0
  br i1 %runtime.ok.2392, label %runtime.continue.2393, label %frame.failure.0
runtime.continue.2393:
  %local.is.active.2394 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2394, label %local.descriptor.active.2395, label %local.descriptor.inactive.2396
local.descriptor.active.2395:
  %local.check.offset.2398 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2399 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2400 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2401 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2402 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2403 = load i32, ptr %context.field.2402, align 4
  %stack.sub.2406 = sub i32 %local.check.owner.end.2401, %local.check.offset.2398
  %descriptor.owner.inside.2404 = icmp ule i32 %local.check.owner.end.2401, %context.value.2403
  %descriptor.offset.inside.2405 = icmp ule i32 %local.check.offset.2398, %local.check.owner.end.2401
  %descriptor.extent.inside.2407 = icmp ule i32 %local.check.extent.2399, %stack.sub.2406
  %descriptor.payload.inside.2408 = icmp ule i32 %local.check.payload.2400, %local.check.extent.2399
  %descriptor.owner.offset.valid.2409 = and i1 %descriptor.owner.inside.2404, %descriptor.offset.inside.2405
  %descriptor.range.inside.2411 = and i1 %descriptor.owner.offset.valid.2409, %descriptor.extent.inside.2407
  %descriptor.range.valid.2410 = and i1 %descriptor.range.inside.2411, %descriptor.payload.inside.2408
  br i1 %descriptor.range.valid.2410, label %descriptor.valid.2412, label %descriptor.invalid.2413
descriptor.invalid.2413:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2412:
  %descriptor.initialized.status.2414 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2398, i32 %local.check.extent.2399)
  %helper.ok.2415 = icmp eq i32 %descriptor.initialized.status.2414, 0
  br i1 %helper.ok.2415, label %helper.continue.2416, label %frame.failure.0
helper.continue.2416:
  br label %local.descriptor.checked.2397
local.descriptor.inactive.2396:
  br label %local.descriptor.checked.2397
local.descriptor.checked.2397:
  %local.is.active.2417 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2417, label %local.descriptor.active.2418, label %local.descriptor.inactive.2419
local.descriptor.active.2418:
  %local.check.offset.2421 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2422 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2423 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2424 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2425 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2426 = load i32, ptr %context.field.2425, align 4
  %stack.sub.2429 = sub i32 %local.check.owner.end.2424, %local.check.offset.2421
  %descriptor.owner.inside.2427 = icmp ule i32 %local.check.owner.end.2424, %context.value.2426
  %descriptor.offset.inside.2428 = icmp ule i32 %local.check.offset.2421, %local.check.owner.end.2424
  %descriptor.extent.inside.2430 = icmp ule i32 %local.check.extent.2422, %stack.sub.2429
  %descriptor.payload.inside.2431 = icmp ule i32 %local.check.payload.2423, %local.check.extent.2422
  %descriptor.owner.offset.valid.2432 = and i1 %descriptor.owner.inside.2427, %descriptor.offset.inside.2428
  %descriptor.range.inside.2434 = and i1 %descriptor.owner.offset.valid.2432, %descriptor.extent.inside.2430
  %descriptor.range.valid.2433 = and i1 %descriptor.range.inside.2434, %descriptor.payload.inside.2431
  br i1 %descriptor.range.valid.2433, label %descriptor.valid.2435, label %descriptor.invalid.2436
descriptor.invalid.2436:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2435:
  %descriptor.initialized.status.2437 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2421, i32 %local.check.extent.2422)
  %helper.ok.2438 = icmp eq i32 %descriptor.initialized.status.2437, 0
  br i1 %helper.ok.2438, label %helper.continue.2439, label %frame.failure.0
helper.continue.2439:
  br label %local.descriptor.checked.2420
local.descriptor.inactive.2419:
  br label %local.descriptor.checked.2420
local.descriptor.checked.2420:
  %local.is.active.2440 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2440, label %local.descriptor.active.2441, label %local.descriptor.inactive.2442
local.descriptor.active.2441:
  %local.check.offset.2444 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2445 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2446 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2447 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2448 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2449 = load i32, ptr %context.field.2448, align 4
  %stack.sub.2452 = sub i32 %local.check.owner.end.2447, %local.check.offset.2444
  %descriptor.owner.inside.2450 = icmp ule i32 %local.check.owner.end.2447, %context.value.2449
  %descriptor.offset.inside.2451 = icmp ule i32 %local.check.offset.2444, %local.check.owner.end.2447
  %descriptor.extent.inside.2453 = icmp ule i32 %local.check.extent.2445, %stack.sub.2452
  %descriptor.payload.inside.2454 = icmp ule i32 %local.check.payload.2446, %local.check.extent.2445
  %descriptor.owner.offset.valid.2455 = and i1 %descriptor.owner.inside.2450, %descriptor.offset.inside.2451
  %descriptor.range.inside.2457 = and i1 %descriptor.owner.offset.valid.2455, %descriptor.extent.inside.2453
  %descriptor.range.valid.2456 = and i1 %descriptor.range.inside.2457, %descriptor.payload.inside.2454
  br i1 %descriptor.range.valid.2456, label %descriptor.valid.2458, label %descriptor.invalid.2459
descriptor.invalid.2459:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2458:
  %descriptor.initialized.status.2460 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2444, i32 %local.check.extent.2445)
  %helper.ok.2461 = icmp eq i32 %descriptor.initialized.status.2460, 0
  br i1 %helper.ok.2461, label %helper.continue.2462, label %frame.failure.0
helper.continue.2462:
  br label %local.descriptor.checked.2443
local.descriptor.inactive.2442:
  br label %local.descriptor.checked.2443
local.descriptor.checked.2443:
  %local.is.active.2463 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2463, label %local.descriptor.active.2464, label %local.descriptor.inactive.2465
local.descriptor.active.2464:
  %local.check.offset.2467 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2468 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2469 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2470 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2471 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2472 = load i32, ptr %context.field.2471, align 4
  %stack.sub.2475 = sub i32 %local.check.owner.end.2470, %local.check.offset.2467
  %descriptor.owner.inside.2473 = icmp ule i32 %local.check.owner.end.2470, %context.value.2472
  %descriptor.offset.inside.2474 = icmp ule i32 %local.check.offset.2467, %local.check.owner.end.2470
  %descriptor.extent.inside.2476 = icmp ule i32 %local.check.extent.2468, %stack.sub.2475
  %descriptor.payload.inside.2477 = icmp ule i32 %local.check.payload.2469, %local.check.extent.2468
  %descriptor.owner.offset.valid.2478 = and i1 %descriptor.owner.inside.2473, %descriptor.offset.inside.2474
  %descriptor.range.inside.2480 = and i1 %descriptor.owner.offset.valid.2478, %descriptor.extent.inside.2476
  %descriptor.range.valid.2479 = and i1 %descriptor.range.inside.2480, %descriptor.payload.inside.2477
  br i1 %descriptor.range.valid.2479, label %descriptor.valid.2481, label %descriptor.invalid.2482
descriptor.invalid.2482:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2481:
  %descriptor.initialized.status.2483 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2467, i32 %local.check.extent.2468)
  %helper.ok.2484 = icmp eq i32 %descriptor.initialized.status.2483, 0
  br i1 %helper.ok.2484, label %helper.continue.2485, label %frame.failure.0
helper.continue.2485:
  br label %local.descriptor.checked.2466
local.descriptor.inactive.2465:
  br label %local.descriptor.checked.2466
local.descriptor.checked.2466:
  %local.is.active.2486 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2486, label %local.descriptor.active.2487, label %local.descriptor.inactive.2488
local.descriptor.active.2487:
  %local.check.offset.2490 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2491 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2492 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2493 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2494 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2495 = load i32, ptr %context.field.2494, align 4
  %stack.sub.2498 = sub i32 %local.check.owner.end.2493, %local.check.offset.2490
  %descriptor.owner.inside.2496 = icmp ule i32 %local.check.owner.end.2493, %context.value.2495
  %descriptor.offset.inside.2497 = icmp ule i32 %local.check.offset.2490, %local.check.owner.end.2493
  %descriptor.extent.inside.2499 = icmp ule i32 %local.check.extent.2491, %stack.sub.2498
  %descriptor.payload.inside.2500 = icmp ule i32 %local.check.payload.2492, %local.check.extent.2491
  %descriptor.owner.offset.valid.2501 = and i1 %descriptor.owner.inside.2496, %descriptor.offset.inside.2497
  %descriptor.range.inside.2503 = and i1 %descriptor.owner.offset.valid.2501, %descriptor.extent.inside.2499
  %descriptor.range.valid.2502 = and i1 %descriptor.range.inside.2503, %descriptor.payload.inside.2500
  br i1 %descriptor.range.valid.2502, label %descriptor.valid.2504, label %descriptor.invalid.2505
descriptor.invalid.2505:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2504:
  %descriptor.initialized.status.2506 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2490, i32 %local.check.extent.2491)
  %helper.ok.2507 = icmp eq i32 %descriptor.initialized.status.2506, 0
  br i1 %helper.ok.2507, label %helper.continue.2508, label %frame.failure.0
helper.continue.2508:
  br label %local.descriptor.checked.2489
local.descriptor.inactive.2488:
  br label %local.descriptor.checked.2489
local.descriptor.checked.2489:
  %local.is.active.2509 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2509, label %local.descriptor.active.2510, label %local.descriptor.inactive.2511
local.descriptor.active.2510:
  %local.check.offset.2513 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2514 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2515 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2516 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2517 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2518 = load i32, ptr %context.field.2517, align 4
  %stack.sub.2521 = sub i32 %local.check.owner.end.2516, %local.check.offset.2513
  %descriptor.owner.inside.2519 = icmp ule i32 %local.check.owner.end.2516, %context.value.2518
  %descriptor.offset.inside.2520 = icmp ule i32 %local.check.offset.2513, %local.check.owner.end.2516
  %descriptor.extent.inside.2522 = icmp ule i32 %local.check.extent.2514, %stack.sub.2521
  %descriptor.payload.inside.2523 = icmp ule i32 %local.check.payload.2515, %local.check.extent.2514
  %descriptor.owner.offset.valid.2524 = and i1 %descriptor.owner.inside.2519, %descriptor.offset.inside.2520
  %descriptor.range.inside.2526 = and i1 %descriptor.owner.offset.valid.2524, %descriptor.extent.inside.2522
  %descriptor.range.valid.2525 = and i1 %descriptor.range.inside.2526, %descriptor.payload.inside.2523
  br i1 %descriptor.range.valid.2525, label %descriptor.valid.2527, label %descriptor.invalid.2528
descriptor.invalid.2528:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2527:
  %descriptor.initialized.status.2529 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2513, i32 %local.check.extent.2514)
  %helper.ok.2530 = icmp eq i32 %descriptor.initialized.status.2529, 0
  br i1 %helper.ok.2530, label %helper.continue.2531, label %frame.failure.0
helper.continue.2531:
  br label %local.descriptor.checked.2512
local.descriptor.inactive.2511:
  br label %local.descriptor.checked.2512
local.descriptor.checked.2512:
  %step.status.2532 = call i32 @al_owning_charge_step(ptr %ctx, i32 19)
  %helper.ok.2533 = icmp eq i32 %step.status.2532, 0
  br i1 %helper.ok.2533, label %helper.continue.2534, label %frame.failure.0
helper.continue.2534:
  %local.resolved.offset.2535 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.2536 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.2537 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.2538 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2539 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2540 = load i32, ptr %context.field.2539, align 4
  %stack.sub.2543 = sub i32 %local.resolved.owner.end.2538, %local.resolved.offset.2535
  %descriptor.owner.inside.2541 = icmp ule i32 %local.resolved.owner.end.2538, %context.value.2540
  %descriptor.offset.inside.2542 = icmp ule i32 %local.resolved.offset.2535, %local.resolved.owner.end.2538
  %descriptor.extent.inside.2544 = icmp ule i32 %local.resolved.extent.2536, %stack.sub.2543
  %descriptor.payload.inside.2545 = icmp ule i32 %local.resolved.payload.2537, %local.resolved.extent.2536
  %descriptor.owner.offset.valid.2546 = and i1 %descriptor.owner.inside.2541, %descriptor.offset.inside.2542
  %descriptor.range.inside.2548 = and i1 %descriptor.owner.offset.valid.2546, %descriptor.extent.inside.2544
  %descriptor.range.valid.2547 = and i1 %descriptor.range.inside.2548, %descriptor.payload.inside.2545
  %descriptor.type.valid.2549 = icmp eq i32 12, 12
  %descriptor.valid.2550 = and i1 %descriptor.range.valid.2547, %descriptor.type.valid.2549
  br i1 %descriptor.valid.2550, label %descriptor.valid.2551, label %descriptor.invalid.2552
descriptor.invalid.2552:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2551:
  %descriptor.initialized.status.2553 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.2535, i32 %local.resolved.extent.2536)
  %helper.ok.2554 = icmp eq i32 %descriptor.initialized.status.2553, 0
  br i1 %helper.ok.2554, label %helper.continue.2555, label %frame.failure.0
helper.continue.2555:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %local.resolved.offset.2535, i32 20, i32 %local.resolved.payload.2537, i32 %local.resolved.owner.end.2538, i32 %local.resolved.extent.2536)
  %context.field.2556 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2557 = load i32, ptr %context.field.2556, align 4
  %runtime.ok.2558 = icmp eq i32 %context.value.2557, 0
  br i1 %runtime.ok.2558, label %runtime.continue.2559, label %frame.failure.0
runtime.continue.2559:
  %context.field.2560 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2561 = load i32, ptr %context.field.2560, align 4
  %stack.sub.2564 = sub i32 %local.resolved.owner.end.2538, %local.resolved.offset.2535
  %descriptor.owner.inside.2562 = icmp ule i32 %local.resolved.owner.end.2538, %context.value.2561
  %descriptor.offset.inside.2563 = icmp ule i32 %local.resolved.offset.2535, %local.resolved.owner.end.2538
  %descriptor.extent.inside.2565 = icmp ule i32 %local.resolved.extent.2536, %stack.sub.2564
  %descriptor.payload.inside.2566 = icmp ule i32 %local.resolved.payload.2537, %local.resolved.extent.2536
  %descriptor.owner.offset.valid.2567 = and i1 %descriptor.owner.inside.2562, %descriptor.offset.inside.2563
  %descriptor.range.inside.2569 = and i1 %descriptor.owner.offset.valid.2567, %descriptor.extent.inside.2565
  %descriptor.range.valid.2568 = and i1 %descriptor.range.inside.2569, %descriptor.payload.inside.2566
  %descriptor.type.valid.2570 = icmp eq i32 12, 12
  %descriptor.valid.2571 = and i1 %descriptor.range.valid.2568, %descriptor.type.valid.2570
  br i1 %descriptor.valid.2571, label %descriptor.valid.2572, label %descriptor.invalid.2573
descriptor.invalid.2573:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2572:
  %descriptor.initialized.status.2574 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.2535, i32 %local.resolved.extent.2536)
  %helper.ok.2575 = icmp eq i32 %descriptor.initialized.status.2574, 0
  br i1 %helper.ok.2575, label %helper.continue.2576, label %frame.failure.0
helper.continue.2576:
  %local.is.active.2577 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2577, label %local.descriptor.active.2578, label %local.descriptor.inactive.2579
local.descriptor.active.2578:
  %local.check.offset.2581 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2582 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2583 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2584 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2585 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2586 = load i32, ptr %context.field.2585, align 4
  %stack.sub.2589 = sub i32 %local.check.owner.end.2584, %local.check.offset.2581
  %descriptor.owner.inside.2587 = icmp ule i32 %local.check.owner.end.2584, %context.value.2586
  %descriptor.offset.inside.2588 = icmp ule i32 %local.check.offset.2581, %local.check.owner.end.2584
  %descriptor.extent.inside.2590 = icmp ule i32 %local.check.extent.2582, %stack.sub.2589
  %descriptor.payload.inside.2591 = icmp ule i32 %local.check.payload.2583, %local.check.extent.2582
  %descriptor.owner.offset.valid.2592 = and i1 %descriptor.owner.inside.2587, %descriptor.offset.inside.2588
  %descriptor.range.inside.2594 = and i1 %descriptor.owner.offset.valid.2592, %descriptor.extent.inside.2590
  %descriptor.range.valid.2593 = and i1 %descriptor.range.inside.2594, %descriptor.payload.inside.2591
  br i1 %descriptor.range.valid.2593, label %descriptor.valid.2595, label %descriptor.invalid.2596
descriptor.invalid.2596:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2595:
  %descriptor.initialized.status.2597 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2581, i32 %local.check.extent.2582)
  %helper.ok.2598 = icmp eq i32 %descriptor.initialized.status.2597, 0
  br i1 %helper.ok.2598, label %helper.continue.2599, label %frame.failure.0
helper.continue.2599:
  br label %local.descriptor.checked.2580
local.descriptor.inactive.2579:
  br label %local.descriptor.checked.2580
local.descriptor.checked.2580:
  %local.is.active.2600 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2600, label %local.descriptor.active.2601, label %local.descriptor.inactive.2602
local.descriptor.active.2601:
  %local.check.offset.2604 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2605 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2606 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2607 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2608 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2609 = load i32, ptr %context.field.2608, align 4
  %stack.sub.2612 = sub i32 %local.check.owner.end.2607, %local.check.offset.2604
  %descriptor.owner.inside.2610 = icmp ule i32 %local.check.owner.end.2607, %context.value.2609
  %descriptor.offset.inside.2611 = icmp ule i32 %local.check.offset.2604, %local.check.owner.end.2607
  %descriptor.extent.inside.2613 = icmp ule i32 %local.check.extent.2605, %stack.sub.2612
  %descriptor.payload.inside.2614 = icmp ule i32 %local.check.payload.2606, %local.check.extent.2605
  %descriptor.owner.offset.valid.2615 = and i1 %descriptor.owner.inside.2610, %descriptor.offset.inside.2611
  %descriptor.range.inside.2617 = and i1 %descriptor.owner.offset.valid.2615, %descriptor.extent.inside.2613
  %descriptor.range.valid.2616 = and i1 %descriptor.range.inside.2617, %descriptor.payload.inside.2614
  br i1 %descriptor.range.valid.2616, label %descriptor.valid.2618, label %descriptor.invalid.2619
descriptor.invalid.2619:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2618:
  %descriptor.initialized.status.2620 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2604, i32 %local.check.extent.2605)
  %helper.ok.2621 = icmp eq i32 %descriptor.initialized.status.2620, 0
  br i1 %helper.ok.2621, label %helper.continue.2622, label %frame.failure.0
helper.continue.2622:
  br label %local.descriptor.checked.2603
local.descriptor.inactive.2602:
  br label %local.descriptor.checked.2603
local.descriptor.checked.2603:
  %local.is.active.2623 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2623, label %local.descriptor.active.2624, label %local.descriptor.inactive.2625
local.descriptor.active.2624:
  %local.check.offset.2627 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2628 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2629 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2630 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2631 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2632 = load i32, ptr %context.field.2631, align 4
  %stack.sub.2635 = sub i32 %local.check.owner.end.2630, %local.check.offset.2627
  %descriptor.owner.inside.2633 = icmp ule i32 %local.check.owner.end.2630, %context.value.2632
  %descriptor.offset.inside.2634 = icmp ule i32 %local.check.offset.2627, %local.check.owner.end.2630
  %descriptor.extent.inside.2636 = icmp ule i32 %local.check.extent.2628, %stack.sub.2635
  %descriptor.payload.inside.2637 = icmp ule i32 %local.check.payload.2629, %local.check.extent.2628
  %descriptor.owner.offset.valid.2638 = and i1 %descriptor.owner.inside.2633, %descriptor.offset.inside.2634
  %descriptor.range.inside.2640 = and i1 %descriptor.owner.offset.valid.2638, %descriptor.extent.inside.2636
  %descriptor.range.valid.2639 = and i1 %descriptor.range.inside.2640, %descriptor.payload.inside.2637
  br i1 %descriptor.range.valid.2639, label %descriptor.valid.2641, label %descriptor.invalid.2642
descriptor.invalid.2642:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2641:
  %descriptor.initialized.status.2643 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2627, i32 %local.check.extent.2628)
  %helper.ok.2644 = icmp eq i32 %descriptor.initialized.status.2643, 0
  br i1 %helper.ok.2644, label %helper.continue.2645, label %frame.failure.0
helper.continue.2645:
  br label %local.descriptor.checked.2626
local.descriptor.inactive.2625:
  br label %local.descriptor.checked.2626
local.descriptor.checked.2626:
  %local.is.active.2646 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2646, label %local.descriptor.active.2647, label %local.descriptor.inactive.2648
local.descriptor.active.2647:
  %local.check.offset.2650 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2651 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2652 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2653 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2654 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2655 = load i32, ptr %context.field.2654, align 4
  %stack.sub.2658 = sub i32 %local.check.owner.end.2653, %local.check.offset.2650
  %descriptor.owner.inside.2656 = icmp ule i32 %local.check.owner.end.2653, %context.value.2655
  %descriptor.offset.inside.2657 = icmp ule i32 %local.check.offset.2650, %local.check.owner.end.2653
  %descriptor.extent.inside.2659 = icmp ule i32 %local.check.extent.2651, %stack.sub.2658
  %descriptor.payload.inside.2660 = icmp ule i32 %local.check.payload.2652, %local.check.extent.2651
  %descriptor.owner.offset.valid.2661 = and i1 %descriptor.owner.inside.2656, %descriptor.offset.inside.2657
  %descriptor.range.inside.2663 = and i1 %descriptor.owner.offset.valid.2661, %descriptor.extent.inside.2659
  %descriptor.range.valid.2662 = and i1 %descriptor.range.inside.2663, %descriptor.payload.inside.2660
  br i1 %descriptor.range.valid.2662, label %descriptor.valid.2664, label %descriptor.invalid.2665
descriptor.invalid.2665:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2664:
  %descriptor.initialized.status.2666 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2650, i32 %local.check.extent.2651)
  %helper.ok.2667 = icmp eq i32 %descriptor.initialized.status.2666, 0
  br i1 %helper.ok.2667, label %helper.continue.2668, label %frame.failure.0
helper.continue.2668:
  br label %local.descriptor.checked.2649
local.descriptor.inactive.2648:
  br label %local.descriptor.checked.2649
local.descriptor.checked.2649:
  %local.is.active.2669 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2669, label %local.descriptor.active.2670, label %local.descriptor.inactive.2671
local.descriptor.active.2670:
  %local.check.offset.2673 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2674 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2675 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2676 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2677 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2678 = load i32, ptr %context.field.2677, align 4
  %stack.sub.2681 = sub i32 %local.check.owner.end.2676, %local.check.offset.2673
  %descriptor.owner.inside.2679 = icmp ule i32 %local.check.owner.end.2676, %context.value.2678
  %descriptor.offset.inside.2680 = icmp ule i32 %local.check.offset.2673, %local.check.owner.end.2676
  %descriptor.extent.inside.2682 = icmp ule i32 %local.check.extent.2674, %stack.sub.2681
  %descriptor.payload.inside.2683 = icmp ule i32 %local.check.payload.2675, %local.check.extent.2674
  %descriptor.owner.offset.valid.2684 = and i1 %descriptor.owner.inside.2679, %descriptor.offset.inside.2680
  %descriptor.range.inside.2686 = and i1 %descriptor.owner.offset.valid.2684, %descriptor.extent.inside.2682
  %descriptor.range.valid.2685 = and i1 %descriptor.range.inside.2686, %descriptor.payload.inside.2683
  br i1 %descriptor.range.valid.2685, label %descriptor.valid.2687, label %descriptor.invalid.2688
descriptor.invalid.2688:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2687:
  %descriptor.initialized.status.2689 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2673, i32 %local.check.extent.2674)
  %helper.ok.2690 = icmp eq i32 %descriptor.initialized.status.2689, 0
  br i1 %helper.ok.2690, label %helper.continue.2691, label %frame.failure.0
helper.continue.2691:
  br label %local.descriptor.checked.2672
local.descriptor.inactive.2671:
  br label %local.descriptor.checked.2672
local.descriptor.checked.2672:
  %local.is.active.2692 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2692, label %local.descriptor.active.2693, label %local.descriptor.inactive.2694
local.descriptor.active.2693:
  %local.check.offset.2696 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2697 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2698 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2699 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2700 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2701 = load i32, ptr %context.field.2700, align 4
  %stack.sub.2704 = sub i32 %local.check.owner.end.2699, %local.check.offset.2696
  %descriptor.owner.inside.2702 = icmp ule i32 %local.check.owner.end.2699, %context.value.2701
  %descriptor.offset.inside.2703 = icmp ule i32 %local.check.offset.2696, %local.check.owner.end.2699
  %descriptor.extent.inside.2705 = icmp ule i32 %local.check.extent.2697, %stack.sub.2704
  %descriptor.payload.inside.2706 = icmp ule i32 %local.check.payload.2698, %local.check.extent.2697
  %descriptor.owner.offset.valid.2707 = and i1 %descriptor.owner.inside.2702, %descriptor.offset.inside.2703
  %descriptor.range.inside.2709 = and i1 %descriptor.owner.offset.valid.2707, %descriptor.extent.inside.2705
  %descriptor.range.valid.2708 = and i1 %descriptor.range.inside.2709, %descriptor.payload.inside.2706
  br i1 %descriptor.range.valid.2708, label %descriptor.valid.2710, label %descriptor.invalid.2711
descriptor.invalid.2711:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2710:
  %descriptor.initialized.status.2712 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2696, i32 %local.check.extent.2697)
  %helper.ok.2713 = icmp eq i32 %descriptor.initialized.status.2712, 0
  br i1 %helper.ok.2713, label %helper.continue.2714, label %frame.failure.0
helper.continue.2714:
  br label %local.descriptor.checked.2695
local.descriptor.inactive.2694:
  br label %local.descriptor.checked.2695
local.descriptor.checked.2695:
  %step.status.2715 = call i32 @al_owning_charge_step(ptr %ctx, i32 20)
  %helper.ok.2716 = icmp eq i32 %step.status.2715, 0
  br i1 %helper.ok.2716, label %helper.continue.2717, label %frame.failure.0
helper.continue.2717:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 12, i32 %local.resolved.offset.2535, i32 %local.resolved.extent.2536, i32 %local.resolved.payload.2537, i32 0, i32 0)
  %context.field.2718 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2719 = load i32, ptr %context.field.2718, align 4
  %runtime.ok.2720 = icmp eq i32 %context.value.2719, 0
  br i1 %runtime.ok.2720, label %runtime.continue.2721, label %frame.failure.0
runtime.continue.2721:
  %local.is.active.2722 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2722, label %local.descriptor.active.2723, label %local.descriptor.inactive.2724
local.descriptor.active.2723:
  %local.check.offset.2726 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2727 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2728 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2729 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2730 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2731 = load i32, ptr %context.field.2730, align 4
  %stack.sub.2734 = sub i32 %local.check.owner.end.2729, %local.check.offset.2726
  %descriptor.owner.inside.2732 = icmp ule i32 %local.check.owner.end.2729, %context.value.2731
  %descriptor.offset.inside.2733 = icmp ule i32 %local.check.offset.2726, %local.check.owner.end.2729
  %descriptor.extent.inside.2735 = icmp ule i32 %local.check.extent.2727, %stack.sub.2734
  %descriptor.payload.inside.2736 = icmp ule i32 %local.check.payload.2728, %local.check.extent.2727
  %descriptor.owner.offset.valid.2737 = and i1 %descriptor.owner.inside.2732, %descriptor.offset.inside.2733
  %descriptor.range.inside.2739 = and i1 %descriptor.owner.offset.valid.2737, %descriptor.extent.inside.2735
  %descriptor.range.valid.2738 = and i1 %descriptor.range.inside.2739, %descriptor.payload.inside.2736
  br i1 %descriptor.range.valid.2738, label %descriptor.valid.2740, label %descriptor.invalid.2741
descriptor.invalid.2741:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2740:
  %descriptor.initialized.status.2742 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2726, i32 %local.check.extent.2727)
  %helper.ok.2743 = icmp eq i32 %descriptor.initialized.status.2742, 0
  br i1 %helper.ok.2743, label %helper.continue.2744, label %frame.failure.0
helper.continue.2744:
  br label %local.descriptor.checked.2725
local.descriptor.inactive.2724:
  br label %local.descriptor.checked.2725
local.descriptor.checked.2725:
  %local.is.active.2745 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2745, label %local.descriptor.active.2746, label %local.descriptor.inactive.2747
local.descriptor.active.2746:
  %local.check.offset.2749 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2750 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2751 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2752 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2753 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2754 = load i32, ptr %context.field.2753, align 4
  %stack.sub.2757 = sub i32 %local.check.owner.end.2752, %local.check.offset.2749
  %descriptor.owner.inside.2755 = icmp ule i32 %local.check.owner.end.2752, %context.value.2754
  %descriptor.offset.inside.2756 = icmp ule i32 %local.check.offset.2749, %local.check.owner.end.2752
  %descriptor.extent.inside.2758 = icmp ule i32 %local.check.extent.2750, %stack.sub.2757
  %descriptor.payload.inside.2759 = icmp ule i32 %local.check.payload.2751, %local.check.extent.2750
  %descriptor.owner.offset.valid.2760 = and i1 %descriptor.owner.inside.2755, %descriptor.offset.inside.2756
  %descriptor.range.inside.2762 = and i1 %descriptor.owner.offset.valid.2760, %descriptor.extent.inside.2758
  %descriptor.range.valid.2761 = and i1 %descriptor.range.inside.2762, %descriptor.payload.inside.2759
  br i1 %descriptor.range.valid.2761, label %descriptor.valid.2763, label %descriptor.invalid.2764
descriptor.invalid.2764:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2763:
  %descriptor.initialized.status.2765 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2749, i32 %local.check.extent.2750)
  %helper.ok.2766 = icmp eq i32 %descriptor.initialized.status.2765, 0
  br i1 %helper.ok.2766, label %helper.continue.2767, label %frame.failure.0
helper.continue.2767:
  br label %local.descriptor.checked.2748
local.descriptor.inactive.2747:
  br label %local.descriptor.checked.2748
local.descriptor.checked.2748:
  %local.is.active.2768 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2768, label %local.descriptor.active.2769, label %local.descriptor.inactive.2770
local.descriptor.active.2769:
  %local.check.offset.2772 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2773 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2774 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2775 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2776 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2777 = load i32, ptr %context.field.2776, align 4
  %stack.sub.2780 = sub i32 %local.check.owner.end.2775, %local.check.offset.2772
  %descriptor.owner.inside.2778 = icmp ule i32 %local.check.owner.end.2775, %context.value.2777
  %descriptor.offset.inside.2779 = icmp ule i32 %local.check.offset.2772, %local.check.owner.end.2775
  %descriptor.extent.inside.2781 = icmp ule i32 %local.check.extent.2773, %stack.sub.2780
  %descriptor.payload.inside.2782 = icmp ule i32 %local.check.payload.2774, %local.check.extent.2773
  %descriptor.owner.offset.valid.2783 = and i1 %descriptor.owner.inside.2778, %descriptor.offset.inside.2779
  %descriptor.range.inside.2785 = and i1 %descriptor.owner.offset.valid.2783, %descriptor.extent.inside.2781
  %descriptor.range.valid.2784 = and i1 %descriptor.range.inside.2785, %descriptor.payload.inside.2782
  br i1 %descriptor.range.valid.2784, label %descriptor.valid.2786, label %descriptor.invalid.2787
descriptor.invalid.2787:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2786:
  %descriptor.initialized.status.2788 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2772, i32 %local.check.extent.2773)
  %helper.ok.2789 = icmp eq i32 %descriptor.initialized.status.2788, 0
  br i1 %helper.ok.2789, label %helper.continue.2790, label %frame.failure.0
helper.continue.2790:
  br label %local.descriptor.checked.2771
local.descriptor.inactive.2770:
  br label %local.descriptor.checked.2771
local.descriptor.checked.2771:
  %local.is.active.2791 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2791, label %local.descriptor.active.2792, label %local.descriptor.inactive.2793
local.descriptor.active.2792:
  %local.check.offset.2795 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2796 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2797 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2798 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2799 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2800 = load i32, ptr %context.field.2799, align 4
  %stack.sub.2803 = sub i32 %local.check.owner.end.2798, %local.check.offset.2795
  %descriptor.owner.inside.2801 = icmp ule i32 %local.check.owner.end.2798, %context.value.2800
  %descriptor.offset.inside.2802 = icmp ule i32 %local.check.offset.2795, %local.check.owner.end.2798
  %descriptor.extent.inside.2804 = icmp ule i32 %local.check.extent.2796, %stack.sub.2803
  %descriptor.payload.inside.2805 = icmp ule i32 %local.check.payload.2797, %local.check.extent.2796
  %descriptor.owner.offset.valid.2806 = and i1 %descriptor.owner.inside.2801, %descriptor.offset.inside.2802
  %descriptor.range.inside.2808 = and i1 %descriptor.owner.offset.valid.2806, %descriptor.extent.inside.2804
  %descriptor.range.valid.2807 = and i1 %descriptor.range.inside.2808, %descriptor.payload.inside.2805
  br i1 %descriptor.range.valid.2807, label %descriptor.valid.2809, label %descriptor.invalid.2810
descriptor.invalid.2810:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2809:
  %descriptor.initialized.status.2811 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2795, i32 %local.check.extent.2796)
  %helper.ok.2812 = icmp eq i32 %descriptor.initialized.status.2811, 0
  br i1 %helper.ok.2812, label %helper.continue.2813, label %frame.failure.0
helper.continue.2813:
  br label %local.descriptor.checked.2794
local.descriptor.inactive.2793:
  br label %local.descriptor.checked.2794
local.descriptor.checked.2794:
  %local.is.active.2814 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2814, label %local.descriptor.active.2815, label %local.descriptor.inactive.2816
local.descriptor.active.2815:
  %local.check.offset.2818 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.2819 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.2820 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.2821 = load i32, ptr %local.owner.end.30, align 4
  %context.field.2822 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2823 = load i32, ptr %context.field.2822, align 4
  %stack.sub.2826 = sub i32 %local.check.owner.end.2821, %local.check.offset.2818
  %descriptor.owner.inside.2824 = icmp ule i32 %local.check.owner.end.2821, %context.value.2823
  %descriptor.offset.inside.2825 = icmp ule i32 %local.check.offset.2818, %local.check.owner.end.2821
  %descriptor.extent.inside.2827 = icmp ule i32 %local.check.extent.2819, %stack.sub.2826
  %descriptor.payload.inside.2828 = icmp ule i32 %local.check.payload.2820, %local.check.extent.2819
  %descriptor.owner.offset.valid.2829 = and i1 %descriptor.owner.inside.2824, %descriptor.offset.inside.2825
  %descriptor.range.inside.2831 = and i1 %descriptor.owner.offset.valid.2829, %descriptor.extent.inside.2827
  %descriptor.range.valid.2830 = and i1 %descriptor.range.inside.2831, %descriptor.payload.inside.2828
  br i1 %descriptor.range.valid.2830, label %descriptor.valid.2832, label %descriptor.invalid.2833
descriptor.invalid.2833:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2832:
  %descriptor.initialized.status.2834 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2818, i32 %local.check.extent.2819)
  %helper.ok.2835 = icmp eq i32 %descriptor.initialized.status.2834, 0
  br i1 %helper.ok.2835, label %helper.continue.2836, label %frame.failure.0
helper.continue.2836:
  br label %local.descriptor.checked.2817
local.descriptor.inactive.2816:
  br label %local.descriptor.checked.2817
local.descriptor.checked.2817:
  %local.is.active.2837 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.2837, label %local.descriptor.active.2838, label %local.descriptor.inactive.2839
local.descriptor.active.2838:
  %local.check.offset.2841 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.2842 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.2843 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.2844 = load i32, ptr %local.owner.end.36, align 4
  %context.field.2845 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2846 = load i32, ptr %context.field.2845, align 4
  %stack.sub.2849 = sub i32 %local.check.owner.end.2844, %local.check.offset.2841
  %descriptor.owner.inside.2847 = icmp ule i32 %local.check.owner.end.2844, %context.value.2846
  %descriptor.offset.inside.2848 = icmp ule i32 %local.check.offset.2841, %local.check.owner.end.2844
  %descriptor.extent.inside.2850 = icmp ule i32 %local.check.extent.2842, %stack.sub.2849
  %descriptor.payload.inside.2851 = icmp ule i32 %local.check.payload.2843, %local.check.extent.2842
  %descriptor.owner.offset.valid.2852 = and i1 %descriptor.owner.inside.2847, %descriptor.offset.inside.2848
  %descriptor.range.inside.2854 = and i1 %descriptor.owner.offset.valid.2852, %descriptor.extent.inside.2850
  %descriptor.range.valid.2853 = and i1 %descriptor.range.inside.2854, %descriptor.payload.inside.2851
  br i1 %descriptor.range.valid.2853, label %descriptor.valid.2855, label %descriptor.invalid.2856
descriptor.invalid.2856:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2855:
  %descriptor.initialized.status.2857 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2841, i32 %local.check.extent.2842)
  %helper.ok.2858 = icmp eq i32 %descriptor.initialized.status.2857, 0
  br i1 %helper.ok.2858, label %helper.continue.2859, label %frame.failure.0
helper.continue.2859:
  br label %local.descriptor.checked.2840
local.descriptor.inactive.2839:
  br label %local.descriptor.checked.2840
local.descriptor.checked.2840:
  %step.status.2860 = call i32 @al_owning_charge_step(ptr %ctx, i32 21)
  %helper.ok.2861 = icmp eq i32 %step.status.2860, 0
  br i1 %helper.ok.2861, label %helper.continue.2862, label %frame.failure.0
helper.continue.2862:
  %local.resolved.offset.2863 = load i32, ptr %local.offset.9, align 4
  %local.resolved.extent.2864 = load i32, ptr %local.extent.10, align 4
  %local.resolved.payload.2865 = load i32, ptr %local.payload.11, align 4
  %local.resolved.owner.end.2866 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2867 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2868 = load i32, ptr %context.field.2867, align 4
  %stack.sub.2871 = sub i32 %local.resolved.owner.end.2866, %local.resolved.offset.2863
  %descriptor.owner.inside.2869 = icmp ule i32 %local.resolved.owner.end.2866, %context.value.2868
  %descriptor.offset.inside.2870 = icmp ule i32 %local.resolved.offset.2863, %local.resolved.owner.end.2866
  %descriptor.extent.inside.2872 = icmp ule i32 %local.resolved.extent.2864, %stack.sub.2871
  %descriptor.payload.inside.2873 = icmp ule i32 %local.resolved.payload.2865, %local.resolved.extent.2864
  %descriptor.owner.offset.valid.2874 = and i1 %descriptor.owner.inside.2869, %descriptor.offset.inside.2870
  %descriptor.range.inside.2876 = and i1 %descriptor.owner.offset.valid.2874, %descriptor.extent.inside.2872
  %descriptor.range.valid.2875 = and i1 %descriptor.range.inside.2876, %descriptor.payload.inside.2873
  %descriptor.type.valid.2877 = icmp eq i32 12, 12
  %descriptor.valid.2878 = and i1 %descriptor.range.valid.2875, %descriptor.type.valid.2877
  br i1 %descriptor.valid.2878, label %descriptor.valid.2879, label %descriptor.invalid.2880
descriptor.invalid.2880:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2879:
  %descriptor.initialized.status.2881 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.2863, i32 %local.resolved.extent.2864)
  %helper.ok.2882 = icmp eq i32 %descriptor.initialized.status.2881, 0
  br i1 %helper.ok.2882, label %helper.continue.2883, label %frame.failure.0
helper.continue.2883:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %local.resolved.offset.2863, i32 20, i32 %local.resolved.payload.2865, i32 %local.resolved.owner.end.2866, i32 %local.resolved.extent.2864)
  %context.field.2884 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.2885 = load i32, ptr %context.field.2884, align 4
  %runtime.ok.2886 = icmp eq i32 %context.value.2885, 0
  br i1 %runtime.ok.2886, label %runtime.continue.2887, label %frame.failure.0
runtime.continue.2887:
  %context.field.2888 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2889 = load i32, ptr %context.field.2888, align 4
  %stack.sub.2892 = sub i32 %local.resolved.owner.end.2866, %local.resolved.offset.2863
  %descriptor.owner.inside.2890 = icmp ule i32 %local.resolved.owner.end.2866, %context.value.2889
  %descriptor.offset.inside.2891 = icmp ule i32 %local.resolved.offset.2863, %local.resolved.owner.end.2866
  %descriptor.extent.inside.2893 = icmp ule i32 %local.resolved.extent.2864, %stack.sub.2892
  %descriptor.payload.inside.2894 = icmp ule i32 %local.resolved.payload.2865, %local.resolved.extent.2864
  %descriptor.owner.offset.valid.2895 = and i1 %descriptor.owner.inside.2890, %descriptor.offset.inside.2891
  %descriptor.range.inside.2897 = and i1 %descriptor.owner.offset.valid.2895, %descriptor.extent.inside.2893
  %descriptor.range.valid.2896 = and i1 %descriptor.range.inside.2897, %descriptor.payload.inside.2894
  %descriptor.type.valid.2898 = icmp eq i32 12, 12
  %descriptor.valid.2899 = and i1 %descriptor.range.valid.2896, %descriptor.type.valid.2898
  br i1 %descriptor.valid.2899, label %descriptor.valid.2900, label %descriptor.invalid.2901
descriptor.invalid.2901:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2900:
  %descriptor.initialized.status.2902 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.2863, i32 %local.resolved.extent.2864)
  %helper.ok.2903 = icmp eq i32 %descriptor.initialized.status.2902, 0
  br i1 %helper.ok.2903, label %helper.continue.2904, label %frame.failure.0
helper.continue.2904:
  %local.is.active.2905 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.2905, label %local.descriptor.active.2906, label %local.descriptor.inactive.2907
local.descriptor.active.2906:
  %local.check.offset.2909 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.2910 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.2911 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.2912 = load i32, ptr %local.owner.end.6, align 4
  %context.field.2913 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2914 = load i32, ptr %context.field.2913, align 4
  %stack.sub.2917 = sub i32 %local.check.owner.end.2912, %local.check.offset.2909
  %descriptor.owner.inside.2915 = icmp ule i32 %local.check.owner.end.2912, %context.value.2914
  %descriptor.offset.inside.2916 = icmp ule i32 %local.check.offset.2909, %local.check.owner.end.2912
  %descriptor.extent.inside.2918 = icmp ule i32 %local.check.extent.2910, %stack.sub.2917
  %descriptor.payload.inside.2919 = icmp ule i32 %local.check.payload.2911, %local.check.extent.2910
  %descriptor.owner.offset.valid.2920 = and i1 %descriptor.owner.inside.2915, %descriptor.offset.inside.2916
  %descriptor.range.inside.2922 = and i1 %descriptor.owner.offset.valid.2920, %descriptor.extent.inside.2918
  %descriptor.range.valid.2921 = and i1 %descriptor.range.inside.2922, %descriptor.payload.inside.2919
  br i1 %descriptor.range.valid.2921, label %descriptor.valid.2923, label %descriptor.invalid.2924
descriptor.invalid.2924:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2923:
  %descriptor.initialized.status.2925 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2909, i32 %local.check.extent.2910)
  %helper.ok.2926 = icmp eq i32 %descriptor.initialized.status.2925, 0
  br i1 %helper.ok.2926, label %helper.continue.2927, label %frame.failure.0
helper.continue.2927:
  br label %local.descriptor.checked.2908
local.descriptor.inactive.2907:
  br label %local.descriptor.checked.2908
local.descriptor.checked.2908:
  %local.is.active.2928 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.2928, label %local.descriptor.active.2929, label %local.descriptor.inactive.2930
local.descriptor.active.2929:
  %local.check.offset.2932 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.2933 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.2934 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.2935 = load i32, ptr %local.owner.end.12, align 4
  %context.field.2936 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2937 = load i32, ptr %context.field.2936, align 4
  %stack.sub.2940 = sub i32 %local.check.owner.end.2935, %local.check.offset.2932
  %descriptor.owner.inside.2938 = icmp ule i32 %local.check.owner.end.2935, %context.value.2937
  %descriptor.offset.inside.2939 = icmp ule i32 %local.check.offset.2932, %local.check.owner.end.2935
  %descriptor.extent.inside.2941 = icmp ule i32 %local.check.extent.2933, %stack.sub.2940
  %descriptor.payload.inside.2942 = icmp ule i32 %local.check.payload.2934, %local.check.extent.2933
  %descriptor.owner.offset.valid.2943 = and i1 %descriptor.owner.inside.2938, %descriptor.offset.inside.2939
  %descriptor.range.inside.2945 = and i1 %descriptor.owner.offset.valid.2943, %descriptor.extent.inside.2941
  %descriptor.range.valid.2944 = and i1 %descriptor.range.inside.2945, %descriptor.payload.inside.2942
  br i1 %descriptor.range.valid.2944, label %descriptor.valid.2946, label %descriptor.invalid.2947
descriptor.invalid.2947:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2946:
  %descriptor.initialized.status.2948 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2932, i32 %local.check.extent.2933)
  %helper.ok.2949 = icmp eq i32 %descriptor.initialized.status.2948, 0
  br i1 %helper.ok.2949, label %helper.continue.2950, label %frame.failure.0
helper.continue.2950:
  br label %local.descriptor.checked.2931
local.descriptor.inactive.2930:
  br label %local.descriptor.checked.2931
local.descriptor.checked.2931:
  %local.is.active.2951 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.2951, label %local.descriptor.active.2952, label %local.descriptor.inactive.2953
local.descriptor.active.2952:
  %local.check.offset.2955 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.2956 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.2957 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.2958 = load i32, ptr %local.owner.end.18, align 4
  %context.field.2959 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2960 = load i32, ptr %context.field.2959, align 4
  %stack.sub.2963 = sub i32 %local.check.owner.end.2958, %local.check.offset.2955
  %descriptor.owner.inside.2961 = icmp ule i32 %local.check.owner.end.2958, %context.value.2960
  %descriptor.offset.inside.2962 = icmp ule i32 %local.check.offset.2955, %local.check.owner.end.2958
  %descriptor.extent.inside.2964 = icmp ule i32 %local.check.extent.2956, %stack.sub.2963
  %descriptor.payload.inside.2965 = icmp ule i32 %local.check.payload.2957, %local.check.extent.2956
  %descriptor.owner.offset.valid.2966 = and i1 %descriptor.owner.inside.2961, %descriptor.offset.inside.2962
  %descriptor.range.inside.2968 = and i1 %descriptor.owner.offset.valid.2966, %descriptor.extent.inside.2964
  %descriptor.range.valid.2967 = and i1 %descriptor.range.inside.2968, %descriptor.payload.inside.2965
  br i1 %descriptor.range.valid.2967, label %descriptor.valid.2969, label %descriptor.invalid.2970
descriptor.invalid.2970:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2969:
  %descriptor.initialized.status.2971 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2955, i32 %local.check.extent.2956)
  %helper.ok.2972 = icmp eq i32 %descriptor.initialized.status.2971, 0
  br i1 %helper.ok.2972, label %helper.continue.2973, label %frame.failure.0
helper.continue.2973:
  br label %local.descriptor.checked.2954
local.descriptor.inactive.2953:
  br label %local.descriptor.checked.2954
local.descriptor.checked.2954:
  %local.is.active.2974 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.2974, label %local.descriptor.active.2975, label %local.descriptor.inactive.2976
local.descriptor.active.2975:
  %local.check.offset.2978 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.2979 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.2980 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.2981 = load i32, ptr %local.owner.end.24, align 4
  %context.field.2982 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.2983 = load i32, ptr %context.field.2982, align 4
  %stack.sub.2986 = sub i32 %local.check.owner.end.2981, %local.check.offset.2978
  %descriptor.owner.inside.2984 = icmp ule i32 %local.check.owner.end.2981, %context.value.2983
  %descriptor.offset.inside.2985 = icmp ule i32 %local.check.offset.2978, %local.check.owner.end.2981
  %descriptor.extent.inside.2987 = icmp ule i32 %local.check.extent.2979, %stack.sub.2986
  %descriptor.payload.inside.2988 = icmp ule i32 %local.check.payload.2980, %local.check.extent.2979
  %descriptor.owner.offset.valid.2989 = and i1 %descriptor.owner.inside.2984, %descriptor.offset.inside.2985
  %descriptor.range.inside.2991 = and i1 %descriptor.owner.offset.valid.2989, %descriptor.extent.inside.2987
  %descriptor.range.valid.2990 = and i1 %descriptor.range.inside.2991, %descriptor.payload.inside.2988
  br i1 %descriptor.range.valid.2990, label %descriptor.valid.2992, label %descriptor.invalid.2993
descriptor.invalid.2993:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.2992:
  %descriptor.initialized.status.2994 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.2978, i32 %local.check.extent.2979)
  %helper.ok.2995 = icmp eq i32 %descriptor.initialized.status.2994, 0
  br i1 %helper.ok.2995, label %helper.continue.2996, label %frame.failure.0
helper.continue.2996:
  br label %local.descriptor.checked.2977
local.descriptor.inactive.2976:
  br label %local.descriptor.checked.2977
local.descriptor.checked.2977:
  %local.is.active.2997 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.2997, label %local.descriptor.active.2998, label %local.descriptor.inactive.2999
local.descriptor.active.2998:
  %local.check.offset.3001 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.3002 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.3003 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.3004 = load i32, ptr %local.owner.end.30, align 4
  %context.field.3005 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3006 = load i32, ptr %context.field.3005, align 4
  %stack.sub.3009 = sub i32 %local.check.owner.end.3004, %local.check.offset.3001
  %descriptor.owner.inside.3007 = icmp ule i32 %local.check.owner.end.3004, %context.value.3006
  %descriptor.offset.inside.3008 = icmp ule i32 %local.check.offset.3001, %local.check.owner.end.3004
  %descriptor.extent.inside.3010 = icmp ule i32 %local.check.extent.3002, %stack.sub.3009
  %descriptor.payload.inside.3011 = icmp ule i32 %local.check.payload.3003, %local.check.extent.3002
  %descriptor.owner.offset.valid.3012 = and i1 %descriptor.owner.inside.3007, %descriptor.offset.inside.3008
  %descriptor.range.inside.3014 = and i1 %descriptor.owner.offset.valid.3012, %descriptor.extent.inside.3010
  %descriptor.range.valid.3013 = and i1 %descriptor.range.inside.3014, %descriptor.payload.inside.3011
  br i1 %descriptor.range.valid.3013, label %descriptor.valid.3015, label %descriptor.invalid.3016
descriptor.invalid.3016:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3015:
  %descriptor.initialized.status.3017 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3001, i32 %local.check.extent.3002)
  %helper.ok.3018 = icmp eq i32 %descriptor.initialized.status.3017, 0
  br i1 %helper.ok.3018, label %helper.continue.3019, label %frame.failure.0
helper.continue.3019:
  br label %local.descriptor.checked.3000
local.descriptor.inactive.2999:
  br label %local.descriptor.checked.3000
local.descriptor.checked.3000:
  %local.is.active.3020 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.3020, label %local.descriptor.active.3021, label %local.descriptor.inactive.3022
local.descriptor.active.3021:
  %local.check.offset.3024 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.3025 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.3026 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.3027 = load i32, ptr %local.owner.end.36, align 4
  %context.field.3028 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3029 = load i32, ptr %context.field.3028, align 4
  %stack.sub.3032 = sub i32 %local.check.owner.end.3027, %local.check.offset.3024
  %descriptor.owner.inside.3030 = icmp ule i32 %local.check.owner.end.3027, %context.value.3029
  %descriptor.offset.inside.3031 = icmp ule i32 %local.check.offset.3024, %local.check.owner.end.3027
  %descriptor.extent.inside.3033 = icmp ule i32 %local.check.extent.3025, %stack.sub.3032
  %descriptor.payload.inside.3034 = icmp ule i32 %local.check.payload.3026, %local.check.extent.3025
  %descriptor.owner.offset.valid.3035 = and i1 %descriptor.owner.inside.3030, %descriptor.offset.inside.3031
  %descriptor.range.inside.3037 = and i1 %descriptor.owner.offset.valid.3035, %descriptor.extent.inside.3033
  %descriptor.range.valid.3036 = and i1 %descriptor.range.inside.3037, %descriptor.payload.inside.3034
  br i1 %descriptor.range.valid.3036, label %descriptor.valid.3038, label %descriptor.invalid.3039
descriptor.invalid.3039:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3038:
  %descriptor.initialized.status.3040 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3024, i32 %local.check.extent.3025)
  %helper.ok.3041 = icmp eq i32 %descriptor.initialized.status.3040, 0
  br i1 %helper.ok.3041, label %helper.continue.3042, label %frame.failure.0
helper.continue.3042:
  br label %local.descriptor.checked.3023
local.descriptor.inactive.3022:
  br label %local.descriptor.checked.3023
local.descriptor.checked.3023:
  %step.status.3043 = call i32 @al_owning_charge_step(ptr %ctx, i32 22)
  %helper.ok.3044 = icmp eq i32 %step.status.3043, 0
  br i1 %helper.ok.3044, label %helper.continue.3045, label %frame.failure.0
helper.continue.3045:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 12, i32 %local.resolved.offset.2863, i32 %local.resolved.extent.2864, i32 %local.resolved.payload.2865, i32 0, i32 0)
  %context.field.3046 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3047 = load i32, ptr %context.field.3046, align 4
  %runtime.ok.3048 = icmp eq i32 %context.value.3047, 0
  br i1 %runtime.ok.3048, label %runtime.continue.3049, label %frame.failure.0
runtime.continue.3049:
  %local.is.active.3050 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.3050, label %local.descriptor.active.3051, label %local.descriptor.inactive.3052
local.descriptor.active.3051:
  %local.check.offset.3054 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.3055 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.3056 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.3057 = load i32, ptr %local.owner.end.6, align 4
  %context.field.3058 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3059 = load i32, ptr %context.field.3058, align 4
  %stack.sub.3062 = sub i32 %local.check.owner.end.3057, %local.check.offset.3054
  %descriptor.owner.inside.3060 = icmp ule i32 %local.check.owner.end.3057, %context.value.3059
  %descriptor.offset.inside.3061 = icmp ule i32 %local.check.offset.3054, %local.check.owner.end.3057
  %descriptor.extent.inside.3063 = icmp ule i32 %local.check.extent.3055, %stack.sub.3062
  %descriptor.payload.inside.3064 = icmp ule i32 %local.check.payload.3056, %local.check.extent.3055
  %descriptor.owner.offset.valid.3065 = and i1 %descriptor.owner.inside.3060, %descriptor.offset.inside.3061
  %descriptor.range.inside.3067 = and i1 %descriptor.owner.offset.valid.3065, %descriptor.extent.inside.3063
  %descriptor.range.valid.3066 = and i1 %descriptor.range.inside.3067, %descriptor.payload.inside.3064
  br i1 %descriptor.range.valid.3066, label %descriptor.valid.3068, label %descriptor.invalid.3069
descriptor.invalid.3069:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3068:
  %descriptor.initialized.status.3070 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3054, i32 %local.check.extent.3055)
  %helper.ok.3071 = icmp eq i32 %descriptor.initialized.status.3070, 0
  br i1 %helper.ok.3071, label %helper.continue.3072, label %frame.failure.0
helper.continue.3072:
  br label %local.descriptor.checked.3053
local.descriptor.inactive.3052:
  br label %local.descriptor.checked.3053
local.descriptor.checked.3053:
  %local.is.active.3073 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.3073, label %local.descriptor.active.3074, label %local.descriptor.inactive.3075
local.descriptor.active.3074:
  %local.check.offset.3077 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.3078 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.3079 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.3080 = load i32, ptr %local.owner.end.12, align 4
  %context.field.3081 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3082 = load i32, ptr %context.field.3081, align 4
  %stack.sub.3085 = sub i32 %local.check.owner.end.3080, %local.check.offset.3077
  %descriptor.owner.inside.3083 = icmp ule i32 %local.check.owner.end.3080, %context.value.3082
  %descriptor.offset.inside.3084 = icmp ule i32 %local.check.offset.3077, %local.check.owner.end.3080
  %descriptor.extent.inside.3086 = icmp ule i32 %local.check.extent.3078, %stack.sub.3085
  %descriptor.payload.inside.3087 = icmp ule i32 %local.check.payload.3079, %local.check.extent.3078
  %descriptor.owner.offset.valid.3088 = and i1 %descriptor.owner.inside.3083, %descriptor.offset.inside.3084
  %descriptor.range.inside.3090 = and i1 %descriptor.owner.offset.valid.3088, %descriptor.extent.inside.3086
  %descriptor.range.valid.3089 = and i1 %descriptor.range.inside.3090, %descriptor.payload.inside.3087
  br i1 %descriptor.range.valid.3089, label %descriptor.valid.3091, label %descriptor.invalid.3092
descriptor.invalid.3092:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3091:
  %descriptor.initialized.status.3093 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3077, i32 %local.check.extent.3078)
  %helper.ok.3094 = icmp eq i32 %descriptor.initialized.status.3093, 0
  br i1 %helper.ok.3094, label %helper.continue.3095, label %frame.failure.0
helper.continue.3095:
  br label %local.descriptor.checked.3076
local.descriptor.inactive.3075:
  br label %local.descriptor.checked.3076
local.descriptor.checked.3076:
  %local.is.active.3096 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.3096, label %local.descriptor.active.3097, label %local.descriptor.inactive.3098
local.descriptor.active.3097:
  %local.check.offset.3100 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.3101 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.3102 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.3103 = load i32, ptr %local.owner.end.18, align 4
  %context.field.3104 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3105 = load i32, ptr %context.field.3104, align 4
  %stack.sub.3108 = sub i32 %local.check.owner.end.3103, %local.check.offset.3100
  %descriptor.owner.inside.3106 = icmp ule i32 %local.check.owner.end.3103, %context.value.3105
  %descriptor.offset.inside.3107 = icmp ule i32 %local.check.offset.3100, %local.check.owner.end.3103
  %descriptor.extent.inside.3109 = icmp ule i32 %local.check.extent.3101, %stack.sub.3108
  %descriptor.payload.inside.3110 = icmp ule i32 %local.check.payload.3102, %local.check.extent.3101
  %descriptor.owner.offset.valid.3111 = and i1 %descriptor.owner.inside.3106, %descriptor.offset.inside.3107
  %descriptor.range.inside.3113 = and i1 %descriptor.owner.offset.valid.3111, %descriptor.extent.inside.3109
  %descriptor.range.valid.3112 = and i1 %descriptor.range.inside.3113, %descriptor.payload.inside.3110
  br i1 %descriptor.range.valid.3112, label %descriptor.valid.3114, label %descriptor.invalid.3115
descriptor.invalid.3115:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3114:
  %descriptor.initialized.status.3116 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3100, i32 %local.check.extent.3101)
  %helper.ok.3117 = icmp eq i32 %descriptor.initialized.status.3116, 0
  br i1 %helper.ok.3117, label %helper.continue.3118, label %frame.failure.0
helper.continue.3118:
  br label %local.descriptor.checked.3099
local.descriptor.inactive.3098:
  br label %local.descriptor.checked.3099
local.descriptor.checked.3099:
  %local.is.active.3119 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.3119, label %local.descriptor.active.3120, label %local.descriptor.inactive.3121
local.descriptor.active.3120:
  %local.check.offset.3123 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.3124 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.3125 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.3126 = load i32, ptr %local.owner.end.24, align 4
  %context.field.3127 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3128 = load i32, ptr %context.field.3127, align 4
  %stack.sub.3131 = sub i32 %local.check.owner.end.3126, %local.check.offset.3123
  %descriptor.owner.inside.3129 = icmp ule i32 %local.check.owner.end.3126, %context.value.3128
  %descriptor.offset.inside.3130 = icmp ule i32 %local.check.offset.3123, %local.check.owner.end.3126
  %descriptor.extent.inside.3132 = icmp ule i32 %local.check.extent.3124, %stack.sub.3131
  %descriptor.payload.inside.3133 = icmp ule i32 %local.check.payload.3125, %local.check.extent.3124
  %descriptor.owner.offset.valid.3134 = and i1 %descriptor.owner.inside.3129, %descriptor.offset.inside.3130
  %descriptor.range.inside.3136 = and i1 %descriptor.owner.offset.valid.3134, %descriptor.extent.inside.3132
  %descriptor.range.valid.3135 = and i1 %descriptor.range.inside.3136, %descriptor.payload.inside.3133
  br i1 %descriptor.range.valid.3135, label %descriptor.valid.3137, label %descriptor.invalid.3138
descriptor.invalid.3138:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3137:
  %descriptor.initialized.status.3139 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3123, i32 %local.check.extent.3124)
  %helper.ok.3140 = icmp eq i32 %descriptor.initialized.status.3139, 0
  br i1 %helper.ok.3140, label %helper.continue.3141, label %frame.failure.0
helper.continue.3141:
  br label %local.descriptor.checked.3122
local.descriptor.inactive.3121:
  br label %local.descriptor.checked.3122
local.descriptor.checked.3122:
  %local.is.active.3142 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.3142, label %local.descriptor.active.3143, label %local.descriptor.inactive.3144
local.descriptor.active.3143:
  %local.check.offset.3146 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.3147 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.3148 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.3149 = load i32, ptr %local.owner.end.30, align 4
  %context.field.3150 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3151 = load i32, ptr %context.field.3150, align 4
  %stack.sub.3154 = sub i32 %local.check.owner.end.3149, %local.check.offset.3146
  %descriptor.owner.inside.3152 = icmp ule i32 %local.check.owner.end.3149, %context.value.3151
  %descriptor.offset.inside.3153 = icmp ule i32 %local.check.offset.3146, %local.check.owner.end.3149
  %descriptor.extent.inside.3155 = icmp ule i32 %local.check.extent.3147, %stack.sub.3154
  %descriptor.payload.inside.3156 = icmp ule i32 %local.check.payload.3148, %local.check.extent.3147
  %descriptor.owner.offset.valid.3157 = and i1 %descriptor.owner.inside.3152, %descriptor.offset.inside.3153
  %descriptor.range.inside.3159 = and i1 %descriptor.owner.offset.valid.3157, %descriptor.extent.inside.3155
  %descriptor.range.valid.3158 = and i1 %descriptor.range.inside.3159, %descriptor.payload.inside.3156
  br i1 %descriptor.range.valid.3158, label %descriptor.valid.3160, label %descriptor.invalid.3161
descriptor.invalid.3161:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3160:
  %descriptor.initialized.status.3162 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3146, i32 %local.check.extent.3147)
  %helper.ok.3163 = icmp eq i32 %descriptor.initialized.status.3162, 0
  br i1 %helper.ok.3163, label %helper.continue.3164, label %frame.failure.0
helper.continue.3164:
  br label %local.descriptor.checked.3145
local.descriptor.inactive.3144:
  br label %local.descriptor.checked.3145
local.descriptor.checked.3145:
  %local.is.active.3165 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.3165, label %local.descriptor.active.3166, label %local.descriptor.inactive.3167
local.descriptor.active.3166:
  %local.check.offset.3169 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.3170 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.3171 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.3172 = load i32, ptr %local.owner.end.36, align 4
  %context.field.3173 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3174 = load i32, ptr %context.field.3173, align 4
  %stack.sub.3177 = sub i32 %local.check.owner.end.3172, %local.check.offset.3169
  %descriptor.owner.inside.3175 = icmp ule i32 %local.check.owner.end.3172, %context.value.3174
  %descriptor.offset.inside.3176 = icmp ule i32 %local.check.offset.3169, %local.check.owner.end.3172
  %descriptor.extent.inside.3178 = icmp ule i32 %local.check.extent.3170, %stack.sub.3177
  %descriptor.payload.inside.3179 = icmp ule i32 %local.check.payload.3171, %local.check.extent.3170
  %descriptor.owner.offset.valid.3180 = and i1 %descriptor.owner.inside.3175, %descriptor.offset.inside.3176
  %descriptor.range.inside.3182 = and i1 %descriptor.owner.offset.valid.3180, %descriptor.extent.inside.3178
  %descriptor.range.valid.3181 = and i1 %descriptor.range.inside.3182, %descriptor.payload.inside.3179
  br i1 %descriptor.range.valid.3181, label %descriptor.valid.3183, label %descriptor.invalid.3184
descriptor.invalid.3184:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3183:
  %descriptor.initialized.status.3185 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3169, i32 %local.check.extent.3170)
  %helper.ok.3186 = icmp eq i32 %descriptor.initialized.status.3185, 0
  br i1 %helper.ok.3186, label %helper.continue.3187, label %frame.failure.0
helper.continue.3187:
  br label %local.descriptor.checked.3168
local.descriptor.inactive.3167:
  br label %local.descriptor.checked.3168
local.descriptor.checked.3168:
  %step.status.3188 = call i32 @al_owning_charge_step(ptr %ctx, i32 23)
  %helper.ok.3189 = icmp eq i32 %step.status.3188, 0
  br i1 %helper.ok.3189, label %helper.continue.3190, label %frame.failure.0
helper.continue.3190:
  %local.resolved.offset.3191 = load i32, ptr %local.offset.15, align 4
  %local.resolved.extent.3192 = load i32, ptr %local.extent.16, align 4
  %local.resolved.payload.3193 = load i32, ptr %local.payload.17, align 4
  %local.resolved.owner.end.3194 = load i32, ptr %local.owner.end.18, align 4
  %context.field.3195 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3196 = load i32, ptr %context.field.3195, align 4
  %stack.sub.3199 = sub i32 %local.resolved.owner.end.3194, %local.resolved.offset.3191
  %descriptor.owner.inside.3197 = icmp ule i32 %local.resolved.owner.end.3194, %context.value.3196
  %descriptor.offset.inside.3198 = icmp ule i32 %local.resolved.offset.3191, %local.resolved.owner.end.3194
  %descriptor.extent.inside.3200 = icmp ule i32 %local.resolved.extent.3192, %stack.sub.3199
  %descriptor.payload.inside.3201 = icmp ule i32 %local.resolved.payload.3193, %local.resolved.extent.3192
  %descriptor.owner.offset.valid.3202 = and i1 %descriptor.owner.inside.3197, %descriptor.offset.inside.3198
  %descriptor.range.inside.3204 = and i1 %descriptor.owner.offset.valid.3202, %descriptor.extent.inside.3200
  %descriptor.range.valid.3203 = and i1 %descriptor.range.inside.3204, %descriptor.payload.inside.3201
  %descriptor.type.valid.3205 = icmp eq i32 12, 12
  %descriptor.valid.3206 = and i1 %descriptor.range.valid.3203, %descriptor.type.valid.3205
  br i1 %descriptor.valid.3206, label %descriptor.valid.3207, label %descriptor.invalid.3208
descriptor.invalid.3208:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3207:
  %descriptor.initialized.status.3209 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.3191, i32 %local.resolved.extent.3192)
  %helper.ok.3210 = icmp eq i32 %descriptor.initialized.status.3209, 0
  br i1 %helper.ok.3210, label %helper.continue.3211, label %frame.failure.0
helper.continue.3211:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %local.resolved.offset.3191, i32 20, i32 %local.resolved.payload.3193, i32 %local.resolved.owner.end.3194, i32 %local.resolved.extent.3192)
  %context.field.3212 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3213 = load i32, ptr %context.field.3212, align 4
  %runtime.ok.3214 = icmp eq i32 %context.value.3213, 0
  br i1 %runtime.ok.3214, label %runtime.continue.3215, label %frame.failure.0
runtime.continue.3215:
  %context.field.3216 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3217 = load i32, ptr %context.field.3216, align 4
  %stack.sub.3220 = sub i32 %local.resolved.owner.end.3194, %local.resolved.offset.3191
  %descriptor.owner.inside.3218 = icmp ule i32 %local.resolved.owner.end.3194, %context.value.3217
  %descriptor.offset.inside.3219 = icmp ule i32 %local.resolved.offset.3191, %local.resolved.owner.end.3194
  %descriptor.extent.inside.3221 = icmp ule i32 %local.resolved.extent.3192, %stack.sub.3220
  %descriptor.payload.inside.3222 = icmp ule i32 %local.resolved.payload.3193, %local.resolved.extent.3192
  %descriptor.owner.offset.valid.3223 = and i1 %descriptor.owner.inside.3218, %descriptor.offset.inside.3219
  %descriptor.range.inside.3225 = and i1 %descriptor.owner.offset.valid.3223, %descriptor.extent.inside.3221
  %descriptor.range.valid.3224 = and i1 %descriptor.range.inside.3225, %descriptor.payload.inside.3222
  %descriptor.type.valid.3226 = icmp eq i32 12, 12
  %descriptor.valid.3227 = and i1 %descriptor.range.valid.3224, %descriptor.type.valid.3226
  br i1 %descriptor.valid.3227, label %descriptor.valid.3228, label %descriptor.invalid.3229
descriptor.invalid.3229:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3228:
  %descriptor.initialized.status.3230 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.3191, i32 %local.resolved.extent.3192)
  %helper.ok.3231 = icmp eq i32 %descriptor.initialized.status.3230, 0
  br i1 %helper.ok.3231, label %helper.continue.3232, label %frame.failure.0
helper.continue.3232:
  %local.is.active.3233 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.3233, label %local.descriptor.active.3234, label %local.descriptor.inactive.3235
local.descriptor.active.3234:
  %local.check.offset.3237 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.3238 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.3239 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.3240 = load i32, ptr %local.owner.end.6, align 4
  %context.field.3241 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3242 = load i32, ptr %context.field.3241, align 4
  %stack.sub.3245 = sub i32 %local.check.owner.end.3240, %local.check.offset.3237
  %descriptor.owner.inside.3243 = icmp ule i32 %local.check.owner.end.3240, %context.value.3242
  %descriptor.offset.inside.3244 = icmp ule i32 %local.check.offset.3237, %local.check.owner.end.3240
  %descriptor.extent.inside.3246 = icmp ule i32 %local.check.extent.3238, %stack.sub.3245
  %descriptor.payload.inside.3247 = icmp ule i32 %local.check.payload.3239, %local.check.extent.3238
  %descriptor.owner.offset.valid.3248 = and i1 %descriptor.owner.inside.3243, %descriptor.offset.inside.3244
  %descriptor.range.inside.3250 = and i1 %descriptor.owner.offset.valid.3248, %descriptor.extent.inside.3246
  %descriptor.range.valid.3249 = and i1 %descriptor.range.inside.3250, %descriptor.payload.inside.3247
  br i1 %descriptor.range.valid.3249, label %descriptor.valid.3251, label %descriptor.invalid.3252
descriptor.invalid.3252:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3251:
  %descriptor.initialized.status.3253 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3237, i32 %local.check.extent.3238)
  %helper.ok.3254 = icmp eq i32 %descriptor.initialized.status.3253, 0
  br i1 %helper.ok.3254, label %helper.continue.3255, label %frame.failure.0
helper.continue.3255:
  br label %local.descriptor.checked.3236
local.descriptor.inactive.3235:
  br label %local.descriptor.checked.3236
local.descriptor.checked.3236:
  %local.is.active.3256 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.3256, label %local.descriptor.active.3257, label %local.descriptor.inactive.3258
local.descriptor.active.3257:
  %local.check.offset.3260 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.3261 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.3262 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.3263 = load i32, ptr %local.owner.end.12, align 4
  %context.field.3264 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3265 = load i32, ptr %context.field.3264, align 4
  %stack.sub.3268 = sub i32 %local.check.owner.end.3263, %local.check.offset.3260
  %descriptor.owner.inside.3266 = icmp ule i32 %local.check.owner.end.3263, %context.value.3265
  %descriptor.offset.inside.3267 = icmp ule i32 %local.check.offset.3260, %local.check.owner.end.3263
  %descriptor.extent.inside.3269 = icmp ule i32 %local.check.extent.3261, %stack.sub.3268
  %descriptor.payload.inside.3270 = icmp ule i32 %local.check.payload.3262, %local.check.extent.3261
  %descriptor.owner.offset.valid.3271 = and i1 %descriptor.owner.inside.3266, %descriptor.offset.inside.3267
  %descriptor.range.inside.3273 = and i1 %descriptor.owner.offset.valid.3271, %descriptor.extent.inside.3269
  %descriptor.range.valid.3272 = and i1 %descriptor.range.inside.3273, %descriptor.payload.inside.3270
  br i1 %descriptor.range.valid.3272, label %descriptor.valid.3274, label %descriptor.invalid.3275
descriptor.invalid.3275:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3274:
  %descriptor.initialized.status.3276 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3260, i32 %local.check.extent.3261)
  %helper.ok.3277 = icmp eq i32 %descriptor.initialized.status.3276, 0
  br i1 %helper.ok.3277, label %helper.continue.3278, label %frame.failure.0
helper.continue.3278:
  br label %local.descriptor.checked.3259
local.descriptor.inactive.3258:
  br label %local.descriptor.checked.3259
local.descriptor.checked.3259:
  %local.is.active.3279 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.3279, label %local.descriptor.active.3280, label %local.descriptor.inactive.3281
local.descriptor.active.3280:
  %local.check.offset.3283 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.3284 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.3285 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.3286 = load i32, ptr %local.owner.end.18, align 4
  %context.field.3287 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3288 = load i32, ptr %context.field.3287, align 4
  %stack.sub.3291 = sub i32 %local.check.owner.end.3286, %local.check.offset.3283
  %descriptor.owner.inside.3289 = icmp ule i32 %local.check.owner.end.3286, %context.value.3288
  %descriptor.offset.inside.3290 = icmp ule i32 %local.check.offset.3283, %local.check.owner.end.3286
  %descriptor.extent.inside.3292 = icmp ule i32 %local.check.extent.3284, %stack.sub.3291
  %descriptor.payload.inside.3293 = icmp ule i32 %local.check.payload.3285, %local.check.extent.3284
  %descriptor.owner.offset.valid.3294 = and i1 %descriptor.owner.inside.3289, %descriptor.offset.inside.3290
  %descriptor.range.inside.3296 = and i1 %descriptor.owner.offset.valid.3294, %descriptor.extent.inside.3292
  %descriptor.range.valid.3295 = and i1 %descriptor.range.inside.3296, %descriptor.payload.inside.3293
  br i1 %descriptor.range.valid.3295, label %descriptor.valid.3297, label %descriptor.invalid.3298
descriptor.invalid.3298:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3297:
  %descriptor.initialized.status.3299 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3283, i32 %local.check.extent.3284)
  %helper.ok.3300 = icmp eq i32 %descriptor.initialized.status.3299, 0
  br i1 %helper.ok.3300, label %helper.continue.3301, label %frame.failure.0
helper.continue.3301:
  br label %local.descriptor.checked.3282
local.descriptor.inactive.3281:
  br label %local.descriptor.checked.3282
local.descriptor.checked.3282:
  %local.is.active.3302 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.3302, label %local.descriptor.active.3303, label %local.descriptor.inactive.3304
local.descriptor.active.3303:
  %local.check.offset.3306 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.3307 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.3308 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.3309 = load i32, ptr %local.owner.end.24, align 4
  %context.field.3310 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3311 = load i32, ptr %context.field.3310, align 4
  %stack.sub.3314 = sub i32 %local.check.owner.end.3309, %local.check.offset.3306
  %descriptor.owner.inside.3312 = icmp ule i32 %local.check.owner.end.3309, %context.value.3311
  %descriptor.offset.inside.3313 = icmp ule i32 %local.check.offset.3306, %local.check.owner.end.3309
  %descriptor.extent.inside.3315 = icmp ule i32 %local.check.extent.3307, %stack.sub.3314
  %descriptor.payload.inside.3316 = icmp ule i32 %local.check.payload.3308, %local.check.extent.3307
  %descriptor.owner.offset.valid.3317 = and i1 %descriptor.owner.inside.3312, %descriptor.offset.inside.3313
  %descriptor.range.inside.3319 = and i1 %descriptor.owner.offset.valid.3317, %descriptor.extent.inside.3315
  %descriptor.range.valid.3318 = and i1 %descriptor.range.inside.3319, %descriptor.payload.inside.3316
  br i1 %descriptor.range.valid.3318, label %descriptor.valid.3320, label %descriptor.invalid.3321
descriptor.invalid.3321:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3320:
  %descriptor.initialized.status.3322 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3306, i32 %local.check.extent.3307)
  %helper.ok.3323 = icmp eq i32 %descriptor.initialized.status.3322, 0
  br i1 %helper.ok.3323, label %helper.continue.3324, label %frame.failure.0
helper.continue.3324:
  br label %local.descriptor.checked.3305
local.descriptor.inactive.3304:
  br label %local.descriptor.checked.3305
local.descriptor.checked.3305:
  %local.is.active.3325 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.3325, label %local.descriptor.active.3326, label %local.descriptor.inactive.3327
local.descriptor.active.3326:
  %local.check.offset.3329 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.3330 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.3331 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.3332 = load i32, ptr %local.owner.end.30, align 4
  %context.field.3333 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3334 = load i32, ptr %context.field.3333, align 4
  %stack.sub.3337 = sub i32 %local.check.owner.end.3332, %local.check.offset.3329
  %descriptor.owner.inside.3335 = icmp ule i32 %local.check.owner.end.3332, %context.value.3334
  %descriptor.offset.inside.3336 = icmp ule i32 %local.check.offset.3329, %local.check.owner.end.3332
  %descriptor.extent.inside.3338 = icmp ule i32 %local.check.extent.3330, %stack.sub.3337
  %descriptor.payload.inside.3339 = icmp ule i32 %local.check.payload.3331, %local.check.extent.3330
  %descriptor.owner.offset.valid.3340 = and i1 %descriptor.owner.inside.3335, %descriptor.offset.inside.3336
  %descriptor.range.inside.3342 = and i1 %descriptor.owner.offset.valid.3340, %descriptor.extent.inside.3338
  %descriptor.range.valid.3341 = and i1 %descriptor.range.inside.3342, %descriptor.payload.inside.3339
  br i1 %descriptor.range.valid.3341, label %descriptor.valid.3343, label %descriptor.invalid.3344
descriptor.invalid.3344:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3343:
  %descriptor.initialized.status.3345 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3329, i32 %local.check.extent.3330)
  %helper.ok.3346 = icmp eq i32 %descriptor.initialized.status.3345, 0
  br i1 %helper.ok.3346, label %helper.continue.3347, label %frame.failure.0
helper.continue.3347:
  br label %local.descriptor.checked.3328
local.descriptor.inactive.3327:
  br label %local.descriptor.checked.3328
local.descriptor.checked.3328:
  %local.is.active.3348 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.3348, label %local.descriptor.active.3349, label %local.descriptor.inactive.3350
local.descriptor.active.3349:
  %local.check.offset.3352 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.3353 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.3354 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.3355 = load i32, ptr %local.owner.end.36, align 4
  %context.field.3356 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3357 = load i32, ptr %context.field.3356, align 4
  %stack.sub.3360 = sub i32 %local.check.owner.end.3355, %local.check.offset.3352
  %descriptor.owner.inside.3358 = icmp ule i32 %local.check.owner.end.3355, %context.value.3357
  %descriptor.offset.inside.3359 = icmp ule i32 %local.check.offset.3352, %local.check.owner.end.3355
  %descriptor.extent.inside.3361 = icmp ule i32 %local.check.extent.3353, %stack.sub.3360
  %descriptor.payload.inside.3362 = icmp ule i32 %local.check.payload.3354, %local.check.extent.3353
  %descriptor.owner.offset.valid.3363 = and i1 %descriptor.owner.inside.3358, %descriptor.offset.inside.3359
  %descriptor.range.inside.3365 = and i1 %descriptor.owner.offset.valid.3363, %descriptor.extent.inside.3361
  %descriptor.range.valid.3364 = and i1 %descriptor.range.inside.3365, %descriptor.payload.inside.3362
  br i1 %descriptor.range.valid.3364, label %descriptor.valid.3366, label %descriptor.invalid.3367
descriptor.invalid.3367:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3366:
  %descriptor.initialized.status.3368 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3352, i32 %local.check.extent.3353)
  %helper.ok.3369 = icmp eq i32 %descriptor.initialized.status.3368, 0
  br i1 %helper.ok.3369, label %helper.continue.3370, label %frame.failure.0
helper.continue.3370:
  br label %local.descriptor.checked.3351
local.descriptor.inactive.3350:
  br label %local.descriptor.checked.3351
local.descriptor.checked.3351:
  %step.status.3371 = call i32 @al_owning_charge_step(ptr %ctx, i32 24)
  %helper.ok.3372 = icmp eq i32 %step.status.3371, 0
  br i1 %helper.ok.3372, label %helper.continue.3373, label %frame.failure.0
helper.continue.3373:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 12, i32 %local.resolved.offset.3191, i32 %local.resolved.extent.3192, i32 %local.resolved.payload.3193, i32 0, i32 0)
  %context.field.3374 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3375 = load i32, ptr %context.field.3374, align 4
  %runtime.ok.3376 = icmp eq i32 %context.value.3375, 0
  br i1 %runtime.ok.3376, label %runtime.continue.3377, label %frame.failure.0
runtime.continue.3377:
  %local.is.active.3378 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.3378, label %local.descriptor.active.3379, label %local.descriptor.inactive.3380
local.descriptor.active.3379:
  %local.check.offset.3382 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.3383 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.3384 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.3385 = load i32, ptr %local.owner.end.6, align 4
  %context.field.3386 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3387 = load i32, ptr %context.field.3386, align 4
  %stack.sub.3390 = sub i32 %local.check.owner.end.3385, %local.check.offset.3382
  %descriptor.owner.inside.3388 = icmp ule i32 %local.check.owner.end.3385, %context.value.3387
  %descriptor.offset.inside.3389 = icmp ule i32 %local.check.offset.3382, %local.check.owner.end.3385
  %descriptor.extent.inside.3391 = icmp ule i32 %local.check.extent.3383, %stack.sub.3390
  %descriptor.payload.inside.3392 = icmp ule i32 %local.check.payload.3384, %local.check.extent.3383
  %descriptor.owner.offset.valid.3393 = and i1 %descriptor.owner.inside.3388, %descriptor.offset.inside.3389
  %descriptor.range.inside.3395 = and i1 %descriptor.owner.offset.valid.3393, %descriptor.extent.inside.3391
  %descriptor.range.valid.3394 = and i1 %descriptor.range.inside.3395, %descriptor.payload.inside.3392
  br i1 %descriptor.range.valid.3394, label %descriptor.valid.3396, label %descriptor.invalid.3397
descriptor.invalid.3397:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3396:
  %descriptor.initialized.status.3398 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3382, i32 %local.check.extent.3383)
  %helper.ok.3399 = icmp eq i32 %descriptor.initialized.status.3398, 0
  br i1 %helper.ok.3399, label %helper.continue.3400, label %frame.failure.0
helper.continue.3400:
  br label %local.descriptor.checked.3381
local.descriptor.inactive.3380:
  br label %local.descriptor.checked.3381
local.descriptor.checked.3381:
  %local.is.active.3401 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.3401, label %local.descriptor.active.3402, label %local.descriptor.inactive.3403
local.descriptor.active.3402:
  %local.check.offset.3405 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.3406 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.3407 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.3408 = load i32, ptr %local.owner.end.12, align 4
  %context.field.3409 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3410 = load i32, ptr %context.field.3409, align 4
  %stack.sub.3413 = sub i32 %local.check.owner.end.3408, %local.check.offset.3405
  %descriptor.owner.inside.3411 = icmp ule i32 %local.check.owner.end.3408, %context.value.3410
  %descriptor.offset.inside.3412 = icmp ule i32 %local.check.offset.3405, %local.check.owner.end.3408
  %descriptor.extent.inside.3414 = icmp ule i32 %local.check.extent.3406, %stack.sub.3413
  %descriptor.payload.inside.3415 = icmp ule i32 %local.check.payload.3407, %local.check.extent.3406
  %descriptor.owner.offset.valid.3416 = and i1 %descriptor.owner.inside.3411, %descriptor.offset.inside.3412
  %descriptor.range.inside.3418 = and i1 %descriptor.owner.offset.valid.3416, %descriptor.extent.inside.3414
  %descriptor.range.valid.3417 = and i1 %descriptor.range.inside.3418, %descriptor.payload.inside.3415
  br i1 %descriptor.range.valid.3417, label %descriptor.valid.3419, label %descriptor.invalid.3420
descriptor.invalid.3420:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3419:
  %descriptor.initialized.status.3421 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3405, i32 %local.check.extent.3406)
  %helper.ok.3422 = icmp eq i32 %descriptor.initialized.status.3421, 0
  br i1 %helper.ok.3422, label %helper.continue.3423, label %frame.failure.0
helper.continue.3423:
  br label %local.descriptor.checked.3404
local.descriptor.inactive.3403:
  br label %local.descriptor.checked.3404
local.descriptor.checked.3404:
  %local.is.active.3424 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.3424, label %local.descriptor.active.3425, label %local.descriptor.inactive.3426
local.descriptor.active.3425:
  %local.check.offset.3428 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.3429 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.3430 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.3431 = load i32, ptr %local.owner.end.18, align 4
  %context.field.3432 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3433 = load i32, ptr %context.field.3432, align 4
  %stack.sub.3436 = sub i32 %local.check.owner.end.3431, %local.check.offset.3428
  %descriptor.owner.inside.3434 = icmp ule i32 %local.check.owner.end.3431, %context.value.3433
  %descriptor.offset.inside.3435 = icmp ule i32 %local.check.offset.3428, %local.check.owner.end.3431
  %descriptor.extent.inside.3437 = icmp ule i32 %local.check.extent.3429, %stack.sub.3436
  %descriptor.payload.inside.3438 = icmp ule i32 %local.check.payload.3430, %local.check.extent.3429
  %descriptor.owner.offset.valid.3439 = and i1 %descriptor.owner.inside.3434, %descriptor.offset.inside.3435
  %descriptor.range.inside.3441 = and i1 %descriptor.owner.offset.valid.3439, %descriptor.extent.inside.3437
  %descriptor.range.valid.3440 = and i1 %descriptor.range.inside.3441, %descriptor.payload.inside.3438
  br i1 %descriptor.range.valid.3440, label %descriptor.valid.3442, label %descriptor.invalid.3443
descriptor.invalid.3443:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3442:
  %descriptor.initialized.status.3444 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3428, i32 %local.check.extent.3429)
  %helper.ok.3445 = icmp eq i32 %descriptor.initialized.status.3444, 0
  br i1 %helper.ok.3445, label %helper.continue.3446, label %frame.failure.0
helper.continue.3446:
  br label %local.descriptor.checked.3427
local.descriptor.inactive.3426:
  br label %local.descriptor.checked.3427
local.descriptor.checked.3427:
  %local.is.active.3447 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.3447, label %local.descriptor.active.3448, label %local.descriptor.inactive.3449
local.descriptor.active.3448:
  %local.check.offset.3451 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.3452 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.3453 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.3454 = load i32, ptr %local.owner.end.24, align 4
  %context.field.3455 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3456 = load i32, ptr %context.field.3455, align 4
  %stack.sub.3459 = sub i32 %local.check.owner.end.3454, %local.check.offset.3451
  %descriptor.owner.inside.3457 = icmp ule i32 %local.check.owner.end.3454, %context.value.3456
  %descriptor.offset.inside.3458 = icmp ule i32 %local.check.offset.3451, %local.check.owner.end.3454
  %descriptor.extent.inside.3460 = icmp ule i32 %local.check.extent.3452, %stack.sub.3459
  %descriptor.payload.inside.3461 = icmp ule i32 %local.check.payload.3453, %local.check.extent.3452
  %descriptor.owner.offset.valid.3462 = and i1 %descriptor.owner.inside.3457, %descriptor.offset.inside.3458
  %descriptor.range.inside.3464 = and i1 %descriptor.owner.offset.valid.3462, %descriptor.extent.inside.3460
  %descriptor.range.valid.3463 = and i1 %descriptor.range.inside.3464, %descriptor.payload.inside.3461
  br i1 %descriptor.range.valid.3463, label %descriptor.valid.3465, label %descriptor.invalid.3466
descriptor.invalid.3466:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3465:
  %descriptor.initialized.status.3467 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3451, i32 %local.check.extent.3452)
  %helper.ok.3468 = icmp eq i32 %descriptor.initialized.status.3467, 0
  br i1 %helper.ok.3468, label %helper.continue.3469, label %frame.failure.0
helper.continue.3469:
  br label %local.descriptor.checked.3450
local.descriptor.inactive.3449:
  br label %local.descriptor.checked.3450
local.descriptor.checked.3450:
  %local.is.active.3470 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.3470, label %local.descriptor.active.3471, label %local.descriptor.inactive.3472
local.descriptor.active.3471:
  %local.check.offset.3474 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.3475 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.3476 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.3477 = load i32, ptr %local.owner.end.30, align 4
  %context.field.3478 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3479 = load i32, ptr %context.field.3478, align 4
  %stack.sub.3482 = sub i32 %local.check.owner.end.3477, %local.check.offset.3474
  %descriptor.owner.inside.3480 = icmp ule i32 %local.check.owner.end.3477, %context.value.3479
  %descriptor.offset.inside.3481 = icmp ule i32 %local.check.offset.3474, %local.check.owner.end.3477
  %descriptor.extent.inside.3483 = icmp ule i32 %local.check.extent.3475, %stack.sub.3482
  %descriptor.payload.inside.3484 = icmp ule i32 %local.check.payload.3476, %local.check.extent.3475
  %descriptor.owner.offset.valid.3485 = and i1 %descriptor.owner.inside.3480, %descriptor.offset.inside.3481
  %descriptor.range.inside.3487 = and i1 %descriptor.owner.offset.valid.3485, %descriptor.extent.inside.3483
  %descriptor.range.valid.3486 = and i1 %descriptor.range.inside.3487, %descriptor.payload.inside.3484
  br i1 %descriptor.range.valid.3486, label %descriptor.valid.3488, label %descriptor.invalid.3489
descriptor.invalid.3489:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3488:
  %descriptor.initialized.status.3490 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3474, i32 %local.check.extent.3475)
  %helper.ok.3491 = icmp eq i32 %descriptor.initialized.status.3490, 0
  br i1 %helper.ok.3491, label %helper.continue.3492, label %frame.failure.0
helper.continue.3492:
  br label %local.descriptor.checked.3473
local.descriptor.inactive.3472:
  br label %local.descriptor.checked.3473
local.descriptor.checked.3473:
  %local.is.active.3493 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.3493, label %local.descriptor.active.3494, label %local.descriptor.inactive.3495
local.descriptor.active.3494:
  %local.check.offset.3497 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.3498 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.3499 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.3500 = load i32, ptr %local.owner.end.36, align 4
  %context.field.3501 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3502 = load i32, ptr %context.field.3501, align 4
  %stack.sub.3505 = sub i32 %local.check.owner.end.3500, %local.check.offset.3497
  %descriptor.owner.inside.3503 = icmp ule i32 %local.check.owner.end.3500, %context.value.3502
  %descriptor.offset.inside.3504 = icmp ule i32 %local.check.offset.3497, %local.check.owner.end.3500
  %descriptor.extent.inside.3506 = icmp ule i32 %local.check.extent.3498, %stack.sub.3505
  %descriptor.payload.inside.3507 = icmp ule i32 %local.check.payload.3499, %local.check.extent.3498
  %descriptor.owner.offset.valid.3508 = and i1 %descriptor.owner.inside.3503, %descriptor.offset.inside.3504
  %descriptor.range.inside.3510 = and i1 %descriptor.owner.offset.valid.3508, %descriptor.extent.inside.3506
  %descriptor.range.valid.3509 = and i1 %descriptor.range.inside.3510, %descriptor.payload.inside.3507
  br i1 %descriptor.range.valid.3509, label %descriptor.valid.3511, label %descriptor.invalid.3512
descriptor.invalid.3512:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3511:
  %descriptor.initialized.status.3513 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3497, i32 %local.check.extent.3498)
  %helper.ok.3514 = icmp eq i32 %descriptor.initialized.status.3513, 0
  br i1 %helper.ok.3514, label %helper.continue.3515, label %frame.failure.0
helper.continue.3515:
  br label %local.descriptor.checked.3496
local.descriptor.inactive.3495:
  br label %local.descriptor.checked.3496
local.descriptor.checked.3496:
  %step.status.3516 = call i32 @al_owning_charge_step(ptr %ctx, i32 25)
  %helper.ok.3517 = icmp eq i32 %step.status.3516, 0
  br i1 %helper.ok.3517, label %helper.continue.3518, label %frame.failure.0
helper.continue.3518:
  %local.resolved.offset.3519 = load i32, ptr %local.offset.21, align 4
  %local.resolved.extent.3520 = load i32, ptr %local.extent.22, align 4
  %local.resolved.payload.3521 = load i32, ptr %local.payload.23, align 4
  %local.resolved.owner.end.3522 = load i32, ptr %local.owner.end.24, align 4
  %context.field.3523 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3524 = load i32, ptr %context.field.3523, align 4
  %stack.sub.3527 = sub i32 %local.resolved.owner.end.3522, %local.resolved.offset.3519
  %descriptor.owner.inside.3525 = icmp ule i32 %local.resolved.owner.end.3522, %context.value.3524
  %descriptor.offset.inside.3526 = icmp ule i32 %local.resolved.offset.3519, %local.resolved.owner.end.3522
  %descriptor.extent.inside.3528 = icmp ule i32 %local.resolved.extent.3520, %stack.sub.3527
  %descriptor.payload.inside.3529 = icmp ule i32 %local.resolved.payload.3521, %local.resolved.extent.3520
  %descriptor.owner.offset.valid.3530 = and i1 %descriptor.owner.inside.3525, %descriptor.offset.inside.3526
  %descriptor.range.inside.3532 = and i1 %descriptor.owner.offset.valid.3530, %descriptor.extent.inside.3528
  %descriptor.range.valid.3531 = and i1 %descriptor.range.inside.3532, %descriptor.payload.inside.3529
  %descriptor.type.valid.3533 = icmp eq i32 12, 12
  %descriptor.valid.3534 = and i1 %descriptor.range.valid.3531, %descriptor.type.valid.3533
  br i1 %descriptor.valid.3534, label %descriptor.valid.3535, label %descriptor.invalid.3536
descriptor.invalid.3536:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3535:
  %descriptor.initialized.status.3537 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.3519, i32 %local.resolved.extent.3520)
  %helper.ok.3538 = icmp eq i32 %descriptor.initialized.status.3537, 0
  br i1 %helper.ok.3538, label %helper.continue.3539, label %frame.failure.0
helper.continue.3539:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %local.resolved.offset.3519, i32 20, i32 %local.resolved.payload.3521, i32 %local.resolved.owner.end.3522, i32 %local.resolved.extent.3520)
  %context.field.3540 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3541 = load i32, ptr %context.field.3540, align 4
  %runtime.ok.3542 = icmp eq i32 %context.value.3541, 0
  br i1 %runtime.ok.3542, label %runtime.continue.3543, label %frame.failure.0
runtime.continue.3543:
  %context.field.3544 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3545 = load i32, ptr %context.field.3544, align 4
  %stack.sub.3548 = sub i32 %local.resolved.owner.end.3522, %local.resolved.offset.3519
  %descriptor.owner.inside.3546 = icmp ule i32 %local.resolved.owner.end.3522, %context.value.3545
  %descriptor.offset.inside.3547 = icmp ule i32 %local.resolved.offset.3519, %local.resolved.owner.end.3522
  %descriptor.extent.inside.3549 = icmp ule i32 %local.resolved.extent.3520, %stack.sub.3548
  %descriptor.payload.inside.3550 = icmp ule i32 %local.resolved.payload.3521, %local.resolved.extent.3520
  %descriptor.owner.offset.valid.3551 = and i1 %descriptor.owner.inside.3546, %descriptor.offset.inside.3547
  %descriptor.range.inside.3553 = and i1 %descriptor.owner.offset.valid.3551, %descriptor.extent.inside.3549
  %descriptor.range.valid.3552 = and i1 %descriptor.range.inside.3553, %descriptor.payload.inside.3550
  %descriptor.type.valid.3554 = icmp eq i32 12, 12
  %descriptor.valid.3555 = and i1 %descriptor.range.valid.3552, %descriptor.type.valid.3554
  br i1 %descriptor.valid.3555, label %descriptor.valid.3556, label %descriptor.invalid.3557
descriptor.invalid.3557:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3556:
  %descriptor.initialized.status.3558 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.3519, i32 %local.resolved.extent.3520)
  %helper.ok.3559 = icmp eq i32 %descriptor.initialized.status.3558, 0
  br i1 %helper.ok.3559, label %helper.continue.3560, label %frame.failure.0
helper.continue.3560:
  %local.is.active.3561 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.3561, label %local.descriptor.active.3562, label %local.descriptor.inactive.3563
local.descriptor.active.3562:
  %local.check.offset.3565 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.3566 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.3567 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.3568 = load i32, ptr %local.owner.end.6, align 4
  %context.field.3569 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3570 = load i32, ptr %context.field.3569, align 4
  %stack.sub.3573 = sub i32 %local.check.owner.end.3568, %local.check.offset.3565
  %descriptor.owner.inside.3571 = icmp ule i32 %local.check.owner.end.3568, %context.value.3570
  %descriptor.offset.inside.3572 = icmp ule i32 %local.check.offset.3565, %local.check.owner.end.3568
  %descriptor.extent.inside.3574 = icmp ule i32 %local.check.extent.3566, %stack.sub.3573
  %descriptor.payload.inside.3575 = icmp ule i32 %local.check.payload.3567, %local.check.extent.3566
  %descriptor.owner.offset.valid.3576 = and i1 %descriptor.owner.inside.3571, %descriptor.offset.inside.3572
  %descriptor.range.inside.3578 = and i1 %descriptor.owner.offset.valid.3576, %descriptor.extent.inside.3574
  %descriptor.range.valid.3577 = and i1 %descriptor.range.inside.3578, %descriptor.payload.inside.3575
  br i1 %descriptor.range.valid.3577, label %descriptor.valid.3579, label %descriptor.invalid.3580
descriptor.invalid.3580:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3579:
  %descriptor.initialized.status.3581 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3565, i32 %local.check.extent.3566)
  %helper.ok.3582 = icmp eq i32 %descriptor.initialized.status.3581, 0
  br i1 %helper.ok.3582, label %helper.continue.3583, label %frame.failure.0
helper.continue.3583:
  br label %local.descriptor.checked.3564
local.descriptor.inactive.3563:
  br label %local.descriptor.checked.3564
local.descriptor.checked.3564:
  %local.is.active.3584 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.3584, label %local.descriptor.active.3585, label %local.descriptor.inactive.3586
local.descriptor.active.3585:
  %local.check.offset.3588 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.3589 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.3590 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.3591 = load i32, ptr %local.owner.end.12, align 4
  %context.field.3592 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3593 = load i32, ptr %context.field.3592, align 4
  %stack.sub.3596 = sub i32 %local.check.owner.end.3591, %local.check.offset.3588
  %descriptor.owner.inside.3594 = icmp ule i32 %local.check.owner.end.3591, %context.value.3593
  %descriptor.offset.inside.3595 = icmp ule i32 %local.check.offset.3588, %local.check.owner.end.3591
  %descriptor.extent.inside.3597 = icmp ule i32 %local.check.extent.3589, %stack.sub.3596
  %descriptor.payload.inside.3598 = icmp ule i32 %local.check.payload.3590, %local.check.extent.3589
  %descriptor.owner.offset.valid.3599 = and i1 %descriptor.owner.inside.3594, %descriptor.offset.inside.3595
  %descriptor.range.inside.3601 = and i1 %descriptor.owner.offset.valid.3599, %descriptor.extent.inside.3597
  %descriptor.range.valid.3600 = and i1 %descriptor.range.inside.3601, %descriptor.payload.inside.3598
  br i1 %descriptor.range.valid.3600, label %descriptor.valid.3602, label %descriptor.invalid.3603
descriptor.invalid.3603:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3602:
  %descriptor.initialized.status.3604 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3588, i32 %local.check.extent.3589)
  %helper.ok.3605 = icmp eq i32 %descriptor.initialized.status.3604, 0
  br i1 %helper.ok.3605, label %helper.continue.3606, label %frame.failure.0
helper.continue.3606:
  br label %local.descriptor.checked.3587
local.descriptor.inactive.3586:
  br label %local.descriptor.checked.3587
local.descriptor.checked.3587:
  %local.is.active.3607 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.3607, label %local.descriptor.active.3608, label %local.descriptor.inactive.3609
local.descriptor.active.3608:
  %local.check.offset.3611 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.3612 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.3613 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.3614 = load i32, ptr %local.owner.end.18, align 4
  %context.field.3615 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3616 = load i32, ptr %context.field.3615, align 4
  %stack.sub.3619 = sub i32 %local.check.owner.end.3614, %local.check.offset.3611
  %descriptor.owner.inside.3617 = icmp ule i32 %local.check.owner.end.3614, %context.value.3616
  %descriptor.offset.inside.3618 = icmp ule i32 %local.check.offset.3611, %local.check.owner.end.3614
  %descriptor.extent.inside.3620 = icmp ule i32 %local.check.extent.3612, %stack.sub.3619
  %descriptor.payload.inside.3621 = icmp ule i32 %local.check.payload.3613, %local.check.extent.3612
  %descriptor.owner.offset.valid.3622 = and i1 %descriptor.owner.inside.3617, %descriptor.offset.inside.3618
  %descriptor.range.inside.3624 = and i1 %descriptor.owner.offset.valid.3622, %descriptor.extent.inside.3620
  %descriptor.range.valid.3623 = and i1 %descriptor.range.inside.3624, %descriptor.payload.inside.3621
  br i1 %descriptor.range.valid.3623, label %descriptor.valid.3625, label %descriptor.invalid.3626
descriptor.invalid.3626:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3625:
  %descriptor.initialized.status.3627 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3611, i32 %local.check.extent.3612)
  %helper.ok.3628 = icmp eq i32 %descriptor.initialized.status.3627, 0
  br i1 %helper.ok.3628, label %helper.continue.3629, label %frame.failure.0
helper.continue.3629:
  br label %local.descriptor.checked.3610
local.descriptor.inactive.3609:
  br label %local.descriptor.checked.3610
local.descriptor.checked.3610:
  %local.is.active.3630 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.3630, label %local.descriptor.active.3631, label %local.descriptor.inactive.3632
local.descriptor.active.3631:
  %local.check.offset.3634 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.3635 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.3636 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.3637 = load i32, ptr %local.owner.end.24, align 4
  %context.field.3638 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3639 = load i32, ptr %context.field.3638, align 4
  %stack.sub.3642 = sub i32 %local.check.owner.end.3637, %local.check.offset.3634
  %descriptor.owner.inside.3640 = icmp ule i32 %local.check.owner.end.3637, %context.value.3639
  %descriptor.offset.inside.3641 = icmp ule i32 %local.check.offset.3634, %local.check.owner.end.3637
  %descriptor.extent.inside.3643 = icmp ule i32 %local.check.extent.3635, %stack.sub.3642
  %descriptor.payload.inside.3644 = icmp ule i32 %local.check.payload.3636, %local.check.extent.3635
  %descriptor.owner.offset.valid.3645 = and i1 %descriptor.owner.inside.3640, %descriptor.offset.inside.3641
  %descriptor.range.inside.3647 = and i1 %descriptor.owner.offset.valid.3645, %descriptor.extent.inside.3643
  %descriptor.range.valid.3646 = and i1 %descriptor.range.inside.3647, %descriptor.payload.inside.3644
  br i1 %descriptor.range.valid.3646, label %descriptor.valid.3648, label %descriptor.invalid.3649
descriptor.invalid.3649:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3648:
  %descriptor.initialized.status.3650 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3634, i32 %local.check.extent.3635)
  %helper.ok.3651 = icmp eq i32 %descriptor.initialized.status.3650, 0
  br i1 %helper.ok.3651, label %helper.continue.3652, label %frame.failure.0
helper.continue.3652:
  br label %local.descriptor.checked.3633
local.descriptor.inactive.3632:
  br label %local.descriptor.checked.3633
local.descriptor.checked.3633:
  %local.is.active.3653 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.3653, label %local.descriptor.active.3654, label %local.descriptor.inactive.3655
local.descriptor.active.3654:
  %local.check.offset.3657 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.3658 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.3659 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.3660 = load i32, ptr %local.owner.end.30, align 4
  %context.field.3661 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3662 = load i32, ptr %context.field.3661, align 4
  %stack.sub.3665 = sub i32 %local.check.owner.end.3660, %local.check.offset.3657
  %descriptor.owner.inside.3663 = icmp ule i32 %local.check.owner.end.3660, %context.value.3662
  %descriptor.offset.inside.3664 = icmp ule i32 %local.check.offset.3657, %local.check.owner.end.3660
  %descriptor.extent.inside.3666 = icmp ule i32 %local.check.extent.3658, %stack.sub.3665
  %descriptor.payload.inside.3667 = icmp ule i32 %local.check.payload.3659, %local.check.extent.3658
  %descriptor.owner.offset.valid.3668 = and i1 %descriptor.owner.inside.3663, %descriptor.offset.inside.3664
  %descriptor.range.inside.3670 = and i1 %descriptor.owner.offset.valid.3668, %descriptor.extent.inside.3666
  %descriptor.range.valid.3669 = and i1 %descriptor.range.inside.3670, %descriptor.payload.inside.3667
  br i1 %descriptor.range.valid.3669, label %descriptor.valid.3671, label %descriptor.invalid.3672
descriptor.invalid.3672:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3671:
  %descriptor.initialized.status.3673 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3657, i32 %local.check.extent.3658)
  %helper.ok.3674 = icmp eq i32 %descriptor.initialized.status.3673, 0
  br i1 %helper.ok.3674, label %helper.continue.3675, label %frame.failure.0
helper.continue.3675:
  br label %local.descriptor.checked.3656
local.descriptor.inactive.3655:
  br label %local.descriptor.checked.3656
local.descriptor.checked.3656:
  %local.is.active.3676 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.3676, label %local.descriptor.active.3677, label %local.descriptor.inactive.3678
local.descriptor.active.3677:
  %local.check.offset.3680 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.3681 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.3682 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.3683 = load i32, ptr %local.owner.end.36, align 4
  %context.field.3684 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3685 = load i32, ptr %context.field.3684, align 4
  %stack.sub.3688 = sub i32 %local.check.owner.end.3683, %local.check.offset.3680
  %descriptor.owner.inside.3686 = icmp ule i32 %local.check.owner.end.3683, %context.value.3685
  %descriptor.offset.inside.3687 = icmp ule i32 %local.check.offset.3680, %local.check.owner.end.3683
  %descriptor.extent.inside.3689 = icmp ule i32 %local.check.extent.3681, %stack.sub.3688
  %descriptor.payload.inside.3690 = icmp ule i32 %local.check.payload.3682, %local.check.extent.3681
  %descriptor.owner.offset.valid.3691 = and i1 %descriptor.owner.inside.3686, %descriptor.offset.inside.3687
  %descriptor.range.inside.3693 = and i1 %descriptor.owner.offset.valid.3691, %descriptor.extent.inside.3689
  %descriptor.range.valid.3692 = and i1 %descriptor.range.inside.3693, %descriptor.payload.inside.3690
  br i1 %descriptor.range.valid.3692, label %descriptor.valid.3694, label %descriptor.invalid.3695
descriptor.invalid.3695:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3694:
  %descriptor.initialized.status.3696 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3680, i32 %local.check.extent.3681)
  %helper.ok.3697 = icmp eq i32 %descriptor.initialized.status.3696, 0
  br i1 %helper.ok.3697, label %helper.continue.3698, label %frame.failure.0
helper.continue.3698:
  br label %local.descriptor.checked.3679
local.descriptor.inactive.3678:
  br label %local.descriptor.checked.3679
local.descriptor.checked.3679:
  %step.status.3699 = call i32 @al_owning_charge_step(ptr %ctx, i32 26)
  %helper.ok.3700 = icmp eq i32 %step.status.3699, 0
  br i1 %helper.ok.3700, label %helper.continue.3701, label %frame.failure.0
helper.continue.3701:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 12, i32 %local.resolved.offset.3519, i32 %local.resolved.extent.3520, i32 %local.resolved.payload.3521, i32 0, i32 0)
  %context.field.3702 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3703 = load i32, ptr %context.field.3702, align 4
  %runtime.ok.3704 = icmp eq i32 %context.value.3703, 0
  br i1 %runtime.ok.3704, label %runtime.continue.3705, label %frame.failure.0
runtime.continue.3705:
  %local.is.active.3706 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.3706, label %local.descriptor.active.3707, label %local.descriptor.inactive.3708
local.descriptor.active.3707:
  %local.check.offset.3710 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.3711 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.3712 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.3713 = load i32, ptr %local.owner.end.6, align 4
  %context.field.3714 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3715 = load i32, ptr %context.field.3714, align 4
  %stack.sub.3718 = sub i32 %local.check.owner.end.3713, %local.check.offset.3710
  %descriptor.owner.inside.3716 = icmp ule i32 %local.check.owner.end.3713, %context.value.3715
  %descriptor.offset.inside.3717 = icmp ule i32 %local.check.offset.3710, %local.check.owner.end.3713
  %descriptor.extent.inside.3719 = icmp ule i32 %local.check.extent.3711, %stack.sub.3718
  %descriptor.payload.inside.3720 = icmp ule i32 %local.check.payload.3712, %local.check.extent.3711
  %descriptor.owner.offset.valid.3721 = and i1 %descriptor.owner.inside.3716, %descriptor.offset.inside.3717
  %descriptor.range.inside.3723 = and i1 %descriptor.owner.offset.valid.3721, %descriptor.extent.inside.3719
  %descriptor.range.valid.3722 = and i1 %descriptor.range.inside.3723, %descriptor.payload.inside.3720
  br i1 %descriptor.range.valid.3722, label %descriptor.valid.3724, label %descriptor.invalid.3725
descriptor.invalid.3725:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3724:
  %descriptor.initialized.status.3726 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3710, i32 %local.check.extent.3711)
  %helper.ok.3727 = icmp eq i32 %descriptor.initialized.status.3726, 0
  br i1 %helper.ok.3727, label %helper.continue.3728, label %frame.failure.0
helper.continue.3728:
  br label %local.descriptor.checked.3709
local.descriptor.inactive.3708:
  br label %local.descriptor.checked.3709
local.descriptor.checked.3709:
  %local.is.active.3729 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.3729, label %local.descriptor.active.3730, label %local.descriptor.inactive.3731
local.descriptor.active.3730:
  %local.check.offset.3733 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.3734 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.3735 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.3736 = load i32, ptr %local.owner.end.12, align 4
  %context.field.3737 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3738 = load i32, ptr %context.field.3737, align 4
  %stack.sub.3741 = sub i32 %local.check.owner.end.3736, %local.check.offset.3733
  %descriptor.owner.inside.3739 = icmp ule i32 %local.check.owner.end.3736, %context.value.3738
  %descriptor.offset.inside.3740 = icmp ule i32 %local.check.offset.3733, %local.check.owner.end.3736
  %descriptor.extent.inside.3742 = icmp ule i32 %local.check.extent.3734, %stack.sub.3741
  %descriptor.payload.inside.3743 = icmp ule i32 %local.check.payload.3735, %local.check.extent.3734
  %descriptor.owner.offset.valid.3744 = and i1 %descriptor.owner.inside.3739, %descriptor.offset.inside.3740
  %descriptor.range.inside.3746 = and i1 %descriptor.owner.offset.valid.3744, %descriptor.extent.inside.3742
  %descriptor.range.valid.3745 = and i1 %descriptor.range.inside.3746, %descriptor.payload.inside.3743
  br i1 %descriptor.range.valid.3745, label %descriptor.valid.3747, label %descriptor.invalid.3748
descriptor.invalid.3748:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3747:
  %descriptor.initialized.status.3749 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3733, i32 %local.check.extent.3734)
  %helper.ok.3750 = icmp eq i32 %descriptor.initialized.status.3749, 0
  br i1 %helper.ok.3750, label %helper.continue.3751, label %frame.failure.0
helper.continue.3751:
  br label %local.descriptor.checked.3732
local.descriptor.inactive.3731:
  br label %local.descriptor.checked.3732
local.descriptor.checked.3732:
  %local.is.active.3752 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.3752, label %local.descriptor.active.3753, label %local.descriptor.inactive.3754
local.descriptor.active.3753:
  %local.check.offset.3756 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.3757 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.3758 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.3759 = load i32, ptr %local.owner.end.18, align 4
  %context.field.3760 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3761 = load i32, ptr %context.field.3760, align 4
  %stack.sub.3764 = sub i32 %local.check.owner.end.3759, %local.check.offset.3756
  %descriptor.owner.inside.3762 = icmp ule i32 %local.check.owner.end.3759, %context.value.3761
  %descriptor.offset.inside.3763 = icmp ule i32 %local.check.offset.3756, %local.check.owner.end.3759
  %descriptor.extent.inside.3765 = icmp ule i32 %local.check.extent.3757, %stack.sub.3764
  %descriptor.payload.inside.3766 = icmp ule i32 %local.check.payload.3758, %local.check.extent.3757
  %descriptor.owner.offset.valid.3767 = and i1 %descriptor.owner.inside.3762, %descriptor.offset.inside.3763
  %descriptor.range.inside.3769 = and i1 %descriptor.owner.offset.valid.3767, %descriptor.extent.inside.3765
  %descriptor.range.valid.3768 = and i1 %descriptor.range.inside.3769, %descriptor.payload.inside.3766
  br i1 %descriptor.range.valid.3768, label %descriptor.valid.3770, label %descriptor.invalid.3771
descriptor.invalid.3771:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3770:
  %descriptor.initialized.status.3772 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3756, i32 %local.check.extent.3757)
  %helper.ok.3773 = icmp eq i32 %descriptor.initialized.status.3772, 0
  br i1 %helper.ok.3773, label %helper.continue.3774, label %frame.failure.0
helper.continue.3774:
  br label %local.descriptor.checked.3755
local.descriptor.inactive.3754:
  br label %local.descriptor.checked.3755
local.descriptor.checked.3755:
  %local.is.active.3775 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.3775, label %local.descriptor.active.3776, label %local.descriptor.inactive.3777
local.descriptor.active.3776:
  %local.check.offset.3779 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.3780 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.3781 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.3782 = load i32, ptr %local.owner.end.24, align 4
  %context.field.3783 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3784 = load i32, ptr %context.field.3783, align 4
  %stack.sub.3787 = sub i32 %local.check.owner.end.3782, %local.check.offset.3779
  %descriptor.owner.inside.3785 = icmp ule i32 %local.check.owner.end.3782, %context.value.3784
  %descriptor.offset.inside.3786 = icmp ule i32 %local.check.offset.3779, %local.check.owner.end.3782
  %descriptor.extent.inside.3788 = icmp ule i32 %local.check.extent.3780, %stack.sub.3787
  %descriptor.payload.inside.3789 = icmp ule i32 %local.check.payload.3781, %local.check.extent.3780
  %descriptor.owner.offset.valid.3790 = and i1 %descriptor.owner.inside.3785, %descriptor.offset.inside.3786
  %descriptor.range.inside.3792 = and i1 %descriptor.owner.offset.valid.3790, %descriptor.extent.inside.3788
  %descriptor.range.valid.3791 = and i1 %descriptor.range.inside.3792, %descriptor.payload.inside.3789
  br i1 %descriptor.range.valid.3791, label %descriptor.valid.3793, label %descriptor.invalid.3794
descriptor.invalid.3794:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3793:
  %descriptor.initialized.status.3795 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3779, i32 %local.check.extent.3780)
  %helper.ok.3796 = icmp eq i32 %descriptor.initialized.status.3795, 0
  br i1 %helper.ok.3796, label %helper.continue.3797, label %frame.failure.0
helper.continue.3797:
  br label %local.descriptor.checked.3778
local.descriptor.inactive.3777:
  br label %local.descriptor.checked.3778
local.descriptor.checked.3778:
  %local.is.active.3798 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.3798, label %local.descriptor.active.3799, label %local.descriptor.inactive.3800
local.descriptor.active.3799:
  %local.check.offset.3802 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.3803 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.3804 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.3805 = load i32, ptr %local.owner.end.30, align 4
  %context.field.3806 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3807 = load i32, ptr %context.field.3806, align 4
  %stack.sub.3810 = sub i32 %local.check.owner.end.3805, %local.check.offset.3802
  %descriptor.owner.inside.3808 = icmp ule i32 %local.check.owner.end.3805, %context.value.3807
  %descriptor.offset.inside.3809 = icmp ule i32 %local.check.offset.3802, %local.check.owner.end.3805
  %descriptor.extent.inside.3811 = icmp ule i32 %local.check.extent.3803, %stack.sub.3810
  %descriptor.payload.inside.3812 = icmp ule i32 %local.check.payload.3804, %local.check.extent.3803
  %descriptor.owner.offset.valid.3813 = and i1 %descriptor.owner.inside.3808, %descriptor.offset.inside.3809
  %descriptor.range.inside.3815 = and i1 %descriptor.owner.offset.valid.3813, %descriptor.extent.inside.3811
  %descriptor.range.valid.3814 = and i1 %descriptor.range.inside.3815, %descriptor.payload.inside.3812
  br i1 %descriptor.range.valid.3814, label %descriptor.valid.3816, label %descriptor.invalid.3817
descriptor.invalid.3817:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3816:
  %descriptor.initialized.status.3818 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3802, i32 %local.check.extent.3803)
  %helper.ok.3819 = icmp eq i32 %descriptor.initialized.status.3818, 0
  br i1 %helper.ok.3819, label %helper.continue.3820, label %frame.failure.0
helper.continue.3820:
  br label %local.descriptor.checked.3801
local.descriptor.inactive.3800:
  br label %local.descriptor.checked.3801
local.descriptor.checked.3801:
  %local.is.active.3821 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.3821, label %local.descriptor.active.3822, label %local.descriptor.inactive.3823
local.descriptor.active.3822:
  %local.check.offset.3825 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.3826 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.3827 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.3828 = load i32, ptr %local.owner.end.36, align 4
  %context.field.3829 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3830 = load i32, ptr %context.field.3829, align 4
  %stack.sub.3833 = sub i32 %local.check.owner.end.3828, %local.check.offset.3825
  %descriptor.owner.inside.3831 = icmp ule i32 %local.check.owner.end.3828, %context.value.3830
  %descriptor.offset.inside.3832 = icmp ule i32 %local.check.offset.3825, %local.check.owner.end.3828
  %descriptor.extent.inside.3834 = icmp ule i32 %local.check.extent.3826, %stack.sub.3833
  %descriptor.payload.inside.3835 = icmp ule i32 %local.check.payload.3827, %local.check.extent.3826
  %descriptor.owner.offset.valid.3836 = and i1 %descriptor.owner.inside.3831, %descriptor.offset.inside.3832
  %descriptor.range.inside.3838 = and i1 %descriptor.owner.offset.valid.3836, %descriptor.extent.inside.3834
  %descriptor.range.valid.3837 = and i1 %descriptor.range.inside.3838, %descriptor.payload.inside.3835
  br i1 %descriptor.range.valid.3837, label %descriptor.valid.3839, label %descriptor.invalid.3840
descriptor.invalid.3840:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3839:
  %descriptor.initialized.status.3841 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3825, i32 %local.check.extent.3826)
  %helper.ok.3842 = icmp eq i32 %descriptor.initialized.status.3841, 0
  br i1 %helper.ok.3842, label %helper.continue.3843, label %frame.failure.0
helper.continue.3843:
  br label %local.descriptor.checked.3824
local.descriptor.inactive.3823:
  br label %local.descriptor.checked.3824
local.descriptor.checked.3824:
  %step.status.3844 = call i32 @al_owning_charge_step(ptr %ctx, i32 27)
  %helper.ok.3845 = icmp eq i32 %step.status.3844, 0
  br i1 %helper.ok.3845, label %helper.continue.3846, label %frame.failure.0
helper.continue.3846:
  %local.resolved.offset.3847 = load i32, ptr %local.offset.27, align 4
  %local.resolved.extent.3848 = load i32, ptr %local.extent.28, align 4
  %local.resolved.payload.3849 = load i32, ptr %local.payload.29, align 4
  %local.resolved.owner.end.3850 = load i32, ptr %local.owner.end.30, align 4
  %context.field.3851 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3852 = load i32, ptr %context.field.3851, align 4
  %stack.sub.3855 = sub i32 %local.resolved.owner.end.3850, %local.resolved.offset.3847
  %descriptor.owner.inside.3853 = icmp ule i32 %local.resolved.owner.end.3850, %context.value.3852
  %descriptor.offset.inside.3854 = icmp ule i32 %local.resolved.offset.3847, %local.resolved.owner.end.3850
  %descriptor.extent.inside.3856 = icmp ule i32 %local.resolved.extent.3848, %stack.sub.3855
  %descriptor.payload.inside.3857 = icmp ule i32 %local.resolved.payload.3849, %local.resolved.extent.3848
  %descriptor.owner.offset.valid.3858 = and i1 %descriptor.owner.inside.3853, %descriptor.offset.inside.3854
  %descriptor.range.inside.3860 = and i1 %descriptor.owner.offset.valid.3858, %descriptor.extent.inside.3856
  %descriptor.range.valid.3859 = and i1 %descriptor.range.inside.3860, %descriptor.payload.inside.3857
  %descriptor.type.valid.3861 = icmp eq i32 12, 12
  %descriptor.valid.3862 = and i1 %descriptor.range.valid.3859, %descriptor.type.valid.3861
  br i1 %descriptor.valid.3862, label %descriptor.valid.3863, label %descriptor.invalid.3864
descriptor.invalid.3864:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3863:
  %descriptor.initialized.status.3865 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.3847, i32 %local.resolved.extent.3848)
  %helper.ok.3866 = icmp eq i32 %descriptor.initialized.status.3865, 0
  br i1 %helper.ok.3866, label %helper.continue.3867, label %frame.failure.0
helper.continue.3867:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %local.resolved.offset.3847, i32 20, i32 %local.resolved.payload.3849, i32 %local.resolved.owner.end.3850, i32 %local.resolved.extent.3848)
  %context.field.3868 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.3869 = load i32, ptr %context.field.3868, align 4
  %runtime.ok.3870 = icmp eq i32 %context.value.3869, 0
  br i1 %runtime.ok.3870, label %runtime.continue.3871, label %frame.failure.0
runtime.continue.3871:
  %context.field.3872 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3873 = load i32, ptr %context.field.3872, align 4
  %stack.sub.3876 = sub i32 %local.resolved.owner.end.3850, %local.resolved.offset.3847
  %descriptor.owner.inside.3874 = icmp ule i32 %local.resolved.owner.end.3850, %context.value.3873
  %descriptor.offset.inside.3875 = icmp ule i32 %local.resolved.offset.3847, %local.resolved.owner.end.3850
  %descriptor.extent.inside.3877 = icmp ule i32 %local.resolved.extent.3848, %stack.sub.3876
  %descriptor.payload.inside.3878 = icmp ule i32 %local.resolved.payload.3849, %local.resolved.extent.3848
  %descriptor.owner.offset.valid.3879 = and i1 %descriptor.owner.inside.3874, %descriptor.offset.inside.3875
  %descriptor.range.inside.3881 = and i1 %descriptor.owner.offset.valid.3879, %descriptor.extent.inside.3877
  %descriptor.range.valid.3880 = and i1 %descriptor.range.inside.3881, %descriptor.payload.inside.3878
  %descriptor.type.valid.3882 = icmp eq i32 12, 12
  %descriptor.valid.3883 = and i1 %descriptor.range.valid.3880, %descriptor.type.valid.3882
  br i1 %descriptor.valid.3883, label %descriptor.valid.3884, label %descriptor.invalid.3885
descriptor.invalid.3885:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3884:
  %descriptor.initialized.status.3886 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.3847, i32 %local.resolved.extent.3848)
  %helper.ok.3887 = icmp eq i32 %descriptor.initialized.status.3886, 0
  br i1 %helper.ok.3887, label %helper.continue.3888, label %frame.failure.0
helper.continue.3888:
  %local.is.active.3889 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.3889, label %local.descriptor.active.3890, label %local.descriptor.inactive.3891
local.descriptor.active.3890:
  %local.check.offset.3893 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.3894 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.3895 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.3896 = load i32, ptr %local.owner.end.6, align 4
  %context.field.3897 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3898 = load i32, ptr %context.field.3897, align 4
  %stack.sub.3901 = sub i32 %local.check.owner.end.3896, %local.check.offset.3893
  %descriptor.owner.inside.3899 = icmp ule i32 %local.check.owner.end.3896, %context.value.3898
  %descriptor.offset.inside.3900 = icmp ule i32 %local.check.offset.3893, %local.check.owner.end.3896
  %descriptor.extent.inside.3902 = icmp ule i32 %local.check.extent.3894, %stack.sub.3901
  %descriptor.payload.inside.3903 = icmp ule i32 %local.check.payload.3895, %local.check.extent.3894
  %descriptor.owner.offset.valid.3904 = and i1 %descriptor.owner.inside.3899, %descriptor.offset.inside.3900
  %descriptor.range.inside.3906 = and i1 %descriptor.owner.offset.valid.3904, %descriptor.extent.inside.3902
  %descriptor.range.valid.3905 = and i1 %descriptor.range.inside.3906, %descriptor.payload.inside.3903
  br i1 %descriptor.range.valid.3905, label %descriptor.valid.3907, label %descriptor.invalid.3908
descriptor.invalid.3908:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3907:
  %descriptor.initialized.status.3909 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3893, i32 %local.check.extent.3894)
  %helper.ok.3910 = icmp eq i32 %descriptor.initialized.status.3909, 0
  br i1 %helper.ok.3910, label %helper.continue.3911, label %frame.failure.0
helper.continue.3911:
  br label %local.descriptor.checked.3892
local.descriptor.inactive.3891:
  br label %local.descriptor.checked.3892
local.descriptor.checked.3892:
  %local.is.active.3912 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.3912, label %local.descriptor.active.3913, label %local.descriptor.inactive.3914
local.descriptor.active.3913:
  %local.check.offset.3916 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.3917 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.3918 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.3919 = load i32, ptr %local.owner.end.12, align 4
  %context.field.3920 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3921 = load i32, ptr %context.field.3920, align 4
  %stack.sub.3924 = sub i32 %local.check.owner.end.3919, %local.check.offset.3916
  %descriptor.owner.inside.3922 = icmp ule i32 %local.check.owner.end.3919, %context.value.3921
  %descriptor.offset.inside.3923 = icmp ule i32 %local.check.offset.3916, %local.check.owner.end.3919
  %descriptor.extent.inside.3925 = icmp ule i32 %local.check.extent.3917, %stack.sub.3924
  %descriptor.payload.inside.3926 = icmp ule i32 %local.check.payload.3918, %local.check.extent.3917
  %descriptor.owner.offset.valid.3927 = and i1 %descriptor.owner.inside.3922, %descriptor.offset.inside.3923
  %descriptor.range.inside.3929 = and i1 %descriptor.owner.offset.valid.3927, %descriptor.extent.inside.3925
  %descriptor.range.valid.3928 = and i1 %descriptor.range.inside.3929, %descriptor.payload.inside.3926
  br i1 %descriptor.range.valid.3928, label %descriptor.valid.3930, label %descriptor.invalid.3931
descriptor.invalid.3931:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3930:
  %descriptor.initialized.status.3932 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3916, i32 %local.check.extent.3917)
  %helper.ok.3933 = icmp eq i32 %descriptor.initialized.status.3932, 0
  br i1 %helper.ok.3933, label %helper.continue.3934, label %frame.failure.0
helper.continue.3934:
  br label %local.descriptor.checked.3915
local.descriptor.inactive.3914:
  br label %local.descriptor.checked.3915
local.descriptor.checked.3915:
  %local.is.active.3935 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.3935, label %local.descriptor.active.3936, label %local.descriptor.inactive.3937
local.descriptor.active.3936:
  %local.check.offset.3939 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.3940 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.3941 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.3942 = load i32, ptr %local.owner.end.18, align 4
  %context.field.3943 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3944 = load i32, ptr %context.field.3943, align 4
  %stack.sub.3947 = sub i32 %local.check.owner.end.3942, %local.check.offset.3939
  %descriptor.owner.inside.3945 = icmp ule i32 %local.check.owner.end.3942, %context.value.3944
  %descriptor.offset.inside.3946 = icmp ule i32 %local.check.offset.3939, %local.check.owner.end.3942
  %descriptor.extent.inside.3948 = icmp ule i32 %local.check.extent.3940, %stack.sub.3947
  %descriptor.payload.inside.3949 = icmp ule i32 %local.check.payload.3941, %local.check.extent.3940
  %descriptor.owner.offset.valid.3950 = and i1 %descriptor.owner.inside.3945, %descriptor.offset.inside.3946
  %descriptor.range.inside.3952 = and i1 %descriptor.owner.offset.valid.3950, %descriptor.extent.inside.3948
  %descriptor.range.valid.3951 = and i1 %descriptor.range.inside.3952, %descriptor.payload.inside.3949
  br i1 %descriptor.range.valid.3951, label %descriptor.valid.3953, label %descriptor.invalid.3954
descriptor.invalid.3954:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3953:
  %descriptor.initialized.status.3955 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3939, i32 %local.check.extent.3940)
  %helper.ok.3956 = icmp eq i32 %descriptor.initialized.status.3955, 0
  br i1 %helper.ok.3956, label %helper.continue.3957, label %frame.failure.0
helper.continue.3957:
  br label %local.descriptor.checked.3938
local.descriptor.inactive.3937:
  br label %local.descriptor.checked.3938
local.descriptor.checked.3938:
  %local.is.active.3958 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.3958, label %local.descriptor.active.3959, label %local.descriptor.inactive.3960
local.descriptor.active.3959:
  %local.check.offset.3962 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.3963 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.3964 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.3965 = load i32, ptr %local.owner.end.24, align 4
  %context.field.3966 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3967 = load i32, ptr %context.field.3966, align 4
  %stack.sub.3970 = sub i32 %local.check.owner.end.3965, %local.check.offset.3962
  %descriptor.owner.inside.3968 = icmp ule i32 %local.check.owner.end.3965, %context.value.3967
  %descriptor.offset.inside.3969 = icmp ule i32 %local.check.offset.3962, %local.check.owner.end.3965
  %descriptor.extent.inside.3971 = icmp ule i32 %local.check.extent.3963, %stack.sub.3970
  %descriptor.payload.inside.3972 = icmp ule i32 %local.check.payload.3964, %local.check.extent.3963
  %descriptor.owner.offset.valid.3973 = and i1 %descriptor.owner.inside.3968, %descriptor.offset.inside.3969
  %descriptor.range.inside.3975 = and i1 %descriptor.owner.offset.valid.3973, %descriptor.extent.inside.3971
  %descriptor.range.valid.3974 = and i1 %descriptor.range.inside.3975, %descriptor.payload.inside.3972
  br i1 %descriptor.range.valid.3974, label %descriptor.valid.3976, label %descriptor.invalid.3977
descriptor.invalid.3977:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3976:
  %descriptor.initialized.status.3978 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3962, i32 %local.check.extent.3963)
  %helper.ok.3979 = icmp eq i32 %descriptor.initialized.status.3978, 0
  br i1 %helper.ok.3979, label %helper.continue.3980, label %frame.failure.0
helper.continue.3980:
  br label %local.descriptor.checked.3961
local.descriptor.inactive.3960:
  br label %local.descriptor.checked.3961
local.descriptor.checked.3961:
  %local.is.active.3981 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.3981, label %local.descriptor.active.3982, label %local.descriptor.inactive.3983
local.descriptor.active.3982:
  %local.check.offset.3985 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.3986 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.3987 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.3988 = load i32, ptr %local.owner.end.30, align 4
  %context.field.3989 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3990 = load i32, ptr %context.field.3989, align 4
  %stack.sub.3993 = sub i32 %local.check.owner.end.3988, %local.check.offset.3985
  %descriptor.owner.inside.3991 = icmp ule i32 %local.check.owner.end.3988, %context.value.3990
  %descriptor.offset.inside.3992 = icmp ule i32 %local.check.offset.3985, %local.check.owner.end.3988
  %descriptor.extent.inside.3994 = icmp ule i32 %local.check.extent.3986, %stack.sub.3993
  %descriptor.payload.inside.3995 = icmp ule i32 %local.check.payload.3987, %local.check.extent.3986
  %descriptor.owner.offset.valid.3996 = and i1 %descriptor.owner.inside.3991, %descriptor.offset.inside.3992
  %descriptor.range.inside.3998 = and i1 %descriptor.owner.offset.valid.3996, %descriptor.extent.inside.3994
  %descriptor.range.valid.3997 = and i1 %descriptor.range.inside.3998, %descriptor.payload.inside.3995
  br i1 %descriptor.range.valid.3997, label %descriptor.valid.3999, label %descriptor.invalid.4000
descriptor.invalid.4000:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.3999:
  %descriptor.initialized.status.4001 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.3985, i32 %local.check.extent.3986)
  %helper.ok.4002 = icmp eq i32 %descriptor.initialized.status.4001, 0
  br i1 %helper.ok.4002, label %helper.continue.4003, label %frame.failure.0
helper.continue.4003:
  br label %local.descriptor.checked.3984
local.descriptor.inactive.3983:
  br label %local.descriptor.checked.3984
local.descriptor.checked.3984:
  %local.is.active.4004 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.4004, label %local.descriptor.active.4005, label %local.descriptor.inactive.4006
local.descriptor.active.4005:
  %local.check.offset.4008 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.4009 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.4010 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.4011 = load i32, ptr %local.owner.end.36, align 4
  %context.field.4012 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4013 = load i32, ptr %context.field.4012, align 4
  %stack.sub.4016 = sub i32 %local.check.owner.end.4011, %local.check.offset.4008
  %descriptor.owner.inside.4014 = icmp ule i32 %local.check.owner.end.4011, %context.value.4013
  %descriptor.offset.inside.4015 = icmp ule i32 %local.check.offset.4008, %local.check.owner.end.4011
  %descriptor.extent.inside.4017 = icmp ule i32 %local.check.extent.4009, %stack.sub.4016
  %descriptor.payload.inside.4018 = icmp ule i32 %local.check.payload.4010, %local.check.extent.4009
  %descriptor.owner.offset.valid.4019 = and i1 %descriptor.owner.inside.4014, %descriptor.offset.inside.4015
  %descriptor.range.inside.4021 = and i1 %descriptor.owner.offset.valid.4019, %descriptor.extent.inside.4017
  %descriptor.range.valid.4020 = and i1 %descriptor.range.inside.4021, %descriptor.payload.inside.4018
  br i1 %descriptor.range.valid.4020, label %descriptor.valid.4022, label %descriptor.invalid.4023
descriptor.invalid.4023:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4022:
  %descriptor.initialized.status.4024 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4008, i32 %local.check.extent.4009)
  %helper.ok.4025 = icmp eq i32 %descriptor.initialized.status.4024, 0
  br i1 %helper.ok.4025, label %helper.continue.4026, label %frame.failure.0
helper.continue.4026:
  br label %local.descriptor.checked.4007
local.descriptor.inactive.4006:
  br label %local.descriptor.checked.4007
local.descriptor.checked.4007:
  %step.status.4027 = call i32 @al_owning_charge_step(ptr %ctx, i32 28)
  %helper.ok.4028 = icmp eq i32 %step.status.4027, 0
  br i1 %helper.ok.4028, label %helper.continue.4029, label %frame.failure.0
helper.continue.4029:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 12, i32 %local.resolved.offset.3847, i32 %local.resolved.extent.3848, i32 %local.resolved.payload.3849, i32 0, i32 0)
  %context.field.4030 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4031 = load i32, ptr %context.field.4030, align 4
  %runtime.ok.4032 = icmp eq i32 %context.value.4031, 0
  br i1 %runtime.ok.4032, label %runtime.continue.4033, label %frame.failure.0
runtime.continue.4033:
  %local.is.active.4034 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.4034, label %local.descriptor.active.4035, label %local.descriptor.inactive.4036
local.descriptor.active.4035:
  %local.check.offset.4038 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.4039 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.4040 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.4041 = load i32, ptr %local.owner.end.6, align 4
  %context.field.4042 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4043 = load i32, ptr %context.field.4042, align 4
  %stack.sub.4046 = sub i32 %local.check.owner.end.4041, %local.check.offset.4038
  %descriptor.owner.inside.4044 = icmp ule i32 %local.check.owner.end.4041, %context.value.4043
  %descriptor.offset.inside.4045 = icmp ule i32 %local.check.offset.4038, %local.check.owner.end.4041
  %descriptor.extent.inside.4047 = icmp ule i32 %local.check.extent.4039, %stack.sub.4046
  %descriptor.payload.inside.4048 = icmp ule i32 %local.check.payload.4040, %local.check.extent.4039
  %descriptor.owner.offset.valid.4049 = and i1 %descriptor.owner.inside.4044, %descriptor.offset.inside.4045
  %descriptor.range.inside.4051 = and i1 %descriptor.owner.offset.valid.4049, %descriptor.extent.inside.4047
  %descriptor.range.valid.4050 = and i1 %descriptor.range.inside.4051, %descriptor.payload.inside.4048
  br i1 %descriptor.range.valid.4050, label %descriptor.valid.4052, label %descriptor.invalid.4053
descriptor.invalid.4053:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4052:
  %descriptor.initialized.status.4054 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4038, i32 %local.check.extent.4039)
  %helper.ok.4055 = icmp eq i32 %descriptor.initialized.status.4054, 0
  br i1 %helper.ok.4055, label %helper.continue.4056, label %frame.failure.0
helper.continue.4056:
  br label %local.descriptor.checked.4037
local.descriptor.inactive.4036:
  br label %local.descriptor.checked.4037
local.descriptor.checked.4037:
  %local.is.active.4057 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.4057, label %local.descriptor.active.4058, label %local.descriptor.inactive.4059
local.descriptor.active.4058:
  %local.check.offset.4061 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.4062 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.4063 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.4064 = load i32, ptr %local.owner.end.12, align 4
  %context.field.4065 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4066 = load i32, ptr %context.field.4065, align 4
  %stack.sub.4069 = sub i32 %local.check.owner.end.4064, %local.check.offset.4061
  %descriptor.owner.inside.4067 = icmp ule i32 %local.check.owner.end.4064, %context.value.4066
  %descriptor.offset.inside.4068 = icmp ule i32 %local.check.offset.4061, %local.check.owner.end.4064
  %descriptor.extent.inside.4070 = icmp ule i32 %local.check.extent.4062, %stack.sub.4069
  %descriptor.payload.inside.4071 = icmp ule i32 %local.check.payload.4063, %local.check.extent.4062
  %descriptor.owner.offset.valid.4072 = and i1 %descriptor.owner.inside.4067, %descriptor.offset.inside.4068
  %descriptor.range.inside.4074 = and i1 %descriptor.owner.offset.valid.4072, %descriptor.extent.inside.4070
  %descriptor.range.valid.4073 = and i1 %descriptor.range.inside.4074, %descriptor.payload.inside.4071
  br i1 %descriptor.range.valid.4073, label %descriptor.valid.4075, label %descriptor.invalid.4076
descriptor.invalid.4076:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4075:
  %descriptor.initialized.status.4077 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4061, i32 %local.check.extent.4062)
  %helper.ok.4078 = icmp eq i32 %descriptor.initialized.status.4077, 0
  br i1 %helper.ok.4078, label %helper.continue.4079, label %frame.failure.0
helper.continue.4079:
  br label %local.descriptor.checked.4060
local.descriptor.inactive.4059:
  br label %local.descriptor.checked.4060
local.descriptor.checked.4060:
  %local.is.active.4080 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.4080, label %local.descriptor.active.4081, label %local.descriptor.inactive.4082
local.descriptor.active.4081:
  %local.check.offset.4084 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.4085 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.4086 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.4087 = load i32, ptr %local.owner.end.18, align 4
  %context.field.4088 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4089 = load i32, ptr %context.field.4088, align 4
  %stack.sub.4092 = sub i32 %local.check.owner.end.4087, %local.check.offset.4084
  %descriptor.owner.inside.4090 = icmp ule i32 %local.check.owner.end.4087, %context.value.4089
  %descriptor.offset.inside.4091 = icmp ule i32 %local.check.offset.4084, %local.check.owner.end.4087
  %descriptor.extent.inside.4093 = icmp ule i32 %local.check.extent.4085, %stack.sub.4092
  %descriptor.payload.inside.4094 = icmp ule i32 %local.check.payload.4086, %local.check.extent.4085
  %descriptor.owner.offset.valid.4095 = and i1 %descriptor.owner.inside.4090, %descriptor.offset.inside.4091
  %descriptor.range.inside.4097 = and i1 %descriptor.owner.offset.valid.4095, %descriptor.extent.inside.4093
  %descriptor.range.valid.4096 = and i1 %descriptor.range.inside.4097, %descriptor.payload.inside.4094
  br i1 %descriptor.range.valid.4096, label %descriptor.valid.4098, label %descriptor.invalid.4099
descriptor.invalid.4099:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4098:
  %descriptor.initialized.status.4100 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4084, i32 %local.check.extent.4085)
  %helper.ok.4101 = icmp eq i32 %descriptor.initialized.status.4100, 0
  br i1 %helper.ok.4101, label %helper.continue.4102, label %frame.failure.0
helper.continue.4102:
  br label %local.descriptor.checked.4083
local.descriptor.inactive.4082:
  br label %local.descriptor.checked.4083
local.descriptor.checked.4083:
  %local.is.active.4103 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.4103, label %local.descriptor.active.4104, label %local.descriptor.inactive.4105
local.descriptor.active.4104:
  %local.check.offset.4107 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.4108 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.4109 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.4110 = load i32, ptr %local.owner.end.24, align 4
  %context.field.4111 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4112 = load i32, ptr %context.field.4111, align 4
  %stack.sub.4115 = sub i32 %local.check.owner.end.4110, %local.check.offset.4107
  %descriptor.owner.inside.4113 = icmp ule i32 %local.check.owner.end.4110, %context.value.4112
  %descriptor.offset.inside.4114 = icmp ule i32 %local.check.offset.4107, %local.check.owner.end.4110
  %descriptor.extent.inside.4116 = icmp ule i32 %local.check.extent.4108, %stack.sub.4115
  %descriptor.payload.inside.4117 = icmp ule i32 %local.check.payload.4109, %local.check.extent.4108
  %descriptor.owner.offset.valid.4118 = and i1 %descriptor.owner.inside.4113, %descriptor.offset.inside.4114
  %descriptor.range.inside.4120 = and i1 %descriptor.owner.offset.valid.4118, %descriptor.extent.inside.4116
  %descriptor.range.valid.4119 = and i1 %descriptor.range.inside.4120, %descriptor.payload.inside.4117
  br i1 %descriptor.range.valid.4119, label %descriptor.valid.4121, label %descriptor.invalid.4122
descriptor.invalid.4122:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4121:
  %descriptor.initialized.status.4123 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4107, i32 %local.check.extent.4108)
  %helper.ok.4124 = icmp eq i32 %descriptor.initialized.status.4123, 0
  br i1 %helper.ok.4124, label %helper.continue.4125, label %frame.failure.0
helper.continue.4125:
  br label %local.descriptor.checked.4106
local.descriptor.inactive.4105:
  br label %local.descriptor.checked.4106
local.descriptor.checked.4106:
  %local.is.active.4126 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.4126, label %local.descriptor.active.4127, label %local.descriptor.inactive.4128
local.descriptor.active.4127:
  %local.check.offset.4130 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.4131 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.4132 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.4133 = load i32, ptr %local.owner.end.30, align 4
  %context.field.4134 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4135 = load i32, ptr %context.field.4134, align 4
  %stack.sub.4138 = sub i32 %local.check.owner.end.4133, %local.check.offset.4130
  %descriptor.owner.inside.4136 = icmp ule i32 %local.check.owner.end.4133, %context.value.4135
  %descriptor.offset.inside.4137 = icmp ule i32 %local.check.offset.4130, %local.check.owner.end.4133
  %descriptor.extent.inside.4139 = icmp ule i32 %local.check.extent.4131, %stack.sub.4138
  %descriptor.payload.inside.4140 = icmp ule i32 %local.check.payload.4132, %local.check.extent.4131
  %descriptor.owner.offset.valid.4141 = and i1 %descriptor.owner.inside.4136, %descriptor.offset.inside.4137
  %descriptor.range.inside.4143 = and i1 %descriptor.owner.offset.valid.4141, %descriptor.extent.inside.4139
  %descriptor.range.valid.4142 = and i1 %descriptor.range.inside.4143, %descriptor.payload.inside.4140
  br i1 %descriptor.range.valid.4142, label %descriptor.valid.4144, label %descriptor.invalid.4145
descriptor.invalid.4145:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4144:
  %descriptor.initialized.status.4146 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4130, i32 %local.check.extent.4131)
  %helper.ok.4147 = icmp eq i32 %descriptor.initialized.status.4146, 0
  br i1 %helper.ok.4147, label %helper.continue.4148, label %frame.failure.0
helper.continue.4148:
  br label %local.descriptor.checked.4129
local.descriptor.inactive.4128:
  br label %local.descriptor.checked.4129
local.descriptor.checked.4129:
  %local.is.active.4149 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.4149, label %local.descriptor.active.4150, label %local.descriptor.inactive.4151
local.descriptor.active.4150:
  %local.check.offset.4153 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.4154 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.4155 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.4156 = load i32, ptr %local.owner.end.36, align 4
  %context.field.4157 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4158 = load i32, ptr %context.field.4157, align 4
  %stack.sub.4161 = sub i32 %local.check.owner.end.4156, %local.check.offset.4153
  %descriptor.owner.inside.4159 = icmp ule i32 %local.check.owner.end.4156, %context.value.4158
  %descriptor.offset.inside.4160 = icmp ule i32 %local.check.offset.4153, %local.check.owner.end.4156
  %descriptor.extent.inside.4162 = icmp ule i32 %local.check.extent.4154, %stack.sub.4161
  %descriptor.payload.inside.4163 = icmp ule i32 %local.check.payload.4155, %local.check.extent.4154
  %descriptor.owner.offset.valid.4164 = and i1 %descriptor.owner.inside.4159, %descriptor.offset.inside.4160
  %descriptor.range.inside.4166 = and i1 %descriptor.owner.offset.valid.4164, %descriptor.extent.inside.4162
  %descriptor.range.valid.4165 = and i1 %descriptor.range.inside.4166, %descriptor.payload.inside.4163
  br i1 %descriptor.range.valid.4165, label %descriptor.valid.4167, label %descriptor.invalid.4168
descriptor.invalid.4168:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4167:
  %descriptor.initialized.status.4169 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4153, i32 %local.check.extent.4154)
  %helper.ok.4170 = icmp eq i32 %descriptor.initialized.status.4169, 0
  br i1 %helper.ok.4170, label %helper.continue.4171, label %frame.failure.0
helper.continue.4171:
  br label %local.descriptor.checked.4152
local.descriptor.inactive.4151:
  br label %local.descriptor.checked.4152
local.descriptor.checked.4152:
  %step.status.4172 = call i32 @al_owning_charge_step(ptr %ctx, i32 29)
  %helper.ok.4173 = icmp eq i32 %step.status.4172, 0
  br i1 %helper.ok.4173, label %helper.continue.4174, label %frame.failure.0
helper.continue.4174:
  %local.resolved.offset.4175 = load i32, ptr %local.offset.33, align 4
  %local.resolved.extent.4176 = load i32, ptr %local.extent.34, align 4
  %local.resolved.payload.4177 = load i32, ptr %local.payload.35, align 4
  %local.resolved.owner.end.4178 = load i32, ptr %local.owner.end.36, align 4
  %context.field.4179 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4180 = load i32, ptr %context.field.4179, align 4
  %stack.sub.4183 = sub i32 %local.resolved.owner.end.4178, %local.resolved.offset.4175
  %descriptor.owner.inside.4181 = icmp ule i32 %local.resolved.owner.end.4178, %context.value.4180
  %descriptor.offset.inside.4182 = icmp ule i32 %local.resolved.offset.4175, %local.resolved.owner.end.4178
  %descriptor.extent.inside.4184 = icmp ule i32 %local.resolved.extent.4176, %stack.sub.4183
  %descriptor.payload.inside.4185 = icmp ule i32 %local.resolved.payload.4177, %local.resolved.extent.4176
  %descriptor.owner.offset.valid.4186 = and i1 %descriptor.owner.inside.4181, %descriptor.offset.inside.4182
  %descriptor.range.inside.4188 = and i1 %descriptor.owner.offset.valid.4186, %descriptor.extent.inside.4184
  %descriptor.range.valid.4187 = and i1 %descriptor.range.inside.4188, %descriptor.payload.inside.4185
  %descriptor.type.valid.4189 = icmp eq i32 12, 12
  %descriptor.valid.4190 = and i1 %descriptor.range.valid.4187, %descriptor.type.valid.4189
  br i1 %descriptor.valid.4190, label %descriptor.valid.4191, label %descriptor.invalid.4192
descriptor.invalid.4192:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4191:
  %descriptor.initialized.status.4193 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.4175, i32 %local.resolved.extent.4176)
  %helper.ok.4194 = icmp eq i32 %descriptor.initialized.status.4193, 0
  br i1 %helper.ok.4194, label %helper.continue.4195, label %frame.failure.0
helper.continue.4195:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %local.resolved.offset.4175, i32 20, i32 %local.resolved.payload.4177, i32 %local.resolved.owner.end.4178, i32 %local.resolved.extent.4176)
  %context.field.4196 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4197 = load i32, ptr %context.field.4196, align 4
  %runtime.ok.4198 = icmp eq i32 %context.value.4197, 0
  br i1 %runtime.ok.4198, label %runtime.continue.4199, label %frame.failure.0
runtime.continue.4199:
  %context.field.4200 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4201 = load i32, ptr %context.field.4200, align 4
  %stack.sub.4204 = sub i32 %local.resolved.owner.end.4178, %local.resolved.offset.4175
  %descriptor.owner.inside.4202 = icmp ule i32 %local.resolved.owner.end.4178, %context.value.4201
  %descriptor.offset.inside.4203 = icmp ule i32 %local.resolved.offset.4175, %local.resolved.owner.end.4178
  %descriptor.extent.inside.4205 = icmp ule i32 %local.resolved.extent.4176, %stack.sub.4204
  %descriptor.payload.inside.4206 = icmp ule i32 %local.resolved.payload.4177, %local.resolved.extent.4176
  %descriptor.owner.offset.valid.4207 = and i1 %descriptor.owner.inside.4202, %descriptor.offset.inside.4203
  %descriptor.range.inside.4209 = and i1 %descriptor.owner.offset.valid.4207, %descriptor.extent.inside.4205
  %descriptor.range.valid.4208 = and i1 %descriptor.range.inside.4209, %descriptor.payload.inside.4206
  %descriptor.type.valid.4210 = icmp eq i32 12, 12
  %descriptor.valid.4211 = and i1 %descriptor.range.valid.4208, %descriptor.type.valid.4210
  br i1 %descriptor.valid.4211, label %descriptor.valid.4212, label %descriptor.invalid.4213
descriptor.invalid.4213:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4212:
  %descriptor.initialized.status.4214 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.4175, i32 %local.resolved.extent.4176)
  %helper.ok.4215 = icmp eq i32 %descriptor.initialized.status.4214, 0
  br i1 %helper.ok.4215, label %helper.continue.4216, label %frame.failure.0
helper.continue.4216:
  %local.is.active.4217 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.4217, label %local.descriptor.active.4218, label %local.descriptor.inactive.4219
local.descriptor.active.4218:
  %local.check.offset.4221 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.4222 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.4223 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.4224 = load i32, ptr %local.owner.end.6, align 4
  %context.field.4225 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4226 = load i32, ptr %context.field.4225, align 4
  %stack.sub.4229 = sub i32 %local.check.owner.end.4224, %local.check.offset.4221
  %descriptor.owner.inside.4227 = icmp ule i32 %local.check.owner.end.4224, %context.value.4226
  %descriptor.offset.inside.4228 = icmp ule i32 %local.check.offset.4221, %local.check.owner.end.4224
  %descriptor.extent.inside.4230 = icmp ule i32 %local.check.extent.4222, %stack.sub.4229
  %descriptor.payload.inside.4231 = icmp ule i32 %local.check.payload.4223, %local.check.extent.4222
  %descriptor.owner.offset.valid.4232 = and i1 %descriptor.owner.inside.4227, %descriptor.offset.inside.4228
  %descriptor.range.inside.4234 = and i1 %descriptor.owner.offset.valid.4232, %descriptor.extent.inside.4230
  %descriptor.range.valid.4233 = and i1 %descriptor.range.inside.4234, %descriptor.payload.inside.4231
  br i1 %descriptor.range.valid.4233, label %descriptor.valid.4235, label %descriptor.invalid.4236
descriptor.invalid.4236:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4235:
  %descriptor.initialized.status.4237 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4221, i32 %local.check.extent.4222)
  %helper.ok.4238 = icmp eq i32 %descriptor.initialized.status.4237, 0
  br i1 %helper.ok.4238, label %helper.continue.4239, label %frame.failure.0
helper.continue.4239:
  br label %local.descriptor.checked.4220
local.descriptor.inactive.4219:
  br label %local.descriptor.checked.4220
local.descriptor.checked.4220:
  %local.is.active.4240 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.4240, label %local.descriptor.active.4241, label %local.descriptor.inactive.4242
local.descriptor.active.4241:
  %local.check.offset.4244 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.4245 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.4246 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.4247 = load i32, ptr %local.owner.end.12, align 4
  %context.field.4248 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4249 = load i32, ptr %context.field.4248, align 4
  %stack.sub.4252 = sub i32 %local.check.owner.end.4247, %local.check.offset.4244
  %descriptor.owner.inside.4250 = icmp ule i32 %local.check.owner.end.4247, %context.value.4249
  %descriptor.offset.inside.4251 = icmp ule i32 %local.check.offset.4244, %local.check.owner.end.4247
  %descriptor.extent.inside.4253 = icmp ule i32 %local.check.extent.4245, %stack.sub.4252
  %descriptor.payload.inside.4254 = icmp ule i32 %local.check.payload.4246, %local.check.extent.4245
  %descriptor.owner.offset.valid.4255 = and i1 %descriptor.owner.inside.4250, %descriptor.offset.inside.4251
  %descriptor.range.inside.4257 = and i1 %descriptor.owner.offset.valid.4255, %descriptor.extent.inside.4253
  %descriptor.range.valid.4256 = and i1 %descriptor.range.inside.4257, %descriptor.payload.inside.4254
  br i1 %descriptor.range.valid.4256, label %descriptor.valid.4258, label %descriptor.invalid.4259
descriptor.invalid.4259:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4258:
  %descriptor.initialized.status.4260 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4244, i32 %local.check.extent.4245)
  %helper.ok.4261 = icmp eq i32 %descriptor.initialized.status.4260, 0
  br i1 %helper.ok.4261, label %helper.continue.4262, label %frame.failure.0
helper.continue.4262:
  br label %local.descriptor.checked.4243
local.descriptor.inactive.4242:
  br label %local.descriptor.checked.4243
local.descriptor.checked.4243:
  %local.is.active.4263 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.4263, label %local.descriptor.active.4264, label %local.descriptor.inactive.4265
local.descriptor.active.4264:
  %local.check.offset.4267 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.4268 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.4269 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.4270 = load i32, ptr %local.owner.end.18, align 4
  %context.field.4271 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4272 = load i32, ptr %context.field.4271, align 4
  %stack.sub.4275 = sub i32 %local.check.owner.end.4270, %local.check.offset.4267
  %descriptor.owner.inside.4273 = icmp ule i32 %local.check.owner.end.4270, %context.value.4272
  %descriptor.offset.inside.4274 = icmp ule i32 %local.check.offset.4267, %local.check.owner.end.4270
  %descriptor.extent.inside.4276 = icmp ule i32 %local.check.extent.4268, %stack.sub.4275
  %descriptor.payload.inside.4277 = icmp ule i32 %local.check.payload.4269, %local.check.extent.4268
  %descriptor.owner.offset.valid.4278 = and i1 %descriptor.owner.inside.4273, %descriptor.offset.inside.4274
  %descriptor.range.inside.4280 = and i1 %descriptor.owner.offset.valid.4278, %descriptor.extent.inside.4276
  %descriptor.range.valid.4279 = and i1 %descriptor.range.inside.4280, %descriptor.payload.inside.4277
  br i1 %descriptor.range.valid.4279, label %descriptor.valid.4281, label %descriptor.invalid.4282
descriptor.invalid.4282:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4281:
  %descriptor.initialized.status.4283 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4267, i32 %local.check.extent.4268)
  %helper.ok.4284 = icmp eq i32 %descriptor.initialized.status.4283, 0
  br i1 %helper.ok.4284, label %helper.continue.4285, label %frame.failure.0
helper.continue.4285:
  br label %local.descriptor.checked.4266
local.descriptor.inactive.4265:
  br label %local.descriptor.checked.4266
local.descriptor.checked.4266:
  %local.is.active.4286 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.4286, label %local.descriptor.active.4287, label %local.descriptor.inactive.4288
local.descriptor.active.4287:
  %local.check.offset.4290 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.4291 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.4292 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.4293 = load i32, ptr %local.owner.end.24, align 4
  %context.field.4294 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4295 = load i32, ptr %context.field.4294, align 4
  %stack.sub.4298 = sub i32 %local.check.owner.end.4293, %local.check.offset.4290
  %descriptor.owner.inside.4296 = icmp ule i32 %local.check.owner.end.4293, %context.value.4295
  %descriptor.offset.inside.4297 = icmp ule i32 %local.check.offset.4290, %local.check.owner.end.4293
  %descriptor.extent.inside.4299 = icmp ule i32 %local.check.extent.4291, %stack.sub.4298
  %descriptor.payload.inside.4300 = icmp ule i32 %local.check.payload.4292, %local.check.extent.4291
  %descriptor.owner.offset.valid.4301 = and i1 %descriptor.owner.inside.4296, %descriptor.offset.inside.4297
  %descriptor.range.inside.4303 = and i1 %descriptor.owner.offset.valid.4301, %descriptor.extent.inside.4299
  %descriptor.range.valid.4302 = and i1 %descriptor.range.inside.4303, %descriptor.payload.inside.4300
  br i1 %descriptor.range.valid.4302, label %descriptor.valid.4304, label %descriptor.invalid.4305
descriptor.invalid.4305:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4304:
  %descriptor.initialized.status.4306 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4290, i32 %local.check.extent.4291)
  %helper.ok.4307 = icmp eq i32 %descriptor.initialized.status.4306, 0
  br i1 %helper.ok.4307, label %helper.continue.4308, label %frame.failure.0
helper.continue.4308:
  br label %local.descriptor.checked.4289
local.descriptor.inactive.4288:
  br label %local.descriptor.checked.4289
local.descriptor.checked.4289:
  %local.is.active.4309 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.4309, label %local.descriptor.active.4310, label %local.descriptor.inactive.4311
local.descriptor.active.4310:
  %local.check.offset.4313 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.4314 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.4315 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.4316 = load i32, ptr %local.owner.end.30, align 4
  %context.field.4317 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4318 = load i32, ptr %context.field.4317, align 4
  %stack.sub.4321 = sub i32 %local.check.owner.end.4316, %local.check.offset.4313
  %descriptor.owner.inside.4319 = icmp ule i32 %local.check.owner.end.4316, %context.value.4318
  %descriptor.offset.inside.4320 = icmp ule i32 %local.check.offset.4313, %local.check.owner.end.4316
  %descriptor.extent.inside.4322 = icmp ule i32 %local.check.extent.4314, %stack.sub.4321
  %descriptor.payload.inside.4323 = icmp ule i32 %local.check.payload.4315, %local.check.extent.4314
  %descriptor.owner.offset.valid.4324 = and i1 %descriptor.owner.inside.4319, %descriptor.offset.inside.4320
  %descriptor.range.inside.4326 = and i1 %descriptor.owner.offset.valid.4324, %descriptor.extent.inside.4322
  %descriptor.range.valid.4325 = and i1 %descriptor.range.inside.4326, %descriptor.payload.inside.4323
  br i1 %descriptor.range.valid.4325, label %descriptor.valid.4327, label %descriptor.invalid.4328
descriptor.invalid.4328:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4327:
  %descriptor.initialized.status.4329 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4313, i32 %local.check.extent.4314)
  %helper.ok.4330 = icmp eq i32 %descriptor.initialized.status.4329, 0
  br i1 %helper.ok.4330, label %helper.continue.4331, label %frame.failure.0
helper.continue.4331:
  br label %local.descriptor.checked.4312
local.descriptor.inactive.4311:
  br label %local.descriptor.checked.4312
local.descriptor.checked.4312:
  %local.is.active.4332 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.4332, label %local.descriptor.active.4333, label %local.descriptor.inactive.4334
local.descriptor.active.4333:
  %local.check.offset.4336 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.4337 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.4338 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.4339 = load i32, ptr %local.owner.end.36, align 4
  %context.field.4340 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4341 = load i32, ptr %context.field.4340, align 4
  %stack.sub.4344 = sub i32 %local.check.owner.end.4339, %local.check.offset.4336
  %descriptor.owner.inside.4342 = icmp ule i32 %local.check.owner.end.4339, %context.value.4341
  %descriptor.offset.inside.4343 = icmp ule i32 %local.check.offset.4336, %local.check.owner.end.4339
  %descriptor.extent.inside.4345 = icmp ule i32 %local.check.extent.4337, %stack.sub.4344
  %descriptor.payload.inside.4346 = icmp ule i32 %local.check.payload.4338, %local.check.extent.4337
  %descriptor.owner.offset.valid.4347 = and i1 %descriptor.owner.inside.4342, %descriptor.offset.inside.4343
  %descriptor.range.inside.4349 = and i1 %descriptor.owner.offset.valid.4347, %descriptor.extent.inside.4345
  %descriptor.range.valid.4348 = and i1 %descriptor.range.inside.4349, %descriptor.payload.inside.4346
  br i1 %descriptor.range.valid.4348, label %descriptor.valid.4350, label %descriptor.invalid.4351
descriptor.invalid.4351:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4350:
  %descriptor.initialized.status.4352 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4336, i32 %local.check.extent.4337)
  %helper.ok.4353 = icmp eq i32 %descriptor.initialized.status.4352, 0
  br i1 %helper.ok.4353, label %helper.continue.4354, label %frame.failure.0
helper.continue.4354:
  br label %local.descriptor.checked.4335
local.descriptor.inactive.4334:
  br label %local.descriptor.checked.4335
local.descriptor.checked.4335:
  %step.status.4355 = call i32 @al_owning_charge_step(ptr %ctx, i32 30)
  %helper.ok.4356 = icmp eq i32 %step.status.4355, 0
  br i1 %helper.ok.4356, label %helper.continue.4357, label %frame.failure.0
helper.continue.4357:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 12, i32 %local.resolved.offset.4175, i32 %local.resolved.extent.4176, i32 %local.resolved.payload.4177, i32 0, i32 0)
  %context.field.4358 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4359 = load i32, ptr %context.field.4358, align 4
  %runtime.ok.4360 = icmp eq i32 %context.value.4359, 0
  br i1 %runtime.ok.4360, label %runtime.continue.4361, label %frame.failure.0
runtime.continue.4361:
  %local.is.active.4362 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.4362, label %local.descriptor.active.4363, label %local.descriptor.inactive.4364
local.descriptor.active.4363:
  %local.check.offset.4366 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.4367 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.4368 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.4369 = load i32, ptr %local.owner.end.6, align 4
  %context.field.4370 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4371 = load i32, ptr %context.field.4370, align 4
  %stack.sub.4374 = sub i32 %local.check.owner.end.4369, %local.check.offset.4366
  %descriptor.owner.inside.4372 = icmp ule i32 %local.check.owner.end.4369, %context.value.4371
  %descriptor.offset.inside.4373 = icmp ule i32 %local.check.offset.4366, %local.check.owner.end.4369
  %descriptor.extent.inside.4375 = icmp ule i32 %local.check.extent.4367, %stack.sub.4374
  %descriptor.payload.inside.4376 = icmp ule i32 %local.check.payload.4368, %local.check.extent.4367
  %descriptor.owner.offset.valid.4377 = and i1 %descriptor.owner.inside.4372, %descriptor.offset.inside.4373
  %descriptor.range.inside.4379 = and i1 %descriptor.owner.offset.valid.4377, %descriptor.extent.inside.4375
  %descriptor.range.valid.4378 = and i1 %descriptor.range.inside.4379, %descriptor.payload.inside.4376
  br i1 %descriptor.range.valid.4378, label %descriptor.valid.4380, label %descriptor.invalid.4381
descriptor.invalid.4381:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4380:
  %descriptor.initialized.status.4382 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4366, i32 %local.check.extent.4367)
  %helper.ok.4383 = icmp eq i32 %descriptor.initialized.status.4382, 0
  br i1 %helper.ok.4383, label %helper.continue.4384, label %frame.failure.0
helper.continue.4384:
  br label %local.descriptor.checked.4365
local.descriptor.inactive.4364:
  br label %local.descriptor.checked.4365
local.descriptor.checked.4365:
  %local.is.active.4385 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.4385, label %local.descriptor.active.4386, label %local.descriptor.inactive.4387
local.descriptor.active.4386:
  %local.check.offset.4389 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.4390 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.4391 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.4392 = load i32, ptr %local.owner.end.12, align 4
  %context.field.4393 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4394 = load i32, ptr %context.field.4393, align 4
  %stack.sub.4397 = sub i32 %local.check.owner.end.4392, %local.check.offset.4389
  %descriptor.owner.inside.4395 = icmp ule i32 %local.check.owner.end.4392, %context.value.4394
  %descriptor.offset.inside.4396 = icmp ule i32 %local.check.offset.4389, %local.check.owner.end.4392
  %descriptor.extent.inside.4398 = icmp ule i32 %local.check.extent.4390, %stack.sub.4397
  %descriptor.payload.inside.4399 = icmp ule i32 %local.check.payload.4391, %local.check.extent.4390
  %descriptor.owner.offset.valid.4400 = and i1 %descriptor.owner.inside.4395, %descriptor.offset.inside.4396
  %descriptor.range.inside.4402 = and i1 %descriptor.owner.offset.valid.4400, %descriptor.extent.inside.4398
  %descriptor.range.valid.4401 = and i1 %descriptor.range.inside.4402, %descriptor.payload.inside.4399
  br i1 %descriptor.range.valid.4401, label %descriptor.valid.4403, label %descriptor.invalid.4404
descriptor.invalid.4404:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4403:
  %descriptor.initialized.status.4405 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4389, i32 %local.check.extent.4390)
  %helper.ok.4406 = icmp eq i32 %descriptor.initialized.status.4405, 0
  br i1 %helper.ok.4406, label %helper.continue.4407, label %frame.failure.0
helper.continue.4407:
  br label %local.descriptor.checked.4388
local.descriptor.inactive.4387:
  br label %local.descriptor.checked.4388
local.descriptor.checked.4388:
  %local.is.active.4408 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.4408, label %local.descriptor.active.4409, label %local.descriptor.inactive.4410
local.descriptor.active.4409:
  %local.check.offset.4412 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.4413 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.4414 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.4415 = load i32, ptr %local.owner.end.18, align 4
  %context.field.4416 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4417 = load i32, ptr %context.field.4416, align 4
  %stack.sub.4420 = sub i32 %local.check.owner.end.4415, %local.check.offset.4412
  %descriptor.owner.inside.4418 = icmp ule i32 %local.check.owner.end.4415, %context.value.4417
  %descriptor.offset.inside.4419 = icmp ule i32 %local.check.offset.4412, %local.check.owner.end.4415
  %descriptor.extent.inside.4421 = icmp ule i32 %local.check.extent.4413, %stack.sub.4420
  %descriptor.payload.inside.4422 = icmp ule i32 %local.check.payload.4414, %local.check.extent.4413
  %descriptor.owner.offset.valid.4423 = and i1 %descriptor.owner.inside.4418, %descriptor.offset.inside.4419
  %descriptor.range.inside.4425 = and i1 %descriptor.owner.offset.valid.4423, %descriptor.extent.inside.4421
  %descriptor.range.valid.4424 = and i1 %descriptor.range.inside.4425, %descriptor.payload.inside.4422
  br i1 %descriptor.range.valid.4424, label %descriptor.valid.4426, label %descriptor.invalid.4427
descriptor.invalid.4427:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4426:
  %descriptor.initialized.status.4428 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4412, i32 %local.check.extent.4413)
  %helper.ok.4429 = icmp eq i32 %descriptor.initialized.status.4428, 0
  br i1 %helper.ok.4429, label %helper.continue.4430, label %frame.failure.0
helper.continue.4430:
  br label %local.descriptor.checked.4411
local.descriptor.inactive.4410:
  br label %local.descriptor.checked.4411
local.descriptor.checked.4411:
  %local.is.active.4431 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.4431, label %local.descriptor.active.4432, label %local.descriptor.inactive.4433
local.descriptor.active.4432:
  %local.check.offset.4435 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.4436 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.4437 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.4438 = load i32, ptr %local.owner.end.24, align 4
  %context.field.4439 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4440 = load i32, ptr %context.field.4439, align 4
  %stack.sub.4443 = sub i32 %local.check.owner.end.4438, %local.check.offset.4435
  %descriptor.owner.inside.4441 = icmp ule i32 %local.check.owner.end.4438, %context.value.4440
  %descriptor.offset.inside.4442 = icmp ule i32 %local.check.offset.4435, %local.check.owner.end.4438
  %descriptor.extent.inside.4444 = icmp ule i32 %local.check.extent.4436, %stack.sub.4443
  %descriptor.payload.inside.4445 = icmp ule i32 %local.check.payload.4437, %local.check.extent.4436
  %descriptor.owner.offset.valid.4446 = and i1 %descriptor.owner.inside.4441, %descriptor.offset.inside.4442
  %descriptor.range.inside.4448 = and i1 %descriptor.owner.offset.valid.4446, %descriptor.extent.inside.4444
  %descriptor.range.valid.4447 = and i1 %descriptor.range.inside.4448, %descriptor.payload.inside.4445
  br i1 %descriptor.range.valid.4447, label %descriptor.valid.4449, label %descriptor.invalid.4450
descriptor.invalid.4450:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4449:
  %descriptor.initialized.status.4451 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4435, i32 %local.check.extent.4436)
  %helper.ok.4452 = icmp eq i32 %descriptor.initialized.status.4451, 0
  br i1 %helper.ok.4452, label %helper.continue.4453, label %frame.failure.0
helper.continue.4453:
  br label %local.descriptor.checked.4434
local.descriptor.inactive.4433:
  br label %local.descriptor.checked.4434
local.descriptor.checked.4434:
  %local.is.active.4454 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.4454, label %local.descriptor.active.4455, label %local.descriptor.inactive.4456
local.descriptor.active.4455:
  %local.check.offset.4458 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.4459 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.4460 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.4461 = load i32, ptr %local.owner.end.30, align 4
  %context.field.4462 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4463 = load i32, ptr %context.field.4462, align 4
  %stack.sub.4466 = sub i32 %local.check.owner.end.4461, %local.check.offset.4458
  %descriptor.owner.inside.4464 = icmp ule i32 %local.check.owner.end.4461, %context.value.4463
  %descriptor.offset.inside.4465 = icmp ule i32 %local.check.offset.4458, %local.check.owner.end.4461
  %descriptor.extent.inside.4467 = icmp ule i32 %local.check.extent.4459, %stack.sub.4466
  %descriptor.payload.inside.4468 = icmp ule i32 %local.check.payload.4460, %local.check.extent.4459
  %descriptor.owner.offset.valid.4469 = and i1 %descriptor.owner.inside.4464, %descriptor.offset.inside.4465
  %descriptor.range.inside.4471 = and i1 %descriptor.owner.offset.valid.4469, %descriptor.extent.inside.4467
  %descriptor.range.valid.4470 = and i1 %descriptor.range.inside.4471, %descriptor.payload.inside.4468
  br i1 %descriptor.range.valid.4470, label %descriptor.valid.4472, label %descriptor.invalid.4473
descriptor.invalid.4473:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4472:
  %descriptor.initialized.status.4474 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4458, i32 %local.check.extent.4459)
  %helper.ok.4475 = icmp eq i32 %descriptor.initialized.status.4474, 0
  br i1 %helper.ok.4475, label %helper.continue.4476, label %frame.failure.0
helper.continue.4476:
  br label %local.descriptor.checked.4457
local.descriptor.inactive.4456:
  br label %local.descriptor.checked.4457
local.descriptor.checked.4457:
  %local.is.active.4477 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.4477, label %local.descriptor.active.4478, label %local.descriptor.inactive.4479
local.descriptor.active.4478:
  %local.check.offset.4481 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.4482 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.4483 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.4484 = load i32, ptr %local.owner.end.36, align 4
  %context.field.4485 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4486 = load i32, ptr %context.field.4485, align 4
  %stack.sub.4489 = sub i32 %local.check.owner.end.4484, %local.check.offset.4481
  %descriptor.owner.inside.4487 = icmp ule i32 %local.check.owner.end.4484, %context.value.4486
  %descriptor.offset.inside.4488 = icmp ule i32 %local.check.offset.4481, %local.check.owner.end.4484
  %descriptor.extent.inside.4490 = icmp ule i32 %local.check.extent.4482, %stack.sub.4489
  %descriptor.payload.inside.4491 = icmp ule i32 %local.check.payload.4483, %local.check.extent.4482
  %descriptor.owner.offset.valid.4492 = and i1 %descriptor.owner.inside.4487, %descriptor.offset.inside.4488
  %descriptor.range.inside.4494 = and i1 %descriptor.owner.offset.valid.4492, %descriptor.extent.inside.4490
  %descriptor.range.valid.4493 = and i1 %descriptor.range.inside.4494, %descriptor.payload.inside.4491
  br i1 %descriptor.range.valid.4493, label %descriptor.valid.4495, label %descriptor.invalid.4496
descriptor.invalid.4496:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4495:
  %descriptor.initialized.status.4497 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4481, i32 %local.check.extent.4482)
  %helper.ok.4498 = icmp eq i32 %descriptor.initialized.status.4497, 0
  br i1 %helper.ok.4498, label %helper.continue.4499, label %frame.failure.0
helper.continue.4499:
  br label %local.descriptor.checked.4480
local.descriptor.inactive.4479:
  br label %local.descriptor.checked.4480
local.descriptor.checked.4480:
  store i1 false, ptr %local.active.32, align 1
  store i32 0, ptr %local.offset.33, align 4
  store i32 0, ptr %local.extent.34, align 4
  store i32 0, ptr %local.payload.35, align 4
  store i32 0, ptr %local.owner.end.36, align 4
  store i32 0, ptr %local.type.37, align 4
  store i1 false, ptr %local.active.26, align 1
  store i32 0, ptr %local.offset.27, align 4
  store i32 0, ptr %local.extent.28, align 4
  store i32 0, ptr %local.payload.29, align 4
  store i32 0, ptr %local.owner.end.30, align 4
  store i32 0, ptr %local.type.31, align 4
  store i1 false, ptr %local.active.20, align 1
  store i32 0, ptr %local.offset.21, align 4
  store i32 0, ptr %local.extent.22, align 4
  store i32 0, ptr %local.payload.23, align 4
  store i32 0, ptr %local.owner.end.24, align 4
  store i32 0, ptr %local.type.25, align 4
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %context.field.4500 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4501 = load i32, ptr %context.field.4500, align 4
  %stack.sub.4502 = sub i32 %context.value.4501, %context.value.233
  call void @al_owning_record_layout(ptr %ctx, i32 18, i32 0, i32 %context.value.233, i32 %stack.sub.4502, i32 0, i32 0, i32 0)
  %context.field.4503 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4504 = load i32, ptr %context.field.4503, align 4
  %runtime.ok.4505 = icmp eq i32 %context.value.4504, 0
  br i1 %runtime.ok.4505, label %runtime.continue.4506, label %frame.failure.0
runtime.continue.4506:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.233, i32 0, i32 0, i32 0)
  %context.field.4507 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4508 = load i32, ptr %context.field.4507, align 4
  %runtime.ok.4509 = icmp eq i32 %context.value.4508, 0
  br i1 %runtime.ok.4509, label %runtime.continue.4510, label %frame.failure.0
runtime.continue.4510:
  %local.is.active.4511 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.4511, label %local.descriptor.active.4512, label %local.descriptor.inactive.4513
local.descriptor.active.4512:
  %local.check.offset.4515 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.4516 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.4517 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.4518 = load i32, ptr %local.owner.end.6, align 4
  %context.field.4519 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4520 = load i32, ptr %context.field.4519, align 4
  %stack.sub.4523 = sub i32 %local.check.owner.end.4518, %local.check.offset.4515
  %descriptor.owner.inside.4521 = icmp ule i32 %local.check.owner.end.4518, %context.value.4520
  %descriptor.offset.inside.4522 = icmp ule i32 %local.check.offset.4515, %local.check.owner.end.4518
  %descriptor.extent.inside.4524 = icmp ule i32 %local.check.extent.4516, %stack.sub.4523
  %descriptor.payload.inside.4525 = icmp ule i32 %local.check.payload.4517, %local.check.extent.4516
  %descriptor.owner.offset.valid.4526 = and i1 %descriptor.owner.inside.4521, %descriptor.offset.inside.4522
  %descriptor.range.inside.4528 = and i1 %descriptor.owner.offset.valid.4526, %descriptor.extent.inside.4524
  %descriptor.range.valid.4527 = and i1 %descriptor.range.inside.4528, %descriptor.payload.inside.4525
  br i1 %descriptor.range.valid.4527, label %descriptor.valid.4529, label %descriptor.invalid.4530
descriptor.invalid.4530:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4529:
  %descriptor.initialized.status.4531 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4515, i32 %local.check.extent.4516)
  %helper.ok.4532 = icmp eq i32 %descriptor.initialized.status.4531, 0
  br i1 %helper.ok.4532, label %helper.continue.4533, label %frame.failure.0
helper.continue.4533:
  br label %local.descriptor.checked.4514
local.descriptor.inactive.4513:
  br label %local.descriptor.checked.4514
local.descriptor.checked.4514:
  %local.is.active.4534 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.4534, label %local.descriptor.active.4535, label %local.descriptor.inactive.4536
local.descriptor.active.4535:
  %local.check.offset.4538 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.4539 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.4540 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.4541 = load i32, ptr %local.owner.end.12, align 4
  %context.field.4542 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4543 = load i32, ptr %context.field.4542, align 4
  %stack.sub.4546 = sub i32 %local.check.owner.end.4541, %local.check.offset.4538
  %descriptor.owner.inside.4544 = icmp ule i32 %local.check.owner.end.4541, %context.value.4543
  %descriptor.offset.inside.4545 = icmp ule i32 %local.check.offset.4538, %local.check.owner.end.4541
  %descriptor.extent.inside.4547 = icmp ule i32 %local.check.extent.4539, %stack.sub.4546
  %descriptor.payload.inside.4548 = icmp ule i32 %local.check.payload.4540, %local.check.extent.4539
  %descriptor.owner.offset.valid.4549 = and i1 %descriptor.owner.inside.4544, %descriptor.offset.inside.4545
  %descriptor.range.inside.4551 = and i1 %descriptor.owner.offset.valid.4549, %descriptor.extent.inside.4547
  %descriptor.range.valid.4550 = and i1 %descriptor.range.inside.4551, %descriptor.payload.inside.4548
  br i1 %descriptor.range.valid.4550, label %descriptor.valid.4552, label %descriptor.invalid.4553
descriptor.invalid.4553:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4552:
  %descriptor.initialized.status.4554 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4538, i32 %local.check.extent.4539)
  %helper.ok.4555 = icmp eq i32 %descriptor.initialized.status.4554, 0
  br i1 %helper.ok.4555, label %helper.continue.4556, label %frame.failure.0
helper.continue.4556:
  br label %local.descriptor.checked.4537
local.descriptor.inactive.4536:
  br label %local.descriptor.checked.4537
local.descriptor.checked.4537:
  %local.is.active.4557 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.4557, label %local.descriptor.active.4558, label %local.descriptor.inactive.4559
local.descriptor.active.4558:
  %local.check.offset.4561 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.4562 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.4563 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.4564 = load i32, ptr %local.owner.end.18, align 4
  %context.field.4565 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4566 = load i32, ptr %context.field.4565, align 4
  %stack.sub.4569 = sub i32 %local.check.owner.end.4564, %local.check.offset.4561
  %descriptor.owner.inside.4567 = icmp ule i32 %local.check.owner.end.4564, %context.value.4566
  %descriptor.offset.inside.4568 = icmp ule i32 %local.check.offset.4561, %local.check.owner.end.4564
  %descriptor.extent.inside.4570 = icmp ule i32 %local.check.extent.4562, %stack.sub.4569
  %descriptor.payload.inside.4571 = icmp ule i32 %local.check.payload.4563, %local.check.extent.4562
  %descriptor.owner.offset.valid.4572 = and i1 %descriptor.owner.inside.4567, %descriptor.offset.inside.4568
  %descriptor.range.inside.4574 = and i1 %descriptor.owner.offset.valid.4572, %descriptor.extent.inside.4570
  %descriptor.range.valid.4573 = and i1 %descriptor.range.inside.4574, %descriptor.payload.inside.4571
  br i1 %descriptor.range.valid.4573, label %descriptor.valid.4575, label %descriptor.invalid.4576
descriptor.invalid.4576:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4575:
  %descriptor.initialized.status.4577 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4561, i32 %local.check.extent.4562)
  %helper.ok.4578 = icmp eq i32 %descriptor.initialized.status.4577, 0
  br i1 %helper.ok.4578, label %helper.continue.4579, label %frame.failure.0
helper.continue.4579:
  br label %local.descriptor.checked.4560
local.descriptor.inactive.4559:
  br label %local.descriptor.checked.4560
local.descriptor.checked.4560:
  %local.is.active.4580 = load i1, ptr %local.active.20, align 1
  br i1 %local.is.active.4580, label %local.descriptor.active.4581, label %local.descriptor.inactive.4582
local.descriptor.active.4581:
  %local.check.offset.4584 = load i32, ptr %local.offset.21, align 4
  %local.check.extent.4585 = load i32, ptr %local.extent.22, align 4
  %local.check.payload.4586 = load i32, ptr %local.payload.23, align 4
  %local.check.owner.end.4587 = load i32, ptr %local.owner.end.24, align 4
  %context.field.4588 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4589 = load i32, ptr %context.field.4588, align 4
  %stack.sub.4592 = sub i32 %local.check.owner.end.4587, %local.check.offset.4584
  %descriptor.owner.inside.4590 = icmp ule i32 %local.check.owner.end.4587, %context.value.4589
  %descriptor.offset.inside.4591 = icmp ule i32 %local.check.offset.4584, %local.check.owner.end.4587
  %descriptor.extent.inside.4593 = icmp ule i32 %local.check.extent.4585, %stack.sub.4592
  %descriptor.payload.inside.4594 = icmp ule i32 %local.check.payload.4586, %local.check.extent.4585
  %descriptor.owner.offset.valid.4595 = and i1 %descriptor.owner.inside.4590, %descriptor.offset.inside.4591
  %descriptor.range.inside.4597 = and i1 %descriptor.owner.offset.valid.4595, %descriptor.extent.inside.4593
  %descriptor.range.valid.4596 = and i1 %descriptor.range.inside.4597, %descriptor.payload.inside.4594
  br i1 %descriptor.range.valid.4596, label %descriptor.valid.4598, label %descriptor.invalid.4599
descriptor.invalid.4599:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4598:
  %descriptor.initialized.status.4600 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4584, i32 %local.check.extent.4585)
  %helper.ok.4601 = icmp eq i32 %descriptor.initialized.status.4600, 0
  br i1 %helper.ok.4601, label %helper.continue.4602, label %frame.failure.0
helper.continue.4602:
  br label %local.descriptor.checked.4583
local.descriptor.inactive.4582:
  br label %local.descriptor.checked.4583
local.descriptor.checked.4583:
  %local.is.active.4603 = load i1, ptr %local.active.26, align 1
  br i1 %local.is.active.4603, label %local.descriptor.active.4604, label %local.descriptor.inactive.4605
local.descriptor.active.4604:
  %local.check.offset.4607 = load i32, ptr %local.offset.27, align 4
  %local.check.extent.4608 = load i32, ptr %local.extent.28, align 4
  %local.check.payload.4609 = load i32, ptr %local.payload.29, align 4
  %local.check.owner.end.4610 = load i32, ptr %local.owner.end.30, align 4
  %context.field.4611 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4612 = load i32, ptr %context.field.4611, align 4
  %stack.sub.4615 = sub i32 %local.check.owner.end.4610, %local.check.offset.4607
  %descriptor.owner.inside.4613 = icmp ule i32 %local.check.owner.end.4610, %context.value.4612
  %descriptor.offset.inside.4614 = icmp ule i32 %local.check.offset.4607, %local.check.owner.end.4610
  %descriptor.extent.inside.4616 = icmp ule i32 %local.check.extent.4608, %stack.sub.4615
  %descriptor.payload.inside.4617 = icmp ule i32 %local.check.payload.4609, %local.check.extent.4608
  %descriptor.owner.offset.valid.4618 = and i1 %descriptor.owner.inside.4613, %descriptor.offset.inside.4614
  %descriptor.range.inside.4620 = and i1 %descriptor.owner.offset.valid.4618, %descriptor.extent.inside.4616
  %descriptor.range.valid.4619 = and i1 %descriptor.range.inside.4620, %descriptor.payload.inside.4617
  br i1 %descriptor.range.valid.4619, label %descriptor.valid.4621, label %descriptor.invalid.4622
descriptor.invalid.4622:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4621:
  %descriptor.initialized.status.4623 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4607, i32 %local.check.extent.4608)
  %helper.ok.4624 = icmp eq i32 %descriptor.initialized.status.4623, 0
  br i1 %helper.ok.4624, label %helper.continue.4625, label %frame.failure.0
helper.continue.4625:
  br label %local.descriptor.checked.4606
local.descriptor.inactive.4605:
  br label %local.descriptor.checked.4606
local.descriptor.checked.4606:
  %local.is.active.4626 = load i1, ptr %local.active.32, align 1
  br i1 %local.is.active.4626, label %local.descriptor.active.4627, label %local.descriptor.inactive.4628
local.descriptor.active.4627:
  %local.check.offset.4630 = load i32, ptr %local.offset.33, align 4
  %local.check.extent.4631 = load i32, ptr %local.extent.34, align 4
  %local.check.payload.4632 = load i32, ptr %local.payload.35, align 4
  %local.check.owner.end.4633 = load i32, ptr %local.owner.end.36, align 4
  %context.field.4634 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4635 = load i32, ptr %context.field.4634, align 4
  %stack.sub.4638 = sub i32 %local.check.owner.end.4633, %local.check.offset.4630
  %descriptor.owner.inside.4636 = icmp ule i32 %local.check.owner.end.4633, %context.value.4635
  %descriptor.offset.inside.4637 = icmp ule i32 %local.check.offset.4630, %local.check.owner.end.4633
  %descriptor.extent.inside.4639 = icmp ule i32 %local.check.extent.4631, %stack.sub.4638
  %descriptor.payload.inside.4640 = icmp ule i32 %local.check.payload.4632, %local.check.extent.4631
  %descriptor.owner.offset.valid.4641 = and i1 %descriptor.owner.inside.4636, %descriptor.offset.inside.4637
  %descriptor.range.inside.4643 = and i1 %descriptor.owner.offset.valid.4641, %descriptor.extent.inside.4639
  %descriptor.range.valid.4642 = and i1 %descriptor.range.inside.4643, %descriptor.payload.inside.4640
  br i1 %descriptor.range.valid.4642, label %descriptor.valid.4644, label %descriptor.invalid.4645
descriptor.invalid.4645:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.4644:
  %descriptor.initialized.status.4646 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.4630, i32 %local.check.extent.4631)
  %helper.ok.4647 = icmp eq i32 %descriptor.initialized.status.4646, 0
  br i1 %helper.ok.4647, label %helper.continue.4648, label %frame.failure.0
helper.continue.4648:
  br label %local.descriptor.checked.4629
local.descriptor.inactive.4628:
  br label %local.descriptor.checked.4629
local.descriptor.checked.4629:
  %context.field.4649 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.4650 = load i32, ptr %context.field.4649, align 4
  %stack.sub.4651 = sub i32 %context.value.4650, %context.value.39
  call void @al_owning_record_layout(ptr %ctx, i32 18, i32 0, i32 %context.value.39, i32 %stack.sub.4651, i32 0, i32 0, i32 0)
  %context.field.4652 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4653 = load i32, ptr %context.field.4652, align 4
  %runtime.ok.4654 = icmp eq i32 %context.value.4653, 0
  br i1 %runtime.ok.4654, label %runtime.continue.4655, label %frame.failure.0
runtime.continue.4655:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.39, i32 0, i32 0, i32 0)
  %context.field.4656 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4657 = load i32, ptr %context.field.4656, align 4
  %runtime.ok.4658 = icmp eq i32 %context.value.4657, 0
  br i1 %runtime.ok.4658, label %runtime.continue.4659, label %frame.failure.0
runtime.continue.4659:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.39, i32 0, i32 0, i32 0)
  %context.field.4660 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.4661 = load i32, ptr %context.field.4660, align 4
  %context.field.4662 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.4663 = load i32, ptr %context.field.4662, align 4
  %context.field.4664 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.4665 = load i32, ptr %context.field.4664, align 4
  %stack.offset.4666 = add i32 %context.value.41, %context.value.43
  %stack.offset.4667 = add i32 %context.value.4661, %context.value.4663
  %stack.sub.4668 = sub i32 %stack.offset.4666, %stack.offset.4667
  %stack.sub.4669 = sub i32 %context.value.43, %context.value.4663
  %stack.sub.4670 = sub i32 %context.value.4665, %context.value.45
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.4668, i32 %stack.sub.4669)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.4670)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 6
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 6, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %entry.input.descriptors.10 = alloca [6 x %AlOwningDescriptor], align 4
  %input.extent.pointer.11 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.12 = load i32, ptr %input.extent.pointer.11, align 4
  %host.pointer.13 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.14 = alloca i32, align 4
  %input.measured.extent.pointer.15 = alloca i32, align 4
  %input.measure.status.16 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 0, ptr %host.pointer.13, i32 %input.host.extent.12, i32 0, i32 31, ptr %input.payload.pointer.14, ptr %input.measured.extent.pointer.15)
  %helper.ok.17 = icmp eq i32 %input.measure.status.16, 0
  br i1 %helper.ok.17, label %helper.continue.18, label %entry.failure.0
helper.continue.18:
  %input.measured.payload.19 = load i32, ptr %input.payload.pointer.14, align 4
  %input.measured.extent.20 = load i32, ptr %input.measured.extent.pointer.15, align 4
  %input.extent.exact.21 = icmp eq i32 %input.measured.extent.20, %input.host.extent.12
  br i1 %input.extent.exact.21, label %input.extent.exact.22, label %input.extent.invalid.23
input.extent.invalid.23:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 31, i32 %input.measured.extent.20, i32 %input.host.extent.12)
  br label %entry.failure.0
input.extent.exact.22:
  %stack.offset.24 = add i32 0, %input.host.extent.12
  %input.extent.pointer.25 = getelementptr inbounds i32, ptr %input.extents, i32 1
  %input.host.extent.26 = load i32, ptr %input.extent.pointer.25, align 4
  %host.pointer.27 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.24
  %input.payload.pointer.28 = alloca i32, align 4
  %input.measured.extent.pointer.29 = alloca i32, align 4
  %input.measure.status.30 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 0, ptr %host.pointer.27, i32 %input.host.extent.26, i32 0, i32 32, ptr %input.payload.pointer.28, ptr %input.measured.extent.pointer.29)
  %helper.ok.31 = icmp eq i32 %input.measure.status.30, 0
  br i1 %helper.ok.31, label %helper.continue.32, label %entry.failure.0
helper.continue.32:
  %input.measured.payload.33 = load i32, ptr %input.payload.pointer.28, align 4
  %input.measured.extent.34 = load i32, ptr %input.measured.extent.pointer.29, align 4
  %input.extent.exact.35 = icmp eq i32 %input.measured.extent.34, %input.host.extent.26
  br i1 %input.extent.exact.35, label %input.extent.exact.36, label %input.extent.invalid.37
input.extent.invalid.37:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 32, i32 %input.measured.extent.34, i32 %input.host.extent.26)
  br label %entry.failure.0
input.extent.exact.36:
  %stack.offset.38 = add i32 %stack.offset.24, %input.host.extent.26
  %input.extent.pointer.39 = getelementptr inbounds i32, ptr %input.extents, i32 2
  %input.host.extent.40 = load i32, ptr %input.extent.pointer.39, align 4
  %host.pointer.41 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.38
  %input.payload.pointer.42 = alloca i32, align 4
  %input.measured.extent.pointer.43 = alloca i32, align 4
  %input.measure.status.44 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 0, ptr %host.pointer.41, i32 %input.host.extent.40, i32 0, i32 33, ptr %input.payload.pointer.42, ptr %input.measured.extent.pointer.43)
  %helper.ok.45 = icmp eq i32 %input.measure.status.44, 0
  br i1 %helper.ok.45, label %helper.continue.46, label %entry.failure.0
helper.continue.46:
  %input.measured.payload.47 = load i32, ptr %input.payload.pointer.42, align 4
  %input.measured.extent.48 = load i32, ptr %input.measured.extent.pointer.43, align 4
  %input.extent.exact.49 = icmp eq i32 %input.measured.extent.48, %input.host.extent.40
  br i1 %input.extent.exact.49, label %input.extent.exact.50, label %input.extent.invalid.51
input.extent.invalid.51:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 33, i32 %input.measured.extent.48, i32 %input.host.extent.40)
  br label %entry.failure.0
input.extent.exact.50:
  %stack.offset.52 = add i32 %stack.offset.38, %input.host.extent.40
  %input.extent.pointer.53 = getelementptr inbounds i32, ptr %input.extents, i32 3
  %input.host.extent.54 = load i32, ptr %input.extent.pointer.53, align 4
  %host.pointer.55 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.52
  %input.payload.pointer.56 = alloca i32, align 4
  %input.measured.extent.pointer.57 = alloca i32, align 4
  %input.measure.status.58 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 0, ptr %host.pointer.55, i32 %input.host.extent.54, i32 0, i32 34, ptr %input.payload.pointer.56, ptr %input.measured.extent.pointer.57)
  %helper.ok.59 = icmp eq i32 %input.measure.status.58, 0
  br i1 %helper.ok.59, label %helper.continue.60, label %entry.failure.0
helper.continue.60:
  %input.measured.payload.61 = load i32, ptr %input.payload.pointer.56, align 4
  %input.measured.extent.62 = load i32, ptr %input.measured.extent.pointer.57, align 4
  %input.extent.exact.63 = icmp eq i32 %input.measured.extent.62, %input.host.extent.54
  br i1 %input.extent.exact.63, label %input.extent.exact.64, label %input.extent.invalid.65
input.extent.invalid.65:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 34, i32 %input.measured.extent.62, i32 %input.host.extent.54)
  br label %entry.failure.0
input.extent.exact.64:
  %stack.offset.66 = add i32 %stack.offset.52, %input.host.extent.54
  %input.extent.pointer.67 = getelementptr inbounds i32, ptr %input.extents, i32 4
  %input.host.extent.68 = load i32, ptr %input.extent.pointer.67, align 4
  %host.pointer.69 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.66
  %input.payload.pointer.70 = alloca i32, align 4
  %input.measured.extent.pointer.71 = alloca i32, align 4
  %input.measure.status.72 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 0, ptr %host.pointer.69, i32 %input.host.extent.68, i32 0, i32 35, ptr %input.payload.pointer.70, ptr %input.measured.extent.pointer.71)
  %helper.ok.73 = icmp eq i32 %input.measure.status.72, 0
  br i1 %helper.ok.73, label %helper.continue.74, label %entry.failure.0
helper.continue.74:
  %input.measured.payload.75 = load i32, ptr %input.payload.pointer.70, align 4
  %input.measured.extent.76 = load i32, ptr %input.measured.extent.pointer.71, align 4
  %input.extent.exact.77 = icmp eq i32 %input.measured.extent.76, %input.host.extent.68
  br i1 %input.extent.exact.77, label %input.extent.exact.78, label %input.extent.invalid.79
input.extent.invalid.79:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 35, i32 %input.measured.extent.76, i32 %input.host.extent.68)
  br label %entry.failure.0
input.extent.exact.78:
  %stack.offset.80 = add i32 %stack.offset.66, %input.host.extent.68
  %input.extent.pointer.81 = getelementptr inbounds i32, ptr %input.extents, i32 5
  %input.host.extent.82 = load i32, ptr %input.extent.pointer.81, align 4
  %host.pointer.83 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.80
  %input.payload.pointer.84 = alloca i32, align 4
  %input.measured.extent.pointer.85 = alloca i32, align 4
  %input.measure.status.86 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 0, ptr %host.pointer.83, i32 %input.host.extent.82, i32 0, i32 36, ptr %input.payload.pointer.84, ptr %input.measured.extent.pointer.85)
  %helper.ok.87 = icmp eq i32 %input.measure.status.86, 0
  br i1 %helper.ok.87, label %helper.continue.88, label %entry.failure.0
helper.continue.88:
  %input.measured.payload.89 = load i32, ptr %input.payload.pointer.84, align 4
  %input.measured.extent.90 = load i32, ptr %input.measured.extent.pointer.85, align 4
  %input.extent.exact.91 = icmp eq i32 %input.measured.extent.90, %input.host.extent.82
  br i1 %input.extent.exact.91, label %input.extent.exact.92, label %input.extent.invalid.93
input.extent.invalid.93:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 36, i32 %input.measured.extent.90, i32 %input.host.extent.82)
  br label %entry.failure.0
input.extent.exact.92:
  %stack.offset.94 = add i32 %stack.offset.80, %input.host.extent.82
  %input.total.exact.95 = icmp eq i32 %stack.offset.94, %input.bytes
  br i1 %input.total.exact.95, label %input.valid.96, label %input.invalid.97
input.invalid.97:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.94, i32 %input.bytes)
  br label %entry.failure.0
input.valid.96:
  %reserve.status.98 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.94, i32 37)
  %reserve.ok.99 = icmp eq i32 %reserve.status.98, 0
  br i1 %reserve.ok.99, label %reserve.continue.100, label %entry.failure.0
reserve.continue.100:
  %host.pointer.101 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.102 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.101, i32 %input.host.extent.12, i32 0, i32 %input.measured.payload.19, i32 %input.host.extent.12, i32 12, i32 38)
  %helper.ok.103 = icmp eq i32 %input.copy.status.102, 0
  br i1 %helper.ok.103, label %helper.continue.104, label %entry.failure.0
helper.continue.104:
  %stack.offset.105 = add i32 0, %input.host.extent.12
  %descriptor.element.106 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.10, i32 0
  %descriptor.field.107 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.106, i32 0, i32 0
  store i32 12, ptr %descriptor.field.107, align 4
  %descriptor.field.108 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.106, i32 0, i32 1
  store i32 0, ptr %descriptor.field.108, align 4
  %descriptor.field.109 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.106, i32 0, i32 2
  store i32 %input.host.extent.12, ptr %descriptor.field.109, align 4
  %descriptor.field.110 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.106, i32 0, i32 3
  store i32 %input.measured.payload.19, ptr %descriptor.field.110, align 4
  %descriptor.field.111 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.106, i32 0, i32 4
  store i32 %stack.offset.105, ptr %descriptor.field.111, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 0, i32 20, i32 %input.measured.payload.19, i32 %stack.offset.105, i32 %input.host.extent.12)
  %context.field.112 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.113 = load i32, ptr %context.field.112, align 4
  %runtime.ok.114 = icmp eq i32 %context.value.113, 0
  br i1 %runtime.ok.114, label %runtime.continue.115, label %entry.failure.0
runtime.continue.115:
  %host.pointer.116 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.24
  %input.copy.status.117 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.24, ptr %host.pointer.116, i32 %input.host.extent.26, i32 0, i32 %input.measured.payload.33, i32 %input.host.extent.26, i32 12, i32 39)
  %helper.ok.118 = icmp eq i32 %input.copy.status.117, 0
  br i1 %helper.ok.118, label %helper.continue.119, label %entry.failure.0
helper.continue.119:
  %stack.offset.120 = add i32 %stack.offset.24, %input.host.extent.26
  %descriptor.element.121 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.10, i32 1
  %descriptor.field.122 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.121, i32 0, i32 0
  store i32 12, ptr %descriptor.field.122, align 4
  %descriptor.field.123 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.121, i32 0, i32 1
  store i32 %stack.offset.24, ptr %descriptor.field.123, align 4
  %descriptor.field.124 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.121, i32 0, i32 2
  store i32 %input.host.extent.26, ptr %descriptor.field.124, align 4
  %descriptor.field.125 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.121, i32 0, i32 3
  store i32 %input.measured.payload.33, ptr %descriptor.field.125, align 4
  %descriptor.field.126 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.121, i32 0, i32 4
  store i32 %stack.offset.120, ptr %descriptor.field.126, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %stack.offset.24, i32 20, i32 %input.measured.payload.33, i32 %stack.offset.120, i32 %input.host.extent.26)
  %context.field.127 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.128 = load i32, ptr %context.field.127, align 4
  %runtime.ok.129 = icmp eq i32 %context.value.128, 0
  br i1 %runtime.ok.129, label %runtime.continue.130, label %entry.failure.0
runtime.continue.130:
  %host.pointer.131 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.38
  %input.copy.status.132 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.38, ptr %host.pointer.131, i32 %input.host.extent.40, i32 0, i32 %input.measured.payload.47, i32 %input.host.extent.40, i32 12, i32 40)
  %helper.ok.133 = icmp eq i32 %input.copy.status.132, 0
  br i1 %helper.ok.133, label %helper.continue.134, label %entry.failure.0
helper.continue.134:
  %stack.offset.135 = add i32 %stack.offset.38, %input.host.extent.40
  %descriptor.element.136 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.10, i32 2
  %descriptor.field.137 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.136, i32 0, i32 0
  store i32 12, ptr %descriptor.field.137, align 4
  %descriptor.field.138 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.136, i32 0, i32 1
  store i32 %stack.offset.38, ptr %descriptor.field.138, align 4
  %descriptor.field.139 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.136, i32 0, i32 2
  store i32 %input.host.extent.40, ptr %descriptor.field.139, align 4
  %descriptor.field.140 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.136, i32 0, i32 3
  store i32 %input.measured.payload.47, ptr %descriptor.field.140, align 4
  %descriptor.field.141 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.136, i32 0, i32 4
  store i32 %stack.offset.135, ptr %descriptor.field.141, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %stack.offset.38, i32 20, i32 %input.measured.payload.47, i32 %stack.offset.135, i32 %input.host.extent.40)
  %context.field.142 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.143 = load i32, ptr %context.field.142, align 4
  %runtime.ok.144 = icmp eq i32 %context.value.143, 0
  br i1 %runtime.ok.144, label %runtime.continue.145, label %entry.failure.0
runtime.continue.145:
  %host.pointer.146 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.52
  %input.copy.status.147 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.52, ptr %host.pointer.146, i32 %input.host.extent.54, i32 0, i32 %input.measured.payload.61, i32 %input.host.extent.54, i32 12, i32 41)
  %helper.ok.148 = icmp eq i32 %input.copy.status.147, 0
  br i1 %helper.ok.148, label %helper.continue.149, label %entry.failure.0
helper.continue.149:
  %stack.offset.150 = add i32 %stack.offset.52, %input.host.extent.54
  %descriptor.element.151 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.10, i32 3
  %descriptor.field.152 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.151, i32 0, i32 0
  store i32 12, ptr %descriptor.field.152, align 4
  %descriptor.field.153 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.151, i32 0, i32 1
  store i32 %stack.offset.52, ptr %descriptor.field.153, align 4
  %descriptor.field.154 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.151, i32 0, i32 2
  store i32 %input.host.extent.54, ptr %descriptor.field.154, align 4
  %descriptor.field.155 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.151, i32 0, i32 3
  store i32 %input.measured.payload.61, ptr %descriptor.field.155, align 4
  %descriptor.field.156 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.151, i32 0, i32 4
  store i32 %stack.offset.150, ptr %descriptor.field.156, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %stack.offset.52, i32 20, i32 %input.measured.payload.61, i32 %stack.offset.150, i32 %input.host.extent.54)
  %context.field.157 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.158 = load i32, ptr %context.field.157, align 4
  %runtime.ok.159 = icmp eq i32 %context.value.158, 0
  br i1 %runtime.ok.159, label %runtime.continue.160, label %entry.failure.0
runtime.continue.160:
  %host.pointer.161 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.66
  %input.copy.status.162 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.66, ptr %host.pointer.161, i32 %input.host.extent.68, i32 0, i32 %input.measured.payload.75, i32 %input.host.extent.68, i32 12, i32 42)
  %helper.ok.163 = icmp eq i32 %input.copy.status.162, 0
  br i1 %helper.ok.163, label %helper.continue.164, label %entry.failure.0
helper.continue.164:
  %stack.offset.165 = add i32 %stack.offset.66, %input.host.extent.68
  %descriptor.element.166 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.10, i32 4
  %descriptor.field.167 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.166, i32 0, i32 0
  store i32 12, ptr %descriptor.field.167, align 4
  %descriptor.field.168 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.166, i32 0, i32 1
  store i32 %stack.offset.66, ptr %descriptor.field.168, align 4
  %descriptor.field.169 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.166, i32 0, i32 2
  store i32 %input.host.extent.68, ptr %descriptor.field.169, align 4
  %descriptor.field.170 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.166, i32 0, i32 3
  store i32 %input.measured.payload.75, ptr %descriptor.field.170, align 4
  %descriptor.field.171 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.166, i32 0, i32 4
  store i32 %stack.offset.165, ptr %descriptor.field.171, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %stack.offset.66, i32 20, i32 %input.measured.payload.75, i32 %stack.offset.165, i32 %input.host.extent.68)
  %context.field.172 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.173 = load i32, ptr %context.field.172, align 4
  %runtime.ok.174 = icmp eq i32 %context.value.173, 0
  br i1 %runtime.ok.174, label %runtime.continue.175, label %entry.failure.0
runtime.continue.175:
  %host.pointer.176 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.80
  %input.copy.status.177 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.80, ptr %host.pointer.176, i32 %input.host.extent.82, i32 0, i32 %input.measured.payload.89, i32 %input.host.extent.82, i32 12, i32 43)
  %helper.ok.178 = icmp eq i32 %input.copy.status.177, 0
  br i1 %helper.ok.178, label %helper.continue.179, label %entry.failure.0
helper.continue.179:
  %stack.offset.180 = add i32 %stack.offset.80, %input.host.extent.82
  %descriptor.element.181 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.10, i32 5
  %descriptor.field.182 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.181, i32 0, i32 0
  store i32 12, ptr %descriptor.field.182, align 4
  %descriptor.field.183 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.181, i32 0, i32 1
  store i32 %stack.offset.80, ptr %descriptor.field.183, align 4
  %descriptor.field.184 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.181, i32 0, i32 2
  store i32 %input.host.extent.82, ptr %descriptor.field.184, align 4
  %descriptor.field.185 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.181, i32 0, i32 3
  store i32 %input.measured.payload.89, ptr %descriptor.field.185, align 4
  %descriptor.field.186 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.181, i32 0, i32 4
  store i32 %stack.offset.180, ptr %descriptor.field.186, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %stack.offset.80, i32 20, i32 %input.measured.payload.89, i32 %stack.offset.180, i32 %input.host.extent.82)
  %context.field.187 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.188 = load i32, ptr %context.field.187, align 4
  %runtime.ok.189 = icmp eq i32 %context.value.188, 0
  br i1 %runtime.ok.189, label %runtime.continue.190, label %entry.failure.0
runtime.continue.190:
  %entry.body.status.191 = call i32 @agentlang_entry_frame(ptr %ctx, ptr %entry.input.descriptors.10, ptr null, i32 44)
  %entry.body.ok.192 = icmp eq i32 %entry.body.status.191, 0
  br i1 %entry.body.ok.192, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %entry.retained.capacity.i64.193 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.194 = icmp ule i64 0, 4294967295
  %entry.retained.required.truncated.195 = trunc i64 0 to i32
  %entry.retained.required.196 = select i1 %entry.retained.required.fits.u32.194, i32 %entry.retained.required.truncated.195, i32 4294967295
  %entry.retained.capacity.ok.197 = icmp ule i64 0, %entry.retained.capacity.i64.193
  br i1 %entry.retained.capacity.ok.197, label %entry.retained.capacity.ready.198, label %entry.retained.capacity.failure.199
entry.retained.capacity.failure.199:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.196, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.198:
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.200 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.201 = load i32, ptr %context.field.200, align 4
  %context.field.202 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.203 = load i32, ptr %context.field.202, align 4
  %stack.sub.204 = sub i32 0, %context.value.201
  %stack.sub.205 = sub i32 0, %context.value.203
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.204, i32 %stack.sub.205)
  %context.field.206 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.207 = load i32, ptr %context.field.206, align 4
  %runtime.ok.208 = icmp eq i32 %context.value.207, 0
  br i1 %runtime.ok.208, label %runtime.continue.209, label %entry.failure.0
runtime.continue.209:
  br label %entry.return.status
entry.failure.0:
  %context.field.210 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.211 = load i32, ptr %context.field.210, align 4
  %context.field.212 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.213 = load i32, ptr %context.field.212, align 4
  %context.field.214 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.215 = load i32, ptr %context.field.214, align 4
  %stack.offset.216 = add i32 %context.value.211, %context.value.213
  %stack.sub.217 = sub i32 0, %stack.offset.216
  %stack.sub.218 = sub i32 0, %context.value.213
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.217, i32 %stack.sub.218)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.215)
  br label %entry.return.status
entry.return.status:
  %context.field.219 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.220 = load i32, ptr %context.field.219, align 4
  ret i32 %context.value.220
}


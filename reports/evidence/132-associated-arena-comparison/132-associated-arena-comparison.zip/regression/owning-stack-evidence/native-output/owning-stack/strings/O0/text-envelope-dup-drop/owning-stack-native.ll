%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [4 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8 }, %AlOwningTypeDescriptor { i32 4, i32 8, i32 0, i32 2, i32 4294967295, i32 4294967295, i32 24, i32 24 }, %AlOwningTypeDescriptor { i32 4, i32 9, i32 2, i32 2, i32 4294967295, i32 4294967295, i32 16, i32 16 }, %AlOwningTypeDescriptor { i32 5, i32 12, i32 4, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8 }], align 4
@al_owning_fields = private constant [4 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 2, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 4294967295, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 3, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 4294967295, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 1, ptr @al_owning_types, i32 4, ptr @al_owning_fields, i32 4 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 8
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 8, 8
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %step.status.43 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.44 = icmp eq i32 %step.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %frame.failure.0
helper.continue.45:
  %context.field.46 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.47 = load i32, ptr %context.field.46, align 4
  %stack.offset.48 = add i32 %context.value.47, %descriptor.value.19
  %reserve.status.49 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.48, i32 2)
  %reserve.ok.50 = icmp eq i32 %reserve.status.49, 0
  br i1 %reserve.ok.50, label %reserve.continue.51, label %frame.failure.0
reserve.continue.51:
  call void @al_owning_duplicate(ptr %ctx, i32 %context.value.47, i32 %descriptor.value.17, i32 %descriptor.value.19, i32 %descriptor.value.21, i32 8)
  %context.field.52 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.53 = load i32, ptr %context.field.52, align 4
  %runtime.ok.54 = icmp eq i32 %context.value.53, 0
  br i1 %runtime.ok.54, label %runtime.continue.55, label %frame.failure.0
runtime.continue.55:
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %stack.sub.60 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.58 = icmp ule i32 %descriptor.value.23, %context.value.57
  %descriptor.offset.inside.59 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.61 = icmp ule i32 %descriptor.value.19, %stack.sub.60
  %descriptor.payload.inside.62 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.63 = and i1 %descriptor.owner.inside.58, %descriptor.offset.inside.59
  %descriptor.range.inside.65 = and i1 %descriptor.owner.offset.valid.63, %descriptor.extent.inside.61
  %descriptor.range.valid.64 = and i1 %descriptor.range.inside.65, %descriptor.payload.inside.62
  %descriptor.type.valid.66 = icmp eq i32 8, 8
  %descriptor.valid.67 = and i1 %descriptor.range.valid.64, %descriptor.type.valid.66
  br i1 %descriptor.valid.67, label %descriptor.valid.68, label %descriptor.invalid.69
descriptor.invalid.69:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.68:
  %descriptor.initialized.status.70 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.71 = icmp eq i32 %descriptor.initialized.status.70, 0
  br i1 %helper.ok.71, label %helper.continue.72, label %frame.failure.0
helper.continue.72:
  %context.field.73 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.74 = load i32, ptr %context.field.73, align 4
  %stack.sub.77 = sub i32 %stack.offset.48, %context.value.47
  %descriptor.owner.inside.75 = icmp ule i32 %stack.offset.48, %context.value.74
  %descriptor.offset.inside.76 = icmp ule i32 %context.value.47, %stack.offset.48
  %descriptor.extent.inside.78 = icmp ule i32 %descriptor.value.19, %stack.sub.77
  %descriptor.payload.inside.79 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.80 = and i1 %descriptor.owner.inside.75, %descriptor.offset.inside.76
  %descriptor.range.inside.82 = and i1 %descriptor.owner.offset.valid.80, %descriptor.extent.inside.78
  %descriptor.range.valid.81 = and i1 %descriptor.range.inside.82, %descriptor.payload.inside.79
  %descriptor.type.valid.83 = icmp eq i32 8, 8
  %descriptor.valid.84 = and i1 %descriptor.range.valid.81, %descriptor.type.valid.83
  br i1 %descriptor.valid.84, label %descriptor.valid.85, label %descriptor.invalid.86
descriptor.invalid.86:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.85:
  %descriptor.initialized.status.87 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.47, i32 %descriptor.value.19)
  %helper.ok.88 = icmp eq i32 %descriptor.initialized.status.87, 0
  br i1 %helper.ok.88, label %helper.continue.89, label %frame.failure.0
helper.continue.89:
  %step.status.90 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.91 = icmp eq i32 %step.status.90, 0
  br i1 %helper.ok.91, label %helper.continue.92, label %frame.failure.0
helper.continue.92:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 8, i32 %context.value.47, i32 %descriptor.value.19, i32 %descriptor.value.21, i32 0, i32 0)
  %context.field.93 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.94 = load i32, ptr %context.field.93, align 4
  %runtime.ok.95 = icmp eq i32 %context.value.94, 0
  br i1 %runtime.ok.95, label %runtime.continue.96, label %frame.failure.0
runtime.continue.96:
  %context.field.97 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.98 = load i32, ptr %context.field.97, align 4
  %stack.sub.101 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.99 = icmp ule i32 %descriptor.value.23, %context.value.98
  %descriptor.offset.inside.100 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.102 = icmp ule i32 %descriptor.value.19, %stack.sub.101
  %descriptor.payload.inside.103 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.104 = and i1 %descriptor.owner.inside.99, %descriptor.offset.inside.100
  %descriptor.range.inside.106 = and i1 %descriptor.owner.offset.valid.104, %descriptor.extent.inside.102
  %descriptor.range.valid.105 = and i1 %descriptor.range.inside.106, %descriptor.payload.inside.103
  %descriptor.type.valid.107 = icmp eq i32 8, 8
  %descriptor.valid.108 = and i1 %descriptor.range.valid.105, %descriptor.type.valid.107
  br i1 %descriptor.valid.108, label %descriptor.valid.109, label %descriptor.invalid.110
descriptor.invalid.110:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.109:
  %descriptor.initialized.status.111 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.112 = icmp eq i32 %descriptor.initialized.status.111, 0
  br i1 %helper.ok.112, label %helper.continue.113, label %frame.failure.0
helper.continue.113:
  %context.field.114 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.115 = load i32, ptr %context.field.114, align 4
  %stack.sub.116 = sub i32 %context.value.115, %context.value.3
  call void @al_owning_record_layout(ptr %ctx, i32 18, i32 0, i32 %context.value.3, i32 %stack.sub.116, i32 0, i32 0, i32 0)
  %context.field.117 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.118 = load i32, ptr %context.field.117, align 4
  %runtime.ok.119 = icmp eq i32 %context.value.118, 0
  br i1 %runtime.ok.119, label %runtime.continue.120, label %frame.failure.0
runtime.continue.120:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.121 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.122 = load i32, ptr %context.field.121, align 4
  %runtime.ok.123 = icmp eq i32 %context.value.122, 0
  br i1 %runtime.ok.123, label %runtime.continue.124, label %frame.failure.0
runtime.continue.124:
  %descriptor.element.125 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.126 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.125, i32 0, i32 0
  store i32 8, ptr %descriptor.field.126, align 4
  %descriptor.field.127 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.125, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.127, align 4
  %descriptor.field.128 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.125, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.128, align 4
  %descriptor.field.129 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.125, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.129, align 4
  %descriptor.field.130 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.125, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.130, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.131 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.132 = load i32, ptr %context.field.131, align 4
  %runtime.ok.133 = icmp eq i32 %context.value.132, 0
  br i1 %runtime.ok.133, label %runtime.continue.134, label %frame.failure.0
runtime.continue.134:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.135 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.136 = load i32, ptr %context.field.135, align 4
  %context.field.137 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.138 = load i32, ptr %context.field.137, align 4
  %context.field.139 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.140 = load i32, ptr %context.field.139, align 4
  %stack.offset.141 = add i32 %context.value.5, %context.value.7
  %stack.offset.142 = add i32 %context.value.136, %context.value.138
  %stack.sub.143 = sub i32 %stack.offset.141, %stack.offset.142
  %stack.sub.144 = sub i32 %context.value.7, %context.value.138
  %stack.sub.145 = sub i32 %context.value.140, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.143, i32 %stack.sub.144)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.145)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 1
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %entry.input.descriptors.10 = alloca [1 x %AlOwningDescriptor], align 4
  %input.extent.pointer.11 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.12 = load i32, ptr %input.extent.pointer.11, align 4
  %host.pointer.13 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.14 = alloca i32, align 4
  %input.measured.extent.pointer.15 = alloca i32, align 4
  %input.measure.status.16 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 1, ptr %host.pointer.13, i32 %input.host.extent.12, i32 0, i32 4, ptr %input.payload.pointer.14, ptr %input.measured.extent.pointer.15)
  %helper.ok.17 = icmp eq i32 %input.measure.status.16, 0
  br i1 %helper.ok.17, label %helper.continue.18, label %entry.failure.0
helper.continue.18:
  %input.measured.payload.19 = load i32, ptr %input.payload.pointer.14, align 4
  %input.measured.extent.20 = load i32, ptr %input.measured.extent.pointer.15, align 4
  %input.extent.exact.21 = icmp eq i32 %input.measured.extent.20, %input.host.extent.12
  br i1 %input.extent.exact.21, label %input.extent.exact.22, label %input.extent.invalid.23
input.extent.invalid.23:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 4, i32 %input.measured.extent.20, i32 %input.host.extent.12)
  br label %entry.failure.0
input.extent.exact.22:
  %stack.offset.24 = add i32 0, %input.host.extent.12
  %input.total.exact.25 = icmp eq i32 %stack.offset.24, %input.bytes
  br i1 %input.total.exact.25, label %input.valid.26, label %input.invalid.27
input.invalid.27:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.24, i32 %input.bytes)
  br label %entry.failure.0
input.valid.26:
  %reserve.status.28 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.24, i32 5)
  %reserve.ok.29 = icmp eq i32 %reserve.status.28, 0
  br i1 %reserve.ok.29, label %reserve.continue.30, label %entry.failure.0
reserve.continue.30:
  %host.pointer.31 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.32 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.31, i32 %input.host.extent.12, i32 0, i32 %input.measured.payload.19, i32 %input.host.extent.12, i32 8, i32 6)
  %helper.ok.33 = icmp eq i32 %input.copy.status.32, 0
  br i1 %helper.ok.33, label %helper.continue.34, label %entry.failure.0
helper.continue.34:
  %stack.offset.35 = add i32 0, %input.host.extent.12
  %descriptor.element.36 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.10, i32 0
  %descriptor.field.37 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.36, i32 0, i32 0
  store i32 8, ptr %descriptor.field.37, align 4
  %descriptor.field.38 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.36, i32 0, i32 1
  store i32 0, ptr %descriptor.field.38, align 4
  %descriptor.field.39 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.36, i32 0, i32 2
  store i32 %input.host.extent.12, ptr %descriptor.field.39, align 4
  %descriptor.field.40 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.36, i32 0, i32 3
  store i32 %input.measured.payload.19, ptr %descriptor.field.40, align 4
  %descriptor.field.41 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.36, i32 0, i32 4
  store i32 %stack.offset.35, ptr %descriptor.field.41, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 0, i32 20, i32 %input.measured.payload.19, i32 %stack.offset.35, i32 %input.host.extent.12)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %entry.failure.0
runtime.continue.45:
  %entry.output.descriptors.46 = alloca [1 x %AlOwningDescriptor], align 4
  %entry.body.status.47 = call i32 @agentlang_entry_frame(ptr %ctx, ptr %entry.input.descriptors.10, ptr %entry.output.descriptors.46, i32 7)
  %entry.body.ok.48 = icmp eq i32 %entry.body.status.47, 0
  br i1 %entry.body.ok.48, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.49 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.46, i32 0
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 0
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 1
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %descriptor.field.54 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 2
  %descriptor.value.55 = load i32, ptr %descriptor.field.54, align 4
  %descriptor.field.56 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 3
  %descriptor.value.57 = load i32, ptr %descriptor.field.56, align 4
  %descriptor.field.58 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 4
  %descriptor.value.59 = load i32, ptr %descriptor.field.58, align 4
  %entry.output.type.valid.60 = icmp eq i32 %descriptor.value.51, 8
  br i1 %entry.output.type.valid.60, label %entry.output.type.ok.61, label %entry.output.type.invalid.62
entry.output.type.invalid.62:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.61:
  %context.field.63 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.64 = load i32, ptr %context.field.63, align 4
  %stack.sub.67 = sub i32 %descriptor.value.59, %descriptor.value.53
  %descriptor.owner.inside.65 = icmp ule i32 %descriptor.value.59, %context.value.64
  %descriptor.offset.inside.66 = icmp ule i32 %descriptor.value.53, %descriptor.value.59
  %descriptor.extent.inside.68 = icmp ule i32 %descriptor.value.55, %stack.sub.67
  %descriptor.payload.inside.69 = icmp ule i32 %descriptor.value.57, %descriptor.value.55
  %descriptor.owner.offset.valid.70 = and i1 %descriptor.owner.inside.65, %descriptor.offset.inside.66
  %descriptor.range.inside.72 = and i1 %descriptor.owner.offset.valid.70, %descriptor.extent.inside.68
  %descriptor.range.valid.71 = and i1 %descriptor.range.inside.72, %descriptor.payload.inside.69
  %descriptor.type.valid.73 = icmp eq i32 8, 8
  %descriptor.valid.74 = and i1 %descriptor.range.valid.71, %descriptor.type.valid.73
  br i1 %descriptor.valid.74, label %descriptor.valid.75, label %descriptor.invalid.76
descriptor.invalid.76:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.75:
  %descriptor.initialized.status.77 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.53, i32 %descriptor.value.55)
  %helper.ok.78 = icmp eq i32 %descriptor.initialized.status.77, 0
  br i1 %helper.ok.78, label %helper.continue.79, label %entry.failure.0
helper.continue.79:
  %entry.output.size.i64.80 = zext i32 %descriptor.value.55 to i64
  %entry.output.total.i64.81 = add i64 0, %entry.output.size.i64.80
  %entry.retained.capacity.i64.82 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.83 = icmp ule i64 %entry.output.total.i64.81, 4294967295
  %entry.retained.required.truncated.84 = trunc i64 %entry.output.total.i64.81 to i32
  %entry.retained.required.85 = select i1 %entry.retained.required.fits.u32.83, i32 %entry.retained.required.truncated.84, i32 4294967295
  %entry.retained.capacity.ok.86 = icmp ule i64 %entry.output.total.i64.81, %entry.retained.capacity.i64.82
  br i1 %entry.retained.capacity.ok.86, label %entry.retained.capacity.ready.87, label %entry.retained.capacity.failure.88
entry.retained.capacity.failure.88:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.85, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.87:
  %host.pointer.89 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.90 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.89, i32 %stack.sub.90, i32 %descriptor.value.53, i32 %descriptor.value.55, i32 8)
  %context.field.91 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.92 = load i32, ptr %context.field.91, align 4
  %runtime.ok.93 = icmp eq i32 %context.value.92, 0
  br i1 %runtime.ok.93, label %runtime.continue.94, label %entry.failure.0
runtime.continue.94:
  %stack.offset.95 = add i32 0, %descriptor.value.55
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %context.field.98 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.99 = load i32, ptr %context.field.98, align 4
  %stack.sub.100 = sub i32 0, %context.value.97
  %stack.sub.101 = sub i32 0, %context.value.99
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.100, i32 %stack.sub.101)
  %context.field.102 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.103 = load i32, ptr %context.field.102, align 4
  %runtime.ok.104 = icmp eq i32 %context.value.103, 0
  br i1 %runtime.ok.104, label %runtime.continue.105, label %entry.failure.0
runtime.continue.105:
  br label %entry.return.status
entry.failure.0:
  %context.field.106 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.107 = load i32, ptr %context.field.106, align 4
  %context.field.108 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.109 = load i32, ptr %context.field.108, align 4
  %context.field.110 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.111 = load i32, ptr %context.field.110, align 4
  %stack.offset.112 = add i32 %context.value.107, %context.value.109
  %stack.sub.113 = sub i32 0, %stack.offset.112
  %stack.sub.114 = sub i32 0, %context.value.109
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.113, i32 %stack.sub.114)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.111)
  br label %entry.return.status
entry.return.status:
  %context.field.115 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.116 = load i32, ptr %context.field.115, align 4
  ret i32 %context.value.116
}


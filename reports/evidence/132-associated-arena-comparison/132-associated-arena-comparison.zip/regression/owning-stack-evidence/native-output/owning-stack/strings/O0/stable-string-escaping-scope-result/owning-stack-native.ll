%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [1 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 5, i32 12, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8 }], align 4
@al_owning_fields = private constant [1 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 0, i32 0, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 1, ptr @al_owning_types, i32 1, ptr @al_owning_fields, i32 0 }, align 8
@al_owning_string_literal_0 = private unnamed_addr constant [16 x i8] c"\04\00\00\00\00\00\00\00\64\00\65\00\61\00\64\00", align 8
@al_owning_string_literal_1 = private unnamed_addr constant [16 x i8] c"\01\00\00\00\00\00\00\00\61\00\00\00\00\00\00\00", align 8
@al_owning_string_literal_2 = private unnamed_addr constant [16 x i8] c"\01\00\00\00\00\00\00\00\62\00\00\00\00\00\00\00", align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %local.active.2 = alloca i1, align 1
  %local.offset.3 = alloca i32, align 4
  %local.extent.4 = alloca i32, align 4
  %local.payload.5 = alloca i32, align 4
  %local.owner.end.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %context.field.14 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.15 = load i32, ptr %context.field.14, align 4
  %frame.entered.16 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.17 = icmp eq i32 %frame.entered.16, 0
  br i1 %frame.enter.ok.17, label %frame.enter.continue.18, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.18:
  %step.status.19 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.20 = icmp eq i32 %step.status.19, 0
  br i1 %helper.ok.20, label %helper.continue.21, label %frame.failure.0
helper.continue.21:
  %context.field.22 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.23 = load i32, ptr %context.field.22, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %step.status.24 = call i32 @al_owning_charge_step(ptr %ctx, i32 2)
  %helper.ok.25 = icmp eq i32 %step.status.24, 0
  br i1 %helper.ok.25, label %helper.continue.26, label %frame.failure.0
helper.continue.26:
  %context.field.27 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.28 = load i32, ptr %context.field.27, align 4
  %stack.offset.29 = add i32 %context.value.28, 16
  %reserve.status.30 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.29, i32 3)
  %reserve.ok.31 = icmp eq i32 %reserve.status.30, 0
  br i1 %reserve.ok.31, label %reserve.continue.32, label %frame.failure.0
reserve.continue.32:
  %literal.status.33 = call i32 @al_owning_copy_constant(ptr %ctx, i32 %context.value.28, ptr getelementptr inbounds ([16 x i8], ptr @al_owning_string_literal_0, i64 0, i64 0), i32 16, i32 16, i32 16, i32 12, i32 4)
  %helper.ok.34 = icmp eq i32 %literal.status.33, 0
  br i1 %helper.ok.34, label %helper.continue.35, label %frame.failure.0
helper.continue.35:
  %context.field.36 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.37 = load i32, ptr %context.field.36, align 4
  %stack.sub.40 = sub i32 %stack.offset.29, %context.value.28
  %descriptor.owner.inside.38 = icmp ule i32 %stack.offset.29, %context.value.37
  %descriptor.offset.inside.39 = icmp ule i32 %context.value.28, %stack.offset.29
  %descriptor.extent.inside.41 = icmp ule i32 16, %stack.sub.40
  %descriptor.payload.inside.42 = icmp ule i32 16, 16
  %descriptor.owner.offset.valid.43 = and i1 %descriptor.owner.inside.38, %descriptor.offset.inside.39
  %descriptor.range.inside.45 = and i1 %descriptor.owner.offset.valid.43, %descriptor.extent.inside.41
  %descriptor.range.valid.44 = and i1 %descriptor.range.inside.45, %descriptor.payload.inside.42
  %descriptor.type.valid.46 = icmp eq i32 12, 12
  %descriptor.valid.47 = and i1 %descriptor.range.valid.44, %descriptor.type.valid.46
  br i1 %descriptor.valid.47, label %descriptor.valid.48, label %descriptor.invalid.49
descriptor.invalid.49:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.48:
  %descriptor.initialized.status.50 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.28, i32 16)
  %helper.ok.51 = icmp eq i32 %descriptor.initialized.status.50, 0
  br i1 %helper.ok.51, label %helper.continue.52, label %frame.failure.0
helper.continue.52:
  %local.is.active.53 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.53, label %local.descriptor.active.54, label %local.descriptor.inactive.55
local.descriptor.active.54:
  %local.check.offset.57 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.58 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.59 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.60 = load i32, ptr %local.owner.end.6, align 4
  %context.field.61 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.62 = load i32, ptr %context.field.61, align 4
  %stack.sub.65 = sub i32 %local.check.owner.end.60, %local.check.offset.57
  %descriptor.owner.inside.63 = icmp ule i32 %local.check.owner.end.60, %context.value.62
  %descriptor.offset.inside.64 = icmp ule i32 %local.check.offset.57, %local.check.owner.end.60
  %descriptor.extent.inside.66 = icmp ule i32 %local.check.extent.58, %stack.sub.65
  %descriptor.payload.inside.67 = icmp ule i32 %local.check.payload.59, %local.check.extent.58
  %descriptor.owner.offset.valid.68 = and i1 %descriptor.owner.inside.63, %descriptor.offset.inside.64
  %descriptor.range.inside.70 = and i1 %descriptor.owner.offset.valid.68, %descriptor.extent.inside.66
  %descriptor.range.valid.69 = and i1 %descriptor.range.inside.70, %descriptor.payload.inside.67
  br i1 %descriptor.range.valid.69, label %descriptor.valid.71, label %descriptor.invalid.72
descriptor.invalid.72:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.71:
  %descriptor.initialized.status.73 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.57, i32 %local.check.extent.58)
  %helper.ok.74 = icmp eq i32 %descriptor.initialized.status.73, 0
  br i1 %helper.ok.74, label %helper.continue.75, label %frame.failure.0
helper.continue.75:
  br label %local.descriptor.checked.56
local.descriptor.inactive.55:
  br label %local.descriptor.checked.56
local.descriptor.checked.56:
  %step.status.76 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.77 = icmp eq i32 %step.status.76, 0
  br i1 %helper.ok.77, label %helper.continue.78, label %frame.failure.0
helper.continue.78:
  store i1 true, ptr %local.active.2, align 1
  store i32 %context.value.28, ptr %local.offset.3, align 4
  store i32 16, ptr %local.extent.4, align 4
  store i32 16, ptr %local.payload.5, align 4
  store i32 %stack.offset.29, ptr %local.owner.end.6, align 4
  store i32 12, ptr %local.type.7, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %context.value.28, i32 20, i32 16, i32 %stack.offset.29, i32 16)
  %context.field.79 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.80 = load i32, ptr %context.field.79, align 4
  %runtime.ok.81 = icmp eq i32 %context.value.80, 0
  br i1 %runtime.ok.81, label %runtime.continue.82, label %frame.failure.0
runtime.continue.82:
  %local.is.active.83 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.83, label %local.descriptor.active.84, label %local.descriptor.inactive.85
local.descriptor.active.84:
  %local.check.offset.87 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.88 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.89 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.90 = load i32, ptr %local.owner.end.6, align 4
  %context.field.91 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.92 = load i32, ptr %context.field.91, align 4
  %stack.sub.95 = sub i32 %local.check.owner.end.90, %local.check.offset.87
  %descriptor.owner.inside.93 = icmp ule i32 %local.check.owner.end.90, %context.value.92
  %descriptor.offset.inside.94 = icmp ule i32 %local.check.offset.87, %local.check.owner.end.90
  %descriptor.extent.inside.96 = icmp ule i32 %local.check.extent.88, %stack.sub.95
  %descriptor.payload.inside.97 = icmp ule i32 %local.check.payload.89, %local.check.extent.88
  %descriptor.owner.offset.valid.98 = and i1 %descriptor.owner.inside.93, %descriptor.offset.inside.94
  %descriptor.range.inside.100 = and i1 %descriptor.owner.offset.valid.98, %descriptor.extent.inside.96
  %descriptor.range.valid.99 = and i1 %descriptor.range.inside.100, %descriptor.payload.inside.97
  br i1 %descriptor.range.valid.99, label %descriptor.valid.101, label %descriptor.invalid.102
descriptor.invalid.102:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.101:
  %descriptor.initialized.status.103 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.87, i32 %local.check.extent.88)
  %helper.ok.104 = icmp eq i32 %descriptor.initialized.status.103, 0
  br i1 %helper.ok.104, label %helper.continue.105, label %frame.failure.0
helper.continue.105:
  br label %local.descriptor.checked.86
local.descriptor.inactive.85:
  br label %local.descriptor.checked.86
local.descriptor.checked.86:
  %step.status.106 = call i32 @al_owning_charge_step(ptr %ctx, i32 6)
  %helper.ok.107 = icmp eq i32 %step.status.106, 0
  br i1 %helper.ok.107, label %helper.continue.108, label %frame.failure.0
helper.continue.108:
  %context.field.109 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.110 = load i32, ptr %context.field.109, align 4
  %stack.offset.111 = add i32 %context.value.110, 16
  %reserve.status.112 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.111, i32 7)
  %reserve.ok.113 = icmp eq i32 %reserve.status.112, 0
  br i1 %reserve.ok.113, label %reserve.continue.114, label %frame.failure.0
reserve.continue.114:
  %literal.status.115 = call i32 @al_owning_copy_constant(ptr %ctx, i32 %context.value.110, ptr getelementptr inbounds ([16 x i8], ptr @al_owning_string_literal_1, i64 0, i64 0), i32 16, i32 10, i32 16, i32 12, i32 8)
  %helper.ok.116 = icmp eq i32 %literal.status.115, 0
  br i1 %helper.ok.116, label %helper.continue.117, label %frame.failure.0
helper.continue.117:
  %context.field.118 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.119 = load i32, ptr %context.field.118, align 4
  %stack.sub.122 = sub i32 %stack.offset.111, %context.value.110
  %descriptor.owner.inside.120 = icmp ule i32 %stack.offset.111, %context.value.119
  %descriptor.offset.inside.121 = icmp ule i32 %context.value.110, %stack.offset.111
  %descriptor.extent.inside.123 = icmp ule i32 16, %stack.sub.122
  %descriptor.payload.inside.124 = icmp ule i32 10, 16
  %descriptor.owner.offset.valid.125 = and i1 %descriptor.owner.inside.120, %descriptor.offset.inside.121
  %descriptor.range.inside.127 = and i1 %descriptor.owner.offset.valid.125, %descriptor.extent.inside.123
  %descriptor.range.valid.126 = and i1 %descriptor.range.inside.127, %descriptor.payload.inside.124
  %descriptor.type.valid.128 = icmp eq i32 12, 12
  %descriptor.valid.129 = and i1 %descriptor.range.valid.126, %descriptor.type.valid.128
  br i1 %descriptor.valid.129, label %descriptor.valid.130, label %descriptor.invalid.131
descriptor.invalid.131:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.130:
  %descriptor.initialized.status.132 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.110, i32 16)
  %helper.ok.133 = icmp eq i32 %descriptor.initialized.status.132, 0
  br i1 %helper.ok.133, label %helper.continue.134, label %frame.failure.0
helper.continue.134:
  %local.is.active.135 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.135, label %local.descriptor.active.136, label %local.descriptor.inactive.137
local.descriptor.active.136:
  %local.check.offset.139 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.140 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.141 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.142 = load i32, ptr %local.owner.end.6, align 4
  %context.field.143 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.144 = load i32, ptr %context.field.143, align 4
  %stack.sub.147 = sub i32 %local.check.owner.end.142, %local.check.offset.139
  %descriptor.owner.inside.145 = icmp ule i32 %local.check.owner.end.142, %context.value.144
  %descriptor.offset.inside.146 = icmp ule i32 %local.check.offset.139, %local.check.owner.end.142
  %descriptor.extent.inside.148 = icmp ule i32 %local.check.extent.140, %stack.sub.147
  %descriptor.payload.inside.149 = icmp ule i32 %local.check.payload.141, %local.check.extent.140
  %descriptor.owner.offset.valid.150 = and i1 %descriptor.owner.inside.145, %descriptor.offset.inside.146
  %descriptor.range.inside.152 = and i1 %descriptor.owner.offset.valid.150, %descriptor.extent.inside.148
  %descriptor.range.valid.151 = and i1 %descriptor.range.inside.152, %descriptor.payload.inside.149
  br i1 %descriptor.range.valid.151, label %descriptor.valid.153, label %descriptor.invalid.154
descriptor.invalid.154:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.153:
  %descriptor.initialized.status.155 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.139, i32 %local.check.extent.140)
  %helper.ok.156 = icmp eq i32 %descriptor.initialized.status.155, 0
  br i1 %helper.ok.156, label %helper.continue.157, label %frame.failure.0
helper.continue.157:
  br label %local.descriptor.checked.138
local.descriptor.inactive.137:
  br label %local.descriptor.checked.138
local.descriptor.checked.138:
  %step.status.158 = call i32 @al_owning_charge_step(ptr %ctx, i32 9)
  %helper.ok.159 = icmp eq i32 %step.status.158, 0
  br i1 %helper.ok.159, label %helper.continue.160, label %frame.failure.0
helper.continue.160:
  %context.field.161 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.162 = load i32, ptr %context.field.161, align 4
  %stack.offset.163 = add i32 %context.value.162, 16
  %reserve.status.164 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.163, i32 10)
  %reserve.ok.165 = icmp eq i32 %reserve.status.164, 0
  br i1 %reserve.ok.165, label %reserve.continue.166, label %frame.failure.0
reserve.continue.166:
  %literal.status.167 = call i32 @al_owning_copy_constant(ptr %ctx, i32 %context.value.162, ptr getelementptr inbounds ([16 x i8], ptr @al_owning_string_literal_2, i64 0, i64 0), i32 16, i32 10, i32 16, i32 12, i32 11)
  %helper.ok.168 = icmp eq i32 %literal.status.167, 0
  br i1 %helper.ok.168, label %helper.continue.169, label %frame.failure.0
helper.continue.169:
  %context.field.170 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.171 = load i32, ptr %context.field.170, align 4
  %stack.sub.174 = sub i32 %stack.offset.111, %context.value.110
  %descriptor.owner.inside.172 = icmp ule i32 %stack.offset.111, %context.value.171
  %descriptor.offset.inside.173 = icmp ule i32 %context.value.110, %stack.offset.111
  %descriptor.extent.inside.175 = icmp ule i32 16, %stack.sub.174
  %descriptor.payload.inside.176 = icmp ule i32 10, 16
  %descriptor.owner.offset.valid.177 = and i1 %descriptor.owner.inside.172, %descriptor.offset.inside.173
  %descriptor.range.inside.179 = and i1 %descriptor.owner.offset.valid.177, %descriptor.extent.inside.175
  %descriptor.range.valid.178 = and i1 %descriptor.range.inside.179, %descriptor.payload.inside.176
  %descriptor.type.valid.180 = icmp eq i32 12, 12
  %descriptor.valid.181 = and i1 %descriptor.range.valid.178, %descriptor.type.valid.180
  br i1 %descriptor.valid.181, label %descriptor.valid.182, label %descriptor.invalid.183
descriptor.invalid.183:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.182:
  %descriptor.initialized.status.184 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.110, i32 16)
  %helper.ok.185 = icmp eq i32 %descriptor.initialized.status.184, 0
  br i1 %helper.ok.185, label %helper.continue.186, label %frame.failure.0
helper.continue.186:
  %context.field.187 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.188 = load i32, ptr %context.field.187, align 4
  %stack.sub.191 = sub i32 %stack.offset.163, %context.value.162
  %descriptor.owner.inside.189 = icmp ule i32 %stack.offset.163, %context.value.188
  %descriptor.offset.inside.190 = icmp ule i32 %context.value.162, %stack.offset.163
  %descriptor.extent.inside.192 = icmp ule i32 16, %stack.sub.191
  %descriptor.payload.inside.193 = icmp ule i32 10, 16
  %descriptor.owner.offset.valid.194 = and i1 %descriptor.owner.inside.189, %descriptor.offset.inside.190
  %descriptor.range.inside.196 = and i1 %descriptor.owner.offset.valid.194, %descriptor.extent.inside.192
  %descriptor.range.valid.195 = and i1 %descriptor.range.inside.196, %descriptor.payload.inside.193
  %descriptor.type.valid.197 = icmp eq i32 12, 12
  %descriptor.valid.198 = and i1 %descriptor.range.valid.195, %descriptor.type.valid.197
  br i1 %descriptor.valid.198, label %descriptor.valid.199, label %descriptor.invalid.200
descriptor.invalid.200:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.199:
  %descriptor.initialized.status.201 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.162, i32 16)
  %helper.ok.202 = icmp eq i32 %descriptor.initialized.status.201, 0
  br i1 %helper.ok.202, label %helper.continue.203, label %frame.failure.0
helper.continue.203:
  %local.is.active.204 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.204, label %local.descriptor.active.205, label %local.descriptor.inactive.206
local.descriptor.active.205:
  %local.check.offset.208 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.209 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.210 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.211 = load i32, ptr %local.owner.end.6, align 4
  %context.field.212 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.213 = load i32, ptr %context.field.212, align 4
  %stack.sub.216 = sub i32 %local.check.owner.end.211, %local.check.offset.208
  %descriptor.owner.inside.214 = icmp ule i32 %local.check.owner.end.211, %context.value.213
  %descriptor.offset.inside.215 = icmp ule i32 %local.check.offset.208, %local.check.owner.end.211
  %descriptor.extent.inside.217 = icmp ule i32 %local.check.extent.209, %stack.sub.216
  %descriptor.payload.inside.218 = icmp ule i32 %local.check.payload.210, %local.check.extent.209
  %descriptor.owner.offset.valid.219 = and i1 %descriptor.owner.inside.214, %descriptor.offset.inside.215
  %descriptor.range.inside.221 = and i1 %descriptor.owner.offset.valid.219, %descriptor.extent.inside.217
  %descriptor.range.valid.220 = and i1 %descriptor.range.inside.221, %descriptor.payload.inside.218
  br i1 %descriptor.range.valid.220, label %descriptor.valid.222, label %descriptor.invalid.223
descriptor.invalid.223:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.222:
  %descriptor.initialized.status.224 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.208, i32 %local.check.extent.209)
  %helper.ok.225 = icmp eq i32 %descriptor.initialized.status.224, 0
  br i1 %helper.ok.225, label %helper.continue.226, label %frame.failure.0
helper.continue.226:
  br label %local.descriptor.checked.207
local.descriptor.inactive.206:
  br label %local.descriptor.checked.207
local.descriptor.checked.207:
  %step.status.227 = call i32 @al_owning_charge_step(ptr %ctx, i32 12)
  %helper.ok.228 = icmp eq i32 %step.status.227, 0
  br i1 %helper.ok.228, label %helper.continue.229, label %frame.failure.0
helper.continue.229:
  %context.field.230 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.231 = load i32, ptr %context.field.230, align 4
  %string.concat.units.232 = alloca i32, align 4
  %string.concat.payload.pointer.233 = alloca i32, align 4
  %string.concat.extent.pointer.234 = alloca i32, align 4
  %string.concat.plan.status.235 = call i32 @al_owning_string_concat_plan(ptr %ctx, i32 %context.value.110, i32 16, i32 %context.value.162, i32 16, i32 13, ptr %string.concat.units.232, ptr %string.concat.payload.pointer.233, ptr %string.concat.extent.pointer.234)
  %helper.ok.236 = icmp eq i32 %string.concat.plan.status.235, 0
  br i1 %helper.ok.236, label %helper.continue.237, label %frame.failure.0
helper.continue.237:
  %string.concat.payload.238 = load i32, ptr %string.concat.payload.pointer.233, align 4
  %string.concat.extent.239 = load i32, ptr %string.concat.extent.pointer.234, align 4
  %stack.offset.240 = add i32 %context.value.231, %string.concat.extent.239
  %reserve.status.241 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.240, i32 14)
  %reserve.ok.242 = icmp eq i32 %reserve.status.241, 0
  br i1 %reserve.ok.242, label %reserve.continue.243, label %frame.failure.0
reserve.continue.243:
  %string.concat.write.status.244 = call i32 @al_owning_string_concat_write(ptr %ctx, i32 %context.value.231, i32 %string.concat.extent.239, i32 %context.value.110, i32 16, i32 %context.value.162, i32 16, i32 12, i32 13)
  %helper.ok.245 = icmp eq i32 %string.concat.write.status.244, 0
  br i1 %helper.ok.245, label %helper.continue.246, label %frame.failure.0
helper.continue.246:
  call void @al_owning_update_live(ptr %ctx, i32 %string.concat.payload.238, i32 0)
  %context.field.247 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.248 = load i32, ptr %context.field.247, align 4
  %runtime.ok.249 = icmp eq i32 %context.value.248, 0
  br i1 %runtime.ok.249, label %runtime.continue.250, label %frame.failure.0
runtime.continue.250:
  %context.field.251 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.252 = load i32, ptr %context.field.251, align 4
  %stack.sub.255 = sub i32 %stack.offset.240, %context.value.231
  %descriptor.owner.inside.253 = icmp ule i32 %stack.offset.240, %context.value.252
  %descriptor.offset.inside.254 = icmp ule i32 %context.value.231, %stack.offset.240
  %descriptor.extent.inside.256 = icmp ule i32 %string.concat.extent.239, %stack.sub.255
  %descriptor.payload.inside.257 = icmp ule i32 %string.concat.payload.238, %string.concat.extent.239
  %descriptor.owner.offset.valid.258 = and i1 %descriptor.owner.inside.253, %descriptor.offset.inside.254
  %descriptor.range.inside.260 = and i1 %descriptor.owner.offset.valid.258, %descriptor.extent.inside.256
  %descriptor.range.valid.259 = and i1 %descriptor.range.inside.260, %descriptor.payload.inside.257
  %descriptor.type.valid.261 = icmp eq i32 12, 12
  %descriptor.valid.262 = and i1 %descriptor.range.valid.259, %descriptor.type.valid.261
  br i1 %descriptor.valid.262, label %descriptor.valid.263, label %descriptor.invalid.264
descriptor.invalid.264:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.263:
  %descriptor.initialized.status.265 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.231, i32 %string.concat.extent.239)
  %helper.ok.266 = icmp eq i32 %descriptor.initialized.status.265, 0
  br i1 %helper.ok.266, label %helper.continue.267, label %frame.failure.0
helper.continue.267:
  %local.is.active.268 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.268, label %local.descriptor.active.269, label %local.descriptor.inactive.270
local.descriptor.active.269:
  %local.check.offset.272 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.273 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.274 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.275 = load i32, ptr %local.owner.end.6, align 4
  %context.field.276 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.277 = load i32, ptr %context.field.276, align 4
  %stack.sub.280 = sub i32 %local.check.owner.end.275, %local.check.offset.272
  %descriptor.owner.inside.278 = icmp ule i32 %local.check.owner.end.275, %context.value.277
  %descriptor.offset.inside.279 = icmp ule i32 %local.check.offset.272, %local.check.owner.end.275
  %descriptor.extent.inside.281 = icmp ule i32 %local.check.extent.273, %stack.sub.280
  %descriptor.payload.inside.282 = icmp ule i32 %local.check.payload.274, %local.check.extent.273
  %descriptor.owner.offset.valid.283 = and i1 %descriptor.owner.inside.278, %descriptor.offset.inside.279
  %descriptor.range.inside.285 = and i1 %descriptor.owner.offset.valid.283, %descriptor.extent.inside.281
  %descriptor.range.valid.284 = and i1 %descriptor.range.inside.285, %descriptor.payload.inside.282
  br i1 %descriptor.range.valid.284, label %descriptor.valid.286, label %descriptor.invalid.287
descriptor.invalid.287:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.286:
  %descriptor.initialized.status.288 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.272, i32 %local.check.extent.273)
  %helper.ok.289 = icmp eq i32 %descriptor.initialized.status.288, 0
  br i1 %helper.ok.289, label %helper.continue.290, label %frame.failure.0
helper.continue.290:
  br label %local.descriptor.checked.271
local.descriptor.inactive.270:
  br label %local.descriptor.checked.271
local.descriptor.checked.271:
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %context.field.291 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.292 = load i32, ptr %context.field.291, align 4
  %stack.sub.295 = sub i32 %stack.offset.240, %context.value.231
  %descriptor.owner.inside.293 = icmp ule i32 %stack.offset.240, %context.value.292
  %descriptor.offset.inside.294 = icmp ule i32 %context.value.231, %stack.offset.240
  %descriptor.extent.inside.296 = icmp ule i32 %string.concat.extent.239, %stack.sub.295
  %descriptor.payload.inside.297 = icmp ule i32 %string.concat.payload.238, %string.concat.extent.239
  %descriptor.owner.offset.valid.298 = and i1 %descriptor.owner.inside.293, %descriptor.offset.inside.294
  %descriptor.range.inside.300 = and i1 %descriptor.owner.offset.valid.298, %descriptor.extent.inside.296
  %descriptor.range.valid.299 = and i1 %descriptor.range.inside.300, %descriptor.payload.inside.297
  %descriptor.type.valid.301 = icmp eq i32 12, 12
  %descriptor.valid.302 = and i1 %descriptor.range.valid.299, %descriptor.type.valid.301
  br i1 %descriptor.valid.302, label %descriptor.valid.303, label %descriptor.invalid.304
descriptor.invalid.304:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.303:
  %descriptor.initialized.status.305 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.231, i32 %string.concat.extent.239)
  %helper.ok.306 = icmp eq i32 %descriptor.initialized.status.305, 0
  br i1 %helper.ok.306, label %helper.continue.307, label %frame.failure.0
helper.continue.307:
  %local.is.active.308 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.308, label %local.descriptor.active.309, label %local.descriptor.inactive.310
local.descriptor.active.309:
  %local.check.offset.312 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.313 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.314 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.315 = load i32, ptr %local.owner.end.6, align 4
  %context.field.316 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.317 = load i32, ptr %context.field.316, align 4
  %stack.sub.320 = sub i32 %local.check.owner.end.315, %local.check.offset.312
  %descriptor.owner.inside.318 = icmp ule i32 %local.check.owner.end.315, %context.value.317
  %descriptor.offset.inside.319 = icmp ule i32 %local.check.offset.312, %local.check.owner.end.315
  %descriptor.extent.inside.321 = icmp ule i32 %local.check.extent.313, %stack.sub.320
  %descriptor.payload.inside.322 = icmp ule i32 %local.check.payload.314, %local.check.extent.313
  %descriptor.owner.offset.valid.323 = and i1 %descriptor.owner.inside.318, %descriptor.offset.inside.319
  %descriptor.range.inside.325 = and i1 %descriptor.owner.offset.valid.323, %descriptor.extent.inside.321
  %descriptor.range.valid.324 = and i1 %descriptor.range.inside.325, %descriptor.payload.inside.322
  br i1 %descriptor.range.valid.324, label %descriptor.valid.326, label %descriptor.invalid.327
descriptor.invalid.327:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.326:
  %descriptor.initialized.status.328 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.312, i32 %local.check.extent.313)
  %helper.ok.329 = icmp eq i32 %descriptor.initialized.status.328, 0
  br i1 %helper.ok.329, label %helper.continue.330, label %frame.failure.0
helper.continue.330:
  br label %local.descriptor.checked.311
local.descriptor.inactive.310:
  br label %local.descriptor.checked.311
local.descriptor.checked.311:
  %descriptor.element.331 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.332 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.331, i32 0, i32 0
  store i32 12, ptr %descriptor.field.332, align 4
  %descriptor.field.333 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.331, i32 0, i32 1
  store i32 %context.value.231, ptr %descriptor.field.333, align 4
  %descriptor.field.334 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.331, i32 0, i32 2
  store i32 %string.concat.extent.239, ptr %descriptor.field.334, align 4
  %descriptor.field.335 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.331, i32 0, i32 3
  store i32 %string.concat.payload.238, ptr %descriptor.field.335, align 4
  %descriptor.field.336 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.331, i32 0, i32 4
  store i32 %stack.offset.240, ptr %descriptor.field.336, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %context.value.231, i32 20, i32 %string.concat.payload.238, i32 %stack.offset.240, i32 %string.concat.extent.239)
  %context.field.337 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.338 = load i32, ptr %context.field.337, align 4
  %runtime.ok.339 = icmp eq i32 %context.value.338, 0
  br i1 %runtime.ok.339, label %runtime.continue.340, label %frame.failure.0
runtime.continue.340:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.9, i32 0, i32 0, i32 0)
  %context.field.341 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.342 = load i32, ptr %context.field.341, align 4
  %context.field.343 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.344 = load i32, ptr %context.field.343, align 4
  %context.field.345 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.346 = load i32, ptr %context.field.345, align 4
  %stack.offset.347 = add i32 %context.value.11, %context.value.13
  %stack.offset.348 = add i32 %context.value.342, %context.value.344
  %stack.sub.349 = sub i32 %stack.offset.347, %stack.offset.348
  %stack.sub.350 = sub i32 %context.value.13, %context.value.344
  %stack.sub.351 = sub i32 %context.value.346, %context.value.15
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.349, i32 %stack.sub.350)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.351)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 0
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 0, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %input.total.exact.10 = icmp eq i32 0, %input.bytes
  br i1 %input.total.exact.10, label %input.valid.11, label %input.invalid.12
input.invalid.12:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 0, i32 %input.bytes)
  br label %entry.failure.0
input.valid.11:
  %reserve.status.13 = call i32 @al_owning_reserve_to(ptr %ctx, i32 0, i32 15)
  %reserve.ok.14 = icmp eq i32 %reserve.status.13, 0
  br i1 %reserve.ok.14, label %reserve.continue.15, label %entry.failure.0
reserve.continue.15:
  %entry.output.descriptors.16 = alloca [1 x %AlOwningDescriptor], align 4
  %entry.body.status.17 = call i32 @agentlang_entry_frame(ptr %ctx, ptr null, ptr %entry.output.descriptors.16, i32 16)
  %entry.body.ok.18 = icmp eq i32 %entry.body.status.17, 0
  br i1 %entry.body.ok.18, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.19 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.16, i32 0
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 0
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 1
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %descriptor.field.24 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 2
  %descriptor.value.25 = load i32, ptr %descriptor.field.24, align 4
  %descriptor.field.26 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 3
  %descriptor.value.27 = load i32, ptr %descriptor.field.26, align 4
  %descriptor.field.28 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 4
  %descriptor.value.29 = load i32, ptr %descriptor.field.28, align 4
  %entry.output.type.valid.30 = icmp eq i32 %descriptor.value.21, 12
  br i1 %entry.output.type.valid.30, label %entry.output.type.ok.31, label %entry.output.type.invalid.32
entry.output.type.invalid.32:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.31:
  %context.field.33 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.34 = load i32, ptr %context.field.33, align 4
  %stack.sub.37 = sub i32 %descriptor.value.29, %descriptor.value.23
  %descriptor.owner.inside.35 = icmp ule i32 %descriptor.value.29, %context.value.34
  %descriptor.offset.inside.36 = icmp ule i32 %descriptor.value.23, %descriptor.value.29
  %descriptor.extent.inside.38 = icmp ule i32 %descriptor.value.25, %stack.sub.37
  %descriptor.payload.inside.39 = icmp ule i32 %descriptor.value.27, %descriptor.value.25
  %descriptor.owner.offset.valid.40 = and i1 %descriptor.owner.inside.35, %descriptor.offset.inside.36
  %descriptor.range.inside.42 = and i1 %descriptor.owner.offset.valid.40, %descriptor.extent.inside.38
  %descriptor.range.valid.41 = and i1 %descriptor.range.inside.42, %descriptor.payload.inside.39
  %descriptor.type.valid.43 = icmp eq i32 12, 12
  %descriptor.valid.44 = and i1 %descriptor.range.valid.41, %descriptor.type.valid.43
  br i1 %descriptor.valid.44, label %descriptor.valid.45, label %descriptor.invalid.46
descriptor.invalid.46:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.45:
  %descriptor.initialized.status.47 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.23, i32 %descriptor.value.25)
  %helper.ok.48 = icmp eq i32 %descriptor.initialized.status.47, 0
  br i1 %helper.ok.48, label %helper.continue.49, label %entry.failure.0
helper.continue.49:
  %entry.output.size.i64.50 = zext i32 %descriptor.value.25 to i64
  %entry.output.total.i64.51 = add i64 0, %entry.output.size.i64.50
  %entry.retained.capacity.i64.52 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.53 = icmp ule i64 %entry.output.total.i64.51, 4294967295
  %entry.retained.required.truncated.54 = trunc i64 %entry.output.total.i64.51 to i32
  %entry.retained.required.55 = select i1 %entry.retained.required.fits.u32.53, i32 %entry.retained.required.truncated.54, i32 4294967295
  %entry.retained.capacity.ok.56 = icmp ule i64 %entry.output.total.i64.51, %entry.retained.capacity.i64.52
  br i1 %entry.retained.capacity.ok.56, label %entry.retained.capacity.ready.57, label %entry.retained.capacity.failure.58
entry.retained.capacity.failure.58:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.55, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.57:
  %host.pointer.59 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.60 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.59, i32 %stack.sub.60, i32 %descriptor.value.23, i32 %descriptor.value.25, i32 12)
  %context.field.61 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.62 = load i32, ptr %context.field.61, align 4
  %runtime.ok.63 = icmp eq i32 %context.value.62, 0
  br i1 %runtime.ok.63, label %runtime.continue.64, label %entry.failure.0
runtime.continue.64:
  %stack.offset.65 = add i32 0, %descriptor.value.25
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.66 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.67 = load i32, ptr %context.field.66, align 4
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %stack.sub.70 = sub i32 0, %context.value.67
  %stack.sub.71 = sub i32 0, %context.value.69
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.70, i32 %stack.sub.71)
  %context.field.72 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.73 = load i32, ptr %context.field.72, align 4
  %runtime.ok.74 = icmp eq i32 %context.value.73, 0
  br i1 %runtime.ok.74, label %runtime.continue.75, label %entry.failure.0
runtime.continue.75:
  br label %entry.return.status
entry.failure.0:
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %context.field.78 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.79 = load i32, ptr %context.field.78, align 4
  %context.field.80 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.81 = load i32, ptr %context.field.80, align 4
  %stack.offset.82 = add i32 %context.value.77, %context.value.79
  %stack.sub.83 = sub i32 0, %stack.offset.82
  %stack.sub.84 = sub i32 0, %context.value.79
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.83, i32 %stack.sub.84)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.81)
  br label %entry.return.status
entry.return.status:
  %context.field.85 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.86 = load i32, ptr %context.field.85, align 4
  ret i32 %context.value.86
}


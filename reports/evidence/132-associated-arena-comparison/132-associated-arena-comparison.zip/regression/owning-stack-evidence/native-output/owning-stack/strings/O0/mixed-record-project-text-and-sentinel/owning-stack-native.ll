%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [4 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8 }, %AlOwningTypeDescriptor { i32 4, i32 4, i32 0, i32 0, i32 0, i32 8, i32 0, i32 8 }, %AlOwningTypeDescriptor { i32 4, i32 10, i32 0, i32 3, i32 4294967295, i32 4294967295, i32 16, i32 16 }, %AlOwningTypeDescriptor { i32 5, i32 12, i32 3, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8 }], align 4
@al_owning_fields = private constant [3 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 1, i32 0, i32 1, i32 0 }, %AlOwningFieldDescriptor { i32 3, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 4294967295, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 1, ptr @al_owning_types, i32 4, ptr @al_owning_fields, i32 3 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 10
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 10, 10
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %step.status.43 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.44 = icmp eq i32 %step.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %frame.failure.0
helper.continue.45:
  %call.arguments.46 = alloca [1 x %AlOwningDescriptor], align 4
  %descriptor.element.47 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.46, i32 0
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 0
  store i32 10, ptr %descriptor.field.48, align 4
  %descriptor.field.49 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.49, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.50, align 4
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.51, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.52, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 10, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.53 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.54 = load i32, ptr %context.field.53, align 4
  %runtime.ok.55 = icmp eq i32 %context.value.54, 0
  br i1 %runtime.ok.55, label %runtime.continue.56, label %frame.failure.0
runtime.continue.56:
  %call.results.57 = alloca [2 x %AlOwningDescriptor], align 4
  %callee.status.58 = call i32 @agentlang_word_0000(ptr %ctx, ptr %call.arguments.46, ptr %call.results.57, i32 2)
  %helper.ok.59 = icmp eq i32 %callee.status.58, 0
  br i1 %helper.ok.59, label %helper.continue.60, label %frame.failure.0
helper.continue.60:
  %descriptor.element.61 = getelementptr inbounds %AlOwningDescriptor, ptr %call.results.57, i32 0
  %descriptor.field.62 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 0
  %descriptor.value.63 = load i32, ptr %descriptor.field.62, align 4
  %descriptor.field.64 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 1
  %descriptor.value.65 = load i32, ptr %descriptor.field.64, align 4
  %descriptor.field.66 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 2
  %descriptor.value.67 = load i32, ptr %descriptor.field.66, align 4
  %descriptor.field.68 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 3
  %descriptor.value.69 = load i32, ptr %descriptor.field.68, align 4
  %descriptor.field.70 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.61, i32 0, i32 4
  %descriptor.value.71 = load i32, ptr %descriptor.field.70, align 4
  %callee.result.type.valid.72 = icmp eq i32 %descriptor.value.63, 12
  br i1 %callee.result.type.valid.72, label %callee.result.type.ok.73, label %frame.failure.0
callee.result.type.ok.73:
  %context.field.74 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.75 = load i32, ptr %context.field.74, align 4
  %stack.sub.78 = sub i32 %descriptor.value.71, %descriptor.value.65
  %descriptor.owner.inside.76 = icmp ule i32 %descriptor.value.71, %context.value.75
  %descriptor.offset.inside.77 = icmp ule i32 %descriptor.value.65, %descriptor.value.71
  %descriptor.extent.inside.79 = icmp ule i32 %descriptor.value.67, %stack.sub.78
  %descriptor.payload.inside.80 = icmp ule i32 %descriptor.value.69, %descriptor.value.67
  %descriptor.owner.offset.valid.81 = and i1 %descriptor.owner.inside.76, %descriptor.offset.inside.77
  %descriptor.range.inside.83 = and i1 %descriptor.owner.offset.valid.81, %descriptor.extent.inside.79
  %descriptor.range.valid.82 = and i1 %descriptor.range.inside.83, %descriptor.payload.inside.80
  %descriptor.type.valid.84 = icmp eq i32 12, 12
  %descriptor.valid.85 = and i1 %descriptor.range.valid.82, %descriptor.type.valid.84
  br i1 %descriptor.valid.85, label %descriptor.valid.86, label %descriptor.invalid.87
descriptor.invalid.87:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.86:
  %descriptor.initialized.status.88 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.65, i32 %descriptor.value.67)
  %helper.ok.89 = icmp eq i32 %descriptor.initialized.status.88, 0
  br i1 %helper.ok.89, label %helper.continue.90, label %frame.failure.0
helper.continue.90:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %descriptor.value.65, i32 20, i32 %descriptor.value.69, i32 %descriptor.value.71, i32 %descriptor.value.67)
  %context.field.91 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.92 = load i32, ptr %context.field.91, align 4
  %runtime.ok.93 = icmp eq i32 %context.value.92, 0
  br i1 %runtime.ok.93, label %runtime.continue.94, label %frame.failure.0
runtime.continue.94:
  %descriptor.element.95 = getelementptr inbounds %AlOwningDescriptor, ptr %call.results.57, i32 1
  %descriptor.field.96 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.95, i32 0, i32 0
  %descriptor.value.97 = load i32, ptr %descriptor.field.96, align 4
  %descriptor.field.98 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.95, i32 0, i32 1
  %descriptor.value.99 = load i32, ptr %descriptor.field.98, align 4
  %descriptor.field.100 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.95, i32 0, i32 2
  %descriptor.value.101 = load i32, ptr %descriptor.field.100, align 4
  %descriptor.field.102 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.95, i32 0, i32 3
  %descriptor.value.103 = load i32, ptr %descriptor.field.102, align 4
  %descriptor.field.104 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.95, i32 0, i32 4
  %descriptor.value.105 = load i32, ptr %descriptor.field.104, align 4
  %callee.result.type.valid.106 = icmp eq i32 %descriptor.value.97, 1
  br i1 %callee.result.type.valid.106, label %callee.result.type.ok.107, label %frame.failure.0
callee.result.type.ok.107:
  %context.field.108 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.109 = load i32, ptr %context.field.108, align 4
  %stack.sub.112 = sub i32 %descriptor.value.105, %descriptor.value.99
  %descriptor.owner.inside.110 = icmp ule i32 %descriptor.value.105, %context.value.109
  %descriptor.offset.inside.111 = icmp ule i32 %descriptor.value.99, %descriptor.value.105
  %descriptor.extent.inside.113 = icmp ule i32 %descriptor.value.101, %stack.sub.112
  %descriptor.payload.inside.114 = icmp ule i32 %descriptor.value.103, %descriptor.value.101
  %descriptor.owner.offset.valid.115 = and i1 %descriptor.owner.inside.110, %descriptor.offset.inside.111
  %descriptor.range.inside.117 = and i1 %descriptor.owner.offset.valid.115, %descriptor.extent.inside.113
  %descriptor.range.valid.116 = and i1 %descriptor.range.inside.117, %descriptor.payload.inside.114
  %descriptor.type.valid.118 = icmp eq i32 1, 1
  %descriptor.valid.119 = and i1 %descriptor.range.valid.116, %descriptor.type.valid.118
  br i1 %descriptor.valid.119, label %descriptor.valid.120, label %descriptor.invalid.121
descriptor.invalid.121:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.120:
  %descriptor.initialized.status.122 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.99, i32 %descriptor.value.101)
  %helper.ok.123 = icmp eq i32 %descriptor.initialized.status.122, 0
  br i1 %helper.ok.123, label %helper.continue.124, label %frame.failure.0
helper.continue.124:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %descriptor.value.99, i32 20, i32 %descriptor.value.103, i32 %descriptor.value.105, i32 %descriptor.value.101)
  %context.field.125 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.126 = load i32, ptr %context.field.125, align 4
  %runtime.ok.127 = icmp eq i32 %context.value.126, 0
  br i1 %runtime.ok.127, label %runtime.continue.128, label %frame.failure.0
runtime.continue.128:
  %context.field.129 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.130 = load i32, ptr %context.field.129, align 4
  %stack.sub.133 = sub i32 %descriptor.value.71, %descriptor.value.65
  %descriptor.owner.inside.131 = icmp ule i32 %descriptor.value.71, %context.value.130
  %descriptor.offset.inside.132 = icmp ule i32 %descriptor.value.65, %descriptor.value.71
  %descriptor.extent.inside.134 = icmp ule i32 %descriptor.value.67, %stack.sub.133
  %descriptor.payload.inside.135 = icmp ule i32 %descriptor.value.69, %descriptor.value.67
  %descriptor.owner.offset.valid.136 = and i1 %descriptor.owner.inside.131, %descriptor.offset.inside.132
  %descriptor.range.inside.138 = and i1 %descriptor.owner.offset.valid.136, %descriptor.extent.inside.134
  %descriptor.range.valid.137 = and i1 %descriptor.range.inside.138, %descriptor.payload.inside.135
  %descriptor.type.valid.139 = icmp eq i32 12, 12
  %descriptor.valid.140 = and i1 %descriptor.range.valid.137, %descriptor.type.valid.139
  br i1 %descriptor.valid.140, label %descriptor.valid.141, label %descriptor.invalid.142
descriptor.invalid.142:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.141:
  %descriptor.initialized.status.143 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.65, i32 %descriptor.value.67)
  %helper.ok.144 = icmp eq i32 %descriptor.initialized.status.143, 0
  br i1 %helper.ok.144, label %helper.continue.145, label %frame.failure.0
helper.continue.145:
  %context.field.146 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.147 = load i32, ptr %context.field.146, align 4
  %stack.sub.150 = sub i32 %descriptor.value.105, %descriptor.value.99
  %descriptor.owner.inside.148 = icmp ule i32 %descriptor.value.105, %context.value.147
  %descriptor.offset.inside.149 = icmp ule i32 %descriptor.value.99, %descriptor.value.105
  %descriptor.extent.inside.151 = icmp ule i32 %descriptor.value.101, %stack.sub.150
  %descriptor.payload.inside.152 = icmp ule i32 %descriptor.value.103, %descriptor.value.101
  %descriptor.owner.offset.valid.153 = and i1 %descriptor.owner.inside.148, %descriptor.offset.inside.149
  %descriptor.range.inside.155 = and i1 %descriptor.owner.offset.valid.153, %descriptor.extent.inside.151
  %descriptor.range.valid.154 = and i1 %descriptor.range.inside.155, %descriptor.payload.inside.152
  %descriptor.type.valid.156 = icmp eq i32 1, 1
  %descriptor.valid.157 = and i1 %descriptor.range.valid.154, %descriptor.type.valid.156
  br i1 %descriptor.valid.157, label %descriptor.valid.158, label %descriptor.invalid.159
descriptor.invalid.159:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.158:
  %descriptor.initialized.status.160 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.99, i32 %descriptor.value.101)
  %helper.ok.161 = icmp eq i32 %descriptor.initialized.status.160, 0
  br i1 %helper.ok.161, label %helper.continue.162, label %frame.failure.0
helper.continue.162:
  %descriptor.element.163 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.164 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.163, i32 0, i32 0
  store i32 12, ptr %descriptor.field.164, align 4
  %descriptor.field.165 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.163, i32 0, i32 1
  store i32 %descriptor.value.65, ptr %descriptor.field.165, align 4
  %descriptor.field.166 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.163, i32 0, i32 2
  store i32 %descriptor.value.67, ptr %descriptor.field.166, align 4
  %descriptor.field.167 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.163, i32 0, i32 3
  store i32 %descriptor.value.69, ptr %descriptor.field.167, align 4
  %descriptor.field.168 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.163, i32 0, i32 4
  store i32 %descriptor.value.71, ptr %descriptor.field.168, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %descriptor.value.65, i32 20, i32 %descriptor.value.69, i32 %descriptor.value.71, i32 %descriptor.value.67)
  %context.field.169 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.170 = load i32, ptr %context.field.169, align 4
  %runtime.ok.171 = icmp eq i32 %context.value.170, 0
  br i1 %runtime.ok.171, label %runtime.continue.172, label %frame.failure.0
runtime.continue.172:
  %descriptor.element.173 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 1
  %descriptor.field.174 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.173, i32 0, i32 0
  store i32 1, ptr %descriptor.field.174, align 4
  %descriptor.field.175 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.173, i32 0, i32 1
  store i32 %descriptor.value.99, ptr %descriptor.field.175, align 4
  %descriptor.field.176 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.173, i32 0, i32 2
  store i32 %descriptor.value.101, ptr %descriptor.field.176, align 4
  %descriptor.field.177 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.173, i32 0, i32 3
  store i32 %descriptor.value.103, ptr %descriptor.field.177, align 4
  %descriptor.field.178 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.173, i32 0, i32 4
  store i32 %descriptor.value.105, ptr %descriptor.field.178, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %descriptor.value.99, i32 20, i32 %descriptor.value.103, i32 %descriptor.value.105, i32 %descriptor.value.101)
  %context.field.179 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.180 = load i32, ptr %context.field.179, align 4
  %runtime.ok.181 = icmp eq i32 %context.value.180, 0
  br i1 %runtime.ok.181, label %runtime.continue.182, label %frame.failure.0
runtime.continue.182:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.183 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.184 = load i32, ptr %context.field.183, align 4
  %context.field.185 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.186 = load i32, ptr %context.field.185, align 4
  %context.field.187 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.188 = load i32, ptr %context.field.187, align 4
  %stack.offset.189 = add i32 %context.value.5, %context.value.7
  %stack.offset.190 = add i32 %context.value.184, %context.value.186
  %stack.sub.191 = sub i32 %stack.offset.189, %stack.offset.190
  %stack.sub.192 = sub i32 %context.value.7, %context.value.186
  %stack.sub.193 = sub i32 %context.value.188, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.191, i32 %stack.sub.192)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.193)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %local.active.2 = alloca i1, align 1
  %local.offset.3 = alloca i32, align 4
  %local.extent.4 = alloca i32, align 4
  %local.payload.5 = alloca i32, align 4
  %local.owner.end.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %local.active.8 = alloca i1, align 1
  %local.offset.9 = alloca i32, align 4
  %local.extent.10 = alloca i32, align 4
  %local.payload.11 = alloca i32, align 4
  %local.owner.end.12 = alloca i32, align 4
  %local.type.13 = alloca i32, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  %local.active.14 = alloca i1, align 1
  %local.offset.15 = alloca i32, align 4
  %local.extent.16 = alloca i32, align 4
  %local.payload.17 = alloca i32, align 4
  %local.owner.end.18 = alloca i32, align 4
  %local.type.19 = alloca i32, align 4
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  %context.field.20 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.21 = load i32, ptr %context.field.20, align 4
  %context.field.22 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.23 = load i32, ptr %context.field.22, align 4
  %context.field.24 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.25 = load i32, ptr %context.field.24, align 4
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %frame.entered.28 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.29 = icmp eq i32 %frame.entered.28, 0
  br i1 %frame.enter.ok.29, label %frame.enter.continue.30, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.30:
  %descriptor.element.31 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.32 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.31, i32 0, i32 0
  %descriptor.value.33 = load i32, ptr %descriptor.field.32, align 4
  %descriptor.field.34 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.31, i32 0, i32 1
  %descriptor.value.35 = load i32, ptr %descriptor.field.34, align 4
  %descriptor.field.36 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.31, i32 0, i32 2
  %descriptor.value.37 = load i32, ptr %descriptor.field.36, align 4
  %descriptor.field.38 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.31, i32 0, i32 3
  %descriptor.value.39 = load i32, ptr %descriptor.field.38, align 4
  %descriptor.field.40 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.31, i32 0, i32 4
  %descriptor.value.41 = load i32, ptr %descriptor.field.40, align 4
  %argument.type.valid.42 = icmp eq i32 %descriptor.value.33, 10
  br i1 %argument.type.valid.42, label %argument.type.ok.43, label %frame.failure.0
argument.type.ok.43:
  %context.field.44 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.45 = load i32, ptr %context.field.44, align 4
  %stack.sub.48 = sub i32 %descriptor.value.41, %descriptor.value.35
  %descriptor.owner.inside.46 = icmp ule i32 %descriptor.value.41, %context.value.45
  %descriptor.offset.inside.47 = icmp ule i32 %descriptor.value.35, %descriptor.value.41
  %descriptor.extent.inside.49 = icmp ule i32 %descriptor.value.37, %stack.sub.48
  %descriptor.payload.inside.50 = icmp ule i32 %descriptor.value.39, %descriptor.value.37
  %descriptor.owner.offset.valid.51 = and i1 %descriptor.owner.inside.46, %descriptor.offset.inside.47
  %descriptor.range.inside.53 = and i1 %descriptor.owner.offset.valid.51, %descriptor.extent.inside.49
  %descriptor.range.valid.52 = and i1 %descriptor.range.inside.53, %descriptor.payload.inside.50
  %descriptor.type.valid.54 = icmp eq i32 10, 10
  %descriptor.valid.55 = and i1 %descriptor.range.valid.52, %descriptor.type.valid.54
  br i1 %descriptor.valid.55, label %descriptor.valid.56, label %descriptor.invalid.57
descriptor.invalid.57:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.56:
  %descriptor.initialized.status.58 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.35, i32 %descriptor.value.37)
  %helper.ok.59 = icmp eq i32 %descriptor.initialized.status.58, 0
  br i1 %helper.ok.59, label %helper.continue.60, label %frame.failure.0
helper.continue.60:
  %step.status.61 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.62 = icmp eq i32 %step.status.61, 0
  br i1 %helper.ok.62, label %helper.continue.63, label %frame.failure.0
helper.continue.63:
  store i1 true, ptr %local.active.2, align 1
  store i32 %descriptor.value.35, ptr %local.offset.3, align 4
  store i32 %descriptor.value.37, ptr %local.extent.4, align 4
  store i32 %descriptor.value.39, ptr %local.payload.5, align 4
  store i32 %descriptor.value.41, ptr %local.owner.end.6, align 4
  store i32 10, ptr %local.type.7, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 10, i32 %descriptor.value.35, i32 20, i32 %descriptor.value.39, i32 %descriptor.value.41, i32 %descriptor.value.37)
  %context.field.64 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.65 = load i32, ptr %context.field.64, align 4
  %runtime.ok.66 = icmp eq i32 %context.value.65, 0
  br i1 %runtime.ok.66, label %runtime.continue.67, label %frame.failure.0
runtime.continue.67:
  %local.is.active.68 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.68, label %local.descriptor.active.69, label %local.descriptor.inactive.70
local.descriptor.active.69:
  %local.check.offset.72 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.73 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.74 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.75 = load i32, ptr %local.owner.end.6, align 4
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %stack.sub.80 = sub i32 %local.check.owner.end.75, %local.check.offset.72
  %descriptor.owner.inside.78 = icmp ule i32 %local.check.owner.end.75, %context.value.77
  %descriptor.offset.inside.79 = icmp ule i32 %local.check.offset.72, %local.check.owner.end.75
  %descriptor.extent.inside.81 = icmp ule i32 %local.check.extent.73, %stack.sub.80
  %descriptor.payload.inside.82 = icmp ule i32 %local.check.payload.74, %local.check.extent.73
  %descriptor.owner.offset.valid.83 = and i1 %descriptor.owner.inside.78, %descriptor.offset.inside.79
  %descriptor.range.inside.85 = and i1 %descriptor.owner.offset.valid.83, %descriptor.extent.inside.81
  %descriptor.range.valid.84 = and i1 %descriptor.range.inside.85, %descriptor.payload.inside.82
  br i1 %descriptor.range.valid.84, label %descriptor.valid.86, label %descriptor.invalid.87
descriptor.invalid.87:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.86:
  %descriptor.initialized.status.88 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.72, i32 %local.check.extent.73)
  %helper.ok.89 = icmp eq i32 %descriptor.initialized.status.88, 0
  br i1 %helper.ok.89, label %helper.continue.90, label %frame.failure.0
helper.continue.90:
  br label %local.descriptor.checked.71
local.descriptor.inactive.70:
  br label %local.descriptor.checked.71
local.descriptor.checked.71:
  %local.is.active.91 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.91, label %local.descriptor.active.92, label %local.descriptor.inactive.93
local.descriptor.active.92:
  %local.check.offset.95 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.96 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.97 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.98 = load i32, ptr %local.owner.end.12, align 4
  %context.field.99 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.100 = load i32, ptr %context.field.99, align 4
  %stack.sub.103 = sub i32 %local.check.owner.end.98, %local.check.offset.95
  %descriptor.owner.inside.101 = icmp ule i32 %local.check.owner.end.98, %context.value.100
  %descriptor.offset.inside.102 = icmp ule i32 %local.check.offset.95, %local.check.owner.end.98
  %descriptor.extent.inside.104 = icmp ule i32 %local.check.extent.96, %stack.sub.103
  %descriptor.payload.inside.105 = icmp ule i32 %local.check.payload.97, %local.check.extent.96
  %descriptor.owner.offset.valid.106 = and i1 %descriptor.owner.inside.101, %descriptor.offset.inside.102
  %descriptor.range.inside.108 = and i1 %descriptor.owner.offset.valid.106, %descriptor.extent.inside.104
  %descriptor.range.valid.107 = and i1 %descriptor.range.inside.108, %descriptor.payload.inside.105
  br i1 %descriptor.range.valid.107, label %descriptor.valid.109, label %descriptor.invalid.110
descriptor.invalid.110:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.109:
  %descriptor.initialized.status.111 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.95, i32 %local.check.extent.96)
  %helper.ok.112 = icmp eq i32 %descriptor.initialized.status.111, 0
  br i1 %helper.ok.112, label %helper.continue.113, label %frame.failure.0
helper.continue.113:
  br label %local.descriptor.checked.94
local.descriptor.inactive.93:
  br label %local.descriptor.checked.94
local.descriptor.checked.94:
  %local.is.active.114 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.114, label %local.descriptor.active.115, label %local.descriptor.inactive.116
local.descriptor.active.115:
  %local.check.offset.118 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.119 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.120 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.121 = load i32, ptr %local.owner.end.18, align 4
  %context.field.122 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.123 = load i32, ptr %context.field.122, align 4
  %stack.sub.126 = sub i32 %local.check.owner.end.121, %local.check.offset.118
  %descriptor.owner.inside.124 = icmp ule i32 %local.check.owner.end.121, %context.value.123
  %descriptor.offset.inside.125 = icmp ule i32 %local.check.offset.118, %local.check.owner.end.121
  %descriptor.extent.inside.127 = icmp ule i32 %local.check.extent.119, %stack.sub.126
  %descriptor.payload.inside.128 = icmp ule i32 %local.check.payload.120, %local.check.extent.119
  %descriptor.owner.offset.valid.129 = and i1 %descriptor.owner.inside.124, %descriptor.offset.inside.125
  %descriptor.range.inside.131 = and i1 %descriptor.owner.offset.valid.129, %descriptor.extent.inside.127
  %descriptor.range.valid.130 = and i1 %descriptor.range.inside.131, %descriptor.payload.inside.128
  br i1 %descriptor.range.valid.130, label %descriptor.valid.132, label %descriptor.invalid.133
descriptor.invalid.133:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.132:
  %descriptor.initialized.status.134 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.118, i32 %local.check.extent.119)
  %helper.ok.135 = icmp eq i32 %descriptor.initialized.status.134, 0
  br i1 %helper.ok.135, label %helper.continue.136, label %frame.failure.0
helper.continue.136:
  br label %local.descriptor.checked.117
local.descriptor.inactive.116:
  br label %local.descriptor.checked.117
local.descriptor.checked.117:
  %step.status.137 = call i32 @al_owning_charge_step(ptr %ctx, i32 4)
  %helper.ok.138 = icmp eq i32 %step.status.137, 0
  br i1 %helper.ok.138, label %helper.continue.139, label %frame.failure.0
helper.continue.139:
  %local.resolved.offset.140 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.141 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.142 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.143 = load i32, ptr %local.owner.end.6, align 4
  %context.field.144 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.145 = load i32, ptr %context.field.144, align 4
  %stack.sub.148 = sub i32 %local.resolved.owner.end.143, %local.resolved.offset.140
  %descriptor.owner.inside.146 = icmp ule i32 %local.resolved.owner.end.143, %context.value.145
  %descriptor.offset.inside.147 = icmp ule i32 %local.resolved.offset.140, %local.resolved.owner.end.143
  %descriptor.extent.inside.149 = icmp ule i32 %local.resolved.extent.141, %stack.sub.148
  %descriptor.payload.inside.150 = icmp ule i32 %local.resolved.payload.142, %local.resolved.extent.141
  %descriptor.owner.offset.valid.151 = and i1 %descriptor.owner.inside.146, %descriptor.offset.inside.147
  %descriptor.range.inside.153 = and i1 %descriptor.owner.offset.valid.151, %descriptor.extent.inside.149
  %descriptor.range.valid.152 = and i1 %descriptor.range.inside.153, %descriptor.payload.inside.150
  %descriptor.type.valid.154 = icmp eq i32 10, 10
  %descriptor.valid.155 = and i1 %descriptor.range.valid.152, %descriptor.type.valid.154
  br i1 %descriptor.valid.155, label %descriptor.valid.156, label %descriptor.invalid.157
descriptor.invalid.157:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.156:
  %descriptor.initialized.status.158 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.140, i32 %local.resolved.extent.141)
  %helper.ok.159 = icmp eq i32 %descriptor.initialized.status.158, 0
  br i1 %helper.ok.159, label %helper.continue.160, label %frame.failure.0
helper.continue.160:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 10, i32 %local.resolved.offset.140, i32 20, i32 %local.resolved.payload.142, i32 %local.resolved.owner.end.143, i32 %local.resolved.extent.141)
  %context.field.161 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.162 = load i32, ptr %context.field.161, align 4
  %runtime.ok.163 = icmp eq i32 %context.value.162, 0
  br i1 %runtime.ok.163, label %runtime.continue.164, label %frame.failure.0
runtime.continue.164:
  %context.field.165 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.166 = load i32, ptr %context.field.165, align 4
  %stack.sub.169 = sub i32 %local.resolved.owner.end.143, %local.resolved.offset.140
  %descriptor.owner.inside.167 = icmp ule i32 %local.resolved.owner.end.143, %context.value.166
  %descriptor.offset.inside.168 = icmp ule i32 %local.resolved.offset.140, %local.resolved.owner.end.143
  %descriptor.extent.inside.170 = icmp ule i32 %local.resolved.extent.141, %stack.sub.169
  %descriptor.payload.inside.171 = icmp ule i32 %local.resolved.payload.142, %local.resolved.extent.141
  %descriptor.owner.offset.valid.172 = and i1 %descriptor.owner.inside.167, %descriptor.offset.inside.168
  %descriptor.range.inside.174 = and i1 %descriptor.owner.offset.valid.172, %descriptor.extent.inside.170
  %descriptor.range.valid.173 = and i1 %descriptor.range.inside.174, %descriptor.payload.inside.171
  %descriptor.type.valid.175 = icmp eq i32 10, 10
  %descriptor.valid.176 = and i1 %descriptor.range.valid.173, %descriptor.type.valid.175
  br i1 %descriptor.valid.176, label %descriptor.valid.177, label %descriptor.invalid.178
descriptor.invalid.178:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.177:
  %descriptor.initialized.status.179 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.140, i32 %local.resolved.extent.141)
  %helper.ok.180 = icmp eq i32 %descriptor.initialized.status.179, 0
  br i1 %helper.ok.180, label %helper.continue.181, label %frame.failure.0
helper.continue.181:
  %local.is.active.182 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.182, label %local.descriptor.active.183, label %local.descriptor.inactive.184
local.descriptor.active.183:
  %local.check.offset.186 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.187 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.188 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.189 = load i32, ptr %local.owner.end.6, align 4
  %context.field.190 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.191 = load i32, ptr %context.field.190, align 4
  %stack.sub.194 = sub i32 %local.check.owner.end.189, %local.check.offset.186
  %descriptor.owner.inside.192 = icmp ule i32 %local.check.owner.end.189, %context.value.191
  %descriptor.offset.inside.193 = icmp ule i32 %local.check.offset.186, %local.check.owner.end.189
  %descriptor.extent.inside.195 = icmp ule i32 %local.check.extent.187, %stack.sub.194
  %descriptor.payload.inside.196 = icmp ule i32 %local.check.payload.188, %local.check.extent.187
  %descriptor.owner.offset.valid.197 = and i1 %descriptor.owner.inside.192, %descriptor.offset.inside.193
  %descriptor.range.inside.199 = and i1 %descriptor.owner.offset.valid.197, %descriptor.extent.inside.195
  %descriptor.range.valid.198 = and i1 %descriptor.range.inside.199, %descriptor.payload.inside.196
  br i1 %descriptor.range.valid.198, label %descriptor.valid.200, label %descriptor.invalid.201
descriptor.invalid.201:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.200:
  %descriptor.initialized.status.202 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.186, i32 %local.check.extent.187)
  %helper.ok.203 = icmp eq i32 %descriptor.initialized.status.202, 0
  br i1 %helper.ok.203, label %helper.continue.204, label %frame.failure.0
helper.continue.204:
  br label %local.descriptor.checked.185
local.descriptor.inactive.184:
  br label %local.descriptor.checked.185
local.descriptor.checked.185:
  %local.is.active.205 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.205, label %local.descriptor.active.206, label %local.descriptor.inactive.207
local.descriptor.active.206:
  %local.check.offset.209 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.210 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.211 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.212 = load i32, ptr %local.owner.end.12, align 4
  %context.field.213 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.214 = load i32, ptr %context.field.213, align 4
  %stack.sub.217 = sub i32 %local.check.owner.end.212, %local.check.offset.209
  %descriptor.owner.inside.215 = icmp ule i32 %local.check.owner.end.212, %context.value.214
  %descriptor.offset.inside.216 = icmp ule i32 %local.check.offset.209, %local.check.owner.end.212
  %descriptor.extent.inside.218 = icmp ule i32 %local.check.extent.210, %stack.sub.217
  %descriptor.payload.inside.219 = icmp ule i32 %local.check.payload.211, %local.check.extent.210
  %descriptor.owner.offset.valid.220 = and i1 %descriptor.owner.inside.215, %descriptor.offset.inside.216
  %descriptor.range.inside.222 = and i1 %descriptor.owner.offset.valid.220, %descriptor.extent.inside.218
  %descriptor.range.valid.221 = and i1 %descriptor.range.inside.222, %descriptor.payload.inside.219
  br i1 %descriptor.range.valid.221, label %descriptor.valid.223, label %descriptor.invalid.224
descriptor.invalid.224:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.223:
  %descriptor.initialized.status.225 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.209, i32 %local.check.extent.210)
  %helper.ok.226 = icmp eq i32 %descriptor.initialized.status.225, 0
  br i1 %helper.ok.226, label %helper.continue.227, label %frame.failure.0
helper.continue.227:
  br label %local.descriptor.checked.208
local.descriptor.inactive.207:
  br label %local.descriptor.checked.208
local.descriptor.checked.208:
  %local.is.active.228 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.228, label %local.descriptor.active.229, label %local.descriptor.inactive.230
local.descriptor.active.229:
  %local.check.offset.232 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.233 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.234 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.235 = load i32, ptr %local.owner.end.18, align 4
  %context.field.236 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.237 = load i32, ptr %context.field.236, align 4
  %stack.sub.240 = sub i32 %local.check.owner.end.235, %local.check.offset.232
  %descriptor.owner.inside.238 = icmp ule i32 %local.check.owner.end.235, %context.value.237
  %descriptor.offset.inside.239 = icmp ule i32 %local.check.offset.232, %local.check.owner.end.235
  %descriptor.extent.inside.241 = icmp ule i32 %local.check.extent.233, %stack.sub.240
  %descriptor.payload.inside.242 = icmp ule i32 %local.check.payload.234, %local.check.extent.233
  %descriptor.owner.offset.valid.243 = and i1 %descriptor.owner.inside.238, %descriptor.offset.inside.239
  %descriptor.range.inside.245 = and i1 %descriptor.owner.offset.valid.243, %descriptor.extent.inside.241
  %descriptor.range.valid.244 = and i1 %descriptor.range.inside.245, %descriptor.payload.inside.242
  br i1 %descriptor.range.valid.244, label %descriptor.valid.246, label %descriptor.invalid.247
descriptor.invalid.247:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.246:
  %descriptor.initialized.status.248 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.232, i32 %local.check.extent.233)
  %helper.ok.249 = icmp eq i32 %descriptor.initialized.status.248, 0
  br i1 %helper.ok.249, label %helper.continue.250, label %frame.failure.0
helper.continue.250:
  br label %local.descriptor.checked.231
local.descriptor.inactive.230:
  br label %local.descriptor.checked.231
local.descriptor.checked.231:
  %step.status.251 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.252 = icmp eq i32 %step.status.251, 0
  br i1 %helper.ok.252, label %helper.continue.253, label %frame.failure.0
helper.continue.253:
  %field.location.254 = alloca %AlOwningFieldLocation, align 4
  %field.location.status.255 = call i32 @al_owning_locate_field(ptr %ctx, ptr @al_owning_layout, i32 2, i32 %local.resolved.offset.140, i32 %local.resolved.extent.141, i32 1, i32 6, ptr %field.location.254)
  %helper.ok.256 = icmp eq i32 %field.location.status.255, 0
  br i1 %helper.ok.256, label %helper.continue.257, label %frame.failure.0
helper.continue.257:
  %field.offset.pointer.258 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.254, i32 0, i32 0
  %field.offset.259 = load i32, ptr %field.offset.pointer.258, align 4
  %field.payload.pointer.260 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.254, i32 0, i32 1
  %field.payload.261 = load i32, ptr %field.payload.pointer.260, align 4
  %field.extent.pointer.262 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.254, i32 0, i32 2
  %field.extent.263 = load i32, ptr %field.extent.pointer.262, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 7, i32 12, i32 %local.resolved.offset.140, i32 %field.extent.263, i32 %field.payload.261, i32 %field.offset.259, i32 %field.extent.263)
  %context.field.264 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.265 = load i32, ptr %context.field.264, align 4
  %runtime.ok.266 = icmp eq i32 %context.value.265, 0
  br i1 %runtime.ok.266, label %runtime.continue.267, label %frame.failure.0
runtime.continue.267:
  %context.field.268 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.269 = load i32, ptr %context.field.268, align 4
  %stack.sub.272 = sub i32 %local.resolved.owner.end.143, %field.offset.259
  %descriptor.owner.inside.270 = icmp ule i32 %local.resolved.owner.end.143, %context.value.269
  %descriptor.offset.inside.271 = icmp ule i32 %field.offset.259, %local.resolved.owner.end.143
  %descriptor.extent.inside.273 = icmp ule i32 %field.extent.263, %stack.sub.272
  %descriptor.payload.inside.274 = icmp ule i32 %field.payload.261, %field.extent.263
  %descriptor.owner.offset.valid.275 = and i1 %descriptor.owner.inside.270, %descriptor.offset.inside.271
  %descriptor.range.inside.277 = and i1 %descriptor.owner.offset.valid.275, %descriptor.extent.inside.273
  %descriptor.range.valid.276 = and i1 %descriptor.range.inside.277, %descriptor.payload.inside.274
  %descriptor.type.valid.278 = icmp eq i32 12, 12
  %descriptor.valid.279 = and i1 %descriptor.range.valid.276, %descriptor.type.valid.278
  br i1 %descriptor.valid.279, label %descriptor.valid.280, label %descriptor.invalid.281
descriptor.invalid.281:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.280:
  %descriptor.initialized.status.282 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %field.offset.259, i32 %field.extent.263)
  %helper.ok.283 = icmp eq i32 %descriptor.initialized.status.282, 0
  br i1 %helper.ok.283, label %helper.continue.284, label %frame.failure.0
helper.continue.284:
  %local.is.active.285 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.285, label %local.descriptor.active.286, label %local.descriptor.inactive.287
local.descriptor.active.286:
  %local.check.offset.289 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.290 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.291 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.292 = load i32, ptr %local.owner.end.6, align 4
  %context.field.293 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.294 = load i32, ptr %context.field.293, align 4
  %stack.sub.297 = sub i32 %local.check.owner.end.292, %local.check.offset.289
  %descriptor.owner.inside.295 = icmp ule i32 %local.check.owner.end.292, %context.value.294
  %descriptor.offset.inside.296 = icmp ule i32 %local.check.offset.289, %local.check.owner.end.292
  %descriptor.extent.inside.298 = icmp ule i32 %local.check.extent.290, %stack.sub.297
  %descriptor.payload.inside.299 = icmp ule i32 %local.check.payload.291, %local.check.extent.290
  %descriptor.owner.offset.valid.300 = and i1 %descriptor.owner.inside.295, %descriptor.offset.inside.296
  %descriptor.range.inside.302 = and i1 %descriptor.owner.offset.valid.300, %descriptor.extent.inside.298
  %descriptor.range.valid.301 = and i1 %descriptor.range.inside.302, %descriptor.payload.inside.299
  br i1 %descriptor.range.valid.301, label %descriptor.valid.303, label %descriptor.invalid.304
descriptor.invalid.304:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.303:
  %descriptor.initialized.status.305 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.289, i32 %local.check.extent.290)
  %helper.ok.306 = icmp eq i32 %descriptor.initialized.status.305, 0
  br i1 %helper.ok.306, label %helper.continue.307, label %frame.failure.0
helper.continue.307:
  br label %local.descriptor.checked.288
local.descriptor.inactive.287:
  br label %local.descriptor.checked.288
local.descriptor.checked.288:
  %local.is.active.308 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.308, label %local.descriptor.active.309, label %local.descriptor.inactive.310
local.descriptor.active.309:
  %local.check.offset.312 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.313 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.314 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.315 = load i32, ptr %local.owner.end.12, align 4
  %context.field.316 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.317 = load i32, ptr %context.field.316, align 4
  %stack.sub.320 = sub i32 %local.check.owner.end.315, %local.check.offset.312
  %descriptor.owner.inside.318 = icmp ule i32 %local.check.owner.end.315, %context.value.317
  %descriptor.offset.inside.319 = icmp ule i32 %local.check.offset.312, %local.check.owner.end.315
  %descriptor.extent.inside.321 = icmp ule i32 %local.check.extent.313, %stack.sub.320
  %descriptor.payload.inside.322 = icmp ule i32 %local.check.payload.314, %local.check.extent.313
  %descriptor.owner.offset.valid.323 = and i1 %descriptor.owner.inside.318, %descriptor.offset.inside.319
  %descriptor.range.inside.325 = and i1 %descriptor.owner.offset.valid.323, %descriptor.extent.inside.321
  %descriptor.range.valid.324 = and i1 %descriptor.range.inside.325, %descriptor.payload.inside.322
  br i1 %descriptor.range.valid.324, label %descriptor.valid.326, label %descriptor.invalid.327
descriptor.invalid.327:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.326:
  %descriptor.initialized.status.328 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.312, i32 %local.check.extent.313)
  %helper.ok.329 = icmp eq i32 %descriptor.initialized.status.328, 0
  br i1 %helper.ok.329, label %helper.continue.330, label %frame.failure.0
helper.continue.330:
  br label %local.descriptor.checked.311
local.descriptor.inactive.310:
  br label %local.descriptor.checked.311
local.descriptor.checked.311:
  %local.is.active.331 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.331, label %local.descriptor.active.332, label %local.descriptor.inactive.333
local.descriptor.active.332:
  %local.check.offset.335 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.336 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.337 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.338 = load i32, ptr %local.owner.end.18, align 4
  %context.field.339 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.340 = load i32, ptr %context.field.339, align 4
  %stack.sub.343 = sub i32 %local.check.owner.end.338, %local.check.offset.335
  %descriptor.owner.inside.341 = icmp ule i32 %local.check.owner.end.338, %context.value.340
  %descriptor.offset.inside.342 = icmp ule i32 %local.check.offset.335, %local.check.owner.end.338
  %descriptor.extent.inside.344 = icmp ule i32 %local.check.extent.336, %stack.sub.343
  %descriptor.payload.inside.345 = icmp ule i32 %local.check.payload.337, %local.check.extent.336
  %descriptor.owner.offset.valid.346 = and i1 %descriptor.owner.inside.341, %descriptor.offset.inside.342
  %descriptor.range.inside.348 = and i1 %descriptor.owner.offset.valid.346, %descriptor.extent.inside.344
  %descriptor.range.valid.347 = and i1 %descriptor.range.inside.348, %descriptor.payload.inside.345
  br i1 %descriptor.range.valid.347, label %descriptor.valid.349, label %descriptor.invalid.350
descriptor.invalid.350:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.349:
  %descriptor.initialized.status.351 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.335, i32 %local.check.extent.336)
  %helper.ok.352 = icmp eq i32 %descriptor.initialized.status.351, 0
  br i1 %helper.ok.352, label %helper.continue.353, label %frame.failure.0
helper.continue.353:
  br label %local.descriptor.checked.334
local.descriptor.inactive.333:
  br label %local.descriptor.checked.334
local.descriptor.checked.334:
  %step.status.354 = call i32 @al_owning_charge_step(ptr %ctx, i32 7)
  %helper.ok.355 = icmp eq i32 %step.status.354, 0
  br i1 %helper.ok.355, label %helper.continue.356, label %frame.failure.0
helper.continue.356:
  store i1 true, ptr %local.active.8, align 1
  store i32 %field.offset.259, ptr %local.offset.9, align 4
  store i32 %field.extent.263, ptr %local.extent.10, align 4
  store i32 %field.payload.261, ptr %local.payload.11, align 4
  store i32 %local.resolved.owner.end.143, ptr %local.owner.end.12, align 4
  store i32 12, ptr %local.type.13, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %field.offset.259, i32 20, i32 %field.payload.261, i32 %local.resolved.owner.end.143, i32 %field.extent.263)
  %context.field.357 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.358 = load i32, ptr %context.field.357, align 4
  %runtime.ok.359 = icmp eq i32 %context.value.358, 0
  br i1 %runtime.ok.359, label %runtime.continue.360, label %frame.failure.0
runtime.continue.360:
  %local.is.active.361 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.361, label %local.descriptor.active.362, label %local.descriptor.inactive.363
local.descriptor.active.362:
  %local.check.offset.365 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.366 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.367 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.368 = load i32, ptr %local.owner.end.6, align 4
  %context.field.369 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.370 = load i32, ptr %context.field.369, align 4
  %stack.sub.373 = sub i32 %local.check.owner.end.368, %local.check.offset.365
  %descriptor.owner.inside.371 = icmp ule i32 %local.check.owner.end.368, %context.value.370
  %descriptor.offset.inside.372 = icmp ule i32 %local.check.offset.365, %local.check.owner.end.368
  %descriptor.extent.inside.374 = icmp ule i32 %local.check.extent.366, %stack.sub.373
  %descriptor.payload.inside.375 = icmp ule i32 %local.check.payload.367, %local.check.extent.366
  %descriptor.owner.offset.valid.376 = and i1 %descriptor.owner.inside.371, %descriptor.offset.inside.372
  %descriptor.range.inside.378 = and i1 %descriptor.owner.offset.valid.376, %descriptor.extent.inside.374
  %descriptor.range.valid.377 = and i1 %descriptor.range.inside.378, %descriptor.payload.inside.375
  br i1 %descriptor.range.valid.377, label %descriptor.valid.379, label %descriptor.invalid.380
descriptor.invalid.380:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.379:
  %descriptor.initialized.status.381 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.365, i32 %local.check.extent.366)
  %helper.ok.382 = icmp eq i32 %descriptor.initialized.status.381, 0
  br i1 %helper.ok.382, label %helper.continue.383, label %frame.failure.0
helper.continue.383:
  br label %local.descriptor.checked.364
local.descriptor.inactive.363:
  br label %local.descriptor.checked.364
local.descriptor.checked.364:
  %local.is.active.384 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.384, label %local.descriptor.active.385, label %local.descriptor.inactive.386
local.descriptor.active.385:
  %local.check.offset.388 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.389 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.390 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.391 = load i32, ptr %local.owner.end.12, align 4
  %context.field.392 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.393 = load i32, ptr %context.field.392, align 4
  %stack.sub.396 = sub i32 %local.check.owner.end.391, %local.check.offset.388
  %descriptor.owner.inside.394 = icmp ule i32 %local.check.owner.end.391, %context.value.393
  %descriptor.offset.inside.395 = icmp ule i32 %local.check.offset.388, %local.check.owner.end.391
  %descriptor.extent.inside.397 = icmp ule i32 %local.check.extent.389, %stack.sub.396
  %descriptor.payload.inside.398 = icmp ule i32 %local.check.payload.390, %local.check.extent.389
  %descriptor.owner.offset.valid.399 = and i1 %descriptor.owner.inside.394, %descriptor.offset.inside.395
  %descriptor.range.inside.401 = and i1 %descriptor.owner.offset.valid.399, %descriptor.extent.inside.397
  %descriptor.range.valid.400 = and i1 %descriptor.range.inside.401, %descriptor.payload.inside.398
  br i1 %descriptor.range.valid.400, label %descriptor.valid.402, label %descriptor.invalid.403
descriptor.invalid.403:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.402:
  %descriptor.initialized.status.404 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.388, i32 %local.check.extent.389)
  %helper.ok.405 = icmp eq i32 %descriptor.initialized.status.404, 0
  br i1 %helper.ok.405, label %helper.continue.406, label %frame.failure.0
helper.continue.406:
  br label %local.descriptor.checked.387
local.descriptor.inactive.386:
  br label %local.descriptor.checked.387
local.descriptor.checked.387:
  %local.is.active.407 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.407, label %local.descriptor.active.408, label %local.descriptor.inactive.409
local.descriptor.active.408:
  %local.check.offset.411 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.412 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.413 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.414 = load i32, ptr %local.owner.end.18, align 4
  %context.field.415 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.416 = load i32, ptr %context.field.415, align 4
  %stack.sub.419 = sub i32 %local.check.owner.end.414, %local.check.offset.411
  %descriptor.owner.inside.417 = icmp ule i32 %local.check.owner.end.414, %context.value.416
  %descriptor.offset.inside.418 = icmp ule i32 %local.check.offset.411, %local.check.owner.end.414
  %descriptor.extent.inside.420 = icmp ule i32 %local.check.extent.412, %stack.sub.419
  %descriptor.payload.inside.421 = icmp ule i32 %local.check.payload.413, %local.check.extent.412
  %descriptor.owner.offset.valid.422 = and i1 %descriptor.owner.inside.417, %descriptor.offset.inside.418
  %descriptor.range.inside.424 = and i1 %descriptor.owner.offset.valid.422, %descriptor.extent.inside.420
  %descriptor.range.valid.423 = and i1 %descriptor.range.inside.424, %descriptor.payload.inside.421
  br i1 %descriptor.range.valid.423, label %descriptor.valid.425, label %descriptor.invalid.426
descriptor.invalid.426:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.425:
  %descriptor.initialized.status.427 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.411, i32 %local.check.extent.412)
  %helper.ok.428 = icmp eq i32 %descriptor.initialized.status.427, 0
  br i1 %helper.ok.428, label %helper.continue.429, label %frame.failure.0
helper.continue.429:
  br label %local.descriptor.checked.410
local.descriptor.inactive.409:
  br label %local.descriptor.checked.410
local.descriptor.checked.410:
  %step.status.430 = call i32 @al_owning_charge_step(ptr %ctx, i32 8)
  %helper.ok.431 = icmp eq i32 %step.status.430, 0
  br i1 %helper.ok.431, label %helper.continue.432, label %frame.failure.0
helper.continue.432:
  %local.resolved.offset.433 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.434 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.435 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.436 = load i32, ptr %local.owner.end.6, align 4
  %context.field.437 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.438 = load i32, ptr %context.field.437, align 4
  %stack.sub.441 = sub i32 %local.resolved.owner.end.436, %local.resolved.offset.433
  %descriptor.owner.inside.439 = icmp ule i32 %local.resolved.owner.end.436, %context.value.438
  %descriptor.offset.inside.440 = icmp ule i32 %local.resolved.offset.433, %local.resolved.owner.end.436
  %descriptor.extent.inside.442 = icmp ule i32 %local.resolved.extent.434, %stack.sub.441
  %descriptor.payload.inside.443 = icmp ule i32 %local.resolved.payload.435, %local.resolved.extent.434
  %descriptor.owner.offset.valid.444 = and i1 %descriptor.owner.inside.439, %descriptor.offset.inside.440
  %descriptor.range.inside.446 = and i1 %descriptor.owner.offset.valid.444, %descriptor.extent.inside.442
  %descriptor.range.valid.445 = and i1 %descriptor.range.inside.446, %descriptor.payload.inside.443
  %descriptor.type.valid.447 = icmp eq i32 10, 10
  %descriptor.valid.448 = and i1 %descriptor.range.valid.445, %descriptor.type.valid.447
  br i1 %descriptor.valid.448, label %descriptor.valid.449, label %descriptor.invalid.450
descriptor.invalid.450:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.449:
  %descriptor.initialized.status.451 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.433, i32 %local.resolved.extent.434)
  %helper.ok.452 = icmp eq i32 %descriptor.initialized.status.451, 0
  br i1 %helper.ok.452, label %helper.continue.453, label %frame.failure.0
helper.continue.453:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 10, i32 %local.resolved.offset.433, i32 20, i32 %local.resolved.payload.435, i32 %local.resolved.owner.end.436, i32 %local.resolved.extent.434)
  %context.field.454 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.455 = load i32, ptr %context.field.454, align 4
  %runtime.ok.456 = icmp eq i32 %context.value.455, 0
  br i1 %runtime.ok.456, label %runtime.continue.457, label %frame.failure.0
runtime.continue.457:
  %context.field.458 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.459 = load i32, ptr %context.field.458, align 4
  %stack.sub.462 = sub i32 %local.resolved.owner.end.436, %local.resolved.offset.433
  %descriptor.owner.inside.460 = icmp ule i32 %local.resolved.owner.end.436, %context.value.459
  %descriptor.offset.inside.461 = icmp ule i32 %local.resolved.offset.433, %local.resolved.owner.end.436
  %descriptor.extent.inside.463 = icmp ule i32 %local.resolved.extent.434, %stack.sub.462
  %descriptor.payload.inside.464 = icmp ule i32 %local.resolved.payload.435, %local.resolved.extent.434
  %descriptor.owner.offset.valid.465 = and i1 %descriptor.owner.inside.460, %descriptor.offset.inside.461
  %descriptor.range.inside.467 = and i1 %descriptor.owner.offset.valid.465, %descriptor.extent.inside.463
  %descriptor.range.valid.466 = and i1 %descriptor.range.inside.467, %descriptor.payload.inside.464
  %descriptor.type.valid.468 = icmp eq i32 10, 10
  %descriptor.valid.469 = and i1 %descriptor.range.valid.466, %descriptor.type.valid.468
  br i1 %descriptor.valid.469, label %descriptor.valid.470, label %descriptor.invalid.471
descriptor.invalid.471:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.470:
  %descriptor.initialized.status.472 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.433, i32 %local.resolved.extent.434)
  %helper.ok.473 = icmp eq i32 %descriptor.initialized.status.472, 0
  br i1 %helper.ok.473, label %helper.continue.474, label %frame.failure.0
helper.continue.474:
  %local.is.active.475 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.475, label %local.descriptor.active.476, label %local.descriptor.inactive.477
local.descriptor.active.476:
  %local.check.offset.479 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.480 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.481 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.482 = load i32, ptr %local.owner.end.6, align 4
  %context.field.483 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.484 = load i32, ptr %context.field.483, align 4
  %stack.sub.487 = sub i32 %local.check.owner.end.482, %local.check.offset.479
  %descriptor.owner.inside.485 = icmp ule i32 %local.check.owner.end.482, %context.value.484
  %descriptor.offset.inside.486 = icmp ule i32 %local.check.offset.479, %local.check.owner.end.482
  %descriptor.extent.inside.488 = icmp ule i32 %local.check.extent.480, %stack.sub.487
  %descriptor.payload.inside.489 = icmp ule i32 %local.check.payload.481, %local.check.extent.480
  %descriptor.owner.offset.valid.490 = and i1 %descriptor.owner.inside.485, %descriptor.offset.inside.486
  %descriptor.range.inside.492 = and i1 %descriptor.owner.offset.valid.490, %descriptor.extent.inside.488
  %descriptor.range.valid.491 = and i1 %descriptor.range.inside.492, %descriptor.payload.inside.489
  br i1 %descriptor.range.valid.491, label %descriptor.valid.493, label %descriptor.invalid.494
descriptor.invalid.494:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.493:
  %descriptor.initialized.status.495 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.479, i32 %local.check.extent.480)
  %helper.ok.496 = icmp eq i32 %descriptor.initialized.status.495, 0
  br i1 %helper.ok.496, label %helper.continue.497, label %frame.failure.0
helper.continue.497:
  br label %local.descriptor.checked.478
local.descriptor.inactive.477:
  br label %local.descriptor.checked.478
local.descriptor.checked.478:
  %local.is.active.498 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.498, label %local.descriptor.active.499, label %local.descriptor.inactive.500
local.descriptor.active.499:
  %local.check.offset.502 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.503 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.504 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.505 = load i32, ptr %local.owner.end.12, align 4
  %context.field.506 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.507 = load i32, ptr %context.field.506, align 4
  %stack.sub.510 = sub i32 %local.check.owner.end.505, %local.check.offset.502
  %descriptor.owner.inside.508 = icmp ule i32 %local.check.owner.end.505, %context.value.507
  %descriptor.offset.inside.509 = icmp ule i32 %local.check.offset.502, %local.check.owner.end.505
  %descriptor.extent.inside.511 = icmp ule i32 %local.check.extent.503, %stack.sub.510
  %descriptor.payload.inside.512 = icmp ule i32 %local.check.payload.504, %local.check.extent.503
  %descriptor.owner.offset.valid.513 = and i1 %descriptor.owner.inside.508, %descriptor.offset.inside.509
  %descriptor.range.inside.515 = and i1 %descriptor.owner.offset.valid.513, %descriptor.extent.inside.511
  %descriptor.range.valid.514 = and i1 %descriptor.range.inside.515, %descriptor.payload.inside.512
  br i1 %descriptor.range.valid.514, label %descriptor.valid.516, label %descriptor.invalid.517
descriptor.invalid.517:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.516:
  %descriptor.initialized.status.518 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.502, i32 %local.check.extent.503)
  %helper.ok.519 = icmp eq i32 %descriptor.initialized.status.518, 0
  br i1 %helper.ok.519, label %helper.continue.520, label %frame.failure.0
helper.continue.520:
  br label %local.descriptor.checked.501
local.descriptor.inactive.500:
  br label %local.descriptor.checked.501
local.descriptor.checked.501:
  %local.is.active.521 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.521, label %local.descriptor.active.522, label %local.descriptor.inactive.523
local.descriptor.active.522:
  %local.check.offset.525 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.526 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.527 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.528 = load i32, ptr %local.owner.end.18, align 4
  %context.field.529 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.530 = load i32, ptr %context.field.529, align 4
  %stack.sub.533 = sub i32 %local.check.owner.end.528, %local.check.offset.525
  %descriptor.owner.inside.531 = icmp ule i32 %local.check.owner.end.528, %context.value.530
  %descriptor.offset.inside.532 = icmp ule i32 %local.check.offset.525, %local.check.owner.end.528
  %descriptor.extent.inside.534 = icmp ule i32 %local.check.extent.526, %stack.sub.533
  %descriptor.payload.inside.535 = icmp ule i32 %local.check.payload.527, %local.check.extent.526
  %descriptor.owner.offset.valid.536 = and i1 %descriptor.owner.inside.531, %descriptor.offset.inside.532
  %descriptor.range.inside.538 = and i1 %descriptor.owner.offset.valid.536, %descriptor.extent.inside.534
  %descriptor.range.valid.537 = and i1 %descriptor.range.inside.538, %descriptor.payload.inside.535
  br i1 %descriptor.range.valid.537, label %descriptor.valid.539, label %descriptor.invalid.540
descriptor.invalid.540:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.539:
  %descriptor.initialized.status.541 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.525, i32 %local.check.extent.526)
  %helper.ok.542 = icmp eq i32 %descriptor.initialized.status.541, 0
  br i1 %helper.ok.542, label %helper.continue.543, label %frame.failure.0
helper.continue.543:
  br label %local.descriptor.checked.524
local.descriptor.inactive.523:
  br label %local.descriptor.checked.524
local.descriptor.checked.524:
  %step.status.544 = call i32 @al_owning_charge_step(ptr %ctx, i32 9)
  %helper.ok.545 = icmp eq i32 %step.status.544, 0
  br i1 %helper.ok.545, label %helper.continue.546, label %frame.failure.0
helper.continue.546:
  %field.location.547 = alloca %AlOwningFieldLocation, align 4
  %field.location.status.548 = call i32 @al_owning_locate_field(ptr %ctx, ptr @al_owning_layout, i32 2, i32 %local.resolved.offset.433, i32 %local.resolved.extent.434, i32 2, i32 10, ptr %field.location.547)
  %helper.ok.549 = icmp eq i32 %field.location.status.548, 0
  br i1 %helper.ok.549, label %helper.continue.550, label %frame.failure.0
helper.continue.550:
  %field.offset.pointer.551 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.547, i32 0, i32 0
  %field.offset.552 = load i32, ptr %field.offset.pointer.551, align 4
  %field.payload.pointer.553 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.547, i32 0, i32 1
  %field.payload.554 = load i32, ptr %field.payload.pointer.553, align 4
  %field.extent.pointer.555 = getelementptr inbounds %AlOwningFieldLocation, ptr %field.location.547, i32 0, i32 2
  %field.extent.556 = load i32, ptr %field.extent.pointer.555, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 7, i32 1, i32 %local.resolved.offset.433, i32 %field.extent.556, i32 %field.payload.554, i32 %field.offset.552, i32 %field.extent.556)
  %context.field.557 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.558 = load i32, ptr %context.field.557, align 4
  %runtime.ok.559 = icmp eq i32 %context.value.558, 0
  br i1 %runtime.ok.559, label %runtime.continue.560, label %frame.failure.0
runtime.continue.560:
  %context.field.561 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.562 = load i32, ptr %context.field.561, align 4
  %stack.sub.565 = sub i32 %local.resolved.owner.end.436, %field.offset.552
  %descriptor.owner.inside.563 = icmp ule i32 %local.resolved.owner.end.436, %context.value.562
  %descriptor.offset.inside.564 = icmp ule i32 %field.offset.552, %local.resolved.owner.end.436
  %descriptor.extent.inside.566 = icmp ule i32 %field.extent.556, %stack.sub.565
  %descriptor.payload.inside.567 = icmp ule i32 %field.payload.554, %field.extent.556
  %descriptor.owner.offset.valid.568 = and i1 %descriptor.owner.inside.563, %descriptor.offset.inside.564
  %descriptor.range.inside.570 = and i1 %descriptor.owner.offset.valid.568, %descriptor.extent.inside.566
  %descriptor.range.valid.569 = and i1 %descriptor.range.inside.570, %descriptor.payload.inside.567
  %descriptor.type.valid.571 = icmp eq i32 1, 1
  %descriptor.valid.572 = and i1 %descriptor.range.valid.569, %descriptor.type.valid.571
  br i1 %descriptor.valid.572, label %descriptor.valid.573, label %descriptor.invalid.574
descriptor.invalid.574:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.573:
  %descriptor.initialized.status.575 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %field.offset.552, i32 %field.extent.556)
  %helper.ok.576 = icmp eq i32 %descriptor.initialized.status.575, 0
  br i1 %helper.ok.576, label %helper.continue.577, label %frame.failure.0
helper.continue.577:
  %local.is.active.578 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.578, label %local.descriptor.active.579, label %local.descriptor.inactive.580
local.descriptor.active.579:
  %local.check.offset.582 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.583 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.584 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.585 = load i32, ptr %local.owner.end.6, align 4
  %context.field.586 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.587 = load i32, ptr %context.field.586, align 4
  %stack.sub.590 = sub i32 %local.check.owner.end.585, %local.check.offset.582
  %descriptor.owner.inside.588 = icmp ule i32 %local.check.owner.end.585, %context.value.587
  %descriptor.offset.inside.589 = icmp ule i32 %local.check.offset.582, %local.check.owner.end.585
  %descriptor.extent.inside.591 = icmp ule i32 %local.check.extent.583, %stack.sub.590
  %descriptor.payload.inside.592 = icmp ule i32 %local.check.payload.584, %local.check.extent.583
  %descriptor.owner.offset.valid.593 = and i1 %descriptor.owner.inside.588, %descriptor.offset.inside.589
  %descriptor.range.inside.595 = and i1 %descriptor.owner.offset.valid.593, %descriptor.extent.inside.591
  %descriptor.range.valid.594 = and i1 %descriptor.range.inside.595, %descriptor.payload.inside.592
  br i1 %descriptor.range.valid.594, label %descriptor.valid.596, label %descriptor.invalid.597
descriptor.invalid.597:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.596:
  %descriptor.initialized.status.598 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.582, i32 %local.check.extent.583)
  %helper.ok.599 = icmp eq i32 %descriptor.initialized.status.598, 0
  br i1 %helper.ok.599, label %helper.continue.600, label %frame.failure.0
helper.continue.600:
  br label %local.descriptor.checked.581
local.descriptor.inactive.580:
  br label %local.descriptor.checked.581
local.descriptor.checked.581:
  %local.is.active.601 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.601, label %local.descriptor.active.602, label %local.descriptor.inactive.603
local.descriptor.active.602:
  %local.check.offset.605 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.606 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.607 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.608 = load i32, ptr %local.owner.end.12, align 4
  %context.field.609 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.610 = load i32, ptr %context.field.609, align 4
  %stack.sub.613 = sub i32 %local.check.owner.end.608, %local.check.offset.605
  %descriptor.owner.inside.611 = icmp ule i32 %local.check.owner.end.608, %context.value.610
  %descriptor.offset.inside.612 = icmp ule i32 %local.check.offset.605, %local.check.owner.end.608
  %descriptor.extent.inside.614 = icmp ule i32 %local.check.extent.606, %stack.sub.613
  %descriptor.payload.inside.615 = icmp ule i32 %local.check.payload.607, %local.check.extent.606
  %descriptor.owner.offset.valid.616 = and i1 %descriptor.owner.inside.611, %descriptor.offset.inside.612
  %descriptor.range.inside.618 = and i1 %descriptor.owner.offset.valid.616, %descriptor.extent.inside.614
  %descriptor.range.valid.617 = and i1 %descriptor.range.inside.618, %descriptor.payload.inside.615
  br i1 %descriptor.range.valid.617, label %descriptor.valid.619, label %descriptor.invalid.620
descriptor.invalid.620:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.619:
  %descriptor.initialized.status.621 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.605, i32 %local.check.extent.606)
  %helper.ok.622 = icmp eq i32 %descriptor.initialized.status.621, 0
  br i1 %helper.ok.622, label %helper.continue.623, label %frame.failure.0
helper.continue.623:
  br label %local.descriptor.checked.604
local.descriptor.inactive.603:
  br label %local.descriptor.checked.604
local.descriptor.checked.604:
  %local.is.active.624 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.624, label %local.descriptor.active.625, label %local.descriptor.inactive.626
local.descriptor.active.625:
  %local.check.offset.628 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.629 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.630 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.631 = load i32, ptr %local.owner.end.18, align 4
  %context.field.632 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.633 = load i32, ptr %context.field.632, align 4
  %stack.sub.636 = sub i32 %local.check.owner.end.631, %local.check.offset.628
  %descriptor.owner.inside.634 = icmp ule i32 %local.check.owner.end.631, %context.value.633
  %descriptor.offset.inside.635 = icmp ule i32 %local.check.offset.628, %local.check.owner.end.631
  %descriptor.extent.inside.637 = icmp ule i32 %local.check.extent.629, %stack.sub.636
  %descriptor.payload.inside.638 = icmp ule i32 %local.check.payload.630, %local.check.extent.629
  %descriptor.owner.offset.valid.639 = and i1 %descriptor.owner.inside.634, %descriptor.offset.inside.635
  %descriptor.range.inside.641 = and i1 %descriptor.owner.offset.valid.639, %descriptor.extent.inside.637
  %descriptor.range.valid.640 = and i1 %descriptor.range.inside.641, %descriptor.payload.inside.638
  br i1 %descriptor.range.valid.640, label %descriptor.valid.642, label %descriptor.invalid.643
descriptor.invalid.643:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.642:
  %descriptor.initialized.status.644 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.628, i32 %local.check.extent.629)
  %helper.ok.645 = icmp eq i32 %descriptor.initialized.status.644, 0
  br i1 %helper.ok.645, label %helper.continue.646, label %frame.failure.0
helper.continue.646:
  br label %local.descriptor.checked.627
local.descriptor.inactive.626:
  br label %local.descriptor.checked.627
local.descriptor.checked.627:
  %step.status.647 = call i32 @al_owning_charge_step(ptr %ctx, i32 11)
  %helper.ok.648 = icmp eq i32 %step.status.647, 0
  br i1 %helper.ok.648, label %helper.continue.649, label %frame.failure.0
helper.continue.649:
  store i1 true, ptr %local.active.14, align 1
  store i32 %field.offset.552, ptr %local.offset.15, align 4
  store i32 %field.extent.556, ptr %local.extent.16, align 4
  store i32 %field.payload.554, ptr %local.payload.17, align 4
  store i32 %local.resolved.owner.end.436, ptr %local.owner.end.18, align 4
  store i32 1, ptr %local.type.19, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %field.offset.552, i32 20, i32 %field.payload.554, i32 %local.resolved.owner.end.436, i32 %field.extent.556)
  %context.field.650 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.651 = load i32, ptr %context.field.650, align 4
  %runtime.ok.652 = icmp eq i32 %context.value.651, 0
  br i1 %runtime.ok.652, label %runtime.continue.653, label %frame.failure.0
runtime.continue.653:
  %local.is.active.654 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.654, label %local.descriptor.active.655, label %local.descriptor.inactive.656
local.descriptor.active.655:
  %local.check.offset.658 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.659 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.660 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.661 = load i32, ptr %local.owner.end.6, align 4
  %context.field.662 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.663 = load i32, ptr %context.field.662, align 4
  %stack.sub.666 = sub i32 %local.check.owner.end.661, %local.check.offset.658
  %descriptor.owner.inside.664 = icmp ule i32 %local.check.owner.end.661, %context.value.663
  %descriptor.offset.inside.665 = icmp ule i32 %local.check.offset.658, %local.check.owner.end.661
  %descriptor.extent.inside.667 = icmp ule i32 %local.check.extent.659, %stack.sub.666
  %descriptor.payload.inside.668 = icmp ule i32 %local.check.payload.660, %local.check.extent.659
  %descriptor.owner.offset.valid.669 = and i1 %descriptor.owner.inside.664, %descriptor.offset.inside.665
  %descriptor.range.inside.671 = and i1 %descriptor.owner.offset.valid.669, %descriptor.extent.inside.667
  %descriptor.range.valid.670 = and i1 %descriptor.range.inside.671, %descriptor.payload.inside.668
  br i1 %descriptor.range.valid.670, label %descriptor.valid.672, label %descriptor.invalid.673
descriptor.invalid.673:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.672:
  %descriptor.initialized.status.674 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.658, i32 %local.check.extent.659)
  %helper.ok.675 = icmp eq i32 %descriptor.initialized.status.674, 0
  br i1 %helper.ok.675, label %helper.continue.676, label %frame.failure.0
helper.continue.676:
  br label %local.descriptor.checked.657
local.descriptor.inactive.656:
  br label %local.descriptor.checked.657
local.descriptor.checked.657:
  %local.is.active.677 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.677, label %local.descriptor.active.678, label %local.descriptor.inactive.679
local.descriptor.active.678:
  %local.check.offset.681 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.682 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.683 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.684 = load i32, ptr %local.owner.end.12, align 4
  %context.field.685 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.686 = load i32, ptr %context.field.685, align 4
  %stack.sub.689 = sub i32 %local.check.owner.end.684, %local.check.offset.681
  %descriptor.owner.inside.687 = icmp ule i32 %local.check.owner.end.684, %context.value.686
  %descriptor.offset.inside.688 = icmp ule i32 %local.check.offset.681, %local.check.owner.end.684
  %descriptor.extent.inside.690 = icmp ule i32 %local.check.extent.682, %stack.sub.689
  %descriptor.payload.inside.691 = icmp ule i32 %local.check.payload.683, %local.check.extent.682
  %descriptor.owner.offset.valid.692 = and i1 %descriptor.owner.inside.687, %descriptor.offset.inside.688
  %descriptor.range.inside.694 = and i1 %descriptor.owner.offset.valid.692, %descriptor.extent.inside.690
  %descriptor.range.valid.693 = and i1 %descriptor.range.inside.694, %descriptor.payload.inside.691
  br i1 %descriptor.range.valid.693, label %descriptor.valid.695, label %descriptor.invalid.696
descriptor.invalid.696:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.695:
  %descriptor.initialized.status.697 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.681, i32 %local.check.extent.682)
  %helper.ok.698 = icmp eq i32 %descriptor.initialized.status.697, 0
  br i1 %helper.ok.698, label %helper.continue.699, label %frame.failure.0
helper.continue.699:
  br label %local.descriptor.checked.680
local.descriptor.inactive.679:
  br label %local.descriptor.checked.680
local.descriptor.checked.680:
  %local.is.active.700 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.700, label %local.descriptor.active.701, label %local.descriptor.inactive.702
local.descriptor.active.701:
  %local.check.offset.704 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.705 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.706 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.707 = load i32, ptr %local.owner.end.18, align 4
  %context.field.708 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.709 = load i32, ptr %context.field.708, align 4
  %stack.sub.712 = sub i32 %local.check.owner.end.707, %local.check.offset.704
  %descriptor.owner.inside.710 = icmp ule i32 %local.check.owner.end.707, %context.value.709
  %descriptor.offset.inside.711 = icmp ule i32 %local.check.offset.704, %local.check.owner.end.707
  %descriptor.extent.inside.713 = icmp ule i32 %local.check.extent.705, %stack.sub.712
  %descriptor.payload.inside.714 = icmp ule i32 %local.check.payload.706, %local.check.extent.705
  %descriptor.owner.offset.valid.715 = and i1 %descriptor.owner.inside.710, %descriptor.offset.inside.711
  %descriptor.range.inside.717 = and i1 %descriptor.owner.offset.valid.715, %descriptor.extent.inside.713
  %descriptor.range.valid.716 = and i1 %descriptor.range.inside.717, %descriptor.payload.inside.714
  br i1 %descriptor.range.valid.716, label %descriptor.valid.718, label %descriptor.invalid.719
descriptor.invalid.719:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.718:
  %descriptor.initialized.status.720 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.704, i32 %local.check.extent.705)
  %helper.ok.721 = icmp eq i32 %descriptor.initialized.status.720, 0
  br i1 %helper.ok.721, label %helper.continue.722, label %frame.failure.0
helper.continue.722:
  br label %local.descriptor.checked.703
local.descriptor.inactive.702:
  br label %local.descriptor.checked.703
local.descriptor.checked.703:
  %step.status.723 = call i32 @al_owning_charge_step(ptr %ctx, i32 12)
  %helper.ok.724 = icmp eq i32 %step.status.723, 0
  br i1 %helper.ok.724, label %helper.continue.725, label %frame.failure.0
helper.continue.725:
  %local.resolved.offset.726 = load i32, ptr %local.offset.9, align 4
  %local.resolved.extent.727 = load i32, ptr %local.extent.10, align 4
  %local.resolved.payload.728 = load i32, ptr %local.payload.11, align 4
  %local.resolved.owner.end.729 = load i32, ptr %local.owner.end.12, align 4
  %context.field.730 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.731 = load i32, ptr %context.field.730, align 4
  %stack.sub.734 = sub i32 %local.resolved.owner.end.729, %local.resolved.offset.726
  %descriptor.owner.inside.732 = icmp ule i32 %local.resolved.owner.end.729, %context.value.731
  %descriptor.offset.inside.733 = icmp ule i32 %local.resolved.offset.726, %local.resolved.owner.end.729
  %descriptor.extent.inside.735 = icmp ule i32 %local.resolved.extent.727, %stack.sub.734
  %descriptor.payload.inside.736 = icmp ule i32 %local.resolved.payload.728, %local.resolved.extent.727
  %descriptor.owner.offset.valid.737 = and i1 %descriptor.owner.inside.732, %descriptor.offset.inside.733
  %descriptor.range.inside.739 = and i1 %descriptor.owner.offset.valid.737, %descriptor.extent.inside.735
  %descriptor.range.valid.738 = and i1 %descriptor.range.inside.739, %descriptor.payload.inside.736
  %descriptor.type.valid.740 = icmp eq i32 12, 12
  %descriptor.valid.741 = and i1 %descriptor.range.valid.738, %descriptor.type.valid.740
  br i1 %descriptor.valid.741, label %descriptor.valid.742, label %descriptor.invalid.743
descriptor.invalid.743:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.742:
  %descriptor.initialized.status.744 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.726, i32 %local.resolved.extent.727)
  %helper.ok.745 = icmp eq i32 %descriptor.initialized.status.744, 0
  br i1 %helper.ok.745, label %helper.continue.746, label %frame.failure.0
helper.continue.746:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %local.resolved.offset.726, i32 20, i32 %local.resolved.payload.728, i32 %local.resolved.owner.end.729, i32 %local.resolved.extent.727)
  %context.field.747 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.748 = load i32, ptr %context.field.747, align 4
  %runtime.ok.749 = icmp eq i32 %context.value.748, 0
  br i1 %runtime.ok.749, label %runtime.continue.750, label %frame.failure.0
runtime.continue.750:
  %context.field.751 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.752 = load i32, ptr %context.field.751, align 4
  %stack.sub.755 = sub i32 %local.resolved.owner.end.729, %local.resolved.offset.726
  %descriptor.owner.inside.753 = icmp ule i32 %local.resolved.owner.end.729, %context.value.752
  %descriptor.offset.inside.754 = icmp ule i32 %local.resolved.offset.726, %local.resolved.owner.end.729
  %descriptor.extent.inside.756 = icmp ule i32 %local.resolved.extent.727, %stack.sub.755
  %descriptor.payload.inside.757 = icmp ule i32 %local.resolved.payload.728, %local.resolved.extent.727
  %descriptor.owner.offset.valid.758 = and i1 %descriptor.owner.inside.753, %descriptor.offset.inside.754
  %descriptor.range.inside.760 = and i1 %descriptor.owner.offset.valid.758, %descriptor.extent.inside.756
  %descriptor.range.valid.759 = and i1 %descriptor.range.inside.760, %descriptor.payload.inside.757
  %descriptor.type.valid.761 = icmp eq i32 12, 12
  %descriptor.valid.762 = and i1 %descriptor.range.valid.759, %descriptor.type.valid.761
  br i1 %descriptor.valid.762, label %descriptor.valid.763, label %descriptor.invalid.764
descriptor.invalid.764:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.763:
  %descriptor.initialized.status.765 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.726, i32 %local.resolved.extent.727)
  %helper.ok.766 = icmp eq i32 %descriptor.initialized.status.765, 0
  br i1 %helper.ok.766, label %helper.continue.767, label %frame.failure.0
helper.continue.767:
  %local.is.active.768 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.768, label %local.descriptor.active.769, label %local.descriptor.inactive.770
local.descriptor.active.769:
  %local.check.offset.772 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.773 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.774 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.775 = load i32, ptr %local.owner.end.6, align 4
  %context.field.776 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.777 = load i32, ptr %context.field.776, align 4
  %stack.sub.780 = sub i32 %local.check.owner.end.775, %local.check.offset.772
  %descriptor.owner.inside.778 = icmp ule i32 %local.check.owner.end.775, %context.value.777
  %descriptor.offset.inside.779 = icmp ule i32 %local.check.offset.772, %local.check.owner.end.775
  %descriptor.extent.inside.781 = icmp ule i32 %local.check.extent.773, %stack.sub.780
  %descriptor.payload.inside.782 = icmp ule i32 %local.check.payload.774, %local.check.extent.773
  %descriptor.owner.offset.valid.783 = and i1 %descriptor.owner.inside.778, %descriptor.offset.inside.779
  %descriptor.range.inside.785 = and i1 %descriptor.owner.offset.valid.783, %descriptor.extent.inside.781
  %descriptor.range.valid.784 = and i1 %descriptor.range.inside.785, %descriptor.payload.inside.782
  br i1 %descriptor.range.valid.784, label %descriptor.valid.786, label %descriptor.invalid.787
descriptor.invalid.787:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.786:
  %descriptor.initialized.status.788 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.772, i32 %local.check.extent.773)
  %helper.ok.789 = icmp eq i32 %descriptor.initialized.status.788, 0
  br i1 %helper.ok.789, label %helper.continue.790, label %frame.failure.0
helper.continue.790:
  br label %local.descriptor.checked.771
local.descriptor.inactive.770:
  br label %local.descriptor.checked.771
local.descriptor.checked.771:
  %local.is.active.791 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.791, label %local.descriptor.active.792, label %local.descriptor.inactive.793
local.descriptor.active.792:
  %local.check.offset.795 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.796 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.797 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.798 = load i32, ptr %local.owner.end.12, align 4
  %context.field.799 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.800 = load i32, ptr %context.field.799, align 4
  %stack.sub.803 = sub i32 %local.check.owner.end.798, %local.check.offset.795
  %descriptor.owner.inside.801 = icmp ule i32 %local.check.owner.end.798, %context.value.800
  %descriptor.offset.inside.802 = icmp ule i32 %local.check.offset.795, %local.check.owner.end.798
  %descriptor.extent.inside.804 = icmp ule i32 %local.check.extent.796, %stack.sub.803
  %descriptor.payload.inside.805 = icmp ule i32 %local.check.payload.797, %local.check.extent.796
  %descriptor.owner.offset.valid.806 = and i1 %descriptor.owner.inside.801, %descriptor.offset.inside.802
  %descriptor.range.inside.808 = and i1 %descriptor.owner.offset.valid.806, %descriptor.extent.inside.804
  %descriptor.range.valid.807 = and i1 %descriptor.range.inside.808, %descriptor.payload.inside.805
  br i1 %descriptor.range.valid.807, label %descriptor.valid.809, label %descriptor.invalid.810
descriptor.invalid.810:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.809:
  %descriptor.initialized.status.811 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.795, i32 %local.check.extent.796)
  %helper.ok.812 = icmp eq i32 %descriptor.initialized.status.811, 0
  br i1 %helper.ok.812, label %helper.continue.813, label %frame.failure.0
helper.continue.813:
  br label %local.descriptor.checked.794
local.descriptor.inactive.793:
  br label %local.descriptor.checked.794
local.descriptor.checked.794:
  %local.is.active.814 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.814, label %local.descriptor.active.815, label %local.descriptor.inactive.816
local.descriptor.active.815:
  %local.check.offset.818 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.819 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.820 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.821 = load i32, ptr %local.owner.end.18, align 4
  %context.field.822 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.823 = load i32, ptr %context.field.822, align 4
  %stack.sub.826 = sub i32 %local.check.owner.end.821, %local.check.offset.818
  %descriptor.owner.inside.824 = icmp ule i32 %local.check.owner.end.821, %context.value.823
  %descriptor.offset.inside.825 = icmp ule i32 %local.check.offset.818, %local.check.owner.end.821
  %descriptor.extent.inside.827 = icmp ule i32 %local.check.extent.819, %stack.sub.826
  %descriptor.payload.inside.828 = icmp ule i32 %local.check.payload.820, %local.check.extent.819
  %descriptor.owner.offset.valid.829 = and i1 %descriptor.owner.inside.824, %descriptor.offset.inside.825
  %descriptor.range.inside.831 = and i1 %descriptor.owner.offset.valid.829, %descriptor.extent.inside.827
  %descriptor.range.valid.830 = and i1 %descriptor.range.inside.831, %descriptor.payload.inside.828
  br i1 %descriptor.range.valid.830, label %descriptor.valid.832, label %descriptor.invalid.833
descriptor.invalid.833:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.832:
  %descriptor.initialized.status.834 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.818, i32 %local.check.extent.819)
  %helper.ok.835 = icmp eq i32 %descriptor.initialized.status.834, 0
  br i1 %helper.ok.835, label %helper.continue.836, label %frame.failure.0
helper.continue.836:
  br label %local.descriptor.checked.817
local.descriptor.inactive.816:
  br label %local.descriptor.checked.817
local.descriptor.checked.817:
  %step.status.837 = call i32 @al_owning_charge_step(ptr %ctx, i32 13)
  %helper.ok.838 = icmp eq i32 %step.status.837, 0
  br i1 %helper.ok.838, label %helper.continue.839, label %frame.failure.0
helper.continue.839:
  %local.resolved.offset.840 = load i32, ptr %local.offset.15, align 4
  %local.resolved.extent.841 = load i32, ptr %local.extent.16, align 4
  %local.resolved.payload.842 = load i32, ptr %local.payload.17, align 4
  %local.resolved.owner.end.843 = load i32, ptr %local.owner.end.18, align 4
  %context.field.844 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.845 = load i32, ptr %context.field.844, align 4
  %stack.sub.848 = sub i32 %local.resolved.owner.end.843, %local.resolved.offset.840
  %descriptor.owner.inside.846 = icmp ule i32 %local.resolved.owner.end.843, %context.value.845
  %descriptor.offset.inside.847 = icmp ule i32 %local.resolved.offset.840, %local.resolved.owner.end.843
  %descriptor.extent.inside.849 = icmp ule i32 %local.resolved.extent.841, %stack.sub.848
  %descriptor.payload.inside.850 = icmp ule i32 %local.resolved.payload.842, %local.resolved.extent.841
  %descriptor.owner.offset.valid.851 = and i1 %descriptor.owner.inside.846, %descriptor.offset.inside.847
  %descriptor.range.inside.853 = and i1 %descriptor.owner.offset.valid.851, %descriptor.extent.inside.849
  %descriptor.range.valid.852 = and i1 %descriptor.range.inside.853, %descriptor.payload.inside.850
  %descriptor.type.valid.854 = icmp eq i32 1, 1
  %descriptor.valid.855 = and i1 %descriptor.range.valid.852, %descriptor.type.valid.854
  br i1 %descriptor.valid.855, label %descriptor.valid.856, label %descriptor.invalid.857
descriptor.invalid.857:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.856:
  %descriptor.initialized.status.858 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.840, i32 %local.resolved.extent.841)
  %helper.ok.859 = icmp eq i32 %descriptor.initialized.status.858, 0
  br i1 %helper.ok.859, label %helper.continue.860, label %frame.failure.0
helper.continue.860:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %local.resolved.offset.840, i32 20, i32 %local.resolved.payload.842, i32 %local.resolved.owner.end.843, i32 %local.resolved.extent.841)
  %context.field.861 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.862 = load i32, ptr %context.field.861, align 4
  %runtime.ok.863 = icmp eq i32 %context.value.862, 0
  br i1 %runtime.ok.863, label %runtime.continue.864, label %frame.failure.0
runtime.continue.864:
  %context.field.865 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.866 = load i32, ptr %context.field.865, align 4
  %stack.sub.869 = sub i32 %local.resolved.owner.end.729, %local.resolved.offset.726
  %descriptor.owner.inside.867 = icmp ule i32 %local.resolved.owner.end.729, %context.value.866
  %descriptor.offset.inside.868 = icmp ule i32 %local.resolved.offset.726, %local.resolved.owner.end.729
  %descriptor.extent.inside.870 = icmp ule i32 %local.resolved.extent.727, %stack.sub.869
  %descriptor.payload.inside.871 = icmp ule i32 %local.resolved.payload.728, %local.resolved.extent.727
  %descriptor.owner.offset.valid.872 = and i1 %descriptor.owner.inside.867, %descriptor.offset.inside.868
  %descriptor.range.inside.874 = and i1 %descriptor.owner.offset.valid.872, %descriptor.extent.inside.870
  %descriptor.range.valid.873 = and i1 %descriptor.range.inside.874, %descriptor.payload.inside.871
  %descriptor.type.valid.875 = icmp eq i32 12, 12
  %descriptor.valid.876 = and i1 %descriptor.range.valid.873, %descriptor.type.valid.875
  br i1 %descriptor.valid.876, label %descriptor.valid.877, label %descriptor.invalid.878
descriptor.invalid.878:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.877:
  %descriptor.initialized.status.879 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.726, i32 %local.resolved.extent.727)
  %helper.ok.880 = icmp eq i32 %descriptor.initialized.status.879, 0
  br i1 %helper.ok.880, label %helper.continue.881, label %frame.failure.0
helper.continue.881:
  %context.field.882 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.883 = load i32, ptr %context.field.882, align 4
  %stack.sub.886 = sub i32 %local.resolved.owner.end.843, %local.resolved.offset.840
  %descriptor.owner.inside.884 = icmp ule i32 %local.resolved.owner.end.843, %context.value.883
  %descriptor.offset.inside.885 = icmp ule i32 %local.resolved.offset.840, %local.resolved.owner.end.843
  %descriptor.extent.inside.887 = icmp ule i32 %local.resolved.extent.841, %stack.sub.886
  %descriptor.payload.inside.888 = icmp ule i32 %local.resolved.payload.842, %local.resolved.extent.841
  %descriptor.owner.offset.valid.889 = and i1 %descriptor.owner.inside.884, %descriptor.offset.inside.885
  %descriptor.range.inside.891 = and i1 %descriptor.owner.offset.valid.889, %descriptor.extent.inside.887
  %descriptor.range.valid.890 = and i1 %descriptor.range.inside.891, %descriptor.payload.inside.888
  %descriptor.type.valid.892 = icmp eq i32 1, 1
  %descriptor.valid.893 = and i1 %descriptor.range.valid.890, %descriptor.type.valid.892
  br i1 %descriptor.valid.893, label %descriptor.valid.894, label %descriptor.invalid.895
descriptor.invalid.895:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.894:
  %descriptor.initialized.status.896 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.840, i32 %local.resolved.extent.841)
  %helper.ok.897 = icmp eq i32 %descriptor.initialized.status.896, 0
  br i1 %helper.ok.897, label %helper.continue.898, label %frame.failure.0
helper.continue.898:
  %local.is.active.899 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.899, label %local.descriptor.active.900, label %local.descriptor.inactive.901
local.descriptor.active.900:
  %local.check.offset.903 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.904 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.905 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.906 = load i32, ptr %local.owner.end.6, align 4
  %context.field.907 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.908 = load i32, ptr %context.field.907, align 4
  %stack.sub.911 = sub i32 %local.check.owner.end.906, %local.check.offset.903
  %descriptor.owner.inside.909 = icmp ule i32 %local.check.owner.end.906, %context.value.908
  %descriptor.offset.inside.910 = icmp ule i32 %local.check.offset.903, %local.check.owner.end.906
  %descriptor.extent.inside.912 = icmp ule i32 %local.check.extent.904, %stack.sub.911
  %descriptor.payload.inside.913 = icmp ule i32 %local.check.payload.905, %local.check.extent.904
  %descriptor.owner.offset.valid.914 = and i1 %descriptor.owner.inside.909, %descriptor.offset.inside.910
  %descriptor.range.inside.916 = and i1 %descriptor.owner.offset.valid.914, %descriptor.extent.inside.912
  %descriptor.range.valid.915 = and i1 %descriptor.range.inside.916, %descriptor.payload.inside.913
  br i1 %descriptor.range.valid.915, label %descriptor.valid.917, label %descriptor.invalid.918
descriptor.invalid.918:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.917:
  %descriptor.initialized.status.919 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.903, i32 %local.check.extent.904)
  %helper.ok.920 = icmp eq i32 %descriptor.initialized.status.919, 0
  br i1 %helper.ok.920, label %helper.continue.921, label %frame.failure.0
helper.continue.921:
  br label %local.descriptor.checked.902
local.descriptor.inactive.901:
  br label %local.descriptor.checked.902
local.descriptor.checked.902:
  %local.is.active.922 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.922, label %local.descriptor.active.923, label %local.descriptor.inactive.924
local.descriptor.active.923:
  %local.check.offset.926 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.927 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.928 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.929 = load i32, ptr %local.owner.end.12, align 4
  %context.field.930 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.931 = load i32, ptr %context.field.930, align 4
  %stack.sub.934 = sub i32 %local.check.owner.end.929, %local.check.offset.926
  %descriptor.owner.inside.932 = icmp ule i32 %local.check.owner.end.929, %context.value.931
  %descriptor.offset.inside.933 = icmp ule i32 %local.check.offset.926, %local.check.owner.end.929
  %descriptor.extent.inside.935 = icmp ule i32 %local.check.extent.927, %stack.sub.934
  %descriptor.payload.inside.936 = icmp ule i32 %local.check.payload.928, %local.check.extent.927
  %descriptor.owner.offset.valid.937 = and i1 %descriptor.owner.inside.932, %descriptor.offset.inside.933
  %descriptor.range.inside.939 = and i1 %descriptor.owner.offset.valid.937, %descriptor.extent.inside.935
  %descriptor.range.valid.938 = and i1 %descriptor.range.inside.939, %descriptor.payload.inside.936
  br i1 %descriptor.range.valid.938, label %descriptor.valid.940, label %descriptor.invalid.941
descriptor.invalid.941:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.940:
  %descriptor.initialized.status.942 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.926, i32 %local.check.extent.927)
  %helper.ok.943 = icmp eq i32 %descriptor.initialized.status.942, 0
  br i1 %helper.ok.943, label %helper.continue.944, label %frame.failure.0
helper.continue.944:
  br label %local.descriptor.checked.925
local.descriptor.inactive.924:
  br label %local.descriptor.checked.925
local.descriptor.checked.925:
  %local.is.active.945 = load i1, ptr %local.active.14, align 1
  br i1 %local.is.active.945, label %local.descriptor.active.946, label %local.descriptor.inactive.947
local.descriptor.active.946:
  %local.check.offset.949 = load i32, ptr %local.offset.15, align 4
  %local.check.extent.950 = load i32, ptr %local.extent.16, align 4
  %local.check.payload.951 = load i32, ptr %local.payload.17, align 4
  %local.check.owner.end.952 = load i32, ptr %local.owner.end.18, align 4
  %context.field.953 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.954 = load i32, ptr %context.field.953, align 4
  %stack.sub.957 = sub i32 %local.check.owner.end.952, %local.check.offset.949
  %descriptor.owner.inside.955 = icmp ule i32 %local.check.owner.end.952, %context.value.954
  %descriptor.offset.inside.956 = icmp ule i32 %local.check.offset.949, %local.check.owner.end.952
  %descriptor.extent.inside.958 = icmp ule i32 %local.check.extent.950, %stack.sub.957
  %descriptor.payload.inside.959 = icmp ule i32 %local.check.payload.951, %local.check.extent.950
  %descriptor.owner.offset.valid.960 = and i1 %descriptor.owner.inside.955, %descriptor.offset.inside.956
  %descriptor.range.inside.962 = and i1 %descriptor.owner.offset.valid.960, %descriptor.extent.inside.958
  %descriptor.range.valid.961 = and i1 %descriptor.range.inside.962, %descriptor.payload.inside.959
  br i1 %descriptor.range.valid.961, label %descriptor.valid.963, label %descriptor.invalid.964
descriptor.invalid.964:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.963:
  %descriptor.initialized.status.965 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.949, i32 %local.check.extent.950)
  %helper.ok.966 = icmp eq i32 %descriptor.initialized.status.965, 0
  br i1 %helper.ok.966, label %helper.continue.967, label %frame.failure.0
helper.continue.967:
  br label %local.descriptor.checked.948
local.descriptor.inactive.947:
  br label %local.descriptor.checked.948
local.descriptor.checked.948:
  store i1 false, ptr %local.active.14, align 1
  store i32 0, ptr %local.offset.15, align 4
  store i32 0, ptr %local.extent.16, align 4
  store i32 0, ptr %local.payload.17, align 4
  store i32 0, ptr %local.owner.end.18, align 4
  store i32 0, ptr %local.type.19, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %context.field.968 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.969 = load i32, ptr %context.field.968, align 4
  %stack.sub.970 = sub i32 %context.value.969, %context.value.21
  call void @al_owning_record_layout(ptr %ctx, i32 18, i32 0, i32 %context.value.21, i32 %stack.sub.970, i32 0, i32 0, i32 0)
  %context.field.971 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.972 = load i32, ptr %context.field.971, align 4
  %runtime.ok.973 = icmp eq i32 %context.value.972, 0
  br i1 %runtime.ok.973, label %runtime.continue.974, label %frame.failure.0
runtime.continue.974:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.21, i32 0, i32 0, i32 0)
  %context.field.975 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.976 = load i32, ptr %context.field.975, align 4
  %runtime.ok.977 = icmp eq i32 %context.value.976, 0
  br i1 %runtime.ok.977, label %runtime.continue.978, label %frame.failure.0
runtime.continue.978:
  %descriptor.element.979 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.980 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.979, i32 0, i32 0
  store i32 12, ptr %descriptor.field.980, align 4
  %descriptor.field.981 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.979, i32 0, i32 1
  store i32 %local.resolved.offset.726, ptr %descriptor.field.981, align 4
  %descriptor.field.982 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.979, i32 0, i32 2
  store i32 %local.resolved.extent.727, ptr %descriptor.field.982, align 4
  %descriptor.field.983 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.979, i32 0, i32 3
  store i32 %local.resolved.payload.728, ptr %descriptor.field.983, align 4
  %descriptor.field.984 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.979, i32 0, i32 4
  store i32 %local.resolved.owner.end.729, ptr %descriptor.field.984, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %local.resolved.offset.726, i32 20, i32 %local.resolved.payload.728, i32 %local.resolved.owner.end.729, i32 %local.resolved.extent.727)
  %context.field.985 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.986 = load i32, ptr %context.field.985, align 4
  %runtime.ok.987 = icmp eq i32 %context.value.986, 0
  br i1 %runtime.ok.987, label %runtime.continue.988, label %frame.failure.0
runtime.continue.988:
  %descriptor.element.989 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 1
  %descriptor.field.990 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.989, i32 0, i32 0
  store i32 1, ptr %descriptor.field.990, align 4
  %descriptor.field.991 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.989, i32 0, i32 1
  store i32 %local.resolved.offset.840, ptr %descriptor.field.991, align 4
  %descriptor.field.992 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.989, i32 0, i32 2
  store i32 %local.resolved.extent.841, ptr %descriptor.field.992, align 4
  %descriptor.field.993 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.989, i32 0, i32 3
  store i32 %local.resolved.payload.842, ptr %descriptor.field.993, align 4
  %descriptor.field.994 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.989, i32 0, i32 4
  store i32 %local.resolved.owner.end.843, ptr %descriptor.field.994, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 1, i32 %local.resolved.offset.840, i32 20, i32 %local.resolved.payload.842, i32 %local.resolved.owner.end.843, i32 %local.resolved.extent.841)
  %context.field.995 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.996 = load i32, ptr %context.field.995, align 4
  %runtime.ok.997 = icmp eq i32 %context.value.996, 0
  br i1 %runtime.ok.997, label %runtime.continue.998, label %frame.failure.0
runtime.continue.998:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.21, i32 0, i32 0, i32 0)
  %context.field.999 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.1000 = load i32, ptr %context.field.999, align 4
  %context.field.1001 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.1002 = load i32, ptr %context.field.1001, align 4
  %context.field.1003 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.1004 = load i32, ptr %context.field.1003, align 4
  %stack.offset.1005 = add i32 %context.value.23, %context.value.25
  %stack.offset.1006 = add i32 %context.value.1000, %context.value.1002
  %stack.sub.1007 = sub i32 %stack.offset.1005, %stack.offset.1006
  %stack.sub.1008 = sub i32 %context.value.25, %context.value.1002
  %stack.sub.1009 = sub i32 %context.value.1004, %context.value.27
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1007, i32 %stack.sub.1008)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.1009)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 1
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %entry.input.descriptors.10 = alloca [1 x %AlOwningDescriptor], align 4
  %input.extent.pointer.11 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.12 = load i32, ptr %input.extent.pointer.11, align 4
  %host.pointer.13 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.14 = alloca i32, align 4
  %input.measured.extent.pointer.15 = alloca i32, align 4
  %input.measure.status.16 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 2, ptr %host.pointer.13, i32 %input.host.extent.12, i32 0, i32 14, ptr %input.payload.pointer.14, ptr %input.measured.extent.pointer.15)
  %helper.ok.17 = icmp eq i32 %input.measure.status.16, 0
  br i1 %helper.ok.17, label %helper.continue.18, label %entry.failure.0
helper.continue.18:
  %input.measured.payload.19 = load i32, ptr %input.payload.pointer.14, align 4
  %input.measured.extent.20 = load i32, ptr %input.measured.extent.pointer.15, align 4
  %input.extent.exact.21 = icmp eq i32 %input.measured.extent.20, %input.host.extent.12
  br i1 %input.extent.exact.21, label %input.extent.exact.22, label %input.extent.invalid.23
input.extent.invalid.23:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 14, i32 %input.measured.extent.20, i32 %input.host.extent.12)
  br label %entry.failure.0
input.extent.exact.22:
  %stack.offset.24 = add i32 0, %input.host.extent.12
  %input.total.exact.25 = icmp eq i32 %stack.offset.24, %input.bytes
  br i1 %input.total.exact.25, label %input.valid.26, label %input.invalid.27
input.invalid.27:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.24, i32 %input.bytes)
  br label %entry.failure.0
input.valid.26:
  %reserve.status.28 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.24, i32 15)
  %reserve.ok.29 = icmp eq i32 %reserve.status.28, 0
  br i1 %reserve.ok.29, label %reserve.continue.30, label %entry.failure.0
reserve.continue.30:
  %host.pointer.31 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.32 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.31, i32 %input.host.extent.12, i32 0, i32 %input.measured.payload.19, i32 %input.host.extent.12, i32 10, i32 16)
  %helper.ok.33 = icmp eq i32 %input.copy.status.32, 0
  br i1 %helper.ok.33, label %helper.continue.34, label %entry.failure.0
helper.continue.34:
  %stack.offset.35 = add i32 0, %input.host.extent.12
  %descriptor.element.36 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.10, i32 0
  %descriptor.field.37 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.36, i32 0, i32 0
  store i32 10, ptr %descriptor.field.37, align 4
  %descriptor.field.38 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.36, i32 0, i32 1
  store i32 0, ptr %descriptor.field.38, align 4
  %descriptor.field.39 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.36, i32 0, i32 2
  store i32 %input.host.extent.12, ptr %descriptor.field.39, align 4
  %descriptor.field.40 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.36, i32 0, i32 3
  store i32 %input.measured.payload.19, ptr %descriptor.field.40, align 4
  %descriptor.field.41 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.36, i32 0, i32 4
  store i32 %stack.offset.35, ptr %descriptor.field.41, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 10, i32 0, i32 20, i32 %input.measured.payload.19, i32 %stack.offset.35, i32 %input.host.extent.12)
  %context.field.42 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.43 = load i32, ptr %context.field.42, align 4
  %runtime.ok.44 = icmp eq i32 %context.value.43, 0
  br i1 %runtime.ok.44, label %runtime.continue.45, label %entry.failure.0
runtime.continue.45:
  %entry.output.descriptors.46 = alloca [2 x %AlOwningDescriptor], align 4
  %entry.body.status.47 = call i32 @agentlang_entry_frame(ptr %ctx, ptr %entry.input.descriptors.10, ptr %entry.output.descriptors.46, i32 17)
  %entry.body.ok.48 = icmp eq i32 %entry.body.status.47, 0
  br i1 %entry.body.ok.48, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.49 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.46, i32 0
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 0
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 1
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %descriptor.field.54 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 2
  %descriptor.value.55 = load i32, ptr %descriptor.field.54, align 4
  %descriptor.field.56 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 3
  %descriptor.value.57 = load i32, ptr %descriptor.field.56, align 4
  %descriptor.field.58 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.49, i32 0, i32 4
  %descriptor.value.59 = load i32, ptr %descriptor.field.58, align 4
  %entry.output.type.valid.60 = icmp eq i32 %descriptor.value.51, 12
  br i1 %entry.output.type.valid.60, label %entry.output.type.ok.61, label %entry.output.type.invalid.62
entry.output.type.invalid.62:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.61:
  %context.field.63 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.64 = load i32, ptr %context.field.63, align 4
  %stack.sub.67 = sub i32 %descriptor.value.59, %descriptor.value.53
  %descriptor.owner.inside.65 = icmp ule i32 %descriptor.value.59, %context.value.64
  %descriptor.offset.inside.66 = icmp ule i32 %descriptor.value.53, %descriptor.value.59
  %descriptor.extent.inside.68 = icmp ule i32 %descriptor.value.55, %stack.sub.67
  %descriptor.payload.inside.69 = icmp ule i32 %descriptor.value.57, %descriptor.value.55
  %descriptor.owner.offset.valid.70 = and i1 %descriptor.owner.inside.65, %descriptor.offset.inside.66
  %descriptor.range.inside.72 = and i1 %descriptor.owner.offset.valid.70, %descriptor.extent.inside.68
  %descriptor.range.valid.71 = and i1 %descriptor.range.inside.72, %descriptor.payload.inside.69
  %descriptor.type.valid.73 = icmp eq i32 12, 12
  %descriptor.valid.74 = and i1 %descriptor.range.valid.71, %descriptor.type.valid.73
  br i1 %descriptor.valid.74, label %descriptor.valid.75, label %descriptor.invalid.76
descriptor.invalid.76:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.75:
  %descriptor.initialized.status.77 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.53, i32 %descriptor.value.55)
  %helper.ok.78 = icmp eq i32 %descriptor.initialized.status.77, 0
  br i1 %helper.ok.78, label %helper.continue.79, label %entry.failure.0
helper.continue.79:
  %entry.output.size.i64.80 = zext i32 %descriptor.value.55 to i64
  %entry.output.total.i64.81 = add i64 0, %entry.output.size.i64.80
  %descriptor.element.82 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.46, i32 1
  %descriptor.field.83 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.82, i32 0, i32 0
  %descriptor.value.84 = load i32, ptr %descriptor.field.83, align 4
  %descriptor.field.85 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.82, i32 0, i32 1
  %descriptor.value.86 = load i32, ptr %descriptor.field.85, align 4
  %descriptor.field.87 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.82, i32 0, i32 2
  %descriptor.value.88 = load i32, ptr %descriptor.field.87, align 4
  %descriptor.field.89 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.82, i32 0, i32 3
  %descriptor.value.90 = load i32, ptr %descriptor.field.89, align 4
  %descriptor.field.91 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.82, i32 0, i32 4
  %descriptor.value.92 = load i32, ptr %descriptor.field.91, align 4
  %entry.output.type.valid.93 = icmp eq i32 %descriptor.value.84, 1
  br i1 %entry.output.type.valid.93, label %entry.output.type.ok.94, label %entry.output.type.invalid.95
entry.output.type.invalid.95:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.94:
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %stack.sub.100 = sub i32 %descriptor.value.92, %descriptor.value.86
  %descriptor.owner.inside.98 = icmp ule i32 %descriptor.value.92, %context.value.97
  %descriptor.offset.inside.99 = icmp ule i32 %descriptor.value.86, %descriptor.value.92
  %descriptor.extent.inside.101 = icmp ule i32 %descriptor.value.88, %stack.sub.100
  %descriptor.payload.inside.102 = icmp ule i32 %descriptor.value.90, %descriptor.value.88
  %descriptor.owner.offset.valid.103 = and i1 %descriptor.owner.inside.98, %descriptor.offset.inside.99
  %descriptor.range.inside.105 = and i1 %descriptor.owner.offset.valid.103, %descriptor.extent.inside.101
  %descriptor.range.valid.104 = and i1 %descriptor.range.inside.105, %descriptor.payload.inside.102
  %descriptor.type.valid.106 = icmp eq i32 1, 1
  %descriptor.valid.107 = and i1 %descriptor.range.valid.104, %descriptor.type.valid.106
  br i1 %descriptor.valid.107, label %descriptor.valid.108, label %descriptor.invalid.109
descriptor.invalid.109:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.108:
  %descriptor.initialized.status.110 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.86, i32 %descriptor.value.88)
  %helper.ok.111 = icmp eq i32 %descriptor.initialized.status.110, 0
  br i1 %helper.ok.111, label %helper.continue.112, label %entry.failure.0
helper.continue.112:
  %entry.output.size.i64.113 = zext i32 %descriptor.value.88 to i64
  %entry.output.total.i64.114 = add i64 %entry.output.total.i64.81, %entry.output.size.i64.113
  %entry.retained.capacity.i64.115 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.116 = icmp ule i64 %entry.output.total.i64.114, 4294967295
  %entry.retained.required.truncated.117 = trunc i64 %entry.output.total.i64.114 to i32
  %entry.retained.required.118 = select i1 %entry.retained.required.fits.u32.116, i32 %entry.retained.required.truncated.117, i32 4294967295
  %entry.retained.capacity.ok.119 = icmp ule i64 %entry.output.total.i64.114, %entry.retained.capacity.i64.115
  br i1 %entry.retained.capacity.ok.119, label %entry.retained.capacity.ready.120, label %entry.retained.capacity.failure.121
entry.retained.capacity.failure.121:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.118, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.120:
  %host.pointer.122 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.123 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.122, i32 %stack.sub.123, i32 %descriptor.value.53, i32 %descriptor.value.55, i32 12)
  %context.field.124 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.125 = load i32, ptr %context.field.124, align 4
  %runtime.ok.126 = icmp eq i32 %context.value.125, 0
  br i1 %runtime.ok.126, label %runtime.continue.127, label %entry.failure.0
runtime.continue.127:
  %stack.offset.128 = add i32 0, %descriptor.value.55
  %host.pointer.129 = getelementptr inbounds i8, ptr %retained, i32 %stack.offset.128
  %stack.sub.130 = sub i32 %retained.capacity, %stack.offset.128
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.129, i32 %stack.sub.130, i32 %descriptor.value.86, i32 %descriptor.value.88, i32 1)
  %context.field.131 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.132 = load i32, ptr %context.field.131, align 4
  %runtime.ok.133 = icmp eq i32 %context.value.132, 0
  br i1 %runtime.ok.133, label %runtime.continue.134, label %entry.failure.0
runtime.continue.134:
  %stack.offset.135 = add i32 %stack.offset.128, %descriptor.value.88
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.136 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.137 = load i32, ptr %context.field.136, align 4
  %context.field.138 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.139 = load i32, ptr %context.field.138, align 4
  %stack.sub.140 = sub i32 0, %context.value.137
  %stack.sub.141 = sub i32 0, %context.value.139
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.140, i32 %stack.sub.141)
  %context.field.142 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.143 = load i32, ptr %context.field.142, align 4
  %runtime.ok.144 = icmp eq i32 %context.value.143, 0
  br i1 %runtime.ok.144, label %runtime.continue.145, label %entry.failure.0
runtime.continue.145:
  br label %entry.return.status
entry.failure.0:
  %context.field.146 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.147 = load i32, ptr %context.field.146, align 4
  %context.field.148 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.149 = load i32, ptr %context.field.148, align 4
  %context.field.150 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.151 = load i32, ptr %context.field.150, align 4
  %stack.offset.152 = add i32 %context.value.147, %context.value.149
  %stack.sub.153 = sub i32 0, %stack.offset.152
  %stack.sub.154 = sub i32 0, %context.value.149
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.153, i32 %stack.sub.154)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.151)
  br label %entry.return.status
entry.return.status:
  %context.field.155 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.156 = load i32, ptr %context.field.155, align 4
  ret i32 %context.value.156
}


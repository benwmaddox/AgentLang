%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [1 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 5, i32 12, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8 }], align 4
@al_owning_fields = private constant [1 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 0, i32 0, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 1, ptr @al_owning_types, i32 1, ptr @al_owning_fields, i32 0 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 12
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 12, 12
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %descriptor.element.43 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.44 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 0
  %descriptor.value.45 = load i32, ptr %descriptor.field.44, align 4
  %descriptor.field.46 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 1
  %descriptor.value.47 = load i32, ptr %descriptor.field.46, align 4
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 2
  %descriptor.value.49 = load i32, ptr %descriptor.field.48, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 3
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 4
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %argument.type.valid.54 = icmp eq i32 %descriptor.value.45, 12
  br i1 %argument.type.valid.54, label %argument.type.ok.55, label %frame.failure.0
argument.type.ok.55:
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %stack.sub.60 = sub i32 %descriptor.value.53, %descriptor.value.47
  %descriptor.owner.inside.58 = icmp ule i32 %descriptor.value.53, %context.value.57
  %descriptor.offset.inside.59 = icmp ule i32 %descriptor.value.47, %descriptor.value.53
  %descriptor.extent.inside.61 = icmp ule i32 %descriptor.value.49, %stack.sub.60
  %descriptor.payload.inside.62 = icmp ule i32 %descriptor.value.51, %descriptor.value.49
  %descriptor.owner.offset.valid.63 = and i1 %descriptor.owner.inside.58, %descriptor.offset.inside.59
  %descriptor.range.inside.65 = and i1 %descriptor.owner.offset.valid.63, %descriptor.extent.inside.61
  %descriptor.range.valid.64 = and i1 %descriptor.range.inside.65, %descriptor.payload.inside.62
  %descriptor.type.valid.66 = icmp eq i32 12, 12
  %descriptor.valid.67 = and i1 %descriptor.range.valid.64, %descriptor.type.valid.66
  br i1 %descriptor.valid.67, label %descriptor.valid.68, label %descriptor.invalid.69
descriptor.invalid.69:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.68:
  %descriptor.initialized.status.70 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.47, i32 %descriptor.value.49)
  %helper.ok.71 = icmp eq i32 %descriptor.initialized.status.70, 0
  br i1 %helper.ok.71, label %helper.continue.72, label %frame.failure.0
helper.continue.72:
  %step.status.73 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.74 = icmp eq i32 %step.status.73, 0
  br i1 %helper.ok.74, label %helper.continue.75, label %frame.failure.0
helper.continue.75:
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %string.concat.units.78 = alloca i32, align 4
  %string.concat.payload.pointer.79 = alloca i32, align 4
  %string.concat.extent.pointer.80 = alloca i32, align 4
  %string.concat.plan.status.81 = call i32 @al_owning_string_concat_plan(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19, i32 %descriptor.value.47, i32 %descriptor.value.49, i32 2, ptr %string.concat.units.78, ptr %string.concat.payload.pointer.79, ptr %string.concat.extent.pointer.80)
  %helper.ok.82 = icmp eq i32 %string.concat.plan.status.81, 0
  br i1 %helper.ok.82, label %helper.continue.83, label %frame.failure.0
helper.continue.83:
  %string.concat.payload.84 = load i32, ptr %string.concat.payload.pointer.79, align 4
  %string.concat.extent.85 = load i32, ptr %string.concat.extent.pointer.80, align 4
  %stack.offset.86 = add i32 %context.value.77, %string.concat.extent.85
  %reserve.status.87 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.86, i32 3)
  %reserve.ok.88 = icmp eq i32 %reserve.status.87, 0
  br i1 %reserve.ok.88, label %reserve.continue.89, label %frame.failure.0
reserve.continue.89:
  %string.concat.write.status.90 = call i32 @al_owning_string_concat_write(ptr %ctx, i32 %context.value.77, i32 %string.concat.extent.85, i32 %descriptor.value.17, i32 %descriptor.value.19, i32 %descriptor.value.47, i32 %descriptor.value.49, i32 12, i32 2)
  %helper.ok.91 = icmp eq i32 %string.concat.write.status.90, 0
  br i1 %helper.ok.91, label %helper.continue.92, label %frame.failure.0
helper.continue.92:
  call void @al_owning_update_live(ptr %ctx, i32 %string.concat.payload.84, i32 0)
  %context.field.93 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.94 = load i32, ptr %context.field.93, align 4
  %runtime.ok.95 = icmp eq i32 %context.value.94, 0
  br i1 %runtime.ok.95, label %runtime.continue.96, label %frame.failure.0
runtime.continue.96:
  %context.field.97 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.98 = load i32, ptr %context.field.97, align 4
  %stack.sub.101 = sub i32 %stack.offset.86, %context.value.77
  %descriptor.owner.inside.99 = icmp ule i32 %stack.offset.86, %context.value.98
  %descriptor.offset.inside.100 = icmp ule i32 %context.value.77, %stack.offset.86
  %descriptor.extent.inside.102 = icmp ule i32 %string.concat.extent.85, %stack.sub.101
  %descriptor.payload.inside.103 = icmp ule i32 %string.concat.payload.84, %string.concat.extent.85
  %descriptor.owner.offset.valid.104 = and i1 %descriptor.owner.inside.99, %descriptor.offset.inside.100
  %descriptor.range.inside.106 = and i1 %descriptor.owner.offset.valid.104, %descriptor.extent.inside.102
  %descriptor.range.valid.105 = and i1 %descriptor.range.inside.106, %descriptor.payload.inside.103
  %descriptor.type.valid.107 = icmp eq i32 12, 12
  %descriptor.valid.108 = and i1 %descriptor.range.valid.105, %descriptor.type.valid.107
  br i1 %descriptor.valid.108, label %descriptor.valid.109, label %descriptor.invalid.110
descriptor.invalid.110:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.109:
  %descriptor.initialized.status.111 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.77, i32 %string.concat.extent.85)
  %helper.ok.112 = icmp eq i32 %descriptor.initialized.status.111, 0
  br i1 %helper.ok.112, label %helper.continue.113, label %frame.failure.0
helper.continue.113:
  %descriptor.element.114 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.115 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.114, i32 0, i32 0
  store i32 12, ptr %descriptor.field.115, align 4
  %descriptor.field.116 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.114, i32 0, i32 1
  store i32 %context.value.77, ptr %descriptor.field.116, align 4
  %descriptor.field.117 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.114, i32 0, i32 2
  store i32 %string.concat.extent.85, ptr %descriptor.field.117, align 4
  %descriptor.field.118 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.114, i32 0, i32 3
  store i32 %string.concat.payload.84, ptr %descriptor.field.118, align 4
  %descriptor.field.119 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.114, i32 0, i32 4
  store i32 %stack.offset.86, ptr %descriptor.field.119, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %context.value.77, i32 20, i32 %string.concat.payload.84, i32 %stack.offset.86, i32 %string.concat.extent.85)
  %context.field.120 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.121 = load i32, ptr %context.field.120, align 4
  %runtime.ok.122 = icmp eq i32 %context.value.121, 0
  br i1 %runtime.ok.122, label %runtime.continue.123, label %frame.failure.0
runtime.continue.123:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.124 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.125 = load i32, ptr %context.field.124, align 4
  %context.field.126 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.127 = load i32, ptr %context.field.126, align 4
  %context.field.128 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.129 = load i32, ptr %context.field.128, align 4
  %stack.offset.130 = add i32 %context.value.5, %context.value.7
  %stack.offset.131 = add i32 %context.value.125, %context.value.127
  %stack.sub.132 = sub i32 %stack.offset.130, %stack.offset.131
  %stack.sub.133 = sub i32 %context.value.7, %context.value.127
  %stack.sub.134 = sub i32 %context.value.129, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.132, i32 %stack.sub.133)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.134)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 2
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 2, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %entry.input.descriptors.10 = alloca [2 x %AlOwningDescriptor], align 4
  %input.extent.pointer.11 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.12 = load i32, ptr %input.extent.pointer.11, align 4
  %host.pointer.13 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.14 = alloca i32, align 4
  %input.measured.extent.pointer.15 = alloca i32, align 4
  %input.measure.status.16 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 0, ptr %host.pointer.13, i32 %input.host.extent.12, i32 0, i32 4, ptr %input.payload.pointer.14, ptr %input.measured.extent.pointer.15)
  %helper.ok.17 = icmp eq i32 %input.measure.status.16, 0
  br i1 %helper.ok.17, label %helper.continue.18, label %entry.failure.0
helper.continue.18:
  %input.measured.payload.19 = load i32, ptr %input.payload.pointer.14, align 4
  %input.measured.extent.20 = load i32, ptr %input.measured.extent.pointer.15, align 4
  %input.extent.exact.21 = icmp eq i32 %input.measured.extent.20, %input.host.extent.12
  br i1 %input.extent.exact.21, label %input.extent.exact.22, label %input.extent.invalid.23
input.extent.invalid.23:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 4, i32 %input.measured.extent.20, i32 %input.host.extent.12)
  br label %entry.failure.0
input.extent.exact.22:
  %stack.offset.24 = add i32 0, %input.host.extent.12
  %input.extent.pointer.25 = getelementptr inbounds i32, ptr %input.extents, i32 1
  %input.host.extent.26 = load i32, ptr %input.extent.pointer.25, align 4
  %host.pointer.27 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.24
  %input.payload.pointer.28 = alloca i32, align 4
  %input.measured.extent.pointer.29 = alloca i32, align 4
  %input.measure.status.30 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 0, ptr %host.pointer.27, i32 %input.host.extent.26, i32 0, i32 5, ptr %input.payload.pointer.28, ptr %input.measured.extent.pointer.29)
  %helper.ok.31 = icmp eq i32 %input.measure.status.30, 0
  br i1 %helper.ok.31, label %helper.continue.32, label %entry.failure.0
helper.continue.32:
  %input.measured.payload.33 = load i32, ptr %input.payload.pointer.28, align 4
  %input.measured.extent.34 = load i32, ptr %input.measured.extent.pointer.29, align 4
  %input.extent.exact.35 = icmp eq i32 %input.measured.extent.34, %input.host.extent.26
  br i1 %input.extent.exact.35, label %input.extent.exact.36, label %input.extent.invalid.37
input.extent.invalid.37:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 5, i32 %input.measured.extent.34, i32 %input.host.extent.26)
  br label %entry.failure.0
input.extent.exact.36:
  %stack.offset.38 = add i32 %stack.offset.24, %input.host.extent.26
  %input.total.exact.39 = icmp eq i32 %stack.offset.38, %input.bytes
  br i1 %input.total.exact.39, label %input.valid.40, label %input.invalid.41
input.invalid.41:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.38, i32 %input.bytes)
  br label %entry.failure.0
input.valid.40:
  %reserve.status.42 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.38, i32 6)
  %reserve.ok.43 = icmp eq i32 %reserve.status.42, 0
  br i1 %reserve.ok.43, label %reserve.continue.44, label %entry.failure.0
reserve.continue.44:
  %host.pointer.45 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.46 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.45, i32 %input.host.extent.12, i32 0, i32 %input.measured.payload.19, i32 %input.host.extent.12, i32 12, i32 7)
  %helper.ok.47 = icmp eq i32 %input.copy.status.46, 0
  br i1 %helper.ok.47, label %helper.continue.48, label %entry.failure.0
helper.continue.48:
  %stack.offset.49 = add i32 0, %input.host.extent.12
  %descriptor.element.50 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.10, i32 0
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 0
  store i32 12, ptr %descriptor.field.51, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 1
  store i32 0, ptr %descriptor.field.52, align 4
  %descriptor.field.53 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 2
  store i32 %input.host.extent.12, ptr %descriptor.field.53, align 4
  %descriptor.field.54 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 3
  store i32 %input.measured.payload.19, ptr %descriptor.field.54, align 4
  %descriptor.field.55 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 4
  store i32 %stack.offset.49, ptr %descriptor.field.55, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 0, i32 20, i32 %input.measured.payload.19, i32 %stack.offset.49, i32 %input.host.extent.12)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %entry.failure.0
runtime.continue.59:
  %host.pointer.60 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.24
  %input.copy.status.61 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.24, ptr %host.pointer.60, i32 %input.host.extent.26, i32 0, i32 %input.measured.payload.33, i32 %input.host.extent.26, i32 12, i32 8)
  %helper.ok.62 = icmp eq i32 %input.copy.status.61, 0
  br i1 %helper.ok.62, label %helper.continue.63, label %entry.failure.0
helper.continue.63:
  %stack.offset.64 = add i32 %stack.offset.24, %input.host.extent.26
  %descriptor.element.65 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.10, i32 1
  %descriptor.field.66 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.65, i32 0, i32 0
  store i32 12, ptr %descriptor.field.66, align 4
  %descriptor.field.67 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.65, i32 0, i32 1
  store i32 %stack.offset.24, ptr %descriptor.field.67, align 4
  %descriptor.field.68 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.65, i32 0, i32 2
  store i32 %input.host.extent.26, ptr %descriptor.field.68, align 4
  %descriptor.field.69 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.65, i32 0, i32 3
  store i32 %input.measured.payload.33, ptr %descriptor.field.69, align 4
  %descriptor.field.70 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.65, i32 0, i32 4
  store i32 %stack.offset.64, ptr %descriptor.field.70, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %stack.offset.24, i32 20, i32 %input.measured.payload.33, i32 %stack.offset.64, i32 %input.host.extent.26)
  %context.field.71 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.72 = load i32, ptr %context.field.71, align 4
  %runtime.ok.73 = icmp eq i32 %context.value.72, 0
  br i1 %runtime.ok.73, label %runtime.continue.74, label %entry.failure.0
runtime.continue.74:
  %entry.output.descriptors.75 = alloca [1 x %AlOwningDescriptor], align 4
  %entry.body.status.76 = call i32 @agentlang_entry_frame(ptr %ctx, ptr %entry.input.descriptors.10, ptr %entry.output.descriptors.75, i32 9)
  %entry.body.ok.77 = icmp eq i32 %entry.body.status.76, 0
  br i1 %entry.body.ok.77, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.78 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.75, i32 0
  %descriptor.field.79 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.78, i32 0, i32 0
  %descriptor.value.80 = load i32, ptr %descriptor.field.79, align 4
  %descriptor.field.81 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.78, i32 0, i32 1
  %descriptor.value.82 = load i32, ptr %descriptor.field.81, align 4
  %descriptor.field.83 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.78, i32 0, i32 2
  %descriptor.value.84 = load i32, ptr %descriptor.field.83, align 4
  %descriptor.field.85 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.78, i32 0, i32 3
  %descriptor.value.86 = load i32, ptr %descriptor.field.85, align 4
  %descriptor.field.87 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.78, i32 0, i32 4
  %descriptor.value.88 = load i32, ptr %descriptor.field.87, align 4
  %entry.output.type.valid.89 = icmp eq i32 %descriptor.value.80, 12
  br i1 %entry.output.type.valid.89, label %entry.output.type.ok.90, label %entry.output.type.invalid.91
entry.output.type.invalid.91:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.90:
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %stack.sub.96 = sub i32 %descriptor.value.88, %descriptor.value.82
  %descriptor.owner.inside.94 = icmp ule i32 %descriptor.value.88, %context.value.93
  %descriptor.offset.inside.95 = icmp ule i32 %descriptor.value.82, %descriptor.value.88
  %descriptor.extent.inside.97 = icmp ule i32 %descriptor.value.84, %stack.sub.96
  %descriptor.payload.inside.98 = icmp ule i32 %descriptor.value.86, %descriptor.value.84
  %descriptor.owner.offset.valid.99 = and i1 %descriptor.owner.inside.94, %descriptor.offset.inside.95
  %descriptor.range.inside.101 = and i1 %descriptor.owner.offset.valid.99, %descriptor.extent.inside.97
  %descriptor.range.valid.100 = and i1 %descriptor.range.inside.101, %descriptor.payload.inside.98
  %descriptor.type.valid.102 = icmp eq i32 12, 12
  %descriptor.valid.103 = and i1 %descriptor.range.valid.100, %descriptor.type.valid.102
  br i1 %descriptor.valid.103, label %descriptor.valid.104, label %descriptor.invalid.105
descriptor.invalid.105:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.104:
  %descriptor.initialized.status.106 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.82, i32 %descriptor.value.84)
  %helper.ok.107 = icmp eq i32 %descriptor.initialized.status.106, 0
  br i1 %helper.ok.107, label %helper.continue.108, label %entry.failure.0
helper.continue.108:
  %entry.output.size.i64.109 = zext i32 %descriptor.value.84 to i64
  %entry.output.total.i64.110 = add i64 0, %entry.output.size.i64.109
  %entry.retained.capacity.i64.111 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.112 = icmp ule i64 %entry.output.total.i64.110, 4294967295
  %entry.retained.required.truncated.113 = trunc i64 %entry.output.total.i64.110 to i32
  %entry.retained.required.114 = select i1 %entry.retained.required.fits.u32.112, i32 %entry.retained.required.truncated.113, i32 4294967295
  %entry.retained.capacity.ok.115 = icmp ule i64 %entry.output.total.i64.110, %entry.retained.capacity.i64.111
  br i1 %entry.retained.capacity.ok.115, label %entry.retained.capacity.ready.116, label %entry.retained.capacity.failure.117
entry.retained.capacity.failure.117:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.114, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.116:
  %host.pointer.118 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.119 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.118, i32 %stack.sub.119, i32 %descriptor.value.82, i32 %descriptor.value.84, i32 12)
  %context.field.120 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.121 = load i32, ptr %context.field.120, align 4
  %runtime.ok.122 = icmp eq i32 %context.value.121, 0
  br i1 %runtime.ok.122, label %runtime.continue.123, label %entry.failure.0
runtime.continue.123:
  %stack.offset.124 = add i32 0, %descriptor.value.84
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.125 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.126 = load i32, ptr %context.field.125, align 4
  %context.field.127 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.128 = load i32, ptr %context.field.127, align 4
  %stack.sub.129 = sub i32 0, %context.value.126
  %stack.sub.130 = sub i32 0, %context.value.128
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.129, i32 %stack.sub.130)
  %context.field.131 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.132 = load i32, ptr %context.field.131, align 4
  %runtime.ok.133 = icmp eq i32 %context.value.132, 0
  br i1 %runtime.ok.133, label %runtime.continue.134, label %entry.failure.0
runtime.continue.134:
  br label %entry.return.status
entry.failure.0:
  %context.field.135 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.136 = load i32, ptr %context.field.135, align 4
  %context.field.137 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.138 = load i32, ptr %context.field.137, align 4
  %context.field.139 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.140 = load i32, ptr %context.field.139, align 4
  %stack.offset.141 = add i32 %context.value.136, %context.value.138
  %stack.sub.142 = sub i32 0, %stack.offset.141
  %stack.sub.143 = sub i32 0, %context.value.138
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.142, i32 %stack.sub.143)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.140)
  br label %entry.return.status
entry.return.status:
  %context.field.144 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.145 = load i32, ptr %context.field.144, align 4
  ret i32 %context.value.145
}


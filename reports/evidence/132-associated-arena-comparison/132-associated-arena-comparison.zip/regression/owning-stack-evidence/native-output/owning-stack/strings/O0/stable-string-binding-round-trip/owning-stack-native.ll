%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [1 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 5, i32 12, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8 }], align 4
@al_owning_fields = private constant [1 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 0, i32 0, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 1, ptr @al_owning_types, i32 1, ptr @al_owning_fields, i32 0 }, align 8
@al_owning_string_literal_0 = private unnamed_addr constant [24 x i8] c"\06\00\00\00\00\00\00\00\73\00\74\00\61\00\62\00\6C\00\65\00\00\00\00\00", align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %local.active.2 = alloca i1, align 1
  %local.offset.3 = alloca i32, align 4
  %local.extent.4 = alloca i32, align 4
  %local.payload.5 = alloca i32, align 4
  %local.owner.end.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %context.field.14 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.15 = load i32, ptr %context.field.14, align 4
  %frame.entered.16 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.17 = icmp eq i32 %frame.entered.16, 0
  br i1 %frame.enter.ok.17, label %frame.enter.continue.18, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.18:
  %step.status.19 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.20 = icmp eq i32 %step.status.19, 0
  br i1 %helper.ok.20, label %helper.continue.21, label %frame.failure.0
helper.continue.21:
  %context.field.22 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.23 = load i32, ptr %context.field.22, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %step.status.24 = call i32 @al_owning_charge_step(ptr %ctx, i32 2)
  %helper.ok.25 = icmp eq i32 %step.status.24, 0
  br i1 %helper.ok.25, label %helper.continue.26, label %frame.failure.0
helper.continue.26:
  %context.field.27 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.28 = load i32, ptr %context.field.27, align 4
  %stack.offset.29 = add i32 %context.value.28, 24
  %reserve.status.30 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.29, i32 3)
  %reserve.ok.31 = icmp eq i32 %reserve.status.30, 0
  br i1 %reserve.ok.31, label %reserve.continue.32, label %frame.failure.0
reserve.continue.32:
  %literal.status.33 = call i32 @al_owning_copy_constant(ptr %ctx, i32 %context.value.28, ptr getelementptr inbounds ([24 x i8], ptr @al_owning_string_literal_0, i64 0, i64 0), i32 24, i32 20, i32 24, i32 12, i32 4)
  %helper.ok.34 = icmp eq i32 %literal.status.33, 0
  br i1 %helper.ok.34, label %helper.continue.35, label %frame.failure.0
helper.continue.35:
  %context.field.36 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.37 = load i32, ptr %context.field.36, align 4
  %stack.sub.40 = sub i32 %stack.offset.29, %context.value.28
  %descriptor.owner.inside.38 = icmp ule i32 %stack.offset.29, %context.value.37
  %descriptor.offset.inside.39 = icmp ule i32 %context.value.28, %stack.offset.29
  %descriptor.extent.inside.41 = icmp ule i32 24, %stack.sub.40
  %descriptor.payload.inside.42 = icmp ule i32 20, 24
  %descriptor.owner.offset.valid.43 = and i1 %descriptor.owner.inside.38, %descriptor.offset.inside.39
  %descriptor.range.inside.45 = and i1 %descriptor.owner.offset.valid.43, %descriptor.extent.inside.41
  %descriptor.range.valid.44 = and i1 %descriptor.range.inside.45, %descriptor.payload.inside.42
  %descriptor.type.valid.46 = icmp eq i32 12, 12
  %descriptor.valid.47 = and i1 %descriptor.range.valid.44, %descriptor.type.valid.46
  br i1 %descriptor.valid.47, label %descriptor.valid.48, label %descriptor.invalid.49
descriptor.invalid.49:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.48:
  %descriptor.initialized.status.50 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.28, i32 24)
  %helper.ok.51 = icmp eq i32 %descriptor.initialized.status.50, 0
  br i1 %helper.ok.51, label %helper.continue.52, label %frame.failure.0
helper.continue.52:
  %local.is.active.53 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.53, label %local.descriptor.active.54, label %local.descriptor.inactive.55
local.descriptor.active.54:
  %local.check.offset.57 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.58 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.59 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.60 = load i32, ptr %local.owner.end.6, align 4
  %context.field.61 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.62 = load i32, ptr %context.field.61, align 4
  %stack.sub.65 = sub i32 %local.check.owner.end.60, %local.check.offset.57
  %descriptor.owner.inside.63 = icmp ule i32 %local.check.owner.end.60, %context.value.62
  %descriptor.offset.inside.64 = icmp ule i32 %local.check.offset.57, %local.check.owner.end.60
  %descriptor.extent.inside.66 = icmp ule i32 %local.check.extent.58, %stack.sub.65
  %descriptor.payload.inside.67 = icmp ule i32 %local.check.payload.59, %local.check.extent.58
  %descriptor.owner.offset.valid.68 = and i1 %descriptor.owner.inside.63, %descriptor.offset.inside.64
  %descriptor.range.inside.70 = and i1 %descriptor.owner.offset.valid.68, %descriptor.extent.inside.66
  %descriptor.range.valid.69 = and i1 %descriptor.range.inside.70, %descriptor.payload.inside.67
  br i1 %descriptor.range.valid.69, label %descriptor.valid.71, label %descriptor.invalid.72
descriptor.invalid.72:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.71:
  %descriptor.initialized.status.73 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.57, i32 %local.check.extent.58)
  %helper.ok.74 = icmp eq i32 %descriptor.initialized.status.73, 0
  br i1 %helper.ok.74, label %helper.continue.75, label %frame.failure.0
helper.continue.75:
  br label %local.descriptor.checked.56
local.descriptor.inactive.55:
  br label %local.descriptor.checked.56
local.descriptor.checked.56:
  %step.status.76 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.77 = icmp eq i32 %step.status.76, 0
  br i1 %helper.ok.77, label %helper.continue.78, label %frame.failure.0
helper.continue.78:
  store i1 true, ptr %local.active.2, align 1
  store i32 %context.value.28, ptr %local.offset.3, align 4
  store i32 24, ptr %local.extent.4, align 4
  store i32 20, ptr %local.payload.5, align 4
  store i32 %stack.offset.29, ptr %local.owner.end.6, align 4
  store i32 12, ptr %local.type.7, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %context.value.28, i32 20, i32 20, i32 %stack.offset.29, i32 24)
  %context.field.79 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.80 = load i32, ptr %context.field.79, align 4
  %runtime.ok.81 = icmp eq i32 %context.value.80, 0
  br i1 %runtime.ok.81, label %runtime.continue.82, label %frame.failure.0
runtime.continue.82:
  %local.is.active.83 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.83, label %local.descriptor.active.84, label %local.descriptor.inactive.85
local.descriptor.active.84:
  %local.check.offset.87 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.88 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.89 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.90 = load i32, ptr %local.owner.end.6, align 4
  %context.field.91 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.92 = load i32, ptr %context.field.91, align 4
  %stack.sub.95 = sub i32 %local.check.owner.end.90, %local.check.offset.87
  %descriptor.owner.inside.93 = icmp ule i32 %local.check.owner.end.90, %context.value.92
  %descriptor.offset.inside.94 = icmp ule i32 %local.check.offset.87, %local.check.owner.end.90
  %descriptor.extent.inside.96 = icmp ule i32 %local.check.extent.88, %stack.sub.95
  %descriptor.payload.inside.97 = icmp ule i32 %local.check.payload.89, %local.check.extent.88
  %descriptor.owner.offset.valid.98 = and i1 %descriptor.owner.inside.93, %descriptor.offset.inside.94
  %descriptor.range.inside.100 = and i1 %descriptor.owner.offset.valid.98, %descriptor.extent.inside.96
  %descriptor.range.valid.99 = and i1 %descriptor.range.inside.100, %descriptor.payload.inside.97
  br i1 %descriptor.range.valid.99, label %descriptor.valid.101, label %descriptor.invalid.102
descriptor.invalid.102:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.101:
  %descriptor.initialized.status.103 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.87, i32 %local.check.extent.88)
  %helper.ok.104 = icmp eq i32 %descriptor.initialized.status.103, 0
  br i1 %helper.ok.104, label %helper.continue.105, label %frame.failure.0
helper.continue.105:
  br label %local.descriptor.checked.86
local.descriptor.inactive.85:
  br label %local.descriptor.checked.86
local.descriptor.checked.86:
  %step.status.106 = call i32 @al_owning_charge_step(ptr %ctx, i32 6)
  %helper.ok.107 = icmp eq i32 %step.status.106, 0
  br i1 %helper.ok.107, label %helper.continue.108, label %frame.failure.0
helper.continue.108:
  %local.resolved.offset.109 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.110 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.111 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.112 = load i32, ptr %local.owner.end.6, align 4
  %context.field.113 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.114 = load i32, ptr %context.field.113, align 4
  %stack.sub.117 = sub i32 %local.resolved.owner.end.112, %local.resolved.offset.109
  %descriptor.owner.inside.115 = icmp ule i32 %local.resolved.owner.end.112, %context.value.114
  %descriptor.offset.inside.116 = icmp ule i32 %local.resolved.offset.109, %local.resolved.owner.end.112
  %descriptor.extent.inside.118 = icmp ule i32 %local.resolved.extent.110, %stack.sub.117
  %descriptor.payload.inside.119 = icmp ule i32 %local.resolved.payload.111, %local.resolved.extent.110
  %descriptor.owner.offset.valid.120 = and i1 %descriptor.owner.inside.115, %descriptor.offset.inside.116
  %descriptor.range.inside.122 = and i1 %descriptor.owner.offset.valid.120, %descriptor.extent.inside.118
  %descriptor.range.valid.121 = and i1 %descriptor.range.inside.122, %descriptor.payload.inside.119
  %descriptor.type.valid.123 = icmp eq i32 12, 12
  %descriptor.valid.124 = and i1 %descriptor.range.valid.121, %descriptor.type.valid.123
  br i1 %descriptor.valid.124, label %descriptor.valid.125, label %descriptor.invalid.126
descriptor.invalid.126:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.125:
  %descriptor.initialized.status.127 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.109, i32 %local.resolved.extent.110)
  %helper.ok.128 = icmp eq i32 %descriptor.initialized.status.127, 0
  br i1 %helper.ok.128, label %helper.continue.129, label %frame.failure.0
helper.continue.129:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %local.resolved.offset.109, i32 20, i32 %local.resolved.payload.111, i32 %local.resolved.owner.end.112, i32 %local.resolved.extent.110)
  %context.field.130 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.131 = load i32, ptr %context.field.130, align 4
  %runtime.ok.132 = icmp eq i32 %context.value.131, 0
  br i1 %runtime.ok.132, label %runtime.continue.133, label %frame.failure.0
runtime.continue.133:
  %context.field.134 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.135 = load i32, ptr %context.field.134, align 4
  %stack.sub.138 = sub i32 %local.resolved.owner.end.112, %local.resolved.offset.109
  %descriptor.owner.inside.136 = icmp ule i32 %local.resolved.owner.end.112, %context.value.135
  %descriptor.offset.inside.137 = icmp ule i32 %local.resolved.offset.109, %local.resolved.owner.end.112
  %descriptor.extent.inside.139 = icmp ule i32 %local.resolved.extent.110, %stack.sub.138
  %descriptor.payload.inside.140 = icmp ule i32 %local.resolved.payload.111, %local.resolved.extent.110
  %descriptor.owner.offset.valid.141 = and i1 %descriptor.owner.inside.136, %descriptor.offset.inside.137
  %descriptor.range.inside.143 = and i1 %descriptor.owner.offset.valid.141, %descriptor.extent.inside.139
  %descriptor.range.valid.142 = and i1 %descriptor.range.inside.143, %descriptor.payload.inside.140
  %descriptor.type.valid.144 = icmp eq i32 12, 12
  %descriptor.valid.145 = and i1 %descriptor.range.valid.142, %descriptor.type.valid.144
  br i1 %descriptor.valid.145, label %descriptor.valid.146, label %descriptor.invalid.147
descriptor.invalid.147:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.146:
  %descriptor.initialized.status.148 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.109, i32 %local.resolved.extent.110)
  %helper.ok.149 = icmp eq i32 %descriptor.initialized.status.148, 0
  br i1 %helper.ok.149, label %helper.continue.150, label %frame.failure.0
helper.continue.150:
  %local.is.active.151 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.151, label %local.descriptor.active.152, label %local.descriptor.inactive.153
local.descriptor.active.152:
  %local.check.offset.155 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.156 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.157 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.158 = load i32, ptr %local.owner.end.6, align 4
  %context.field.159 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.160 = load i32, ptr %context.field.159, align 4
  %stack.sub.163 = sub i32 %local.check.owner.end.158, %local.check.offset.155
  %descriptor.owner.inside.161 = icmp ule i32 %local.check.owner.end.158, %context.value.160
  %descriptor.offset.inside.162 = icmp ule i32 %local.check.offset.155, %local.check.owner.end.158
  %descriptor.extent.inside.164 = icmp ule i32 %local.check.extent.156, %stack.sub.163
  %descriptor.payload.inside.165 = icmp ule i32 %local.check.payload.157, %local.check.extent.156
  %descriptor.owner.offset.valid.166 = and i1 %descriptor.owner.inside.161, %descriptor.offset.inside.162
  %descriptor.range.inside.168 = and i1 %descriptor.owner.offset.valid.166, %descriptor.extent.inside.164
  %descriptor.range.valid.167 = and i1 %descriptor.range.inside.168, %descriptor.payload.inside.165
  br i1 %descriptor.range.valid.167, label %descriptor.valid.169, label %descriptor.invalid.170
descriptor.invalid.170:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.169:
  %descriptor.initialized.status.171 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.155, i32 %local.check.extent.156)
  %helper.ok.172 = icmp eq i32 %descriptor.initialized.status.171, 0
  br i1 %helper.ok.172, label %helper.continue.173, label %frame.failure.0
helper.continue.173:
  br label %local.descriptor.checked.154
local.descriptor.inactive.153:
  br label %local.descriptor.checked.154
local.descriptor.checked.154:
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %context.field.174 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.175 = load i32, ptr %context.field.174, align 4
  %stack.sub.178 = sub i32 %local.resolved.owner.end.112, %local.resolved.offset.109
  %descriptor.owner.inside.176 = icmp ule i32 %local.resolved.owner.end.112, %context.value.175
  %descriptor.offset.inside.177 = icmp ule i32 %local.resolved.offset.109, %local.resolved.owner.end.112
  %descriptor.extent.inside.179 = icmp ule i32 %local.resolved.extent.110, %stack.sub.178
  %descriptor.payload.inside.180 = icmp ule i32 %local.resolved.payload.111, %local.resolved.extent.110
  %descriptor.owner.offset.valid.181 = and i1 %descriptor.owner.inside.176, %descriptor.offset.inside.177
  %descriptor.range.inside.183 = and i1 %descriptor.owner.offset.valid.181, %descriptor.extent.inside.179
  %descriptor.range.valid.182 = and i1 %descriptor.range.inside.183, %descriptor.payload.inside.180
  %descriptor.type.valid.184 = icmp eq i32 12, 12
  %descriptor.valid.185 = and i1 %descriptor.range.valid.182, %descriptor.type.valid.184
  br i1 %descriptor.valid.185, label %descriptor.valid.186, label %descriptor.invalid.187
descriptor.invalid.187:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.186:
  %descriptor.initialized.status.188 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.109, i32 %local.resolved.extent.110)
  %helper.ok.189 = icmp eq i32 %descriptor.initialized.status.188, 0
  br i1 %helper.ok.189, label %helper.continue.190, label %frame.failure.0
helper.continue.190:
  %local.is.active.191 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.191, label %local.descriptor.active.192, label %local.descriptor.inactive.193
local.descriptor.active.192:
  %local.check.offset.195 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.196 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.197 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.198 = load i32, ptr %local.owner.end.6, align 4
  %context.field.199 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.200 = load i32, ptr %context.field.199, align 4
  %stack.sub.203 = sub i32 %local.check.owner.end.198, %local.check.offset.195
  %descriptor.owner.inside.201 = icmp ule i32 %local.check.owner.end.198, %context.value.200
  %descriptor.offset.inside.202 = icmp ule i32 %local.check.offset.195, %local.check.owner.end.198
  %descriptor.extent.inside.204 = icmp ule i32 %local.check.extent.196, %stack.sub.203
  %descriptor.payload.inside.205 = icmp ule i32 %local.check.payload.197, %local.check.extent.196
  %descriptor.owner.offset.valid.206 = and i1 %descriptor.owner.inside.201, %descriptor.offset.inside.202
  %descriptor.range.inside.208 = and i1 %descriptor.owner.offset.valid.206, %descriptor.extent.inside.204
  %descriptor.range.valid.207 = and i1 %descriptor.range.inside.208, %descriptor.payload.inside.205
  br i1 %descriptor.range.valid.207, label %descriptor.valid.209, label %descriptor.invalid.210
descriptor.invalid.210:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.209:
  %descriptor.initialized.status.211 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.195, i32 %local.check.extent.196)
  %helper.ok.212 = icmp eq i32 %descriptor.initialized.status.211, 0
  br i1 %helper.ok.212, label %helper.continue.213, label %frame.failure.0
helper.continue.213:
  br label %local.descriptor.checked.194
local.descriptor.inactive.193:
  br label %local.descriptor.checked.194
local.descriptor.checked.194:
  %descriptor.element.214 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.215 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.214, i32 0, i32 0
  store i32 12, ptr %descriptor.field.215, align 4
  %descriptor.field.216 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.214, i32 0, i32 1
  store i32 %local.resolved.offset.109, ptr %descriptor.field.216, align 4
  %descriptor.field.217 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.214, i32 0, i32 2
  store i32 %local.resolved.extent.110, ptr %descriptor.field.217, align 4
  %descriptor.field.218 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.214, i32 0, i32 3
  store i32 %local.resolved.payload.111, ptr %descriptor.field.218, align 4
  %descriptor.field.219 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.214, i32 0, i32 4
  store i32 %local.resolved.owner.end.112, ptr %descriptor.field.219, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 12, i32 %local.resolved.offset.109, i32 20, i32 %local.resolved.payload.111, i32 %local.resolved.owner.end.112, i32 %local.resolved.extent.110)
  %context.field.220 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.221 = load i32, ptr %context.field.220, align 4
  %runtime.ok.222 = icmp eq i32 %context.value.221, 0
  br i1 %runtime.ok.222, label %runtime.continue.223, label %frame.failure.0
runtime.continue.223:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.9, i32 0, i32 0, i32 0)
  %context.field.224 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.225 = load i32, ptr %context.field.224, align 4
  %context.field.226 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.227 = load i32, ptr %context.field.226, align 4
  %context.field.228 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.229 = load i32, ptr %context.field.228, align 4
  %stack.offset.230 = add i32 %context.value.11, %context.value.13
  %stack.offset.231 = add i32 %context.value.225, %context.value.227
  %stack.sub.232 = sub i32 %stack.offset.230, %stack.offset.231
  %stack.sub.233 = sub i32 %context.value.13, %context.value.227
  %stack.sub.234 = sub i32 %context.value.229, %context.value.15
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.232, i32 %stack.sub.233)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.234)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 0
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 0, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %input.total.exact.10 = icmp eq i32 0, %input.bytes
  br i1 %input.total.exact.10, label %input.valid.11, label %input.invalid.12
input.invalid.12:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 0, i32 %input.bytes)
  br label %entry.failure.0
input.valid.11:
  %reserve.status.13 = call i32 @al_owning_reserve_to(ptr %ctx, i32 0, i32 7)
  %reserve.ok.14 = icmp eq i32 %reserve.status.13, 0
  br i1 %reserve.ok.14, label %reserve.continue.15, label %entry.failure.0
reserve.continue.15:
  %entry.output.descriptors.16 = alloca [1 x %AlOwningDescriptor], align 4
  %entry.body.status.17 = call i32 @agentlang_entry_frame(ptr %ctx, ptr null, ptr %entry.output.descriptors.16, i32 8)
  %entry.body.ok.18 = icmp eq i32 %entry.body.status.17, 0
  br i1 %entry.body.ok.18, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.19 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.16, i32 0
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 0
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 1
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %descriptor.field.24 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 2
  %descriptor.value.25 = load i32, ptr %descriptor.field.24, align 4
  %descriptor.field.26 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 3
  %descriptor.value.27 = load i32, ptr %descriptor.field.26, align 4
  %descriptor.field.28 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 4
  %descriptor.value.29 = load i32, ptr %descriptor.field.28, align 4
  %entry.output.type.valid.30 = icmp eq i32 %descriptor.value.21, 12
  br i1 %entry.output.type.valid.30, label %entry.output.type.ok.31, label %entry.output.type.invalid.32
entry.output.type.invalid.32:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.31:
  %context.field.33 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.34 = load i32, ptr %context.field.33, align 4
  %stack.sub.37 = sub i32 %descriptor.value.29, %descriptor.value.23
  %descriptor.owner.inside.35 = icmp ule i32 %descriptor.value.29, %context.value.34
  %descriptor.offset.inside.36 = icmp ule i32 %descriptor.value.23, %descriptor.value.29
  %descriptor.extent.inside.38 = icmp ule i32 %descriptor.value.25, %stack.sub.37
  %descriptor.payload.inside.39 = icmp ule i32 %descriptor.value.27, %descriptor.value.25
  %descriptor.owner.offset.valid.40 = and i1 %descriptor.owner.inside.35, %descriptor.offset.inside.36
  %descriptor.range.inside.42 = and i1 %descriptor.owner.offset.valid.40, %descriptor.extent.inside.38
  %descriptor.range.valid.41 = and i1 %descriptor.range.inside.42, %descriptor.payload.inside.39
  %descriptor.type.valid.43 = icmp eq i32 12, 12
  %descriptor.valid.44 = and i1 %descriptor.range.valid.41, %descriptor.type.valid.43
  br i1 %descriptor.valid.44, label %descriptor.valid.45, label %descriptor.invalid.46
descriptor.invalid.46:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.45:
  %descriptor.initialized.status.47 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.23, i32 %descriptor.value.25)
  %helper.ok.48 = icmp eq i32 %descriptor.initialized.status.47, 0
  br i1 %helper.ok.48, label %helper.continue.49, label %entry.failure.0
helper.continue.49:
  %entry.output.size.i64.50 = zext i32 %descriptor.value.25 to i64
  %entry.output.total.i64.51 = add i64 0, %entry.output.size.i64.50
  %entry.retained.capacity.i64.52 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.53 = icmp ule i64 %entry.output.total.i64.51, 4294967295
  %entry.retained.required.truncated.54 = trunc i64 %entry.output.total.i64.51 to i32
  %entry.retained.required.55 = select i1 %entry.retained.required.fits.u32.53, i32 %entry.retained.required.truncated.54, i32 4294967295
  %entry.retained.capacity.ok.56 = icmp ule i64 %entry.output.total.i64.51, %entry.retained.capacity.i64.52
  br i1 %entry.retained.capacity.ok.56, label %entry.retained.capacity.ready.57, label %entry.retained.capacity.failure.58
entry.retained.capacity.failure.58:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.55, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.57:
  %host.pointer.59 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.60 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.59, i32 %stack.sub.60, i32 %descriptor.value.23, i32 %descriptor.value.25, i32 12)
  %context.field.61 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.62 = load i32, ptr %context.field.61, align 4
  %runtime.ok.63 = icmp eq i32 %context.value.62, 0
  br i1 %runtime.ok.63, label %runtime.continue.64, label %entry.failure.0
runtime.continue.64:
  %stack.offset.65 = add i32 0, %descriptor.value.25
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.66 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.67 = load i32, ptr %context.field.66, align 4
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %stack.sub.70 = sub i32 0, %context.value.67
  %stack.sub.71 = sub i32 0, %context.value.69
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.70, i32 %stack.sub.71)
  %context.field.72 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.73 = load i32, ptr %context.field.72, align 4
  %runtime.ok.74 = icmp eq i32 %context.value.73, 0
  br i1 %runtime.ok.74, label %runtime.continue.75, label %entry.failure.0
runtime.continue.75:
  br label %entry.return.status
entry.failure.0:
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %context.field.78 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.79 = load i32, ptr %context.field.78, align 4
  %context.field.80 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.81 = load i32, ptr %context.field.80, align 4
  %stack.offset.82 = add i32 %context.value.77, %context.value.79
  %stack.sub.83 = sub i32 0, %stack.offset.82
  %stack.sub.84 = sub i32 0, %context.value.79
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.83, i32 %stack.sub.84)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.81)
  br label %entry.return.status
entry.return.status:
  %context.field.85 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.86 = load i32, ptr %context.field.85, align 4
  ret i32 %context.value.86
}


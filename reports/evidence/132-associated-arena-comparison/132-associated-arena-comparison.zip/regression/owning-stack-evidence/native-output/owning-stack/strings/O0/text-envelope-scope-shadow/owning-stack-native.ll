%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [4 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8 }, %AlOwningTypeDescriptor { i32 4, i32 8, i32 0, i32 2, i32 4294967295, i32 4294967295, i32 24, i32 24 }, %AlOwningTypeDescriptor { i32 4, i32 9, i32 2, i32 2, i32 4294967295, i32 4294967295, i32 16, i32 16 }, %AlOwningTypeDescriptor { i32 5, i32 12, i32 4, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8 }], align 4
@al_owning_fields = private constant [4 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 2, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 4294967295, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 3, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 4294967295, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 1, ptr @al_owning_types, i32 4, ptr @al_owning_fields, i32 4 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal(ptr, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %local.active.2 = alloca i1, align 1
  %local.offset.3 = alloca i32, align 4
  %local.extent.4 = alloca i32, align 4
  %local.payload.5 = alloca i32, align 4
  %local.owner.end.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %local.active.8 = alloca i1, align 1
  %local.offset.9 = alloca i32, align 4
  %local.extent.10 = alloca i32, align 4
  %local.payload.11 = alloca i32, align 4
  %local.owner.end.12 = alloca i32, align 4
  %local.type.13 = alloca i32, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  %context.field.14 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.15 = load i32, ptr %context.field.14, align 4
  %context.field.16 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.17 = load i32, ptr %context.field.16, align 4
  %context.field.18 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.19 = load i32, ptr %context.field.18, align 4
  %context.field.20 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.21 = load i32, ptr %context.field.20, align 4
  %frame.entered.22 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.23 = icmp eq i32 %frame.entered.22, 0
  br i1 %frame.enter.ok.23, label %frame.enter.continue.24, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.24:
  %descriptor.element.25 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.26 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 0
  %descriptor.value.27 = load i32, ptr %descriptor.field.26, align 4
  %descriptor.field.28 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 1
  %descriptor.value.29 = load i32, ptr %descriptor.field.28, align 4
  %descriptor.field.30 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 2
  %descriptor.value.31 = load i32, ptr %descriptor.field.30, align 4
  %descriptor.field.32 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 3
  %descriptor.value.33 = load i32, ptr %descriptor.field.32, align 4
  %descriptor.field.34 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.25, i32 0, i32 4
  %descriptor.value.35 = load i32, ptr %descriptor.field.34, align 4
  %argument.type.valid.36 = icmp eq i32 %descriptor.value.27, 8
  br i1 %argument.type.valid.36, label %argument.type.ok.37, label %frame.failure.0
argument.type.ok.37:
  %context.field.38 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.39 = load i32, ptr %context.field.38, align 4
  %stack.sub.42 = sub i32 %descriptor.value.35, %descriptor.value.29
  %descriptor.owner.inside.40 = icmp ule i32 %descriptor.value.35, %context.value.39
  %descriptor.offset.inside.41 = icmp ule i32 %descriptor.value.29, %descriptor.value.35
  %descriptor.extent.inside.43 = icmp ule i32 %descriptor.value.31, %stack.sub.42
  %descriptor.payload.inside.44 = icmp ule i32 %descriptor.value.33, %descriptor.value.31
  %descriptor.owner.offset.valid.45 = and i1 %descriptor.owner.inside.40, %descriptor.offset.inside.41
  %descriptor.range.inside.47 = and i1 %descriptor.owner.offset.valid.45, %descriptor.extent.inside.43
  %descriptor.range.valid.46 = and i1 %descriptor.range.inside.47, %descriptor.payload.inside.44
  %descriptor.type.valid.48 = icmp eq i32 8, 8
  %descriptor.valid.49 = and i1 %descriptor.range.valid.46, %descriptor.type.valid.48
  br i1 %descriptor.valid.49, label %descriptor.valid.50, label %descriptor.invalid.51
descriptor.invalid.51:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.50:
  %descriptor.initialized.status.52 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.29, i32 %descriptor.value.31)
  %helper.ok.53 = icmp eq i32 %descriptor.initialized.status.52, 0
  br i1 %helper.ok.53, label %helper.continue.54, label %frame.failure.0
helper.continue.54:
  %descriptor.element.55 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.56 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.55, i32 0, i32 0
  %descriptor.value.57 = load i32, ptr %descriptor.field.56, align 4
  %descriptor.field.58 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.55, i32 0, i32 1
  %descriptor.value.59 = load i32, ptr %descriptor.field.58, align 4
  %descriptor.field.60 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.55, i32 0, i32 2
  %descriptor.value.61 = load i32, ptr %descriptor.field.60, align 4
  %descriptor.field.62 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.55, i32 0, i32 3
  %descriptor.value.63 = load i32, ptr %descriptor.field.62, align 4
  %descriptor.field.64 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.55, i32 0, i32 4
  %descriptor.value.65 = load i32, ptr %descriptor.field.64, align 4
  %argument.type.valid.66 = icmp eq i32 %descriptor.value.57, 8
  br i1 %argument.type.valid.66, label %argument.type.ok.67, label %frame.failure.0
argument.type.ok.67:
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %stack.sub.72 = sub i32 %descriptor.value.65, %descriptor.value.59
  %descriptor.owner.inside.70 = icmp ule i32 %descriptor.value.65, %context.value.69
  %descriptor.offset.inside.71 = icmp ule i32 %descriptor.value.59, %descriptor.value.65
  %descriptor.extent.inside.73 = icmp ule i32 %descriptor.value.61, %stack.sub.72
  %descriptor.payload.inside.74 = icmp ule i32 %descriptor.value.63, %descriptor.value.61
  %descriptor.owner.offset.valid.75 = and i1 %descriptor.owner.inside.70, %descriptor.offset.inside.71
  %descriptor.range.inside.77 = and i1 %descriptor.owner.offset.valid.75, %descriptor.extent.inside.73
  %descriptor.range.valid.76 = and i1 %descriptor.range.inside.77, %descriptor.payload.inside.74
  %descriptor.type.valid.78 = icmp eq i32 8, 8
  %descriptor.valid.79 = and i1 %descriptor.range.valid.76, %descriptor.type.valid.78
  br i1 %descriptor.valid.79, label %descriptor.valid.80, label %descriptor.invalid.81
descriptor.invalid.81:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.80:
  %descriptor.initialized.status.82 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.59, i32 %descriptor.value.61)
  %helper.ok.83 = icmp eq i32 %descriptor.initialized.status.82, 0
  br i1 %helper.ok.83, label %helper.continue.84, label %frame.failure.0
helper.continue.84:
  %step.status.85 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.86 = icmp eq i32 %step.status.85, 0
  br i1 %helper.ok.86, label %helper.continue.87, label %frame.failure.0
helper.continue.87:
  %context.field.88 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.89 = load i32, ptr %context.field.88, align 4
  %stack.sub.92 = sub i32 %descriptor.value.65, %descriptor.value.59
  %descriptor.owner.inside.90 = icmp ule i32 %descriptor.value.65, %context.value.89
  %descriptor.offset.inside.91 = icmp ule i32 %descriptor.value.59, %descriptor.value.65
  %descriptor.extent.inside.93 = icmp ule i32 %descriptor.value.61, %stack.sub.92
  %descriptor.payload.inside.94 = icmp ule i32 %descriptor.value.63, %descriptor.value.61
  %descriptor.owner.offset.valid.95 = and i1 %descriptor.owner.inside.90, %descriptor.offset.inside.91
  %descriptor.range.inside.97 = and i1 %descriptor.owner.offset.valid.95, %descriptor.extent.inside.93
  %descriptor.range.valid.96 = and i1 %descriptor.range.inside.97, %descriptor.payload.inside.94
  %descriptor.type.valid.98 = icmp eq i32 8, 8
  %descriptor.valid.99 = and i1 %descriptor.range.valid.96, %descriptor.type.valid.98
  br i1 %descriptor.valid.99, label %descriptor.valid.100, label %descriptor.invalid.101
descriptor.invalid.101:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.100:
  %descriptor.initialized.status.102 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.59, i32 %descriptor.value.61)
  %helper.ok.103 = icmp eq i32 %descriptor.initialized.status.102, 0
  br i1 %helper.ok.103, label %helper.continue.104, label %frame.failure.0
helper.continue.104:
  %context.field.105 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.106 = load i32, ptr %context.field.105, align 4
  %stack.sub.109 = sub i32 %descriptor.value.35, %descriptor.value.29
  %descriptor.owner.inside.107 = icmp ule i32 %descriptor.value.35, %context.value.106
  %descriptor.offset.inside.108 = icmp ule i32 %descriptor.value.29, %descriptor.value.35
  %descriptor.extent.inside.110 = icmp ule i32 %descriptor.value.31, %stack.sub.109
  %descriptor.payload.inside.111 = icmp ule i32 %descriptor.value.33, %descriptor.value.31
  %descriptor.owner.offset.valid.112 = and i1 %descriptor.owner.inside.107, %descriptor.offset.inside.108
  %descriptor.range.inside.114 = and i1 %descriptor.owner.offset.valid.112, %descriptor.extent.inside.110
  %descriptor.range.valid.113 = and i1 %descriptor.range.inside.114, %descriptor.payload.inside.111
  %descriptor.type.valid.115 = icmp eq i32 8, 8
  %descriptor.valid.116 = and i1 %descriptor.range.valid.113, %descriptor.type.valid.115
  br i1 %descriptor.valid.116, label %descriptor.valid.117, label %descriptor.invalid.118
descriptor.invalid.118:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.117:
  %descriptor.initialized.status.119 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.29, i32 %descriptor.value.31)
  %helper.ok.120 = icmp eq i32 %descriptor.initialized.status.119, 0
  br i1 %helper.ok.120, label %helper.continue.121, label %frame.failure.0
helper.continue.121:
  %local.is.active.122 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.122, label %local.descriptor.active.123, label %local.descriptor.inactive.124
local.descriptor.active.123:
  %local.check.offset.126 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.127 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.128 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.129 = load i32, ptr %local.owner.end.6, align 4
  %context.field.130 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.131 = load i32, ptr %context.field.130, align 4
  %stack.sub.134 = sub i32 %local.check.owner.end.129, %local.check.offset.126
  %descriptor.owner.inside.132 = icmp ule i32 %local.check.owner.end.129, %context.value.131
  %descriptor.offset.inside.133 = icmp ule i32 %local.check.offset.126, %local.check.owner.end.129
  %descriptor.extent.inside.135 = icmp ule i32 %local.check.extent.127, %stack.sub.134
  %descriptor.payload.inside.136 = icmp ule i32 %local.check.payload.128, %local.check.extent.127
  %descriptor.owner.offset.valid.137 = and i1 %descriptor.owner.inside.132, %descriptor.offset.inside.133
  %descriptor.range.inside.139 = and i1 %descriptor.owner.offset.valid.137, %descriptor.extent.inside.135
  %descriptor.range.valid.138 = and i1 %descriptor.range.inside.139, %descriptor.payload.inside.136
  br i1 %descriptor.range.valid.138, label %descriptor.valid.140, label %descriptor.invalid.141
descriptor.invalid.141:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.140:
  %descriptor.initialized.status.142 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.126, i32 %local.check.extent.127)
  %helper.ok.143 = icmp eq i32 %descriptor.initialized.status.142, 0
  br i1 %helper.ok.143, label %helper.continue.144, label %frame.failure.0
helper.continue.144:
  br label %local.descriptor.checked.125
local.descriptor.inactive.124:
  br label %local.descriptor.checked.125
local.descriptor.checked.125:
  %local.is.active.145 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.145, label %local.descriptor.active.146, label %local.descriptor.inactive.147
local.descriptor.active.146:
  %local.check.offset.149 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.150 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.151 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.152 = load i32, ptr %local.owner.end.12, align 4
  %context.field.153 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.154 = load i32, ptr %context.field.153, align 4
  %stack.sub.157 = sub i32 %local.check.owner.end.152, %local.check.offset.149
  %descriptor.owner.inside.155 = icmp ule i32 %local.check.owner.end.152, %context.value.154
  %descriptor.offset.inside.156 = icmp ule i32 %local.check.offset.149, %local.check.owner.end.152
  %descriptor.extent.inside.158 = icmp ule i32 %local.check.extent.150, %stack.sub.157
  %descriptor.payload.inside.159 = icmp ule i32 %local.check.payload.151, %local.check.extent.150
  %descriptor.owner.offset.valid.160 = and i1 %descriptor.owner.inside.155, %descriptor.offset.inside.156
  %descriptor.range.inside.162 = and i1 %descriptor.owner.offset.valid.160, %descriptor.extent.inside.158
  %descriptor.range.valid.161 = and i1 %descriptor.range.inside.162, %descriptor.payload.inside.159
  br i1 %descriptor.range.valid.161, label %descriptor.valid.163, label %descriptor.invalid.164
descriptor.invalid.164:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.163:
  %descriptor.initialized.status.165 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.149, i32 %local.check.extent.150)
  %helper.ok.166 = icmp eq i32 %descriptor.initialized.status.165, 0
  br i1 %helper.ok.166, label %helper.continue.167, label %frame.failure.0
helper.continue.167:
  br label %local.descriptor.checked.148
local.descriptor.inactive.147:
  br label %local.descriptor.checked.148
local.descriptor.checked.148:
  %step.status.168 = call i32 @al_owning_charge_step(ptr %ctx, i32 2)
  %helper.ok.169 = icmp eq i32 %step.status.168, 0
  br i1 %helper.ok.169, label %helper.continue.170, label %frame.failure.0
helper.continue.170:
  store i1 true, ptr %local.active.2, align 1
  store i32 %descriptor.value.29, ptr %local.offset.3, align 4
  store i32 %descriptor.value.31, ptr %local.extent.4, align 4
  store i32 %descriptor.value.33, ptr %local.payload.5, align 4
  store i32 %descriptor.value.35, ptr %local.owner.end.6, align 4
  store i32 8, ptr %local.type.7, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %descriptor.value.29, i32 20, i32 %descriptor.value.33, i32 %descriptor.value.35, i32 %descriptor.value.31)
  %context.field.171 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.172 = load i32, ptr %context.field.171, align 4
  %runtime.ok.173 = icmp eq i32 %context.value.172, 0
  br i1 %runtime.ok.173, label %runtime.continue.174, label %frame.failure.0
runtime.continue.174:
  %context.field.175 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.176 = load i32, ptr %context.field.175, align 4
  %stack.sub.179 = sub i32 %descriptor.value.65, %descriptor.value.59
  %descriptor.owner.inside.177 = icmp ule i32 %descriptor.value.65, %context.value.176
  %descriptor.offset.inside.178 = icmp ule i32 %descriptor.value.59, %descriptor.value.65
  %descriptor.extent.inside.180 = icmp ule i32 %descriptor.value.61, %stack.sub.179
  %descriptor.payload.inside.181 = icmp ule i32 %descriptor.value.63, %descriptor.value.61
  %descriptor.owner.offset.valid.182 = and i1 %descriptor.owner.inside.177, %descriptor.offset.inside.178
  %descriptor.range.inside.184 = and i1 %descriptor.owner.offset.valid.182, %descriptor.extent.inside.180
  %descriptor.range.valid.183 = and i1 %descriptor.range.inside.184, %descriptor.payload.inside.181
  %descriptor.type.valid.185 = icmp eq i32 8, 8
  %descriptor.valid.186 = and i1 %descriptor.range.valid.183, %descriptor.type.valid.185
  br i1 %descriptor.valid.186, label %descriptor.valid.187, label %descriptor.invalid.188
descriptor.invalid.188:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.187:
  %descriptor.initialized.status.189 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.59, i32 %descriptor.value.61)
  %helper.ok.190 = icmp eq i32 %descriptor.initialized.status.189, 0
  br i1 %helper.ok.190, label %helper.continue.191, label %frame.failure.0
helper.continue.191:
  %local.is.active.192 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.192, label %local.descriptor.active.193, label %local.descriptor.inactive.194
local.descriptor.active.193:
  %local.check.offset.196 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.197 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.198 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.199 = load i32, ptr %local.owner.end.6, align 4
  %context.field.200 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.201 = load i32, ptr %context.field.200, align 4
  %stack.sub.204 = sub i32 %local.check.owner.end.199, %local.check.offset.196
  %descriptor.owner.inside.202 = icmp ule i32 %local.check.owner.end.199, %context.value.201
  %descriptor.offset.inside.203 = icmp ule i32 %local.check.offset.196, %local.check.owner.end.199
  %descriptor.extent.inside.205 = icmp ule i32 %local.check.extent.197, %stack.sub.204
  %descriptor.payload.inside.206 = icmp ule i32 %local.check.payload.198, %local.check.extent.197
  %descriptor.owner.offset.valid.207 = and i1 %descriptor.owner.inside.202, %descriptor.offset.inside.203
  %descriptor.range.inside.209 = and i1 %descriptor.owner.offset.valid.207, %descriptor.extent.inside.205
  %descriptor.range.valid.208 = and i1 %descriptor.range.inside.209, %descriptor.payload.inside.206
  br i1 %descriptor.range.valid.208, label %descriptor.valid.210, label %descriptor.invalid.211
descriptor.invalid.211:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.210:
  %descriptor.initialized.status.212 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.196, i32 %local.check.extent.197)
  %helper.ok.213 = icmp eq i32 %descriptor.initialized.status.212, 0
  br i1 %helper.ok.213, label %helper.continue.214, label %frame.failure.0
helper.continue.214:
  br label %local.descriptor.checked.195
local.descriptor.inactive.194:
  br label %local.descriptor.checked.195
local.descriptor.checked.195:
  %local.is.active.215 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.215, label %local.descriptor.active.216, label %local.descriptor.inactive.217
local.descriptor.active.216:
  %local.check.offset.219 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.220 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.221 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.222 = load i32, ptr %local.owner.end.12, align 4
  %context.field.223 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.224 = load i32, ptr %context.field.223, align 4
  %stack.sub.227 = sub i32 %local.check.owner.end.222, %local.check.offset.219
  %descriptor.owner.inside.225 = icmp ule i32 %local.check.owner.end.222, %context.value.224
  %descriptor.offset.inside.226 = icmp ule i32 %local.check.offset.219, %local.check.owner.end.222
  %descriptor.extent.inside.228 = icmp ule i32 %local.check.extent.220, %stack.sub.227
  %descriptor.payload.inside.229 = icmp ule i32 %local.check.payload.221, %local.check.extent.220
  %descriptor.owner.offset.valid.230 = and i1 %descriptor.owner.inside.225, %descriptor.offset.inside.226
  %descriptor.range.inside.232 = and i1 %descriptor.owner.offset.valid.230, %descriptor.extent.inside.228
  %descriptor.range.valid.231 = and i1 %descriptor.range.inside.232, %descriptor.payload.inside.229
  br i1 %descriptor.range.valid.231, label %descriptor.valid.233, label %descriptor.invalid.234
descriptor.invalid.234:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.233:
  %descriptor.initialized.status.235 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.219, i32 %local.check.extent.220)
  %helper.ok.236 = icmp eq i32 %descriptor.initialized.status.235, 0
  br i1 %helper.ok.236, label %helper.continue.237, label %frame.failure.0
helper.continue.237:
  br label %local.descriptor.checked.218
local.descriptor.inactive.217:
  br label %local.descriptor.checked.218
local.descriptor.checked.218:
  %step.status.238 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.239 = icmp eq i32 %step.status.238, 0
  br i1 %helper.ok.239, label %helper.continue.240, label %frame.failure.0
helper.continue.240:
  %context.field.241 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.242 = load i32, ptr %context.field.241, align 4
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  %step.status.243 = call i32 @al_owning_charge_step(ptr %ctx, i32 4)
  %helper.ok.244 = icmp eq i32 %step.status.243, 0
  br i1 %helper.ok.244, label %helper.continue.245, label %frame.failure.0
helper.continue.245:
  store i1 true, ptr %local.active.8, align 1
  store i32 %descriptor.value.59, ptr %local.offset.9, align 4
  store i32 %descriptor.value.61, ptr %local.extent.10, align 4
  store i32 %descriptor.value.63, ptr %local.payload.11, align 4
  store i32 %descriptor.value.65, ptr %local.owner.end.12, align 4
  store i32 8, ptr %local.type.13, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %descriptor.value.59, i32 20, i32 %descriptor.value.63, i32 %descriptor.value.65, i32 %descriptor.value.61)
  %context.field.246 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.247 = load i32, ptr %context.field.246, align 4
  %runtime.ok.248 = icmp eq i32 %context.value.247, 0
  br i1 %runtime.ok.248, label %runtime.continue.249, label %frame.failure.0
runtime.continue.249:
  %local.is.active.250 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.250, label %local.descriptor.active.251, label %local.descriptor.inactive.252
local.descriptor.active.251:
  %local.check.offset.254 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.255 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.256 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.257 = load i32, ptr %local.owner.end.6, align 4
  %context.field.258 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.259 = load i32, ptr %context.field.258, align 4
  %stack.sub.262 = sub i32 %local.check.owner.end.257, %local.check.offset.254
  %descriptor.owner.inside.260 = icmp ule i32 %local.check.owner.end.257, %context.value.259
  %descriptor.offset.inside.261 = icmp ule i32 %local.check.offset.254, %local.check.owner.end.257
  %descriptor.extent.inside.263 = icmp ule i32 %local.check.extent.255, %stack.sub.262
  %descriptor.payload.inside.264 = icmp ule i32 %local.check.payload.256, %local.check.extent.255
  %descriptor.owner.offset.valid.265 = and i1 %descriptor.owner.inside.260, %descriptor.offset.inside.261
  %descriptor.range.inside.267 = and i1 %descriptor.owner.offset.valid.265, %descriptor.extent.inside.263
  %descriptor.range.valid.266 = and i1 %descriptor.range.inside.267, %descriptor.payload.inside.264
  br i1 %descriptor.range.valid.266, label %descriptor.valid.268, label %descriptor.invalid.269
descriptor.invalid.269:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.268:
  %descriptor.initialized.status.270 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.254, i32 %local.check.extent.255)
  %helper.ok.271 = icmp eq i32 %descriptor.initialized.status.270, 0
  br i1 %helper.ok.271, label %helper.continue.272, label %frame.failure.0
helper.continue.272:
  br label %local.descriptor.checked.253
local.descriptor.inactive.252:
  br label %local.descriptor.checked.253
local.descriptor.checked.253:
  %local.is.active.273 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.273, label %local.descriptor.active.274, label %local.descriptor.inactive.275
local.descriptor.active.274:
  %local.check.offset.277 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.278 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.279 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.280 = load i32, ptr %local.owner.end.12, align 4
  %context.field.281 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.282 = load i32, ptr %context.field.281, align 4
  %stack.sub.285 = sub i32 %local.check.owner.end.280, %local.check.offset.277
  %descriptor.owner.inside.283 = icmp ule i32 %local.check.owner.end.280, %context.value.282
  %descriptor.offset.inside.284 = icmp ule i32 %local.check.offset.277, %local.check.owner.end.280
  %descriptor.extent.inside.286 = icmp ule i32 %local.check.extent.278, %stack.sub.285
  %descriptor.payload.inside.287 = icmp ule i32 %local.check.payload.279, %local.check.extent.278
  %descriptor.owner.offset.valid.288 = and i1 %descriptor.owner.inside.283, %descriptor.offset.inside.284
  %descriptor.range.inside.290 = and i1 %descriptor.owner.offset.valid.288, %descriptor.extent.inside.286
  %descriptor.range.valid.289 = and i1 %descriptor.range.inside.290, %descriptor.payload.inside.287
  br i1 %descriptor.range.valid.289, label %descriptor.valid.291, label %descriptor.invalid.292
descriptor.invalid.292:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.291:
  %descriptor.initialized.status.293 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.277, i32 %local.check.extent.278)
  %helper.ok.294 = icmp eq i32 %descriptor.initialized.status.293, 0
  br i1 %helper.ok.294, label %helper.continue.295, label %frame.failure.0
helper.continue.295:
  br label %local.descriptor.checked.276
local.descriptor.inactive.275:
  br label %local.descriptor.checked.276
local.descriptor.checked.276:
  store i1 false, ptr %local.active.8, align 1
  store i32 0, ptr %local.offset.9, align 4
  store i32 0, ptr %local.extent.10, align 4
  store i32 0, ptr %local.payload.11, align 4
  store i32 0, ptr %local.owner.end.12, align 4
  store i32 0, ptr %local.type.13, align 4
  %context.field.296 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.297 = load i32, ptr %context.field.296, align 4
  %stack.sub.298 = sub i32 %context.value.297, %context.value.242
  call void @al_owning_record_layout(ptr %ctx, i32 18, i32 0, i32 %context.value.242, i32 %stack.sub.298, i32 0, i32 0, i32 0)
  %context.field.299 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.300 = load i32, ptr %context.field.299, align 4
  %runtime.ok.301 = icmp eq i32 %context.value.300, 0
  br i1 %runtime.ok.301, label %runtime.continue.302, label %frame.failure.0
runtime.continue.302:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.242, i32 0, i32 0, i32 0)
  %context.field.303 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.304 = load i32, ptr %context.field.303, align 4
  %runtime.ok.305 = icmp eq i32 %context.value.304, 0
  br i1 %runtime.ok.305, label %runtime.continue.306, label %frame.failure.0
runtime.continue.306:
  %local.is.active.307 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.307, label %local.descriptor.active.308, label %local.descriptor.inactive.309
local.descriptor.active.308:
  %local.check.offset.311 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.312 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.313 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.314 = load i32, ptr %local.owner.end.6, align 4
  %context.field.315 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.316 = load i32, ptr %context.field.315, align 4
  %stack.sub.319 = sub i32 %local.check.owner.end.314, %local.check.offset.311
  %descriptor.owner.inside.317 = icmp ule i32 %local.check.owner.end.314, %context.value.316
  %descriptor.offset.inside.318 = icmp ule i32 %local.check.offset.311, %local.check.owner.end.314
  %descriptor.extent.inside.320 = icmp ule i32 %local.check.extent.312, %stack.sub.319
  %descriptor.payload.inside.321 = icmp ule i32 %local.check.payload.313, %local.check.extent.312
  %descriptor.owner.offset.valid.322 = and i1 %descriptor.owner.inside.317, %descriptor.offset.inside.318
  %descriptor.range.inside.324 = and i1 %descriptor.owner.offset.valid.322, %descriptor.extent.inside.320
  %descriptor.range.valid.323 = and i1 %descriptor.range.inside.324, %descriptor.payload.inside.321
  br i1 %descriptor.range.valid.323, label %descriptor.valid.325, label %descriptor.invalid.326
descriptor.invalid.326:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.325:
  %descriptor.initialized.status.327 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.311, i32 %local.check.extent.312)
  %helper.ok.328 = icmp eq i32 %descriptor.initialized.status.327, 0
  br i1 %helper.ok.328, label %helper.continue.329, label %frame.failure.0
helper.continue.329:
  br label %local.descriptor.checked.310
local.descriptor.inactive.309:
  br label %local.descriptor.checked.310
local.descriptor.checked.310:
  %local.is.active.330 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.330, label %local.descriptor.active.331, label %local.descriptor.inactive.332
local.descriptor.active.331:
  %local.check.offset.334 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.335 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.336 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.337 = load i32, ptr %local.owner.end.12, align 4
  %context.field.338 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.339 = load i32, ptr %context.field.338, align 4
  %stack.sub.342 = sub i32 %local.check.owner.end.337, %local.check.offset.334
  %descriptor.owner.inside.340 = icmp ule i32 %local.check.owner.end.337, %context.value.339
  %descriptor.offset.inside.341 = icmp ule i32 %local.check.offset.334, %local.check.owner.end.337
  %descriptor.extent.inside.343 = icmp ule i32 %local.check.extent.335, %stack.sub.342
  %descriptor.payload.inside.344 = icmp ule i32 %local.check.payload.336, %local.check.extent.335
  %descriptor.owner.offset.valid.345 = and i1 %descriptor.owner.inside.340, %descriptor.offset.inside.341
  %descriptor.range.inside.347 = and i1 %descriptor.owner.offset.valid.345, %descriptor.extent.inside.343
  %descriptor.range.valid.346 = and i1 %descriptor.range.inside.347, %descriptor.payload.inside.344
  br i1 %descriptor.range.valid.346, label %descriptor.valid.348, label %descriptor.invalid.349
descriptor.invalid.349:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.348:
  %descriptor.initialized.status.350 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.334, i32 %local.check.extent.335)
  %helper.ok.351 = icmp eq i32 %descriptor.initialized.status.350, 0
  br i1 %helper.ok.351, label %helper.continue.352, label %frame.failure.0
helper.continue.352:
  br label %local.descriptor.checked.333
local.descriptor.inactive.332:
  br label %local.descriptor.checked.333
local.descriptor.checked.333:
  %step.status.353 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.354 = icmp eq i32 %step.status.353, 0
  br i1 %helper.ok.354, label %helper.continue.355, label %frame.failure.0
helper.continue.355:
  %local.resolved.offset.356 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.357 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.358 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.359 = load i32, ptr %local.owner.end.6, align 4
  %context.field.360 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.361 = load i32, ptr %context.field.360, align 4
  %stack.sub.364 = sub i32 %local.resolved.owner.end.359, %local.resolved.offset.356
  %descriptor.owner.inside.362 = icmp ule i32 %local.resolved.owner.end.359, %context.value.361
  %descriptor.offset.inside.363 = icmp ule i32 %local.resolved.offset.356, %local.resolved.owner.end.359
  %descriptor.extent.inside.365 = icmp ule i32 %local.resolved.extent.357, %stack.sub.364
  %descriptor.payload.inside.366 = icmp ule i32 %local.resolved.payload.358, %local.resolved.extent.357
  %descriptor.owner.offset.valid.367 = and i1 %descriptor.owner.inside.362, %descriptor.offset.inside.363
  %descriptor.range.inside.369 = and i1 %descriptor.owner.offset.valid.367, %descriptor.extent.inside.365
  %descriptor.range.valid.368 = and i1 %descriptor.range.inside.369, %descriptor.payload.inside.366
  %descriptor.type.valid.370 = icmp eq i32 8, 8
  %descriptor.valid.371 = and i1 %descriptor.range.valid.368, %descriptor.type.valid.370
  br i1 %descriptor.valid.371, label %descriptor.valid.372, label %descriptor.invalid.373
descriptor.invalid.373:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.372:
  %descriptor.initialized.status.374 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.356, i32 %local.resolved.extent.357)
  %helper.ok.375 = icmp eq i32 %descriptor.initialized.status.374, 0
  br i1 %helper.ok.375, label %helper.continue.376, label %frame.failure.0
helper.continue.376:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %local.resolved.offset.356, i32 20, i32 %local.resolved.payload.358, i32 %local.resolved.owner.end.359, i32 %local.resolved.extent.357)
  %context.field.377 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.378 = load i32, ptr %context.field.377, align 4
  %runtime.ok.379 = icmp eq i32 %context.value.378, 0
  br i1 %runtime.ok.379, label %runtime.continue.380, label %frame.failure.0
runtime.continue.380:
  %context.field.381 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.382 = load i32, ptr %context.field.381, align 4
  %stack.sub.385 = sub i32 %local.resolved.owner.end.359, %local.resolved.offset.356
  %descriptor.owner.inside.383 = icmp ule i32 %local.resolved.owner.end.359, %context.value.382
  %descriptor.offset.inside.384 = icmp ule i32 %local.resolved.offset.356, %local.resolved.owner.end.359
  %descriptor.extent.inside.386 = icmp ule i32 %local.resolved.extent.357, %stack.sub.385
  %descriptor.payload.inside.387 = icmp ule i32 %local.resolved.payload.358, %local.resolved.extent.357
  %descriptor.owner.offset.valid.388 = and i1 %descriptor.owner.inside.383, %descriptor.offset.inside.384
  %descriptor.range.inside.390 = and i1 %descriptor.owner.offset.valid.388, %descriptor.extent.inside.386
  %descriptor.range.valid.389 = and i1 %descriptor.range.inside.390, %descriptor.payload.inside.387
  %descriptor.type.valid.391 = icmp eq i32 8, 8
  %descriptor.valid.392 = and i1 %descriptor.range.valid.389, %descriptor.type.valid.391
  br i1 %descriptor.valid.392, label %descriptor.valid.393, label %descriptor.invalid.394
descriptor.invalid.394:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.393:
  %descriptor.initialized.status.395 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.356, i32 %local.resolved.extent.357)
  %helper.ok.396 = icmp eq i32 %descriptor.initialized.status.395, 0
  br i1 %helper.ok.396, label %helper.continue.397, label %frame.failure.0
helper.continue.397:
  %local.is.active.398 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.398, label %local.descriptor.active.399, label %local.descriptor.inactive.400
local.descriptor.active.399:
  %local.check.offset.402 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.403 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.404 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.405 = load i32, ptr %local.owner.end.6, align 4
  %context.field.406 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.407 = load i32, ptr %context.field.406, align 4
  %stack.sub.410 = sub i32 %local.check.owner.end.405, %local.check.offset.402
  %descriptor.owner.inside.408 = icmp ule i32 %local.check.owner.end.405, %context.value.407
  %descriptor.offset.inside.409 = icmp ule i32 %local.check.offset.402, %local.check.owner.end.405
  %descriptor.extent.inside.411 = icmp ule i32 %local.check.extent.403, %stack.sub.410
  %descriptor.payload.inside.412 = icmp ule i32 %local.check.payload.404, %local.check.extent.403
  %descriptor.owner.offset.valid.413 = and i1 %descriptor.owner.inside.408, %descriptor.offset.inside.409
  %descriptor.range.inside.415 = and i1 %descriptor.owner.offset.valid.413, %descriptor.extent.inside.411
  %descriptor.range.valid.414 = and i1 %descriptor.range.inside.415, %descriptor.payload.inside.412
  br i1 %descriptor.range.valid.414, label %descriptor.valid.416, label %descriptor.invalid.417
descriptor.invalid.417:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.416:
  %descriptor.initialized.status.418 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.402, i32 %local.check.extent.403)
  %helper.ok.419 = icmp eq i32 %descriptor.initialized.status.418, 0
  br i1 %helper.ok.419, label %helper.continue.420, label %frame.failure.0
helper.continue.420:
  br label %local.descriptor.checked.401
local.descriptor.inactive.400:
  br label %local.descriptor.checked.401
local.descriptor.checked.401:
  %local.is.active.421 = load i1, ptr %local.active.8, align 1
  br i1 %local.is.active.421, label %local.descriptor.active.422, label %local.descriptor.inactive.423
local.descriptor.active.422:
  %local.check.offset.425 = load i32, ptr %local.offset.9, align 4
  %local.check.extent.426 = load i32, ptr %local.extent.10, align 4
  %local.check.payload.427 = load i32, ptr %local.payload.11, align 4
  %local.check.owner.end.428 = load i32, ptr %local.owner.end.12, align 4
  %context.field.429 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.430 = load i32, ptr %context.field.429, align 4
  %stack.sub.433 = sub i32 %local.check.owner.end.428, %local.check.offset.425
  %descriptor.owner.inside.431 = icmp ule i32 %local.check.owner.end.428, %context.value.430
  %descriptor.offset.inside.432 = icmp ule i32 %local.check.offset.425, %local.check.owner.end.428
  %descriptor.extent.inside.434 = icmp ule i32 %local.check.extent.426, %stack.sub.433
  %descriptor.payload.inside.435 = icmp ule i32 %local.check.payload.427, %local.check.extent.426
  %descriptor.owner.offset.valid.436 = and i1 %descriptor.owner.inside.431, %descriptor.offset.inside.432
  %descriptor.range.inside.438 = and i1 %descriptor.owner.offset.valid.436, %descriptor.extent.inside.434
  %descriptor.range.valid.437 = and i1 %descriptor.range.inside.438, %descriptor.payload.inside.435
  br i1 %descriptor.range.valid.437, label %descriptor.valid.439, label %descriptor.invalid.440
descriptor.invalid.440:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.439:
  %descriptor.initialized.status.441 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.425, i32 %local.check.extent.426)
  %helper.ok.442 = icmp eq i32 %descriptor.initialized.status.441, 0
  br i1 %helper.ok.442, label %helper.continue.443, label %frame.failure.0
helper.continue.443:
  br label %local.descriptor.checked.424
local.descriptor.inactive.423:
  br label %local.descriptor.checked.424
local.descriptor.checked.424:
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %context.field.444 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.445 = load i32, ptr %context.field.444, align 4
  %stack.sub.446 = sub i32 %context.value.445, %context.value.15
  call void @al_owning_record_layout(ptr %ctx, i32 18, i32 0, i32 %context.value.15, i32 %stack.sub.446, i32 0, i32 0, i32 0)
  %context.field.447 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.448 = load i32, ptr %context.field.447, align 4
  %runtime.ok.449 = icmp eq i32 %context.value.448, 0
  br i1 %runtime.ok.449, label %runtime.continue.450, label %frame.failure.0
runtime.continue.450:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.15, i32 0, i32 0, i32 0)
  %context.field.451 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.452 = load i32, ptr %context.field.451, align 4
  %runtime.ok.453 = icmp eq i32 %context.value.452, 0
  br i1 %runtime.ok.453, label %runtime.continue.454, label %frame.failure.0
runtime.continue.454:
  %descriptor.element.455 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.456 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.455, i32 0, i32 0
  store i32 8, ptr %descriptor.field.456, align 4
  %descriptor.field.457 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.455, i32 0, i32 1
  store i32 %local.resolved.offset.356, ptr %descriptor.field.457, align 4
  %descriptor.field.458 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.455, i32 0, i32 2
  store i32 %local.resolved.extent.357, ptr %descriptor.field.458, align 4
  %descriptor.field.459 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.455, i32 0, i32 3
  store i32 %local.resolved.payload.358, ptr %descriptor.field.459, align 4
  %descriptor.field.460 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.455, i32 0, i32 4
  store i32 %local.resolved.owner.end.359, ptr %descriptor.field.460, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %local.resolved.offset.356, i32 20, i32 %local.resolved.payload.358, i32 %local.resolved.owner.end.359, i32 %local.resolved.extent.357)
  %context.field.461 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.462 = load i32, ptr %context.field.461, align 4
  %runtime.ok.463 = icmp eq i32 %context.value.462, 0
  br i1 %runtime.ok.463, label %runtime.continue.464, label %frame.failure.0
runtime.continue.464:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.15, i32 0, i32 0, i32 0)
  %context.field.465 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.466 = load i32, ptr %context.field.465, align 4
  %context.field.467 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.468 = load i32, ptr %context.field.467, align 4
  %context.field.469 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.470 = load i32, ptr %context.field.469, align 4
  %stack.offset.471 = add i32 %context.value.17, %context.value.19
  %stack.offset.472 = add i32 %context.value.466, %context.value.468
  %stack.sub.473 = sub i32 %stack.offset.471, %stack.offset.472
  %stack.sub.474 = sub i32 %context.value.19, %context.value.468
  %stack.sub.475 = sub i32 %context.value.470, %context.value.21
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.473, i32 %stack.sub.474)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.475)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 2
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 2, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %entry.input.descriptors.10 = alloca [2 x %AlOwningDescriptor], align 4
  %input.extent.pointer.11 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.12 = load i32, ptr %input.extent.pointer.11, align 4
  %host.pointer.13 = getelementptr inbounds i8, ptr %input, i32 0
  %input.payload.pointer.14 = alloca i32, align 4
  %input.measured.extent.pointer.15 = alloca i32, align 4
  %input.measure.status.16 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 1, ptr %host.pointer.13, i32 %input.host.extent.12, i32 0, i32 6, ptr %input.payload.pointer.14, ptr %input.measured.extent.pointer.15)
  %helper.ok.17 = icmp eq i32 %input.measure.status.16, 0
  br i1 %helper.ok.17, label %helper.continue.18, label %entry.failure.0
helper.continue.18:
  %input.measured.payload.19 = load i32, ptr %input.payload.pointer.14, align 4
  %input.measured.extent.20 = load i32, ptr %input.measured.extent.pointer.15, align 4
  %input.extent.exact.21 = icmp eq i32 %input.measured.extent.20, %input.host.extent.12
  br i1 %input.extent.exact.21, label %input.extent.exact.22, label %input.extent.invalid.23
input.extent.invalid.23:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 6, i32 %input.measured.extent.20, i32 %input.host.extent.12)
  br label %entry.failure.0
input.extent.exact.22:
  %stack.offset.24 = add i32 0, %input.host.extent.12
  %input.extent.pointer.25 = getelementptr inbounds i32, ptr %input.extents, i32 1
  %input.host.extent.26 = load i32, ptr %input.extent.pointer.25, align 4
  %host.pointer.27 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.24
  %input.payload.pointer.28 = alloca i32, align 4
  %input.measured.extent.pointer.29 = alloca i32, align 4
  %input.measure.status.30 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 1, ptr %host.pointer.27, i32 %input.host.extent.26, i32 0, i32 7, ptr %input.payload.pointer.28, ptr %input.measured.extent.pointer.29)
  %helper.ok.31 = icmp eq i32 %input.measure.status.30, 0
  br i1 %helper.ok.31, label %helper.continue.32, label %entry.failure.0
helper.continue.32:
  %input.measured.payload.33 = load i32, ptr %input.payload.pointer.28, align 4
  %input.measured.extent.34 = load i32, ptr %input.measured.extent.pointer.29, align 4
  %input.extent.exact.35 = icmp eq i32 %input.measured.extent.34, %input.host.extent.26
  br i1 %input.extent.exact.35, label %input.extent.exact.36, label %input.extent.invalid.37
input.extent.invalid.37:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 7, i32 %input.measured.extent.34, i32 %input.host.extent.26)
  br label %entry.failure.0
input.extent.exact.36:
  %stack.offset.38 = add i32 %stack.offset.24, %input.host.extent.26
  %input.total.exact.39 = icmp eq i32 %stack.offset.38, %input.bytes
  br i1 %input.total.exact.39, label %input.valid.40, label %input.invalid.41
input.invalid.41:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.38, i32 %input.bytes)
  br label %entry.failure.0
input.valid.40:
  %reserve.status.42 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.38, i32 8)
  %reserve.ok.43 = icmp eq i32 %reserve.status.42, 0
  br i1 %reserve.ok.43, label %reserve.continue.44, label %entry.failure.0
reserve.continue.44:
  %host.pointer.45 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.46 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.45, i32 %input.host.extent.12, i32 0, i32 %input.measured.payload.19, i32 %input.host.extent.12, i32 8, i32 9)
  %helper.ok.47 = icmp eq i32 %input.copy.status.46, 0
  br i1 %helper.ok.47, label %helper.continue.48, label %entry.failure.0
helper.continue.48:
  %stack.offset.49 = add i32 0, %input.host.extent.12
  %descriptor.element.50 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.10, i32 0
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 0
  store i32 8, ptr %descriptor.field.51, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 1
  store i32 0, ptr %descriptor.field.52, align 4
  %descriptor.field.53 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 2
  store i32 %input.host.extent.12, ptr %descriptor.field.53, align 4
  %descriptor.field.54 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 3
  store i32 %input.measured.payload.19, ptr %descriptor.field.54, align 4
  %descriptor.field.55 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.50, i32 0, i32 4
  store i32 %stack.offset.49, ptr %descriptor.field.55, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 0, i32 20, i32 %input.measured.payload.19, i32 %stack.offset.49, i32 %input.host.extent.12)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %entry.failure.0
runtime.continue.59:
  %host.pointer.60 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.24
  %input.copy.status.61 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.24, ptr %host.pointer.60, i32 %input.host.extent.26, i32 0, i32 %input.measured.payload.33, i32 %input.host.extent.26, i32 8, i32 10)
  %helper.ok.62 = icmp eq i32 %input.copy.status.61, 0
  br i1 %helper.ok.62, label %helper.continue.63, label %entry.failure.0
helper.continue.63:
  %stack.offset.64 = add i32 %stack.offset.24, %input.host.extent.26
  %descriptor.element.65 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.10, i32 1
  %descriptor.field.66 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.65, i32 0, i32 0
  store i32 8, ptr %descriptor.field.66, align 4
  %descriptor.field.67 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.65, i32 0, i32 1
  store i32 %stack.offset.24, ptr %descriptor.field.67, align 4
  %descriptor.field.68 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.65, i32 0, i32 2
  store i32 %input.host.extent.26, ptr %descriptor.field.68, align 4
  %descriptor.field.69 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.65, i32 0, i32 3
  store i32 %input.measured.payload.33, ptr %descriptor.field.69, align 4
  %descriptor.field.70 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.65, i32 0, i32 4
  store i32 %stack.offset.64, ptr %descriptor.field.70, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 8, i32 %stack.offset.24, i32 20, i32 %input.measured.payload.33, i32 %stack.offset.64, i32 %input.host.extent.26)
  %context.field.71 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.72 = load i32, ptr %context.field.71, align 4
  %runtime.ok.73 = icmp eq i32 %context.value.72, 0
  br i1 %runtime.ok.73, label %runtime.continue.74, label %entry.failure.0
runtime.continue.74:
  %entry.output.descriptors.75 = alloca [1 x %AlOwningDescriptor], align 4
  %entry.body.status.76 = call i32 @agentlang_entry_frame(ptr %ctx, ptr %entry.input.descriptors.10, ptr %entry.output.descriptors.75, i32 11)
  %entry.body.ok.77 = icmp eq i32 %entry.body.status.76, 0
  br i1 %entry.body.ok.77, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.78 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.75, i32 0
  %descriptor.field.79 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.78, i32 0, i32 0
  %descriptor.value.80 = load i32, ptr %descriptor.field.79, align 4
  %descriptor.field.81 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.78, i32 0, i32 1
  %descriptor.value.82 = load i32, ptr %descriptor.field.81, align 4
  %descriptor.field.83 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.78, i32 0, i32 2
  %descriptor.value.84 = load i32, ptr %descriptor.field.83, align 4
  %descriptor.field.85 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.78, i32 0, i32 3
  %descriptor.value.86 = load i32, ptr %descriptor.field.85, align 4
  %descriptor.field.87 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.78, i32 0, i32 4
  %descriptor.value.88 = load i32, ptr %descriptor.field.87, align 4
  %entry.output.type.valid.89 = icmp eq i32 %descriptor.value.80, 8
  br i1 %entry.output.type.valid.89, label %entry.output.type.ok.90, label %entry.output.type.invalid.91
entry.output.type.invalid.91:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.90:
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %stack.sub.96 = sub i32 %descriptor.value.88, %descriptor.value.82
  %descriptor.owner.inside.94 = icmp ule i32 %descriptor.value.88, %context.value.93
  %descriptor.offset.inside.95 = icmp ule i32 %descriptor.value.82, %descriptor.value.88
  %descriptor.extent.inside.97 = icmp ule i32 %descriptor.value.84, %stack.sub.96
  %descriptor.payload.inside.98 = icmp ule i32 %descriptor.value.86, %descriptor.value.84
  %descriptor.owner.offset.valid.99 = and i1 %descriptor.owner.inside.94, %descriptor.offset.inside.95
  %descriptor.range.inside.101 = and i1 %descriptor.owner.offset.valid.99, %descriptor.extent.inside.97
  %descriptor.range.valid.100 = and i1 %descriptor.range.inside.101, %descriptor.payload.inside.98
  %descriptor.type.valid.102 = icmp eq i32 8, 8
  %descriptor.valid.103 = and i1 %descriptor.range.valid.100, %descriptor.type.valid.102
  br i1 %descriptor.valid.103, label %descriptor.valid.104, label %descriptor.invalid.105
descriptor.invalid.105:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.104:
  %descriptor.initialized.status.106 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.82, i32 %descriptor.value.84)
  %helper.ok.107 = icmp eq i32 %descriptor.initialized.status.106, 0
  br i1 %helper.ok.107, label %helper.continue.108, label %entry.failure.0
helper.continue.108:
  %entry.output.size.i64.109 = zext i32 %descriptor.value.84 to i64
  %entry.output.total.i64.110 = add i64 0, %entry.output.size.i64.109
  %entry.retained.capacity.i64.111 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.112 = icmp ule i64 %entry.output.total.i64.110, 4294967295
  %entry.retained.required.truncated.113 = trunc i64 %entry.output.total.i64.110 to i32
  %entry.retained.required.114 = select i1 %entry.retained.required.fits.u32.112, i32 %entry.retained.required.truncated.113, i32 4294967295
  %entry.retained.capacity.ok.115 = icmp ule i64 %entry.output.total.i64.110, %entry.retained.capacity.i64.111
  br i1 %entry.retained.capacity.ok.115, label %entry.retained.capacity.ready.116, label %entry.retained.capacity.failure.117
entry.retained.capacity.failure.117:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.114, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.116:
  %host.pointer.118 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.119 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.118, i32 %stack.sub.119, i32 %descriptor.value.82, i32 %descriptor.value.84, i32 8)
  %context.field.120 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.121 = load i32, ptr %context.field.120, align 4
  %runtime.ok.122 = icmp eq i32 %context.value.121, 0
  br i1 %runtime.ok.122, label %runtime.continue.123, label %entry.failure.0
runtime.continue.123:
  %stack.offset.124 = add i32 0, %descriptor.value.84
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.125 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.126 = load i32, ptr %context.field.125, align 4
  %context.field.127 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.128 = load i32, ptr %context.field.127, align 4
  %stack.sub.129 = sub i32 0, %context.value.126
  %stack.sub.130 = sub i32 0, %context.value.128
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.129, i32 %stack.sub.130)
  %context.field.131 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.132 = load i32, ptr %context.field.131, align 4
  %runtime.ok.133 = icmp eq i32 %context.value.132, 0
  br i1 %runtime.ok.133, label %runtime.continue.134, label %entry.failure.0
runtime.continue.134:
  br label %entry.return.status
entry.failure.0:
  %context.field.135 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.136 = load i32, ptr %context.field.135, align 4
  %context.field.137 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.138 = load i32, ptr %context.field.137, align 4
  %context.field.139 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.140 = load i32, ptr %context.field.139, align 4
  %stack.offset.141 = add i32 %context.value.136, %context.value.138
  %stack.sub.142 = sub i32 0, %stack.offset.141
  %stack.sub.143 = sub i32 0, %context.value.138
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.142, i32 %stack.sub.143)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.140)
  br label %entry.return.status
entry.return.status:
  %context.field.144 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.145 = load i32, ptr %context.field.144, align 4
  ret i32 %context.value.145
}


target triple = "x86_64-pc-windows-msvc"
%NativeExecutionContext = type { i32, i32, i32, i32, i64, i64, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, i32, i32 }
%NativeExecutionContextAlignmentProbe = type { i8, %NativeExecutionContext }
%NativeTypeDescriptor = type { i32, i32, ptr }
%NativeProgramDescriptor = type { ptr, i32, i32 }
declare i32 @al_runtime_validate_request(ptr, ptr, i32, i32, ptr, i32)
declare i32 @al_runtime_import_state(ptr, ptr, ptr, i32)
declare i32 @al_runtime_make_record(ptr, ptr, i32, ptr, i32, ptr)
declare i32 @al_runtime_get_field(ptr, ptr, i32, i64, i32, ptr)
declare i32 @al_runtime_equal(ptr, ptr, i32, i64, i64, ptr)
declare i32 @al_runtime_promote(ptr, ptr, ptr, ptr, i32, ptr, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

@agentlang_fields_4 = private constant [2 x i32] [i32 5, i32 0]
@agentlang_fields_5 = private constant [1 x i32] [i32 0]
@agentlang_fields_6 = private constant [2 x i32] [i32 0, i32 4]
@agentlang_type_descriptors = private constant [7 x %NativeTypeDescriptor] [%NativeTypeDescriptor { i32 1, i32 0, ptr null }, %NativeTypeDescriptor { i32 2, i32 0, ptr null }, %NativeTypeDescriptor { i32 3, i32 0, ptr null }, %NativeTypeDescriptor { i32 4, i32 0, ptr null }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_4, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_5, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_6, i32 0, i32 0) }]
@agentlang_program = private constant %NativeProgramDescriptor { ptr getelementptr inbounds ([7 x %NativeTypeDescriptor], ptr @agentlang_type_descriptors, i32 0, i32 0), i32 7, i32 0 }
@agentlang_root_type_ids = private constant [1 x i32] [i32 4]
@agentlang_input_type_ids = private constant [1 x i32] [i32 0]

define internal void @agentlang_body(ptr %ctx, ptr %outputs, ptr %status, i32 %depth, i64 %arg0) {
entry:
  %ctx.field.0 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1 = load i32, ptr %ctx.field.0, align 4
  %steps.next.2 = add i32 %steps.current.1, 1
  store i32 %steps.next.2, ptr %ctx.field.0, align 4
  %steps.over.3 = icmp ugt i32 %steps.next.2, 10000
  br i1 %steps.over.3, label %failure.4, label %continue.5
failure.4:
  %ctx.field.6 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 0, ptr %ctx.field.6, align 4
  %status.diagnostic.7 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7, align 4
  ret void
continue.5:
  %depth.exceeded.8 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.8, label %failure.9, label %continue.10
failure.9:
  %ctx.field.11 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1, ptr %ctx.field.11, align 4
  %status.diagnostic.12 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.12, align 4
  ret void
continue.10:
  %call.depth.13 = add i32 %depth, 1
  call void @agentlang_fn_78a9fe4aae4865562a7601feaa8db7bce76e7f86ea462967747659512c63f1bd_r1(ptr %ctx, ptr %outputs, ptr %status, i32 %call.depth.13, i64 %arg0)
  %callee.status.14 = load i32, ptr %status, align 4
  %callee.succeeded.15 = icmp eq i32 %callee.status.14, 0
  br i1 %callee.succeeded.15, label %callee.continue.17, label %callee.failure.16
callee.failure.16:
  ret void
callee.continue.17:
  %call.output.ptr.18 = getelementptr inbounds i64, ptr %outputs, i64 0
  %call.output.19 = load i64, ptr %call.output.ptr.18, align 8
  %output.ptr.20 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %call.output.19, ptr %output.ptr.20, align 8
  ret void
}

define internal void @agentlang_fn_595af45502edb375d2c34ed58568618551d754bf531d9216b84c417c2cf7efb0_r1(ptr %ctx, ptr %outputs, ptr %status, i32 %depth, i64 %arg0, i64 %arg1) {
entry:
  %ctx.field.0 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1 = load i32, ptr %ctx.field.0, align 4
  %steps.next.2 = add i32 %steps.current.1, 1
  store i32 %steps.next.2, ptr %ctx.field.0, align 4
  %steps.over.3 = icmp ugt i32 %steps.next.2, 10000
  br i1 %steps.over.3, label %failure.4, label %continue.5
failure.4:
  %ctx.field.6 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 2, ptr %ctx.field.6, align 4
  %status.diagnostic.7 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7, align 4
  ret void
continue.5:
  %ctx.field.8 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9 = load i32, ptr %ctx.field.8, align 4
  %steps.next.10 = add i32 %steps.current.9, 1
  store i32 %steps.next.10, ptr %ctx.field.8, align 4
  %steps.over.11 = icmp ugt i32 %steps.next.10, 10000
  br i1 %steps.over.11, label %failure.12, label %continue.13
failure.12:
  %ctx.field.14 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 3, ptr %ctx.field.14, align 4
  %status.diagnostic.15 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.15, align 4
  ret void
continue.13:
  %ctx.field.16 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.17 = load i32, ptr %ctx.field.16, align 4
  %steps.next.18 = add i32 %steps.current.17, 1
  store i32 %steps.next.18, ptr %ctx.field.16, align 4
  %steps.over.19 = icmp ugt i32 %steps.next.18, 10000
  br i1 %steps.over.19, label %failure.20, label %continue.21
failure.20:
  %ctx.field.22 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 4, ptr %ctx.field.22, align 4
  %status.diagnostic.23 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.23, align 4
  ret void
continue.21:
  %ctx.field.24 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.25 = load i32, ptr %ctx.field.24, align 4
  %steps.next.26 = add i32 %steps.current.25, 1
  store i32 %steps.next.26, ptr %ctx.field.24, align 4
  %steps.over.27 = icmp ugt i32 %steps.next.26, 10000
  br i1 %steps.over.27, label %failure.28, label %continue.29
failure.28:
  %ctx.field.30 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 5, ptr %ctx.field.30, align 4
  %status.diagnostic.31 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.31, align 4
  ret void
continue.29:
  %ctx.field.32 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.33 = load i32, ptr %ctx.field.32, align 4
  %steps.next.34 = add i32 %steps.current.33, 1
  store i32 %steps.next.34, ptr %ctx.field.32, align 4
  %steps.over.35 = icmp ugt i32 %steps.next.34, 10000
  br i1 %steps.over.35, label %failure.36, label %continue.37
failure.36:
  %ctx.field.38 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 6, ptr %ctx.field.38, align 4
  %status.diagnostic.39 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.39, align 4
  ret void
continue.37:
  %ctx.field.40 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.41 = load i32, ptr %ctx.field.40, align 4
  %steps.next.42 = add i32 %steps.current.41, 1
  store i32 %steps.next.42, ptr %ctx.field.40, align 4
  %steps.over.43 = icmp ugt i32 %steps.next.42, 10000
  br i1 %steps.over.43, label %failure.44, label %continue.45
failure.44:
  %ctx.field.46 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 7, ptr %ctx.field.46, align 4
  %status.diagnostic.47 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.47, align 4
  ret void
continue.45:
  %ctx.field.48 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.49 = load i32, ptr %ctx.field.48, align 4
  %steps.next.50 = add i32 %steps.current.49, 1
  store i32 %steps.next.50, ptr %ctx.field.48, align 4
  %steps.over.51 = icmp ugt i32 %steps.next.50, 10000
  br i1 %steps.over.51, label %failure.52, label %continue.53
failure.52:
  %ctx.field.54 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 8, ptr %ctx.field.54, align 4
  %status.diagnostic.55 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.55, align 4
  ret void
continue.53:
  %depth.exceeded.56 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.56, label %failure.57, label %continue.58
failure.57:
  %ctx.field.59 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 9, ptr %ctx.field.59, align 4
  %status.diagnostic.60 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.60, align 4
  ret void
continue.58:
  %workspace.slot.61 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %arg0, ptr %workspace.slot.61, align 8
  %workspace.slot.62 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.63 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 5, ptr %outputs, i32 1, ptr %workspace.slot.62)
  switch i32 %record.make.status.63, label %runtime.invalid.result.69 [ i32 0, label %runtime.success.64 i32 1, label %runtime.invalid.request.65 i32 2, label %runtime.invalid.reference.66 i32 3, label %runtime.scratch.capacity.67 i32 4, label %runtime.retained.capacity.68 ]
runtime.invalid.request.65:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.66:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.67:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.68:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.69:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.64:
  %record.make.handle.70 = load i64, ptr %workspace.slot.62, align 8
  %ctx.field.71 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.72 = load i32, ptr %ctx.field.71, align 4
  %steps.next.73 = add i32 %steps.current.72, 1
  store i32 %steps.next.73, ptr %ctx.field.71, align 4
  %steps.over.74 = icmp ugt i32 %steps.next.73, 10000
  br i1 %steps.over.74, label %failure.75, label %continue.76
failure.75:
  %ctx.field.77 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 10, ptr %ctx.field.77, align 4
  %status.diagnostic.78 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.78, align 4
  ret void
continue.76:
  %ctx.field.79 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.80 = load i32, ptr %ctx.field.79, align 4
  %steps.next.81 = add i32 %steps.current.80, 1
  store i32 %steps.next.81, ptr %ctx.field.79, align 4
  %steps.over.82 = icmp ugt i32 %steps.next.81, 10000
  br i1 %steps.over.82, label %failure.83, label %continue.84
failure.83:
  %ctx.field.85 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 11, ptr %ctx.field.85, align 4
  %status.diagnostic.86 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.86, align 4
  ret void
continue.84:
  %ctx.field.87 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.88 = load i32, ptr %ctx.field.87, align 4
  %steps.next.89 = add i32 %steps.current.88, 1
  store i32 %steps.next.89, ptr %ctx.field.87, align 4
  %steps.over.90 = icmp ugt i32 %steps.next.89, 10000
  br i1 %steps.over.90, label %failure.91, label %continue.92
failure.91:
  %ctx.field.93 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 12, ptr %ctx.field.93, align 4
  %status.diagnostic.94 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.94, align 4
  ret void
continue.92:
  %ctx.field.95 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.96 = load i32, ptr %ctx.field.95, align 4
  %steps.next.97 = add i32 %steps.current.96, 1
  store i32 %steps.next.97, ptr %ctx.field.95, align 4
  %steps.over.98 = icmp ugt i32 %steps.next.97, 10000
  br i1 %steps.over.98, label %failure.99, label %continue.100
failure.99:
  %ctx.field.101 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 13, ptr %ctx.field.101, align 4
  %status.diagnostic.102 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.102, align 4
  ret void
continue.100:
  %ctx.field.103 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.104 = load i32, ptr %ctx.field.103, align 4
  %steps.next.105 = add i32 %steps.current.104, 1
  store i32 %steps.next.105, ptr %ctx.field.103, align 4
  %steps.over.106 = icmp ugt i32 %steps.next.105, 10000
  br i1 %steps.over.106, label %failure.107, label %continue.108
failure.107:
  %ctx.field.109 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 14, ptr %ctx.field.109, align 4
  %status.diagnostic.110 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.110, align 4
  ret void
continue.108:
  %ctx.field.111 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.112 = load i32, ptr %ctx.field.111, align 4
  %steps.next.113 = add i32 %steps.current.112, 1
  store i32 %steps.next.113, ptr %ctx.field.111, align 4
  %steps.over.114 = icmp ugt i32 %steps.next.113, 10000
  br i1 %steps.over.114, label %failure.115, label %continue.116
failure.115:
  %ctx.field.117 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 15, ptr %ctx.field.117, align 4
  %status.diagnostic.118 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.118, align 4
  ret void
continue.116:
  %ctx.field.119 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.120 = load i32, ptr %ctx.field.119, align 4
  %steps.next.121 = add i32 %steps.current.120, 1
  store i32 %steps.next.121, ptr %ctx.field.119, align 4
  %steps.over.122 = icmp ugt i32 %steps.next.121, 10000
  br i1 %steps.over.122, label %failure.123, label %continue.124
failure.123:
  %ctx.field.125 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 16, ptr %ctx.field.125, align 4
  %status.diagnostic.126 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.126, align 4
  ret void
continue.124:
  %ctx.field.127 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.128 = load i32, ptr %ctx.field.127, align 4
  %steps.next.129 = add i32 %steps.current.128, 1
  store i32 %steps.next.129, ptr %ctx.field.127, align 4
  %steps.over.130 = icmp ugt i32 %steps.next.129, 10000
  br i1 %steps.over.130, label %failure.131, label %continue.132
failure.131:
  %ctx.field.133 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 17, ptr %ctx.field.133, align 4
  %status.diagnostic.134 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.134, align 4
  ret void
continue.132:
  %ctx.field.135 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.136 = load i32, ptr %ctx.field.135, align 4
  %steps.next.137 = add i32 %steps.current.136, 1
  store i32 %steps.next.137, ptr %ctx.field.135, align 4
  %steps.over.138 = icmp ugt i32 %steps.next.137, 10000
  br i1 %steps.over.138, label %failure.139, label %continue.140
failure.139:
  %ctx.field.141 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 18, ptr %ctx.field.141, align 4
  %status.diagnostic.142 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.142, align 4
  ret void
continue.140:
  %depth.exceeded.143 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.143, label %failure.144, label %continue.145
failure.144:
  %ctx.field.146 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 19, ptr %ctx.field.146, align 4
  %status.diagnostic.147 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.147, align 4
  ret void
continue.145:
  %workspace.slot.148 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.70, ptr %workspace.slot.148, align 8
  %workspace.slot.149 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %arg1, ptr %workspace.slot.149, align 8
  %workspace.slot.150 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.151 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 4, ptr %outputs, i32 2, ptr %workspace.slot.150)
  switch i32 %record.make.status.151, label %runtime.invalid.result.157 [ i32 0, label %runtime.success.152 i32 1, label %runtime.invalid.request.153 i32 2, label %runtime.invalid.reference.154 i32 3, label %runtime.scratch.capacity.155 i32 4, label %runtime.retained.capacity.156 ]
runtime.invalid.request.153:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.154:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.155:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.156:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.157:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.152:
  %record.make.handle.158 = load i64, ptr %workspace.slot.150, align 8
  %output.ptr.159 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.158, ptr %output.ptr.159, align 8
  ret void
}

define internal void @agentlang_fn_78a9fe4aae4865562a7601feaa8db7bce76e7f86ea462967747659512c63f1bd_r1(ptr %ctx, ptr %outputs, ptr %status, i32 %depth, i64 %arg0) {
entry:
  %ctx.field.0 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1 = load i32, ptr %ctx.field.0, align 4
  %steps.next.2 = add i32 %steps.current.1, 1
  store i32 %steps.next.2, ptr %ctx.field.0, align 4
  %steps.over.3 = icmp ugt i32 %steps.next.2, 10000
  br i1 %steps.over.3, label %failure.4, label %continue.5
failure.4:
  %ctx.field.6 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 20, ptr %ctx.field.6, align 4
  %status.diagnostic.7 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7, align 4
  ret void
continue.5:
  %ctx.field.8 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9 = load i32, ptr %ctx.field.8, align 4
  %steps.next.10 = add i32 %steps.current.9, 1
  store i32 %steps.next.10, ptr %ctx.field.8, align 4
  %steps.over.11 = icmp ugt i32 %steps.next.10, 10000
  br i1 %steps.over.11, label %failure.12, label %continue.13
failure.12:
  %ctx.field.14 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 21, ptr %ctx.field.14, align 4
  %status.diagnostic.15 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.15, align 4
  ret void
continue.13:
  %ctx.field.16 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.17 = load i32, ptr %ctx.field.16, align 4
  %steps.next.18 = add i32 %steps.current.17, 1
  store i32 %steps.next.18, ptr %ctx.field.16, align 4
  %steps.over.19 = icmp ugt i32 %steps.next.18, 10000
  br i1 %steps.over.19, label %failure.20, label %continue.21
failure.20:
  %ctx.field.22 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 22, ptr %ctx.field.22, align 4
  %status.diagnostic.23 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.23, align 4
  ret void
continue.21:
  %ctx.field.24 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.25 = load i32, ptr %ctx.field.24, align 4
  %steps.next.26 = add i32 %steps.current.25, 1
  store i32 %steps.next.26, ptr %ctx.field.24, align 4
  %steps.over.27 = icmp ugt i32 %steps.next.26, 10000
  br i1 %steps.over.27, label %failure.28, label %continue.29
failure.28:
  %ctx.field.30 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 23, ptr %ctx.field.30, align 4
  %status.diagnostic.31 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.31, align 4
  ret void
continue.29:
  %depth.exceeded.32 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.32, label %failure.33, label %continue.34
failure.33:
  %ctx.field.35 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 24, ptr %ctx.field.35, align 4
  %status.diagnostic.36 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.36, align 4
  ret void
continue.34:
  %call.depth.37 = add i32 %depth, 1
  call void @agentlang_fn_595af45502edb375d2c34ed58568618551d754bf531d9216b84c417c2cf7efb0_r1(ptr %ctx, ptr %outputs, ptr %status, i32 %call.depth.37, i64 %arg0, i64 700)
  %callee.status.38 = load i32, ptr %status, align 4
  %callee.succeeded.39 = icmp eq i32 %callee.status.38, 0
  br i1 %callee.succeeded.39, label %callee.continue.41, label %callee.failure.40
callee.failure.40:
  ret void
callee.continue.41:
  %call.output.ptr.42 = getelementptr inbounds i64, ptr %outputs, i64 0
  %call.output.43 = load i64, ptr %call.output.ptr.42, align 8
  %ctx.field.44 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.45 = load i32, ptr %ctx.field.44, align 4
  %steps.next.46 = add i32 %steps.current.45, 1
  store i32 %steps.next.46, ptr %ctx.field.44, align 4
  %steps.over.47 = icmp ugt i32 %steps.next.46, 10000
  br i1 %steps.over.47, label %failure.48, label %continue.49
failure.48:
  %ctx.field.50 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 25, ptr %ctx.field.50, align 4
  %status.diagnostic.51 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.51, align 4
  ret void
continue.49:
  %ctx.field.52 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.53 = load i32, ptr %ctx.field.52, align 4
  %steps.next.54 = add i32 %steps.current.53, 1
  store i32 %steps.next.54, ptr %ctx.field.52, align 4
  %steps.over.55 = icmp ugt i32 %steps.next.54, 10000
  br i1 %steps.over.55, label %failure.56, label %continue.57
failure.56:
  %ctx.field.58 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 26, ptr %ctx.field.58, align 4
  %status.diagnostic.59 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.59, align 4
  ret void
continue.57:
  %ctx.field.60 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.61 = load i32, ptr %ctx.field.60, align 4
  %steps.next.62 = add i32 %steps.current.61, 1
  store i32 %steps.next.62, ptr %ctx.field.60, align 4
  %steps.over.63 = icmp ugt i32 %steps.next.62, 10000
  br i1 %steps.over.63, label %failure.64, label %continue.65
failure.64:
  %ctx.field.66 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 27, ptr %ctx.field.66, align 4
  %status.diagnostic.67 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.67, align 4
  ret void
continue.65:
  %ctx.field.68 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.69 = load i32, ptr %ctx.field.68, align 4
  %steps.next.70 = add i32 %steps.current.69, 1
  store i32 %steps.next.70, ptr %ctx.field.68, align 4
  %steps.over.71 = icmp ugt i32 %steps.next.70, 10000
  br i1 %steps.over.71, label %failure.72, label %continue.73
failure.72:
  %ctx.field.74 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 28, ptr %ctx.field.74, align 4
  %status.diagnostic.75 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.75, align 4
  ret void
continue.73:
  %depth.exceeded.76 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.76, label %failure.77, label %continue.78
failure.77:
  %ctx.field.79 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 29, ptr %ctx.field.79, align 4
  %status.diagnostic.80 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.80, align 4
  ret void
continue.78:
  %scalar.equals.81 = icmp eq i64 %arg0, 0
  %bool.slot.82 = zext i1 %scalar.equals.81 to i64
  %ctx.field.83 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.84 = load i32, ptr %ctx.field.83, align 4
  %steps.next.85 = add i32 %steps.current.84, 1
  store i32 %steps.next.85, ptr %ctx.field.83, align 4
  %steps.over.86 = icmp ugt i32 %steps.next.85, 10000
  br i1 %steps.over.86, label %failure.87, label %continue.88
failure.87:
  %ctx.field.89 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 30, ptr %ctx.field.89, align 4
  %status.diagnostic.90 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.90, align 4
  ret void
continue.88:
  %if.condition.91 = icmp ne i64 %bool.slot.82, 0
  br i1 %if.condition.91, label %if.then.92, label %if.else.93
if.then.92:
  %ctx.field.95 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.96 = load i32, ptr %ctx.field.95, align 4
  %steps.next.97 = add i32 %steps.current.96, 1
  store i32 %steps.next.97, ptr %ctx.field.95, align 4
  %steps.over.98 = icmp ugt i32 %steps.next.97, 10000
  br i1 %steps.over.98, label %failure.99, label %continue.100
failure.99:
  %ctx.field.101 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 31, ptr %ctx.field.101, align 4
  %status.diagnostic.102 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.102, align 4
  ret void
continue.100:
  %ctx.field.103 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.104 = load i32, ptr %ctx.field.103, align 4
  %steps.next.105 = add i32 %steps.current.104, 1
  store i32 %steps.next.105, ptr %ctx.field.103, align 4
  %steps.over.106 = icmp ugt i32 %steps.next.105, 10000
  br i1 %steps.over.106, label %failure.107, label %continue.108
failure.107:
  %ctx.field.109 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 32, ptr %ctx.field.109, align 4
  %status.diagnostic.110 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.110, align 4
  ret void
continue.108:
  %ctx.field.111 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.112 = load i32, ptr %ctx.field.111, align 4
  %steps.next.113 = add i32 %steps.current.112, 1
  store i32 %steps.next.113, ptr %ctx.field.111, align 4
  %steps.over.114 = icmp ugt i32 %steps.next.113, 10000
  br i1 %steps.over.114, label %failure.115, label %continue.116
failure.115:
  %ctx.field.117 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 33, ptr %ctx.field.117, align 4
  %status.diagnostic.118 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.118, align 4
  ret void
continue.116:
  %ctx.field.119 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.120 = load i32, ptr %ctx.field.119, align 4
  %steps.next.121 = add i32 %steps.current.120, 1
  store i32 %steps.next.121, ptr %ctx.field.119, align 4
  %steps.over.122 = icmp ugt i32 %steps.next.121, 10000
  br i1 %steps.over.122, label %failure.123, label %continue.124
failure.123:
  %ctx.field.125 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 34, ptr %ctx.field.125, align 4
  %status.diagnostic.126 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.126, align 4
  ret void
continue.124:
  %ctx.field.127 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.128 = load i32, ptr %ctx.field.127, align 4
  %steps.next.129 = add i32 %steps.current.128, 1
  store i32 %steps.next.129, ptr %ctx.field.127, align 4
  %steps.over.130 = icmp ugt i32 %steps.next.129, 10000
  br i1 %steps.over.130, label %failure.131, label %continue.132
failure.131:
  %ctx.field.133 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 35, ptr %ctx.field.133, align 4
  %status.diagnostic.134 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.134, align 4
  ret void
continue.132:
  %ctx.field.135 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.136 = load i32, ptr %ctx.field.135, align 4
  %steps.next.137 = add i32 %steps.current.136, 1
  store i32 %steps.next.137, ptr %ctx.field.135, align 4
  %steps.over.138 = icmp ugt i32 %steps.next.137, 10000
  br i1 %steps.over.138, label %failure.139, label %continue.140
failure.139:
  %ctx.field.141 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 36, ptr %ctx.field.141, align 4
  %status.diagnostic.142 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.142, align 4
  ret void
continue.140:
  %depth.exceeded.143 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.143, label %failure.144, label %continue.145
failure.144:
  %ctx.field.146 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 37, ptr %ctx.field.146, align 4
  %status.diagnostic.147 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.147, align 4
  ret void
continue.145:
  %workspace.slot.148 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %arg0, ptr %workspace.slot.148, align 8
  %workspace.slot.149 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.150 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 5, ptr %outputs, i32 1, ptr %workspace.slot.149)
  switch i32 %record.make.status.150, label %runtime.invalid.result.156 [ i32 0, label %runtime.success.151 i32 1, label %runtime.invalid.request.152 i32 2, label %runtime.invalid.reference.153 i32 3, label %runtime.scratch.capacity.154 i32 4, label %runtime.retained.capacity.155 ]
runtime.invalid.request.152:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.153:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.154:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.155:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.156:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.151:
  %record.make.handle.157 = load i64, ptr %workspace.slot.149, align 8
  %ctx.field.158 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.159 = load i32, ptr %ctx.field.158, align 4
  %steps.next.160 = add i32 %steps.current.159, 1
  store i32 %steps.next.160, ptr %ctx.field.158, align 4
  %steps.over.161 = icmp ugt i32 %steps.next.160, 10000
  br i1 %steps.over.161, label %failure.162, label %continue.163
failure.162:
  %ctx.field.164 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 38, ptr %ctx.field.164, align 4
  %status.diagnostic.165 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.165, align 4
  ret void
continue.163:
  %ctx.field.166 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.167 = load i32, ptr %ctx.field.166, align 4
  %steps.next.168 = add i32 %steps.current.167, 1
  store i32 %steps.next.168, ptr %ctx.field.166, align 4
  %steps.over.169 = icmp ugt i32 %steps.next.168, 10000
  br i1 %steps.over.169, label %failure.170, label %continue.171
failure.170:
  %ctx.field.172 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 39, ptr %ctx.field.172, align 4
  %status.diagnostic.173 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.173, align 4
  ret void
continue.171:
  %ctx.field.174 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.175 = load i32, ptr %ctx.field.174, align 4
  %steps.next.176 = add i32 %steps.current.175, 1
  store i32 %steps.next.176, ptr %ctx.field.174, align 4
  %steps.over.177 = icmp ugt i32 %steps.next.176, 10000
  br i1 %steps.over.177, label %failure.178, label %continue.179
failure.178:
  %ctx.field.180 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 40, ptr %ctx.field.180, align 4
  %status.diagnostic.181 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.181, align 4
  ret void
continue.179:
  %depth.exceeded.182 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.182, label %failure.183, label %continue.184
failure.183:
  %ctx.field.185 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 41, ptr %ctx.field.185, align 4
  %status.diagnostic.186 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.186, align 4
  ret void
continue.184:
  %workspace.slot.187 = getelementptr inbounds i64, ptr %outputs, i64 0
  %record.field.status.188 = call i32 @al_runtime_get_field(ptr %ctx, ptr @agentlang_program, i32 5, i64 %record.make.handle.157, i32 0, ptr %workspace.slot.187)
  switch i32 %record.field.status.188, label %runtime.invalid.result.194 [ i32 0, label %runtime.success.189 i32 1, label %runtime.invalid.request.190 i32 2, label %runtime.invalid.reference.191 i32 3, label %runtime.scratch.capacity.192 i32 4, label %runtime.retained.capacity.193 ]
runtime.invalid.request.190:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.191:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.192:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.193:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.194:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.189:
  %record.field.value.195 = load i64, ptr %workspace.slot.187, align 8
  br label %if.merge.94
if.else.93:
  %ctx.field.196 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.197 = load i32, ptr %ctx.field.196, align 4
  %steps.next.198 = add i32 %steps.current.197, 1
  store i32 %steps.next.198, ptr %ctx.field.196, align 4
  %steps.over.199 = icmp ugt i32 %steps.next.198, 10000
  br i1 %steps.over.199, label %failure.200, label %continue.201
failure.200:
  %ctx.field.202 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 42, ptr %ctx.field.202, align 4
  %status.diagnostic.203 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.203, align 4
  ret void
continue.201:
  %ctx.field.204 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.205 = load i32, ptr %ctx.field.204, align 4
  %steps.next.206 = add i32 %steps.current.205, 1
  store i32 %steps.next.206, ptr %ctx.field.204, align 4
  %steps.over.207 = icmp ugt i32 %steps.next.206, 10000
  br i1 %steps.over.207, label %failure.208, label %continue.209
failure.208:
  %ctx.field.210 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 43, ptr %ctx.field.210, align 4
  %status.diagnostic.211 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.211, align 4
  ret void
continue.209:
  %ctx.field.212 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.213 = load i32, ptr %ctx.field.212, align 4
  %steps.next.214 = add i32 %steps.current.213, 1
  store i32 %steps.next.214, ptr %ctx.field.212, align 4
  %steps.over.215 = icmp ugt i32 %steps.next.214, 10000
  br i1 %steps.over.215, label %failure.216, label %continue.217
failure.216:
  %ctx.field.218 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 44, ptr %ctx.field.218, align 4
  %status.diagnostic.219 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.219, align 4
  ret void
continue.217:
  %ctx.field.220 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.221 = load i32, ptr %ctx.field.220, align 4
  %steps.next.222 = add i32 %steps.current.221, 1
  store i32 %steps.next.222, ptr %ctx.field.220, align 4
  %steps.over.223 = icmp ugt i32 %steps.next.222, 10000
  br i1 %steps.over.223, label %failure.224, label %continue.225
failure.224:
  %ctx.field.226 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 45, ptr %ctx.field.226, align 4
  %status.diagnostic.227 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.227, align 4
  ret void
continue.225:
  %ctx.field.228 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.229 = load i32, ptr %ctx.field.228, align 4
  %steps.next.230 = add i32 %steps.current.229, 1
  store i32 %steps.next.230, ptr %ctx.field.228, align 4
  %steps.over.231 = icmp ugt i32 %steps.next.230, 10000
  br i1 %steps.over.231, label %failure.232, label %continue.233
failure.232:
  %ctx.field.234 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 46, ptr %ctx.field.234, align 4
  %status.diagnostic.235 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.235, align 4
  ret void
continue.233:
  %ctx.field.236 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.237 = load i32, ptr %ctx.field.236, align 4
  %steps.next.238 = add i32 %steps.current.237, 1
  store i32 %steps.next.238, ptr %ctx.field.236, align 4
  %steps.over.239 = icmp ugt i32 %steps.next.238, 10000
  br i1 %steps.over.239, label %failure.240, label %continue.241
failure.240:
  %ctx.field.242 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 47, ptr %ctx.field.242, align 4
  %status.diagnostic.243 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.243, align 4
  ret void
continue.241:
  %ctx.field.244 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.245 = load i32, ptr %ctx.field.244, align 4
  %steps.next.246 = add i32 %steps.current.245, 1
  store i32 %steps.next.246, ptr %ctx.field.244, align 4
  %steps.over.247 = icmp ugt i32 %steps.next.246, 10000
  br i1 %steps.over.247, label %failure.248, label %continue.249
failure.248:
  %ctx.field.250 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 48, ptr %ctx.field.250, align 4
  %status.diagnostic.251 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.251, align 4
  ret void
continue.249:
  %depth.exceeded.252 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.252, label %failure.253, label %continue.254
failure.253:
  %ctx.field.255 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 49, ptr %ctx.field.255, align 4
  %status.diagnostic.256 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.256, align 4
  ret void
continue.254:
  %call.depth.257 = add i32 %depth, 1
  call void @agentlang_fn_595af45502edb375d2c34ed58568618551d754bf531d9216b84c417c2cf7efb0_r1(ptr %ctx, ptr %outputs, ptr %status, i32 %call.depth.257, i64 %arg0, i64 800)
  %callee.status.258 = load i32, ptr %status, align 4
  %callee.succeeded.259 = icmp eq i32 %callee.status.258, 0
  br i1 %callee.succeeded.259, label %callee.continue.261, label %callee.failure.260
callee.failure.260:
  ret void
callee.continue.261:
  %call.output.ptr.262 = getelementptr inbounds i64, ptr %outputs, i64 0
  %call.output.263 = load i64, ptr %call.output.ptr.262, align 8
  %ctx.field.264 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.265 = load i32, ptr %ctx.field.264, align 4
  %steps.next.266 = add i32 %steps.current.265, 1
  store i32 %steps.next.266, ptr %ctx.field.264, align 4
  %steps.over.267 = icmp ugt i32 %steps.next.266, 10000
  br i1 %steps.over.267, label %failure.268, label %continue.269
failure.268:
  %ctx.field.270 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 50, ptr %ctx.field.270, align 4
  %status.diagnostic.271 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.271, align 4
  ret void
continue.269:
  %ctx.field.272 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.273 = load i32, ptr %ctx.field.272, align 4
  %steps.next.274 = add i32 %steps.current.273, 1
  store i32 %steps.next.274, ptr %ctx.field.272, align 4
  %steps.over.275 = icmp ugt i32 %steps.next.274, 10000
  br i1 %steps.over.275, label %failure.276, label %continue.277
failure.276:
  %ctx.field.278 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 51, ptr %ctx.field.278, align 4
  %status.diagnostic.279 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.279, align 4
  ret void
continue.277:
  %ctx.field.280 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.281 = load i32, ptr %ctx.field.280, align 4
  %steps.next.282 = add i32 %steps.current.281, 1
  store i32 %steps.next.282, ptr %ctx.field.280, align 4
  %steps.over.283 = icmp ugt i32 %steps.next.282, 10000
  br i1 %steps.over.283, label %failure.284, label %continue.285
failure.284:
  %ctx.field.286 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 52, ptr %ctx.field.286, align 4
  %status.diagnostic.287 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.287, align 4
  ret void
continue.285:
  %ctx.field.288 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.289 = load i32, ptr %ctx.field.288, align 4
  %steps.next.290 = add i32 %steps.current.289, 1
  store i32 %steps.next.290, ptr %ctx.field.288, align 4
  %steps.over.291 = icmp ugt i32 %steps.next.290, 10000
  br i1 %steps.over.291, label %failure.292, label %continue.293
failure.292:
  %ctx.field.294 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 53, ptr %ctx.field.294, align 4
  %status.diagnostic.295 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.295, align 4
  ret void
continue.293:
  %depth.exceeded.296 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.296, label %failure.297, label %continue.298
failure.297:
  %ctx.field.299 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 54, ptr %ctx.field.299, align 4
  %status.diagnostic.300 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.300, align 4
  ret void
continue.298:
  %workspace.slot.301 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %arg0, ptr %workspace.slot.301, align 8
  %workspace.slot.302 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %call.output.263, ptr %workspace.slot.302, align 8
  %workspace.slot.303 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.304 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 6, ptr %outputs, i32 2, ptr %workspace.slot.303)
  switch i32 %record.make.status.304, label %runtime.invalid.result.310 [ i32 0, label %runtime.success.305 i32 1, label %runtime.invalid.request.306 i32 2, label %runtime.invalid.reference.307 i32 3, label %runtime.scratch.capacity.308 i32 4, label %runtime.retained.capacity.309 ]
runtime.invalid.request.306:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.307:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.308:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.309:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.310:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.305:
  %record.make.handle.311 = load i64, ptr %workspace.slot.303, align 8
  %ctx.field.312 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.313 = load i32, ptr %ctx.field.312, align 4
  %steps.next.314 = add i32 %steps.current.313, 1
  store i32 %steps.next.314, ptr %ctx.field.312, align 4
  %steps.over.315 = icmp ugt i32 %steps.next.314, 10000
  br i1 %steps.over.315, label %failure.316, label %continue.317
failure.316:
  %ctx.field.318 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 55, ptr %ctx.field.318, align 4
  %status.diagnostic.319 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.319, align 4
  ret void
continue.317:
  %ctx.field.320 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.321 = load i32, ptr %ctx.field.320, align 4
  %steps.next.322 = add i32 %steps.current.321, 1
  store i32 %steps.next.322, ptr %ctx.field.320, align 4
  %steps.over.323 = icmp ugt i32 %steps.next.322, 10000
  br i1 %steps.over.323, label %failure.324, label %continue.325
failure.324:
  %ctx.field.326 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 56, ptr %ctx.field.326, align 4
  %status.diagnostic.327 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.327, align 4
  ret void
continue.325:
  %ctx.field.328 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.329 = load i32, ptr %ctx.field.328, align 4
  %steps.next.330 = add i32 %steps.current.329, 1
  store i32 %steps.next.330, ptr %ctx.field.328, align 4
  %steps.over.331 = icmp ugt i32 %steps.next.330, 10000
  br i1 %steps.over.331, label %failure.332, label %continue.333
failure.332:
  %ctx.field.334 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 57, ptr %ctx.field.334, align 4
  %status.diagnostic.335 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.335, align 4
  ret void
continue.333:
  %depth.exceeded.336 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.336, label %failure.337, label %continue.338
failure.337:
  %ctx.field.339 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 58, ptr %ctx.field.339, align 4
  %status.diagnostic.340 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.340, align 4
  ret void
continue.338:
  %workspace.slot.341 = getelementptr inbounds i64, ptr %outputs, i64 0
  %record.field.status.342 = call i32 @al_runtime_get_field(ptr %ctx, ptr @agentlang_program, i32 6, i64 %record.make.handle.311, i32 0, ptr %workspace.slot.341)
  switch i32 %record.field.status.342, label %runtime.invalid.result.348 [ i32 0, label %runtime.success.343 i32 1, label %runtime.invalid.request.344 i32 2, label %runtime.invalid.reference.345 i32 3, label %runtime.scratch.capacity.346 i32 4, label %runtime.retained.capacity.347 ]
runtime.invalid.request.344:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.345:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.346:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.347:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.348:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.343:
  %record.field.value.349 = load i64, ptr %workspace.slot.341, align 8
  br label %if.merge.94
if.merge.94:
  %stack.phi.350 = phi i64 [ %record.field.value.195, %runtime.success.189 ], [ %record.field.value.349, %runtime.success.343 ]
  %local.phi.351 = phi i64 [ %arg0, %runtime.success.189 ], [ %arg0, %runtime.success.343 ]
  %local.phi.352 = phi i64 [ %call.output.43, %runtime.success.189 ], [ %call.output.43, %runtime.success.343 ]
  %ctx.field.353 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.354 = load i32, ptr %ctx.field.353, align 4
  %steps.next.355 = add i32 %steps.current.354, 1
  store i32 %steps.next.355, ptr %ctx.field.353, align 4
  %steps.over.356 = icmp ugt i32 %steps.next.355, 10000
  br i1 %steps.over.356, label %failure.357, label %continue.358
failure.357:
  %ctx.field.359 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 59, ptr %ctx.field.359, align 4
  %status.diagnostic.360 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.360, align 4
  ret void
continue.358:
  %ctx.field.361 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.362 = load i32, ptr %ctx.field.361, align 4
  %steps.next.363 = add i32 %steps.current.362, 1
  store i32 %steps.next.363, ptr %ctx.field.361, align 4
  %steps.over.364 = icmp ugt i32 %steps.next.363, 10000
  br i1 %steps.over.364, label %failure.365, label %continue.366
failure.365:
  %ctx.field.367 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 60, ptr %ctx.field.367, align 4
  %status.diagnostic.368 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.368, align 4
  ret void
continue.366:
  %ctx.field.369 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.370 = load i32, ptr %ctx.field.369, align 4
  %steps.next.371 = add i32 %steps.current.370, 1
  store i32 %steps.next.371, ptr %ctx.field.369, align 4
  %steps.over.372 = icmp ugt i32 %steps.next.371, 10000
  br i1 %steps.over.372, label %failure.373, label %continue.374
failure.373:
  %ctx.field.375 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 61, ptr %ctx.field.375, align 4
  %status.diagnostic.376 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.376, align 4
  ret void
continue.374:
  %ctx.field.377 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.378 = load i32, ptr %ctx.field.377, align 4
  %steps.next.379 = add i32 %steps.current.378, 1
  store i32 %steps.next.379, ptr %ctx.field.377, align 4
  %steps.over.380 = icmp ugt i32 %steps.next.379, 10000
  br i1 %steps.over.380, label %failure.381, label %continue.382
failure.381:
  %ctx.field.383 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 62, ptr %ctx.field.383, align 4
  %status.diagnostic.384 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.384, align 4
  ret void
continue.382:
  %depth.exceeded.385 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.385, label %failure.386, label %continue.387
failure.386:
  %ctx.field.388 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 63, ptr %ctx.field.388, align 4
  %status.diagnostic.389 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.389, align 4
  ret void
continue.387:
  %workspace.slot.390 = getelementptr inbounds i64, ptr %outputs, i64 0
  %record.field.status.391 = call i32 @al_runtime_get_field(ptr %ctx, ptr @agentlang_program, i32 4, i64 %local.phi.352, i32 0, ptr %workspace.slot.390)
  switch i32 %record.field.status.391, label %runtime.invalid.result.397 [ i32 0, label %runtime.success.392 i32 1, label %runtime.invalid.request.393 i32 2, label %runtime.invalid.reference.394 i32 3, label %runtime.scratch.capacity.395 i32 4, label %runtime.retained.capacity.396 ]
runtime.invalid.request.393:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.394:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.395:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.396:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.397:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.392:
  %record.field.value.398 = load i64, ptr %workspace.slot.390, align 8
  %ctx.field.399 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.400 = load i32, ptr %ctx.field.399, align 4
  %steps.next.401 = add i32 %steps.current.400, 1
  store i32 %steps.next.401, ptr %ctx.field.399, align 4
  %steps.over.402 = icmp ugt i32 %steps.next.401, 10000
  br i1 %steps.over.402, label %failure.403, label %continue.404
failure.403:
  %ctx.field.405 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 64, ptr %ctx.field.405, align 4
  %status.diagnostic.406 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.406, align 4
  ret void
continue.404:
  %ctx.field.407 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.408 = load i32, ptr %ctx.field.407, align 4
  %steps.next.409 = add i32 %steps.current.408, 1
  store i32 %steps.next.409, ptr %ctx.field.407, align 4
  %steps.over.410 = icmp ugt i32 %steps.next.409, 10000
  br i1 %steps.over.410, label %failure.411, label %continue.412
failure.411:
  %ctx.field.413 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 65, ptr %ctx.field.413, align 4
  %status.diagnostic.414 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.414, align 4
  ret void
continue.412:
  %ctx.field.415 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.416 = load i32, ptr %ctx.field.415, align 4
  %steps.next.417 = add i32 %steps.current.416, 1
  store i32 %steps.next.417, ptr %ctx.field.415, align 4
  %steps.over.418 = icmp ugt i32 %steps.next.417, 10000
  br i1 %steps.over.418, label %failure.419, label %continue.420
failure.419:
  %ctx.field.421 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 66, ptr %ctx.field.421, align 4
  %status.diagnostic.422 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.422, align 4
  ret void
continue.420:
  %depth.exceeded.423 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.423, label %failure.424, label %continue.425
failure.424:
  %ctx.field.426 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 67, ptr %ctx.field.426, align 4
  %status.diagnostic.427 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.427, align 4
  ret void
continue.425:
  %workspace.slot.428 = getelementptr inbounds i64, ptr %outputs, i64 0
  %record.field.status.429 = call i32 @al_runtime_get_field(ptr %ctx, ptr @agentlang_program, i32 4, i64 %local.phi.352, i32 1, ptr %workspace.slot.428)
  switch i32 %record.field.status.429, label %runtime.invalid.result.435 [ i32 0, label %runtime.success.430 i32 1, label %runtime.invalid.request.431 i32 2, label %runtime.invalid.reference.432 i32 3, label %runtime.scratch.capacity.433 i32 4, label %runtime.retained.capacity.434 ]
runtime.invalid.request.431:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.432:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.433:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.434:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.435:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.430:
  %record.field.value.436 = load i64, ptr %workspace.slot.428, align 8
  %ctx.field.437 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.438 = load i32, ptr %ctx.field.437, align 4
  %steps.next.439 = add i32 %steps.current.438, 1
  store i32 %steps.next.439, ptr %ctx.field.437, align 4
  %steps.over.440 = icmp ugt i32 %steps.next.439, 10000
  br i1 %steps.over.440, label %failure.441, label %continue.442
failure.441:
  %ctx.field.443 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 68, ptr %ctx.field.443, align 4
  %status.diagnostic.444 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.444, align 4
  ret void
continue.442:
  %ctx.field.445 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.446 = load i32, ptr %ctx.field.445, align 4
  %steps.next.447 = add i32 %steps.current.446, 1
  store i32 %steps.next.447, ptr %ctx.field.445, align 4
  %steps.over.448 = icmp ugt i32 %steps.next.447, 10000
  br i1 %steps.over.448, label %failure.449, label %continue.450
failure.449:
  %ctx.field.451 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 69, ptr %ctx.field.451, align 4
  %status.diagnostic.452 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.452, align 4
  ret void
continue.450:
  %depth.exceeded.453 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.453, label %failure.454, label %continue.455
failure.454:
  %ctx.field.456 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 70, ptr %ctx.field.456, align 4
  %status.diagnostic.457 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.457, align 4
  ret void
continue.455:
  %checked.tuple.458 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %record.field.value.436, i64 %stack.phi.350)
  %checked.raw.459 = extractvalue { i64, i1 } %checked.tuple.458, 0
  %checked.overflow.460 = extractvalue { i64, i1 } %checked.tuple.458, 1
  br i1 %checked.overflow.460, label %overflow.461, label %checked.462
overflow.461:
  %ctx.field.463 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 4
  %ctx.field.464 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 5
  store i64 %record.field.value.436, ptr %ctx.field.463, align 8
  store i64 %stack.phi.350, ptr %ctx.field.464, align 8
  %ctx.field.465 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 71, ptr %ctx.field.465, align 4
  %status.diagnostic.466 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.466, align 4
  ret void
checked.462:
  %ctx.field.467 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.468 = load i32, ptr %ctx.field.467, align 4
  %steps.next.469 = add i32 %steps.current.468, 1
  store i32 %steps.next.469, ptr %ctx.field.467, align 4
  %steps.over.470 = icmp ugt i32 %steps.next.469, 10000
  br i1 %steps.over.470, label %failure.471, label %continue.472
failure.471:
  %ctx.field.473 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 72, ptr %ctx.field.473, align 4
  %status.diagnostic.474 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.474, align 4
  ret void
continue.472:
  %ctx.field.475 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.476 = load i32, ptr %ctx.field.475, align 4
  %steps.next.477 = add i32 %steps.current.476, 1
  store i32 %steps.next.477, ptr %ctx.field.475, align 4
  %steps.over.478 = icmp ugt i32 %steps.next.477, 10000
  br i1 %steps.over.478, label %failure.479, label %continue.480
failure.479:
  %ctx.field.481 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 73, ptr %ctx.field.481, align 4
  %status.diagnostic.482 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.482, align 4
  ret void
continue.480:
  %ctx.field.483 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.484 = load i32, ptr %ctx.field.483, align 4
  %steps.next.485 = add i32 %steps.current.484, 1
  store i32 %steps.next.485, ptr %ctx.field.483, align 4
  %steps.over.486 = icmp ugt i32 %steps.next.485, 10000
  br i1 %steps.over.486, label %failure.487, label %continue.488
failure.487:
  %ctx.field.489 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 74, ptr %ctx.field.489, align 4
  %status.diagnostic.490 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.490, align 4
  ret void
continue.488:
  %ctx.field.491 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.492 = load i32, ptr %ctx.field.491, align 4
  %steps.next.493 = add i32 %steps.current.492, 1
  store i32 %steps.next.493, ptr %ctx.field.491, align 4
  %steps.over.494 = icmp ugt i32 %steps.next.493, 10000
  br i1 %steps.over.494, label %failure.495, label %continue.496
failure.495:
  %ctx.field.497 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 75, ptr %ctx.field.497, align 4
  %status.diagnostic.498 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.498, align 4
  ret void
continue.496:
  %depth.exceeded.499 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.499, label %failure.500, label %continue.501
failure.500:
  %ctx.field.502 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 76, ptr %ctx.field.502, align 4
  %status.diagnostic.503 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.503, align 4
  ret void
continue.501:
  %workspace.slot.504 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.field.value.398, ptr %workspace.slot.504, align 8
  %workspace.slot.505 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %checked.raw.459, ptr %workspace.slot.505, align 8
  %workspace.slot.506 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.507 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 4, ptr %outputs, i32 2, ptr %workspace.slot.506)
  switch i32 %record.make.status.507, label %runtime.invalid.result.513 [ i32 0, label %runtime.success.508 i32 1, label %runtime.invalid.request.509 i32 2, label %runtime.invalid.reference.510 i32 3, label %runtime.scratch.capacity.511 i32 4, label %runtime.retained.capacity.512 ]
runtime.invalid.request.509:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.510:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.511:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.512:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.513:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.508:
  %record.make.handle.514 = load i64, ptr %workspace.slot.506, align 8
  %output.ptr.515 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.514, ptr %output.ptr.515, align 8
  ret void
}

define dllexport i32 @agentlang_output_capacity() { ret i32 3 }

define dllexport void @agentlang_abi_layout(ptr %output) {
entry:
  %size.ptr = getelementptr %NativeExecutionContext, ptr null, i32 1
  %size = ptrtoint ptr %size.ptr to i64
  %align.ptr = getelementptr %NativeExecutionContextAlignmentProbe, ptr null, i32 0, i32 1
  %alignment = ptrtoint ptr %align.ptr to i64
  %field0.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 0
  %field0 = ptrtoint ptr %field0.ptr to i64
  %field1.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 1
  %field1 = ptrtoint ptr %field1.ptr to i64
  %field2.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 2
  %field2 = ptrtoint ptr %field2.ptr to i64
  %field3.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 3
  %field3 = ptrtoint ptr %field3.ptr to i64
  %field4.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 4
  %field4 = ptrtoint ptr %field4.ptr to i64
  %field5.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 5
  %field5 = ptrtoint ptr %field5.ptr to i64
  %field6.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 6
  %field6 = ptrtoint ptr %field6.ptr to i64
  %field7.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 7
  %field7 = ptrtoint ptr %field7.ptr to i64
  %field8.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 8
  %field8 = ptrtoint ptr %field8.ptr to i64
  %field9.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 9
  %field9 = ptrtoint ptr %field9.ptr to i64
  %field10.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 10
  %field10 = ptrtoint ptr %field10.ptr to i64
  %field11.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 11
  %field11 = ptrtoint ptr %field11.ptr to i64
  %field12.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 12
  %field12 = ptrtoint ptr %field12.ptr to i64
  %field13.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 13
  %field13 = ptrtoint ptr %field13.ptr to i64
  %field14.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 14
  %field14 = ptrtoint ptr %field14.ptr to i64
  %field15.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 15
  %field15 = ptrtoint ptr %field15.ptr to i64
  %items = alloca [18 x i64], align 8
  %out0 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 0
  store i64 %size, ptr %out0, align 8
  %out1 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 1
  store i64 %alignment, ptr %out1, align 8
  %out2 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 2
  store i64 %field0, ptr %out2, align 8
  %out3 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 3
  store i64 %field1, ptr %out3, align 8
  %out4 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 4
  store i64 %field2, ptr %out4, align 8
  %out5 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 5
  store i64 %field3, ptr %out5, align 8
  %out6 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 6
  store i64 %field4, ptr %out6, align 8
  %out7 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 7
  store i64 %field5, ptr %out7, align 8
  %out8 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 8
  store i64 %field6, ptr %out8, align 8
  %out9 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 9
  store i64 %field7, ptr %out9, align 8
  %out10 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 10
  store i64 %field8, ptr %out10, align 8
  %out11 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 11
  store i64 %field9, ptr %out11, align 8
  %out12 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 12
  store i64 %field10, ptr %out12, align 8
  %out13 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 13
  store i64 %field11, ptr %out13, align 8
  %out14 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 14
  store i64 %field12, ptr %out14, align 8
  %out15 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 15
  store i64 %field13, ptr %out15, align 8
  %out16 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 16
  store i64 %field14, ptr %out16, align 8
  %out17 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 17
  store i64 %field15, ptr %out17, align 8
  %item0 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 0
  %value0 = load i64, ptr %item0, align 8
  %dest0 = getelementptr inbounds i64, ptr %output, i64 0
  store i64 %value0, ptr %dest0, align 8
  %item1 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 1
  %value1 = load i64, ptr %item1, align 8
  %dest1 = getelementptr inbounds i64, ptr %output, i64 1
  store i64 %value1, ptr %dest1, align 8
  %item2 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 2
  %value2 = load i64, ptr %item2, align 8
  %dest2 = getelementptr inbounds i64, ptr %output, i64 2
  store i64 %value2, ptr %dest2, align 8
  %item3 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 3
  %value3 = load i64, ptr %item3, align 8
  %dest3 = getelementptr inbounds i64, ptr %output, i64 3
  store i64 %value3, ptr %dest3, align 8
  %item4 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 4
  %value4 = load i64, ptr %item4, align 8
  %dest4 = getelementptr inbounds i64, ptr %output, i64 4
  store i64 %value4, ptr %dest4, align 8
  %item5 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 5
  %value5 = load i64, ptr %item5, align 8
  %dest5 = getelementptr inbounds i64, ptr %output, i64 5
  store i64 %value5, ptr %dest5, align 8
  %item6 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 6
  %value6 = load i64, ptr %item6, align 8
  %dest6 = getelementptr inbounds i64, ptr %output, i64 6
  store i64 %value6, ptr %dest6, align 8
  %item7 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 7
  %value7 = load i64, ptr %item7, align 8
  %dest7 = getelementptr inbounds i64, ptr %output, i64 7
  store i64 %value7, ptr %dest7, align 8
  %item8 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 8
  %value8 = load i64, ptr %item8, align 8
  %dest8 = getelementptr inbounds i64, ptr %output, i64 8
  store i64 %value8, ptr %dest8, align 8
  %item9 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 9
  %value9 = load i64, ptr %item9, align 8
  %dest9 = getelementptr inbounds i64, ptr %output, i64 9
  store i64 %value9, ptr %dest9, align 8
  %item10 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 10
  %value10 = load i64, ptr %item10, align 8
  %dest10 = getelementptr inbounds i64, ptr %output, i64 10
  store i64 %value10, ptr %dest10, align 8
  %item11 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 11
  %value11 = load i64, ptr %item11, align 8
  %dest11 = getelementptr inbounds i64, ptr %output, i64 11
  store i64 %value11, ptr %dest11, align 8
  %item12 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 12
  %value12 = load i64, ptr %item12, align 8
  %dest12 = getelementptr inbounds i64, ptr %output, i64 12
  store i64 %value12, ptr %dest12, align 8
  %item13 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 13
  %value13 = load i64, ptr %item13, align 8
  %dest13 = getelementptr inbounds i64, ptr %output, i64 13
  store i64 %value13, ptr %dest13, align 8
  %item14 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 14
  %value14 = load i64, ptr %item14, align 8
  %dest14 = getelementptr inbounds i64, ptr %output, i64 14
  store i64 %value14, ptr %dest14, align 8
  %item15 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 15
  %value15 = load i64, ptr %item15, align 8
  %dest15 = getelementptr inbounds i64, ptr %output, i64 15
  store i64 %value15, ptr %dest15, align 8
  %item16 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 16
  %value16 = load i64, ptr %item16, align 8
  %dest16 = getelementptr inbounds i64, ptr %output, i64 16
  store i64 %value16, ptr %dest16, align 8
  %item17 = getelementptr inbounds [18 x i64], ptr %items, i64 0, i64 17
  %value17 = load i64, ptr %item17, align 8
  %dest17 = getelementptr inbounds i64, ptr %output, i64 17
  store i64 %value17, ptr %dest17, align 8
  ret void
}

define dllexport void @agentlang_execute(ptr %ctx, ptr %outputs, i32 %capacity, ptr %status) {
entry:
  %validation.result = call i32 @al_runtime_validate_request(ptr %ctx, ptr %outputs, i32 1, i32 %capacity, ptr %status, i32 3)
  %request.valid = icmp eq i32 %validation.result, 0
  br i1 %request.valid, label %request.accepted, label %request.rejected
request.rejected:
  ret void
request.accepted:
  %steps.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  store i32 0, ptr %steps.ptr, align 4
  %error.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 -1, ptr %error.ptr, align 4
  %reserved.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 3
  store i32 0, ptr %reserved.ptr, align 4
  %arg0.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 4
  store i64 0, ptr %arg0.ptr, align 8
  %arg1.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 5
  store i64 0, ptr %arg1.ptr, align 8
  %workspace.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 8
  %workspace = load ptr, ptr %workspace.ptr, align 8
  %import.result = call i32 @al_runtime_import_state(ptr %ctx, ptr @agentlang_program, ptr @agentlang_input_type_ids, i32 1)
  switch i32 %import.result, label %import.invalid [ i32 0, label %import.succeeded i32 1, label %import.invalid.request i32 2, label %import.invalid.reference i32 3, label %import.scratch.capacity i32 4, label %import.retained.capacity ]
import.invalid:
  store i32 2, ptr %status, align 4
  ret void
import.invalid.request:
  store i32 2, ptr %status, align 4
  ret void
import.invalid.reference:
  store i32 5, ptr %status, align 4
  ret void
import.scratch.capacity:
  store i32 3, ptr %status, align 4
  ret void
import.retained.capacity:
  store i32 4, ptr %status, align 4
  ret void
import.succeeded:
  %entry.arg0.ptr = getelementptr inbounds i64, ptr %workspace, i64 0
  %entry.arg0 = load i64, ptr %entry.arg0.ptr, align 8
  call void @agentlang_body(ptr %ctx, ptr %workspace, ptr %status, i32 0, i64 %entry.arg0)
  %body.status = load i32, ptr %status, align 4
  %body.succeeded = icmp eq i32 %body.status, 0
  br i1 %body.succeeded, label %promote, label %body.failed
body.failed:
  ret void
promote:
  %promote.result = call i32 @al_runtime_promote(ptr %ctx, ptr @agentlang_program, ptr %workspace, ptr @agentlang_root_type_ids, i32 1, ptr %outputs, i32 %capacity)
  switch i32 %promote.result, label %promote.invalid [ i32 0, label %promote.succeeded i32 1, label %promote.invalid.request i32 2, label %promote.invalid.reference i32 3, label %promote.scratch.capacity i32 4, label %promote.retained.capacity ]
promote.invalid:
  store i32 2, ptr %status, align 4
  ret void
promote.invalid.request:
  store i32 2, ptr %status, align 4
  ret void
promote.invalid.reference:
  store i32 5, ptr %status, align 4
  ret void
promote.scratch.capacity:
  store i32 3, ptr %status, align 4
  ret void
promote.retained.capacity:
  store i32 4, ptr %status, align 4
  ret void
promote.succeeded:
  ret void
}

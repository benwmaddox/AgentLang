param(
    [Parameter(Mandatory = $true)]
    [string]$OrdinaryEvidencePath,
    [Parameter(Mandatory = $true)]
    [string]$PolicyEvidencePath,
    [Parameter(Mandatory = $true)]
    [string]$HistoricalLinkFailureEvidencePath,
    [switch]$TerminalConfirmed
)

# One-time Milestone 132 archive. The terminal switch is an additional guard;
# root must explicitly confirm that the current four-step regression gate ended.
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
if (-not $TerminalConfirmed) {
    throw 'Packaging is gated: rerun with -TerminalConfirmed only after root confirms the full regression sequence is terminal.'
}

$repoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
$regressionRoot = Join-Path $repoRoot '.agentlang\owning-mailbox-002\regression-validation'
$checksPath = Join-Path $regressionRoot 'checks.json'
$fullGatePath = Join-Path $regressionRoot 'validation.json'
$llvmRegressionLog = Join-Path $regressionRoot 'llvm-regression.log'
$mailbox002Root = Join-Path $repoRoot '.agentlang\owning-mailbox-002'
$mailbox001Root = Join-Path $repoRoot '.agentlang\owning-mailbox-001'
$componentValidationRoot = Join-Path $mailbox002Root 'component-validation'
$outputRoot = Join-Path $repoRoot 'reports\evidence\132-associated-arena-comparison'
$outputParent = Split-Path -Parent $outputRoot
$archiveName = '132-associated-arena-comparison.zip'
$indexName = 'storage-index.json'

function Get-Sha256([string]$Path) {
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Get-RepoRelative([string]$Path) {
    $full = [System.IO.Path]::GetFullPath($Path)
    $relative = [System.IO.Path]::GetRelativePath($repoRoot, $full)
    if ([System.IO.Path]::IsPathRooted($relative) -or $relative -eq '..' -or
        $relative.StartsWith('..\', [System.StringComparison]::Ordinal) -or
        $relative.StartsWith('../', [System.StringComparison]::Ordinal)) {
        throw "Evidence source is outside the repository: $full"
    }
    return $relative.Replace('\', '/')
}

function Get-ContainedPath([string]$Root, [string]$Candidate) {
    $rootFull = [System.IO.Path]::GetFullPath($Root).TrimEnd([char[]]@('\', '/'))
    $candidateFull = [System.IO.Path]::GetFullPath($Candidate)
    $prefix = $rootFull + [System.IO.Path]::DirectorySeparatorChar
    if (-not $candidateFull.StartsWith($prefix, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Path escapes its approved root: $candidateFull"
    }
    return $candidateFull
}

function Write-Utf8Lf([string]$Path, [string]$Text) {
    $normalized = [regex]::Replace($Text, "`r`n?", "`n")
    [System.IO.File]::WriteAllText($Path, $normalized, [System.Text.UTF8Encoding]::new($false))
}

function Get-TreeSha256([string]$Root, [string[]]$RelativeFiles) {
    $hash = [System.Security.Cryptography.IncrementalHash]::CreateHash([System.Security.Cryptography.HashAlgorithmName]::SHA256)
    $utf8 = [System.Text.UTF8Encoding]::new($false)
    $delimiter = [byte[]]@(0)
    $sorted = @($RelativeFiles)
    [System.Array]::Sort($sorted, [System.StringComparer]::Ordinal)
    try {
        foreach ($relative in $sorted) {
            $portable = $relative.Replace('\', '/')
            $hash.AppendData($utf8.GetBytes($portable))
            $hash.AppendData($delimiter)
            $path = Join-Path $Root ($portable.Replace('/', [System.IO.Path]::DirectorySeparatorChar))
            $stream = [System.IO.File]::OpenRead($path)
            $buffer = [byte[]]::new(65536)
            try {
                while (($read = $stream.Read($buffer, 0, $buffer.Length)) -gt 0) {
                    if ($read -eq $buffer.Length) {
                        $hash.AppendData($buffer)
                    } else {
                        $chunk = [byte[]]::new($read)
                        [System.Array]::Copy($buffer, $chunk, $read)
                        $hash.AppendData($chunk)
                    }
                }
            } finally { $stream.Dispose() }
            $hash.AppendData($delimiter)
        }
        return [System.Convert]::ToHexString($hash.GetHashAndReset()).ToLowerInvariant()
    } finally { $hash.Dispose() }
}

function Get-InputJson([string]$Path, [string]$Label) {
    $full = [System.IO.Path]::GetFullPath($Path)
    [void](Get-RepoRelative $full)
    if (-not (Test-Path -LiteralPath $full -PathType Leaf)) { throw "$Label evidence is missing: $full" }
    return (Get-Content -LiteralPath $full -Raw | ConvertFrom-Json)
}

function Assert-CleanChecks($Checks, [string]$Label) {
    $items = @($Checks)
    if ($items.Count -eq 0 -or @($items | Where-Object { -not $_.passed }).Count -ne 0) {
        throw "$Label does not contain a nonempty all-passing check list."
    }
    return $items.Count
}

function Get-FinalRunSourceHashes($Evidence, [string]$Label) {
    $inputHashProperty = $Evidence.PSObject.Properties['sourceInputHashes']
    $sourceBeforeProperty = $Evidence.PSObject.Properties['sourceHashesBefore']
    $sourceAfterProperty = $Evidence.PSObject.Properties['sourceHashesAfter']
    if ($null -ne $inputHashProperty) {
        $before = @($Evidence.sourceInputHashes.before)
        $after = @($Evidence.sourceInputHashes.after)
        if ($Evidence.sourceInputHashes.unchanged -ne $true) { throw "$Label source hashes were not marked unchanged." }
    } elseif ($null -ne $sourceBeforeProperty -and $null -ne $sourceAfterProperty) {
        $before = @($Evidence.sourceHashesBefore)
        $after = @($Evidence.sourceHashesAfter)
    } else {
        throw "$Label evidence has no recognized source-hash schema."
    }
    if ($before.Count -eq 0 -or $before.Count -ne $after.Count) { throw "$Label before/after source-hash sets are empty or unequal." }
    $beforeByPath = @{}
    foreach ($record in $before) {
        $relative = Get-RepoRelative ([string]$record.path)
        if ($beforeByPath.ContainsKey($relative)) { throw "$Label has a duplicate source hash path: $relative" }
        $beforeByPath[$relative] = ([string]$record.sha256).ToLowerInvariant()
    }
    $records = [System.Collections.Generic.List[object]]::new()
    $afterPaths = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($record in $after) {
        $relative = Get-RepoRelative ([string]$record.path)
        $expected = ([string]$record.sha256).ToLowerInvariant()
        if (-not $afterPaths.Add($relative) -or -not $beforeByPath.ContainsKey($relative) -or $beforeByPath[$relative] -ne $expected) {
            throw "$Label source hashes differ before/after or contain duplicates: $relative"
        }
        $currentPath = Join-Path $repoRoot ($relative.Replace('/', [System.IO.Path]::DirectorySeparatorChar))
        if (-not (Test-Path -LiteralPath $currentPath -PathType Leaf) -or (Get-Sha256 $currentPath) -ne $expected) {
            throw "$Label source no longer matches the final run hash: $relative"
        }
        $records.Add([pscustomobject]@{ path = $currentPath; relative = $relative; sha256 = $expected; run = $Label })
    }
    if ($beforeByPath.Count -ne $afterPaths.Count) { throw "$Label source hash path sets differ." }
    return @($records)
}

$ordinaryPath = [System.IO.Path]::GetFullPath($OrdinaryEvidencePath)
$policyPath = [System.IO.Path]::GetFullPath($PolicyEvidencePath)
$linkFailurePath = [System.IO.Path]::GetFullPath($HistoricalLinkFailureEvidencePath)
$ordinary = Get-InputJson $ordinaryPath 'Final ordinary policy-control'
$policy = Get-InputJson $policyPath 'Final keep-associated policy'
$linkFailure = Get-InputJson $linkFailurePath 'Historical link-failure'

if (-not $ordinary.passed -or -not $policy.passed) { throw 'Both final focused evidence files must report passed=true.' }
$ordinaryCheckCount = Assert-CleanChecks $ordinary.checks 'Final ordinary run'
$policyCheckCount = Assert-CleanChecks $policy.checks 'Final policy run'
if ($ordinary.nativeRuns.Count -ne 2 -or $policy.nativeRuns.Count -ne 2) {
    throw 'Both final focused runs must contain exactly two native optimization runs.'
}
$nativeCheckCounts = [ordered]@{}
foreach ($runSet in @(@{ label = 'ordinary'; runs = $ordinary.nativeRuns }, @{ label = 'policy'; runs = $policy.nativeRuns })) {
    $seen = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::Ordinal)
    foreach ($nativeRun in $runSet.runs) {
        $optimization = [string]$nativeRun.optimization
        if ($optimization -notin @('O0', 'O2') -or -not $seen.Add($optimization) -or
            $null -eq $nativeRun.result -or -not $nativeRun.result.passed) {
            throw "$($runSet.label) has missing, duplicate, or failing native optimization evidence."
        }
        $count = Assert-CleanChecks $nativeRun.result.checks "$($runSet.label) native $optimization"
        $nativeCheckCounts["$($runSet.label)-$optimization"] = $count
    }
    if ($seen.Count -ne 2) { throw "$($runSet.label) is missing O0 or O2 native evidence." }
}
if (-not $linkFailure.kind -or $linkFailure.passed -eq $true) {
    throw 'The historical link-failure input does not look like a failed integration evidence record.'
}

# The two final gates must identify one unchanged source set. Snapshot every
# unique source only after checking both run records and the current bytes.
$sourceRecords = [System.Collections.Generic.List[object]]::new()
$sourceByPath = @{}
foreach ($pair in @(
    @{ evidence = $ordinary; label = 'ordinary' },
    @{ evidence = $policy; label = 'policy' }
)) {
    foreach ($record in (Get-FinalRunSourceHashes $pair.evidence $pair.label)) {
        if ($sourceByPath.ContainsKey($record.relative)) {
            if ($sourceByPath[$record.relative].sha256 -ne $record.sha256) {
                throw "Final gates recorded different versions of the same source: $($record.relative)"
            }
        } else {
            $sourceByPath[$record.relative] = $record
            $sourceRecords.Add($record)
        }
    }
}

# Require the current 002 gate and validate its command identities before any
# archive staging. These paths intentionally do not refer to milestone 131.
foreach ($required in @($checksPath, $fullGatePath, $llvmRegressionLog, (Join-Path $mailbox002Root 'Run-RegressionChecks.ps1'))) {
    if (-not (Test-Path -LiteralPath $required -PathType Leaf)) { throw "Required current regression evidence is missing: $required" }
}
$regressionChecks = @(Get-Content -LiteralPath $checksPath -Raw | ConvertFrom-Json)
$expectedSteps = @(
    [ordered]@{ name = 'owning-stack'; executable = 'pwsh'; arguments = @('-NoProfile', '-File', 'scripts/Verify-NativeValueStack.ps1') },
    [ordered]@{ name = 'native-dispatch'; executable = 'pwsh'; arguments = @('-NoProfile', '-File', 'scripts/Verify-NativeDispatch.ps1', '-SerialBuild', '-SkipPackageAudit') },
    [ordered]@{ name = 'full-release'; executable = 'pwsh'; arguments = @('-NoProfile', '-File', 'scripts/Validate.ps1', '-SerialBuild', '-SkipPackageAudit', '-ReportPath', '.agentlang/owning-mailbox-002/regression-validation/validation.json') },
    [ordered]@{ name = 'llvm-regression'; executable = 'dotnet'; arguments = @('run', '--no-build', '-c', 'Release', '--project', 'tests/AgentLang.Llvm.Tests') }
)
if ($regressionChecks.Count -ne $expectedSteps.Count -or @($regressionChecks | Where-Object { $_.exitCode -ne 0 }).Count -ne 0) {
    throw 'Current regression sequence is not terminal with four successful steps.'
}
$stepNames = [System.Collections.Generic.List[string]]::new()
for ($index = 0; $index -lt $expectedSteps.Count; $index++) {
    $actual = $regressionChecks[$index]
    $expected = $expectedSteps[$index]
    $stepNames.Add([string]$actual.name)
    if ([string]$actual.name -ne [string]$expected.name -or [string]$actual.executable -ne [string]$expected.executable -or
        @($actual.arguments).Count -ne @($expected.arguments).Count) { throw "Regression step $index differs from the approved current sequence." }
    for ($arg = 0; $arg -lt $expected.arguments.Count; $arg++) {
        if ([string]$actual.arguments[$arg] -ne [string]$expected.arguments[$arg]) { throw "Regression command differs for $($expected.name)." }
    }
    $expectedLog = Join-Path $regressionRoot "$($expected.name).log"
    if ([System.IO.Path]::GetFullPath([string]$actual.log) -ne [System.IO.Path]::GetFullPath($expectedLog) -or
        -not (Test-Path -LiteralPath $expectedLog -PathType Leaf)) { throw "Regression log path is missing or unexpected for $($expected.name)." }
    [void](Get-RepoRelative $expectedLog)
}
$fullGate = Get-Content -LiteralPath $fullGatePath -Raw | ConvertFrom-Json
$fullGateChecks = @($fullGate.checks)
$fullGateCheckCount = $fullGateChecks.Count
if (-not $fullGate.passed -or $fullGateCheckCount -eq 0 -or @($fullGateChecks | Where-Object { $_.exitCode -ne 0 }).Count -ne 0) {
    throw 'Current full-release validation is not a clean pass.'
}
$llvmLogText = Get-Content -LiteralPath $llvmRegressionLog -Raw
if ($llvmLogText -notmatch 'AgentLang\.Llvm\.Tests:\s*\d+\s+assertions passed') {
    throw 'Current LLVM regression log does not report a passing assertion count.'
}

$owningStackLog = Join-Path $regressionRoot 'owning-stack.log'
$nativeDispatchLog = Join-Path $regressionRoot 'native-dispatch.log'
$owningStackMatch = [regex]::Match((Get-Content -LiteralPath $owningStackLog -Raw), 'Evidence:\s*(?<path>[^\r\n]+\.json)')
$nativeDispatchMatch = [regex]::Match((Get-Content -LiteralPath $nativeDispatchLog -Raw), 'EvidencePath=(?<path>[^\r\n]+\.json)')
if (-not $owningStackMatch.Success -or -not $nativeDispatchMatch.Success) { throw 'Current regression logs do not identify owning-stack/native-dispatch evidence JSON.' }
function Resolve-LogPath([string]$Value) {
    $valueTrimmed = $Value.Trim().Trim('"').Trim("'")
    if ([System.IO.Path]::IsPathRooted($valueTrimmed)) { return [System.IO.Path]::GetFullPath($valueTrimmed) }
    return [System.IO.Path]::GetFullPath((Join-Path $repoRoot $valueTrimmed))
}
$owningStackEvidencePath = Resolve-LogPath $owningStackMatch.Groups['path'].Value
$nativeDispatchEvidencePath = Resolve-LogPath $nativeDispatchMatch.Groups['path'].Value
$owningStackEvidence = Get-InputJson $owningStackEvidencePath 'Current owning-stack regression'
$nativeDispatchEvidence = Get-InputJson $nativeDispatchEvidencePath 'Current native-dispatch regression'
if (-not $owningStackEvidence.passed -or -not $nativeDispatchEvidence.passed) {
    throw 'Evidence referenced by current owning-stack/native-dispatch logs is not passing.'
}

if (-not (Test-Path -LiteralPath $componentValidationRoot -PathType Container)) { throw 'Current direct component-validation evidence is missing.' }
$componentReadme = Join-Path $componentValidationRoot 'README.md'
if (-not (Test-Path -LiteralPath $componentReadme -PathType Leaf)) { throw 'Component-validation README is missing.' }
$componentBeforePath = Join-Path $componentValidationRoot 'source-hashes-before.txt'
$componentAfterPath = Join-Path $componentValidationRoot 'source-hashes-after.txt'
foreach ($path in @($componentBeforePath, $componentAfterPath)) {
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "Component-validation source manifest is missing: $path" }
}
$componentBeforeText = [System.IO.File]::ReadAllText($componentBeforePath)
$componentAfterText = [System.IO.File]::ReadAllText($componentAfterPath)
if (-not [string]::Equals($componentBeforeText, $componentAfterText, [System.StringComparison]::Ordinal)) {
    throw 'Component-validation before/after source manifests are not byte-identical.'
}
$componentHashRecords = [System.Collections.Generic.List[object]]::new()
$componentHashPaths = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
$componentManifestLines = @([regex]::Split($componentAfterText.Trim(), "`r?`n") | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
if ($componentManifestLines.Count -ne 12) { throw "Component-validation manifests must contain the expected 12 source hashes; found $($componentManifestLines.Count)." }
foreach ($line in $componentManifestLines) {
    if ($line -notmatch '^(?<sha256>[A-Fa-f0-9]{64})\s+\*?(?<path>.+)$') { throw "Malformed component-validation hash record: $line" }
    $expectedHash = $Matches.sha256.ToLowerInvariant()
    $relative = Get-RepoRelative (Join-Path $repoRoot $Matches.path.Trim())
    if (-not $componentHashPaths.Add($relative)) { throw "Duplicate component-validation source path: $relative" }
    $currentPath = Join-Path $repoRoot ($relative.Replace('/', [System.IO.Path]::DirectorySeparatorChar))
    if (-not (Test-Path -LiteralPath $currentPath -PathType Leaf) -or (Get-Sha256 $currentPath) -ne $expectedHash) {
        throw "Current source does not match the component-validation manifest: $relative"
    }
    $componentHashRecords.Add([pscustomobject]@{ path = $relative; sha256 = $expectedHash })
}

$priorPolicyRoots = @(
    (Join-Path $mailbox002Root 'policy-run-0ee4cb81069a4eaa8d8a6d5c2a9145e7'),
    (Join-Path $mailbox002Root 'policy-run-d17dd81cd7d148968245935b1bf1fbc9'),
    (Join-Path $mailbox002Root 'policy-run-a12b327eb5fb4df7ae63e31eb744b8f4')
)
foreach ($root in $priorPolicyRoots) {
    $historicalPolicyPath = Join-Path $root 'policy-evidence.json'
    if (-not (Test-Path -LiteralPath $historicalPolicyPath -PathType Leaf)) { throw "Required historical policy failure is missing: $root" }
    if ((Get-Content -LiteralPath $historicalPolicyPath -Raw | ConvertFrom-Json).passed) { throw "Historical policy-failure path unexpectedly contains a passing run: $root" }
}
$linkFailureRoot = Split-Path -Parent $linkFailurePath
if (-not (Test-Path -LiteralPath $linkFailureRoot -PathType Container)) { throw "Historical link-failure run folder is missing: $linkFailureRoot" }

if (Test-Path -LiteralPath $outputRoot) { throw "Evidence output already exists; refusing to overwrite: $outputRoot" }
if (-not (Test-Path -LiteralPath $outputParent -PathType Container)) { New-Item -ItemType Directory -Path $outputParent | Out-Null }
$stageRoot = Get-ContainedPath $outputParent (Join-Path $outputParent ('.132-associated-arena-comparison-stage-' + [Guid]::NewGuid().ToString('N')))
$contentRoot = Get-ContainedPath $stageRoot (Join-Path $stageRoot 'content')
New-Item -ItemType Directory -Path $contentRoot -Force | Out-Null
$zipPath = Get-ContainedPath $stageRoot (Join-Path $stageRoot $archiveName)
$script:archiveFiles = [System.Collections.Generic.List[object]]::new()
$script:archivePaths = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::Ordinal)

function Add-ArchiveFile([string]$SourcePath, [string]$ArchiveRelative, [string]$Category, [string]$ExpectedSha256 = '') {
    $sourceFull = [System.IO.Path]::GetFullPath($SourcePath)
    if (-not (Test-Path -LiteralPath $sourceFull -PathType Leaf)) { throw "Required evidence file is missing: $sourceFull" }
    $sourceRelative = Get-RepoRelative $sourceFull
    $portable = $ArchiveRelative.Replace('\', '/')
    if ([System.IO.Path]::IsPathRooted($portable) -or $portable.Split('/') -contains '..' -or
        $portable.Split('/') -contains '' -or -not $script:archivePaths.Add($portable)) {
        throw "Archive path is rooted, invalid, or duplicated: $portable"
    }
    $extension = [System.IO.Path]::GetExtension($portable).ToLowerInvariant()
    if ($extension -in @('.exe', '.dll', '.pdb', '.obj', '.lib', '.so', '.a', '.o', '.dylib', '.class', '.jar', '.zip')) {
        throw "Binary/build output is not permitted in the evidence archive: $portable"
    }
    $segments = $portable.Split('/')
    if ($segments | Where-Object { $_ -in @('bin', 'obj', 'dotnet-artifacts', 'repo-temp', 'tmp', 'MSBuildTemp', 'NuGetScratch', 'native-O0', 'native-O2') }) {
        throw "Build cache/output tree is not permitted in the evidence archive: $portable"
    }
    $sourceHash = Get-Sha256 $sourceFull
    if ($ExpectedSha256 -and $sourceHash -ne $ExpectedSha256.ToLowerInvariant()) { throw "Source hash changed before archive copy: $sourceRelative" }
    $destination = Join-Path $contentRoot ($portable.Replace('/', [System.IO.Path]::DirectorySeparatorChar))
    New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
    Copy-Item -LiteralPath $sourceFull -Destination $destination
    $copiedInfo = Get-Item -LiteralPath $destination
    $copiedHash = Get-Sha256 $destination
    if ($copiedHash -ne $sourceHash -or $copiedInfo.Length -ne (Get-Item -LiteralPath $sourceFull).Length) { throw "Evidence copy verification failed: $portable" }
    $script:archiveFiles.Add([ordered]@{ source = $sourceRelative; archive = $portable; category = $Category; bytes = [long]$copiedInfo.Length; sha256 = $copiedHash })
}

function Test-AllowedTextExtension([string]$Path) {
    return [System.IO.Path]::GetExtension($Path).ToLowerInvariant() -in @('.json', '.txt', '.log', '.ll', '.c', '.h', '.md', '.ps1')
}

function Test-ExcludedTreeSegment([string]$Name) {
    return $Name -in @('bin', 'obj', 'dotnet-artifacts', 'repo-temp', 'tmp', 'MSBuildTemp', 'NuGetScratch', 'native-O0', 'native-O2')
}

function Add-TextTree([string]$RunRoot, [string]$ArchivePrefix, [string]$Category) {
    $rootFull = [System.IO.Path]::GetFullPath($RunRoot)
    [void](Get-RepoRelative $rootFull)
    if (-not (Test-Path -LiteralPath $rootFull -PathType Container)) { throw "Evidence run folder is missing: $rootFull" }
    $pending = [System.Collections.Generic.Stack[string]]::new()
    $pending.Push($rootFull)
    while ($pending.Count -gt 0) {
        $current = $pending.Pop()
        foreach ($directory in (Get-ChildItem -LiteralPath $current -Directory -Force)) {
            if (-not (Test-ExcludedTreeSegment $directory.Name)) { $pending.Push($directory.FullName) }
        }
        foreach ($file in (Get-ChildItem -LiteralPath $current -File -Force)) {
            if (-not (Test-AllowedTextExtension $file.FullName)) { continue }
            $relative = [System.IO.Path]::GetRelativePath($rootFull, $file.FullName).Replace('\', '/')
            $archiveRelative = "$ArchivePrefix/$relative"
            Add-ArchiveFile $file.FullName $archiveRelative $Category
        }
    }
}

function Add-RunTopLevel([string]$EvidencePath, [string]$Label, [string]$Category) {
    $runRoot = Split-Path -Parent ([System.IO.Path]::GetFullPath($EvidencePath))
    $archivePrefix = "focused/$Label"
    foreach ($file in (Get-ChildItem -LiteralPath $runRoot -File -Force | Where-Object { Test-AllowedTextExtension $_.FullName } | Sort-Object Name)) {
        Add-ArchiveFile $file.FullName "$archivePrefix/$($file.Name)" $Category
    }
    foreach ($optimization in @('O0', 'O2')) {
        $moduleRoot = Join-Path $runRoot "module-$optimization"
        if (-not (Test-Path -LiteralPath $moduleRoot -PathType Container)) { throw "Generated $optimization module folder is missing: $moduleRoot" }
        $manifest = Join-Path $moduleRoot 'owning-mailbox-module-manifest.json'
        if (-not (Test-Path -LiteralPath $manifest -PathType Leaf)) { throw "Generated module manifest is missing: $manifest" }
        foreach ($file in (Get-ChildItem -LiteralPath $moduleRoot -File | Where-Object { $_.Extension -in @('.ll', '.c') } | Sort-Object Name)) {
            Add-ArchiveFile $file.FullName "$archivePrefix/module-$optimization/$($file.Name)" 'generated-llvm-c'
        }
        Add-ArchiveFile $manifest "$archivePrefix/module-$optimization/owning-mailbox-module-manifest.json" 'generated-module-manifest'
        $entryRoot = Join-Path $moduleRoot 'entries'
        if (-not (Test-Path -LiteralPath $entryRoot -PathType Container)) { throw "Generated entry IR folder is missing: $entryRoot" }
        foreach ($file in (Get-ChildItem -LiteralPath $entryRoot -File | Where-Object { $_.Name -like '*.frame.ll' -or $_.Name -like '*.verified-ir.txt' } | Sort-Object Name)) {
            Add-ArchiveFile $file.FullName "$archivePrefix/module-$optimization/entries/$($file.Name)" 'verified-entry-ir'
        }
    }
}

function Add-RegressionRun([string]$EvidencePath, [string]$Prefix, [string]$Category) {
    $root = Split-Path -Parent $EvidencePath
    $evidence = Get-Content -LiteralPath $EvidencePath -Raw | ConvertFrom-Json
    if (-not $evidence.passed) { throw "Referenced regression evidence failed: $EvidencePath" }
    Add-TextTree $root $Prefix $Category
}

try {
    # Final focused evidence and their generated C/LLVM/manifests/verified IR.
    Add-ArchiveFile $PSCommandPath '.agentlang/owning-mailbox-002/Archive-Evidence.ps1' 'archive-tooling'
    Add-RunTopLevel $ordinaryPath ("ordinary-" + [string]$ordinary.runId) 'final-ordinary-policy-control'
    Add-RunTopLevel $policyPath ("policy-" + [string]$policy.runId) 'final-keep-associated-policy'
    foreach ($record in $sourceRecords) {
        Add-ArchiveFile $record.path "source-snapshots/$($record.relative)" 'union-final-gate-source' $record.sha256
    }

    # Direct C checks and the reviewed implementation contract are retained as
    # text evidence together with their matching before/after source manifests.
    foreach ($file in (Get-ChildItem -LiteralPath $componentValidationRoot -File | Where-Object { Test-AllowedTextExtension $_.FullName } | Sort-Object Name)) {
        Add-ArchiveFile $file.FullName "component-validation/$($file.Name)" 'direct-component-validation'
    }
    foreach ($name in @('implementation-contract.md', 'prefix-safety-review.md', 'Run-RegressionChecks.ps1')) {
        $path = Join-Path $mailbox002Root $name
        Add-ArchiveFile $path "review-and-gate-notes/$name" 'review-note'
    }

    # Preserve the first Milestone 132 integrated link failure and earlier
    # associated-policy setup failures as history, never as passing evidence.
    Add-TextTree $linkFailureRoot 'historical/link-failure-c29be5bedfca451c84ec61057e7c3b0a' 'historical-link-failure'
    foreach ($root in $priorPolicyRoots) {
        $runId = (Split-Path -Leaf $root) -replace '^policy-run-', ''
        Add-TextTree $root "historical/policy-failure-$runId" 'historical-policy-failure'
    }

    # The current 002 terminal regression records, commands, logs, and the
    # specific JSON runs named by the owning-stack/native-dispatch logs.
    Add-ArchiveFile $checksPath 'regression/checks.json' 'terminal-regression'
    foreach ($check in $regressionChecks) {
        $name = ([string]$check.name) -replace '[^A-Za-z0-9._-]', '_'
        Add-ArchiveFile ([string]$check.log) "regression/logs/$name.log" 'terminal-regression-log'
    }
    Add-ArchiveFile $fullGatePath 'regression/validation.json' 'terminal-full-validation'
    foreach ($sidecar in (Get-ChildItem -LiteralPath $regressionRoot -File -Filter 'validation.*.json' | Sort-Object Name)) {
        Add-ArchiveFile $sidecar.FullName "regression/$($sidecar.Name)" 'terminal-validation-sidecar'
    }
    Add-ArchiveFile $llvmRegressionLog 'regression/llvm-regression.log' 'terminal-llvm-regression'
    Add-RegressionRun $owningStackEvidencePath 'regression/owning-stack-evidence' 'owning-stack-regression'
    Add-RegressionRun $nativeDispatchEvidencePath 'regression/native-dispatch-evidence' 'native-dispatch-regression'

    $payloadPaths = @($script:archiveFiles | ForEach-Object { [string]$_.archive })
    $payloadHash = Get-TreeSha256 $contentRoot $payloadPaths
    $manifest = [ordered]@{
        formatVersion = 1
        milestone = 132
        scope = 'Associated owning-arena policy comparison, direct component evidence, historical failures, and current terminal regression records.'
        focusedRuns = [ordered]@{
            ordinary = [ordered]@{ runId = [string]$ordinary.runId; passed = [bool]$ordinary.passed; checksPassed = $ordinaryCheckCount; sourceRecords = @($ordinary.sourceInputHashes.after).Count }
            keepAssociated = [ordered]@{ runId = [string]$policy.runId; passed = [bool]$policy.passed; checksPassed = $policyCheckCount; sourceRecords = @($policy.sourceHashesAfter).Count }
            nativeChecks = $nativeCheckCounts
            unionSourceSnapshotCount = $sourceRecords.Count
            sourceHashesMatchBothRunsAndCurrent = $true
        }
        terminalRegression = [ordered]@{
            stepCount = $regressionChecks.Count
            allStepsPassed = $true
            stepNames = @($stepNames)
            fullValidationPassed = [bool]$fullGate.passed
            fullValidationChecksPassed = $fullGateCheckCount
            llvmAssertionCount = [int]([regex]::Match($llvmLogText, 'AgentLang\.Llvm\.Tests:\s*(\d+)\s+assertions passed').Groups[1].Value)
        }
        componentValidation = [ordered]@{
            sourceRecordCount = $componentHashRecords.Count
            beforeAfterManifestsByteIdentical = $true
            currentFilesMatchManifest = $true
            provenance = 'The README records SHA-256 manifests immediately before and after the direct C rerun; the manifests match byte-for-byte, and archive preflight independently checked all 12 listed files against the current checkout.'
        }
        historicalFailures = @('link-failure-c29be5bedfca451c84ec61057e7c3b0a', 'policy-failure-0ee4cb81069a4eaa8d8a6d5c2a9145e7', 'policy-failure-d17dd81cd7d148968245935b1bf1fbc9', 'policy-failure-a12b327eb5fb4df7ae63e31eb744b8f4')
        uncompressedPayloadSha256 = $payloadHash
        uncompressedPayloadHashAlgorithm = 'SHA-256 of sorted UTF-8 relative path, NUL, raw file bytes, NUL; internal manifest excluded.'
        files = @($script:archiveFiles | Sort-Object { $_.archive })
    }
    $manifestPath = Join-Path $contentRoot 'manifest.json'
    Write-Utf8Lf $manifestPath ($manifest | ConvertTo-Json -Depth 12)

    Add-Type -AssemblyName System.IO.Compression
    $zipStream = [System.IO.File]::Open($zipPath, [System.IO.FileMode]::CreateNew, [System.IO.FileAccess]::ReadWrite, [System.IO.FileShare]::None)
    try {
        $zip = [System.IO.Compression.ZipArchive]::new($zipStream, [System.IO.Compression.ZipArchiveMode]::Create, $false)
        try {
            $contentFiles = @(Get-ChildItem -LiteralPath $contentRoot -File -Recurse | ForEach-Object {
                [pscustomobject]@{ FullName = $_.FullName; Relative = [System.IO.Path]::GetRelativePath($contentRoot, $_.FullName).Replace('\', '/') }
            } | Sort-Object Relative)
            foreach ($file in $contentFiles) {
                $entry = $zip.CreateEntry($file.Relative, [System.IO.Compression.CompressionLevel]::Optimal)
                $entry.LastWriteTime = [System.DateTimeOffset]::new(1980, 1, 1, 0, 0, 0, [System.TimeSpan]::Zero)
                $entryStream = $entry.Open()
                $inputStream = [System.IO.File]::OpenRead($file.FullName)
                try { $inputStream.CopyTo($entryStream) } finally { $inputStream.Dispose(); $entryStream.Dispose() }
            }
        } finally { $zip.Dispose() }
    } finally { $zipStream.Dispose() }

    $zipHash = Get-Sha256 $zipPath
    $zipReadStream = [System.IO.File]::OpenRead($zipPath)
    try {
        $readZip = [System.IO.Compression.ZipArchive]::new($zipReadStream, [System.IO.Compression.ZipArchiveMode]::Read, $false)
        try {
            if ($readZip.Entries.Count -ne ($script:archiveFiles.Count + 1)) { throw 'ZIP entry count differs from payload manifest.' }
            foreach ($record in $script:archiveFiles) {
                $entry = $readZip.GetEntry([string]$record.archive)
                if ($null -eq $entry -or $entry.Length -ne [long]$record.bytes) { throw "ZIP entry missing or wrong size: $($record.archive)" }
                $entryStream = $entry.Open()
                $sha = [System.Security.Cryptography.SHA256]::Create()
                try { $entryHash = [System.Convert]::ToHexString($sha.ComputeHash($entryStream)).ToLowerInvariant() } finally { $sha.Dispose(); $entryStream.Dispose() }
                if ($entryHash -ne [string]$record.sha256) { throw "ZIP entry SHA-256 mismatch: $($record.archive)" }
            }
            $manifestEntry = $readZip.GetEntry('manifest.json')
            if ($null -eq $manifestEntry) { throw 'ZIP is missing its internal manifest.' }
            $manifestStream = $manifestEntry.Open()
            $manifestSha = [System.Security.Cryptography.SHA256]::Create()
            try { $manifestHash = [System.Convert]::ToHexString($manifestSha.ComputeHash($manifestStream)).ToLowerInvariant() } finally { $manifestSha.Dispose(); $manifestStream.Dispose() }
        } finally { $readZip.Dispose() }
    } finally { $zipReadStream.Dispose() }
    if ((Get-Sha256 $zipPath) -ne $zipHash) { throw 'ZIP SHA-256 changed during verification.' }
    foreach ($record in $sourceRecords) {
        if ((Get-Sha256 $record.path) -ne $record.sha256) { throw "Source changed while packaging: $($record.relative)" }
    }

    $index = [ordered]@{
        formatVersion = 1
        phase = 'final'
        scope = $manifest.scope
        archive = $archiveName
        archiveSha256 = $zipHash
        manifestSha256 = $manifestHash
        uncompressedPayloadSha256 = $payloadHash
        uncompressedPayloadHashAlgorithm = $manifest.uncompressedPayloadHashAlgorithm
        archivedPayloadFileCount = $script:archiveFiles.Count
        archiveEntryCount = $script:archiveFiles.Count + 1
        ordinaryChecks = $ordinaryCheckCount
        policyChecks = $policyCheckCount
        nativeChecks = $nativeCheckCounts
        terminalRegressionSteps = $regressionChecks.Count
        fullValidationChecks = $fullGateCheckCount
        files = @($script:archiveFiles | Sort-Object { $_.archive })
    }
    $indexPath = Join-Path $stageRoot $indexName
    Write-Utf8Lf $indexPath ($index | ConvertTo-Json -Depth 12)
    $indexHash = Get-Sha256 $indexPath
    Write-Utf8Lf (Join-Path $stageRoot "$archiveName.sha256") "$zipHash  $archiveName`n"
    Write-Utf8Lf (Join-Path $stageRoot "$indexName.sha256") "$indexHash  $indexName`n"
    Write-Utf8Lf (Join-Path $stageRoot 'uncompressed-payload.sha256') "$payloadHash  $archiveName (payload digest; see index algorithm)`n"

    # The output is published only after all copies, ZIP entries and source
    # snapshots verify; deleting this invocation's temporary payload is bounded.
    $contentRootFull = Get-ContainedPath $stageRoot $contentRoot
    Remove-Item -LiteralPath $contentRootFull -Recurse -Force
    Move-Item -LiteralPath $stageRoot -Destination $outputRoot
    [pscustomobject]@{
        archive = Join-Path $outputRoot $archiveName
        archiveSha256 = $zipHash
        index = Join-Path $outputRoot $indexName
        indexSha256 = $indexHash
        archivedPayloadFiles = $script:archiveFiles.Count
        archiveEntries = $script:archiveFiles.Count + 1
        ordinaryChecks = $ordinaryCheckCount
        policyChecks = $policyCheckCount
        terminalRegressionSteps = $regressionChecks.Count
        fullValidationChecks = $fullGateCheckCount
        unionSourceHashesMatched = $sourceRecords.Count
    } | ConvertTo-Json -Depth 4
} catch {
    if (Test-Path -LiteralPath $stageRoot) {
        $stageRootFull = Get-ContainedPath $outputParent $stageRoot
        Remove-Item -LiteralPath $stageRootFull -Recurse -Force
    }
    throw
}

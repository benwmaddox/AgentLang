# Type discovery 232 implementation receipt

Changed files:
- `src/AgentLang.Core/Runtime.fs`: `describe(type)` now appends deterministic `generatedOperations` from the effective runtime snapshot's `WordEntry.Builtin` ownership tags. Each entry uses the active word's actual name, input/output signature, effects, and Flow/2 call-reference metadata; it adds operation kind and record field, enum case, or ordered named record-constructor parameters as applicable. A shadowed generated entry is absent from the effective snapshot and is not advertised.
- `src/AgentLang.Core/AuthoringHelp.fs`: documents generated operation discovery and exact Flow/2 references.
- `tests/AgentLang.Flow.Runtime.Tests/Program.fs`: checks record, scalar, and enum metadata; checks `describe(word)` agreement and executable advertised references; verifies named record arguments in reversed order map to the right fields; checks deterministic metadata after commit/reload; confirms define responses still list authored words only.

Validation:
- `dotnet build tests/AgentLang.Flow.Runtime.Tests/AgentLang.Flow.Runtime.Tests.fsproj --no-restore -m:1 -c Release -v:minimal` — exit 0, zero warnings/errors. This used the existing audited-success NuGet assets; it is not fresh restore/audit evidence.
- `dotnet run --no-build --no-restore --project tests/AgentLang.Flow.Runtime.Tests/AgentLang.Flow.Runtime.Tests.fsproj -c Release`, with `TEMP` and `TMP` set to `.agentlang/type-discovery-232/implementation/temp` — exit 0; 45 groups and 2,351 assertions passed.
- `git diff --check` — exit 0.

Restore and environment notes: ordinary run/restore attempts failed before emitting compiler diagnostics (`Build FAILED`, zero reported errors); raw outputs are retained in `restore-normal.log` and `restore-diagnostic.log`. The initial test execution also failed before the suite reached these changes because the sandbox denied its default system-temp path; `flow-runtime-run-no-build.log` records that attempt. The passing run used only a workspace-local temp override. No Flow parser source was changed, so the separate Flow parser suite was not run here; root owns full serial validation.

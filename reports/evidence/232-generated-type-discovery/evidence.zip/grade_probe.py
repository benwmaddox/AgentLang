import hashlib
import json
from pathlib import Path

repo = Path(__file__).resolve().parents[2]
probe = Path(__file__).parent / 'probe'
freeze = json.loads((probe / 'freeze.json').read_text(encoding='utf-8-sig'))
checks = []
def pin(path, expected):
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    checks.append({'path': str(path.relative_to(repo)), 'passed': actual == expected, 'sha256': actual})
for name, expected in freeze['sourceHashes'].items():
    pin(repo / name, expected)
for item in freeze['inputPins']:
    pin(probe / item['path'], item['sha256'])
for arm, entries in freeze['runtimePins'].items():
    for item in entries:
        pin(probe / 'runtime' / arm / item['path'], item['sha256'])
for item in freeze['seedPins']:
    pin(probe / 'seed' / item['path'], item['sha256'])
    for arm in ('current', 'previous'):
        pin(probe / 'actors' / arm / item['path'], item['sha256'])
results = []
for arm in ('current', 'previous'):
    trace = [json.loads(line) for line in (probe / 'traces' / (arm + '.jsonl')).read_text(encoding='utf-8-sig').splitlines()]
    exchanges = [row for row in trace if row['event'] == 'exchange']
    end = [row for row in trace if row['event'] == 'session-end'][-1]
    start = trace[0]
    responses = [json.loads(row['response']['canonical']) for row in exchanges if row.get('response', {}).get('source') == 'runtime']
    passed = any(r.get('ok') is True and r.get('kind') == 'eval' and r.get('data', {}).get('stackTypes') == ['RenewalTiming'] and r.get('data', {}).get('stack') == ['RenewalTiming { at = 10, expires-at = 20 }'] and r.get('data', {}).get('effects') == {} for r in responses)
    results.append({'arm': arm, 'passed': passed, 'exchanges': len(exchanges), 'operations': [r['operation'] for r in exchanges], 'rejectedResponses': sum(r.get('ok') is False for r in responses), 'requestWireBytes': sum(r['request']['wireUtf8Bytes'] for r in exchanges), 'responseWireBytes': sum(r['response']['wireUtf8Bytes'] for r in exchanges), 'startedUtc': start['startedUtc'], 'finishedUtc': end['finishedUtc'], 'terminationKind': end['terminationKind'], 'hostExitCode': end['hostExitCode'], 'runtimeExitCode': end['runtimeExitCode']})
result = {'schemaVersion': 1, 'pinChecksPassed': all(c['passed'] for c in checks), 'pinChecks': checks, 'results': results, 'limitations': 'Single tiny discovery task, fixed current-first order; protocol bytes are not LLM token usage; no causal efficacy conclusion or OS-confinement claim.'}
(probe / 'results.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'pinChecksPassed': result['pinChecksPassed'], 'pinCount': len(checks), 'results': results}, indent=2))
assert result['pinChecksPassed']
assert all(r['terminationKind'] == 'host-close' and r['hostExitCode'] == 0 and r['runtimeExitCode'] == 0 for r in results)

# Type discovery 232 plan

## Finding

The trace used the type name as a callable and guessed `RenewalTiming.new`. Records are described by type name (`describe` with `type: "RenewalTiming"`); generated Flow dictionary words are separate operations. `Runtime.makeGenerated` lowercases only the first character of a record type name, so the constructor is `renewalTiming.new`, with field accessors such as `renewalTiming.At` and `renewalTiming.ExpiresAt`. For Flow/2, the exact constructor reference is obtained from the word description and has leading-dot spelling, normally `.renewalTiming.new`.

## Existing discovery and authoritative metadata

- `Protocol.parseRequest` is a generic JSON request parser; `Runtime.Engine.Dispatch` owns the operations. No separate protocol operation is needed.
- `describe` already accepts exactly one `word` or `type`. `describe(type)` returns checked type metadata including ordered fields and canonical type names, type kind, source hash, revision, and validator metadata. `describe(word)` returns an individual operation's exact name, input/output types, effects, generated-vs-authored kind, and `flowReference` plus its syntax version or unavailability reason.
- `words` lists effective dictionary words, including generated words; `compact: true` returns names only. `search` can find a known name or signature. `context` is a bounded word-rooted dependency/type view; its record nodes expose fields but do not associate them with generated operations. `source` can return the authored type source.
- The authoritative type-to-word relationship is the `Runtime.makeGenerated` map. It creates `WordEntry` values tagged with `Builtin.RecordConstructor typeName` or `Builtin.RecordAccessor(typeName, fieldName)` (and corresponding scalar/enum tags). `Core.fs` defines those tags and the semantic `RecordDefinition` / `RecordField` values. The generated entry's `Definition.Name`, `Inputs`, `Outputs`, and `Effects` are the actual dictionary metadata. Record constructor input names are the declared field names in `RecordDefinition.Fields` order; the generated word signature itself stores only input types.
- `FlowParser.describeCallReference` is the authoritative validator/formatter for exact Flow/2 calls; it returns an optional reference and an explanation when no ordinary exact call exists. `Compiler.buildGeneratedTargets` consumes the same generated-word tags to create executable IR operations, but does not need to participate in description formatting.

The define response does **not** currently list generated names. Flow project responses list explicitly declared words and type names (or type names with source hashes for type evolution); one-word responses list that authored word. Stack define responses list parsed authored words. Generated operations are queryable afterward through `words` and `describe`, but the define response does not associate them with the type.

## Smallest useful change

Extend the existing `describe(type)` JSON additively with a deterministic `generatedOperations` array, retaining the current `fields` shape. Build entries by filtering the current effective snapshot's `Words` on their `Builtin` owner tags, rather than duplicating `lowerFirst` or concatenating names in the serializer. Use each generated entry's real name and signature, and `FlowParser.describeCallReference` for its exact Flow/2 reference. For record constructors, include ordered `{name, type}` parameters from the record fields so an agent can form named constructor arguments; include the associated field on each record accessor. If the response covers scalar and enum types too, use the existing scalar constructor/accessor and enum-case tags in the same array. Carry `flowReferenceSyntaxVersion: 2`; preserve null plus `flowReferenceUnavailableReason` when the reference helper rejects a name. This is read-only metadata and adds no language effects or new operation.

Affected files for implementation are `src/AgentLang.Core/Runtime.fs` (type description serialization), `src/AgentLang.Core/AuthoringHelp.fs` (discovery guidance), and `tests/AgentLang.Flow.Runtime.Tests/Program.fs` (runtime contract tests). `Protocol.fs`, `Core.fs`, `Compiler.fs`, and generated-name rules should remain unchanged. Keep the define response as the list of requested authored changes; use the enriched type description for generated capabilities.

## Focused validation

Extend `testSemanticTypeInspectionAndTestAccounting` around its existing record/scalar/enum description checks and `testDescribeFlowReferences` around its generated record reference checks. Define a `RenewalTiming` record and assert that type description reports its field order/types and the exact generated constructor/accessor names. Cross-check each advertised operation against `describe(word)` signatures and Flow/2 references, then evaluate the advertised references (including a named-field constructor call) to show they resolve. Cover scalar/enum operation tags if included, and verify record metadata is unchanged after commit/reload. Confirm the define response still lists authored names only.

Run the focused runtime suite and whitespace check:

```powershell
dotnet run --project tests/AgentLang.Flow.Runtime.Tests/AgentLang.Flow.Runtime.Tests.fsproj -c Release
git diff --check
```

If the call-reference serialization path changes, also run:

```powershell
dotnet run --project tests/AgentLang.Flow.Tests/AgentLang.Flow.Tests.fsproj -c Release
```

## Risks and limits

The response change is additive but type descriptions grow by one operation entry per generated word; keep ordering deterministic and avoid copying type source or dependency graphs into each row. Constructor names and call spellings must always come from the generated snapshot and Flow reference helper, not a second naming implementation. This improves introspection but does not make record types callable or change Flow syntax; agents must call the advertised generated constructor.

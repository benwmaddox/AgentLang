from pathlib import Path
import json,hashlib,shutil,subprocess
r=Path.cwd(); p=r/'.agentlang/type-discovery-232/probe'
assert not (p/'setup.json').exists()
old=r/'.agentlang/replacement-trial-230/runtime/agentlang'
new=r/'src/AgentLang.Cli/bin/Release/net9.0'
# Run after the final full build; never rebuild private copies.
for arm,src in [('previous',old),('current',new)]:
 dest=p/'runtime'/arm; assert not dest.exists(); dest.mkdir(parents=True)
 for f in sorted(src.iterdir()):
  if f.suffix in ('.dll','.json') and f.is_file():
   assert not f.is_symlink(); shutil.copyfile(f,dest/f.name)
seed=p/'seed';assert not seed.exists();seed.mkdir()
source='record RenewalTiming {\n    at: Int\n    expires-at: Int\n}\n'
requests=[{'op':'define','frontend':'flow','syntaxVersion':2,'source':source},{'op':'commit','word':'RenewalTiming'},{'op':'describe','type':'RenewalTiming'}]
wire=''.join(json.dumps(x)+'\n' for x in requests)
(p/'seed-requests.jsonl').write_text(wire,encoding='utf-8')
run=subprocess.run(['dotnet',str(p/'runtime/previous/AgentLang.Cli.dll'),'--project',str(seed),'--jsonl'],input=wire,text=True,capture_output=True,timeout=30)
(p/'seed-responses.jsonl').write_text(run.stdout,encoding='utf-8');(p/'seed-stderr.txt').write_text(run.stderr,encoding='utf-8')
rows=[json.loads(x) for x in run.stdout.splitlines()];assert run.returncode==0 and len(rows)==3 and all(x['ok'] for x in rows),rows
assert [x['name'] for x in rows[2]['data']['fields']]==['at','expires-at']
assert 'generatedOperations' not in rows[2]['data']
for arm in ('current','previous'):
 actor=p/'actors'/arm; actor.parent.mkdir(exist_ok=True);shutil.copytree(seed,actor)
 launch=p/'launchers'/f'{arm}.ps1';launch.parent.mkdir(exist_ok=True)
 text=f'''#requires -Version 7.0
$ErrorActionPreference = 'Stop'
$repo = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../../../'))
$study = Join-Path $repo '.agentlang/type-discovery-232/probe'
& (Join-Path $repo 'scripts/Start-SubagentTrialHostV2.ps1') -CliDll (Join-Path $study 'runtime/{arm}/AgentLang.Cli.dll') -ProjectPath (Join-Path $study 'actors/{arm}') -TracePath (Join-Path $study 'traces/{arm}.jsonl') -AllowedOperations @('help','describe','words','search','eval') -Capabilities @() -ClockValue '2000-01-01T00:00:00Z' -MaxRequestBytes 16384 -MaxResponseBytes 262144 -ExchangeTimeoutMilliseconds 20000 -MaxExchanges 12
'''
 launch.write_text(text,encoding='utf-8')
 packet=p/'packets'/f'{arm}.md';packet.parent.mkdir(exist_ok=True)
 packet.write_text(f'''Run from D:\\code\\AgentLang:
`pwsh -NoProfile -ExecutionPolicy Bypass -File .agentlang/type-discovery-232/probe/launchers/{arm}.ps1`

Launch with exec_command tty:true, sandbox default. Use that same session_id for all write_stdin requests and final host.close. Poll the same handle on silence; do not restart or escalate execution to the host. Send one JSON request per line. At most 12 broker exchanges. Allowed: help, describe, words, search, eval. Use only this broker and packet, no project files, sibling data, other agents or web.

Discover the existing `RenewalTiming` record and evaluate a value with `at` equal to 10 and `expires-at` equal to 20. Return the evaluated record, using existing dictionary capabilities only; do not define or edit functions/types. No effects are granted.

`describe` accepts exactly one of `word` or `type`; use a nonempty name. `search` uses `query`; `words` accepts `compact: true`. `help` can give authoring guidance. Every eval request must include `frontend: "flow"`, `syntaxVersion: 2`, and `code`. Example shape: `{{"op":"describe","type":"SomeType"}}`. Generated call names are discoverable through the interface.

After a successful eval, send `{{"op":"host.close"}}` on the same handle and observe terminal exit. Report actual result, failures and closure. Do not coach or message other agents.
''',encoding='utf-8')
def inventory(base):
 return [{'path':x.relative_to(base).as_posix(),'bytes':x.stat().st_size,'sha256':hashlib.sha256(x.read_bytes()).hexdigest()} for x in sorted(base.rglob('*')) if x.is_file()]
setup={'study':'type-discovery-232','status':'prepared-not-dispatched','order':['current','previous'],'seed':inventory(seed),'runtimes':{arm:inventory(p/'runtime'/arm) for arm in ('current','previous')},'packets':inventory(p/'packets'),'launchers':inventory(p/'launchers'),'sourceRevision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'sourceHashes':{str(f):hashlib.sha256((r/f).read_bytes()).hexdigest() for f in ('src/AgentLang.Core/Runtime.fs','src/AgentLang.Core/AuthoringHelp.fs','tests/AgentLang.Flow.Runtime.Tests/Program.fs')},'security':'Sandbox-only pure interpreter evaluations; no extra effects/packages/native execution. Broker rules are not OS confinement.'}
(p/'setup.json').write_text(json.dumps(setup,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':setup['status'],'seedFiles':len(setup['seed']),'runtimeFiles':{k:len(v) for k,v in setup['runtimes'].items()}}))

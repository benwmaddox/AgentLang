Run from D:\code\AgentLang:
`pwsh -NoProfile -ExecutionPolicy Bypass -File .agentlang/type-discovery-232/probe/launchers/current.ps1`

Launch with exec_command tty:true, sandbox default. Use that same session_id for all write_stdin requests and final host.close. Poll the same handle on silence; do not restart or escalate execution to the host. Send one JSON request per line. At most 12 broker exchanges. Allowed: help, describe, words, search, eval. Use only this broker and packet, no project files, sibling data, other agents or web.

Discover the existing `RenewalTiming` record and evaluate a value with `at` equal to 10 and `expires-at` equal to 20. Return the evaluated record, using existing dictionary capabilities only; do not define or edit functions/types. No effects are granted.

`describe` accepts exactly one of `word` or `type`; use a nonempty name. `search` uses `query`; `words` accepts `compact: true`. `help` can give authoring guidance. Every eval request must include `frontend: "flow"`, `syntaxVersion: 2`, and `code`. Example shape: `{"op":"describe","type":"SomeType"}`. Generated call names are discoverable through the interface.

After a successful eval, send `{"op":"host.close"}` on the same handle and observe terminal exit. Report actual result, failures and closure. Do not coach or message other agents.

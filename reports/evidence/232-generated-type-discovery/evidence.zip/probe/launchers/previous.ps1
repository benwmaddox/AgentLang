#requires -Version 7.0
$ErrorActionPreference = 'Stop'
$repo = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../../../'))
$study = Join-Path $repo '.agentlang/type-discovery-232/probe'
$scratch = Join-Path $study 'scratch/previous'
[IO.Directory]::CreateDirectory($scratch) | Out-Null
$env:TEMP = $scratch
$env:TMP = $scratch
$env:MSBuildEnableWorkloadResolver = 'false'
& (Join-Path $repo 'scripts/Start-SubagentTrialHostV2.ps1') -CliDll (Join-Path $study 'runtime/previous/AgentLang.Cli.dll') -ProjectPath (Join-Path $study 'actors/previous') -TracePath (Join-Path $study 'traces/previous.jsonl') -AllowedOperations @('help','describe','words','search','eval') -Capabilities @() -ClockValue '2000-01-01T00:00:00Z' -MaxRequestBytes 16384 -MaxResponseBytes 262144 -ExchangeTimeoutMilliseconds 20000 -MaxExchanges 12

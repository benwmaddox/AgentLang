# Plan: declare test-case edits in atomic Flow replacements

## Finding

Report 231 failed inherited-input preservation because an unrelated value in the existing `subscription.renew-batch-step/errors` test changed from `30000000-0000-0000-0000-000000000001` to `33000000-0000-0000-0000-000000000001`. That case did not call the migrated monthly operation, so its source did not need to change. Its result stayed the same because the case short-circuits on an already-failed state, but that masks the fixture drift.

The multiword replacement route currently accepts every inline test source in the submitted project. `registerFlowReplacementProjectParsed` builds `incomingTestsByKey`, then replaces any same-key test while retaining omitted tests. It checks owner word revisions, but not whether an incoming test edit was requested. Existing `FlowAuthoredAttachment.Source.Reference.Hash` already provides the exact prior test-source hash, so this can be enforced without a persisted schema change.

## Smallest runtime contract

Add an optional `testChanges` array to multiword Flow replacement requests. Each row declares one test-case edit:

```json
{"word":"subscription.renew-monthly","caseName":"grouped-time","action":"add"}
{"word":"subscription.renew-monthly","caseName":"existing-case","action":"replace","expectedSourceHash":"<current hash>"}
```

At the existing `registerFlowReplacementProjectParsed` staging boundary, compare each incoming test’s immutable source hash with the old attachment for that owner/case. Unchanged sources need no declaration. A changed existing source requires exactly one `replace` row with the current source hash; a newly added case requires exactly one `add` row. Reject undeclared changes, wrong or stale hashes, action/key mismatches, duplicate rows, and declarations that do not correspond to an actual change. Omitted cases remain retained as today. Run these checks before mutating candidate state, with deterministic diagnostics. Keep wrapper restrictions and example behavior unchanged.

This gives tasks a precise case-level edit boundary: requested monthly-call adaptations and an added regression remain possible, while an unrelated error-state case cannot silently drift. It does not judge the contents of a case that the request explicitly authorizes; behavior grading and source review remain responsible for that.

## Files and focused tests

- `src/AgentLang.Core/Runtime.fs`: parse and validate `testChanges` only on the atomic replacement route, reusing attachment keys and source hashes already held in `old.FlowTests` and `incomingTestsByKey`.
- `src/AgentLang.Core/AuthoringHelp.fs`: expose the new define field and document the case-level action/hash contract. Existing `tests` inspection with `includeSource: true` returns `sourceHash`, so callers can obtain the replacement token without a new operation.
- `tests/AgentLang.Flow.Runtime.Tests/Program.fs`: extend `testAtomicMultiwordFlowReplacement` with: a successful explicitly declared changed case plus declared new regression; rejection of the report-231-style undeclared unrelated fixture change; stale-hash, duplicate, wrong-action, missing-declaration, and unused-declaration failures; and assertions that rejection leaves revisions, staged candidates, and durable manifest unchanged. Retain tests showing unchanged submitted cases and omitted cases behave as before. Existing one-word replacement tests should remain unchanged if the first implementation is deliberately scoped to the multiword route.

## Acceptance and validation

The report-231 mutation is rejected before staging when not listed. The same test edit is accepted when declared with its exact current hash, and a new regression is accepted only with `action: "add"`. Invalid declarations fail atomically and deterministically. Identical inline tests and omitted retained tests continue to work; no source-content comparison is weakened.

Run the focused suite and whitespace check:

```powershell
dotnet run --project tests/AgentLang.Flow.Runtime.Tests/AgentLang.Flow.Runtime.Tests.fsproj -c Release
git diff --check
```

## Compatibility and limits

The request shape is additive, but multiword replacements that currently change or add inline tests must include declarations. Re-sending byte-identical tests, omitting retained tests, and existing one-word edits are unaffected by the narrow first cut. Source hashes intentionally compare authored bytes, not normalized semantics, matching the inherited-source-preservation requirement. Case-level authorization prevents unrelated-case drift; it does not prevent an inappropriate fixture edit inside a case explicitly authorized for migration.

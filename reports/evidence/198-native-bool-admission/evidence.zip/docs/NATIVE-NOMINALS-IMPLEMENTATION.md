# Native nominal scalar implementation plan

2026-10-10. The first nominal Int slice is complete and validated in
[report 170](../reports/170-native-nominal-int.md): 521 LLVM assertions, 94
independent nominal cases across O0/O2, mailbox regressions and all 37 full local
Release checks pass. Predicate-bearing Int also passes its independent native,
mailbox-regression and full local gates in report 172. The bounded validated
String scope below is tracked by report 174; general Email validation remains
subsequent work. The verified semantic IR remains authoritative.

[Report 172](../reports/172-native-refined-int.md) completes ordinary owning
predicate-bearing Int: 595 LLVM assertions, 44 independent native checks, 1,587
mailbox regressions and all 37 full local Release checks pass. Ordinary raw host
inputs run the frozen predicate over active nested values before executing the
body. Refined mailbox layouts remain rejected until their own external ingress
is validated. Nominal identity alone is not sufficient at either boundary.

## Delivery order

First preserve unvalidated nominal Int identity, such as OrderId or Meters,
including supported record and Option/Result nesting. Then implement a bounded
predicate-bearing Int refinement (PositiveId), followed by nominal String and
its predicate support. A nominal name alone is not a value-validation rule.
Unsupported refinements must continue to fail explicitly rather than executing
as their base type with validation omitted.

## First slice: nominal Int (completed in report 170)

`IrScalarTypeDefinition` already stores a base type and optional frozen validator;
IR verification checks exact generated wrap/unwrap targets and nominal identity.
The interpreter represents a scalar as its nominal key plus base value. Keep
those semantics in the selected owning descriptor backend, not the historical
fixed emitter or a source-AST execution path.

In `OwningStackAot.fs`, permit only scalar definitions with Int base and no
validator. Keep a distinct IrNominal key, source name and TypeId, with eight-byte
payload and extent. Extend block validation, stack planning, descriptor emission,
and host value measurement/encoding/decoding for generated wrap/unwrap. Wrapping
and unwrapping retag the descriptor without copying payload, preserving owner
provenance. The physical descriptor kind can remain Int; its separate TypeId
retains nominal identity. An ABI change is unnecessary unless implementation
evidence contradicts this representation.

Host input must be `NamedValue` with the exact expected name and Int payload;
reject a bare Int or another wrapper even when its bytes are identical. Host
decoding must reconstruct that name. Conservatively retain existing lifetime
origins until transfer modeling proves a rewind safe. No opportunistic rewind,
compaction, reference-counting mechanism or new source ownership syntax belongs
in this slice.

## Independent acceptance

- Interpreter and owning O0/O2 execute the same verified program/body, retaining
  nominal host inputs and outputs.
- Two distinct Int wrappers with identical bytes remain distinct types. Wrong
  accessors, bare-Int input and wrong nominal input reject atomically.
- Independent eight-byte fixtures cover zero, negative values and Int64 limits,
  with explicit distinct nominal TypeIds.
- Wrap/unwrap, ordinary calls, locals and matches introduce zero deep-copy and
  move bytes; explicit record/sum construction keeps its existing accounting.
- Records, Option and Result retain wrapped payload identity through construction,
  extraction, equality, inactive alternatives and host round trips.
- In the original Int-only slice, String/Bool/Float wrappers remain explicit
  unsupported errors, including inactive sum alternatives. Predicate-bearing Int is covered separately by
  report 172; unsupported validator forms still reject explicitly.
- Lifetime escapes and short-capacity failures preserve outputs and cleanup.
- Fresh native value-stack and applicable mailbox regression gates, plus the
  full local Release gate, pass before publication.

## Predicate-bearing Int (completed in report 172)

PositiveId must invoke the validator target frozen into the same verified IR.
Discover validator-only dependencies as well as ordinary calls; use ordinary
depth/fuel limits. Preserve the distinction between a false predicate
(`REFINEMENT_FAILED`) and a validator execution error. Validate construction,
external entry boundaries and output publication wherever the language contract
requires it; physical byte scanning does not enforce a predicate. Workspace
lifetimes and failure rollback need independent tests. Do not resolve predicates
from mutable compiler state or silently erase validation.

Record validators, Float/List wrappers and general Email predicates are later
work. This delivery order establishes partial native support while retaining
the full strong-type requirement; it does not redefine that requirement as
nominal naming alone.

## Validated String (report 174 scope)

Extend ordinary owning-native compilation to a String-backed refinement such as
NonEmptyString, with a pure frozen String -> Bool validator. Reuse the existing
dynamic UTF-16 String layout and descriptor kind; preserve distinct nominal
TypeIds, exact host identities and owner ranges. Construction and raw external
entry must validate active nested record, Option and Result payloads before the
body or output publication. Wrap/unwrap must retag without payload copying.

Independent O0/O2 acceptance must pin bytes, layout, recursive admission,
frozen validator identity, atomic failures and ownership accounting. Layout
schema 3, stack ABI 1 and module ABI 1 remain unchanged. In that slice, refined
mailbox layouts, unvalidated String wrappers and Bool/Float refinements remain
unsupported.
This slice does not establish general Email validation or add native I/O. Run
fresh LLVM, native value-stack, mailbox and full local gates before reporting
completion. [Report 174](../reports/174-native-refined-string.md) records gate
results and retained failed attempts; its status is the completion record.

## Refined mailbox admission (milestone 180 acceptance plan)

Admit the same frozen pure Int/String predicates in owning mailbox compilation.
After structural import, validate active nested State/Continuation payloads
before the external callback body. A temporary validation frame must leave on
both success and failure. Constructors validate newly produced values; avoid
blanket output predicate replay.

RETURN re-imports retained roots and validates them again. KEEP_ASSOCIATED
resumes from privately retained, previously admitted roots without replaying
their predicates. The completion remains a plain String. Keep the existing
text controller APIs: real lifecycle fixtures construct refined records from
text and test failure/retry; direct generated callbacks separately exercise
raw invalid external slices. No new host effect or controller API is required.

Structural preflight failure leaves output sentinels untouched. Later predicate
failure leaves requested descriptors invalid under the existing ABI, while
committed roots and pending tokens survive for retry. Distinguish predicate
false from validator execution failure. Pin exact nominal identities, frozen
revisions, independent bytes, active/inactive nested payloads and copy/predicate
counts across O0/O2 and both arena policies. Keep ABI/layout versions unchanged
and audit generated frame bounds. Unsupported validator forms remain explicit.

This slice is complete in [report 180](../reports/180-native-refined-mailbox.md).
It is not a security certification. Fresh focused and full LLVM, native
value-stack, mailbox/policy and applicable local I/O regression gates, plus the
full local Release gate, passed before publication.

## Next slice: unvalidated nominal String (planned after checkpoint 182)

Permit a String-backed nominal wrapper without a predicate, such as TextTag.
Validated String already uses dynamic UTF-16 payloads, exact nominal host names
and distinct TypeIds. Reuse that representation and host codecs; do not erase
identity or add a predicate to a type that declares none. The current owning
scalar admission rejects this case explicitly. Removing that rejection requires
conformance evidence, not treating it as already supported.

At O0/O2, check exact-name host round trips, rejection of bare String and another
wrapper without output mutation, nested records and active Option/Result cases,
and UTF-16 bytes including embedded NUL and isolated surrogates. Wrap/unwrap must
preserve owner ranges and introduce no payload movement or predicate invocation.
Keep layout ABI 3 and stack ABI 1 unchanged. Because mailbox layout admission
shares this path, include direct mailbox import/round-trip checks before claiming
mailbox support; run fresh native, LLVM, mailbox and full local gates.

Implementation ownership is `src/AgentLang.Llvm/OwningStackAot.fs` and
`tests/AgentLang.Llvm.Tests/Program.fs`, with independent runner/mailbox fixtures
if needed for the acceptance evidence. No allocator, source syntax or host
capability change is planned. Bool wrappers need additional codec/descriptor
work; Float requires broader numeric/ABI analysis, and List requires a larger
representation/lifetime design. These remain explicit gaps, not silent base-type
fallbacks. This is a bounded plan, not implementation completion. Implementation,
accepted validation and remaining limits are tracked in
[report 183](../reports/183-native-nominal-string.md); use its status as the
completion record.

## Bool-backed nominal and refined values (report 198)

The bounded Bool implementation and its acceptance status are tracked in
[report 198](../reports/198-native-bool-admission.md), following the reviewed
[plan 194](../reports/194-native-bool-implementation-plan.md). It extends the
selected owning descriptor backend and host codecs to exact-name Bool wrappers
with optional pure frozen predicates. The physical payload remains eight-byte
little-endian 0 or 1 with distinct nominal TypeIds. Full-payload canonicalization
must occur after the owner-bounded readability check, including active nested
values. Wrapping and unwrapping retain their retag-only behavior.

Mailbox State and Continuation remain nominal records; request and completion
inputs remain String. Test Bool ingress inside those records and directly in
ordinary native entry, rather than broadening the lifecycle signature. RETURN
reimports and validates roots; KEEP retains admitted roots without predicate
replay. Failed callbacks must publish no valid output or committed state.

This slice preserves layout schema 3 and stack/mailbox/module ABI 1. It adds no
host capability, dependency or allocator mechanism. Float/List support, general
JIT and service performance remain separate work. The earlier sections describe
their original delivery boundaries; report 198 is the current Bool status.

## Investigation references

Read-only planning inspected `TypedIR.fs` scalar definitions and generated-target
verification, `IrInterpreter.fs` wrap/unwrap execution, `LlvmAot.fs` existing
scalar/validator lowering, `OwningStackAot.fs` program inspection, block validation,
host codecs and selected dynamic descriptor emitter, and `ArenaLifetime.fs`
conservative transfer handling. Existing LLVM tests cover nominal identities,
PositiveId and frozen-validator replacement. The initial planning pass changed
no executable code. Report 170 records the subsequent first-slice implementation,
failed attempts, accepted validation and remaining boundaries.

#!/usr/bin/env python3
"""Create a deterministic, filtered evidence ZIP after all gates are accepted.

The script intentionally has no baked-in gate result or evidence paths. Supply a
manifest with this shape when packaging is authorized:

{
  "format": 1,
  "task": "native-bool-198",
  "status": "accepted",
  "retainedAttemptsComplete": true,
  "pendingGates": [],
  "acceptedGates": [{
    "name": "full-llvm", "status": "passed", "terminal": true,
    "exitCode": 0, "counts": {"assertions": 80},
    "paths": [".agentlang/.../gate.log", ".agentlang/.../gate.json"]
  }],
  "retainedAttempts": [{
    "name": "native-attempt-2", "status": "failed",
    "reason": "The returned case count was stale.",
    "paths": [".agentlang/.../verification-evidence.json"]
  }, {
    "name": "build-attempt-7", "status": "unverified", "terminal": true,
    "reason": "No text command/exit receipt was saved; the build tree is excluded.",
    "receiptAvailability": "missing", "paths": []
  }],
  "sourcePins": [{"path": "src/...", "sha256": "...", "bytes": 123}],
  "abiSnapshots": [{"path": "...", "sha256": "..."}],
  "fixtureSnapshots": [{"path": "...", "sha256": "..."}],
  "frozenTests": [{"path": "tests/...", "sha256": "..."}],
  "additionalReceipts": [{
    "path": ".agentlang/.../review.md", "role": "source-review",
    "classification": "accepted"
  }]
}

Gate records must be terminal successes with exit code zero. Every failed or
preparation attempt must be enumerated under retainedAttempts, with a terminal
status and receipt paths; the manifest's retainedAttemptsComplete flag is the
packager's completeness assertion. Retained attempts remain labeled that way
in the index. Paths may name a file or a directory; directory walks include
only approved text/source/receipt files and skip build, dependency, and cache
trees. Every explicit source/ABI/fixture/test pin is checked before packaging.
The output ZIP and its sibling `<zip-name>.index.json` are created only when
the manifest has status "accepted", pendingGates is empty, and every listed
gate passes these checks.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import pathlib
import tempfile
import zipfile
from typing import Any


ALLOWED_SUFFIXES = {
    ".c", ".cc", ".csv", ".diff", ".flow", ".fs", ".fsx", ".h",
    ".json", ".jsonl", ".ll", ".log", ".md", ".patch", ".ps1",
    ".py", ".rst", ".sh", ".txt", ".toml", ".xml", ".yaml", ".yml",
}
EXCLUDED_PARTS = {
    ".git", ".nuget", "__pycache__", "bin", "build", "dist", "node_modules",
    "obj", "packages", "target", "temp", "tmp", "vendor",
}
EXCLUDED_SUFFIXES = {
    ".7z", ".a", ".dll", ".exe", ".lib", ".nupkg", ".o", ".obj",
    ".pdb", ".pyc", ".so", ".zip",
}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def stable_json(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def read_json(path: pathlib.Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise ValueError(f"cannot read JSON manifest {path}: {error}") from error
    if not isinstance(value, dict):
        raise ValueError("manifest root must be a JSON object")
    return value


def require_list(manifest: dict[str, Any], key: str) -> list[dict[str, Any]]:
    value = manifest.get(key, [])
    if not isinstance(value, list) or any(not isinstance(row, dict) for row in value):
        raise ValueError(f"manifest field {key!r} must be an array of objects")
    return value


def resolve_repo_path(repo: pathlib.Path, raw: str) -> pathlib.Path:
    if not isinstance(raw, str) or not raw.strip():
        raise ValueError("every selected path must be a non-empty string")
    supplied = pathlib.Path(raw)
    path = supplied if supplied.is_absolute() else repo / supplied
    # Non-strict resolve still normalizes path components and symlinks. Strict
    # Windows resolution can fail with ACCESS_DENIED on sandboxed workspace ACLs
    # even when the selected file is readable, so existence is checked below.
    resolved = path.resolve()
    if not resolved.is_relative_to(repo):
        raise ValueError(f"path escapes repository root: {raw}")
    if not resolved.is_file() and not resolved.is_dir():
        raise ValueError(f"selected path is not a file or directory: {raw}")
    return resolved


def exclusion_reason(repo: pathlib.Path, path: pathlib.Path) -> str | None:
    relative = pathlib.PurePosixPath(path.relative_to(repo).as_posix())
    lowered = tuple(part.lower() for part in relative.parts)
    # Exclude build/dependency directories, not text receipt filenames such as
    # build-attempt20.log. The latter are important command outputs and are
    # safe to retain alongside the excluded generated build tree.
    directories = lowered[:-1]
    if any(part in EXCLUDED_PARTS or part.startswith("build-") for part in directories):
        return "build/dependency/cache path"
    if path.suffix.lower() in EXCLUDED_SUFFIXES:
        return "binary or packaged artifact suffix"
    if path.suffix.lower() not in ALLOWED_SUFFIXES:
        return "unapproved non-text file suffix"
    return None


def collect_path(
    repo: pathlib.Path,
    raw_path: str,
    role: str,
    classification: str,
    selected: dict[str, dict[str, Any]],
    skipped: list[dict[str, str]],
) -> None:
    root = resolve_repo_path(repo, raw_path)
    candidates = [root] if root.is_file() else sorted(root.rglob("*"))
    included_here = 0
    for candidate in candidates:
        if not candidate.is_file():
            continue
        path = candidate.resolve()
        if not path.is_relative_to(repo):
            raise ValueError(f"directory traversal escaped repository root: {candidate}")
        reason = exclusion_reason(repo, path)
        if reason:
            skipped.append({"path": path.relative_to(repo).as_posix(), "reason": reason})
            continue
        relative = path.relative_to(repo).as_posix()
        row = selected.setdefault(relative, {"path": relative, "roles": [], "classifications": []})
        if role not in row["roles"]:
            row["roles"].append(role)
        if classification not in row["classifications"]:
            row["classifications"].append(classification)
        included_here += 1
    if root.is_file() and included_here == 0:
        raise ValueError(f"explicit file is excluded from text evidence: {raw_path}")
    if root.is_dir() and included_here == 0:
        raise ValueError(f"selected directory contains no eligible evidence files: {raw_path}")


def verify_pin(repo: pathlib.Path, row: dict[str, Any], category: str) -> pathlib.Path:
    raw_path = row.get("path")
    path = resolve_repo_path(repo, raw_path)
    if not path.is_file():
        raise ValueError(f"{category} pin must name a file: {raw_path}")
    expected_hash = row.get("sha256")
    if not isinstance(expected_hash, str) or len(expected_hash) != 64:
        raise ValueError(f"{category} pin needs a 64-character sha256: {raw_path}")
    payload = path.read_bytes()
    observed_hash = sha256(payload)
    if observed_hash.lower() != expected_hash.lower():
        raise ValueError(f"{category} pin mismatch for {raw_path}: {observed_hash}")
    if "bytes" in row and row["bytes"] != len(payload):
        raise ValueError(f"{category} byte-length pin mismatch for {raw_path}")
    if exclusion_reason(repo, path):
        raise ValueError(f"{category} snapshot is a build/binary/non-text file: {raw_path}")
    return path


def validate_acceptance(manifest: dict[str, Any]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    if manifest.get("format") != 1:
        raise ValueError("manifest format must be 1")
    if not isinstance(manifest.get("task"), str) or not manifest["task"].strip():
        raise ValueError("manifest must identify its task")
    if manifest.get("status") != "accepted":
        raise ValueError("refusing packaging until manifest status is 'accepted'")
    if manifest.get("retainedAttemptsComplete") is not True:
        raise ValueError("manifest must confirm all failed/preparation attempts are listed")
    pending = require_list(manifest, "pendingGates")
    if pending:
        raise ValueError("refusing packaging while pendingGates is non-empty")
    accepted = require_list(manifest, "acceptedGates")
    retained = require_list(manifest, "retainedAttempts")
    if not accepted:
        raise ValueError("manifest must list at least one accepted gate")
    if not retained:
        raise ValueError("known preparation and failed attempts must be listed under retainedAttempts")
    names: set[str] = set()
    for row in accepted:
        name = row.get("name")
        if (not isinstance(name, str) or not name.strip()
                or row.get("status") != "passed"
                or row.get("terminal") is not True
                or not isinstance(row.get("exitCode"), int)
                or isinstance(row.get("exitCode"), bool)
                or row.get("exitCode") != 0):
            raise ValueError(f"accepted gate is not a terminal zero-exit pass: {name!r}")
        if name in names:
            raise ValueError(f"duplicate gate/attempt name: {name}")
        names.add(name)
        paths = row.get("paths")
        if not isinstance(paths, list) or not paths:
            raise ValueError(f"accepted gate {name!r} must select at least one receipt path")
    for row in retained:
        name = row.get("name")
        if not isinstance(name, str) or not name.strip():
            raise ValueError("every retained attempt needs a name")
        if name in names:
            raise ValueError(f"duplicate gate/attempt name: {name}")
        names.add(name)
        if row.get("terminal") is not True:
            raise ValueError(f"retained attempt {name!r} is not marked terminal")
        attempt_status = row.get("status")
        if not isinstance(attempt_status, str) or not attempt_status.strip() or attempt_status.strip().lower() in {
            "passed", "pass", "accepted", "success", "succeeded", "running", "pending",
        }:
            raise ValueError(f"retained attempt {name!r} needs a terminal failure/preparation status")
        if not isinstance(row.get("reason"), str) or not row["reason"].strip():
            raise ValueError(f"retained attempt {name!r} needs a reason")
        paths = row.get("paths")
        if not isinstance(paths, list):
            raise ValueError(f"retained attempt {name!r} paths must be an array")
        if paths and row.get("receiptAvailability", "present") not in {"present", "partial"}:
            raise ValueError(f"retained attempt {name!r} has paths but is marked receipt-missing")
        if not paths and row.get("receiptAvailability") != "missing":
            raise ValueError(f"retained attempt {name!r} without paths must explicitly record receiptAvailability='missing'")
    return accepted, retained


def make_member_set(
    repo: pathlib.Path,
    manifest_path: pathlib.Path,
    manifest: dict[str, Any],
    accepted: list[dict[str, Any]],
    retained: list[dict[str, Any]],
    output: pathlib.Path,
) -> tuple[dict[str, dict[str, Any]], list[dict[str, str]]]:
    selected: dict[str, dict[str, Any]] = {}
    skipped: list[dict[str, str]] = []

    def add(raw: str, role: str, classification: str) -> None:
        collect_path(repo, raw, role, classification, selected, skipped)

    add(manifest_path.relative_to(repo).as_posix(), "packaging-manifest", "manifest")
    for gate in accepted:
        for raw in gate["paths"]:
            add(raw, f"accepted-gate:{gate['name']}", "accepted")
    for attempt in retained:
        for raw in attempt["paths"]:
            add(raw, f"retained-attempt:{attempt['name']}", "retained")

    for field, classification in (
        ("sourcePins", "frozen-source"),
        ("abiSnapshots", "abi-snapshot"),
        ("fixtureSnapshots", "fixture-snapshot"),
        ("frozenTests", "frozen-test"),
    ):
        for pin in require_list(manifest, field):
            path = verify_pin(repo, pin, field)
            add(path.relative_to(repo).as_posix(), field, classification)

    for receipt in require_list(manifest, "additionalReceipts"):
        role = receipt.get("role")
        classification = receipt.get("classification")
        if not isinstance(role, str) or not role.strip():
            raise ValueError("each additional receipt needs a role")
        if classification not in {"accepted", "retained", "frozen"}:
            raise ValueError(f"invalid additional receipt classification for {receipt.get('path')}")
        add(receipt.get("path"), role, classification)

    output_relative = output.relative_to(repo).as_posix()
    index_relative = (output.parent / (output.name + ".index.json")).relative_to(repo).as_posix()
    if output_relative in selected or index_relative in selected:
        raise ValueError("output ZIP/index path is also selected as input evidence")
    return dict(sorted(selected.items())), skipped


def write_atomic(path: pathlib.Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    temporary = pathlib.Path(temporary_name)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        temporary.replace(path)
    finally:
        if temporary.exists():
            temporary.unlink()


def package(repo: pathlib.Path, manifest_arg: str, output_arg: str) -> dict[str, Any]:
    repo = repo.resolve()
    if not repo.is_dir():
        raise ValueError(f"repository root is not a directory: {repo}")
    manifest_path = resolve_repo_path(repo, manifest_arg)
    if not manifest_path.is_file():
        raise ValueError("manifest must be a file")
    manifest = read_json(manifest_path)
    accepted, retained = validate_acceptance(manifest)

    output_input = pathlib.Path(output_arg)
    output = (output_input if output_input.is_absolute() else repo / output_input).resolve()
    if not output.is_relative_to(repo):
        raise ValueError("output path must stay inside repository root")
    if output.suffix.lower() != ".zip":
        raise ValueError("output path must end in .zip")
    index_path = output.with_name(output.name + ".index.json")
    if output.exists() or index_path.exists():
        raise FileExistsError(f"refusing to overwrite existing package: {output} or {index_path}")

    members, skipped = make_member_set(repo, manifest_path, manifest, accepted, retained, output)
    output.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix=output.name + ".", suffix=".tmp", dir=output.parent)
    os.close(descriptor)
    temporary_zip = pathlib.Path(temporary_name)
    member_rows: list[dict[str, Any]] = []
    try:
        with zipfile.ZipFile(temporary_zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for name, metadata in members.items():
                payload = (repo / pathlib.PurePosixPath(name)).read_bytes()
                info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o100644 << 16
                archive.writestr(info, payload, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
                member_rows.append({
                    "path": name,
                    "bytes": len(payload),
                    "sha256": sha256(payload),
                    "roles": sorted(metadata["roles"]),
                    "classifications": sorted(metadata["classifications"]),
                })

        with zipfile.ZipFile(temporary_zip, "r") as archive:
            names = archive.namelist()
            if names != sorted(members) or archive.testzip() is not None:
                raise ValueError("archive membership, ordering, or CRC verification failed")
            expected = {row["path"]: row for row in member_rows}
            for name in names:
                payload = archive.read(name)
                row = expected[name]
                if len(payload) != row["bytes"] or sha256(payload) != row["sha256"]:
                    raise ValueError(f"archive member hash/length mismatch: {name}")
                if exclusion_reason(repo, repo / pathlib.PurePosixPath(name)):
                    raise ValueError(f"excluded binary/build member entered archive: {name}")

        archive_bytes = temporary_zip.read_bytes()
        index = {
            "format": 1,
            "task": manifest["task"],
            "status": "verified",
            "acceptance": {
                "manifestStatus": manifest["status"],
                "retainedAttemptsComplete": manifest["retainedAttemptsComplete"],
                "acceptedGates": accepted,
                "retainedAttempts": retained,
            },
            "receiptGaps": [
                {"name": row["name"], "status": row["status"], "reason": row["reason"]}
                for row in retained if row.get("receiptAvailability") == "missing"
            ],
            "sourceFreeze": manifest.get("sourceFreeze"),
            "archive": {
                "path": output.relative_to(repo).as_posix(),
                "bytes": len(archive_bytes),
                "sha256": sha256(archive_bytes),
            },
            "memberCount": len(member_rows),
            "exclusions": {
                "directoryParts": sorted(EXCLUDED_PARTS),
                "buildDirectoryPrefix": "build-",
                "suffixes": sorted(EXCLUDED_SUFFIXES),
                "allowedTextSuffixes": sorted(ALLOWED_SUFFIXES),
                "skippedSelectedFiles": skipped,
            },
            "manifest": {
                "path": manifest_path.relative_to(repo).as_posix(),
                "bytes": manifest_path.stat().st_size,
                "sha256": sha256(manifest_path.read_bytes()),
            },
            "files": member_rows,
        }
        index_bytes = stable_json(index)

        # Validate the on-disk temporary ZIP's complete byte-level receipt before
        # publishing either output. The ZIP itself is immutable after this point.
        if len(archive_bytes) != temporary_zip.stat().st_size or sha256(temporary_zip.read_bytes()) != index["archive"]["sha256"]:
            raise ValueError("archive hash/length changed before publication")
        temporary_zip.replace(output)
        write_atomic(index_path, index_bytes)
        return index
    finally:
        if temporary_zip.exists():
            temporary_zip.unlink()


def main() -> None:
    parser = argparse.ArgumentParser(description="Package accepted native Bool evidence from an explicit manifest.")
    parser.add_argument("--manifest", required=True, help="repository-relative JSON package manifest")
    parser.add_argument("--output", required=True, help="repository-relative output .zip path")
    parser.add_argument("--repo-root", default=str(pathlib.Path(__file__).resolve().parents[2]), help="repository root (default: containing repository)")
    args = parser.parse_args()
    try:
        result = package(pathlib.Path(args.repo_root), args.manifest, args.output)
    except (OSError, ValueError, KeyError, TypeError, zipfile.BadZipFile) as error:
        parser.error(str(error))
    print(json.dumps({
        "status": result["status"],
        "archive": result["archive"],
        "memberCount": result["memberCount"],
        "index": args.output + ".index.json",
    }, indent=2))


if __name__ == "__main__":
    main()

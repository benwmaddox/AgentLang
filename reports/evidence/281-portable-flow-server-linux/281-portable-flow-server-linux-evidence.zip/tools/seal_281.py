#!/usr/bin/env python3
"""Seal report-281 (273-281) evidence (fail closed, immutable output)."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile

REPO = Path(__file__).resolve().parents[2]
HERE = REPO / ".agentlang" / "lang-281"
OUT = REPO / "reports" / "evidence" / "281-portable-flow-server-linux"
BANNED = re.compile(r"(?i)(\.sqlite3?(-wal|-shm|-journal)?$|\.db3?$|secret|cookie\.txt$|\.env$|labels\.json$)")


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def collect(gates: Path) -> list[tuple[Path, str]]:
    items: list[tuple[Path, str]] = []
    for f in sorted(gates.glob("*.log")) + [gates / "summary.json"]:
        items.append((f, f"gates/{f.name}"))
    # The first gate run, interrupted when its session ended (kept; see the report).
    for f in sorted((HERE / "gates-20261015T032218Z").glob("*.log")):
        items.append((f, f"gates-interrupted/{f.name}"))
    for f in sorted((REPO / ".agentlang" / "campfire-native-room-read-252" / "test-runs").glob("*/test-receipt.json"))[-2:]:
        items.append((f, f"room-read-receipts/{f.parent.name}.json"))
    lb = REPO / ".agentlang" / "linux-bench-273"
    for name in ("NATIVE-REFS-PROGRESS.md", "native-lifetime.sh", "run-native.sh", "cleanup-native.sh",
                 "build-ruby-native.sh", "build-rust-native.sh", "setup-rails-native.sh"):
        items.append((lb / name, f"linux-bench/{name}"))
    for f in sorted((lb / "runs").glob("*/*")):
        if f.is_file() and (f.name != "server.log" or f.stat().st_size < 1_000_000):
            items.append((f, f"linux-bench/runs/{f.parent.name}/{f.name}"))
    for name in ("Run-Gates.ps1", "seal_281.py", "secret_scan.py"):
        items.append((HERE / name, f"tools/{name}"))
    changed = subprocess.run(["git", "diff", "--name-only", "16c1c62"], cwd=REPO, check=True, capture_output=True, text=True).stdout.split()
    untracked = subprocess.run(["git", "ls-files", "--others", "--exclude-standard", "reports/281-portable-flow-server-linux.md"],
                               cwd=REPO, check=True, capture_output=True, text=True).stdout.split()
    for rel in sorted(set(changed) | set(untracked)):
        path = REPO / rel
        if path.is_file() and not rel.startswith("reports/evidence/") and not rel.startswith("reports/281-"):
            items.append((path, f"sources/{rel}"))
    return items


def main() -> int:
    gates = Path(sys.argv[1]).resolve()
    if OUT.exists():
        raise SystemExit(f"immutable output exists: {OUT}")
    entries, blobs = [], {}
    for path, arc in collect(gates):
        if not path.is_file():
            raise SystemExit(f"missing evidence input: {path}")
        if BANNED.search(path.name) and path.name not in ("server-log-secret-scan.txt", "secret_scan.py"):  # holds a hit count only
            raise SystemExit(f"refused sensitive path: {arc}")
        data = path.read_bytes()
        blobs[arc] = data
        entries.append({"archivePath": arc, "sourcePath": path.relative_to(REPO).as_posix(), "sha256": sha(data), "sizeBytes": len(data)})
    embedded = (json.dumps({"format": "agentlang-evidence-v1", "report": "281", "entries": entries}, indent=2) + "\n").encode()
    OUT.mkdir(parents=True)
    archive = OUT / "281-portable-flow-server-linux-evidence.zip"
    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for arc in sorted(blobs):
            zf.writestr(arc, blobs[arc])
        zf.writestr("evidence-manifest.json", embedded)
    with zipfile.ZipFile(archive) as zf:
        if set(zf.namelist()) != set(blobs) | {"evidence-manifest.json"}:
            raise SystemExit("archive members differ from collection")
        for row in entries:
            if sha(zf.read(row["archivePath"])) != row["sha256"]:
                raise SystemExit(f"checksum mismatch: {row['archivePath']}")
    manifest = {"archiveFile": archive.name, "archiveSha256": sha(archive.read_bytes()), "archiveSizeBytes": archive.stat().st_size,
                "entryCount": len(entries) + 1, "entries": entries}
    (OUT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({k: manifest[k] for k in ("archiveSha256", "archiveSizeBytes", "entryCount")}))
    return 0


if __name__ == "__main__":
    sys.exit(main())

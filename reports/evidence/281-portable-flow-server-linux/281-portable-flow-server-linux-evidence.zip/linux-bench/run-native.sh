# Root wrapper: runs native-lifetime.sh (immutable run names) and verifies teardown.
# wsl -d Ubuntu -u root -- bash /mnt/d/code/AgentLang/.agentlang/linux-bench-273/run-native.sh <rails|rust|flow> <run> [on|off] [secs]
set -u
[ $# -ge 2 ] || { echo "usage: run-native.sh <rails|rust|flow> <run> [on|off] [secs]"; exit 2; }
bash /mnt/d/code/AgentLang/.agentlang/linux-bench-273/native-lifetime.sh "$@"; rc=$?
echo "exit=$rc cgroup_left=$(test -e /sys/fs/cgroup/lb273-srv && echo yes || echo no) netns=$(ip netns list | grep -c lb273) host_listeners=$(ss -ltnH | awk '{print $4}' | grep -cE ':(13774|13775|6379)$')"

# Build Ruby 3.4.10 like the official ruby:3.4.10-trixie image (configure args read from the image's RbConfig).
set -eu
export PATH=$HOME/.cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
P=$HOME/linuxbench/ruby-3.4.10; S=$HOME/linuxbench/ruby-src
test -x "$P/bin/ruby" && { "$P/bin/ruby" -v; exit 0; }
mkdir -p "$S"; cd "$S"
curl -fsSL -o ruby.tar.xz https://cache.ruby-lang.org/pub/ruby/3.4/ruby-3.4.10.tar.xz
echo "6f32ad662baafc228d12030dbcd284f83b034dd4337b300dc84ac74d11a1eb68  ruby.tar.xz" | sha256sum -c -
rm -rf ruby-3.4.10; tar -xJf ruby.tar.xz; cd ruby-3.4.10
rustc -V
./configure --prefix="$P" --build=x86_64-linux-gnu --disable-install-doc --enable-shared --enable-yjit LDFLAGS='-Wl,-z,relro -Wl,-z,now' > ../configure.log 2>&1
make -j16 > ../make.log 2>&1 && make install > ../install.log 2>&1
"$P/bin/ruby" -e 'puts RUBY_DESCRIPTION; puts RbConfig::CONFIG.values_at("configure_args","optflags"); p RubyVM::YJIT.enable; p RubyVM::YJIT.enabled?'

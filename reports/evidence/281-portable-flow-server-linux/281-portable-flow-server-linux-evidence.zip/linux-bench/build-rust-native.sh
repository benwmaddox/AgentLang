# Build the Rust reference natively in WSL with the image's toolchain and flags (cargo build --release --locked -p campfire).
set -eu
export PATH=$HOME/.cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
unset RUSTFLAGS CARGO_BUILD_RUSTFLAGS CARGO_TARGET_DIR CARGO_ENCODED_RUSTFLAGS
B=$HOME/linuxbench/rust
mkdir -p "$B"
rustup toolchain install 1.98.1 --profile minimal >/dev/null 2>&1
if [ ! -d "$B/src/.git" ]; then
  git clone -q $HOME/cm258/campfire-rust-src "$B/src"
  git -C "$B/src" checkout -q --detach 6dae2fd3c1a2dce61ca11beb731bcce2b42b67ad
  git -C "$B/src" config submodule.reference.url $HOME/cm258/campfire-rust-src/reference
  git -C "$B/src" -c protocol.file.allow=always submodule update --init -q reference
fi
echo "src=$(git -C "$B/src" rev-parse HEAD) reference=$(git -C "$B/src/reference" rev-parse HEAD) dirty=$(git -C "$B/src" status --porcelain | wc -l)"
cd "$B/src"
rustc +1.98.1 -V; cargo +1.98.1 -V
ls $HOME/.cargo/config* .cargo 2>/dev/null || echo "no cargo config"
time cargo +1.98.1 build --release --locked -p campfire > "$B/build.log" 2>&1 && rc=0 || rc=$?
echo "build-exit=$rc"; tail -3 "$B/build.log"
install -D -m 755 target/release/campfire "$B/bin/campfire"
sha256sum "$B/bin/campfire"; ldd "$B/bin/campfire" | grep -E "vips|not found|libc.so"

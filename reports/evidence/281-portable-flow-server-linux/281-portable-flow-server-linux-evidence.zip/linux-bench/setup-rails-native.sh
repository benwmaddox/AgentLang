# One-time setup of the native Rails reference (app + gems extracted from once-campfire-verification:reference-90b3300).
set -eu
L=$HOME/linuxbench; R=$L/rails; RB=$L/ruby-3.4.10/bin
export PATH=$RB:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
test ! -e "$R" || { echo "exists: $R"; exit 2; }
mkdir -p "$R"
cp -a $L/rails-image/rails "$R/app"; cp -a $L/rails-image/bundle-image "$R/bundle"
rm -rf "$R/app/tmp/cache/bootsnap"
G=$R/bundle/ruby/3.4.0
# Native-extension gems were compiled against Debian trixie (glibc 2.41, OpenSSL 3.5): remove and rebuild from rubygems.org at the locked versions.
for d in $(ls $G/extensions/x86_64-linux/3.4.0/); do rm -rf "$G/gems/$d" "$G/specifications/$d.gemspec" "$G/extensions/x86_64-linux/3.4.0/$d"; echo "rebuild $d"; done
gem install bundler -v 4.0.13 --no-document >/dev/null
cd "$R/app"
export BUNDLE_APP_CONFIG=$R/bundle GEM_HOME=$R/bundle RAILS_ENV=production BUNDLE_DEPLOYMENT=1 BUNDLE_PATH=$R/bundle BUNDLE_WITHOUT=development BUNDLE_SILENCE_ROOT_WARNING=1
bundle -v
bundle install --jobs 8 > $R/bundle-install.log 2>&1 && rc=0 || rc=$?
echo "bundle-install-exit=$rc"; tail -3 $R/bundle-install.log
bundle check
find $G -name '*.so' | xargs ldd 2>/dev/null | grep -c "not found" || true
ls $G/extensions/x86_64-linux/3.4.0/ | tr '\n' ' '; echo

#!/usr/bin/env python3
"""Seal a byte-verified, preflight-only evidence archive for trial 230.

Coordinator-only standard-library script. It does not execute participant code.
Run from the AgentLang repository root with: python -B <this file>
"""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys
import zipfile
from datetime import datetime, timezone


REPO = Path.cwd()
TRIAL = Path(".agentlang/replacement-trial-230")
FREEZE_REL = TRIAL / "freeze.json"
REPORT_REL = Path("reports/230-grouped-renewal-timing-preflight.md")
ARCHIVE_DIR_REL = TRIAL / "root/archive"
EVIDENCE_DIR_REL = Path("reports/evidence/230-grouped-renewal-timing-preflight")
SKIP_DIRS = {".git", "bin", "obj", "artifacts", "__pycache__", ".pytest_cache", ".mypy_cache"}
SKIP_SUFFIXES = {
    ".dll", ".exe", ".pdb", ".so", ".dylib", ".o", ".obj", ".a", ".lib",
    ".class", ".pyc", ".wasm", ".zip", ".7z", ".tar", ".gz", ".tgz",
}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical_json(value: object) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode("utf-8")


def is_link_or_reparse(path: Path) -> bool:
    st = path.lstat()
    if stat.S_ISLNK(st.st_mode):
        return True
    reparse = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
    return bool(getattr(st, "st_file_attributes", 0) & reparse)


def checked_source(rel: Path) -> Path:
    if rel.is_absolute() or ".." in rel.parts:
        raise RuntimeError(f"unsafe source path: {rel}")
    absolute = REPO / rel
    if os.path.commonpath((str(REPO.absolute()), str(absolute.absolute()))) != str(REPO.absolute()):
        raise RuntimeError(f"source escaped repository: {rel}")
    cursor = REPO
    for part in rel.parts:
        cursor = cursor / part
        if not cursor.exists() and not cursor.is_symlink():
            raise RuntimeError(f"missing source path: {rel}")
        if is_link_or_reparse(cursor):
            raise RuntimeError(f"reparse point or symlink in source path: {rel}")
    if not absolute.is_file():
        raise RuntimeError(f"source is not a regular file: {rel}")
    return absolute


def checked_directory(rel: Path) -> Path:
    if rel.is_absolute() or ".." in rel.parts:
        raise RuntimeError(f"unsafe source directory: {rel}")
    absolute = REPO / rel
    if os.path.commonpath((str(REPO.absolute()), str(absolute.absolute()))) != str(REPO.absolute()):
        raise RuntimeError(f"source directory escaped repository: {rel}")
    cursor = REPO
    for part in rel.parts:
        cursor = cursor / part
        if not cursor.exists() and not cursor.is_symlink():
            raise RuntimeError(f"missing source directory: {rel}")
        if is_link_or_reparse(cursor):
            raise RuntimeError(f"reparse point or symlink in source directory: {rel}")
    if not absolute.is_dir():
        raise RuntimeError(f"source is not a directory: {rel}")
    return absolute


def verify_freeze_inputs(freeze: dict) -> list[dict]:
    inputs = freeze.get("inputs")
    if not isinstance(inputs, list) or len(inputs) != 48:
        raise RuntimeError(f"expected 48 frozen inputs, found {len(inputs) if isinstance(inputs, list) else 'invalid'}")
    checked = []
    for item in inputs:
        rel = Path(item["path"])
        src = checked_source(rel)
        data = src.read_bytes()
        actual = {"path": item["path"], "bytes": len(data), "sha256": sha256(data)}
        if actual["bytes"] != item["bytes"] or actual["sha256"] != item["sha256"]:
            raise RuntimeError(f"frozen input changed: {item['path']}")
        checked.append(actual)
    return checked


def safe_archive_name(name: str, source_rel: str) -> str:
    normalized = name.replace("\\", "/")
    posix = PurePosixPath(normalized)
    if posix.is_absolute() or ".." in posix.parts:
        raise RuntimeError(f"unsafe archive member path: {name}")
    if len(normalized) > 220:
        suffix = Path(source_rel).suffix[:12]
        normalized = f"long-paths/{hashlib.sha256(source_rel.encode()).hexdigest()[:24]}{suffix}"
    return normalized


def phase_for(group: str, source: str) -> str:
    low = source.lower().replace("\\", "/")
    if group == "freeze":
        return "frozen-pre-dispatch-record"
    if group in {"report", "review", "preflight", "packets", "launchers"}:
        return "pre-dispatch"
    if group == "calibration":
        if "185804.227859z" in low or "arity-gate.json" in low or "assertion-gate.json" in low or "agentlang-controls.json" in low:
            return "current-verified-control"
        if any(token in low for token in ("failed", "retry-old", "false-positive", "invalid-cas")):
            return "retained-failed-attempt"
        return "retained-control-or-support"
    if group == "oracle-work":
        if any(token in low for token in ("final3", "signed-summary", "185804.227859z")):
            return "current-final-receipt-or-source"
        return "raw-prior-run-or-support"
    if group == "frozen-input":
        return "frozen-input"
    return "supporting-source"


def collect_tree(root_rel: Path, archive_prefix: str, group: str) -> list[dict]:
    root = checked_directory(root_rel)
    found: list[dict] = []
    for current, dirs, files in os.walk(root, topdown=True, followlinks=False):
        here = Path(current)
        keep_dirs = []
        for dirname in sorted(dirs):
            child = here / dirname
            if is_link_or_reparse(child):
                raise RuntimeError(f"reparse point or symlink in selected tree: {child.relative_to(REPO)}")
            if dirname.lower() not in SKIP_DIRS:
                keep_dirs.append(dirname)
        dirs[:] = keep_dirs
        for filename in sorted(files):
            src = here / filename
            if is_link_or_reparse(src):
                raise RuntimeError(f"reparse point or symlink in selected tree: {src.relative_to(REPO)}")
            if src.suffix.lower() in SKIP_SUFFIXES:
                continue
            rel = src.relative_to(REPO).as_posix()
            tail = src.relative_to(root).as_posix()
            archived = safe_archive_name(f"{archive_prefix}/{tail}", rel)
            found.append({
                "source": rel,
                "archive": archived,
                "group": group,
                "phase": phase_for(group, rel),
            })
    return found


def add_file(candidates: list[dict], source_rel: Path, archived: str, group: str) -> None:
    checked_source(source_rel)
    candidates.append({
        "source": source_rel.as_posix(),
        "archive": safe_archive_name(archived, source_rel.as_posix()),
        "group": group,
        "phase": phase_for(group, source_rel.as_posix()),
    })


def write_exclusive(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(data)


def main() -> int:
    if not (REPO / FREEZE_REL).is_file() or not (REPO / REPORT_REL).is_file():
        raise RuntimeError("run this helper from the AgentLang repository root")
    freeze_bytes = (REPO / FREEZE_REL).read_bytes()
    freeze = json.loads(freeze_bytes)
    if freeze.get("status") != "frozen-ready":
        raise RuntimeError(f"freeze status is not frozen-ready: {freeze.get('status')}")
    pins_before = verify_freeze_inputs(freeze)

    candidates: list[dict] = []
    for item in freeze["inputs"]:
        source_rel = Path(item["path"])
        add_file(candidates, source_rel, f"frozen/{source_rel.as_posix()}", "frozen-input")
    add_file(candidates, FREEZE_REL, "freeze/freeze.json", "freeze")
    add_file(candidates, REPORT_REL, "report/current.md", "report")

    review_root = REPO / TRIAL
    for rel in sorted(review_root.glob("review-*.md")):
        if rel.is_file():
            add_file(candidates, rel.relative_to(REPO), f"review/{rel.name}", "review")
    plan_rel = TRIAL / "plan.md"
    if (REPO / plan_rel).is_file():
        add_file(candidates, plan_rel, "review/plan.md", "review")

    candidates.extend(collect_tree(TRIAL / "preflight", "preflight", "preflight"))
    candidates.extend(collect_tree(TRIAL / "packets", "packets", "packets"))
    candidates.extend(collect_tree(TRIAL / "launchers", "launchers", "launchers"))
    candidates.extend(collect_tree(TRIAL / "calibration", "calibration", "calibration"))
    candidates.extend(collect_tree(TRIAL / "oracle-work/l", "oracle-work/l", "oracle-work"))
    candidates.extend(collect_tree(TRIAL / "oracle-work/f", "oracle-work/f", "oracle-work"))
    add_file(
        candidates,
        ARCHIVE_DIR_REL / "seal_preflight.py",
        "archive-tool/seal_preflight.py",
        "archive-tool",
    )

    seen: set[str] = set()
    for item in candidates:
        name = item["archive"]
        if name in seen:
            raise RuntimeError(f"duplicate archive member: {name}")
        seen.add(name)

    now = datetime.now(timezone.utc)
    stamp = now.strftime("%Y%m%dT%H%M%S.%fZ")
    evidence_dir = REPO / EVIDENCE_DIR_REL
    archive_path = evidence_dir / f"preflight-230-{stamp}.zip"
    index_path = evidence_dir / f"preflight-230-{stamp}.members.json"
    receipt_path = REPO / ARCHIVE_DIR_REL / f"seal-{stamp}.json"
    for output in (archive_path, index_path, receipt_path):
        if output.exists() or output.is_symlink():
            raise RuntimeError(f"refusing to overwrite existing output: {output}")

    evidence_dir.mkdir(parents=True, exist_ok=True)
    archive_tmp = archive_path.with_suffix(".zip.partial")
    if archive_tmp.exists() or archive_tmp.is_symlink():
        raise RuntimeError(f"refusing to overwrite temporary output: {archive_tmp}")

    entries = []
    try:
        with archive_tmp.open("xb") as raw, zipfile.ZipFile(raw, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as zf:
            for item in sorted(candidates, key=lambda x: x["archive"]):
                src = checked_source(Path(item["source"]))
                before = src.stat()
                data = src.read_bytes()
                after = src.stat()
                if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
                    raise RuntimeError(f"source changed while archiving: {item['source']}")
                digest = sha256(data)
                zf.writestr(item["archive"], data)
                entries.append({
                    "member": item["archive"],
                    "source": item["source"],
                    "group": item["group"],
                    "phase": item["phase"],
                    "bytes": len(data),
                    "sha256": digest,
                })
        os.rename(archive_tmp, archive_path)
    except Exception:
        if archive_tmp.exists():
            archive_tmp.unlink()
        raise

    # Verify all ZIP members byte-for-byte against the external member index.
    with zipfile.ZipFile(archive_path, "r") as zf:
        bad_member = zf.testzip()
        if bad_member is not None:
            raise RuntimeError(f"ZIP CRC check failed: {bad_member}")
        names = zf.namelist()
        if len(names) != len(entries) or set(names) != {entry["member"] for entry in entries}:
            raise RuntimeError("ZIP member inventory differs from collected index")
        by_name = {entry["member"]: entry for entry in entries}
        for name in names:
            payload = zf.read(name)
            entry = by_name[name]
            if len(payload) != entry["bytes"] or sha256(payload) != entry["sha256"]:
                raise RuntimeError(f"ZIP payload verification failed: {name}")

    pins_after = verify_freeze_inputs(freeze)
    if pins_after != pins_before:
        raise RuntimeError("frozen input pins changed during archive sealing")
    if freeze.get("participantsDispatched") != 0:
        raise RuntimeError("freeze record no longer says participantsDispatched=0")

    groups: dict[str, int] = {}
    phases: dict[str, int] = {}
    for entry in entries:
        groups[entry["group"]] = groups.get(entry["group"], 0) + 1
        phases[entry["phase"]] = phases.get(entry["phase"], 0) + 1
    index = {
        "schema": "agentlang-replacement-trial-230-preflight-members-v1",
        "status": "verified-preflight-only",
        "capturedAtUtc": now.isoformat().replace("+00:00", "Z"),
        "participantsDispatchedAtFreeze": 0,
        "participantsIncluded": 0,
        "archiveScope": "Frozen pre-dispatch inputs and supporting preflight evidence only; dispatch.json and post-freeze participant traces are excluded.",
        "freeze": {
            "path": FREEZE_REL.as_posix(),
            "sha256": sha256(freeze_bytes),
            "status": freeze["status"],
            "frozenInputCount": len(pins_after),
            "allFrozenInputPinsVerifiedBeforeAndAfter": True,
            "pins": pins_after,
        },
        "mandatoryIndependentPostTrialSourceAudit": freeze.get("mandatoryPostTrialReview", {}),
        "limitations": {
            "staticAudit": "F# token retention is triage, not executable equivalence proof; resolve static failures against the original requirements.",
            "securityBoundary": "No OS confinement claim is made. Broker/no-web rules are not OS confinement.",
            "dependencyAudit": "NuGetAudit was enabled, but advisory data was unavailable (NU1900); no audit pass is claimed.",
            "duplicateRuntimeBaselines": "Preparational archive already contains baselines and private runtime binaries; this archive does not duplicate them.",
        },
        "filters": {
            "excludedDirectories": sorted(SKIP_DIRS),
            "excludedSuffixes": sorted(SKIP_SUFFIXES),
            "compiledBinariesIncluded": False,
        },
        "memberCount": len(entries),
        "groupCounts": dict(sorted(groups.items())),
        "phaseCounts": dict(sorted(phases.items())),
        "members": entries,
    }
    index_bytes = canonical_json(index)
    write_exclusive(index_path, index_bytes)

    archive_hash = sha256(archive_path.read_bytes())
    receipt = {
        "schema": "agentlang-replacement-trial-230-preflight-seal-v1",
        "status": "verified-preflight-only",
        "participantsDispatchedAtFreeze": 0,
        "participantsIncluded": 0,
        "frozenInputCount": len(pins_after),
        "allFrozenInputPinsVerifiedBeforeAndAfter": True,
        "allArchiveMembersByteVerified": True,
        "archivePath": archive_path.relative_to(REPO).as_posix(),
        "archiveSha256": archive_hash,
        "memberIndexPath": index_path.relative_to(REPO).as_posix(),
        "memberIndexSha256": sha256(index_bytes),
        "memberCount": len(entries),
        "groupCounts": dict(sorted(groups.items())),
        "phaseCounts": dict(sorted(phases.items())),
        "mandatoryIndependentPostTrialSourceAudit": freeze.get("mandatoryPostTrialReview", {}),
        "limitations": index["limitations"],
        "excludedPostFreezeArtifacts": ["dispatch.json", "future participant traces"],
    }
    write_exclusive(receipt_path, canonical_json(receipt))
    print(json.dumps({
        "status": receipt["status"],
        "archivePath": receipt["archivePath"],
        "archiveSha256": archive_hash,
        "memberIndexPath": receipt["memberIndexPath"],
        "memberIndexSha256": receipt["memberIndexSha256"],
        "receiptPath": receipt_path.relative_to(REPO).as_posix(),
        "memberCount": len(entries),
        "groupCounts": receipt["groupCounts"],
        "phaseCounts": receipt["phaseCounts"],
        "frozenInputCount": len(pins_after),
        "allFrozenInputPinsVerifiedBeforeAndAfter": True,
        "allArchiveMembersByteVerified": True,
    }, indent=2))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"seal failed: {type(exc).__name__}: {exc}", file=sys.stderr)
        raise

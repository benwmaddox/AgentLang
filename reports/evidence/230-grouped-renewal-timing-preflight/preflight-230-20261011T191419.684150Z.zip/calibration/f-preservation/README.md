# F# preservation gate

`preservation.py` is a pure, standard-library-only source audit. It does not
compile or execute actor code. From the AgentLang repository root, run:

```powershell
python -B experiments/AgentLang.SubagentTrials/replacement-trial-230/oracle/fsharp/preservation.py `
  --candidate .agentlang/replacement-trial-230/actors/fsharp
```

The Python integration point is:

```python
from preservation import audit

report = audit(candidate_path, baseline_path)
```

`audit(candidate: Path, baseline: Path = DEFAULT_BASELINE) -> dict` returns a
JSON-compatible report with `status`, `failures`, and per-file checks. The
default baseline is the accepted 228 F# endpoint copied for trial 230. The
CLI exits 0 on `status: pass`, 1 on an audit failure, and writes the same
report to `--output` when requested.

The gate enforces byte identity for the four protected seed files, rejects
extra source/project files and symlinks, checks the scoped `RenewalTiming`,
monthly implementation and entire Monthly batch branch, and preserves the
inherited `SelfTests.fs` token stream in order. Comments and whitespace outside
quoted literals are ignored; quoted literals are compared exactly. It also
requires the monthly scenario adapter and one direct grouped-time call whose
result is checked through an assertion or an `Ok`/`Error` match. The callback
and direct test may construct `RenewalTiming` inline or through a local record
binding, with named record fields in either order. The new test may appear
anywhere inside `SelfTests.run()`.

This is a lexical preservation gate, not a compiler or semantic proof. It does
not validate the production monthly field mapping or API signature; those are
checked by the separate scorer/build. Its result-check detector is a static
heuristic that recognizes assertion calls, result matches, and common
conditional failure checks. An unusual assertion helper or control-flow form
may need an explicit pure control before it is accepted.

Run pure mutation controls with:

```powershell
python -B experiments/AgentLang.SubagentTrials/replacement-trial-230/oracle/fsharp/preservation_checks.py
```

Each invocation creates a fresh directory under `runs/` and saves its
per-control source hashes, audit JSON, and summary receipt. The successful
control run for the current gate is recorded in the latest
`runs/run-*/checks-receipt.json`; it includes expected-pass local timing,
swapped-field, inline-result-assertion, post-annual/match-style controls and
expected-fail preservation mutations.

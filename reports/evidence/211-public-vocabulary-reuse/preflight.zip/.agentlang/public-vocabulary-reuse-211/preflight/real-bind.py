import json
from pathlib import Path
import sys

repo = Path(__file__).resolve().parents[3]
study = repo / '.agentlang/public-vocabulary-reuse-211'
sys.path.insert(0, str(repo / 'experiments/AgentLang.SubagentTrials/public-vocabulary-reuse-211/oracle'))
import score_public_vocabulary_reuse as adapter
payload = json.loads((study / 'accepted/creator/reuse-targets.json').read_text())
inventory, _ = adapter.scorer.validate_seed_inventory(adapter.scorer.DEFAULT_SEED_PROJECT)
binding = adapter.bind_targets(study / 'accepted/creator/project', payload, inventory)
assert adapter.scorer.project_fingerprint(study / 'actors/developer') == binding['acceptedProjectFingerprint']
(study / 'preflight/bound-targets.json').write_text(json.dumps(binding, indent=2) + '\n')
print(json.dumps({'status': 'real accepted snapshot bound; actor copy identical; no runtime executed', 'targets': [r['name'] for r in binding['targets']], 'fingerprint': binding['acceptedProjectFingerprint']}))

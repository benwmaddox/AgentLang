import json
from pathlib import Path
import sys

repo = Path(__file__).resolve().parents[3]
study = repo / '.agentlang/public-vocabulary-reuse-211'
sys.path.insert(0, str(repo / 'experiments/AgentLang.SubagentTrials/organic-reuse-210/oracle'))
import score_organic_reuse as scorer
import control_preflight as controls
import run_preflight_controls as runner

scorer.STUDY_ROOT = study
cli = study / 'runtime/AgentLang.Cli.dll'
project = study / 'accepted/creator/project'
assert scorer.project_fingerprint(project) == '390c0ebc697b735a21e5f12efe508b5e192f3d04c1a8947d9174f1835f62edd2'
pin = runner.validate_runtime_pin(cli)
# Keep inherited production functions; add only the batch control definitions.
controls.creator_source = lambda mutant='correct': ''
for variant in controls.SUCCESSOR_VARIANTS:
    source = controls.control_source(variant)
    assert 'fn subscription.renew-monthly' not in source
    assert 'fn subscription.renew-annual' not in source
    assert '.subscription.renew-monthly(' in source and '.subscription.renew-annual(' in source
attempt = scorer.create_run_directory(study / 'preflight/controls', 'attempts')
reports = [runner.run_variant(variant, cli, project, attempt, pin) for variant in controls.SUCCESSOR_VARIANTS]
assert scorer.project_fingerprint(project) == '390c0ebc697b735a21e5f12efe508b5e192f3d04c1a8947d9174f1835f62edd2'
summary = {'status': 'preflight-passed' if all(r['status'] == 'preflight-passed' for r in reports) else 'preflight-failed', 'scope': 'Existing held-out batch behavior controls on accepted creator snapshot; no predecessor redefinition; no participant outcome', 'variants': reports, 'acceptedProjectUnchanged': True, 'runtimeInvocation': {'filesystemMode': 'virtual', 'capabilities': [], 'testCapabilities': []}}
(attempt / 'control-preflight-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'status': summary['status'], 'summary': str(attempt / 'control-preflight-summary.json'), 'variants': {r['variant']: r['status'] for r in reports}}, indent=2))
sys.exit(0 if summary['status'] == 'preflight-passed' else 1)

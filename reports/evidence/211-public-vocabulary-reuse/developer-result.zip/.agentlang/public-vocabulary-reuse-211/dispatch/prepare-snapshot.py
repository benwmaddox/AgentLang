import hashlib
import json
from pathlib import Path
import shutil
import sys
from zipfile import ZipFile

repo = Path(__file__).resolve().parents[3]
study = repo / '.agentlang/public-vocabulary-reuse-211'
archive = repo / 'reports/evidence/210-organic-reuse-replication/creator-result.zip'
index = json.loads(archive.with_suffix('.index.json').read_text())
assert hashlib.sha256(archive.read_bytes()).hexdigest() == index['archiveSha256']
entries = {r['path']: r for r in index['members']}
prefix = '.agentlang/organic-reuse-210/actors/creator/'
destination = study / 'accepted/creator/project'
assert not any(destination.iterdir()), 'Refuse to overwrite accepted project'
with ZipFile(archive) as z:
    for name in sorted(z.namelist()):
        if not name.startswith(prefix):
            continue
        target = (destination / name[len(prefix):]).resolve()
        assert destination.resolve() in target.parents, name
        data = z.read(name)
        row = entries[name]
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
sys.path.insert(0, str(repo / 'experiments/AgentLang.SubagentTrials/organic-reuse-210/oracle'))
import score_organic_reuse as scorer
fingerprint = scorer.project_fingerprint(destination)
assert fingerprint == '390c0ebc697b735a21e5f12efe508b5e192f3d04c1a8947d9174f1835f62edd2'
_, manifest, _ = scorer.current_manifest(destination)
current = scorer.current_revisions(manifest)
targets = []
for name in ['subscription.renew-monthly', 'subscription.renew-annual']:
    row = current[name]
    assert row['revision']['maturity'] == 'library'
    targets.append({'name': name})
payload = {'schemaVersion': 1, 'targetKind': 'task-required-creator-authored-library-functions', 'acceptedProjectFingerprint': fingerprint, 'targets': targets}
(study / 'accepted/creator/reuse-targets.json').write_text(json.dumps(payload, indent=2) + '\n')
shutil.copytree(destination, study / 'actors/developer')
receipt = {'status': 'accepted creator snapshot extracted and every selected member verified', 'originStudy': 210, 'originArchiveSha256': index['archiveSha256'], 'acceptedProjectFingerprint': fingerprint, 'targetKind': payload['targetKind'], 'targets': targets}
(study / 'preflight/snapshot.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))

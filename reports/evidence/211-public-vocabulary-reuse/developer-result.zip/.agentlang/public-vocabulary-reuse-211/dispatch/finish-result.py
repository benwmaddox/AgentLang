import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parents[3]
study = root / '.agentlang/public-vocabulary-reuse-211'
summary = json.loads((study / 'scoring/vocabulary-reuse-summary.json').read_text())
assert summary['status'] == 'passed'
for row in json.loads((study / 'source-pin.json').read_text())['files']:
    data = (root / row['path']).read_bytes()
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256'], row['path']
for row in json.loads((study / 'accepted-runtime-pin.json').read_text())['runtimeFiles']:
    data = (study / 'runtime' / row['name']).read_bytes()
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256'], row['name']
(study / 'dispatch/developer-final.md').write_text('''# Participant final disclosure

The participant reported adding SubscriptionPlan, SubscriptionRenewal and
subscription.renew-batch, using a fold helper preserving the first error.
It reported publishing the helper and batch operation as library functions,
3/3 helper tests, 4/4 batch tests and 152/152 total tests passing.
It reported reading only the assigned packet and using the specified broker,
with no other project tools; the broker closed with exit 0.

These are participant statements. Independent scoring and the termination audit
are retained separately and govern the result.
''', encoding='utf-8')
(study / 'dispatch/final-pin-verification.json').write_text(json.dumps({'status':'passed','sourceFiles':37,'runtimeFiles':5,'participantProjectUnchangedAcrossScoring':summary['participantProjectUnchangedAcrossScoring']},indent=2)+'\n',encoding='utf-8')
out = root / 'reports/evidence/211-public-vocabulary-reuse'
archive = out / 'developer-result.zip'
index = out / 'developer-result.index.json'
assert not archive.exists() and not index.exists(), 'Do not overwrite sealed evidence'
paths = [study / 'traces/developer.jsonl', study / 'accepted/creator/reuse-targets.json']
for directory in ['dispatch', 'actors/developer', 'scoring']:
    paths.extend(p for p in (study / directory).rglob('*') if p.is_file())
for name in ['accepted-runtime-pin.json','source-pin.json','frozen-inputs.json']:
    paths.append(study / name)
members = []
with ZipFile(archive,'x',ZIP_DEFLATED,compresslevel=9) as z:
    for path in sorted(set(paths)):
        data = path.read_bytes()
        name = path.relative_to(root).as_posix()
        z.writestr(name,data)
        members.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with ZipFile(archive) as z:
    assert len(z.namelist()) == len(members)
    for row in members:
        data = z.read(row['path'])
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
receipt = {'status':summary['status'],'endpoint':summary['endpoint'],'archive':archive.relative_to(root).as_posix(),'archiveBytes':archive.stat().st_size,'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'memberCount':len(members),'members':members,'limits':summary['interpretationLimit']}
index.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k != 'members'}))

$env:TEMP = 'D:\code\AgentLang\.agentlang\public-vocabulary-reuse-211\tmp'
$env:TMP = $env:TEMP
& 'D:\code\AgentLang\scripts\Start-SubagentTrialHostV2.ps1' `
    -CliDll 'D:\code\AgentLang\.agentlang\public-vocabulary-reuse-211\runtime\AgentLang.Cli.dll' `
    -ProjectPath 'D:\code\AgentLang\.agentlang\public-vocabulary-reuse-211\actors\developer' `
    -TracePath 'D:\code\AgentLang\.agentlang\public-vocabulary-reuse-211\traces\developer.jsonl' `
    -AllowedOperations 'help,words,source,tests,define,test,test-all,commit,storage.status,task.begin,task.status,task.commit,describe,search,eval,context,dependencies,callers,failed-tests,examples,effects,type-of,history,task.abort' `
    -Profile agentlang -ExchangeTimeoutMilliseconds 120000 -MaxExchanges 100

import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

repo = Path(__file__).resolve().parents[3]
study = repo / '.agentlang/public-vocabulary-reuse-211'
out = repo / 'reports/evidence/211-public-vocabulary-reuse'
out.mkdir(parents=True, exist_ok=True)
archive = out / 'preflight.zip'
index = out / 'preflight.index.json'
if archive.exists() or index.exists():
    raise RuntimeError('Refuse to overwrite sealed evidence')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
source_pin = json.loads((study / 'source-pin.json').read_text(encoding='utf-8-sig'))
runtime_pin = json.loads((study / 'accepted-runtime-pin.json').read_text(encoding='utf-8-sig'))
for row in source_pin['files']:
    assert sha(repo / row['path']) == row['sha256'], row['path']
for row in runtime_pin['runtimeFiles']:
    assert sha(study / 'runtime' / row['name']) == row['sha256'], row['name']
summary = json.loads((study / 'preflight/controls/attempts/20261011T092732Z-01/control-preflight-summary.json').read_text())
assert summary['status'] == 'preflight-passed' and len(summary['variants']) == 3
assert all(r['status'] == 'preflight-passed' and not r['behavior']['setupErrors'] for r in summary['variants'])
paths = set()
for directory in [study / 'preflight', study / 'accepted', study / 'actors/developer', study / 'dispatch', repo / 'experiments/AgentLang.SubagentTrials/public-vocabulary-reuse-211', repo / 'experiments/AgentLang.SubagentTrials/organic-reuse-210/oracle']:
    paths.update(p for p in directory.rglob('*') if p.is_file())
paths.update(repo / row['path'] for row in source_pin['files'])
paths.update([study / 'source-pin.json', study / 'accepted-runtime-pin.json'])
paths.update(repo / p for p in [
    'experiments/AgentLang.SubagentTrials/subscription-handoff-161/oracle/score_agentlang.py',
    'experiments/AgentLang.SubagentTrials/subscription-handoff-161/oracle/model.py',
    'experiments/AgentLang.SubagentTrials/subscription-handoff-maintenance-166/oracle/score_agentlang.py',
    'reports/evidence/210-organic-reuse-replication/preflight.index.json',
    'reports/evidence/210-organic-reuse-replication/creator-result.index.json'])
pins = []
for path in sorted(paths):
    assert repo in path.resolve().parents and path.is_file(), str(path)
    assert path.suffix.lower() not in {'.dll', '.exe', '.pdb', '.zip', '.pyc'}, str(path)
    pins.append({'path': path.relative_to(repo).as_posix(), 'bytes': path.stat().st_size, 'sha256': sha(path)})
frozen = study / 'frozen-inputs.json'
frozen.write_text(json.dumps({'status': 'accepted pre-dispatch inputs; no participant run', 'files': pins, 'externalCapabilities': [], 'controls': 'three held-out batch controls passed calibration on accepted snapshot', 'participantModel': 'gpt-6-luna', 'reasoning': 'max', 'maxExchanges': 100}, indent=2) + '\n')
paths.add(frozen)
members = []
with ZipFile(archive, 'x', ZIP_DEFLATED, compresslevel=9) as z:
    for path in sorted(paths):
        data = path.read_bytes()
        name = path.relative_to(repo).as_posix()
        z.writestr(name, data)
        members.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
with ZipFile(archive) as z:
    assert len(z.namelist()) == len(members)
    for row in members:
        data = z.read(row['path'])
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
receipt = {'status': 'pre-dispatch evidence; no participant result', 'archiveSha256': sha(archive), 'memberCount': len(members), 'verification': 'Reopened every member and verified length and SHA256', 'members': members}
index.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k: v for k, v in receipt.items() if k != 'members'}))

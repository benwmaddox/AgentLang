# Reset-2 preservation audit

Read only the captured project, its source history, the seed pins, the immutable snapshot, and the recorded broker trace. No runtime rebuild, rerun, participant interaction, network access, or source edits were performed. This receipt does not report an independent oracle score.

## Seed, preflight, and immutable capture

The historical draft-009 project is generation 9 with manifest `5e6cbd0030940b4814b86511d83bb2aa36328e64a3c043a4a13cf7c6877177ef`. Its `history/task-0001.json` is complete (`active=false`, 54 tests run, 0 failed, empty effects); the same task-1 history is present in the final snapshot. All 61 reset-2 `initialPins` in `trials/actors.json` match the original draft-009 project byte-for-byte. This is seed provenance, separate from dispatch readiness.

An earlier `preparation-attempt-001.json` records `preparation-preflight-failed` before it created a trial directory (sandbox `WinError 5` while resolving a pinned deps file). The later `dispatch-preflight-reset-2.json` records `passed` at source revision `ec8fe2a`. Prompt and CLI hashes agree with the actor pins. Capture and metrics both point to trace SHA-256 `ce8c25c5a4467a53579fa845b3d2c777e2615e3918536aa9bbbb1d2c86d9eace`.

The final candidate is generation 10 (`76c44dcae7dfa6c1776f5bfdcd85d5403c9456d73c3f4f61208844f110c54057`). Its capture lists 89 files; all 89 hashes match the 89 files in `trials/snapshots/reset-2`, with no missing, mismatched, or unlisted files.

## Inherited evidence and interface

The seed contains exactly 18 tests and 2 examples. All 18 tests and both examples remain attached under their original names. A token-shape comparison of the captured attachment source matched every inherited body after ignoring formatting/comments and Flow/2 root-dot qualification, and unwrapping only `TrackingReference.new(<literal>)`; the remaining token sequences, including calls, branches, operands, expected values, and assertions, match. This is stronger than name or raw-text comparison, while not claiming a formal compiler-AST equivalence. The final project adds five tests and no examples, for 23 tests total; the trace reports `23/23 test(s) passed` at exchanges 46 and 58.

The snapshot adds the empty nominal definition `TrackingReference : String` and retypes `Scan.reference`, `ScanInput.reference`, and `ShipmentScanLookup.target` to it. Public entry names and function signatures for `shipment.ingest`, `shipment.ingest-rule`, `shipment.ingest-batch`, and `shipment.scan-lookup-step` remain as seeded; the affected generated field outputs are recorded as `TrackingReference` by `describe` at exchanges 52–54. All nine seeded word IDs are unchanged. Five current function revisions advance from 1 to 2; the remaining four stay at revision 1. The helper `shipment.scan-lookup-step` retains its seeded word ID and `library` maturity.

Manifest call bindings show reuse through the existing chain: `shipment.ingest` calls `store.shipment`, `shipment.ingest-rule`, and `store.with-shipment`; `shipment.ingest-rule` calls the shared `shipment.scan-lookup-step`; `shipment.ingest-batch` calls `shipment.batch-step`, which calls `shipment.ingest`. No duplicated call-chain implementation is evidenced in the committed definitions.

## Rejected exchanges and terminal state

Metrics records six rejected exchanges. Exchanges 7, 32, 41, and 42 were resolved in the trace: the query argument is supplied at 8; a corrected atomic define succeeds at 45 and all 23 tests pass at 46; the malformed replacement CAS is likewise corrected at 45; and the missing history word is supplied at 43. Exchanges 49 and 51 remain unresolved diff queries (the explicit revision query also returned `HISTORY_REVISION_UNKNOWN`; no successful diff follows). They are retained in task history as errors, but did not block the recorded commit or finalization.

The commit at exchange 55 reports 23 attached tests passed and selected candidates committed. `task.commit` at exchange 59 saves the task log and returns `active=false`. Capture records normal broker finalization, host-close termination, host/runtime exit code 0, and zero runtime stderr bytes. The broker session began with no capabilities; observed operations remain within the allowlist (`allowlistMissing=[]`, `allowlistExtra=[]`), and task effects are empty. Revised functions declare `effects none`.

## Lifecycle transport note

`coordinator-reset-2-launch.json` labels the event a prelaunch transport clarification: the participant asked for a broker-named tool; the coordinator repeated the existing authorization to read the assigned prompt and use its unchanged launch with `tty:true` plus `exec`/`write_stdin`. Its timestamp falls after the trace `session-start` and before exchange 1, so the captures establish clarification before the first broker request, not before host process startup. The record says task-logic feedback, oracle feedback, code repair, and limit changes were all false. It is outside the exchange trace and should remain visible in cohort interpretation.

**Limits:** the receipt establishes preservation and captured lifecycle evidence only. It does not rerun the trial or assess the independent oracle. The two diff-query failures remain unresolved as queries.

target triple = "x86_64-pc-windows-msvc"
%NativeExecutionContext = type { i32, i32, i32, i32, i64, i64, ptr, ptr, ptr, i32, i32 }
%NativeExecutionContextAlignmentProbe = type { i8, %NativeExecutionContext }
%NativeTypeDescriptor = type { i32, i32, ptr }
%NativeProgramDescriptor = type { ptr, i32, i32 }
declare i32 @al_runtime_validate_request(ptr, ptr, i32, i32, ptr, i32)
declare i32 @al_runtime_make_record(ptr, ptr, i32, ptr, i32, ptr)
declare i32 @al_runtime_get_field(ptr, ptr, i32, i64, i32, ptr)
declare i32 @al_runtime_equal(ptr, ptr, i32, i64, i64, ptr)
declare i32 @al_runtime_promote(ptr, ptr, ptr, ptr, i32, ptr, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

@agentlang_fields_4 = private constant [2 x i32] [i32 3, i32 3]
@agentlang_fields_5 = private constant [2 x i32] [i32 4, i32 4]
@agentlang_fields_6 = private constant [2 x i32] [i32 5, i32 5]
@agentlang_fields_7 = private constant [2 x i32] [i32 6, i32 6]
@agentlang_fields_8 = private constant [2 x i32] [i32 7, i32 7]
@agentlang_fields_9 = private constant [2 x i32] [i32 8, i32 8]
@agentlang_fields_10 = private constant [2 x i32] [i32 9, i32 9]
@agentlang_fields_11 = private constant [2 x i32] [i32 10, i32 10]
@agentlang_fields_12 = private constant [2 x i32] [i32 11, i32 11]
@agentlang_fields_13 = private constant [2 x i32] [i32 12, i32 12]
@agentlang_fields_14 = private constant [2 x i32] [i32 13, i32 13]
@agentlang_fields_15 = private constant [2 x i32] [i32 14, i32 14]
@agentlang_fields_16 = private constant [2 x i32] [i32 15, i32 15]
@agentlang_fields_17 = private constant [2 x i32] [i32 16, i32 16]
@agentlang_fields_18 = private constant [2 x i32] [i32 17, i32 17]
@agentlang_type_descriptors = private constant [19 x %NativeTypeDescriptor] [%NativeTypeDescriptor { i32 1, i32 0, ptr null }, %NativeTypeDescriptor { i32 2, i32 0, ptr null }, %NativeTypeDescriptor { i32 3, i32 0, ptr null }, %NativeTypeDescriptor { i32 4, i32 0, ptr null }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_4, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_5, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_6, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_7, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_8, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_9, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_10, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_11, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_12, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_13, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_14, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_15, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_16, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_17, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_18, i32 0, i32 0) }]
@agentlang_program = private constant %NativeProgramDescriptor { ptr getelementptr inbounds ([19 x %NativeTypeDescriptor], ptr @agentlang_type_descriptors, i32 0, i32 0), i32 19, i32 0 }
@agentlang_root_type_ids = private constant [2 x i32] [i32 18, i32 18]

define internal void @agentlang_body(ptr %ctx, ptr %outputs, ptr %status, i32 %depth) {
entry:
  %ctx.field.0 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1 = load i32, ptr %ctx.field.0, align 4
  %steps.next.2 = add i32 %steps.current.1, 1
  store i32 %steps.next.2, ptr %ctx.field.0, align 4
  %steps.over.3 = icmp ugt i32 %steps.next.2, 10000
  br i1 %steps.over.3, label %failure.4, label %continue.5
failure.4:
  %ctx.field.6 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 0, ptr %ctx.field.6, align 4
  %status.diagnostic.7 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7, align 4
  ret void
continue.5:
  %depth.exceeded.8 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.8, label %failure.9, label %continue.10
failure.9:
  %ctx.field.11 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1, ptr %ctx.field.11, align 4
  %status.diagnostic.12 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.12, align 4
  ret void
continue.10:
  %workspace.slot.13 = getelementptr inbounds i64, ptr %outputs, i64 0
  %record.make.status.14 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 3, ptr %outputs, i32 0, ptr %workspace.slot.13)
  switch i32 %record.make.status.14, label %runtime.invalid.result.20 [ i32 0, label %runtime.success.15 i32 1, label %runtime.invalid.request.16 i32 2, label %runtime.invalid.reference.17 i32 3, label %runtime.scratch.capacity.18 i32 4, label %runtime.retained.capacity.19 ]
runtime.invalid.request.16:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.17:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.18:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.19:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.20:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.15:
  %record.make.handle.21 = load i64, ptr %workspace.slot.13, align 8
  %ctx.field.22 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.23 = load i32, ptr %ctx.field.22, align 4
  %steps.next.24 = add i32 %steps.current.23, 1
  store i32 %steps.next.24, ptr %ctx.field.22, align 4
  %steps.over.25 = icmp ugt i32 %steps.next.24, 10000
  br i1 %steps.over.25, label %failure.26, label %continue.27
failure.26:
  %ctx.field.28 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 2, ptr %ctx.field.28, align 4
  %status.diagnostic.29 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.29, align 4
  ret void
continue.27:
  %depth.exceeded.30 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.30, label %failure.31, label %continue.32
failure.31:
  %ctx.field.33 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 3, ptr %ctx.field.33, align 4
  %status.diagnostic.34 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.34, align 4
  ret void
continue.32:
  %ctx.field.35 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.36 = load i32, ptr %ctx.field.35, align 4
  %steps.next.37 = add i32 %steps.current.36, 1
  store i32 %steps.next.37, ptr %ctx.field.35, align 4
  %steps.over.38 = icmp ugt i32 %steps.next.37, 10000
  br i1 %steps.over.38, label %failure.39, label %continue.40
failure.39:
  %ctx.field.41 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 4, ptr %ctx.field.41, align 4
  %status.diagnostic.42 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.42, align 4
  ret void
continue.40:
  %depth.exceeded.43 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.43, label %failure.44, label %continue.45
failure.44:
  %ctx.field.46 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 5, ptr %ctx.field.46, align 4
  %status.diagnostic.47 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.47, align 4
  ret void
continue.45:
  %workspace.slot.48 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.21, ptr %workspace.slot.48, align 8
  %workspace.slot.49 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.21, ptr %workspace.slot.49, align 8
  %workspace.slot.50 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.51 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 4, ptr %outputs, i32 2, ptr %workspace.slot.50)
  switch i32 %record.make.status.51, label %runtime.invalid.result.57 [ i32 0, label %runtime.success.52 i32 1, label %runtime.invalid.request.53 i32 2, label %runtime.invalid.reference.54 i32 3, label %runtime.scratch.capacity.55 i32 4, label %runtime.retained.capacity.56 ]
runtime.invalid.request.53:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.54:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.55:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.56:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.57:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.52:
  %record.make.handle.58 = load i64, ptr %workspace.slot.50, align 8
  %ctx.field.59 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.60 = load i32, ptr %ctx.field.59, align 4
  %steps.next.61 = add i32 %steps.current.60, 1
  store i32 %steps.next.61, ptr %ctx.field.59, align 4
  %steps.over.62 = icmp ugt i32 %steps.next.61, 10000
  br i1 %steps.over.62, label %failure.63, label %continue.64
failure.63:
  %ctx.field.65 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 6, ptr %ctx.field.65, align 4
  %status.diagnostic.66 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.66, align 4
  ret void
continue.64:
  %depth.exceeded.67 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.67, label %failure.68, label %continue.69
failure.68:
  %ctx.field.70 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 7, ptr %ctx.field.70, align 4
  %status.diagnostic.71 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.71, align 4
  ret void
continue.69:
  %ctx.field.72 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.73 = load i32, ptr %ctx.field.72, align 4
  %steps.next.74 = add i32 %steps.current.73, 1
  store i32 %steps.next.74, ptr %ctx.field.72, align 4
  %steps.over.75 = icmp ugt i32 %steps.next.74, 10000
  br i1 %steps.over.75, label %failure.76, label %continue.77
failure.76:
  %ctx.field.78 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 8, ptr %ctx.field.78, align 4
  %status.diagnostic.79 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.79, align 4
  ret void
continue.77:
  %depth.exceeded.80 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.80, label %failure.81, label %continue.82
failure.81:
  %ctx.field.83 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 9, ptr %ctx.field.83, align 4
  %status.diagnostic.84 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.84, align 4
  ret void
continue.82:
  %workspace.slot.85 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.58, ptr %workspace.slot.85, align 8
  %workspace.slot.86 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.58, ptr %workspace.slot.86, align 8
  %workspace.slot.87 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.88 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 5, ptr %outputs, i32 2, ptr %workspace.slot.87)
  switch i32 %record.make.status.88, label %runtime.invalid.result.94 [ i32 0, label %runtime.success.89 i32 1, label %runtime.invalid.request.90 i32 2, label %runtime.invalid.reference.91 i32 3, label %runtime.scratch.capacity.92 i32 4, label %runtime.retained.capacity.93 ]
runtime.invalid.request.90:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.91:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.92:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.93:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.94:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.89:
  %record.make.handle.95 = load i64, ptr %workspace.slot.87, align 8
  %ctx.field.96 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.97 = load i32, ptr %ctx.field.96, align 4
  %steps.next.98 = add i32 %steps.current.97, 1
  store i32 %steps.next.98, ptr %ctx.field.96, align 4
  %steps.over.99 = icmp ugt i32 %steps.next.98, 10000
  br i1 %steps.over.99, label %failure.100, label %continue.101
failure.100:
  %ctx.field.102 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 10, ptr %ctx.field.102, align 4
  %status.diagnostic.103 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.103, align 4
  ret void
continue.101:
  %depth.exceeded.104 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.104, label %failure.105, label %continue.106
failure.105:
  %ctx.field.107 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 11, ptr %ctx.field.107, align 4
  %status.diagnostic.108 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.108, align 4
  ret void
continue.106:
  %ctx.field.109 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.110 = load i32, ptr %ctx.field.109, align 4
  %steps.next.111 = add i32 %steps.current.110, 1
  store i32 %steps.next.111, ptr %ctx.field.109, align 4
  %steps.over.112 = icmp ugt i32 %steps.next.111, 10000
  br i1 %steps.over.112, label %failure.113, label %continue.114
failure.113:
  %ctx.field.115 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 12, ptr %ctx.field.115, align 4
  %status.diagnostic.116 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.116, align 4
  ret void
continue.114:
  %depth.exceeded.117 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.117, label %failure.118, label %continue.119
failure.118:
  %ctx.field.120 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 13, ptr %ctx.field.120, align 4
  %status.diagnostic.121 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.121, align 4
  ret void
continue.119:
  %workspace.slot.122 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.95, ptr %workspace.slot.122, align 8
  %workspace.slot.123 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.95, ptr %workspace.slot.123, align 8
  %workspace.slot.124 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.125 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 6, ptr %outputs, i32 2, ptr %workspace.slot.124)
  switch i32 %record.make.status.125, label %runtime.invalid.result.131 [ i32 0, label %runtime.success.126 i32 1, label %runtime.invalid.request.127 i32 2, label %runtime.invalid.reference.128 i32 3, label %runtime.scratch.capacity.129 i32 4, label %runtime.retained.capacity.130 ]
runtime.invalid.request.127:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.128:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.129:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.130:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.131:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.126:
  %record.make.handle.132 = load i64, ptr %workspace.slot.124, align 8
  %ctx.field.133 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.134 = load i32, ptr %ctx.field.133, align 4
  %steps.next.135 = add i32 %steps.current.134, 1
  store i32 %steps.next.135, ptr %ctx.field.133, align 4
  %steps.over.136 = icmp ugt i32 %steps.next.135, 10000
  br i1 %steps.over.136, label %failure.137, label %continue.138
failure.137:
  %ctx.field.139 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 14, ptr %ctx.field.139, align 4
  %status.diagnostic.140 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.140, align 4
  ret void
continue.138:
  %depth.exceeded.141 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.141, label %failure.142, label %continue.143
failure.142:
  %ctx.field.144 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 15, ptr %ctx.field.144, align 4
  %status.diagnostic.145 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.145, align 4
  ret void
continue.143:
  %ctx.field.146 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.147 = load i32, ptr %ctx.field.146, align 4
  %steps.next.148 = add i32 %steps.current.147, 1
  store i32 %steps.next.148, ptr %ctx.field.146, align 4
  %steps.over.149 = icmp ugt i32 %steps.next.148, 10000
  br i1 %steps.over.149, label %failure.150, label %continue.151
failure.150:
  %ctx.field.152 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 16, ptr %ctx.field.152, align 4
  %status.diagnostic.153 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.153, align 4
  ret void
continue.151:
  %depth.exceeded.154 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.154, label %failure.155, label %continue.156
failure.155:
  %ctx.field.157 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 17, ptr %ctx.field.157, align 4
  %status.diagnostic.158 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.158, align 4
  ret void
continue.156:
  %workspace.slot.159 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.132, ptr %workspace.slot.159, align 8
  %workspace.slot.160 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.132, ptr %workspace.slot.160, align 8
  %workspace.slot.161 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.162 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 7, ptr %outputs, i32 2, ptr %workspace.slot.161)
  switch i32 %record.make.status.162, label %runtime.invalid.result.168 [ i32 0, label %runtime.success.163 i32 1, label %runtime.invalid.request.164 i32 2, label %runtime.invalid.reference.165 i32 3, label %runtime.scratch.capacity.166 i32 4, label %runtime.retained.capacity.167 ]
runtime.invalid.request.164:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.165:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.166:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.167:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.168:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.163:
  %record.make.handle.169 = load i64, ptr %workspace.slot.161, align 8
  %ctx.field.170 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.171 = load i32, ptr %ctx.field.170, align 4
  %steps.next.172 = add i32 %steps.current.171, 1
  store i32 %steps.next.172, ptr %ctx.field.170, align 4
  %steps.over.173 = icmp ugt i32 %steps.next.172, 10000
  br i1 %steps.over.173, label %failure.174, label %continue.175
failure.174:
  %ctx.field.176 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 18, ptr %ctx.field.176, align 4
  %status.diagnostic.177 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.177, align 4
  ret void
continue.175:
  %depth.exceeded.178 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.178, label %failure.179, label %continue.180
failure.179:
  %ctx.field.181 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 19, ptr %ctx.field.181, align 4
  %status.diagnostic.182 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.182, align 4
  ret void
continue.180:
  %ctx.field.183 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.184 = load i32, ptr %ctx.field.183, align 4
  %steps.next.185 = add i32 %steps.current.184, 1
  store i32 %steps.next.185, ptr %ctx.field.183, align 4
  %steps.over.186 = icmp ugt i32 %steps.next.185, 10000
  br i1 %steps.over.186, label %failure.187, label %continue.188
failure.187:
  %ctx.field.189 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 20, ptr %ctx.field.189, align 4
  %status.diagnostic.190 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.190, align 4
  ret void
continue.188:
  %depth.exceeded.191 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.191, label %failure.192, label %continue.193
failure.192:
  %ctx.field.194 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 21, ptr %ctx.field.194, align 4
  %status.diagnostic.195 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.195, align 4
  ret void
continue.193:
  %workspace.slot.196 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.169, ptr %workspace.slot.196, align 8
  %workspace.slot.197 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.169, ptr %workspace.slot.197, align 8
  %workspace.slot.198 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.199 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 8, ptr %outputs, i32 2, ptr %workspace.slot.198)
  switch i32 %record.make.status.199, label %runtime.invalid.result.205 [ i32 0, label %runtime.success.200 i32 1, label %runtime.invalid.request.201 i32 2, label %runtime.invalid.reference.202 i32 3, label %runtime.scratch.capacity.203 i32 4, label %runtime.retained.capacity.204 ]
runtime.invalid.request.201:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.202:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.203:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.204:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.205:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.200:
  %record.make.handle.206 = load i64, ptr %workspace.slot.198, align 8
  %ctx.field.207 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.208 = load i32, ptr %ctx.field.207, align 4
  %steps.next.209 = add i32 %steps.current.208, 1
  store i32 %steps.next.209, ptr %ctx.field.207, align 4
  %steps.over.210 = icmp ugt i32 %steps.next.209, 10000
  br i1 %steps.over.210, label %failure.211, label %continue.212
failure.211:
  %ctx.field.213 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 22, ptr %ctx.field.213, align 4
  %status.diagnostic.214 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.214, align 4
  ret void
continue.212:
  %depth.exceeded.215 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.215, label %failure.216, label %continue.217
failure.216:
  %ctx.field.218 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 23, ptr %ctx.field.218, align 4
  %status.diagnostic.219 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.219, align 4
  ret void
continue.217:
  %ctx.field.220 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.221 = load i32, ptr %ctx.field.220, align 4
  %steps.next.222 = add i32 %steps.current.221, 1
  store i32 %steps.next.222, ptr %ctx.field.220, align 4
  %steps.over.223 = icmp ugt i32 %steps.next.222, 10000
  br i1 %steps.over.223, label %failure.224, label %continue.225
failure.224:
  %ctx.field.226 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 24, ptr %ctx.field.226, align 4
  %status.diagnostic.227 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.227, align 4
  ret void
continue.225:
  %depth.exceeded.228 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.228, label %failure.229, label %continue.230
failure.229:
  %ctx.field.231 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 25, ptr %ctx.field.231, align 4
  %status.diagnostic.232 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.232, align 4
  ret void
continue.230:
  %workspace.slot.233 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.206, ptr %workspace.slot.233, align 8
  %workspace.slot.234 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.206, ptr %workspace.slot.234, align 8
  %workspace.slot.235 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.236 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 9, ptr %outputs, i32 2, ptr %workspace.slot.235)
  switch i32 %record.make.status.236, label %runtime.invalid.result.242 [ i32 0, label %runtime.success.237 i32 1, label %runtime.invalid.request.238 i32 2, label %runtime.invalid.reference.239 i32 3, label %runtime.scratch.capacity.240 i32 4, label %runtime.retained.capacity.241 ]
runtime.invalid.request.238:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.239:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.240:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.241:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.242:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.237:
  %record.make.handle.243 = load i64, ptr %workspace.slot.235, align 8
  %ctx.field.244 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.245 = load i32, ptr %ctx.field.244, align 4
  %steps.next.246 = add i32 %steps.current.245, 1
  store i32 %steps.next.246, ptr %ctx.field.244, align 4
  %steps.over.247 = icmp ugt i32 %steps.next.246, 10000
  br i1 %steps.over.247, label %failure.248, label %continue.249
failure.248:
  %ctx.field.250 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 26, ptr %ctx.field.250, align 4
  %status.diagnostic.251 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.251, align 4
  ret void
continue.249:
  %depth.exceeded.252 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.252, label %failure.253, label %continue.254
failure.253:
  %ctx.field.255 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 27, ptr %ctx.field.255, align 4
  %status.diagnostic.256 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.256, align 4
  ret void
continue.254:
  %ctx.field.257 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.258 = load i32, ptr %ctx.field.257, align 4
  %steps.next.259 = add i32 %steps.current.258, 1
  store i32 %steps.next.259, ptr %ctx.field.257, align 4
  %steps.over.260 = icmp ugt i32 %steps.next.259, 10000
  br i1 %steps.over.260, label %failure.261, label %continue.262
failure.261:
  %ctx.field.263 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 28, ptr %ctx.field.263, align 4
  %status.diagnostic.264 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.264, align 4
  ret void
continue.262:
  %depth.exceeded.265 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.265, label %failure.266, label %continue.267
failure.266:
  %ctx.field.268 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 29, ptr %ctx.field.268, align 4
  %status.diagnostic.269 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.269, align 4
  ret void
continue.267:
  %workspace.slot.270 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.243, ptr %workspace.slot.270, align 8
  %workspace.slot.271 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.243, ptr %workspace.slot.271, align 8
  %workspace.slot.272 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.273 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 10, ptr %outputs, i32 2, ptr %workspace.slot.272)
  switch i32 %record.make.status.273, label %runtime.invalid.result.279 [ i32 0, label %runtime.success.274 i32 1, label %runtime.invalid.request.275 i32 2, label %runtime.invalid.reference.276 i32 3, label %runtime.scratch.capacity.277 i32 4, label %runtime.retained.capacity.278 ]
runtime.invalid.request.275:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.276:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.277:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.278:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.279:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.274:
  %record.make.handle.280 = load i64, ptr %workspace.slot.272, align 8
  %ctx.field.281 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.282 = load i32, ptr %ctx.field.281, align 4
  %steps.next.283 = add i32 %steps.current.282, 1
  store i32 %steps.next.283, ptr %ctx.field.281, align 4
  %steps.over.284 = icmp ugt i32 %steps.next.283, 10000
  br i1 %steps.over.284, label %failure.285, label %continue.286
failure.285:
  %ctx.field.287 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 30, ptr %ctx.field.287, align 4
  %status.diagnostic.288 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.288, align 4
  ret void
continue.286:
  %depth.exceeded.289 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.289, label %failure.290, label %continue.291
failure.290:
  %ctx.field.292 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 31, ptr %ctx.field.292, align 4
  %status.diagnostic.293 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.293, align 4
  ret void
continue.291:
  %ctx.field.294 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.295 = load i32, ptr %ctx.field.294, align 4
  %steps.next.296 = add i32 %steps.current.295, 1
  store i32 %steps.next.296, ptr %ctx.field.294, align 4
  %steps.over.297 = icmp ugt i32 %steps.next.296, 10000
  br i1 %steps.over.297, label %failure.298, label %continue.299
failure.298:
  %ctx.field.300 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 32, ptr %ctx.field.300, align 4
  %status.diagnostic.301 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.301, align 4
  ret void
continue.299:
  %depth.exceeded.302 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.302, label %failure.303, label %continue.304
failure.303:
  %ctx.field.305 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 33, ptr %ctx.field.305, align 4
  %status.diagnostic.306 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.306, align 4
  ret void
continue.304:
  %workspace.slot.307 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.280, ptr %workspace.slot.307, align 8
  %workspace.slot.308 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.280, ptr %workspace.slot.308, align 8
  %workspace.slot.309 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.310 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 11, ptr %outputs, i32 2, ptr %workspace.slot.309)
  switch i32 %record.make.status.310, label %runtime.invalid.result.316 [ i32 0, label %runtime.success.311 i32 1, label %runtime.invalid.request.312 i32 2, label %runtime.invalid.reference.313 i32 3, label %runtime.scratch.capacity.314 i32 4, label %runtime.retained.capacity.315 ]
runtime.invalid.request.312:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.313:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.314:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.315:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.316:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.311:
  %record.make.handle.317 = load i64, ptr %workspace.slot.309, align 8
  %ctx.field.318 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.319 = load i32, ptr %ctx.field.318, align 4
  %steps.next.320 = add i32 %steps.current.319, 1
  store i32 %steps.next.320, ptr %ctx.field.318, align 4
  %steps.over.321 = icmp ugt i32 %steps.next.320, 10000
  br i1 %steps.over.321, label %failure.322, label %continue.323
failure.322:
  %ctx.field.324 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 34, ptr %ctx.field.324, align 4
  %status.diagnostic.325 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.325, align 4
  ret void
continue.323:
  %depth.exceeded.326 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.326, label %failure.327, label %continue.328
failure.327:
  %ctx.field.329 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 35, ptr %ctx.field.329, align 4
  %status.diagnostic.330 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.330, align 4
  ret void
continue.328:
  %ctx.field.331 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.332 = load i32, ptr %ctx.field.331, align 4
  %steps.next.333 = add i32 %steps.current.332, 1
  store i32 %steps.next.333, ptr %ctx.field.331, align 4
  %steps.over.334 = icmp ugt i32 %steps.next.333, 10000
  br i1 %steps.over.334, label %failure.335, label %continue.336
failure.335:
  %ctx.field.337 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 36, ptr %ctx.field.337, align 4
  %status.diagnostic.338 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.338, align 4
  ret void
continue.336:
  %depth.exceeded.339 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.339, label %failure.340, label %continue.341
failure.340:
  %ctx.field.342 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 37, ptr %ctx.field.342, align 4
  %status.diagnostic.343 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.343, align 4
  ret void
continue.341:
  %workspace.slot.344 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.317, ptr %workspace.slot.344, align 8
  %workspace.slot.345 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.317, ptr %workspace.slot.345, align 8
  %workspace.slot.346 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.347 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 12, ptr %outputs, i32 2, ptr %workspace.slot.346)
  switch i32 %record.make.status.347, label %runtime.invalid.result.353 [ i32 0, label %runtime.success.348 i32 1, label %runtime.invalid.request.349 i32 2, label %runtime.invalid.reference.350 i32 3, label %runtime.scratch.capacity.351 i32 4, label %runtime.retained.capacity.352 ]
runtime.invalid.request.349:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.350:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.351:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.352:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.353:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.348:
  %record.make.handle.354 = load i64, ptr %workspace.slot.346, align 8
  %ctx.field.355 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.356 = load i32, ptr %ctx.field.355, align 4
  %steps.next.357 = add i32 %steps.current.356, 1
  store i32 %steps.next.357, ptr %ctx.field.355, align 4
  %steps.over.358 = icmp ugt i32 %steps.next.357, 10000
  br i1 %steps.over.358, label %failure.359, label %continue.360
failure.359:
  %ctx.field.361 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 38, ptr %ctx.field.361, align 4
  %status.diagnostic.362 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.362, align 4
  ret void
continue.360:
  %depth.exceeded.363 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.363, label %failure.364, label %continue.365
failure.364:
  %ctx.field.366 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 39, ptr %ctx.field.366, align 4
  %status.diagnostic.367 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.367, align 4
  ret void
continue.365:
  %ctx.field.368 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.369 = load i32, ptr %ctx.field.368, align 4
  %steps.next.370 = add i32 %steps.current.369, 1
  store i32 %steps.next.370, ptr %ctx.field.368, align 4
  %steps.over.371 = icmp ugt i32 %steps.next.370, 10000
  br i1 %steps.over.371, label %failure.372, label %continue.373
failure.372:
  %ctx.field.374 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 40, ptr %ctx.field.374, align 4
  %status.diagnostic.375 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.375, align 4
  ret void
continue.373:
  %depth.exceeded.376 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.376, label %failure.377, label %continue.378
failure.377:
  %ctx.field.379 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 41, ptr %ctx.field.379, align 4
  %status.diagnostic.380 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.380, align 4
  ret void
continue.378:
  %workspace.slot.381 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.354, ptr %workspace.slot.381, align 8
  %workspace.slot.382 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.354, ptr %workspace.slot.382, align 8
  %workspace.slot.383 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.384 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 13, ptr %outputs, i32 2, ptr %workspace.slot.383)
  switch i32 %record.make.status.384, label %runtime.invalid.result.390 [ i32 0, label %runtime.success.385 i32 1, label %runtime.invalid.request.386 i32 2, label %runtime.invalid.reference.387 i32 3, label %runtime.scratch.capacity.388 i32 4, label %runtime.retained.capacity.389 ]
runtime.invalid.request.386:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.387:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.388:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.389:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.390:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.385:
  %record.make.handle.391 = load i64, ptr %workspace.slot.383, align 8
  %ctx.field.392 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.393 = load i32, ptr %ctx.field.392, align 4
  %steps.next.394 = add i32 %steps.current.393, 1
  store i32 %steps.next.394, ptr %ctx.field.392, align 4
  %steps.over.395 = icmp ugt i32 %steps.next.394, 10000
  br i1 %steps.over.395, label %failure.396, label %continue.397
failure.396:
  %ctx.field.398 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 42, ptr %ctx.field.398, align 4
  %status.diagnostic.399 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.399, align 4
  ret void
continue.397:
  %depth.exceeded.400 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.400, label %failure.401, label %continue.402
failure.401:
  %ctx.field.403 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 43, ptr %ctx.field.403, align 4
  %status.diagnostic.404 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.404, align 4
  ret void
continue.402:
  %ctx.field.405 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.406 = load i32, ptr %ctx.field.405, align 4
  %steps.next.407 = add i32 %steps.current.406, 1
  store i32 %steps.next.407, ptr %ctx.field.405, align 4
  %steps.over.408 = icmp ugt i32 %steps.next.407, 10000
  br i1 %steps.over.408, label %failure.409, label %continue.410
failure.409:
  %ctx.field.411 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 44, ptr %ctx.field.411, align 4
  %status.diagnostic.412 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.412, align 4
  ret void
continue.410:
  %depth.exceeded.413 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.413, label %failure.414, label %continue.415
failure.414:
  %ctx.field.416 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 45, ptr %ctx.field.416, align 4
  %status.diagnostic.417 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.417, align 4
  ret void
continue.415:
  %workspace.slot.418 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.391, ptr %workspace.slot.418, align 8
  %workspace.slot.419 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.391, ptr %workspace.slot.419, align 8
  %workspace.slot.420 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.421 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 14, ptr %outputs, i32 2, ptr %workspace.slot.420)
  switch i32 %record.make.status.421, label %runtime.invalid.result.427 [ i32 0, label %runtime.success.422 i32 1, label %runtime.invalid.request.423 i32 2, label %runtime.invalid.reference.424 i32 3, label %runtime.scratch.capacity.425 i32 4, label %runtime.retained.capacity.426 ]
runtime.invalid.request.423:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.424:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.425:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.426:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.427:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.422:
  %record.make.handle.428 = load i64, ptr %workspace.slot.420, align 8
  %ctx.field.429 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.430 = load i32, ptr %ctx.field.429, align 4
  %steps.next.431 = add i32 %steps.current.430, 1
  store i32 %steps.next.431, ptr %ctx.field.429, align 4
  %steps.over.432 = icmp ugt i32 %steps.next.431, 10000
  br i1 %steps.over.432, label %failure.433, label %continue.434
failure.433:
  %ctx.field.435 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 46, ptr %ctx.field.435, align 4
  %status.diagnostic.436 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.436, align 4
  ret void
continue.434:
  %depth.exceeded.437 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.437, label %failure.438, label %continue.439
failure.438:
  %ctx.field.440 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 47, ptr %ctx.field.440, align 4
  %status.diagnostic.441 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.441, align 4
  ret void
continue.439:
  %ctx.field.442 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.443 = load i32, ptr %ctx.field.442, align 4
  %steps.next.444 = add i32 %steps.current.443, 1
  store i32 %steps.next.444, ptr %ctx.field.442, align 4
  %steps.over.445 = icmp ugt i32 %steps.next.444, 10000
  br i1 %steps.over.445, label %failure.446, label %continue.447
failure.446:
  %ctx.field.448 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 48, ptr %ctx.field.448, align 4
  %status.diagnostic.449 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.449, align 4
  ret void
continue.447:
  %depth.exceeded.450 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.450, label %failure.451, label %continue.452
failure.451:
  %ctx.field.453 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 49, ptr %ctx.field.453, align 4
  %status.diagnostic.454 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.454, align 4
  ret void
continue.452:
  %workspace.slot.455 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.428, ptr %workspace.slot.455, align 8
  %workspace.slot.456 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.428, ptr %workspace.slot.456, align 8
  %workspace.slot.457 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.458 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 15, ptr %outputs, i32 2, ptr %workspace.slot.457)
  switch i32 %record.make.status.458, label %runtime.invalid.result.464 [ i32 0, label %runtime.success.459 i32 1, label %runtime.invalid.request.460 i32 2, label %runtime.invalid.reference.461 i32 3, label %runtime.scratch.capacity.462 i32 4, label %runtime.retained.capacity.463 ]
runtime.invalid.request.460:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.461:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.462:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.463:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.464:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.459:
  %record.make.handle.465 = load i64, ptr %workspace.slot.457, align 8
  %ctx.field.466 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.467 = load i32, ptr %ctx.field.466, align 4
  %steps.next.468 = add i32 %steps.current.467, 1
  store i32 %steps.next.468, ptr %ctx.field.466, align 4
  %steps.over.469 = icmp ugt i32 %steps.next.468, 10000
  br i1 %steps.over.469, label %failure.470, label %continue.471
failure.470:
  %ctx.field.472 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 50, ptr %ctx.field.472, align 4
  %status.diagnostic.473 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.473, align 4
  ret void
continue.471:
  %depth.exceeded.474 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.474, label %failure.475, label %continue.476
failure.475:
  %ctx.field.477 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 51, ptr %ctx.field.477, align 4
  %status.diagnostic.478 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.478, align 4
  ret void
continue.476:
  %ctx.field.479 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.480 = load i32, ptr %ctx.field.479, align 4
  %steps.next.481 = add i32 %steps.current.480, 1
  store i32 %steps.next.481, ptr %ctx.field.479, align 4
  %steps.over.482 = icmp ugt i32 %steps.next.481, 10000
  br i1 %steps.over.482, label %failure.483, label %continue.484
failure.483:
  %ctx.field.485 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 52, ptr %ctx.field.485, align 4
  %status.diagnostic.486 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.486, align 4
  ret void
continue.484:
  %depth.exceeded.487 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.487, label %failure.488, label %continue.489
failure.488:
  %ctx.field.490 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 53, ptr %ctx.field.490, align 4
  %status.diagnostic.491 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.491, align 4
  ret void
continue.489:
  %workspace.slot.492 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.465, ptr %workspace.slot.492, align 8
  %workspace.slot.493 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.465, ptr %workspace.slot.493, align 8
  %workspace.slot.494 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.495 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 16, ptr %outputs, i32 2, ptr %workspace.slot.494)
  switch i32 %record.make.status.495, label %runtime.invalid.result.501 [ i32 0, label %runtime.success.496 i32 1, label %runtime.invalid.request.497 i32 2, label %runtime.invalid.reference.498 i32 3, label %runtime.scratch.capacity.499 i32 4, label %runtime.retained.capacity.500 ]
runtime.invalid.request.497:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.498:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.499:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.500:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.501:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.496:
  %record.make.handle.502 = load i64, ptr %workspace.slot.494, align 8
  %ctx.field.503 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.504 = load i32, ptr %ctx.field.503, align 4
  %steps.next.505 = add i32 %steps.current.504, 1
  store i32 %steps.next.505, ptr %ctx.field.503, align 4
  %steps.over.506 = icmp ugt i32 %steps.next.505, 10000
  br i1 %steps.over.506, label %failure.507, label %continue.508
failure.507:
  %ctx.field.509 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 54, ptr %ctx.field.509, align 4
  %status.diagnostic.510 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.510, align 4
  ret void
continue.508:
  %depth.exceeded.511 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.511, label %failure.512, label %continue.513
failure.512:
  %ctx.field.514 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 55, ptr %ctx.field.514, align 4
  %status.diagnostic.515 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.515, align 4
  ret void
continue.513:
  %ctx.field.516 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.517 = load i32, ptr %ctx.field.516, align 4
  %steps.next.518 = add i32 %steps.current.517, 1
  store i32 %steps.next.518, ptr %ctx.field.516, align 4
  %steps.over.519 = icmp ugt i32 %steps.next.518, 10000
  br i1 %steps.over.519, label %failure.520, label %continue.521
failure.520:
  %ctx.field.522 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 56, ptr %ctx.field.522, align 4
  %status.diagnostic.523 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.523, align 4
  ret void
continue.521:
  %depth.exceeded.524 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.524, label %failure.525, label %continue.526
failure.525:
  %ctx.field.527 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 57, ptr %ctx.field.527, align 4
  %status.diagnostic.528 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.528, align 4
  ret void
continue.526:
  %workspace.slot.529 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.502, ptr %workspace.slot.529, align 8
  %workspace.slot.530 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.502, ptr %workspace.slot.530, align 8
  %workspace.slot.531 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.532 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 17, ptr %outputs, i32 2, ptr %workspace.slot.531)
  switch i32 %record.make.status.532, label %runtime.invalid.result.538 [ i32 0, label %runtime.success.533 i32 1, label %runtime.invalid.request.534 i32 2, label %runtime.invalid.reference.535 i32 3, label %runtime.scratch.capacity.536 i32 4, label %runtime.retained.capacity.537 ]
runtime.invalid.request.534:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.535:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.536:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.537:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.538:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.533:
  %record.make.handle.539 = load i64, ptr %workspace.slot.531, align 8
  %ctx.field.540 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.541 = load i32, ptr %ctx.field.540, align 4
  %steps.next.542 = add i32 %steps.current.541, 1
  store i32 %steps.next.542, ptr %ctx.field.540, align 4
  %steps.over.543 = icmp ugt i32 %steps.next.542, 10000
  br i1 %steps.over.543, label %failure.544, label %continue.545
failure.544:
  %ctx.field.546 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 58, ptr %ctx.field.546, align 4
  %status.diagnostic.547 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.547, align 4
  ret void
continue.545:
  %depth.exceeded.548 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.548, label %failure.549, label %continue.550
failure.549:
  %ctx.field.551 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 59, ptr %ctx.field.551, align 4
  %status.diagnostic.552 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.552, align 4
  ret void
continue.550:
  %ctx.field.553 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.554 = load i32, ptr %ctx.field.553, align 4
  %steps.next.555 = add i32 %steps.current.554, 1
  store i32 %steps.next.555, ptr %ctx.field.553, align 4
  %steps.over.556 = icmp ugt i32 %steps.next.555, 10000
  br i1 %steps.over.556, label %failure.557, label %continue.558
failure.557:
  %ctx.field.559 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 60, ptr %ctx.field.559, align 4
  %status.diagnostic.560 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.560, align 4
  ret void
continue.558:
  %depth.exceeded.561 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.561, label %failure.562, label %continue.563
failure.562:
  %ctx.field.564 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 61, ptr %ctx.field.564, align 4
  %status.diagnostic.565 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.565, align 4
  ret void
continue.563:
  %workspace.slot.566 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.539, ptr %workspace.slot.566, align 8
  %workspace.slot.567 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.539, ptr %workspace.slot.567, align 8
  %workspace.slot.568 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.569 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 18, ptr %outputs, i32 2, ptr %workspace.slot.568)
  switch i32 %record.make.status.569, label %runtime.invalid.result.575 [ i32 0, label %runtime.success.570 i32 1, label %runtime.invalid.request.571 i32 2, label %runtime.invalid.reference.572 i32 3, label %runtime.scratch.capacity.573 i32 4, label %runtime.retained.capacity.574 ]
runtime.invalid.request.571:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.572:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.573:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.574:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.575:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.570:
  %record.make.handle.576 = load i64, ptr %workspace.slot.568, align 8
  %ctx.field.577 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.578 = load i32, ptr %ctx.field.577, align 4
  %steps.next.579 = add i32 %steps.current.578, 1
  store i32 %steps.next.579, ptr %ctx.field.577, align 4
  %steps.over.580 = icmp ugt i32 %steps.next.579, 10000
  br i1 %steps.over.580, label %failure.581, label %continue.582
failure.581:
  %ctx.field.583 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 62, ptr %ctx.field.583, align 4
  %status.diagnostic.584 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.584, align 4
  ret void
continue.582:
  %depth.exceeded.585 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.585, label %failure.586, label %continue.587
failure.586:
  %ctx.field.588 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 63, ptr %ctx.field.588, align 4
  %status.diagnostic.589 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.589, align 4
  ret void
continue.587:
  br label %value.limit.failure.590
value.limit.failure.590:
  %ctx.field.592 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 64, ptr %ctx.field.592, align 4
  %status.diagnostic.593 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.593, align 4
  ret void
value.limit.continue.591:
  br label %value.limit.failure.594
value.limit.failure.594:
  %ctx.field.596 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 65, ptr %ctx.field.596, align 4
  %status.diagnostic.597 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.597, align 4
  ret void
value.limit.continue.595:
  %output.ptr.598 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.576, ptr %output.ptr.598, align 8
  %output.ptr.599 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.576, ptr %output.ptr.599, align 8
  ret void
}

define dllexport i32 @agentlang_output_capacity() { ret i32 3 }

define dllexport void @agentlang_abi_layout(ptr %output) {
entry:
  %size.ptr = getelementptr %NativeExecutionContext, ptr null, i32 1
  %size = ptrtoint ptr %size.ptr to i64
  %align.ptr = getelementptr %NativeExecutionContextAlignmentProbe, ptr null, i32 0, i32 1
  %alignment = ptrtoint ptr %align.ptr to i64
  %field0.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 0
  %field0 = ptrtoint ptr %field0.ptr to i64
  %field1.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 1
  %field1 = ptrtoint ptr %field1.ptr to i64
  %field2.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 2
  %field2 = ptrtoint ptr %field2.ptr to i64
  %field3.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 3
  %field3 = ptrtoint ptr %field3.ptr to i64
  %field4.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 4
  %field4 = ptrtoint ptr %field4.ptr to i64
  %field5.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 5
  %field5 = ptrtoint ptr %field5.ptr to i64
  %field6.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 6
  %field6 = ptrtoint ptr %field6.ptr to i64
  %field7.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 7
  %field7 = ptrtoint ptr %field7.ptr to i64
  %field8.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 8
  %field8 = ptrtoint ptr %field8.ptr to i64
  %field9.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 9
  %field9 = ptrtoint ptr %field9.ptr to i64
  %field10.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 10
  %field10 = ptrtoint ptr %field10.ptr to i64
  %items = alloca [13 x i64], align 8
  %out0 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 0
  store i64 %size, ptr %out0, align 8
  %out1 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 1
  store i64 %alignment, ptr %out1, align 8
  %out2 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 2
  store i64 %field0, ptr %out2, align 8
  %out3 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 3
  store i64 %field1, ptr %out3, align 8
  %out4 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 4
  store i64 %field2, ptr %out4, align 8
  %out5 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 5
  store i64 %field3, ptr %out5, align 8
  %out6 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 6
  store i64 %field4, ptr %out6, align 8
  %out7 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 7
  store i64 %field5, ptr %out7, align 8
  %out8 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 8
  store i64 %field6, ptr %out8, align 8
  %out9 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 9
  store i64 %field7, ptr %out9, align 8
  %out10 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 10
  store i64 %field8, ptr %out10, align 8
  %out11 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 11
  store i64 %field9, ptr %out11, align 8
  %out12 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 12
  store i64 %field10, ptr %out12, align 8
  %item0 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 0
  %value0 = load i64, ptr %item0, align 8
  %dest0 = getelementptr inbounds i64, ptr %output, i64 0
  store i64 %value0, ptr %dest0, align 8
  %item1 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 1
  %value1 = load i64, ptr %item1, align 8
  %dest1 = getelementptr inbounds i64, ptr %output, i64 1
  store i64 %value1, ptr %dest1, align 8
  %item2 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 2
  %value2 = load i64, ptr %item2, align 8
  %dest2 = getelementptr inbounds i64, ptr %output, i64 2
  store i64 %value2, ptr %dest2, align 8
  %item3 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 3
  %value3 = load i64, ptr %item3, align 8
  %dest3 = getelementptr inbounds i64, ptr %output, i64 3
  store i64 %value3, ptr %dest3, align 8
  %item4 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 4
  %value4 = load i64, ptr %item4, align 8
  %dest4 = getelementptr inbounds i64, ptr %output, i64 4
  store i64 %value4, ptr %dest4, align 8
  %item5 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 5
  %value5 = load i64, ptr %item5, align 8
  %dest5 = getelementptr inbounds i64, ptr %output, i64 5
  store i64 %value5, ptr %dest5, align 8
  %item6 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 6
  %value6 = load i64, ptr %item6, align 8
  %dest6 = getelementptr inbounds i64, ptr %output, i64 6
  store i64 %value6, ptr %dest6, align 8
  %item7 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 7
  %value7 = load i64, ptr %item7, align 8
  %dest7 = getelementptr inbounds i64, ptr %output, i64 7
  store i64 %value7, ptr %dest7, align 8
  %item8 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 8
  %value8 = load i64, ptr %item8, align 8
  %dest8 = getelementptr inbounds i64, ptr %output, i64 8
  store i64 %value8, ptr %dest8, align 8
  %item9 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 9
  %value9 = load i64, ptr %item9, align 8
  %dest9 = getelementptr inbounds i64, ptr %output, i64 9
  store i64 %value9, ptr %dest9, align 8
  %item10 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 10
  %value10 = load i64, ptr %item10, align 8
  %dest10 = getelementptr inbounds i64, ptr %output, i64 10
  store i64 %value10, ptr %dest10, align 8
  %item11 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 11
  %value11 = load i64, ptr %item11, align 8
  %dest11 = getelementptr inbounds i64, ptr %output, i64 11
  store i64 %value11, ptr %dest11, align 8
  %item12 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 12
  %value12 = load i64, ptr %item12, align 8
  %dest12 = getelementptr inbounds i64, ptr %output, i64 12
  store i64 %value12, ptr %dest12, align 8
  ret void
}

define dllexport void @agentlang_execute(ptr %ctx, ptr %outputs, i32 %capacity, ptr %status) {
entry:
  %validation.result = call i32 @al_runtime_validate_request(ptr %ctx, ptr %outputs, i32 2, i32 %capacity, ptr %status, i32 3)
  %request.valid = icmp eq i32 %validation.result, 0
  br i1 %request.valid, label %request.accepted, label %request.rejected
request.rejected:
  ret void
request.accepted:
  %steps.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  store i32 0, ptr %steps.ptr, align 4
  %error.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 -1, ptr %error.ptr, align 4
  %reserved.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 3
  store i32 0, ptr %reserved.ptr, align 4
  %arg0.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 4
  store i64 0, ptr %arg0.ptr, align 8
  %arg1.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 5
  store i64 0, ptr %arg1.ptr, align 8
  %workspace.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 8
  %workspace = load ptr, ptr %workspace.ptr, align 8
  call void @agentlang_body(ptr %ctx, ptr %workspace, ptr %status, i32 0)
  %body.status = load i32, ptr %status, align 4
  %body.succeeded = icmp eq i32 %body.status, 0
  br i1 %body.succeeded, label %promote, label %body.failed
body.failed:
  ret void
promote:
  %promote.result = call i32 @al_runtime_promote(ptr %ctx, ptr @agentlang_program, ptr %workspace, ptr @agentlang_root_type_ids, i32 2, ptr %outputs, i32 %capacity)
  switch i32 %promote.result, label %promote.invalid [ i32 0, label %promote.succeeded i32 1, label %promote.invalid.request i32 2, label %promote.invalid.reference i32 3, label %promote.scratch.capacity i32 4, label %promote.retained.capacity ]
promote.invalid:
  store i32 2, ptr %status, align 4
  ret void
promote.invalid.request:
  store i32 2, ptr %status, align 4
  ret void
promote.invalid.reference:
  store i32 5, ptr %status, align 4
  ret void
promote.scratch.capacity:
  store i32 3, ptr %status, align 4
  ret void
promote.retained.capacity:
  store i32 4, ptr %status, align 4
  ret void
promote.succeeded:
  ret void
}

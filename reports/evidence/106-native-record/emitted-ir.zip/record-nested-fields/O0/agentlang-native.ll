target triple = "x86_64-pc-windows-msvc"
%NativeExecutionContext = type { i32, i32, i32, i32, i64, i64, ptr, ptr, ptr, i32, i32 }
%NativeExecutionContextAlignmentProbe = type { i8, %NativeExecutionContext }
%NativeTypeDescriptor = type { i32, i32, ptr }
%NativeProgramDescriptor = type { ptr, i32, i32 }
declare i32 @al_runtime_validate_request(ptr, ptr, i32, i32, ptr, i32)
declare i32 @al_runtime_make_record(ptr, ptr, i32, ptr, i32, ptr)
declare i32 @al_runtime_get_field(ptr, ptr, i32, i64, i32, ptr)
declare i32 @al_runtime_equal(ptr, ptr, i32, i64, i64, ptr)
declare i32 @al_runtime_promote(ptr, ptr, ptr, ptr, i32, ptr, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

@agentlang_fields_3 = private constant [2 x i32] [i32 1, i32 0]
@agentlang_fields_5 = private constant [2 x i32] [i32 4, i32 3]
@agentlang_type_descriptors = private constant [6 x %NativeTypeDescriptor] [%NativeTypeDescriptor { i32 1, i32 0, ptr null }, %NativeTypeDescriptor { i32 2, i32 0, ptr null }, %NativeTypeDescriptor { i32 3, i32 0, ptr null }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_3, i32 0, i32 0) }, %NativeTypeDescriptor { i32 1, i32 0, ptr null }, %NativeTypeDescriptor { i32 4, i32 2, ptr getelementptr inbounds ([2 x i32], ptr @agentlang_fields_5, i32 0, i32 0) }]
@agentlang_program = private constant %NativeProgramDescriptor { ptr getelementptr inbounds ([6 x %NativeTypeDescriptor], ptr @agentlang_type_descriptors, i32 0, i32 0), i32 6, i32 0 }
@agentlang_root_type_ids = private constant [3 x i32] [i32 0, i32 5, i32 0]

define internal void @agentlang_body(ptr %ctx, ptr %outputs, ptr %status, i32 %depth) {
entry:
  %ctx.field.0 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1 = load i32, ptr %ctx.field.0, align 4
  %steps.next.2 = add i32 %steps.current.1, 1
  store i32 %steps.next.2, ptr %ctx.field.0, align 4
  %steps.over.3 = icmp ugt i32 %steps.next.2, 10000
  br i1 %steps.over.3, label %failure.4, label %continue.5
failure.4:
  %ctx.field.6 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 0, ptr %ctx.field.6, align 4
  %status.diagnostic.7 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7, align 4
  ret void
continue.5:
  %ctx.field.8 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9 = load i32, ptr %ctx.field.8, align 4
  %steps.next.10 = add i32 %steps.current.9, 1
  store i32 %steps.next.10, ptr %ctx.field.8, align 4
  %steps.over.11 = icmp ugt i32 %steps.next.10, 10000
  br i1 %steps.over.11, label %failure.12, label %continue.13
failure.12:
  %ctx.field.14 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1, ptr %ctx.field.14, align 4
  %status.diagnostic.15 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.15, align 4
  ret void
continue.13:
  %depth.exceeded.16 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.16, label %failure.17, label %continue.18
failure.17:
  %ctx.field.19 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 2, ptr %ctx.field.19, align 4
  %status.diagnostic.20 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.20, align 4
  ret void
continue.18:
  %validator.depth.21 = add i32 %depth, 1
  %depth.exceeded.22 = icmp ugt i32 %validator.depth.21, 64
  br i1 %depth.exceeded.22, label %failure.23, label %continue.24
failure.23:
  %ctx.field.25 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 3, ptr %ctx.field.25, align 4
  %status.diagnostic.26 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.26, align 4
  ret void
continue.24:
  %call.depth.27 = add i32 %validator.depth.21, 1
  call void @agentlang_fn_f45a7718c13ec3a7e88e635c9ae3c3a859e2a99fb2d77734eac659cebc6130d6_r1(ptr %ctx, ptr %outputs, ptr %status, i32 %call.depth.27, i64 7)
  %callee.status.28 = load i32, ptr %status, align 4
  %callee.succeeded.29 = icmp eq i32 %callee.status.28, 0
  br i1 %callee.succeeded.29, label %callee.continue.31, label %callee.failure.30
callee.failure.30:
  ret void
callee.continue.31:
  %call.output.ptr.32 = getelementptr inbounds i64, ptr %outputs, i64 0
  %call.output.33 = load i64, ptr %call.output.ptr.32, align 8
  %validator.accepted.34 = icmp ne i64 %call.output.33, 0
  %validator.failed.35 = xor i1 %validator.accepted.34, true
  br i1 %validator.failed.35, label %failure.36, label %continue.37
failure.36:
  %ctx.field.38 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 4, ptr %ctx.field.38, align 4
  %status.diagnostic.39 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.39, align 4
  ret void
continue.37:
  %ctx.field.40 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.41 = load i32, ptr %ctx.field.40, align 4
  %steps.next.42 = add i32 %steps.current.41, 1
  store i32 %steps.next.42, ptr %ctx.field.40, align 4
  %steps.over.43 = icmp ugt i32 %steps.next.42, 10000
  br i1 %steps.over.43, label %failure.44, label %continue.45
failure.44:
  %ctx.field.46 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 5, ptr %ctx.field.46, align 4
  %status.diagnostic.47 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.47, align 4
  ret void
continue.45:
  %ctx.field.48 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.49 = load i32, ptr %ctx.field.48, align 4
  %steps.next.50 = add i32 %steps.current.49, 1
  store i32 %steps.next.50, ptr %ctx.field.48, align 4
  %steps.over.51 = icmp ugt i32 %steps.next.50, 10000
  br i1 %steps.over.51, label %failure.52, label %continue.53
failure.52:
  %ctx.field.54 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 6, ptr %ctx.field.54, align 4
  %status.diagnostic.55 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.55, align 4
  ret void
continue.53:
  %ctx.field.56 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.57 = load i32, ptr %ctx.field.56, align 4
  %steps.next.58 = add i32 %steps.current.57, 1
  store i32 %steps.next.58, ptr %ctx.field.56, align 4
  %steps.over.59 = icmp ugt i32 %steps.next.58, 10000
  br i1 %steps.over.59, label %failure.60, label %continue.61
failure.60:
  %ctx.field.62 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 7, ptr %ctx.field.62, align 4
  %status.diagnostic.63 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.63, align 4
  ret void
continue.61:
  %ctx.field.64 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.65 = load i32, ptr %ctx.field.64, align 4
  %steps.next.66 = add i32 %steps.current.65, 1
  store i32 %steps.next.66, ptr %ctx.field.64, align 4
  %steps.over.67 = icmp ugt i32 %steps.next.66, 10000
  br i1 %steps.over.67, label %failure.68, label %continue.69
failure.68:
  %ctx.field.70 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 8, ptr %ctx.field.70, align 4
  %status.diagnostic.71 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.71, align 4
  ret void
continue.69:
  %depth.exceeded.72 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.72, label %failure.73, label %continue.74
failure.73:
  %ctx.field.75 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 9, ptr %ctx.field.75, align 4
  %status.diagnostic.76 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.76, align 4
  ret void
continue.74:
  %workspace.slot.77 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 1, ptr %workspace.slot.77, align 8
  %workspace.slot.78 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 17, ptr %workspace.slot.78, align 8
  %workspace.slot.79 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.80 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 3, ptr %outputs, i32 2, ptr %workspace.slot.79)
  switch i32 %record.make.status.80, label %runtime.invalid.result.86 [ i32 0, label %runtime.success.81 i32 1, label %runtime.invalid.request.82 i32 2, label %runtime.invalid.reference.83 i32 3, label %runtime.scratch.capacity.84 i32 4, label %runtime.retained.capacity.85 ]
runtime.invalid.request.82:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.83:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.84:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.85:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.86:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.81:
  %record.make.handle.87 = load i64, ptr %workspace.slot.79, align 8
  %ctx.field.88 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.89 = load i32, ptr %ctx.field.88, align 4
  %steps.next.90 = add i32 %steps.current.89, 1
  store i32 %steps.next.90, ptr %ctx.field.88, align 4
  %steps.over.91 = icmp ugt i32 %steps.next.90, 10000
  br i1 %steps.over.91, label %failure.92, label %continue.93
failure.92:
  %ctx.field.94 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 10, ptr %ctx.field.94, align 4
  %status.diagnostic.95 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.95, align 4
  ret void
continue.93:
  %ctx.field.96 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.97 = load i32, ptr %ctx.field.96, align 4
  %steps.next.98 = add i32 %steps.current.97, 1
  store i32 %steps.next.98, ptr %ctx.field.96, align 4
  %steps.over.99 = icmp ugt i32 %steps.next.98, 10000
  br i1 %steps.over.99, label %failure.100, label %continue.101
failure.100:
  %ctx.field.102 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 11, ptr %ctx.field.102, align 4
  %status.diagnostic.103 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.103, align 4
  ret void
continue.101:
  %ctx.field.104 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.105 = load i32, ptr %ctx.field.104, align 4
  %steps.next.106 = add i32 %steps.current.105, 1
  store i32 %steps.next.106, ptr %ctx.field.104, align 4
  %steps.over.107 = icmp ugt i32 %steps.next.106, 10000
  br i1 %steps.over.107, label %failure.108, label %continue.109
failure.108:
  %ctx.field.110 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 12, ptr %ctx.field.110, align 4
  %status.diagnostic.111 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.111, align 4
  ret void
continue.109:
  %if.condition.112 = icmp ne i64 0, 0
  br i1 %if.condition.112, label %if.then.113, label %if.else.114
if.then.113:
  %ctx.field.116 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.117 = load i32, ptr %ctx.field.116, align 4
  %steps.next.118 = add i32 %steps.current.117, 1
  store i32 %steps.next.118, ptr %ctx.field.116, align 4
  %steps.over.119 = icmp ugt i32 %steps.next.118, 10000
  br i1 %steps.over.119, label %failure.120, label %continue.121
failure.120:
  %ctx.field.122 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 13, ptr %ctx.field.122, align 4
  %status.diagnostic.123 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.123, align 4
  ret void
continue.121:
  %ctx.field.124 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.125 = load i32, ptr %ctx.field.124, align 4
  %steps.next.126 = add i32 %steps.current.125, 1
  store i32 %steps.next.126, ptr %ctx.field.124, align 4
  %steps.over.127 = icmp ugt i32 %steps.next.126, 10000
  br i1 %steps.over.127, label %failure.128, label %continue.129
failure.128:
  %ctx.field.130 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 14, ptr %ctx.field.130, align 4
  %status.diagnostic.131 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.131, align 4
  ret void
continue.129:
  %ctx.field.132 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.133 = load i32, ptr %ctx.field.132, align 4
  %steps.next.134 = add i32 %steps.current.133, 1
  store i32 %steps.next.134, ptr %ctx.field.132, align 4
  %steps.over.135 = icmp ugt i32 %steps.next.134, 10000
  br i1 %steps.over.135, label %failure.136, label %continue.137
failure.136:
  %ctx.field.138 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 15, ptr %ctx.field.138, align 4
  %status.diagnostic.139 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.139, align 4
  ret void
continue.137:
  %depth.exceeded.140 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.140, label %failure.141, label %continue.142
failure.141:
  %ctx.field.143 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 16, ptr %ctx.field.143, align 4
  %status.diagnostic.144 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.144, align 4
  ret void
continue.142:
  %workspace.slot.145 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 0, ptr %workspace.slot.145, align 8
  %workspace.slot.146 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 99, ptr %workspace.slot.146, align 8
  %workspace.slot.147 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.148 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 3, ptr %outputs, i32 2, ptr %workspace.slot.147)
  switch i32 %record.make.status.148, label %runtime.invalid.result.154 [ i32 0, label %runtime.success.149 i32 1, label %runtime.invalid.request.150 i32 2, label %runtime.invalid.reference.151 i32 3, label %runtime.scratch.capacity.152 i32 4, label %runtime.retained.capacity.153 ]
runtime.invalid.request.150:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.151:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.152:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.153:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.154:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.149:
  %record.make.handle.155 = load i64, ptr %workspace.slot.147, align 8
  br label %if.merge.115
if.else.114:
  %ctx.field.156 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.157 = load i32, ptr %ctx.field.156, align 4
  %steps.next.158 = add i32 %steps.current.157, 1
  store i32 %steps.next.158, ptr %ctx.field.156, align 4
  %steps.over.159 = icmp ugt i32 %steps.next.158, 10000
  br i1 %steps.over.159, label %failure.160, label %continue.161
failure.160:
  %ctx.field.162 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 17, ptr %ctx.field.162, align 4
  %status.diagnostic.163 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.163, align 4
  ret void
continue.161:
  br label %if.merge.115
if.merge.115:
  %stack.phi.164 = phi i64 [ %record.make.handle.155, %runtime.success.149 ], [ %record.make.handle.87, %continue.161 ]
  %local.phi.165 = phi i64 [ 7, %runtime.success.149 ], [ 7, %continue.161 ]
  %local.phi.166 = phi i64 [ %record.make.handle.87, %runtime.success.149 ], [ %record.make.handle.87, %continue.161 ]
  %ctx.field.167 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.168 = load i32, ptr %ctx.field.167, align 4
  %steps.next.169 = add i32 %steps.current.168, 1
  store i32 %steps.next.169, ptr %ctx.field.167, align 4
  %steps.over.170 = icmp ugt i32 %steps.next.169, 10000
  br i1 %steps.over.170, label %failure.171, label %continue.172
failure.171:
  %ctx.field.173 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 18, ptr %ctx.field.173, align 4
  %status.diagnostic.174 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.174, align 4
  ret void
continue.172:
  %ctx.field.175 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.176 = load i32, ptr %ctx.field.175, align 4
  %steps.next.177 = add i32 %steps.current.176, 1
  store i32 %steps.next.177, ptr %ctx.field.175, align 4
  %steps.over.178 = icmp ugt i32 %steps.next.177, 10000
  br i1 %steps.over.178, label %failure.179, label %continue.180
failure.179:
  %ctx.field.181 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 19, ptr %ctx.field.181, align 4
  %status.diagnostic.182 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.182, align 4
  ret void
continue.180:
  %ctx.field.183 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.184 = load i32, ptr %ctx.field.183, align 4
  %steps.next.185 = add i32 %steps.current.184, 1
  store i32 %steps.next.185, ptr %ctx.field.183, align 4
  %steps.over.186 = icmp ugt i32 %steps.next.185, 10000
  br i1 %steps.over.186, label %failure.187, label %continue.188
failure.187:
  %ctx.field.189 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 20, ptr %ctx.field.189, align 4
  %status.diagnostic.190 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.190, align 4
  ret void
continue.188:
  %ctx.field.191 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.192 = load i32, ptr %ctx.field.191, align 4
  %steps.next.193 = add i32 %steps.current.192, 1
  store i32 %steps.next.193, ptr %ctx.field.191, align 4
  %steps.over.194 = icmp ugt i32 %steps.next.193, 10000
  br i1 %steps.over.194, label %failure.195, label %continue.196
failure.195:
  %ctx.field.197 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 21, ptr %ctx.field.197, align 4
  %status.diagnostic.198 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.198, align 4
  ret void
continue.196:
  %depth.exceeded.199 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.199, label %failure.200, label %continue.201
failure.200:
  %ctx.field.202 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 22, ptr %ctx.field.202, align 4
  %status.diagnostic.203 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.203, align 4
  ret void
continue.201:
  %workspace.slot.204 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %local.phi.165, ptr %workspace.slot.204, align 8
  %workspace.slot.205 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %stack.phi.164, ptr %workspace.slot.205, align 8
  %workspace.slot.206 = getelementptr inbounds i64, ptr %outputs, i64 2
  %record.make.status.207 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 5, ptr %outputs, i32 2, ptr %workspace.slot.206)
  switch i32 %record.make.status.207, label %runtime.invalid.result.213 [ i32 0, label %runtime.success.208 i32 1, label %runtime.invalid.request.209 i32 2, label %runtime.invalid.reference.210 i32 3, label %runtime.scratch.capacity.211 i32 4, label %runtime.retained.capacity.212 ]
runtime.invalid.request.209:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.210:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.211:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.212:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.213:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.208:
  %record.make.handle.214 = load i64, ptr %workspace.slot.206, align 8
  %ctx.field.215 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.216 = load i32, ptr %ctx.field.215, align 4
  %steps.next.217 = add i32 %steps.current.216, 1
  store i32 %steps.next.217, ptr %ctx.field.215, align 4
  %steps.over.218 = icmp ugt i32 %steps.next.217, 10000
  br i1 %steps.over.218, label %failure.219, label %continue.220
failure.219:
  %ctx.field.221 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 23, ptr %ctx.field.221, align 4
  %status.diagnostic.222 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.222, align 4
  ret void
continue.220:
  %depth.exceeded.223 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.223, label %failure.224, label %continue.225
failure.224:
  %ctx.field.226 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 24, ptr %ctx.field.226, align 4
  %status.diagnostic.227 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.227, align 4
  ret void
continue.225:
  %ctx.field.228 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.229 = load i32, ptr %ctx.field.228, align 4
  %steps.next.230 = add i32 %steps.current.229, 1
  store i32 %steps.next.230, ptr %ctx.field.228, align 4
  %steps.over.231 = icmp ugt i32 %steps.next.230, 10000
  br i1 %steps.over.231, label %failure.232, label %continue.233
failure.232:
  %ctx.field.234 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 25, ptr %ctx.field.234, align 4
  %status.diagnostic.235 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.235, align 4
  ret void
continue.233:
  %depth.exceeded.236 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.236, label %failure.237, label %continue.238
failure.237:
  %ctx.field.239 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 26, ptr %ctx.field.239, align 4
  %status.diagnostic.240 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.240, align 4
  ret void
continue.238:
  %workspace.slot.241 = getelementptr inbounds i64, ptr %outputs, i64 0
  %record.field.status.242 = call i32 @al_runtime_get_field(ptr %ctx, ptr @agentlang_program, i32 5, i64 %record.make.handle.214, i32 1, ptr %workspace.slot.241)
  switch i32 %record.field.status.242, label %runtime.invalid.result.248 [ i32 0, label %runtime.success.243 i32 1, label %runtime.invalid.request.244 i32 2, label %runtime.invalid.reference.245 i32 3, label %runtime.scratch.capacity.246 i32 4, label %runtime.retained.capacity.247 ]
runtime.invalid.request.244:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.245:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.246:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.247:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.248:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.243:
  %record.field.value.249 = load i64, ptr %workspace.slot.241, align 8
  %ctx.field.250 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.251 = load i32, ptr %ctx.field.250, align 4
  %steps.next.252 = add i32 %steps.current.251, 1
  store i32 %steps.next.252, ptr %ctx.field.250, align 4
  %steps.over.253 = icmp ugt i32 %steps.next.252, 10000
  br i1 %steps.over.253, label %failure.254, label %continue.255
failure.254:
  %ctx.field.256 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 27, ptr %ctx.field.256, align 4
  %status.diagnostic.257 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.257, align 4
  ret void
continue.255:
  %depth.exceeded.258 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.258, label %failure.259, label %continue.260
failure.259:
  %ctx.field.261 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 28, ptr %ctx.field.261, align 4
  %status.diagnostic.262 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.262, align 4
  ret void
continue.260:
  %workspace.slot.263 = getelementptr inbounds i64, ptr %outputs, i64 0
  %record.field.status.264 = call i32 @al_runtime_get_field(ptr %ctx, ptr @agentlang_program, i32 3, i64 %record.field.value.249, i32 1, ptr %workspace.slot.263)
  switch i32 %record.field.status.264, label %runtime.invalid.result.270 [ i32 0, label %runtime.success.265 i32 1, label %runtime.invalid.request.266 i32 2, label %runtime.invalid.reference.267 i32 3, label %runtime.scratch.capacity.268 i32 4, label %runtime.retained.capacity.269 ]
runtime.invalid.request.266:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.267:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.268:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.269:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.270:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.265:
  %record.field.value.271 = load i64, ptr %workspace.slot.263, align 8
  %ctx.field.272 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.273 = load i32, ptr %ctx.field.272, align 4
  %steps.next.274 = add i32 %steps.current.273, 1
  store i32 %steps.next.274, ptr %ctx.field.272, align 4
  %steps.over.275 = icmp ugt i32 %steps.next.274, 10000
  br i1 %steps.over.275, label %failure.276, label %continue.277
failure.276:
  %ctx.field.278 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 29, ptr %ctx.field.278, align 4
  %status.diagnostic.279 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.279, align 4
  ret void
continue.277:
  %depth.exceeded.280 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.280, label %failure.281, label %continue.282
failure.281:
  %ctx.field.283 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 30, ptr %ctx.field.283, align 4
  %status.diagnostic.284 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.284, align 4
  ret void
continue.282:
  %ctx.field.285 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.286 = load i32, ptr %ctx.field.285, align 4
  %steps.next.287 = add i32 %steps.current.286, 1
  store i32 %steps.next.287, ptr %ctx.field.285, align 4
  %steps.over.288 = icmp ugt i32 %steps.next.287, 10000
  br i1 %steps.over.288, label %failure.289, label %continue.290
failure.289:
  %ctx.field.291 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 31, ptr %ctx.field.291, align 4
  %status.diagnostic.292 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.292, align 4
  ret void
continue.290:
  %depth.exceeded.293 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.293, label %failure.294, label %continue.295
failure.294:
  %ctx.field.296 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 32, ptr %ctx.field.296, align 4
  %status.diagnostic.297 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.297, align 4
  ret void
continue.295:
  %ctx.field.298 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.299 = load i32, ptr %ctx.field.298, align 4
  %steps.next.300 = add i32 %steps.current.299, 1
  store i32 %steps.next.300, ptr %ctx.field.298, align 4
  %steps.over.301 = icmp ugt i32 %steps.next.300, 10000
  br i1 %steps.over.301, label %failure.302, label %continue.303
failure.302:
  %ctx.field.304 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 33, ptr %ctx.field.304, align 4
  %status.diagnostic.305 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.305, align 4
  ret void
continue.303:
  %depth.exceeded.306 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.306, label %failure.307, label %continue.308
failure.307:
  %ctx.field.309 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 34, ptr %ctx.field.309, align 4
  %status.diagnostic.310 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.310, align 4
  ret void
continue.308:
  %workspace.slot.311 = getelementptr inbounds i64, ptr %outputs, i64 0
  %record.field.status.312 = call i32 @al_runtime_get_field(ptr %ctx, ptr @agentlang_program, i32 5, i64 %record.make.handle.214, i32 0, ptr %workspace.slot.311)
  switch i32 %record.field.status.312, label %runtime.invalid.result.318 [ i32 0, label %runtime.success.313 i32 1, label %runtime.invalid.request.314 i32 2, label %runtime.invalid.reference.315 i32 3, label %runtime.scratch.capacity.316 i32 4, label %runtime.retained.capacity.317 ]
runtime.invalid.request.314:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.315:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.316:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.317:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.318:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.313:
  %record.field.value.319 = load i64, ptr %workspace.slot.311, align 8
  %ctx.field.320 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.321 = load i32, ptr %ctx.field.320, align 4
  %steps.next.322 = add i32 %steps.current.321, 1
  store i32 %steps.next.322, ptr %ctx.field.320, align 4
  %steps.over.323 = icmp ugt i32 %steps.next.322, 10000
  br i1 %steps.over.323, label %failure.324, label %continue.325
failure.324:
  %ctx.field.326 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 35, ptr %ctx.field.326, align 4
  %status.diagnostic.327 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.327, align 4
  ret void
continue.325:
  %depth.exceeded.328 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.328, label %failure.329, label %continue.330
failure.329:
  %ctx.field.331 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 36, ptr %ctx.field.331, align 4
  %status.diagnostic.332 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.332, align 4
  ret void
continue.330:
  %output.ptr.333 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.field.value.271, ptr %output.ptr.333, align 8
  %output.ptr.334 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %record.make.handle.214, ptr %output.ptr.334, align 8
  %output.ptr.335 = getelementptr inbounds i64, ptr %outputs, i64 2
  store i64 %record.field.value.319, ptr %output.ptr.335, align 8
  ret void
}

define internal void @agentlang_fn_f45a7718c13ec3a7e88e635c9ae3c3a859e2a99fb2d77734eac659cebc6130d6_r1(ptr %ctx, ptr %outputs, ptr %status, i32 %depth, i64 %arg0) {
entry:
  %ctx.field.0 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1 = load i32, ptr %ctx.field.0, align 4
  %steps.next.2 = add i32 %steps.current.1, 1
  store i32 %steps.next.2, ptr %ctx.field.0, align 4
  %steps.over.3 = icmp ugt i32 %steps.next.2, 10000
  br i1 %steps.over.3, label %failure.4, label %continue.5
failure.4:
  %ctx.field.6 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 37, ptr %ctx.field.6, align 4
  %status.diagnostic.7 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7, align 4
  ret void
continue.5:
  %ctx.field.8 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9 = load i32, ptr %ctx.field.8, align 4
  %steps.next.10 = add i32 %steps.current.9, 1
  store i32 %steps.next.10, ptr %ctx.field.8, align 4
  %steps.over.11 = icmp ugt i32 %steps.next.10, 10000
  br i1 %steps.over.11, label %failure.12, label %continue.13
failure.12:
  %ctx.field.14 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 38, ptr %ctx.field.14, align 4
  %status.diagnostic.15 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.15, align 4
  ret void
continue.13:
  %depth.exceeded.16 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.16, label %failure.17, label %continue.18
failure.17:
  %ctx.field.19 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 39, ptr %ctx.field.19, align 4
  %status.diagnostic.20 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.20, align 4
  ret void
continue.18:
  %int.compare.21 = icmp sgt i64 %arg0, 0
  %bool.slot.22 = zext i1 %int.compare.21 to i64
  %output.ptr.23 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %bool.slot.22, ptr %output.ptr.23, align 8
  ret void
}

define dllexport i32 @agentlang_output_capacity() { ret i32 3 }

define dllexport void @agentlang_abi_layout(ptr %output) {
entry:
  %size.ptr = getelementptr %NativeExecutionContext, ptr null, i32 1
  %size = ptrtoint ptr %size.ptr to i64
  %align.ptr = getelementptr %NativeExecutionContextAlignmentProbe, ptr null, i32 0, i32 1
  %alignment = ptrtoint ptr %align.ptr to i64
  %field0.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 0
  %field0 = ptrtoint ptr %field0.ptr to i64
  %field1.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 1
  %field1 = ptrtoint ptr %field1.ptr to i64
  %field2.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 2
  %field2 = ptrtoint ptr %field2.ptr to i64
  %field3.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 3
  %field3 = ptrtoint ptr %field3.ptr to i64
  %field4.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 4
  %field4 = ptrtoint ptr %field4.ptr to i64
  %field5.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 5
  %field5 = ptrtoint ptr %field5.ptr to i64
  %field6.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 6
  %field6 = ptrtoint ptr %field6.ptr to i64
  %field7.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 7
  %field7 = ptrtoint ptr %field7.ptr to i64
  %field8.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 8
  %field8 = ptrtoint ptr %field8.ptr to i64
  %field9.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 9
  %field9 = ptrtoint ptr %field9.ptr to i64
  %field10.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 10
  %field10 = ptrtoint ptr %field10.ptr to i64
  %items = alloca [13 x i64], align 8
  %out0 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 0
  store i64 %size, ptr %out0, align 8
  %out1 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 1
  store i64 %alignment, ptr %out1, align 8
  %out2 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 2
  store i64 %field0, ptr %out2, align 8
  %out3 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 3
  store i64 %field1, ptr %out3, align 8
  %out4 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 4
  store i64 %field2, ptr %out4, align 8
  %out5 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 5
  store i64 %field3, ptr %out5, align 8
  %out6 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 6
  store i64 %field4, ptr %out6, align 8
  %out7 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 7
  store i64 %field5, ptr %out7, align 8
  %out8 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 8
  store i64 %field6, ptr %out8, align 8
  %out9 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 9
  store i64 %field7, ptr %out9, align 8
  %out10 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 10
  store i64 %field8, ptr %out10, align 8
  %out11 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 11
  store i64 %field9, ptr %out11, align 8
  %out12 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 12
  store i64 %field10, ptr %out12, align 8
  %item0 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 0
  %value0 = load i64, ptr %item0, align 8
  %dest0 = getelementptr inbounds i64, ptr %output, i64 0
  store i64 %value0, ptr %dest0, align 8
  %item1 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 1
  %value1 = load i64, ptr %item1, align 8
  %dest1 = getelementptr inbounds i64, ptr %output, i64 1
  store i64 %value1, ptr %dest1, align 8
  %item2 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 2
  %value2 = load i64, ptr %item2, align 8
  %dest2 = getelementptr inbounds i64, ptr %output, i64 2
  store i64 %value2, ptr %dest2, align 8
  %item3 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 3
  %value3 = load i64, ptr %item3, align 8
  %dest3 = getelementptr inbounds i64, ptr %output, i64 3
  store i64 %value3, ptr %dest3, align 8
  %item4 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 4
  %value4 = load i64, ptr %item4, align 8
  %dest4 = getelementptr inbounds i64, ptr %output, i64 4
  store i64 %value4, ptr %dest4, align 8
  %item5 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 5
  %value5 = load i64, ptr %item5, align 8
  %dest5 = getelementptr inbounds i64, ptr %output, i64 5
  store i64 %value5, ptr %dest5, align 8
  %item6 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 6
  %value6 = load i64, ptr %item6, align 8
  %dest6 = getelementptr inbounds i64, ptr %output, i64 6
  store i64 %value6, ptr %dest6, align 8
  %item7 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 7
  %value7 = load i64, ptr %item7, align 8
  %dest7 = getelementptr inbounds i64, ptr %output, i64 7
  store i64 %value7, ptr %dest7, align 8
  %item8 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 8
  %value8 = load i64, ptr %item8, align 8
  %dest8 = getelementptr inbounds i64, ptr %output, i64 8
  store i64 %value8, ptr %dest8, align 8
  %item9 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 9
  %value9 = load i64, ptr %item9, align 8
  %dest9 = getelementptr inbounds i64, ptr %output, i64 9
  store i64 %value9, ptr %dest9, align 8
  %item10 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 10
  %value10 = load i64, ptr %item10, align 8
  %dest10 = getelementptr inbounds i64, ptr %output, i64 10
  store i64 %value10, ptr %dest10, align 8
  %item11 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 11
  %value11 = load i64, ptr %item11, align 8
  %dest11 = getelementptr inbounds i64, ptr %output, i64 11
  store i64 %value11, ptr %dest11, align 8
  %item12 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 12
  %value12 = load i64, ptr %item12, align 8
  %dest12 = getelementptr inbounds i64, ptr %output, i64 12
  store i64 %value12, ptr %dest12, align 8
  ret void
}

define dllexport void @agentlang_execute(ptr %ctx, ptr %outputs, i32 %capacity, ptr %status) {
entry:
  %validation.result = call i32 @al_runtime_validate_request(ptr %ctx, ptr %outputs, i32 3, i32 %capacity, ptr %status, i32 3)
  %request.valid = icmp eq i32 %validation.result, 0
  br i1 %request.valid, label %request.accepted, label %request.rejected
request.rejected:
  ret void
request.accepted:
  %steps.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  store i32 0, ptr %steps.ptr, align 4
  %error.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 -1, ptr %error.ptr, align 4
  %reserved.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 3
  store i32 0, ptr %reserved.ptr, align 4
  %arg0.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 4
  store i64 0, ptr %arg0.ptr, align 8
  %arg1.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 5
  store i64 0, ptr %arg1.ptr, align 8
  %workspace.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 8
  %workspace = load ptr, ptr %workspace.ptr, align 8
  call void @agentlang_body(ptr %ctx, ptr %workspace, ptr %status, i32 0)
  %body.status = load i32, ptr %status, align 4
  %body.succeeded = icmp eq i32 %body.status, 0
  br i1 %body.succeeded, label %promote, label %body.failed
body.failed:
  ret void
promote:
  %promote.result = call i32 @al_runtime_promote(ptr %ctx, ptr @agentlang_program, ptr %workspace, ptr @agentlang_root_type_ids, i32 3, ptr %outputs, i32 %capacity)
  switch i32 %promote.result, label %promote.invalid [ i32 0, label %promote.succeeded i32 1, label %promote.invalid.request i32 2, label %promote.invalid.reference i32 3, label %promote.scratch.capacity i32 4, label %promote.retained.capacity ]
promote.invalid:
  store i32 2, ptr %status, align 4
  ret void
promote.invalid.request:
  store i32 2, ptr %status, align 4
  ret void
promote.invalid.reference:
  store i32 5, ptr %status, align 4
  ret void
promote.scratch.capacity:
  store i32 3, ptr %status, align 4
  ret void
promote.retained.capacity:
  store i32 4, ptr %status, align 4
  ret void
promote.succeeded:
  ret void
}

target triple = "x86_64-pc-windows-msvc"
%NativeExecutionContext = type { i32, i32, i32, i32, i64, i64, ptr, ptr, ptr, i32, i32 }
%NativeExecutionContextAlignmentProbe = type { i8, %NativeExecutionContext }
%NativeTypeDescriptor = type { i32, i32, ptr }
%NativeProgramDescriptor = type { ptr, i32, i32 }
declare i32 @al_runtime_validate_request(ptr, ptr, i32, i32, ptr, i32)
declare i32 @al_runtime_make_record(ptr, ptr, i32, ptr, i32, ptr)
declare i32 @al_runtime_get_field(ptr, ptr, i32, i64, i32, ptr)
declare i32 @al_runtime_equal(ptr, ptr, i32, i64, i64, ptr)
declare i32 @al_runtime_promote(ptr, ptr, ptr, ptr, i32, ptr, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

@agentlang_fields_3 = private constant [1 x i32] [i32 0]
@agentlang_fields_4 = private constant [1 x i32] [i32 3]
@agentlang_fields_5 = private constant [1 x i32] [i32 248]
@agentlang_fields_6 = private constant [1 x i32] [i32 258]
@agentlang_fields_7 = private constant [1 x i32] [i32 6]
@agentlang_fields_8 = private constant [1 x i32] [i32 7]
@agentlang_fields_9 = private constant [1 x i32] [i32 8]
@agentlang_fields_10 = private constant [1 x i32] [i32 9]
@agentlang_fields_11 = private constant [1 x i32] [i32 10]
@agentlang_fields_12 = private constant [1 x i32] [i32 11]
@agentlang_fields_13 = private constant [1 x i32] [i32 12]
@agentlang_fields_14 = private constant [1 x i32] [i32 13]
@agentlang_fields_15 = private constant [1 x i32] [i32 14]
@agentlang_fields_16 = private constant [1 x i32] [i32 5]
@agentlang_fields_17 = private constant [1 x i32] [i32 15]
@agentlang_fields_18 = private constant [1 x i32] [i32 17]
@agentlang_fields_19 = private constant [1 x i32] [i32 18]
@agentlang_fields_20 = private constant [1 x i32] [i32 19]
@agentlang_fields_21 = private constant [1 x i32] [i32 20]
@agentlang_fields_22 = private constant [1 x i32] [i32 21]
@agentlang_fields_23 = private constant [1 x i32] [i32 22]
@agentlang_fields_24 = private constant [1 x i32] [i32 23]
@agentlang_fields_25 = private constant [1 x i32] [i32 24]
@agentlang_fields_26 = private constant [1 x i32] [i32 25]
@agentlang_fields_27 = private constant [1 x i32] [i32 16]
@agentlang_fields_28 = private constant [1 x i32] [i32 26]
@agentlang_fields_29 = private constant [1 x i32] [i32 28]
@agentlang_fields_30 = private constant [1 x i32] [i32 29]
@agentlang_fields_31 = private constant [1 x i32] [i32 30]
@agentlang_fields_32 = private constant [1 x i32] [i32 31]
@agentlang_fields_33 = private constant [1 x i32] [i32 32]
@agentlang_fields_34 = private constant [1 x i32] [i32 33]
@agentlang_fields_35 = private constant [1 x i32] [i32 34]
@agentlang_fields_36 = private constant [1 x i32] [i32 35]
@agentlang_fields_37 = private constant [1 x i32] [i32 36]
@agentlang_fields_38 = private constant [1 x i32] [i32 27]
@agentlang_fields_39 = private constant [1 x i32] [i32 37]
@agentlang_fields_40 = private constant [1 x i32] [i32 39]
@agentlang_fields_41 = private constant [1 x i32] [i32 40]
@agentlang_fields_42 = private constant [1 x i32] [i32 41]
@agentlang_fields_43 = private constant [1 x i32] [i32 42]
@agentlang_fields_44 = private constant [1 x i32] [i32 43]
@agentlang_fields_45 = private constant [1 x i32] [i32 44]
@agentlang_fields_46 = private constant [1 x i32] [i32 45]
@agentlang_fields_47 = private constant [1 x i32] [i32 46]
@agentlang_fields_48 = private constant [1 x i32] [i32 47]
@agentlang_fields_49 = private constant [1 x i32] [i32 38]
@agentlang_fields_50 = private constant [1 x i32] [i32 48]
@agentlang_fields_51 = private constant [1 x i32] [i32 50]
@agentlang_fields_52 = private constant [1 x i32] [i32 51]
@agentlang_fields_53 = private constant [1 x i32] [i32 52]
@agentlang_fields_54 = private constant [1 x i32] [i32 53]
@agentlang_fields_55 = private constant [1 x i32] [i32 54]
@agentlang_fields_56 = private constant [1 x i32] [i32 55]
@agentlang_fields_57 = private constant [1 x i32] [i32 56]
@agentlang_fields_58 = private constant [1 x i32] [i32 57]
@agentlang_fields_59 = private constant [1 x i32] [i32 58]
@agentlang_fields_60 = private constant [1 x i32] [i32 49]
@agentlang_fields_61 = private constant [1 x i32] [i32 59]
@agentlang_fields_62 = private constant [1 x i32] [i32 61]
@agentlang_fields_63 = private constant [1 x i32] [i32 62]
@agentlang_fields_64 = private constant [1 x i32] [i32 63]
@agentlang_fields_65 = private constant [1 x i32] [i32 64]
@agentlang_fields_66 = private constant [1 x i32] [i32 65]
@agentlang_fields_67 = private constant [1 x i32] [i32 66]
@agentlang_fields_68 = private constant [1 x i32] [i32 67]
@agentlang_fields_69 = private constant [1 x i32] [i32 68]
@agentlang_fields_70 = private constant [1 x i32] [i32 69]
@agentlang_fields_71 = private constant [1 x i32] [i32 60]
@agentlang_fields_72 = private constant [1 x i32] [i32 70]
@agentlang_fields_73 = private constant [1 x i32] [i32 72]
@agentlang_fields_74 = private constant [1 x i32] [i32 73]
@agentlang_fields_75 = private constant [1 x i32] [i32 74]
@agentlang_fields_76 = private constant [1 x i32] [i32 75]
@agentlang_fields_77 = private constant [1 x i32] [i32 76]
@agentlang_fields_78 = private constant [1 x i32] [i32 77]
@agentlang_fields_79 = private constant [1 x i32] [i32 78]
@agentlang_fields_80 = private constant [1 x i32] [i32 79]
@agentlang_fields_81 = private constant [1 x i32] [i32 80]
@agentlang_fields_82 = private constant [1 x i32] [i32 71]
@agentlang_fields_83 = private constant [1 x i32] [i32 81]
@agentlang_fields_84 = private constant [1 x i32] [i32 83]
@agentlang_fields_85 = private constant [1 x i32] [i32 84]
@agentlang_fields_86 = private constant [1 x i32] [i32 85]
@agentlang_fields_87 = private constant [1 x i32] [i32 86]
@agentlang_fields_88 = private constant [1 x i32] [i32 87]
@agentlang_fields_89 = private constant [1 x i32] [i32 88]
@agentlang_fields_90 = private constant [1 x i32] [i32 89]
@agentlang_fields_91 = private constant [1 x i32] [i32 90]
@agentlang_fields_92 = private constant [1 x i32] [i32 91]
@agentlang_fields_93 = private constant [1 x i32] [i32 82]
@agentlang_fields_94 = private constant [1 x i32] [i32 92]
@agentlang_fields_95 = private constant [1 x i32] [i32 94]
@agentlang_fields_96 = private constant [1 x i32] [i32 95]
@agentlang_fields_97 = private constant [1 x i32] [i32 96]
@agentlang_fields_98 = private constant [1 x i32] [i32 97]
@agentlang_fields_99 = private constant [1 x i32] [i32 98]
@agentlang_fields_100 = private constant [1 x i32] [i32 99]
@agentlang_fields_101 = private constant [1 x i32] [i32 100]
@agentlang_fields_102 = private constant [1 x i32] [i32 101]
@agentlang_fields_103 = private constant [1 x i32] [i32 102]
@agentlang_fields_104 = private constant [1 x i32] [i32 93]
@agentlang_fields_105 = private constant [1 x i32] [i32 103]
@agentlang_fields_106 = private constant [1 x i32] [i32 105]
@agentlang_fields_107 = private constant [1 x i32] [i32 106]
@agentlang_fields_108 = private constant [1 x i32] [i32 107]
@agentlang_fields_109 = private constant [1 x i32] [i32 108]
@agentlang_fields_110 = private constant [1 x i32] [i32 109]
@agentlang_fields_111 = private constant [1 x i32] [i32 110]
@agentlang_fields_112 = private constant [1 x i32] [i32 111]
@agentlang_fields_113 = private constant [1 x i32] [i32 112]
@agentlang_fields_114 = private constant [1 x i32] [i32 113]
@agentlang_fields_115 = private constant [1 x i32] [i32 4]
@agentlang_fields_116 = private constant [1 x i32] [i32 104]
@agentlang_fields_117 = private constant [1 x i32] [i32 114]
@agentlang_fields_118 = private constant [1 x i32] [i32 117]
@agentlang_fields_119 = private constant [1 x i32] [i32 118]
@agentlang_fields_120 = private constant [1 x i32] [i32 119]
@agentlang_fields_121 = private constant [1 x i32] [i32 120]
@agentlang_fields_122 = private constant [1 x i32] [i32 121]
@agentlang_fields_123 = private constant [1 x i32] [i32 122]
@agentlang_fields_124 = private constant [1 x i32] [i32 123]
@agentlang_fields_125 = private constant [1 x i32] [i32 124]
@agentlang_fields_126 = private constant [1 x i32] [i32 125]
@agentlang_fields_127 = private constant [1 x i32] [i32 116]
@agentlang_fields_128 = private constant [1 x i32] [i32 126]
@agentlang_fields_129 = private constant [1 x i32] [i32 128]
@agentlang_fields_130 = private constant [1 x i32] [i32 129]
@agentlang_fields_131 = private constant [1 x i32] [i32 130]
@agentlang_fields_132 = private constant [1 x i32] [i32 131]
@agentlang_fields_133 = private constant [1 x i32] [i32 132]
@agentlang_fields_134 = private constant [1 x i32] [i32 133]
@agentlang_fields_135 = private constant [1 x i32] [i32 134]
@agentlang_fields_136 = private constant [1 x i32] [i32 135]
@agentlang_fields_137 = private constant [1 x i32] [i32 136]
@agentlang_fields_138 = private constant [1 x i32] [i32 127]
@agentlang_fields_139 = private constant [1 x i32] [i32 137]
@agentlang_fields_140 = private constant [1 x i32] [i32 139]
@agentlang_fields_141 = private constant [1 x i32] [i32 140]
@agentlang_fields_142 = private constant [1 x i32] [i32 141]
@agentlang_fields_143 = private constant [1 x i32] [i32 142]
@agentlang_fields_144 = private constant [1 x i32] [i32 143]
@agentlang_fields_145 = private constant [1 x i32] [i32 144]
@agentlang_fields_146 = private constant [1 x i32] [i32 145]
@agentlang_fields_147 = private constant [1 x i32] [i32 146]
@agentlang_fields_148 = private constant [1 x i32] [i32 147]
@agentlang_fields_149 = private constant [1 x i32] [i32 138]
@agentlang_fields_150 = private constant [1 x i32] [i32 148]
@agentlang_fields_151 = private constant [1 x i32] [i32 150]
@agentlang_fields_152 = private constant [1 x i32] [i32 151]
@agentlang_fields_153 = private constant [1 x i32] [i32 152]
@agentlang_fields_154 = private constant [1 x i32] [i32 153]
@agentlang_fields_155 = private constant [1 x i32] [i32 154]
@agentlang_fields_156 = private constant [1 x i32] [i32 155]
@agentlang_fields_157 = private constant [1 x i32] [i32 156]
@agentlang_fields_158 = private constant [1 x i32] [i32 157]
@agentlang_fields_159 = private constant [1 x i32] [i32 158]
@agentlang_fields_160 = private constant [1 x i32] [i32 149]
@agentlang_fields_161 = private constant [1 x i32] [i32 159]
@agentlang_fields_162 = private constant [1 x i32] [i32 161]
@agentlang_fields_163 = private constant [1 x i32] [i32 162]
@agentlang_fields_164 = private constant [1 x i32] [i32 163]
@agentlang_fields_165 = private constant [1 x i32] [i32 164]
@agentlang_fields_166 = private constant [1 x i32] [i32 165]
@agentlang_fields_167 = private constant [1 x i32] [i32 166]
@agentlang_fields_168 = private constant [1 x i32] [i32 167]
@agentlang_fields_169 = private constant [1 x i32] [i32 168]
@agentlang_fields_170 = private constant [1 x i32] [i32 169]
@agentlang_fields_171 = private constant [1 x i32] [i32 160]
@agentlang_fields_172 = private constant [1 x i32] [i32 170]
@agentlang_fields_173 = private constant [1 x i32] [i32 172]
@agentlang_fields_174 = private constant [1 x i32] [i32 173]
@agentlang_fields_175 = private constant [1 x i32] [i32 174]
@agentlang_fields_176 = private constant [1 x i32] [i32 175]
@agentlang_fields_177 = private constant [1 x i32] [i32 176]
@agentlang_fields_178 = private constant [1 x i32] [i32 171]
@agentlang_fields_179 = private constant [1 x i32] [i32 178]
@agentlang_fields_180 = private constant [1 x i32] [i32 179]
@agentlang_fields_181 = private constant [1 x i32] [i32 180]
@agentlang_fields_182 = private constant [1 x i32] [i32 115]
@agentlang_fields_183 = private constant [1 x i32] [i32 181]
@agentlang_fields_184 = private constant [1 x i32] [i32 183]
@agentlang_fields_185 = private constant [1 x i32] [i32 184]
@agentlang_fields_186 = private constant [1 x i32] [i32 185]
@agentlang_fields_187 = private constant [1 x i32] [i32 186]
@agentlang_fields_188 = private constant [1 x i32] [i32 187]
@agentlang_fields_189 = private constant [1 x i32] [i32 188]
@agentlang_fields_190 = private constant [1 x i32] [i32 189]
@agentlang_fields_191 = private constant [1 x i32] [i32 190]
@agentlang_fields_192 = private constant [1 x i32] [i32 191]
@agentlang_fields_193 = private constant [1 x i32] [i32 182]
@agentlang_fields_194 = private constant [1 x i32] [i32 192]
@agentlang_fields_195 = private constant [1 x i32] [i32 194]
@agentlang_fields_196 = private constant [1 x i32] [i32 195]
@agentlang_fields_197 = private constant [1 x i32] [i32 196]
@agentlang_fields_198 = private constant [1 x i32] [i32 197]
@agentlang_fields_199 = private constant [1 x i32] [i32 198]
@agentlang_fields_200 = private constant [1 x i32] [i32 199]
@agentlang_fields_201 = private constant [1 x i32] [i32 200]
@agentlang_fields_202 = private constant [1 x i32] [i32 201]
@agentlang_fields_203 = private constant [1 x i32] [i32 202]
@agentlang_fields_204 = private constant [1 x i32] [i32 193]
@agentlang_fields_205 = private constant [1 x i32] [i32 203]
@agentlang_fields_206 = private constant [1 x i32] [i32 205]
@agentlang_fields_207 = private constant [1 x i32] [i32 206]
@agentlang_fields_208 = private constant [1 x i32] [i32 207]
@agentlang_fields_209 = private constant [1 x i32] [i32 208]
@agentlang_fields_210 = private constant [1 x i32] [i32 209]
@agentlang_fields_211 = private constant [1 x i32] [i32 210]
@agentlang_fields_212 = private constant [1 x i32] [i32 211]
@agentlang_fields_213 = private constant [1 x i32] [i32 212]
@agentlang_fields_214 = private constant [1 x i32] [i32 213]
@agentlang_fields_215 = private constant [1 x i32] [i32 204]
@agentlang_fields_216 = private constant [1 x i32] [i32 214]
@agentlang_fields_217 = private constant [1 x i32] [i32 216]
@agentlang_fields_218 = private constant [1 x i32] [i32 217]
@agentlang_fields_219 = private constant [1 x i32] [i32 218]
@agentlang_fields_220 = private constant [1 x i32] [i32 219]
@agentlang_fields_221 = private constant [1 x i32] [i32 220]
@agentlang_fields_222 = private constant [1 x i32] [i32 221]
@agentlang_fields_223 = private constant [1 x i32] [i32 222]
@agentlang_fields_224 = private constant [1 x i32] [i32 223]
@agentlang_fields_225 = private constant [1 x i32] [i32 224]
@agentlang_fields_226 = private constant [1 x i32] [i32 215]
@agentlang_fields_227 = private constant [1 x i32] [i32 225]
@agentlang_fields_228 = private constant [1 x i32] [i32 227]
@agentlang_fields_229 = private constant [1 x i32] [i32 228]
@agentlang_fields_230 = private constant [1 x i32] [i32 229]
@agentlang_fields_231 = private constant [1 x i32] [i32 230]
@agentlang_fields_232 = private constant [1 x i32] [i32 231]
@agentlang_fields_233 = private constant [1 x i32] [i32 232]
@agentlang_fields_234 = private constant [1 x i32] [i32 233]
@agentlang_fields_235 = private constant [1 x i32] [i32 234]
@agentlang_fields_236 = private constant [1 x i32] [i32 235]
@agentlang_fields_237 = private constant [1 x i32] [i32 226]
@agentlang_fields_238 = private constant [1 x i32] [i32 236]
@agentlang_fields_239 = private constant [1 x i32] [i32 238]
@agentlang_fields_240 = private constant [1 x i32] [i32 239]
@agentlang_fields_241 = private constant [1 x i32] [i32 240]
@agentlang_fields_242 = private constant [1 x i32] [i32 241]
@agentlang_fields_243 = private constant [1 x i32] [i32 242]
@agentlang_fields_244 = private constant [1 x i32] [i32 243]
@agentlang_fields_245 = private constant [1 x i32] [i32 244]
@agentlang_fields_246 = private constant [1 x i32] [i32 245]
@agentlang_fields_247 = private constant [1 x i32] [i32 246]
@agentlang_fields_248 = private constant [1 x i32] [i32 237]
@agentlang_fields_249 = private constant [1 x i32] [i32 247]
@agentlang_fields_250 = private constant [1 x i32] [i32 249]
@agentlang_fields_251 = private constant [1 x i32] [i32 250]
@agentlang_fields_252 = private constant [1 x i32] [i32 251]
@agentlang_fields_253 = private constant [1 x i32] [i32 252]
@agentlang_fields_254 = private constant [1 x i32] [i32 253]
@agentlang_fields_255 = private constant [1 x i32] [i32 254]
@agentlang_fields_256 = private constant [1 x i32] [i32 255]
@agentlang_fields_257 = private constant [1 x i32] [i32 256]
@agentlang_fields_258 = private constant [1 x i32] [i32 257]
@agentlang_type_descriptors = private constant [259 x %NativeTypeDescriptor] [%NativeTypeDescriptor { i32 1, i32 0, ptr null }, %NativeTypeDescriptor { i32 2, i32 0, ptr null }, %NativeTypeDescriptor { i32 3, i32 0, ptr null }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_3, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_4, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_5, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_6, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_7, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_8, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_9, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_10, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_11, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_12, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_13, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_14, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_15, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_16, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_17, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_18, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_19, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_20, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_21, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_22, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_23, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_24, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_25, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_26, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_27, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_28, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_29, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_30, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_31, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_32, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_33, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_34, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_35, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_36, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_37, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_38, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_39, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_40, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_41, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_42, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_43, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_44, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_45, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_46, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_47, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_48, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_49, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_50, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_51, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_52, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_53, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_54, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_55, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_56, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_57, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_58, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_59, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_60, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_61, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_62, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_63, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_64, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_65, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_66, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_67, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_68, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_69, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_70, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_71, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_72, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_73, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_74, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_75, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_76, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_77, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_78, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_79, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_80, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_81, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_82, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_83, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_84, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_85, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_86, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_87, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_88, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_89, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_90, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_91, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_92, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_93, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_94, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_95, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_96, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_97, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_98, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_99, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_100, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_101, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_102, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_103, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_104, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_105, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_106, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_107, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_108, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_109, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_110, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_111, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_112, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_113, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_114, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_115, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_116, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_117, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_118, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_119, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_120, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_121, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_122, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_123, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_124, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_125, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_126, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_127, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_128, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_129, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_130, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_131, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_132, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_133, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_134, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_135, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_136, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_137, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_138, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_139, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_140, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_141, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_142, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_143, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_144, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_145, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_146, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_147, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_148, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_149, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_150, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_151, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_152, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_153, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_154, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_155, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_156, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_157, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_158, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_159, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_160, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_161, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_162, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_163, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_164, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_165, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_166, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_167, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_168, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_169, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_170, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_171, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_172, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_173, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_174, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_175, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_176, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_177, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_178, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_179, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_180, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_181, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_182, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_183, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_184, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_185, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_186, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_187, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_188, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_189, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_190, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_191, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_192, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_193, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_194, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_195, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_196, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_197, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_198, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_199, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_200, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_201, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_202, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_203, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_204, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_205, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_206, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_207, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_208, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_209, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_210, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_211, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_212, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_213, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_214, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_215, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_216, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_217, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_218, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_219, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_220, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_221, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_222, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_223, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_224, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_225, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_226, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_227, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_228, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_229, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_230, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_231, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_232, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_233, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_234, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_235, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_236, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_237, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_238, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_239, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_240, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_241, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_242, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_243, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_244, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_245, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_246, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_247, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_248, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_249, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_250, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_251, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_252, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_253, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_254, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_255, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_256, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_257, i32 0, i32 0) }, %NativeTypeDescriptor { i32 4, i32 1, ptr getelementptr inbounds ([1 x i32], ptr @agentlang_fields_258, i32 0, i32 0) }]
@agentlang_program = private constant %NativeProgramDescriptor { ptr getelementptr inbounds ([259 x %NativeTypeDescriptor], ptr @agentlang_type_descriptors, i32 0, i32 0), i32 259, i32 0 }
@agentlang_root_type_ids = private constant [1 x i32] [i32 0]

define internal void @agentlang_body(ptr %ctx, ptr %outputs, ptr %status, i32 %depth) {
entry:
  %ctx.field.0 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1 = load i32, ptr %ctx.field.0, align 4
  %steps.next.2 = add i32 %steps.current.1, 1
  store i32 %steps.next.2, ptr %ctx.field.0, align 4
  %steps.over.3 = icmp ugt i32 %steps.next.2, 10000
  br i1 %steps.over.3, label %failure.4, label %continue.5
failure.4:
  %ctx.field.6 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 0, ptr %ctx.field.6, align 4
  %status.diagnostic.7 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7, align 4
  ret void
continue.5:
  %ctx.field.8 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9 = load i32, ptr %ctx.field.8, align 4
  %steps.next.10 = add i32 %steps.current.9, 1
  store i32 %steps.next.10, ptr %ctx.field.8, align 4
  %steps.over.11 = icmp ugt i32 %steps.next.10, 10000
  br i1 %steps.over.11, label %failure.12, label %continue.13
failure.12:
  %ctx.field.14 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1, ptr %ctx.field.14, align 4
  %status.diagnostic.15 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.15, align 4
  ret void
continue.13:
  %if.condition.16 = icmp ne i64 0, 0
  br i1 %if.condition.16, label %if.then.17, label %if.else.18
if.then.17:
  %ctx.field.20 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.21 = load i32, ptr %ctx.field.20, align 4
  %steps.next.22 = add i32 %steps.current.21, 1
  store i32 %steps.next.22, ptr %ctx.field.20, align 4
  %steps.over.23 = icmp ugt i32 %steps.next.22, 10000
  br i1 %steps.over.23, label %failure.24, label %continue.25
failure.24:
  %ctx.field.26 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 2, ptr %ctx.field.26, align 4
  %status.diagnostic.27 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.27, align 4
  ret void
continue.25:
  %ctx.field.28 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.29 = load i32, ptr %ctx.field.28, align 4
  %steps.next.30 = add i32 %steps.current.29, 1
  store i32 %steps.next.30, ptr %ctx.field.28, align 4
  %steps.over.31 = icmp ugt i32 %steps.next.30, 10000
  br i1 %steps.over.31, label %failure.32, label %continue.33
failure.32:
  %ctx.field.34 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 3, ptr %ctx.field.34, align 4
  %status.diagnostic.35 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.35, align 4
  ret void
continue.33:
  %depth.exceeded.36 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.36, label %failure.37, label %continue.38
failure.37:
  %ctx.field.39 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 4, ptr %ctx.field.39, align 4
  %status.diagnostic.40 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.40, align 4
  ret void
continue.38:
  %workspace.slot.41 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 1, ptr %workspace.slot.41, align 8
  %workspace.slot.42 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.43 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 3, ptr %outputs, i32 1, ptr %workspace.slot.42)
  switch i32 %record.make.status.43, label %runtime.invalid.result.49 [ i32 0, label %runtime.success.44 i32 1, label %runtime.invalid.request.45 i32 2, label %runtime.invalid.reference.46 i32 3, label %runtime.scratch.capacity.47 i32 4, label %runtime.retained.capacity.48 ]
runtime.invalid.request.45:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.46:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.47:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.48:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.49:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.44:
  %record.make.handle.50 = load i64, ptr %workspace.slot.42, align 8
  %ctx.field.51 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.52 = load i32, ptr %ctx.field.51, align 4
  %steps.next.53 = add i32 %steps.current.52, 1
  store i32 %steps.next.53, ptr %ctx.field.51, align 4
  %steps.over.54 = icmp ugt i32 %steps.next.53, 10000
  br i1 %steps.over.54, label %failure.55, label %continue.56
failure.55:
  %ctx.field.57 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 5, ptr %ctx.field.57, align 4
  %status.diagnostic.58 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.58, align 4
  ret void
continue.56:
  %depth.exceeded.59 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.59, label %failure.60, label %continue.61
failure.60:
  %ctx.field.62 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 6, ptr %ctx.field.62, align 4
  %status.diagnostic.63 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.63, align 4
  ret void
continue.61:
  %workspace.slot.64 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.50, ptr %workspace.slot.64, align 8
  %workspace.slot.65 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.66 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 4, ptr %outputs, i32 1, ptr %workspace.slot.65)
  switch i32 %record.make.status.66, label %runtime.invalid.result.72 [ i32 0, label %runtime.success.67 i32 1, label %runtime.invalid.request.68 i32 2, label %runtime.invalid.reference.69 i32 3, label %runtime.scratch.capacity.70 i32 4, label %runtime.retained.capacity.71 ]
runtime.invalid.request.68:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.69:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.70:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.71:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.72:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.67:
  %record.make.handle.73 = load i64, ptr %workspace.slot.65, align 8
  %ctx.field.74 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.75 = load i32, ptr %ctx.field.74, align 4
  %steps.next.76 = add i32 %steps.current.75, 1
  store i32 %steps.next.76, ptr %ctx.field.74, align 4
  %steps.over.77 = icmp ugt i32 %steps.next.76, 10000
  br i1 %steps.over.77, label %failure.78, label %continue.79
failure.78:
  %ctx.field.80 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 7, ptr %ctx.field.80, align 4
  %status.diagnostic.81 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.81, align 4
  ret void
continue.79:
  %depth.exceeded.82 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.82, label %failure.83, label %continue.84
failure.83:
  %ctx.field.85 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 8, ptr %ctx.field.85, align 4
  %status.diagnostic.86 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.86, align 4
  ret void
continue.84:
  %workspace.slot.87 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.73, ptr %workspace.slot.87, align 8
  %workspace.slot.88 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.89 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 115, ptr %outputs, i32 1, ptr %workspace.slot.88)
  switch i32 %record.make.status.89, label %runtime.invalid.result.95 [ i32 0, label %runtime.success.90 i32 1, label %runtime.invalid.request.91 i32 2, label %runtime.invalid.reference.92 i32 3, label %runtime.scratch.capacity.93 i32 4, label %runtime.retained.capacity.94 ]
runtime.invalid.request.91:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.92:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.93:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.94:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.95:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.90:
  %record.make.handle.96 = load i64, ptr %workspace.slot.88, align 8
  %ctx.field.97 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.98 = load i32, ptr %ctx.field.97, align 4
  %steps.next.99 = add i32 %steps.current.98, 1
  store i32 %steps.next.99, ptr %ctx.field.97, align 4
  %steps.over.100 = icmp ugt i32 %steps.next.99, 10000
  br i1 %steps.over.100, label %failure.101, label %continue.102
failure.101:
  %ctx.field.103 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 9, ptr %ctx.field.103, align 4
  %status.diagnostic.104 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.104, align 4
  ret void
continue.102:
  %depth.exceeded.105 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.105, label %failure.106, label %continue.107
failure.106:
  %ctx.field.108 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 10, ptr %ctx.field.108, align 4
  %status.diagnostic.109 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.109, align 4
  ret void
continue.107:
  %workspace.slot.110 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.96, ptr %workspace.slot.110, align 8
  %workspace.slot.111 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.112 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 182, ptr %outputs, i32 1, ptr %workspace.slot.111)
  switch i32 %record.make.status.112, label %runtime.invalid.result.118 [ i32 0, label %runtime.success.113 i32 1, label %runtime.invalid.request.114 i32 2, label %runtime.invalid.reference.115 i32 3, label %runtime.scratch.capacity.116 i32 4, label %runtime.retained.capacity.117 ]
runtime.invalid.request.114:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.115:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.116:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.117:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.118:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.113:
  %record.make.handle.119 = load i64, ptr %workspace.slot.111, align 8
  %ctx.field.120 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.121 = load i32, ptr %ctx.field.120, align 4
  %steps.next.122 = add i32 %steps.current.121, 1
  store i32 %steps.next.122, ptr %ctx.field.120, align 4
  %steps.over.123 = icmp ugt i32 %steps.next.122, 10000
  br i1 %steps.over.123, label %failure.124, label %continue.125
failure.124:
  %ctx.field.126 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 11, ptr %ctx.field.126, align 4
  %status.diagnostic.127 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.127, align 4
  ret void
continue.125:
  %depth.exceeded.128 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.128, label %failure.129, label %continue.130
failure.129:
  %ctx.field.131 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 12, ptr %ctx.field.131, align 4
  %status.diagnostic.132 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.132, align 4
  ret void
continue.130:
  %workspace.slot.133 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.119, ptr %workspace.slot.133, align 8
  %workspace.slot.134 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.135 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 193, ptr %outputs, i32 1, ptr %workspace.slot.134)
  switch i32 %record.make.status.135, label %runtime.invalid.result.141 [ i32 0, label %runtime.success.136 i32 1, label %runtime.invalid.request.137 i32 2, label %runtime.invalid.reference.138 i32 3, label %runtime.scratch.capacity.139 i32 4, label %runtime.retained.capacity.140 ]
runtime.invalid.request.137:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.138:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.139:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.140:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.141:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.136:
  %record.make.handle.142 = load i64, ptr %workspace.slot.134, align 8
  %ctx.field.143 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.144 = load i32, ptr %ctx.field.143, align 4
  %steps.next.145 = add i32 %steps.current.144, 1
  store i32 %steps.next.145, ptr %ctx.field.143, align 4
  %steps.over.146 = icmp ugt i32 %steps.next.145, 10000
  br i1 %steps.over.146, label %failure.147, label %continue.148
failure.147:
  %ctx.field.149 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 13, ptr %ctx.field.149, align 4
  %status.diagnostic.150 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.150, align 4
  ret void
continue.148:
  %depth.exceeded.151 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.151, label %failure.152, label %continue.153
failure.152:
  %ctx.field.154 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 14, ptr %ctx.field.154, align 4
  %status.diagnostic.155 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.155, align 4
  ret void
continue.153:
  %workspace.slot.156 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.142, ptr %workspace.slot.156, align 8
  %workspace.slot.157 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.158 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 204, ptr %outputs, i32 1, ptr %workspace.slot.157)
  switch i32 %record.make.status.158, label %runtime.invalid.result.164 [ i32 0, label %runtime.success.159 i32 1, label %runtime.invalid.request.160 i32 2, label %runtime.invalid.reference.161 i32 3, label %runtime.scratch.capacity.162 i32 4, label %runtime.retained.capacity.163 ]
runtime.invalid.request.160:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.161:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.162:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.163:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.164:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.159:
  %record.make.handle.165 = load i64, ptr %workspace.slot.157, align 8
  %ctx.field.166 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.167 = load i32, ptr %ctx.field.166, align 4
  %steps.next.168 = add i32 %steps.current.167, 1
  store i32 %steps.next.168, ptr %ctx.field.166, align 4
  %steps.over.169 = icmp ugt i32 %steps.next.168, 10000
  br i1 %steps.over.169, label %failure.170, label %continue.171
failure.170:
  %ctx.field.172 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 15, ptr %ctx.field.172, align 4
  %status.diagnostic.173 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.173, align 4
  ret void
continue.171:
  %depth.exceeded.174 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.174, label %failure.175, label %continue.176
failure.175:
  %ctx.field.177 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 16, ptr %ctx.field.177, align 4
  %status.diagnostic.178 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.178, align 4
  ret void
continue.176:
  %workspace.slot.179 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.165, ptr %workspace.slot.179, align 8
  %workspace.slot.180 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.181 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 215, ptr %outputs, i32 1, ptr %workspace.slot.180)
  switch i32 %record.make.status.181, label %runtime.invalid.result.187 [ i32 0, label %runtime.success.182 i32 1, label %runtime.invalid.request.183 i32 2, label %runtime.invalid.reference.184 i32 3, label %runtime.scratch.capacity.185 i32 4, label %runtime.retained.capacity.186 ]
runtime.invalid.request.183:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.184:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.185:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.186:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.187:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.182:
  %record.make.handle.188 = load i64, ptr %workspace.slot.180, align 8
  %ctx.field.189 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.190 = load i32, ptr %ctx.field.189, align 4
  %steps.next.191 = add i32 %steps.current.190, 1
  store i32 %steps.next.191, ptr %ctx.field.189, align 4
  %steps.over.192 = icmp ugt i32 %steps.next.191, 10000
  br i1 %steps.over.192, label %failure.193, label %continue.194
failure.193:
  %ctx.field.195 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 17, ptr %ctx.field.195, align 4
  %status.diagnostic.196 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.196, align 4
  ret void
continue.194:
  %depth.exceeded.197 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.197, label %failure.198, label %continue.199
failure.198:
  %ctx.field.200 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 18, ptr %ctx.field.200, align 4
  %status.diagnostic.201 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.201, align 4
  ret void
continue.199:
  %workspace.slot.202 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.188, ptr %workspace.slot.202, align 8
  %workspace.slot.203 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.204 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 226, ptr %outputs, i32 1, ptr %workspace.slot.203)
  switch i32 %record.make.status.204, label %runtime.invalid.result.210 [ i32 0, label %runtime.success.205 i32 1, label %runtime.invalid.request.206 i32 2, label %runtime.invalid.reference.207 i32 3, label %runtime.scratch.capacity.208 i32 4, label %runtime.retained.capacity.209 ]
runtime.invalid.request.206:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.207:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.208:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.209:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.210:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.205:
  %record.make.handle.211 = load i64, ptr %workspace.slot.203, align 8
  %ctx.field.212 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.213 = load i32, ptr %ctx.field.212, align 4
  %steps.next.214 = add i32 %steps.current.213, 1
  store i32 %steps.next.214, ptr %ctx.field.212, align 4
  %steps.over.215 = icmp ugt i32 %steps.next.214, 10000
  br i1 %steps.over.215, label %failure.216, label %continue.217
failure.216:
  %ctx.field.218 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 19, ptr %ctx.field.218, align 4
  %status.diagnostic.219 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.219, align 4
  ret void
continue.217:
  %depth.exceeded.220 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.220, label %failure.221, label %continue.222
failure.221:
  %ctx.field.223 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 20, ptr %ctx.field.223, align 4
  %status.diagnostic.224 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.224, align 4
  ret void
continue.222:
  %workspace.slot.225 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.211, ptr %workspace.slot.225, align 8
  %workspace.slot.226 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.227 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 237, ptr %outputs, i32 1, ptr %workspace.slot.226)
  switch i32 %record.make.status.227, label %runtime.invalid.result.233 [ i32 0, label %runtime.success.228 i32 1, label %runtime.invalid.request.229 i32 2, label %runtime.invalid.reference.230 i32 3, label %runtime.scratch.capacity.231 i32 4, label %runtime.retained.capacity.232 ]
runtime.invalid.request.229:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.230:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.231:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.232:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.233:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.228:
  %record.make.handle.234 = load i64, ptr %workspace.slot.226, align 8
  %ctx.field.235 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.236 = load i32, ptr %ctx.field.235, align 4
  %steps.next.237 = add i32 %steps.current.236, 1
  store i32 %steps.next.237, ptr %ctx.field.235, align 4
  %steps.over.238 = icmp ugt i32 %steps.next.237, 10000
  br i1 %steps.over.238, label %failure.239, label %continue.240
failure.239:
  %ctx.field.241 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 21, ptr %ctx.field.241, align 4
  %status.diagnostic.242 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.242, align 4
  ret void
continue.240:
  %depth.exceeded.243 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.243, label %failure.244, label %continue.245
failure.244:
  %ctx.field.246 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 22, ptr %ctx.field.246, align 4
  %status.diagnostic.247 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.247, align 4
  ret void
continue.245:
  %workspace.slot.248 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.234, ptr %workspace.slot.248, align 8
  %workspace.slot.249 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.250 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 248, ptr %outputs, i32 1, ptr %workspace.slot.249)
  switch i32 %record.make.status.250, label %runtime.invalid.result.256 [ i32 0, label %runtime.success.251 i32 1, label %runtime.invalid.request.252 i32 2, label %runtime.invalid.reference.253 i32 3, label %runtime.scratch.capacity.254 i32 4, label %runtime.retained.capacity.255 ]
runtime.invalid.request.252:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.253:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.254:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.255:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.256:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.251:
  %record.make.handle.257 = load i64, ptr %workspace.slot.249, align 8
  %ctx.field.258 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.259 = load i32, ptr %ctx.field.258, align 4
  %steps.next.260 = add i32 %steps.current.259, 1
  store i32 %steps.next.260, ptr %ctx.field.258, align 4
  %steps.over.261 = icmp ugt i32 %steps.next.260, 10000
  br i1 %steps.over.261, label %failure.262, label %continue.263
failure.262:
  %ctx.field.264 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 23, ptr %ctx.field.264, align 4
  %status.diagnostic.265 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.265, align 4
  ret void
continue.263:
  %depth.exceeded.266 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.266, label %failure.267, label %continue.268
failure.267:
  %ctx.field.269 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 24, ptr %ctx.field.269, align 4
  %status.diagnostic.270 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.270, align 4
  ret void
continue.268:
  %workspace.slot.271 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.257, ptr %workspace.slot.271, align 8
  %workspace.slot.272 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.273 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 5, ptr %outputs, i32 1, ptr %workspace.slot.272)
  switch i32 %record.make.status.273, label %runtime.invalid.result.279 [ i32 0, label %runtime.success.274 i32 1, label %runtime.invalid.request.275 i32 2, label %runtime.invalid.reference.276 i32 3, label %runtime.scratch.capacity.277 i32 4, label %runtime.retained.capacity.278 ]
runtime.invalid.request.275:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.276:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.277:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.278:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.279:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.274:
  %record.make.handle.280 = load i64, ptr %workspace.slot.272, align 8
  %ctx.field.281 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.282 = load i32, ptr %ctx.field.281, align 4
  %steps.next.283 = add i32 %steps.current.282, 1
  store i32 %steps.next.283, ptr %ctx.field.281, align 4
  %steps.over.284 = icmp ugt i32 %steps.next.283, 10000
  br i1 %steps.over.284, label %failure.285, label %continue.286
failure.285:
  %ctx.field.287 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 25, ptr %ctx.field.287, align 4
  %status.diagnostic.288 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.288, align 4
  ret void
continue.286:
  %depth.exceeded.289 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.289, label %failure.290, label %continue.291
failure.290:
  %ctx.field.292 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 26, ptr %ctx.field.292, align 4
  %status.diagnostic.293 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.293, align 4
  ret void
continue.291:
  %workspace.slot.294 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.280, ptr %workspace.slot.294, align 8
  %workspace.slot.295 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.296 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 16, ptr %outputs, i32 1, ptr %workspace.slot.295)
  switch i32 %record.make.status.296, label %runtime.invalid.result.302 [ i32 0, label %runtime.success.297 i32 1, label %runtime.invalid.request.298 i32 2, label %runtime.invalid.reference.299 i32 3, label %runtime.scratch.capacity.300 i32 4, label %runtime.retained.capacity.301 ]
runtime.invalid.request.298:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.299:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.300:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.301:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.302:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.297:
  %record.make.handle.303 = load i64, ptr %workspace.slot.295, align 8
  %ctx.field.304 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.305 = load i32, ptr %ctx.field.304, align 4
  %steps.next.306 = add i32 %steps.current.305, 1
  store i32 %steps.next.306, ptr %ctx.field.304, align 4
  %steps.over.307 = icmp ugt i32 %steps.next.306, 10000
  br i1 %steps.over.307, label %failure.308, label %continue.309
failure.308:
  %ctx.field.310 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 27, ptr %ctx.field.310, align 4
  %status.diagnostic.311 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.311, align 4
  ret void
continue.309:
  %depth.exceeded.312 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.312, label %failure.313, label %continue.314
failure.313:
  %ctx.field.315 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 28, ptr %ctx.field.315, align 4
  %status.diagnostic.316 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.316, align 4
  ret void
continue.314:
  %workspace.slot.317 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.303, ptr %workspace.slot.317, align 8
  %workspace.slot.318 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.319 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 27, ptr %outputs, i32 1, ptr %workspace.slot.318)
  switch i32 %record.make.status.319, label %runtime.invalid.result.325 [ i32 0, label %runtime.success.320 i32 1, label %runtime.invalid.request.321 i32 2, label %runtime.invalid.reference.322 i32 3, label %runtime.scratch.capacity.323 i32 4, label %runtime.retained.capacity.324 ]
runtime.invalid.request.321:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.322:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.323:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.324:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.325:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.320:
  %record.make.handle.326 = load i64, ptr %workspace.slot.318, align 8
  %ctx.field.327 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.328 = load i32, ptr %ctx.field.327, align 4
  %steps.next.329 = add i32 %steps.current.328, 1
  store i32 %steps.next.329, ptr %ctx.field.327, align 4
  %steps.over.330 = icmp ugt i32 %steps.next.329, 10000
  br i1 %steps.over.330, label %failure.331, label %continue.332
failure.331:
  %ctx.field.333 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 29, ptr %ctx.field.333, align 4
  %status.diagnostic.334 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.334, align 4
  ret void
continue.332:
  %depth.exceeded.335 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.335, label %failure.336, label %continue.337
failure.336:
  %ctx.field.338 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 30, ptr %ctx.field.338, align 4
  %status.diagnostic.339 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.339, align 4
  ret void
continue.337:
  %workspace.slot.340 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.326, ptr %workspace.slot.340, align 8
  %workspace.slot.341 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.342 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 38, ptr %outputs, i32 1, ptr %workspace.slot.341)
  switch i32 %record.make.status.342, label %runtime.invalid.result.348 [ i32 0, label %runtime.success.343 i32 1, label %runtime.invalid.request.344 i32 2, label %runtime.invalid.reference.345 i32 3, label %runtime.scratch.capacity.346 i32 4, label %runtime.retained.capacity.347 ]
runtime.invalid.request.344:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.345:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.346:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.347:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.348:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.343:
  %record.make.handle.349 = load i64, ptr %workspace.slot.341, align 8
  %ctx.field.350 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.351 = load i32, ptr %ctx.field.350, align 4
  %steps.next.352 = add i32 %steps.current.351, 1
  store i32 %steps.next.352, ptr %ctx.field.350, align 4
  %steps.over.353 = icmp ugt i32 %steps.next.352, 10000
  br i1 %steps.over.353, label %failure.354, label %continue.355
failure.354:
  %ctx.field.356 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 31, ptr %ctx.field.356, align 4
  %status.diagnostic.357 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.357, align 4
  ret void
continue.355:
  %depth.exceeded.358 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.358, label %failure.359, label %continue.360
failure.359:
  %ctx.field.361 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 32, ptr %ctx.field.361, align 4
  %status.diagnostic.362 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.362, align 4
  ret void
continue.360:
  %workspace.slot.363 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.349, ptr %workspace.slot.363, align 8
  %workspace.slot.364 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.365 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 49, ptr %outputs, i32 1, ptr %workspace.slot.364)
  switch i32 %record.make.status.365, label %runtime.invalid.result.371 [ i32 0, label %runtime.success.366 i32 1, label %runtime.invalid.request.367 i32 2, label %runtime.invalid.reference.368 i32 3, label %runtime.scratch.capacity.369 i32 4, label %runtime.retained.capacity.370 ]
runtime.invalid.request.367:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.368:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.369:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.370:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.371:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.366:
  %record.make.handle.372 = load i64, ptr %workspace.slot.364, align 8
  %ctx.field.373 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.374 = load i32, ptr %ctx.field.373, align 4
  %steps.next.375 = add i32 %steps.current.374, 1
  store i32 %steps.next.375, ptr %ctx.field.373, align 4
  %steps.over.376 = icmp ugt i32 %steps.next.375, 10000
  br i1 %steps.over.376, label %failure.377, label %continue.378
failure.377:
  %ctx.field.379 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 33, ptr %ctx.field.379, align 4
  %status.diagnostic.380 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.380, align 4
  ret void
continue.378:
  %depth.exceeded.381 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.381, label %failure.382, label %continue.383
failure.382:
  %ctx.field.384 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 34, ptr %ctx.field.384, align 4
  %status.diagnostic.385 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.385, align 4
  ret void
continue.383:
  %workspace.slot.386 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.372, ptr %workspace.slot.386, align 8
  %workspace.slot.387 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.388 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 60, ptr %outputs, i32 1, ptr %workspace.slot.387)
  switch i32 %record.make.status.388, label %runtime.invalid.result.394 [ i32 0, label %runtime.success.389 i32 1, label %runtime.invalid.request.390 i32 2, label %runtime.invalid.reference.391 i32 3, label %runtime.scratch.capacity.392 i32 4, label %runtime.retained.capacity.393 ]
runtime.invalid.request.390:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.391:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.392:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.393:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.394:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.389:
  %record.make.handle.395 = load i64, ptr %workspace.slot.387, align 8
  %ctx.field.396 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.397 = load i32, ptr %ctx.field.396, align 4
  %steps.next.398 = add i32 %steps.current.397, 1
  store i32 %steps.next.398, ptr %ctx.field.396, align 4
  %steps.over.399 = icmp ugt i32 %steps.next.398, 10000
  br i1 %steps.over.399, label %failure.400, label %continue.401
failure.400:
  %ctx.field.402 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 35, ptr %ctx.field.402, align 4
  %status.diagnostic.403 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.403, align 4
  ret void
continue.401:
  %depth.exceeded.404 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.404, label %failure.405, label %continue.406
failure.405:
  %ctx.field.407 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 36, ptr %ctx.field.407, align 4
  %status.diagnostic.408 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.408, align 4
  ret void
continue.406:
  %workspace.slot.409 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.395, ptr %workspace.slot.409, align 8
  %workspace.slot.410 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.411 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 71, ptr %outputs, i32 1, ptr %workspace.slot.410)
  switch i32 %record.make.status.411, label %runtime.invalid.result.417 [ i32 0, label %runtime.success.412 i32 1, label %runtime.invalid.request.413 i32 2, label %runtime.invalid.reference.414 i32 3, label %runtime.scratch.capacity.415 i32 4, label %runtime.retained.capacity.416 ]
runtime.invalid.request.413:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.414:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.415:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.416:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.417:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.412:
  %record.make.handle.418 = load i64, ptr %workspace.slot.410, align 8
  %ctx.field.419 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.420 = load i32, ptr %ctx.field.419, align 4
  %steps.next.421 = add i32 %steps.current.420, 1
  store i32 %steps.next.421, ptr %ctx.field.419, align 4
  %steps.over.422 = icmp ugt i32 %steps.next.421, 10000
  br i1 %steps.over.422, label %failure.423, label %continue.424
failure.423:
  %ctx.field.425 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 37, ptr %ctx.field.425, align 4
  %status.diagnostic.426 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.426, align 4
  ret void
continue.424:
  %depth.exceeded.427 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.427, label %failure.428, label %continue.429
failure.428:
  %ctx.field.430 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 38, ptr %ctx.field.430, align 4
  %status.diagnostic.431 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.431, align 4
  ret void
continue.429:
  %workspace.slot.432 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.418, ptr %workspace.slot.432, align 8
  %workspace.slot.433 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.434 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 82, ptr %outputs, i32 1, ptr %workspace.slot.433)
  switch i32 %record.make.status.434, label %runtime.invalid.result.440 [ i32 0, label %runtime.success.435 i32 1, label %runtime.invalid.request.436 i32 2, label %runtime.invalid.reference.437 i32 3, label %runtime.scratch.capacity.438 i32 4, label %runtime.retained.capacity.439 ]
runtime.invalid.request.436:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.437:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.438:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.439:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.440:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.435:
  %record.make.handle.441 = load i64, ptr %workspace.slot.433, align 8
  %ctx.field.442 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.443 = load i32, ptr %ctx.field.442, align 4
  %steps.next.444 = add i32 %steps.current.443, 1
  store i32 %steps.next.444, ptr %ctx.field.442, align 4
  %steps.over.445 = icmp ugt i32 %steps.next.444, 10000
  br i1 %steps.over.445, label %failure.446, label %continue.447
failure.446:
  %ctx.field.448 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 39, ptr %ctx.field.448, align 4
  %status.diagnostic.449 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.449, align 4
  ret void
continue.447:
  %depth.exceeded.450 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.450, label %failure.451, label %continue.452
failure.451:
  %ctx.field.453 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 40, ptr %ctx.field.453, align 4
  %status.diagnostic.454 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.454, align 4
  ret void
continue.452:
  %workspace.slot.455 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.441, ptr %workspace.slot.455, align 8
  %workspace.slot.456 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.457 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 93, ptr %outputs, i32 1, ptr %workspace.slot.456)
  switch i32 %record.make.status.457, label %runtime.invalid.result.463 [ i32 0, label %runtime.success.458 i32 1, label %runtime.invalid.request.459 i32 2, label %runtime.invalid.reference.460 i32 3, label %runtime.scratch.capacity.461 i32 4, label %runtime.retained.capacity.462 ]
runtime.invalid.request.459:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.460:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.461:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.462:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.463:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.458:
  %record.make.handle.464 = load i64, ptr %workspace.slot.456, align 8
  %ctx.field.465 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.466 = load i32, ptr %ctx.field.465, align 4
  %steps.next.467 = add i32 %steps.current.466, 1
  store i32 %steps.next.467, ptr %ctx.field.465, align 4
  %steps.over.468 = icmp ugt i32 %steps.next.467, 10000
  br i1 %steps.over.468, label %failure.469, label %continue.470
failure.469:
  %ctx.field.471 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 41, ptr %ctx.field.471, align 4
  %status.diagnostic.472 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.472, align 4
  ret void
continue.470:
  %depth.exceeded.473 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.473, label %failure.474, label %continue.475
failure.474:
  %ctx.field.476 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 42, ptr %ctx.field.476, align 4
  %status.diagnostic.477 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.477, align 4
  ret void
continue.475:
  %workspace.slot.478 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.464, ptr %workspace.slot.478, align 8
  %workspace.slot.479 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.480 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 104, ptr %outputs, i32 1, ptr %workspace.slot.479)
  switch i32 %record.make.status.480, label %runtime.invalid.result.486 [ i32 0, label %runtime.success.481 i32 1, label %runtime.invalid.request.482 i32 2, label %runtime.invalid.reference.483 i32 3, label %runtime.scratch.capacity.484 i32 4, label %runtime.retained.capacity.485 ]
runtime.invalid.request.482:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.483:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.484:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.485:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.486:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.481:
  %record.make.handle.487 = load i64, ptr %workspace.slot.479, align 8
  %ctx.field.488 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.489 = load i32, ptr %ctx.field.488, align 4
  %steps.next.490 = add i32 %steps.current.489, 1
  store i32 %steps.next.490, ptr %ctx.field.488, align 4
  %steps.over.491 = icmp ugt i32 %steps.next.490, 10000
  br i1 %steps.over.491, label %failure.492, label %continue.493
failure.492:
  %ctx.field.494 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 43, ptr %ctx.field.494, align 4
  %status.diagnostic.495 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.495, align 4
  ret void
continue.493:
  %depth.exceeded.496 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.496, label %failure.497, label %continue.498
failure.497:
  %ctx.field.499 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 44, ptr %ctx.field.499, align 4
  %status.diagnostic.500 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.500, align 4
  ret void
continue.498:
  %workspace.slot.501 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.487, ptr %workspace.slot.501, align 8
  %workspace.slot.502 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.503 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 116, ptr %outputs, i32 1, ptr %workspace.slot.502)
  switch i32 %record.make.status.503, label %runtime.invalid.result.509 [ i32 0, label %runtime.success.504 i32 1, label %runtime.invalid.request.505 i32 2, label %runtime.invalid.reference.506 i32 3, label %runtime.scratch.capacity.507 i32 4, label %runtime.retained.capacity.508 ]
runtime.invalid.request.505:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.506:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.507:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.508:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.509:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.504:
  %record.make.handle.510 = load i64, ptr %workspace.slot.502, align 8
  %ctx.field.511 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.512 = load i32, ptr %ctx.field.511, align 4
  %steps.next.513 = add i32 %steps.current.512, 1
  store i32 %steps.next.513, ptr %ctx.field.511, align 4
  %steps.over.514 = icmp ugt i32 %steps.next.513, 10000
  br i1 %steps.over.514, label %failure.515, label %continue.516
failure.515:
  %ctx.field.517 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 45, ptr %ctx.field.517, align 4
  %status.diagnostic.518 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.518, align 4
  ret void
continue.516:
  %depth.exceeded.519 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.519, label %failure.520, label %continue.521
failure.520:
  %ctx.field.522 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 46, ptr %ctx.field.522, align 4
  %status.diagnostic.523 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.523, align 4
  ret void
continue.521:
  %workspace.slot.524 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.510, ptr %workspace.slot.524, align 8
  %workspace.slot.525 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.526 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 127, ptr %outputs, i32 1, ptr %workspace.slot.525)
  switch i32 %record.make.status.526, label %runtime.invalid.result.532 [ i32 0, label %runtime.success.527 i32 1, label %runtime.invalid.request.528 i32 2, label %runtime.invalid.reference.529 i32 3, label %runtime.scratch.capacity.530 i32 4, label %runtime.retained.capacity.531 ]
runtime.invalid.request.528:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.529:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.530:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.531:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.532:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.527:
  %record.make.handle.533 = load i64, ptr %workspace.slot.525, align 8
  %ctx.field.534 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.535 = load i32, ptr %ctx.field.534, align 4
  %steps.next.536 = add i32 %steps.current.535, 1
  store i32 %steps.next.536, ptr %ctx.field.534, align 4
  %steps.over.537 = icmp ugt i32 %steps.next.536, 10000
  br i1 %steps.over.537, label %failure.538, label %continue.539
failure.538:
  %ctx.field.540 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 47, ptr %ctx.field.540, align 4
  %status.diagnostic.541 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.541, align 4
  ret void
continue.539:
  %depth.exceeded.542 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.542, label %failure.543, label %continue.544
failure.543:
  %ctx.field.545 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 48, ptr %ctx.field.545, align 4
  %status.diagnostic.546 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.546, align 4
  ret void
continue.544:
  %workspace.slot.547 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.533, ptr %workspace.slot.547, align 8
  %workspace.slot.548 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.549 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 138, ptr %outputs, i32 1, ptr %workspace.slot.548)
  switch i32 %record.make.status.549, label %runtime.invalid.result.555 [ i32 0, label %runtime.success.550 i32 1, label %runtime.invalid.request.551 i32 2, label %runtime.invalid.reference.552 i32 3, label %runtime.scratch.capacity.553 i32 4, label %runtime.retained.capacity.554 ]
runtime.invalid.request.551:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.552:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.553:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.554:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.555:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.550:
  %record.make.handle.556 = load i64, ptr %workspace.slot.548, align 8
  %ctx.field.557 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.558 = load i32, ptr %ctx.field.557, align 4
  %steps.next.559 = add i32 %steps.current.558, 1
  store i32 %steps.next.559, ptr %ctx.field.557, align 4
  %steps.over.560 = icmp ugt i32 %steps.next.559, 10000
  br i1 %steps.over.560, label %failure.561, label %continue.562
failure.561:
  %ctx.field.563 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 49, ptr %ctx.field.563, align 4
  %status.diagnostic.564 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.564, align 4
  ret void
continue.562:
  %depth.exceeded.565 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.565, label %failure.566, label %continue.567
failure.566:
  %ctx.field.568 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 50, ptr %ctx.field.568, align 4
  %status.diagnostic.569 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.569, align 4
  ret void
continue.567:
  %workspace.slot.570 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.556, ptr %workspace.slot.570, align 8
  %workspace.slot.571 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.572 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 149, ptr %outputs, i32 1, ptr %workspace.slot.571)
  switch i32 %record.make.status.572, label %runtime.invalid.result.578 [ i32 0, label %runtime.success.573 i32 1, label %runtime.invalid.request.574 i32 2, label %runtime.invalid.reference.575 i32 3, label %runtime.scratch.capacity.576 i32 4, label %runtime.retained.capacity.577 ]
runtime.invalid.request.574:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.575:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.576:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.577:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.578:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.573:
  %record.make.handle.579 = load i64, ptr %workspace.slot.571, align 8
  %ctx.field.580 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.581 = load i32, ptr %ctx.field.580, align 4
  %steps.next.582 = add i32 %steps.current.581, 1
  store i32 %steps.next.582, ptr %ctx.field.580, align 4
  %steps.over.583 = icmp ugt i32 %steps.next.582, 10000
  br i1 %steps.over.583, label %failure.584, label %continue.585
failure.584:
  %ctx.field.586 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 51, ptr %ctx.field.586, align 4
  %status.diagnostic.587 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.587, align 4
  ret void
continue.585:
  %depth.exceeded.588 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.588, label %failure.589, label %continue.590
failure.589:
  %ctx.field.591 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 52, ptr %ctx.field.591, align 4
  %status.diagnostic.592 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.592, align 4
  ret void
continue.590:
  %workspace.slot.593 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.579, ptr %workspace.slot.593, align 8
  %workspace.slot.594 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.595 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 160, ptr %outputs, i32 1, ptr %workspace.slot.594)
  switch i32 %record.make.status.595, label %runtime.invalid.result.601 [ i32 0, label %runtime.success.596 i32 1, label %runtime.invalid.request.597 i32 2, label %runtime.invalid.reference.598 i32 3, label %runtime.scratch.capacity.599 i32 4, label %runtime.retained.capacity.600 ]
runtime.invalid.request.597:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.598:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.599:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.600:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.601:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.596:
  %record.make.handle.602 = load i64, ptr %workspace.slot.594, align 8
  %ctx.field.603 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.604 = load i32, ptr %ctx.field.603, align 4
  %steps.next.605 = add i32 %steps.current.604, 1
  store i32 %steps.next.605, ptr %ctx.field.603, align 4
  %steps.over.606 = icmp ugt i32 %steps.next.605, 10000
  br i1 %steps.over.606, label %failure.607, label %continue.608
failure.607:
  %ctx.field.609 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 53, ptr %ctx.field.609, align 4
  %status.diagnostic.610 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.610, align 4
  ret void
continue.608:
  %depth.exceeded.611 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.611, label %failure.612, label %continue.613
failure.612:
  %ctx.field.614 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 54, ptr %ctx.field.614, align 4
  %status.diagnostic.615 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.615, align 4
  ret void
continue.613:
  %workspace.slot.616 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.602, ptr %workspace.slot.616, align 8
  %workspace.slot.617 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.618 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 171, ptr %outputs, i32 1, ptr %workspace.slot.617)
  switch i32 %record.make.status.618, label %runtime.invalid.result.624 [ i32 0, label %runtime.success.619 i32 1, label %runtime.invalid.request.620 i32 2, label %runtime.invalid.reference.621 i32 3, label %runtime.scratch.capacity.622 i32 4, label %runtime.retained.capacity.623 ]
runtime.invalid.request.620:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.621:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.622:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.623:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.624:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.619:
  %record.make.handle.625 = load i64, ptr %workspace.slot.617, align 8
  %ctx.field.626 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.627 = load i32, ptr %ctx.field.626, align 4
  %steps.next.628 = add i32 %steps.current.627, 1
  store i32 %steps.next.628, ptr %ctx.field.626, align 4
  %steps.over.629 = icmp ugt i32 %steps.next.628, 10000
  br i1 %steps.over.629, label %failure.630, label %continue.631
failure.630:
  %ctx.field.632 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 55, ptr %ctx.field.632, align 4
  %status.diagnostic.633 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.633, align 4
  ret void
continue.631:
  %depth.exceeded.634 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.634, label %failure.635, label %continue.636
failure.635:
  %ctx.field.637 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 56, ptr %ctx.field.637, align 4
  %status.diagnostic.638 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.638, align 4
  ret void
continue.636:
  %workspace.slot.639 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.625, ptr %workspace.slot.639, align 8
  %workspace.slot.640 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.641 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 178, ptr %outputs, i32 1, ptr %workspace.slot.640)
  switch i32 %record.make.status.641, label %runtime.invalid.result.647 [ i32 0, label %runtime.success.642 i32 1, label %runtime.invalid.request.643 i32 2, label %runtime.invalid.reference.644 i32 3, label %runtime.scratch.capacity.645 i32 4, label %runtime.retained.capacity.646 ]
runtime.invalid.request.643:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.644:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.645:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.646:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.647:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.642:
  %record.make.handle.648 = load i64, ptr %workspace.slot.640, align 8
  %ctx.field.649 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.650 = load i32, ptr %ctx.field.649, align 4
  %steps.next.651 = add i32 %steps.current.650, 1
  store i32 %steps.next.651, ptr %ctx.field.649, align 4
  %steps.over.652 = icmp ugt i32 %steps.next.651, 10000
  br i1 %steps.over.652, label %failure.653, label %continue.654
failure.653:
  %ctx.field.655 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 57, ptr %ctx.field.655, align 4
  %status.diagnostic.656 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.656, align 4
  ret void
continue.654:
  %depth.exceeded.657 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.657, label %failure.658, label %continue.659
failure.658:
  %ctx.field.660 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 58, ptr %ctx.field.660, align 4
  %status.diagnostic.661 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.661, align 4
  ret void
continue.659:
  %workspace.slot.662 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.648, ptr %workspace.slot.662, align 8
  %workspace.slot.663 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.664 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 179, ptr %outputs, i32 1, ptr %workspace.slot.663)
  switch i32 %record.make.status.664, label %runtime.invalid.result.670 [ i32 0, label %runtime.success.665 i32 1, label %runtime.invalid.request.666 i32 2, label %runtime.invalid.reference.667 i32 3, label %runtime.scratch.capacity.668 i32 4, label %runtime.retained.capacity.669 ]
runtime.invalid.request.666:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.667:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.668:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.669:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.670:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.665:
  %record.make.handle.671 = load i64, ptr %workspace.slot.663, align 8
  %ctx.field.672 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.673 = load i32, ptr %ctx.field.672, align 4
  %steps.next.674 = add i32 %steps.current.673, 1
  store i32 %steps.next.674, ptr %ctx.field.672, align 4
  %steps.over.675 = icmp ugt i32 %steps.next.674, 10000
  br i1 %steps.over.675, label %failure.676, label %continue.677
failure.676:
  %ctx.field.678 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 59, ptr %ctx.field.678, align 4
  %status.diagnostic.679 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.679, align 4
  ret void
continue.677:
  %depth.exceeded.680 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.680, label %failure.681, label %continue.682
failure.681:
  %ctx.field.683 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 60, ptr %ctx.field.683, align 4
  %status.diagnostic.684 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.684, align 4
  ret void
continue.682:
  %workspace.slot.685 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.671, ptr %workspace.slot.685, align 8
  %workspace.slot.686 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.687 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 180, ptr %outputs, i32 1, ptr %workspace.slot.686)
  switch i32 %record.make.status.687, label %runtime.invalid.result.693 [ i32 0, label %runtime.success.688 i32 1, label %runtime.invalid.request.689 i32 2, label %runtime.invalid.reference.690 i32 3, label %runtime.scratch.capacity.691 i32 4, label %runtime.retained.capacity.692 ]
runtime.invalid.request.689:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.690:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.691:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.692:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.693:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.688:
  %record.make.handle.694 = load i64, ptr %workspace.slot.686, align 8
  %ctx.field.695 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.696 = load i32, ptr %ctx.field.695, align 4
  %steps.next.697 = add i32 %steps.current.696, 1
  store i32 %steps.next.697, ptr %ctx.field.695, align 4
  %steps.over.698 = icmp ugt i32 %steps.next.697, 10000
  br i1 %steps.over.698, label %failure.699, label %continue.700
failure.699:
  %ctx.field.701 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 61, ptr %ctx.field.701, align 4
  %status.diagnostic.702 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.702, align 4
  ret void
continue.700:
  %depth.exceeded.703 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.703, label %failure.704, label %continue.705
failure.704:
  %ctx.field.706 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 62, ptr %ctx.field.706, align 4
  %status.diagnostic.707 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.707, align 4
  ret void
continue.705:
  %workspace.slot.708 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.694, ptr %workspace.slot.708, align 8
  %workspace.slot.709 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.710 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 181, ptr %outputs, i32 1, ptr %workspace.slot.709)
  switch i32 %record.make.status.710, label %runtime.invalid.result.716 [ i32 0, label %runtime.success.711 i32 1, label %runtime.invalid.request.712 i32 2, label %runtime.invalid.reference.713 i32 3, label %runtime.scratch.capacity.714 i32 4, label %runtime.retained.capacity.715 ]
runtime.invalid.request.712:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.713:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.714:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.715:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.716:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.711:
  %record.make.handle.717 = load i64, ptr %workspace.slot.709, align 8
  %ctx.field.718 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.719 = load i32, ptr %ctx.field.718, align 4
  %steps.next.720 = add i32 %steps.current.719, 1
  store i32 %steps.next.720, ptr %ctx.field.718, align 4
  %steps.over.721 = icmp ugt i32 %steps.next.720, 10000
  br i1 %steps.over.721, label %failure.722, label %continue.723
failure.722:
  %ctx.field.724 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 63, ptr %ctx.field.724, align 4
  %status.diagnostic.725 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.725, align 4
  ret void
continue.723:
  %depth.exceeded.726 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.726, label %failure.727, label %continue.728
failure.727:
  %ctx.field.729 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 64, ptr %ctx.field.729, align 4
  %status.diagnostic.730 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.730, align 4
  ret void
continue.728:
  %workspace.slot.731 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.717, ptr %workspace.slot.731, align 8
  %workspace.slot.732 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.733 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 183, ptr %outputs, i32 1, ptr %workspace.slot.732)
  switch i32 %record.make.status.733, label %runtime.invalid.result.739 [ i32 0, label %runtime.success.734 i32 1, label %runtime.invalid.request.735 i32 2, label %runtime.invalid.reference.736 i32 3, label %runtime.scratch.capacity.737 i32 4, label %runtime.retained.capacity.738 ]
runtime.invalid.request.735:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.736:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.737:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.738:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.739:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.734:
  %record.make.handle.740 = load i64, ptr %workspace.slot.732, align 8
  %ctx.field.741 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.742 = load i32, ptr %ctx.field.741, align 4
  %steps.next.743 = add i32 %steps.current.742, 1
  store i32 %steps.next.743, ptr %ctx.field.741, align 4
  %steps.over.744 = icmp ugt i32 %steps.next.743, 10000
  br i1 %steps.over.744, label %failure.745, label %continue.746
failure.745:
  %ctx.field.747 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 65, ptr %ctx.field.747, align 4
  %status.diagnostic.748 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.748, align 4
  ret void
continue.746:
  %depth.exceeded.749 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.749, label %failure.750, label %continue.751
failure.750:
  %ctx.field.752 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 66, ptr %ctx.field.752, align 4
  %status.diagnostic.753 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.753, align 4
  ret void
continue.751:
  %workspace.slot.754 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.740, ptr %workspace.slot.754, align 8
  %workspace.slot.755 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.756 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 184, ptr %outputs, i32 1, ptr %workspace.slot.755)
  switch i32 %record.make.status.756, label %runtime.invalid.result.762 [ i32 0, label %runtime.success.757 i32 1, label %runtime.invalid.request.758 i32 2, label %runtime.invalid.reference.759 i32 3, label %runtime.scratch.capacity.760 i32 4, label %runtime.retained.capacity.761 ]
runtime.invalid.request.758:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.759:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.760:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.761:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.762:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.757:
  %record.make.handle.763 = load i64, ptr %workspace.slot.755, align 8
  %ctx.field.764 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.765 = load i32, ptr %ctx.field.764, align 4
  %steps.next.766 = add i32 %steps.current.765, 1
  store i32 %steps.next.766, ptr %ctx.field.764, align 4
  %steps.over.767 = icmp ugt i32 %steps.next.766, 10000
  br i1 %steps.over.767, label %failure.768, label %continue.769
failure.768:
  %ctx.field.770 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 67, ptr %ctx.field.770, align 4
  %status.diagnostic.771 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.771, align 4
  ret void
continue.769:
  %depth.exceeded.772 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.772, label %failure.773, label %continue.774
failure.773:
  %ctx.field.775 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 68, ptr %ctx.field.775, align 4
  %status.diagnostic.776 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.776, align 4
  ret void
continue.774:
  %workspace.slot.777 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.763, ptr %workspace.slot.777, align 8
  %workspace.slot.778 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.779 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 185, ptr %outputs, i32 1, ptr %workspace.slot.778)
  switch i32 %record.make.status.779, label %runtime.invalid.result.785 [ i32 0, label %runtime.success.780 i32 1, label %runtime.invalid.request.781 i32 2, label %runtime.invalid.reference.782 i32 3, label %runtime.scratch.capacity.783 i32 4, label %runtime.retained.capacity.784 ]
runtime.invalid.request.781:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.782:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.783:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.784:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.785:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.780:
  %record.make.handle.786 = load i64, ptr %workspace.slot.778, align 8
  %ctx.field.787 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.788 = load i32, ptr %ctx.field.787, align 4
  %steps.next.789 = add i32 %steps.current.788, 1
  store i32 %steps.next.789, ptr %ctx.field.787, align 4
  %steps.over.790 = icmp ugt i32 %steps.next.789, 10000
  br i1 %steps.over.790, label %failure.791, label %continue.792
failure.791:
  %ctx.field.793 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 69, ptr %ctx.field.793, align 4
  %status.diagnostic.794 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.794, align 4
  ret void
continue.792:
  %depth.exceeded.795 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.795, label %failure.796, label %continue.797
failure.796:
  %ctx.field.798 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 70, ptr %ctx.field.798, align 4
  %status.diagnostic.799 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.799, align 4
  ret void
continue.797:
  %workspace.slot.800 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.786, ptr %workspace.slot.800, align 8
  %workspace.slot.801 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.802 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 186, ptr %outputs, i32 1, ptr %workspace.slot.801)
  switch i32 %record.make.status.802, label %runtime.invalid.result.808 [ i32 0, label %runtime.success.803 i32 1, label %runtime.invalid.request.804 i32 2, label %runtime.invalid.reference.805 i32 3, label %runtime.scratch.capacity.806 i32 4, label %runtime.retained.capacity.807 ]
runtime.invalid.request.804:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.805:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.806:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.807:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.808:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.803:
  %record.make.handle.809 = load i64, ptr %workspace.slot.801, align 8
  %ctx.field.810 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.811 = load i32, ptr %ctx.field.810, align 4
  %steps.next.812 = add i32 %steps.current.811, 1
  store i32 %steps.next.812, ptr %ctx.field.810, align 4
  %steps.over.813 = icmp ugt i32 %steps.next.812, 10000
  br i1 %steps.over.813, label %failure.814, label %continue.815
failure.814:
  %ctx.field.816 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 71, ptr %ctx.field.816, align 4
  %status.diagnostic.817 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.817, align 4
  ret void
continue.815:
  %depth.exceeded.818 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.818, label %failure.819, label %continue.820
failure.819:
  %ctx.field.821 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 72, ptr %ctx.field.821, align 4
  %status.diagnostic.822 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.822, align 4
  ret void
continue.820:
  %workspace.slot.823 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.809, ptr %workspace.slot.823, align 8
  %workspace.slot.824 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.825 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 187, ptr %outputs, i32 1, ptr %workspace.slot.824)
  switch i32 %record.make.status.825, label %runtime.invalid.result.831 [ i32 0, label %runtime.success.826 i32 1, label %runtime.invalid.request.827 i32 2, label %runtime.invalid.reference.828 i32 3, label %runtime.scratch.capacity.829 i32 4, label %runtime.retained.capacity.830 ]
runtime.invalid.request.827:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.828:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.829:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.830:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.831:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.826:
  %record.make.handle.832 = load i64, ptr %workspace.slot.824, align 8
  %ctx.field.833 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.834 = load i32, ptr %ctx.field.833, align 4
  %steps.next.835 = add i32 %steps.current.834, 1
  store i32 %steps.next.835, ptr %ctx.field.833, align 4
  %steps.over.836 = icmp ugt i32 %steps.next.835, 10000
  br i1 %steps.over.836, label %failure.837, label %continue.838
failure.837:
  %ctx.field.839 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 73, ptr %ctx.field.839, align 4
  %status.diagnostic.840 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.840, align 4
  ret void
continue.838:
  %depth.exceeded.841 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.841, label %failure.842, label %continue.843
failure.842:
  %ctx.field.844 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 74, ptr %ctx.field.844, align 4
  %status.diagnostic.845 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.845, align 4
  ret void
continue.843:
  %workspace.slot.846 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.832, ptr %workspace.slot.846, align 8
  %workspace.slot.847 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.848 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 188, ptr %outputs, i32 1, ptr %workspace.slot.847)
  switch i32 %record.make.status.848, label %runtime.invalid.result.854 [ i32 0, label %runtime.success.849 i32 1, label %runtime.invalid.request.850 i32 2, label %runtime.invalid.reference.851 i32 3, label %runtime.scratch.capacity.852 i32 4, label %runtime.retained.capacity.853 ]
runtime.invalid.request.850:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.851:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.852:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.853:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.854:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.849:
  %record.make.handle.855 = load i64, ptr %workspace.slot.847, align 8
  %ctx.field.856 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.857 = load i32, ptr %ctx.field.856, align 4
  %steps.next.858 = add i32 %steps.current.857, 1
  store i32 %steps.next.858, ptr %ctx.field.856, align 4
  %steps.over.859 = icmp ugt i32 %steps.next.858, 10000
  br i1 %steps.over.859, label %failure.860, label %continue.861
failure.860:
  %ctx.field.862 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 75, ptr %ctx.field.862, align 4
  %status.diagnostic.863 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.863, align 4
  ret void
continue.861:
  %depth.exceeded.864 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.864, label %failure.865, label %continue.866
failure.865:
  %ctx.field.867 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 76, ptr %ctx.field.867, align 4
  %status.diagnostic.868 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.868, align 4
  ret void
continue.866:
  %workspace.slot.869 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.855, ptr %workspace.slot.869, align 8
  %workspace.slot.870 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.871 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 189, ptr %outputs, i32 1, ptr %workspace.slot.870)
  switch i32 %record.make.status.871, label %runtime.invalid.result.877 [ i32 0, label %runtime.success.872 i32 1, label %runtime.invalid.request.873 i32 2, label %runtime.invalid.reference.874 i32 3, label %runtime.scratch.capacity.875 i32 4, label %runtime.retained.capacity.876 ]
runtime.invalid.request.873:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.874:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.875:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.876:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.877:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.872:
  %record.make.handle.878 = load i64, ptr %workspace.slot.870, align 8
  %ctx.field.879 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.880 = load i32, ptr %ctx.field.879, align 4
  %steps.next.881 = add i32 %steps.current.880, 1
  store i32 %steps.next.881, ptr %ctx.field.879, align 4
  %steps.over.882 = icmp ugt i32 %steps.next.881, 10000
  br i1 %steps.over.882, label %failure.883, label %continue.884
failure.883:
  %ctx.field.885 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 77, ptr %ctx.field.885, align 4
  %status.diagnostic.886 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.886, align 4
  ret void
continue.884:
  %depth.exceeded.887 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.887, label %failure.888, label %continue.889
failure.888:
  %ctx.field.890 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 78, ptr %ctx.field.890, align 4
  %status.diagnostic.891 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.891, align 4
  ret void
continue.889:
  %workspace.slot.892 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.878, ptr %workspace.slot.892, align 8
  %workspace.slot.893 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.894 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 190, ptr %outputs, i32 1, ptr %workspace.slot.893)
  switch i32 %record.make.status.894, label %runtime.invalid.result.900 [ i32 0, label %runtime.success.895 i32 1, label %runtime.invalid.request.896 i32 2, label %runtime.invalid.reference.897 i32 3, label %runtime.scratch.capacity.898 i32 4, label %runtime.retained.capacity.899 ]
runtime.invalid.request.896:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.897:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.898:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.899:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.900:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.895:
  %record.make.handle.901 = load i64, ptr %workspace.slot.893, align 8
  %ctx.field.902 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.903 = load i32, ptr %ctx.field.902, align 4
  %steps.next.904 = add i32 %steps.current.903, 1
  store i32 %steps.next.904, ptr %ctx.field.902, align 4
  %steps.over.905 = icmp ugt i32 %steps.next.904, 10000
  br i1 %steps.over.905, label %failure.906, label %continue.907
failure.906:
  %ctx.field.908 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 79, ptr %ctx.field.908, align 4
  %status.diagnostic.909 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.909, align 4
  ret void
continue.907:
  %depth.exceeded.910 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.910, label %failure.911, label %continue.912
failure.911:
  %ctx.field.913 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 80, ptr %ctx.field.913, align 4
  %status.diagnostic.914 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.914, align 4
  ret void
continue.912:
  %workspace.slot.915 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.901, ptr %workspace.slot.915, align 8
  %workspace.slot.916 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.917 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 191, ptr %outputs, i32 1, ptr %workspace.slot.916)
  switch i32 %record.make.status.917, label %runtime.invalid.result.923 [ i32 0, label %runtime.success.918 i32 1, label %runtime.invalid.request.919 i32 2, label %runtime.invalid.reference.920 i32 3, label %runtime.scratch.capacity.921 i32 4, label %runtime.retained.capacity.922 ]
runtime.invalid.request.919:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.920:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.921:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.922:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.923:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.918:
  %record.make.handle.924 = load i64, ptr %workspace.slot.916, align 8
  %ctx.field.925 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.926 = load i32, ptr %ctx.field.925, align 4
  %steps.next.927 = add i32 %steps.current.926, 1
  store i32 %steps.next.927, ptr %ctx.field.925, align 4
  %steps.over.928 = icmp ugt i32 %steps.next.927, 10000
  br i1 %steps.over.928, label %failure.929, label %continue.930
failure.929:
  %ctx.field.931 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 81, ptr %ctx.field.931, align 4
  %status.diagnostic.932 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.932, align 4
  ret void
continue.930:
  %depth.exceeded.933 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.933, label %failure.934, label %continue.935
failure.934:
  %ctx.field.936 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 82, ptr %ctx.field.936, align 4
  %status.diagnostic.937 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.937, align 4
  ret void
continue.935:
  %workspace.slot.938 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.924, ptr %workspace.slot.938, align 8
  %workspace.slot.939 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.940 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 192, ptr %outputs, i32 1, ptr %workspace.slot.939)
  switch i32 %record.make.status.940, label %runtime.invalid.result.946 [ i32 0, label %runtime.success.941 i32 1, label %runtime.invalid.request.942 i32 2, label %runtime.invalid.reference.943 i32 3, label %runtime.scratch.capacity.944 i32 4, label %runtime.retained.capacity.945 ]
runtime.invalid.request.942:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.943:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.944:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.945:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.946:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.941:
  %record.make.handle.947 = load i64, ptr %workspace.slot.939, align 8
  %ctx.field.948 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.949 = load i32, ptr %ctx.field.948, align 4
  %steps.next.950 = add i32 %steps.current.949, 1
  store i32 %steps.next.950, ptr %ctx.field.948, align 4
  %steps.over.951 = icmp ugt i32 %steps.next.950, 10000
  br i1 %steps.over.951, label %failure.952, label %continue.953
failure.952:
  %ctx.field.954 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 83, ptr %ctx.field.954, align 4
  %status.diagnostic.955 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.955, align 4
  ret void
continue.953:
  %depth.exceeded.956 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.956, label %failure.957, label %continue.958
failure.957:
  %ctx.field.959 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 84, ptr %ctx.field.959, align 4
  %status.diagnostic.960 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.960, align 4
  ret void
continue.958:
  %workspace.slot.961 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.947, ptr %workspace.slot.961, align 8
  %workspace.slot.962 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.963 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 194, ptr %outputs, i32 1, ptr %workspace.slot.962)
  switch i32 %record.make.status.963, label %runtime.invalid.result.969 [ i32 0, label %runtime.success.964 i32 1, label %runtime.invalid.request.965 i32 2, label %runtime.invalid.reference.966 i32 3, label %runtime.scratch.capacity.967 i32 4, label %runtime.retained.capacity.968 ]
runtime.invalid.request.965:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.966:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.967:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.968:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.969:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.964:
  %record.make.handle.970 = load i64, ptr %workspace.slot.962, align 8
  %ctx.field.971 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.972 = load i32, ptr %ctx.field.971, align 4
  %steps.next.973 = add i32 %steps.current.972, 1
  store i32 %steps.next.973, ptr %ctx.field.971, align 4
  %steps.over.974 = icmp ugt i32 %steps.next.973, 10000
  br i1 %steps.over.974, label %failure.975, label %continue.976
failure.975:
  %ctx.field.977 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 85, ptr %ctx.field.977, align 4
  %status.diagnostic.978 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.978, align 4
  ret void
continue.976:
  %depth.exceeded.979 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.979, label %failure.980, label %continue.981
failure.980:
  %ctx.field.982 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 86, ptr %ctx.field.982, align 4
  %status.diagnostic.983 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.983, align 4
  ret void
continue.981:
  %workspace.slot.984 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.970, ptr %workspace.slot.984, align 8
  %workspace.slot.985 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.986 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 195, ptr %outputs, i32 1, ptr %workspace.slot.985)
  switch i32 %record.make.status.986, label %runtime.invalid.result.992 [ i32 0, label %runtime.success.987 i32 1, label %runtime.invalid.request.988 i32 2, label %runtime.invalid.reference.989 i32 3, label %runtime.scratch.capacity.990 i32 4, label %runtime.retained.capacity.991 ]
runtime.invalid.request.988:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.989:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.990:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.991:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.992:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.987:
  %record.make.handle.993 = load i64, ptr %workspace.slot.985, align 8
  %ctx.field.994 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.995 = load i32, ptr %ctx.field.994, align 4
  %steps.next.996 = add i32 %steps.current.995, 1
  store i32 %steps.next.996, ptr %ctx.field.994, align 4
  %steps.over.997 = icmp ugt i32 %steps.next.996, 10000
  br i1 %steps.over.997, label %failure.998, label %continue.999
failure.998:
  %ctx.field.1000 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 87, ptr %ctx.field.1000, align 4
  %status.diagnostic.1001 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1001, align 4
  ret void
continue.999:
  %depth.exceeded.1002 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1002, label %failure.1003, label %continue.1004
failure.1003:
  %ctx.field.1005 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 88, ptr %ctx.field.1005, align 4
  %status.diagnostic.1006 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1006, align 4
  ret void
continue.1004:
  %workspace.slot.1007 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.993, ptr %workspace.slot.1007, align 8
  %workspace.slot.1008 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1009 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 196, ptr %outputs, i32 1, ptr %workspace.slot.1008)
  switch i32 %record.make.status.1009, label %runtime.invalid.result.1015 [ i32 0, label %runtime.success.1010 i32 1, label %runtime.invalid.request.1011 i32 2, label %runtime.invalid.reference.1012 i32 3, label %runtime.scratch.capacity.1013 i32 4, label %runtime.retained.capacity.1014 ]
runtime.invalid.request.1011:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1012:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1013:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1014:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1015:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1010:
  %record.make.handle.1016 = load i64, ptr %workspace.slot.1008, align 8
  %ctx.field.1017 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1018 = load i32, ptr %ctx.field.1017, align 4
  %steps.next.1019 = add i32 %steps.current.1018, 1
  store i32 %steps.next.1019, ptr %ctx.field.1017, align 4
  %steps.over.1020 = icmp ugt i32 %steps.next.1019, 10000
  br i1 %steps.over.1020, label %failure.1021, label %continue.1022
failure.1021:
  %ctx.field.1023 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 89, ptr %ctx.field.1023, align 4
  %status.diagnostic.1024 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1024, align 4
  ret void
continue.1022:
  %depth.exceeded.1025 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1025, label %failure.1026, label %continue.1027
failure.1026:
  %ctx.field.1028 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 90, ptr %ctx.field.1028, align 4
  %status.diagnostic.1029 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1029, align 4
  ret void
continue.1027:
  %workspace.slot.1030 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1016, ptr %workspace.slot.1030, align 8
  %workspace.slot.1031 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1032 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 197, ptr %outputs, i32 1, ptr %workspace.slot.1031)
  switch i32 %record.make.status.1032, label %runtime.invalid.result.1038 [ i32 0, label %runtime.success.1033 i32 1, label %runtime.invalid.request.1034 i32 2, label %runtime.invalid.reference.1035 i32 3, label %runtime.scratch.capacity.1036 i32 4, label %runtime.retained.capacity.1037 ]
runtime.invalid.request.1034:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1035:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1036:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1037:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1038:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1033:
  %record.make.handle.1039 = load i64, ptr %workspace.slot.1031, align 8
  %ctx.field.1040 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1041 = load i32, ptr %ctx.field.1040, align 4
  %steps.next.1042 = add i32 %steps.current.1041, 1
  store i32 %steps.next.1042, ptr %ctx.field.1040, align 4
  %steps.over.1043 = icmp ugt i32 %steps.next.1042, 10000
  br i1 %steps.over.1043, label %failure.1044, label %continue.1045
failure.1044:
  %ctx.field.1046 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 91, ptr %ctx.field.1046, align 4
  %status.diagnostic.1047 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1047, align 4
  ret void
continue.1045:
  %depth.exceeded.1048 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1048, label %failure.1049, label %continue.1050
failure.1049:
  %ctx.field.1051 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 92, ptr %ctx.field.1051, align 4
  %status.diagnostic.1052 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1052, align 4
  ret void
continue.1050:
  %workspace.slot.1053 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1039, ptr %workspace.slot.1053, align 8
  %workspace.slot.1054 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1055 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 198, ptr %outputs, i32 1, ptr %workspace.slot.1054)
  switch i32 %record.make.status.1055, label %runtime.invalid.result.1061 [ i32 0, label %runtime.success.1056 i32 1, label %runtime.invalid.request.1057 i32 2, label %runtime.invalid.reference.1058 i32 3, label %runtime.scratch.capacity.1059 i32 4, label %runtime.retained.capacity.1060 ]
runtime.invalid.request.1057:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1058:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1059:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1060:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1061:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1056:
  %record.make.handle.1062 = load i64, ptr %workspace.slot.1054, align 8
  %ctx.field.1063 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1064 = load i32, ptr %ctx.field.1063, align 4
  %steps.next.1065 = add i32 %steps.current.1064, 1
  store i32 %steps.next.1065, ptr %ctx.field.1063, align 4
  %steps.over.1066 = icmp ugt i32 %steps.next.1065, 10000
  br i1 %steps.over.1066, label %failure.1067, label %continue.1068
failure.1067:
  %ctx.field.1069 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 93, ptr %ctx.field.1069, align 4
  %status.diagnostic.1070 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1070, align 4
  ret void
continue.1068:
  %depth.exceeded.1071 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1071, label %failure.1072, label %continue.1073
failure.1072:
  %ctx.field.1074 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 94, ptr %ctx.field.1074, align 4
  %status.diagnostic.1075 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1075, align 4
  ret void
continue.1073:
  %workspace.slot.1076 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1062, ptr %workspace.slot.1076, align 8
  %workspace.slot.1077 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1078 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 199, ptr %outputs, i32 1, ptr %workspace.slot.1077)
  switch i32 %record.make.status.1078, label %runtime.invalid.result.1084 [ i32 0, label %runtime.success.1079 i32 1, label %runtime.invalid.request.1080 i32 2, label %runtime.invalid.reference.1081 i32 3, label %runtime.scratch.capacity.1082 i32 4, label %runtime.retained.capacity.1083 ]
runtime.invalid.request.1080:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1081:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1082:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1083:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1084:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1079:
  %record.make.handle.1085 = load i64, ptr %workspace.slot.1077, align 8
  %ctx.field.1086 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1087 = load i32, ptr %ctx.field.1086, align 4
  %steps.next.1088 = add i32 %steps.current.1087, 1
  store i32 %steps.next.1088, ptr %ctx.field.1086, align 4
  %steps.over.1089 = icmp ugt i32 %steps.next.1088, 10000
  br i1 %steps.over.1089, label %failure.1090, label %continue.1091
failure.1090:
  %ctx.field.1092 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 95, ptr %ctx.field.1092, align 4
  %status.diagnostic.1093 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1093, align 4
  ret void
continue.1091:
  %depth.exceeded.1094 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1094, label %failure.1095, label %continue.1096
failure.1095:
  %ctx.field.1097 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 96, ptr %ctx.field.1097, align 4
  %status.diagnostic.1098 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1098, align 4
  ret void
continue.1096:
  %workspace.slot.1099 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1085, ptr %workspace.slot.1099, align 8
  %workspace.slot.1100 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1101 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 200, ptr %outputs, i32 1, ptr %workspace.slot.1100)
  switch i32 %record.make.status.1101, label %runtime.invalid.result.1107 [ i32 0, label %runtime.success.1102 i32 1, label %runtime.invalid.request.1103 i32 2, label %runtime.invalid.reference.1104 i32 3, label %runtime.scratch.capacity.1105 i32 4, label %runtime.retained.capacity.1106 ]
runtime.invalid.request.1103:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1104:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1105:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1106:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1107:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1102:
  %record.make.handle.1108 = load i64, ptr %workspace.slot.1100, align 8
  %ctx.field.1109 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1110 = load i32, ptr %ctx.field.1109, align 4
  %steps.next.1111 = add i32 %steps.current.1110, 1
  store i32 %steps.next.1111, ptr %ctx.field.1109, align 4
  %steps.over.1112 = icmp ugt i32 %steps.next.1111, 10000
  br i1 %steps.over.1112, label %failure.1113, label %continue.1114
failure.1113:
  %ctx.field.1115 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 97, ptr %ctx.field.1115, align 4
  %status.diagnostic.1116 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1116, align 4
  ret void
continue.1114:
  %depth.exceeded.1117 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1117, label %failure.1118, label %continue.1119
failure.1118:
  %ctx.field.1120 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 98, ptr %ctx.field.1120, align 4
  %status.diagnostic.1121 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1121, align 4
  ret void
continue.1119:
  %workspace.slot.1122 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1108, ptr %workspace.slot.1122, align 8
  %workspace.slot.1123 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1124 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 201, ptr %outputs, i32 1, ptr %workspace.slot.1123)
  switch i32 %record.make.status.1124, label %runtime.invalid.result.1130 [ i32 0, label %runtime.success.1125 i32 1, label %runtime.invalid.request.1126 i32 2, label %runtime.invalid.reference.1127 i32 3, label %runtime.scratch.capacity.1128 i32 4, label %runtime.retained.capacity.1129 ]
runtime.invalid.request.1126:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1127:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1128:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1129:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1130:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1125:
  %record.make.handle.1131 = load i64, ptr %workspace.slot.1123, align 8
  %ctx.field.1132 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1133 = load i32, ptr %ctx.field.1132, align 4
  %steps.next.1134 = add i32 %steps.current.1133, 1
  store i32 %steps.next.1134, ptr %ctx.field.1132, align 4
  %steps.over.1135 = icmp ugt i32 %steps.next.1134, 10000
  br i1 %steps.over.1135, label %failure.1136, label %continue.1137
failure.1136:
  %ctx.field.1138 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 99, ptr %ctx.field.1138, align 4
  %status.diagnostic.1139 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1139, align 4
  ret void
continue.1137:
  %depth.exceeded.1140 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1140, label %failure.1141, label %continue.1142
failure.1141:
  %ctx.field.1143 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 100, ptr %ctx.field.1143, align 4
  %status.diagnostic.1144 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1144, align 4
  ret void
continue.1142:
  %workspace.slot.1145 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1131, ptr %workspace.slot.1145, align 8
  %workspace.slot.1146 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1147 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 202, ptr %outputs, i32 1, ptr %workspace.slot.1146)
  switch i32 %record.make.status.1147, label %runtime.invalid.result.1153 [ i32 0, label %runtime.success.1148 i32 1, label %runtime.invalid.request.1149 i32 2, label %runtime.invalid.reference.1150 i32 3, label %runtime.scratch.capacity.1151 i32 4, label %runtime.retained.capacity.1152 ]
runtime.invalid.request.1149:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1150:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1151:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1152:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1153:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1148:
  %record.make.handle.1154 = load i64, ptr %workspace.slot.1146, align 8
  %ctx.field.1155 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1156 = load i32, ptr %ctx.field.1155, align 4
  %steps.next.1157 = add i32 %steps.current.1156, 1
  store i32 %steps.next.1157, ptr %ctx.field.1155, align 4
  %steps.over.1158 = icmp ugt i32 %steps.next.1157, 10000
  br i1 %steps.over.1158, label %failure.1159, label %continue.1160
failure.1159:
  %ctx.field.1161 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 101, ptr %ctx.field.1161, align 4
  %status.diagnostic.1162 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1162, align 4
  ret void
continue.1160:
  %depth.exceeded.1163 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1163, label %failure.1164, label %continue.1165
failure.1164:
  %ctx.field.1166 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 102, ptr %ctx.field.1166, align 4
  %status.diagnostic.1167 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1167, align 4
  ret void
continue.1165:
  %workspace.slot.1168 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1154, ptr %workspace.slot.1168, align 8
  %workspace.slot.1169 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1170 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 203, ptr %outputs, i32 1, ptr %workspace.slot.1169)
  switch i32 %record.make.status.1170, label %runtime.invalid.result.1176 [ i32 0, label %runtime.success.1171 i32 1, label %runtime.invalid.request.1172 i32 2, label %runtime.invalid.reference.1173 i32 3, label %runtime.scratch.capacity.1174 i32 4, label %runtime.retained.capacity.1175 ]
runtime.invalid.request.1172:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1173:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1174:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1175:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1176:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1171:
  %record.make.handle.1177 = load i64, ptr %workspace.slot.1169, align 8
  %ctx.field.1178 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1179 = load i32, ptr %ctx.field.1178, align 4
  %steps.next.1180 = add i32 %steps.current.1179, 1
  store i32 %steps.next.1180, ptr %ctx.field.1178, align 4
  %steps.over.1181 = icmp ugt i32 %steps.next.1180, 10000
  br i1 %steps.over.1181, label %failure.1182, label %continue.1183
failure.1182:
  %ctx.field.1184 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 103, ptr %ctx.field.1184, align 4
  %status.diagnostic.1185 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1185, align 4
  ret void
continue.1183:
  %depth.exceeded.1186 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1186, label %failure.1187, label %continue.1188
failure.1187:
  %ctx.field.1189 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 104, ptr %ctx.field.1189, align 4
  %status.diagnostic.1190 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1190, align 4
  ret void
continue.1188:
  %workspace.slot.1191 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1177, ptr %workspace.slot.1191, align 8
  %workspace.slot.1192 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1193 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 205, ptr %outputs, i32 1, ptr %workspace.slot.1192)
  switch i32 %record.make.status.1193, label %runtime.invalid.result.1199 [ i32 0, label %runtime.success.1194 i32 1, label %runtime.invalid.request.1195 i32 2, label %runtime.invalid.reference.1196 i32 3, label %runtime.scratch.capacity.1197 i32 4, label %runtime.retained.capacity.1198 ]
runtime.invalid.request.1195:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1196:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1197:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1198:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1199:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1194:
  %record.make.handle.1200 = load i64, ptr %workspace.slot.1192, align 8
  %ctx.field.1201 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1202 = load i32, ptr %ctx.field.1201, align 4
  %steps.next.1203 = add i32 %steps.current.1202, 1
  store i32 %steps.next.1203, ptr %ctx.field.1201, align 4
  %steps.over.1204 = icmp ugt i32 %steps.next.1203, 10000
  br i1 %steps.over.1204, label %failure.1205, label %continue.1206
failure.1205:
  %ctx.field.1207 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 105, ptr %ctx.field.1207, align 4
  %status.diagnostic.1208 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1208, align 4
  ret void
continue.1206:
  %depth.exceeded.1209 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1209, label %failure.1210, label %continue.1211
failure.1210:
  %ctx.field.1212 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 106, ptr %ctx.field.1212, align 4
  %status.diagnostic.1213 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1213, align 4
  ret void
continue.1211:
  %workspace.slot.1214 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1200, ptr %workspace.slot.1214, align 8
  %workspace.slot.1215 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1216 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 206, ptr %outputs, i32 1, ptr %workspace.slot.1215)
  switch i32 %record.make.status.1216, label %runtime.invalid.result.1222 [ i32 0, label %runtime.success.1217 i32 1, label %runtime.invalid.request.1218 i32 2, label %runtime.invalid.reference.1219 i32 3, label %runtime.scratch.capacity.1220 i32 4, label %runtime.retained.capacity.1221 ]
runtime.invalid.request.1218:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1219:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1220:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1221:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1222:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1217:
  %record.make.handle.1223 = load i64, ptr %workspace.slot.1215, align 8
  %ctx.field.1224 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1225 = load i32, ptr %ctx.field.1224, align 4
  %steps.next.1226 = add i32 %steps.current.1225, 1
  store i32 %steps.next.1226, ptr %ctx.field.1224, align 4
  %steps.over.1227 = icmp ugt i32 %steps.next.1226, 10000
  br i1 %steps.over.1227, label %failure.1228, label %continue.1229
failure.1228:
  %ctx.field.1230 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 107, ptr %ctx.field.1230, align 4
  %status.diagnostic.1231 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1231, align 4
  ret void
continue.1229:
  %depth.exceeded.1232 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1232, label %failure.1233, label %continue.1234
failure.1233:
  %ctx.field.1235 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 108, ptr %ctx.field.1235, align 4
  %status.diagnostic.1236 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1236, align 4
  ret void
continue.1234:
  %workspace.slot.1237 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1223, ptr %workspace.slot.1237, align 8
  %workspace.slot.1238 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1239 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 207, ptr %outputs, i32 1, ptr %workspace.slot.1238)
  switch i32 %record.make.status.1239, label %runtime.invalid.result.1245 [ i32 0, label %runtime.success.1240 i32 1, label %runtime.invalid.request.1241 i32 2, label %runtime.invalid.reference.1242 i32 3, label %runtime.scratch.capacity.1243 i32 4, label %runtime.retained.capacity.1244 ]
runtime.invalid.request.1241:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1242:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1243:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1244:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1245:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1240:
  %record.make.handle.1246 = load i64, ptr %workspace.slot.1238, align 8
  %ctx.field.1247 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1248 = load i32, ptr %ctx.field.1247, align 4
  %steps.next.1249 = add i32 %steps.current.1248, 1
  store i32 %steps.next.1249, ptr %ctx.field.1247, align 4
  %steps.over.1250 = icmp ugt i32 %steps.next.1249, 10000
  br i1 %steps.over.1250, label %failure.1251, label %continue.1252
failure.1251:
  %ctx.field.1253 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 109, ptr %ctx.field.1253, align 4
  %status.diagnostic.1254 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1254, align 4
  ret void
continue.1252:
  %depth.exceeded.1255 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1255, label %failure.1256, label %continue.1257
failure.1256:
  %ctx.field.1258 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 110, ptr %ctx.field.1258, align 4
  %status.diagnostic.1259 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1259, align 4
  ret void
continue.1257:
  %workspace.slot.1260 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1246, ptr %workspace.slot.1260, align 8
  %workspace.slot.1261 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1262 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 208, ptr %outputs, i32 1, ptr %workspace.slot.1261)
  switch i32 %record.make.status.1262, label %runtime.invalid.result.1268 [ i32 0, label %runtime.success.1263 i32 1, label %runtime.invalid.request.1264 i32 2, label %runtime.invalid.reference.1265 i32 3, label %runtime.scratch.capacity.1266 i32 4, label %runtime.retained.capacity.1267 ]
runtime.invalid.request.1264:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1265:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1266:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1267:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1268:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1263:
  %record.make.handle.1269 = load i64, ptr %workspace.slot.1261, align 8
  %ctx.field.1270 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1271 = load i32, ptr %ctx.field.1270, align 4
  %steps.next.1272 = add i32 %steps.current.1271, 1
  store i32 %steps.next.1272, ptr %ctx.field.1270, align 4
  %steps.over.1273 = icmp ugt i32 %steps.next.1272, 10000
  br i1 %steps.over.1273, label %failure.1274, label %continue.1275
failure.1274:
  %ctx.field.1276 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 111, ptr %ctx.field.1276, align 4
  %status.diagnostic.1277 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1277, align 4
  ret void
continue.1275:
  %depth.exceeded.1278 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1278, label %failure.1279, label %continue.1280
failure.1279:
  %ctx.field.1281 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 112, ptr %ctx.field.1281, align 4
  %status.diagnostic.1282 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1282, align 4
  ret void
continue.1280:
  %workspace.slot.1283 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1269, ptr %workspace.slot.1283, align 8
  %workspace.slot.1284 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1285 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 209, ptr %outputs, i32 1, ptr %workspace.slot.1284)
  switch i32 %record.make.status.1285, label %runtime.invalid.result.1291 [ i32 0, label %runtime.success.1286 i32 1, label %runtime.invalid.request.1287 i32 2, label %runtime.invalid.reference.1288 i32 3, label %runtime.scratch.capacity.1289 i32 4, label %runtime.retained.capacity.1290 ]
runtime.invalid.request.1287:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1288:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1289:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1290:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1291:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1286:
  %record.make.handle.1292 = load i64, ptr %workspace.slot.1284, align 8
  %ctx.field.1293 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1294 = load i32, ptr %ctx.field.1293, align 4
  %steps.next.1295 = add i32 %steps.current.1294, 1
  store i32 %steps.next.1295, ptr %ctx.field.1293, align 4
  %steps.over.1296 = icmp ugt i32 %steps.next.1295, 10000
  br i1 %steps.over.1296, label %failure.1297, label %continue.1298
failure.1297:
  %ctx.field.1299 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 113, ptr %ctx.field.1299, align 4
  %status.diagnostic.1300 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1300, align 4
  ret void
continue.1298:
  %depth.exceeded.1301 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1301, label %failure.1302, label %continue.1303
failure.1302:
  %ctx.field.1304 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 114, ptr %ctx.field.1304, align 4
  %status.diagnostic.1305 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1305, align 4
  ret void
continue.1303:
  %workspace.slot.1306 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1292, ptr %workspace.slot.1306, align 8
  %workspace.slot.1307 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1308 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 210, ptr %outputs, i32 1, ptr %workspace.slot.1307)
  switch i32 %record.make.status.1308, label %runtime.invalid.result.1314 [ i32 0, label %runtime.success.1309 i32 1, label %runtime.invalid.request.1310 i32 2, label %runtime.invalid.reference.1311 i32 3, label %runtime.scratch.capacity.1312 i32 4, label %runtime.retained.capacity.1313 ]
runtime.invalid.request.1310:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1311:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1312:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1313:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1314:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1309:
  %record.make.handle.1315 = load i64, ptr %workspace.slot.1307, align 8
  %ctx.field.1316 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1317 = load i32, ptr %ctx.field.1316, align 4
  %steps.next.1318 = add i32 %steps.current.1317, 1
  store i32 %steps.next.1318, ptr %ctx.field.1316, align 4
  %steps.over.1319 = icmp ugt i32 %steps.next.1318, 10000
  br i1 %steps.over.1319, label %failure.1320, label %continue.1321
failure.1320:
  %ctx.field.1322 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 115, ptr %ctx.field.1322, align 4
  %status.diagnostic.1323 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1323, align 4
  ret void
continue.1321:
  %depth.exceeded.1324 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1324, label %failure.1325, label %continue.1326
failure.1325:
  %ctx.field.1327 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 116, ptr %ctx.field.1327, align 4
  %status.diagnostic.1328 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1328, align 4
  ret void
continue.1326:
  %workspace.slot.1329 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1315, ptr %workspace.slot.1329, align 8
  %workspace.slot.1330 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1331 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 211, ptr %outputs, i32 1, ptr %workspace.slot.1330)
  switch i32 %record.make.status.1331, label %runtime.invalid.result.1337 [ i32 0, label %runtime.success.1332 i32 1, label %runtime.invalid.request.1333 i32 2, label %runtime.invalid.reference.1334 i32 3, label %runtime.scratch.capacity.1335 i32 4, label %runtime.retained.capacity.1336 ]
runtime.invalid.request.1333:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1334:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1335:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1336:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1337:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1332:
  %record.make.handle.1338 = load i64, ptr %workspace.slot.1330, align 8
  %ctx.field.1339 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1340 = load i32, ptr %ctx.field.1339, align 4
  %steps.next.1341 = add i32 %steps.current.1340, 1
  store i32 %steps.next.1341, ptr %ctx.field.1339, align 4
  %steps.over.1342 = icmp ugt i32 %steps.next.1341, 10000
  br i1 %steps.over.1342, label %failure.1343, label %continue.1344
failure.1343:
  %ctx.field.1345 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 117, ptr %ctx.field.1345, align 4
  %status.diagnostic.1346 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1346, align 4
  ret void
continue.1344:
  %depth.exceeded.1347 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1347, label %failure.1348, label %continue.1349
failure.1348:
  %ctx.field.1350 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 118, ptr %ctx.field.1350, align 4
  %status.diagnostic.1351 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1351, align 4
  ret void
continue.1349:
  %workspace.slot.1352 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1338, ptr %workspace.slot.1352, align 8
  %workspace.slot.1353 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1354 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 212, ptr %outputs, i32 1, ptr %workspace.slot.1353)
  switch i32 %record.make.status.1354, label %runtime.invalid.result.1360 [ i32 0, label %runtime.success.1355 i32 1, label %runtime.invalid.request.1356 i32 2, label %runtime.invalid.reference.1357 i32 3, label %runtime.scratch.capacity.1358 i32 4, label %runtime.retained.capacity.1359 ]
runtime.invalid.request.1356:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1357:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1358:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1359:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1360:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1355:
  %record.make.handle.1361 = load i64, ptr %workspace.slot.1353, align 8
  %ctx.field.1362 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1363 = load i32, ptr %ctx.field.1362, align 4
  %steps.next.1364 = add i32 %steps.current.1363, 1
  store i32 %steps.next.1364, ptr %ctx.field.1362, align 4
  %steps.over.1365 = icmp ugt i32 %steps.next.1364, 10000
  br i1 %steps.over.1365, label %failure.1366, label %continue.1367
failure.1366:
  %ctx.field.1368 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 119, ptr %ctx.field.1368, align 4
  %status.diagnostic.1369 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1369, align 4
  ret void
continue.1367:
  %depth.exceeded.1370 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1370, label %failure.1371, label %continue.1372
failure.1371:
  %ctx.field.1373 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 120, ptr %ctx.field.1373, align 4
  %status.diagnostic.1374 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1374, align 4
  ret void
continue.1372:
  %workspace.slot.1375 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1361, ptr %workspace.slot.1375, align 8
  %workspace.slot.1376 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1377 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 213, ptr %outputs, i32 1, ptr %workspace.slot.1376)
  switch i32 %record.make.status.1377, label %runtime.invalid.result.1383 [ i32 0, label %runtime.success.1378 i32 1, label %runtime.invalid.request.1379 i32 2, label %runtime.invalid.reference.1380 i32 3, label %runtime.scratch.capacity.1381 i32 4, label %runtime.retained.capacity.1382 ]
runtime.invalid.request.1379:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1380:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1381:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1382:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1383:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1378:
  %record.make.handle.1384 = load i64, ptr %workspace.slot.1376, align 8
  %ctx.field.1385 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1386 = load i32, ptr %ctx.field.1385, align 4
  %steps.next.1387 = add i32 %steps.current.1386, 1
  store i32 %steps.next.1387, ptr %ctx.field.1385, align 4
  %steps.over.1388 = icmp ugt i32 %steps.next.1387, 10000
  br i1 %steps.over.1388, label %failure.1389, label %continue.1390
failure.1389:
  %ctx.field.1391 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 121, ptr %ctx.field.1391, align 4
  %status.diagnostic.1392 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1392, align 4
  ret void
continue.1390:
  %depth.exceeded.1393 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1393, label %failure.1394, label %continue.1395
failure.1394:
  %ctx.field.1396 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 122, ptr %ctx.field.1396, align 4
  %status.diagnostic.1397 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1397, align 4
  ret void
continue.1395:
  %workspace.slot.1398 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1384, ptr %workspace.slot.1398, align 8
  %workspace.slot.1399 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1400 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 214, ptr %outputs, i32 1, ptr %workspace.slot.1399)
  switch i32 %record.make.status.1400, label %runtime.invalid.result.1406 [ i32 0, label %runtime.success.1401 i32 1, label %runtime.invalid.request.1402 i32 2, label %runtime.invalid.reference.1403 i32 3, label %runtime.scratch.capacity.1404 i32 4, label %runtime.retained.capacity.1405 ]
runtime.invalid.request.1402:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1403:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1404:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1405:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1406:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1401:
  %record.make.handle.1407 = load i64, ptr %workspace.slot.1399, align 8
  %ctx.field.1408 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1409 = load i32, ptr %ctx.field.1408, align 4
  %steps.next.1410 = add i32 %steps.current.1409, 1
  store i32 %steps.next.1410, ptr %ctx.field.1408, align 4
  %steps.over.1411 = icmp ugt i32 %steps.next.1410, 10000
  br i1 %steps.over.1411, label %failure.1412, label %continue.1413
failure.1412:
  %ctx.field.1414 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 123, ptr %ctx.field.1414, align 4
  %status.diagnostic.1415 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1415, align 4
  ret void
continue.1413:
  %depth.exceeded.1416 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1416, label %failure.1417, label %continue.1418
failure.1417:
  %ctx.field.1419 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 124, ptr %ctx.field.1419, align 4
  %status.diagnostic.1420 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1420, align 4
  ret void
continue.1418:
  %workspace.slot.1421 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1407, ptr %workspace.slot.1421, align 8
  %workspace.slot.1422 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1423 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 216, ptr %outputs, i32 1, ptr %workspace.slot.1422)
  switch i32 %record.make.status.1423, label %runtime.invalid.result.1429 [ i32 0, label %runtime.success.1424 i32 1, label %runtime.invalid.request.1425 i32 2, label %runtime.invalid.reference.1426 i32 3, label %runtime.scratch.capacity.1427 i32 4, label %runtime.retained.capacity.1428 ]
runtime.invalid.request.1425:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1426:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1427:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1428:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1429:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1424:
  %record.make.handle.1430 = load i64, ptr %workspace.slot.1422, align 8
  %ctx.field.1431 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1432 = load i32, ptr %ctx.field.1431, align 4
  %steps.next.1433 = add i32 %steps.current.1432, 1
  store i32 %steps.next.1433, ptr %ctx.field.1431, align 4
  %steps.over.1434 = icmp ugt i32 %steps.next.1433, 10000
  br i1 %steps.over.1434, label %failure.1435, label %continue.1436
failure.1435:
  %ctx.field.1437 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 125, ptr %ctx.field.1437, align 4
  %status.diagnostic.1438 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1438, align 4
  ret void
continue.1436:
  %depth.exceeded.1439 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1439, label %failure.1440, label %continue.1441
failure.1440:
  %ctx.field.1442 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 126, ptr %ctx.field.1442, align 4
  %status.diagnostic.1443 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1443, align 4
  ret void
continue.1441:
  %workspace.slot.1444 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1430, ptr %workspace.slot.1444, align 8
  %workspace.slot.1445 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1446 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 217, ptr %outputs, i32 1, ptr %workspace.slot.1445)
  switch i32 %record.make.status.1446, label %runtime.invalid.result.1452 [ i32 0, label %runtime.success.1447 i32 1, label %runtime.invalid.request.1448 i32 2, label %runtime.invalid.reference.1449 i32 3, label %runtime.scratch.capacity.1450 i32 4, label %runtime.retained.capacity.1451 ]
runtime.invalid.request.1448:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1449:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1450:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1451:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1452:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1447:
  %record.make.handle.1453 = load i64, ptr %workspace.slot.1445, align 8
  %ctx.field.1454 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1455 = load i32, ptr %ctx.field.1454, align 4
  %steps.next.1456 = add i32 %steps.current.1455, 1
  store i32 %steps.next.1456, ptr %ctx.field.1454, align 4
  %steps.over.1457 = icmp ugt i32 %steps.next.1456, 10000
  br i1 %steps.over.1457, label %failure.1458, label %continue.1459
failure.1458:
  %ctx.field.1460 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 127, ptr %ctx.field.1460, align 4
  %status.diagnostic.1461 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1461, align 4
  ret void
continue.1459:
  %depth.exceeded.1462 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1462, label %failure.1463, label %continue.1464
failure.1463:
  %ctx.field.1465 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 128, ptr %ctx.field.1465, align 4
  %status.diagnostic.1466 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1466, align 4
  ret void
continue.1464:
  %workspace.slot.1467 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1453, ptr %workspace.slot.1467, align 8
  %workspace.slot.1468 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1469 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 218, ptr %outputs, i32 1, ptr %workspace.slot.1468)
  switch i32 %record.make.status.1469, label %runtime.invalid.result.1475 [ i32 0, label %runtime.success.1470 i32 1, label %runtime.invalid.request.1471 i32 2, label %runtime.invalid.reference.1472 i32 3, label %runtime.scratch.capacity.1473 i32 4, label %runtime.retained.capacity.1474 ]
runtime.invalid.request.1471:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1472:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1473:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1474:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1475:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1470:
  %record.make.handle.1476 = load i64, ptr %workspace.slot.1468, align 8
  %ctx.field.1477 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1478 = load i32, ptr %ctx.field.1477, align 4
  %steps.next.1479 = add i32 %steps.current.1478, 1
  store i32 %steps.next.1479, ptr %ctx.field.1477, align 4
  %steps.over.1480 = icmp ugt i32 %steps.next.1479, 10000
  br i1 %steps.over.1480, label %failure.1481, label %continue.1482
failure.1481:
  %ctx.field.1483 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 129, ptr %ctx.field.1483, align 4
  %status.diagnostic.1484 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1484, align 4
  ret void
continue.1482:
  %depth.exceeded.1485 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1485, label %failure.1486, label %continue.1487
failure.1486:
  %ctx.field.1488 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 130, ptr %ctx.field.1488, align 4
  %status.diagnostic.1489 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1489, align 4
  ret void
continue.1487:
  %workspace.slot.1490 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1476, ptr %workspace.slot.1490, align 8
  %workspace.slot.1491 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1492 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 219, ptr %outputs, i32 1, ptr %workspace.slot.1491)
  switch i32 %record.make.status.1492, label %runtime.invalid.result.1498 [ i32 0, label %runtime.success.1493 i32 1, label %runtime.invalid.request.1494 i32 2, label %runtime.invalid.reference.1495 i32 3, label %runtime.scratch.capacity.1496 i32 4, label %runtime.retained.capacity.1497 ]
runtime.invalid.request.1494:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1495:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1496:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1497:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1498:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1493:
  %record.make.handle.1499 = load i64, ptr %workspace.slot.1491, align 8
  %ctx.field.1500 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1501 = load i32, ptr %ctx.field.1500, align 4
  %steps.next.1502 = add i32 %steps.current.1501, 1
  store i32 %steps.next.1502, ptr %ctx.field.1500, align 4
  %steps.over.1503 = icmp ugt i32 %steps.next.1502, 10000
  br i1 %steps.over.1503, label %failure.1504, label %continue.1505
failure.1504:
  %ctx.field.1506 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 131, ptr %ctx.field.1506, align 4
  %status.diagnostic.1507 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1507, align 4
  ret void
continue.1505:
  %depth.exceeded.1508 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1508, label %failure.1509, label %continue.1510
failure.1509:
  %ctx.field.1511 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 132, ptr %ctx.field.1511, align 4
  %status.diagnostic.1512 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1512, align 4
  ret void
continue.1510:
  %workspace.slot.1513 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1499, ptr %workspace.slot.1513, align 8
  %workspace.slot.1514 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1515 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 220, ptr %outputs, i32 1, ptr %workspace.slot.1514)
  switch i32 %record.make.status.1515, label %runtime.invalid.result.1521 [ i32 0, label %runtime.success.1516 i32 1, label %runtime.invalid.request.1517 i32 2, label %runtime.invalid.reference.1518 i32 3, label %runtime.scratch.capacity.1519 i32 4, label %runtime.retained.capacity.1520 ]
runtime.invalid.request.1517:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1518:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1519:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1520:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1521:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1516:
  %record.make.handle.1522 = load i64, ptr %workspace.slot.1514, align 8
  %ctx.field.1523 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1524 = load i32, ptr %ctx.field.1523, align 4
  %steps.next.1525 = add i32 %steps.current.1524, 1
  store i32 %steps.next.1525, ptr %ctx.field.1523, align 4
  %steps.over.1526 = icmp ugt i32 %steps.next.1525, 10000
  br i1 %steps.over.1526, label %failure.1527, label %continue.1528
failure.1527:
  %ctx.field.1529 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 133, ptr %ctx.field.1529, align 4
  %status.diagnostic.1530 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1530, align 4
  ret void
continue.1528:
  %depth.exceeded.1531 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1531, label %failure.1532, label %continue.1533
failure.1532:
  %ctx.field.1534 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 134, ptr %ctx.field.1534, align 4
  %status.diagnostic.1535 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1535, align 4
  ret void
continue.1533:
  %workspace.slot.1536 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1522, ptr %workspace.slot.1536, align 8
  %workspace.slot.1537 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1538 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 221, ptr %outputs, i32 1, ptr %workspace.slot.1537)
  switch i32 %record.make.status.1538, label %runtime.invalid.result.1544 [ i32 0, label %runtime.success.1539 i32 1, label %runtime.invalid.request.1540 i32 2, label %runtime.invalid.reference.1541 i32 3, label %runtime.scratch.capacity.1542 i32 4, label %runtime.retained.capacity.1543 ]
runtime.invalid.request.1540:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1541:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1542:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1543:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1544:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1539:
  %record.make.handle.1545 = load i64, ptr %workspace.slot.1537, align 8
  %ctx.field.1546 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1547 = load i32, ptr %ctx.field.1546, align 4
  %steps.next.1548 = add i32 %steps.current.1547, 1
  store i32 %steps.next.1548, ptr %ctx.field.1546, align 4
  %steps.over.1549 = icmp ugt i32 %steps.next.1548, 10000
  br i1 %steps.over.1549, label %failure.1550, label %continue.1551
failure.1550:
  %ctx.field.1552 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 135, ptr %ctx.field.1552, align 4
  %status.diagnostic.1553 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1553, align 4
  ret void
continue.1551:
  %depth.exceeded.1554 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1554, label %failure.1555, label %continue.1556
failure.1555:
  %ctx.field.1557 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 136, ptr %ctx.field.1557, align 4
  %status.diagnostic.1558 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1558, align 4
  ret void
continue.1556:
  %workspace.slot.1559 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1545, ptr %workspace.slot.1559, align 8
  %workspace.slot.1560 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1561 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 222, ptr %outputs, i32 1, ptr %workspace.slot.1560)
  switch i32 %record.make.status.1561, label %runtime.invalid.result.1567 [ i32 0, label %runtime.success.1562 i32 1, label %runtime.invalid.request.1563 i32 2, label %runtime.invalid.reference.1564 i32 3, label %runtime.scratch.capacity.1565 i32 4, label %runtime.retained.capacity.1566 ]
runtime.invalid.request.1563:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1564:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1565:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1566:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1567:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1562:
  %record.make.handle.1568 = load i64, ptr %workspace.slot.1560, align 8
  %ctx.field.1569 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1570 = load i32, ptr %ctx.field.1569, align 4
  %steps.next.1571 = add i32 %steps.current.1570, 1
  store i32 %steps.next.1571, ptr %ctx.field.1569, align 4
  %steps.over.1572 = icmp ugt i32 %steps.next.1571, 10000
  br i1 %steps.over.1572, label %failure.1573, label %continue.1574
failure.1573:
  %ctx.field.1575 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 137, ptr %ctx.field.1575, align 4
  %status.diagnostic.1576 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1576, align 4
  ret void
continue.1574:
  %depth.exceeded.1577 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1577, label %failure.1578, label %continue.1579
failure.1578:
  %ctx.field.1580 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 138, ptr %ctx.field.1580, align 4
  %status.diagnostic.1581 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1581, align 4
  ret void
continue.1579:
  %workspace.slot.1582 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1568, ptr %workspace.slot.1582, align 8
  %workspace.slot.1583 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1584 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 223, ptr %outputs, i32 1, ptr %workspace.slot.1583)
  switch i32 %record.make.status.1584, label %runtime.invalid.result.1590 [ i32 0, label %runtime.success.1585 i32 1, label %runtime.invalid.request.1586 i32 2, label %runtime.invalid.reference.1587 i32 3, label %runtime.scratch.capacity.1588 i32 4, label %runtime.retained.capacity.1589 ]
runtime.invalid.request.1586:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1587:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1588:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1589:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1590:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1585:
  %record.make.handle.1591 = load i64, ptr %workspace.slot.1583, align 8
  %ctx.field.1592 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1593 = load i32, ptr %ctx.field.1592, align 4
  %steps.next.1594 = add i32 %steps.current.1593, 1
  store i32 %steps.next.1594, ptr %ctx.field.1592, align 4
  %steps.over.1595 = icmp ugt i32 %steps.next.1594, 10000
  br i1 %steps.over.1595, label %failure.1596, label %continue.1597
failure.1596:
  %ctx.field.1598 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 139, ptr %ctx.field.1598, align 4
  %status.diagnostic.1599 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1599, align 4
  ret void
continue.1597:
  %depth.exceeded.1600 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1600, label %failure.1601, label %continue.1602
failure.1601:
  %ctx.field.1603 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 140, ptr %ctx.field.1603, align 4
  %status.diagnostic.1604 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1604, align 4
  ret void
continue.1602:
  %workspace.slot.1605 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1591, ptr %workspace.slot.1605, align 8
  %workspace.slot.1606 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1607 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 224, ptr %outputs, i32 1, ptr %workspace.slot.1606)
  switch i32 %record.make.status.1607, label %runtime.invalid.result.1613 [ i32 0, label %runtime.success.1608 i32 1, label %runtime.invalid.request.1609 i32 2, label %runtime.invalid.reference.1610 i32 3, label %runtime.scratch.capacity.1611 i32 4, label %runtime.retained.capacity.1612 ]
runtime.invalid.request.1609:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1610:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1611:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1612:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1613:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1608:
  %record.make.handle.1614 = load i64, ptr %workspace.slot.1606, align 8
  %ctx.field.1615 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1616 = load i32, ptr %ctx.field.1615, align 4
  %steps.next.1617 = add i32 %steps.current.1616, 1
  store i32 %steps.next.1617, ptr %ctx.field.1615, align 4
  %steps.over.1618 = icmp ugt i32 %steps.next.1617, 10000
  br i1 %steps.over.1618, label %failure.1619, label %continue.1620
failure.1619:
  %ctx.field.1621 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 141, ptr %ctx.field.1621, align 4
  %status.diagnostic.1622 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1622, align 4
  ret void
continue.1620:
  %depth.exceeded.1623 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1623, label %failure.1624, label %continue.1625
failure.1624:
  %ctx.field.1626 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 142, ptr %ctx.field.1626, align 4
  %status.diagnostic.1627 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1627, align 4
  ret void
continue.1625:
  %workspace.slot.1628 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1614, ptr %workspace.slot.1628, align 8
  %workspace.slot.1629 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1630 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 225, ptr %outputs, i32 1, ptr %workspace.slot.1629)
  switch i32 %record.make.status.1630, label %runtime.invalid.result.1636 [ i32 0, label %runtime.success.1631 i32 1, label %runtime.invalid.request.1632 i32 2, label %runtime.invalid.reference.1633 i32 3, label %runtime.scratch.capacity.1634 i32 4, label %runtime.retained.capacity.1635 ]
runtime.invalid.request.1632:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1633:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1634:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1635:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1636:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1631:
  %record.make.handle.1637 = load i64, ptr %workspace.slot.1629, align 8
  %ctx.field.1638 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1639 = load i32, ptr %ctx.field.1638, align 4
  %steps.next.1640 = add i32 %steps.current.1639, 1
  store i32 %steps.next.1640, ptr %ctx.field.1638, align 4
  %steps.over.1641 = icmp ugt i32 %steps.next.1640, 10000
  br i1 %steps.over.1641, label %failure.1642, label %continue.1643
failure.1642:
  %ctx.field.1644 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 143, ptr %ctx.field.1644, align 4
  %status.diagnostic.1645 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1645, align 4
  ret void
continue.1643:
  %depth.exceeded.1646 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1646, label %failure.1647, label %continue.1648
failure.1647:
  %ctx.field.1649 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 144, ptr %ctx.field.1649, align 4
  %status.diagnostic.1650 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1650, align 4
  ret void
continue.1648:
  %workspace.slot.1651 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1637, ptr %workspace.slot.1651, align 8
  %workspace.slot.1652 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1653 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 227, ptr %outputs, i32 1, ptr %workspace.slot.1652)
  switch i32 %record.make.status.1653, label %runtime.invalid.result.1659 [ i32 0, label %runtime.success.1654 i32 1, label %runtime.invalid.request.1655 i32 2, label %runtime.invalid.reference.1656 i32 3, label %runtime.scratch.capacity.1657 i32 4, label %runtime.retained.capacity.1658 ]
runtime.invalid.request.1655:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1656:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1657:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1658:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1659:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1654:
  %record.make.handle.1660 = load i64, ptr %workspace.slot.1652, align 8
  %ctx.field.1661 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1662 = load i32, ptr %ctx.field.1661, align 4
  %steps.next.1663 = add i32 %steps.current.1662, 1
  store i32 %steps.next.1663, ptr %ctx.field.1661, align 4
  %steps.over.1664 = icmp ugt i32 %steps.next.1663, 10000
  br i1 %steps.over.1664, label %failure.1665, label %continue.1666
failure.1665:
  %ctx.field.1667 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 145, ptr %ctx.field.1667, align 4
  %status.diagnostic.1668 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1668, align 4
  ret void
continue.1666:
  %depth.exceeded.1669 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1669, label %failure.1670, label %continue.1671
failure.1670:
  %ctx.field.1672 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 146, ptr %ctx.field.1672, align 4
  %status.diagnostic.1673 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1673, align 4
  ret void
continue.1671:
  %workspace.slot.1674 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1660, ptr %workspace.slot.1674, align 8
  %workspace.slot.1675 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1676 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 228, ptr %outputs, i32 1, ptr %workspace.slot.1675)
  switch i32 %record.make.status.1676, label %runtime.invalid.result.1682 [ i32 0, label %runtime.success.1677 i32 1, label %runtime.invalid.request.1678 i32 2, label %runtime.invalid.reference.1679 i32 3, label %runtime.scratch.capacity.1680 i32 4, label %runtime.retained.capacity.1681 ]
runtime.invalid.request.1678:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1679:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1680:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1681:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1682:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1677:
  %record.make.handle.1683 = load i64, ptr %workspace.slot.1675, align 8
  %ctx.field.1684 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1685 = load i32, ptr %ctx.field.1684, align 4
  %steps.next.1686 = add i32 %steps.current.1685, 1
  store i32 %steps.next.1686, ptr %ctx.field.1684, align 4
  %steps.over.1687 = icmp ugt i32 %steps.next.1686, 10000
  br i1 %steps.over.1687, label %failure.1688, label %continue.1689
failure.1688:
  %ctx.field.1690 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 147, ptr %ctx.field.1690, align 4
  %status.diagnostic.1691 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1691, align 4
  ret void
continue.1689:
  %depth.exceeded.1692 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1692, label %failure.1693, label %continue.1694
failure.1693:
  %ctx.field.1695 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 148, ptr %ctx.field.1695, align 4
  %status.diagnostic.1696 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1696, align 4
  ret void
continue.1694:
  %workspace.slot.1697 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1683, ptr %workspace.slot.1697, align 8
  %workspace.slot.1698 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1699 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 229, ptr %outputs, i32 1, ptr %workspace.slot.1698)
  switch i32 %record.make.status.1699, label %runtime.invalid.result.1705 [ i32 0, label %runtime.success.1700 i32 1, label %runtime.invalid.request.1701 i32 2, label %runtime.invalid.reference.1702 i32 3, label %runtime.scratch.capacity.1703 i32 4, label %runtime.retained.capacity.1704 ]
runtime.invalid.request.1701:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1702:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1703:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1704:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1705:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1700:
  %record.make.handle.1706 = load i64, ptr %workspace.slot.1698, align 8
  %ctx.field.1707 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1708 = load i32, ptr %ctx.field.1707, align 4
  %steps.next.1709 = add i32 %steps.current.1708, 1
  store i32 %steps.next.1709, ptr %ctx.field.1707, align 4
  %steps.over.1710 = icmp ugt i32 %steps.next.1709, 10000
  br i1 %steps.over.1710, label %failure.1711, label %continue.1712
failure.1711:
  %ctx.field.1713 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 149, ptr %ctx.field.1713, align 4
  %status.diagnostic.1714 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1714, align 4
  ret void
continue.1712:
  %depth.exceeded.1715 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1715, label %failure.1716, label %continue.1717
failure.1716:
  %ctx.field.1718 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 150, ptr %ctx.field.1718, align 4
  %status.diagnostic.1719 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1719, align 4
  ret void
continue.1717:
  %workspace.slot.1720 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1706, ptr %workspace.slot.1720, align 8
  %workspace.slot.1721 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1722 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 230, ptr %outputs, i32 1, ptr %workspace.slot.1721)
  switch i32 %record.make.status.1722, label %runtime.invalid.result.1728 [ i32 0, label %runtime.success.1723 i32 1, label %runtime.invalid.request.1724 i32 2, label %runtime.invalid.reference.1725 i32 3, label %runtime.scratch.capacity.1726 i32 4, label %runtime.retained.capacity.1727 ]
runtime.invalid.request.1724:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1725:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1726:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1727:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1728:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1723:
  %record.make.handle.1729 = load i64, ptr %workspace.slot.1721, align 8
  %ctx.field.1730 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1731 = load i32, ptr %ctx.field.1730, align 4
  %steps.next.1732 = add i32 %steps.current.1731, 1
  store i32 %steps.next.1732, ptr %ctx.field.1730, align 4
  %steps.over.1733 = icmp ugt i32 %steps.next.1732, 10000
  br i1 %steps.over.1733, label %failure.1734, label %continue.1735
failure.1734:
  %ctx.field.1736 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 151, ptr %ctx.field.1736, align 4
  %status.diagnostic.1737 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1737, align 4
  ret void
continue.1735:
  %depth.exceeded.1738 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1738, label %failure.1739, label %continue.1740
failure.1739:
  %ctx.field.1741 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 152, ptr %ctx.field.1741, align 4
  %status.diagnostic.1742 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1742, align 4
  ret void
continue.1740:
  %workspace.slot.1743 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1729, ptr %workspace.slot.1743, align 8
  %workspace.slot.1744 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1745 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 231, ptr %outputs, i32 1, ptr %workspace.slot.1744)
  switch i32 %record.make.status.1745, label %runtime.invalid.result.1751 [ i32 0, label %runtime.success.1746 i32 1, label %runtime.invalid.request.1747 i32 2, label %runtime.invalid.reference.1748 i32 3, label %runtime.scratch.capacity.1749 i32 4, label %runtime.retained.capacity.1750 ]
runtime.invalid.request.1747:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1748:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1749:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1750:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1751:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1746:
  %record.make.handle.1752 = load i64, ptr %workspace.slot.1744, align 8
  %ctx.field.1753 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1754 = load i32, ptr %ctx.field.1753, align 4
  %steps.next.1755 = add i32 %steps.current.1754, 1
  store i32 %steps.next.1755, ptr %ctx.field.1753, align 4
  %steps.over.1756 = icmp ugt i32 %steps.next.1755, 10000
  br i1 %steps.over.1756, label %failure.1757, label %continue.1758
failure.1757:
  %ctx.field.1759 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 153, ptr %ctx.field.1759, align 4
  %status.diagnostic.1760 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1760, align 4
  ret void
continue.1758:
  %depth.exceeded.1761 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1761, label %failure.1762, label %continue.1763
failure.1762:
  %ctx.field.1764 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 154, ptr %ctx.field.1764, align 4
  %status.diagnostic.1765 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1765, align 4
  ret void
continue.1763:
  %workspace.slot.1766 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1752, ptr %workspace.slot.1766, align 8
  %workspace.slot.1767 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1768 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 232, ptr %outputs, i32 1, ptr %workspace.slot.1767)
  switch i32 %record.make.status.1768, label %runtime.invalid.result.1774 [ i32 0, label %runtime.success.1769 i32 1, label %runtime.invalid.request.1770 i32 2, label %runtime.invalid.reference.1771 i32 3, label %runtime.scratch.capacity.1772 i32 4, label %runtime.retained.capacity.1773 ]
runtime.invalid.request.1770:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1771:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1772:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1773:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1774:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1769:
  %record.make.handle.1775 = load i64, ptr %workspace.slot.1767, align 8
  %ctx.field.1776 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1777 = load i32, ptr %ctx.field.1776, align 4
  %steps.next.1778 = add i32 %steps.current.1777, 1
  store i32 %steps.next.1778, ptr %ctx.field.1776, align 4
  %steps.over.1779 = icmp ugt i32 %steps.next.1778, 10000
  br i1 %steps.over.1779, label %failure.1780, label %continue.1781
failure.1780:
  %ctx.field.1782 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 155, ptr %ctx.field.1782, align 4
  %status.diagnostic.1783 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1783, align 4
  ret void
continue.1781:
  %depth.exceeded.1784 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1784, label %failure.1785, label %continue.1786
failure.1785:
  %ctx.field.1787 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 156, ptr %ctx.field.1787, align 4
  %status.diagnostic.1788 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1788, align 4
  ret void
continue.1786:
  %workspace.slot.1789 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1775, ptr %workspace.slot.1789, align 8
  %workspace.slot.1790 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1791 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 233, ptr %outputs, i32 1, ptr %workspace.slot.1790)
  switch i32 %record.make.status.1791, label %runtime.invalid.result.1797 [ i32 0, label %runtime.success.1792 i32 1, label %runtime.invalid.request.1793 i32 2, label %runtime.invalid.reference.1794 i32 3, label %runtime.scratch.capacity.1795 i32 4, label %runtime.retained.capacity.1796 ]
runtime.invalid.request.1793:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1794:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1795:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1796:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1797:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1792:
  %record.make.handle.1798 = load i64, ptr %workspace.slot.1790, align 8
  %ctx.field.1799 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1800 = load i32, ptr %ctx.field.1799, align 4
  %steps.next.1801 = add i32 %steps.current.1800, 1
  store i32 %steps.next.1801, ptr %ctx.field.1799, align 4
  %steps.over.1802 = icmp ugt i32 %steps.next.1801, 10000
  br i1 %steps.over.1802, label %failure.1803, label %continue.1804
failure.1803:
  %ctx.field.1805 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 157, ptr %ctx.field.1805, align 4
  %status.diagnostic.1806 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1806, align 4
  ret void
continue.1804:
  %depth.exceeded.1807 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1807, label %failure.1808, label %continue.1809
failure.1808:
  %ctx.field.1810 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 158, ptr %ctx.field.1810, align 4
  %status.diagnostic.1811 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1811, align 4
  ret void
continue.1809:
  %workspace.slot.1812 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1798, ptr %workspace.slot.1812, align 8
  %workspace.slot.1813 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1814 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 234, ptr %outputs, i32 1, ptr %workspace.slot.1813)
  switch i32 %record.make.status.1814, label %runtime.invalid.result.1820 [ i32 0, label %runtime.success.1815 i32 1, label %runtime.invalid.request.1816 i32 2, label %runtime.invalid.reference.1817 i32 3, label %runtime.scratch.capacity.1818 i32 4, label %runtime.retained.capacity.1819 ]
runtime.invalid.request.1816:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1817:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1818:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1819:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1820:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1815:
  %record.make.handle.1821 = load i64, ptr %workspace.slot.1813, align 8
  %ctx.field.1822 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1823 = load i32, ptr %ctx.field.1822, align 4
  %steps.next.1824 = add i32 %steps.current.1823, 1
  store i32 %steps.next.1824, ptr %ctx.field.1822, align 4
  %steps.over.1825 = icmp ugt i32 %steps.next.1824, 10000
  br i1 %steps.over.1825, label %failure.1826, label %continue.1827
failure.1826:
  %ctx.field.1828 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 159, ptr %ctx.field.1828, align 4
  %status.diagnostic.1829 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1829, align 4
  ret void
continue.1827:
  %depth.exceeded.1830 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1830, label %failure.1831, label %continue.1832
failure.1831:
  %ctx.field.1833 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 160, ptr %ctx.field.1833, align 4
  %status.diagnostic.1834 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1834, align 4
  ret void
continue.1832:
  %workspace.slot.1835 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1821, ptr %workspace.slot.1835, align 8
  %workspace.slot.1836 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1837 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 235, ptr %outputs, i32 1, ptr %workspace.slot.1836)
  switch i32 %record.make.status.1837, label %runtime.invalid.result.1843 [ i32 0, label %runtime.success.1838 i32 1, label %runtime.invalid.request.1839 i32 2, label %runtime.invalid.reference.1840 i32 3, label %runtime.scratch.capacity.1841 i32 4, label %runtime.retained.capacity.1842 ]
runtime.invalid.request.1839:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1840:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1841:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1842:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1843:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1838:
  %record.make.handle.1844 = load i64, ptr %workspace.slot.1836, align 8
  %ctx.field.1845 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1846 = load i32, ptr %ctx.field.1845, align 4
  %steps.next.1847 = add i32 %steps.current.1846, 1
  store i32 %steps.next.1847, ptr %ctx.field.1845, align 4
  %steps.over.1848 = icmp ugt i32 %steps.next.1847, 10000
  br i1 %steps.over.1848, label %failure.1849, label %continue.1850
failure.1849:
  %ctx.field.1851 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 161, ptr %ctx.field.1851, align 4
  %status.diagnostic.1852 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1852, align 4
  ret void
continue.1850:
  %depth.exceeded.1853 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1853, label %failure.1854, label %continue.1855
failure.1854:
  %ctx.field.1856 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 162, ptr %ctx.field.1856, align 4
  %status.diagnostic.1857 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1857, align 4
  ret void
continue.1855:
  %workspace.slot.1858 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1844, ptr %workspace.slot.1858, align 8
  %workspace.slot.1859 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1860 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 236, ptr %outputs, i32 1, ptr %workspace.slot.1859)
  switch i32 %record.make.status.1860, label %runtime.invalid.result.1866 [ i32 0, label %runtime.success.1861 i32 1, label %runtime.invalid.request.1862 i32 2, label %runtime.invalid.reference.1863 i32 3, label %runtime.scratch.capacity.1864 i32 4, label %runtime.retained.capacity.1865 ]
runtime.invalid.request.1862:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1863:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1864:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1865:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1866:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1861:
  %record.make.handle.1867 = load i64, ptr %workspace.slot.1859, align 8
  %ctx.field.1868 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1869 = load i32, ptr %ctx.field.1868, align 4
  %steps.next.1870 = add i32 %steps.current.1869, 1
  store i32 %steps.next.1870, ptr %ctx.field.1868, align 4
  %steps.over.1871 = icmp ugt i32 %steps.next.1870, 10000
  br i1 %steps.over.1871, label %failure.1872, label %continue.1873
failure.1872:
  %ctx.field.1874 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 163, ptr %ctx.field.1874, align 4
  %status.diagnostic.1875 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1875, align 4
  ret void
continue.1873:
  %depth.exceeded.1876 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1876, label %failure.1877, label %continue.1878
failure.1877:
  %ctx.field.1879 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 164, ptr %ctx.field.1879, align 4
  %status.diagnostic.1880 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1880, align 4
  ret void
continue.1878:
  %workspace.slot.1881 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1867, ptr %workspace.slot.1881, align 8
  %workspace.slot.1882 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1883 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 238, ptr %outputs, i32 1, ptr %workspace.slot.1882)
  switch i32 %record.make.status.1883, label %runtime.invalid.result.1889 [ i32 0, label %runtime.success.1884 i32 1, label %runtime.invalid.request.1885 i32 2, label %runtime.invalid.reference.1886 i32 3, label %runtime.scratch.capacity.1887 i32 4, label %runtime.retained.capacity.1888 ]
runtime.invalid.request.1885:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1886:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1887:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1888:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1889:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1884:
  %record.make.handle.1890 = load i64, ptr %workspace.slot.1882, align 8
  %ctx.field.1891 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1892 = load i32, ptr %ctx.field.1891, align 4
  %steps.next.1893 = add i32 %steps.current.1892, 1
  store i32 %steps.next.1893, ptr %ctx.field.1891, align 4
  %steps.over.1894 = icmp ugt i32 %steps.next.1893, 10000
  br i1 %steps.over.1894, label %failure.1895, label %continue.1896
failure.1895:
  %ctx.field.1897 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 165, ptr %ctx.field.1897, align 4
  %status.diagnostic.1898 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1898, align 4
  ret void
continue.1896:
  %depth.exceeded.1899 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1899, label %failure.1900, label %continue.1901
failure.1900:
  %ctx.field.1902 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 166, ptr %ctx.field.1902, align 4
  %status.diagnostic.1903 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1903, align 4
  ret void
continue.1901:
  %workspace.slot.1904 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1890, ptr %workspace.slot.1904, align 8
  %workspace.slot.1905 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1906 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 239, ptr %outputs, i32 1, ptr %workspace.slot.1905)
  switch i32 %record.make.status.1906, label %runtime.invalid.result.1912 [ i32 0, label %runtime.success.1907 i32 1, label %runtime.invalid.request.1908 i32 2, label %runtime.invalid.reference.1909 i32 3, label %runtime.scratch.capacity.1910 i32 4, label %runtime.retained.capacity.1911 ]
runtime.invalid.request.1908:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1909:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1910:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1911:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1912:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1907:
  %record.make.handle.1913 = load i64, ptr %workspace.slot.1905, align 8
  %ctx.field.1914 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1915 = load i32, ptr %ctx.field.1914, align 4
  %steps.next.1916 = add i32 %steps.current.1915, 1
  store i32 %steps.next.1916, ptr %ctx.field.1914, align 4
  %steps.over.1917 = icmp ugt i32 %steps.next.1916, 10000
  br i1 %steps.over.1917, label %failure.1918, label %continue.1919
failure.1918:
  %ctx.field.1920 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 167, ptr %ctx.field.1920, align 4
  %status.diagnostic.1921 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1921, align 4
  ret void
continue.1919:
  %depth.exceeded.1922 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1922, label %failure.1923, label %continue.1924
failure.1923:
  %ctx.field.1925 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 168, ptr %ctx.field.1925, align 4
  %status.diagnostic.1926 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1926, align 4
  ret void
continue.1924:
  %workspace.slot.1927 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1913, ptr %workspace.slot.1927, align 8
  %workspace.slot.1928 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1929 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 240, ptr %outputs, i32 1, ptr %workspace.slot.1928)
  switch i32 %record.make.status.1929, label %runtime.invalid.result.1935 [ i32 0, label %runtime.success.1930 i32 1, label %runtime.invalid.request.1931 i32 2, label %runtime.invalid.reference.1932 i32 3, label %runtime.scratch.capacity.1933 i32 4, label %runtime.retained.capacity.1934 ]
runtime.invalid.request.1931:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1932:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1933:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1934:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1935:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1930:
  %record.make.handle.1936 = load i64, ptr %workspace.slot.1928, align 8
  %ctx.field.1937 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1938 = load i32, ptr %ctx.field.1937, align 4
  %steps.next.1939 = add i32 %steps.current.1938, 1
  store i32 %steps.next.1939, ptr %ctx.field.1937, align 4
  %steps.over.1940 = icmp ugt i32 %steps.next.1939, 10000
  br i1 %steps.over.1940, label %failure.1941, label %continue.1942
failure.1941:
  %ctx.field.1943 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 169, ptr %ctx.field.1943, align 4
  %status.diagnostic.1944 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1944, align 4
  ret void
continue.1942:
  %depth.exceeded.1945 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1945, label %failure.1946, label %continue.1947
failure.1946:
  %ctx.field.1948 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 170, ptr %ctx.field.1948, align 4
  %status.diagnostic.1949 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1949, align 4
  ret void
continue.1947:
  %workspace.slot.1950 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1936, ptr %workspace.slot.1950, align 8
  %workspace.slot.1951 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1952 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 241, ptr %outputs, i32 1, ptr %workspace.slot.1951)
  switch i32 %record.make.status.1952, label %runtime.invalid.result.1958 [ i32 0, label %runtime.success.1953 i32 1, label %runtime.invalid.request.1954 i32 2, label %runtime.invalid.reference.1955 i32 3, label %runtime.scratch.capacity.1956 i32 4, label %runtime.retained.capacity.1957 ]
runtime.invalid.request.1954:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1955:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1956:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1957:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1958:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1953:
  %record.make.handle.1959 = load i64, ptr %workspace.slot.1951, align 8
  %ctx.field.1960 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1961 = load i32, ptr %ctx.field.1960, align 4
  %steps.next.1962 = add i32 %steps.current.1961, 1
  store i32 %steps.next.1962, ptr %ctx.field.1960, align 4
  %steps.over.1963 = icmp ugt i32 %steps.next.1962, 10000
  br i1 %steps.over.1963, label %failure.1964, label %continue.1965
failure.1964:
  %ctx.field.1966 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 171, ptr %ctx.field.1966, align 4
  %status.diagnostic.1967 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1967, align 4
  ret void
continue.1965:
  %depth.exceeded.1968 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1968, label %failure.1969, label %continue.1970
failure.1969:
  %ctx.field.1971 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 172, ptr %ctx.field.1971, align 4
  %status.diagnostic.1972 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1972, align 4
  ret void
continue.1970:
  %workspace.slot.1973 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1959, ptr %workspace.slot.1973, align 8
  %workspace.slot.1974 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1975 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 242, ptr %outputs, i32 1, ptr %workspace.slot.1974)
  switch i32 %record.make.status.1975, label %runtime.invalid.result.1981 [ i32 0, label %runtime.success.1976 i32 1, label %runtime.invalid.request.1977 i32 2, label %runtime.invalid.reference.1978 i32 3, label %runtime.scratch.capacity.1979 i32 4, label %runtime.retained.capacity.1980 ]
runtime.invalid.request.1977:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.1978:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.1979:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.1980:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.1981:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1976:
  %record.make.handle.1982 = load i64, ptr %workspace.slot.1974, align 8
  %ctx.field.1983 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1984 = load i32, ptr %ctx.field.1983, align 4
  %steps.next.1985 = add i32 %steps.current.1984, 1
  store i32 %steps.next.1985, ptr %ctx.field.1983, align 4
  %steps.over.1986 = icmp ugt i32 %steps.next.1985, 10000
  br i1 %steps.over.1986, label %failure.1987, label %continue.1988
failure.1987:
  %ctx.field.1989 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 173, ptr %ctx.field.1989, align 4
  %status.diagnostic.1990 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1990, align 4
  ret void
continue.1988:
  %depth.exceeded.1991 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.1991, label %failure.1992, label %continue.1993
failure.1992:
  %ctx.field.1994 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 174, ptr %ctx.field.1994, align 4
  %status.diagnostic.1995 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.1995, align 4
  ret void
continue.1993:
  %workspace.slot.1996 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.1982, ptr %workspace.slot.1996, align 8
  %workspace.slot.1997 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.1998 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 243, ptr %outputs, i32 1, ptr %workspace.slot.1997)
  switch i32 %record.make.status.1998, label %runtime.invalid.result.2004 [ i32 0, label %runtime.success.1999 i32 1, label %runtime.invalid.request.2000 i32 2, label %runtime.invalid.reference.2001 i32 3, label %runtime.scratch.capacity.2002 i32 4, label %runtime.retained.capacity.2003 ]
runtime.invalid.request.2000:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2001:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2002:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2003:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2004:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.1999:
  %record.make.handle.2005 = load i64, ptr %workspace.slot.1997, align 8
  %ctx.field.2006 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2007 = load i32, ptr %ctx.field.2006, align 4
  %steps.next.2008 = add i32 %steps.current.2007, 1
  store i32 %steps.next.2008, ptr %ctx.field.2006, align 4
  %steps.over.2009 = icmp ugt i32 %steps.next.2008, 10000
  br i1 %steps.over.2009, label %failure.2010, label %continue.2011
failure.2010:
  %ctx.field.2012 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 175, ptr %ctx.field.2012, align 4
  %status.diagnostic.2013 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2013, align 4
  ret void
continue.2011:
  %depth.exceeded.2014 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2014, label %failure.2015, label %continue.2016
failure.2015:
  %ctx.field.2017 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 176, ptr %ctx.field.2017, align 4
  %status.diagnostic.2018 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2018, align 4
  ret void
continue.2016:
  %workspace.slot.2019 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2005, ptr %workspace.slot.2019, align 8
  %workspace.slot.2020 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2021 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 244, ptr %outputs, i32 1, ptr %workspace.slot.2020)
  switch i32 %record.make.status.2021, label %runtime.invalid.result.2027 [ i32 0, label %runtime.success.2022 i32 1, label %runtime.invalid.request.2023 i32 2, label %runtime.invalid.reference.2024 i32 3, label %runtime.scratch.capacity.2025 i32 4, label %runtime.retained.capacity.2026 ]
runtime.invalid.request.2023:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2024:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2025:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2026:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2027:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2022:
  %record.make.handle.2028 = load i64, ptr %workspace.slot.2020, align 8
  %ctx.field.2029 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2030 = load i32, ptr %ctx.field.2029, align 4
  %steps.next.2031 = add i32 %steps.current.2030, 1
  store i32 %steps.next.2031, ptr %ctx.field.2029, align 4
  %steps.over.2032 = icmp ugt i32 %steps.next.2031, 10000
  br i1 %steps.over.2032, label %failure.2033, label %continue.2034
failure.2033:
  %ctx.field.2035 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 177, ptr %ctx.field.2035, align 4
  %status.diagnostic.2036 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2036, align 4
  ret void
continue.2034:
  %depth.exceeded.2037 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2037, label %failure.2038, label %continue.2039
failure.2038:
  %ctx.field.2040 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 178, ptr %ctx.field.2040, align 4
  %status.diagnostic.2041 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2041, align 4
  ret void
continue.2039:
  %workspace.slot.2042 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2028, ptr %workspace.slot.2042, align 8
  %workspace.slot.2043 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2044 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 245, ptr %outputs, i32 1, ptr %workspace.slot.2043)
  switch i32 %record.make.status.2044, label %runtime.invalid.result.2050 [ i32 0, label %runtime.success.2045 i32 1, label %runtime.invalid.request.2046 i32 2, label %runtime.invalid.reference.2047 i32 3, label %runtime.scratch.capacity.2048 i32 4, label %runtime.retained.capacity.2049 ]
runtime.invalid.request.2046:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2047:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2048:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2049:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2050:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2045:
  %record.make.handle.2051 = load i64, ptr %workspace.slot.2043, align 8
  %ctx.field.2052 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2053 = load i32, ptr %ctx.field.2052, align 4
  %steps.next.2054 = add i32 %steps.current.2053, 1
  store i32 %steps.next.2054, ptr %ctx.field.2052, align 4
  %steps.over.2055 = icmp ugt i32 %steps.next.2054, 10000
  br i1 %steps.over.2055, label %failure.2056, label %continue.2057
failure.2056:
  %ctx.field.2058 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 179, ptr %ctx.field.2058, align 4
  %status.diagnostic.2059 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2059, align 4
  ret void
continue.2057:
  %depth.exceeded.2060 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2060, label %failure.2061, label %continue.2062
failure.2061:
  %ctx.field.2063 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 180, ptr %ctx.field.2063, align 4
  %status.diagnostic.2064 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2064, align 4
  ret void
continue.2062:
  %workspace.slot.2065 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2051, ptr %workspace.slot.2065, align 8
  %workspace.slot.2066 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2067 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 246, ptr %outputs, i32 1, ptr %workspace.slot.2066)
  switch i32 %record.make.status.2067, label %runtime.invalid.result.2073 [ i32 0, label %runtime.success.2068 i32 1, label %runtime.invalid.request.2069 i32 2, label %runtime.invalid.reference.2070 i32 3, label %runtime.scratch.capacity.2071 i32 4, label %runtime.retained.capacity.2072 ]
runtime.invalid.request.2069:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2070:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2071:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2072:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2073:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2068:
  %record.make.handle.2074 = load i64, ptr %workspace.slot.2066, align 8
  %ctx.field.2075 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2076 = load i32, ptr %ctx.field.2075, align 4
  %steps.next.2077 = add i32 %steps.current.2076, 1
  store i32 %steps.next.2077, ptr %ctx.field.2075, align 4
  %steps.over.2078 = icmp ugt i32 %steps.next.2077, 10000
  br i1 %steps.over.2078, label %failure.2079, label %continue.2080
failure.2079:
  %ctx.field.2081 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 181, ptr %ctx.field.2081, align 4
  %status.diagnostic.2082 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2082, align 4
  ret void
continue.2080:
  %depth.exceeded.2083 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2083, label %failure.2084, label %continue.2085
failure.2084:
  %ctx.field.2086 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 182, ptr %ctx.field.2086, align 4
  %status.diagnostic.2087 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2087, align 4
  ret void
continue.2085:
  %workspace.slot.2088 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2074, ptr %workspace.slot.2088, align 8
  %workspace.slot.2089 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2090 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 247, ptr %outputs, i32 1, ptr %workspace.slot.2089)
  switch i32 %record.make.status.2090, label %runtime.invalid.result.2096 [ i32 0, label %runtime.success.2091 i32 1, label %runtime.invalid.request.2092 i32 2, label %runtime.invalid.reference.2093 i32 3, label %runtime.scratch.capacity.2094 i32 4, label %runtime.retained.capacity.2095 ]
runtime.invalid.request.2092:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2093:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2094:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2095:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2096:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2091:
  %record.make.handle.2097 = load i64, ptr %workspace.slot.2089, align 8
  %ctx.field.2098 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2099 = load i32, ptr %ctx.field.2098, align 4
  %steps.next.2100 = add i32 %steps.current.2099, 1
  store i32 %steps.next.2100, ptr %ctx.field.2098, align 4
  %steps.over.2101 = icmp ugt i32 %steps.next.2100, 10000
  br i1 %steps.over.2101, label %failure.2102, label %continue.2103
failure.2102:
  %ctx.field.2104 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 183, ptr %ctx.field.2104, align 4
  %status.diagnostic.2105 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2105, align 4
  ret void
continue.2103:
  %depth.exceeded.2106 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2106, label %failure.2107, label %continue.2108
failure.2107:
  %ctx.field.2109 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 184, ptr %ctx.field.2109, align 4
  %status.diagnostic.2110 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2110, align 4
  ret void
continue.2108:
  %workspace.slot.2111 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2097, ptr %workspace.slot.2111, align 8
  %workspace.slot.2112 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2113 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 249, ptr %outputs, i32 1, ptr %workspace.slot.2112)
  switch i32 %record.make.status.2113, label %runtime.invalid.result.2119 [ i32 0, label %runtime.success.2114 i32 1, label %runtime.invalid.request.2115 i32 2, label %runtime.invalid.reference.2116 i32 3, label %runtime.scratch.capacity.2117 i32 4, label %runtime.retained.capacity.2118 ]
runtime.invalid.request.2115:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2116:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2117:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2118:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2119:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2114:
  %record.make.handle.2120 = load i64, ptr %workspace.slot.2112, align 8
  %ctx.field.2121 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2122 = load i32, ptr %ctx.field.2121, align 4
  %steps.next.2123 = add i32 %steps.current.2122, 1
  store i32 %steps.next.2123, ptr %ctx.field.2121, align 4
  %steps.over.2124 = icmp ugt i32 %steps.next.2123, 10000
  br i1 %steps.over.2124, label %failure.2125, label %continue.2126
failure.2125:
  %ctx.field.2127 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 185, ptr %ctx.field.2127, align 4
  %status.diagnostic.2128 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2128, align 4
  ret void
continue.2126:
  %depth.exceeded.2129 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2129, label %failure.2130, label %continue.2131
failure.2130:
  %ctx.field.2132 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 186, ptr %ctx.field.2132, align 4
  %status.diagnostic.2133 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2133, align 4
  ret void
continue.2131:
  %workspace.slot.2134 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2120, ptr %workspace.slot.2134, align 8
  %workspace.slot.2135 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2136 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 250, ptr %outputs, i32 1, ptr %workspace.slot.2135)
  switch i32 %record.make.status.2136, label %runtime.invalid.result.2142 [ i32 0, label %runtime.success.2137 i32 1, label %runtime.invalid.request.2138 i32 2, label %runtime.invalid.reference.2139 i32 3, label %runtime.scratch.capacity.2140 i32 4, label %runtime.retained.capacity.2141 ]
runtime.invalid.request.2138:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2139:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2140:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2141:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2142:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2137:
  %record.make.handle.2143 = load i64, ptr %workspace.slot.2135, align 8
  %ctx.field.2144 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2145 = load i32, ptr %ctx.field.2144, align 4
  %steps.next.2146 = add i32 %steps.current.2145, 1
  store i32 %steps.next.2146, ptr %ctx.field.2144, align 4
  %steps.over.2147 = icmp ugt i32 %steps.next.2146, 10000
  br i1 %steps.over.2147, label %failure.2148, label %continue.2149
failure.2148:
  %ctx.field.2150 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 187, ptr %ctx.field.2150, align 4
  %status.diagnostic.2151 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2151, align 4
  ret void
continue.2149:
  %depth.exceeded.2152 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2152, label %failure.2153, label %continue.2154
failure.2153:
  %ctx.field.2155 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 188, ptr %ctx.field.2155, align 4
  %status.diagnostic.2156 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2156, align 4
  ret void
continue.2154:
  %workspace.slot.2157 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2143, ptr %workspace.slot.2157, align 8
  %workspace.slot.2158 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2159 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 251, ptr %outputs, i32 1, ptr %workspace.slot.2158)
  switch i32 %record.make.status.2159, label %runtime.invalid.result.2165 [ i32 0, label %runtime.success.2160 i32 1, label %runtime.invalid.request.2161 i32 2, label %runtime.invalid.reference.2162 i32 3, label %runtime.scratch.capacity.2163 i32 4, label %runtime.retained.capacity.2164 ]
runtime.invalid.request.2161:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2162:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2163:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2164:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2165:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2160:
  %record.make.handle.2166 = load i64, ptr %workspace.slot.2158, align 8
  %ctx.field.2167 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2168 = load i32, ptr %ctx.field.2167, align 4
  %steps.next.2169 = add i32 %steps.current.2168, 1
  store i32 %steps.next.2169, ptr %ctx.field.2167, align 4
  %steps.over.2170 = icmp ugt i32 %steps.next.2169, 10000
  br i1 %steps.over.2170, label %failure.2171, label %continue.2172
failure.2171:
  %ctx.field.2173 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 189, ptr %ctx.field.2173, align 4
  %status.diagnostic.2174 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2174, align 4
  ret void
continue.2172:
  %depth.exceeded.2175 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2175, label %failure.2176, label %continue.2177
failure.2176:
  %ctx.field.2178 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 190, ptr %ctx.field.2178, align 4
  %status.diagnostic.2179 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2179, align 4
  ret void
continue.2177:
  %workspace.slot.2180 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2166, ptr %workspace.slot.2180, align 8
  %workspace.slot.2181 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2182 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 252, ptr %outputs, i32 1, ptr %workspace.slot.2181)
  switch i32 %record.make.status.2182, label %runtime.invalid.result.2188 [ i32 0, label %runtime.success.2183 i32 1, label %runtime.invalid.request.2184 i32 2, label %runtime.invalid.reference.2185 i32 3, label %runtime.scratch.capacity.2186 i32 4, label %runtime.retained.capacity.2187 ]
runtime.invalid.request.2184:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2185:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2186:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2187:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2188:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2183:
  %record.make.handle.2189 = load i64, ptr %workspace.slot.2181, align 8
  %ctx.field.2190 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2191 = load i32, ptr %ctx.field.2190, align 4
  %steps.next.2192 = add i32 %steps.current.2191, 1
  store i32 %steps.next.2192, ptr %ctx.field.2190, align 4
  %steps.over.2193 = icmp ugt i32 %steps.next.2192, 10000
  br i1 %steps.over.2193, label %failure.2194, label %continue.2195
failure.2194:
  %ctx.field.2196 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 191, ptr %ctx.field.2196, align 4
  %status.diagnostic.2197 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2197, align 4
  ret void
continue.2195:
  %depth.exceeded.2198 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2198, label %failure.2199, label %continue.2200
failure.2199:
  %ctx.field.2201 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 192, ptr %ctx.field.2201, align 4
  %status.diagnostic.2202 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2202, align 4
  ret void
continue.2200:
  %workspace.slot.2203 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2189, ptr %workspace.slot.2203, align 8
  %workspace.slot.2204 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2205 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 253, ptr %outputs, i32 1, ptr %workspace.slot.2204)
  switch i32 %record.make.status.2205, label %runtime.invalid.result.2211 [ i32 0, label %runtime.success.2206 i32 1, label %runtime.invalid.request.2207 i32 2, label %runtime.invalid.reference.2208 i32 3, label %runtime.scratch.capacity.2209 i32 4, label %runtime.retained.capacity.2210 ]
runtime.invalid.request.2207:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2208:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2209:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2210:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2211:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2206:
  %record.make.handle.2212 = load i64, ptr %workspace.slot.2204, align 8
  %ctx.field.2213 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2214 = load i32, ptr %ctx.field.2213, align 4
  %steps.next.2215 = add i32 %steps.current.2214, 1
  store i32 %steps.next.2215, ptr %ctx.field.2213, align 4
  %steps.over.2216 = icmp ugt i32 %steps.next.2215, 10000
  br i1 %steps.over.2216, label %failure.2217, label %continue.2218
failure.2217:
  %ctx.field.2219 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 193, ptr %ctx.field.2219, align 4
  %status.diagnostic.2220 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2220, align 4
  ret void
continue.2218:
  %depth.exceeded.2221 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2221, label %failure.2222, label %continue.2223
failure.2222:
  %ctx.field.2224 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 194, ptr %ctx.field.2224, align 4
  %status.diagnostic.2225 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2225, align 4
  ret void
continue.2223:
  %workspace.slot.2226 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2212, ptr %workspace.slot.2226, align 8
  %workspace.slot.2227 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2228 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 254, ptr %outputs, i32 1, ptr %workspace.slot.2227)
  switch i32 %record.make.status.2228, label %runtime.invalid.result.2234 [ i32 0, label %runtime.success.2229 i32 1, label %runtime.invalid.request.2230 i32 2, label %runtime.invalid.reference.2231 i32 3, label %runtime.scratch.capacity.2232 i32 4, label %runtime.retained.capacity.2233 ]
runtime.invalid.request.2230:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2231:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2232:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2233:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2234:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2229:
  %record.make.handle.2235 = load i64, ptr %workspace.slot.2227, align 8
  %ctx.field.2236 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2237 = load i32, ptr %ctx.field.2236, align 4
  %steps.next.2238 = add i32 %steps.current.2237, 1
  store i32 %steps.next.2238, ptr %ctx.field.2236, align 4
  %steps.over.2239 = icmp ugt i32 %steps.next.2238, 10000
  br i1 %steps.over.2239, label %failure.2240, label %continue.2241
failure.2240:
  %ctx.field.2242 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 195, ptr %ctx.field.2242, align 4
  %status.diagnostic.2243 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2243, align 4
  ret void
continue.2241:
  %depth.exceeded.2244 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2244, label %failure.2245, label %continue.2246
failure.2245:
  %ctx.field.2247 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 196, ptr %ctx.field.2247, align 4
  %status.diagnostic.2248 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2248, align 4
  ret void
continue.2246:
  %workspace.slot.2249 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2235, ptr %workspace.slot.2249, align 8
  %workspace.slot.2250 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2251 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 255, ptr %outputs, i32 1, ptr %workspace.slot.2250)
  switch i32 %record.make.status.2251, label %runtime.invalid.result.2257 [ i32 0, label %runtime.success.2252 i32 1, label %runtime.invalid.request.2253 i32 2, label %runtime.invalid.reference.2254 i32 3, label %runtime.scratch.capacity.2255 i32 4, label %runtime.retained.capacity.2256 ]
runtime.invalid.request.2253:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2254:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2255:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2256:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2257:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2252:
  %record.make.handle.2258 = load i64, ptr %workspace.slot.2250, align 8
  %ctx.field.2259 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2260 = load i32, ptr %ctx.field.2259, align 4
  %steps.next.2261 = add i32 %steps.current.2260, 1
  store i32 %steps.next.2261, ptr %ctx.field.2259, align 4
  %steps.over.2262 = icmp ugt i32 %steps.next.2261, 10000
  br i1 %steps.over.2262, label %failure.2263, label %continue.2264
failure.2263:
  %ctx.field.2265 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 197, ptr %ctx.field.2265, align 4
  %status.diagnostic.2266 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2266, align 4
  ret void
continue.2264:
  %depth.exceeded.2267 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2267, label %failure.2268, label %continue.2269
failure.2268:
  %ctx.field.2270 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 198, ptr %ctx.field.2270, align 4
  %status.diagnostic.2271 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2271, align 4
  ret void
continue.2269:
  %workspace.slot.2272 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2258, ptr %workspace.slot.2272, align 8
  %workspace.slot.2273 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2274 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 256, ptr %outputs, i32 1, ptr %workspace.slot.2273)
  switch i32 %record.make.status.2274, label %runtime.invalid.result.2280 [ i32 0, label %runtime.success.2275 i32 1, label %runtime.invalid.request.2276 i32 2, label %runtime.invalid.reference.2277 i32 3, label %runtime.scratch.capacity.2278 i32 4, label %runtime.retained.capacity.2279 ]
runtime.invalid.request.2276:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2277:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2278:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2279:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2280:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2275:
  %record.make.handle.2281 = load i64, ptr %workspace.slot.2273, align 8
  %ctx.field.2282 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2283 = load i32, ptr %ctx.field.2282, align 4
  %steps.next.2284 = add i32 %steps.current.2283, 1
  store i32 %steps.next.2284, ptr %ctx.field.2282, align 4
  %steps.over.2285 = icmp ugt i32 %steps.next.2284, 10000
  br i1 %steps.over.2285, label %failure.2286, label %continue.2287
failure.2286:
  %ctx.field.2288 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 199, ptr %ctx.field.2288, align 4
  %status.diagnostic.2289 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2289, align 4
  ret void
continue.2287:
  %depth.exceeded.2290 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2290, label %failure.2291, label %continue.2292
failure.2291:
  %ctx.field.2293 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 200, ptr %ctx.field.2293, align 4
  %status.diagnostic.2294 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2294, align 4
  ret void
continue.2292:
  %workspace.slot.2295 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2281, ptr %workspace.slot.2295, align 8
  %workspace.slot.2296 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2297 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 257, ptr %outputs, i32 1, ptr %workspace.slot.2296)
  switch i32 %record.make.status.2297, label %runtime.invalid.result.2303 [ i32 0, label %runtime.success.2298 i32 1, label %runtime.invalid.request.2299 i32 2, label %runtime.invalid.reference.2300 i32 3, label %runtime.scratch.capacity.2301 i32 4, label %runtime.retained.capacity.2302 ]
runtime.invalid.request.2299:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2300:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2301:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2302:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2303:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2298:
  %record.make.handle.2304 = load i64, ptr %workspace.slot.2296, align 8
  %ctx.field.2305 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2306 = load i32, ptr %ctx.field.2305, align 4
  %steps.next.2307 = add i32 %steps.current.2306, 1
  store i32 %steps.next.2307, ptr %ctx.field.2305, align 4
  %steps.over.2308 = icmp ugt i32 %steps.next.2307, 10000
  br i1 %steps.over.2308, label %failure.2309, label %continue.2310
failure.2309:
  %ctx.field.2311 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 201, ptr %ctx.field.2311, align 4
  %status.diagnostic.2312 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2312, align 4
  ret void
continue.2310:
  %depth.exceeded.2313 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2313, label %failure.2314, label %continue.2315
failure.2314:
  %ctx.field.2316 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 202, ptr %ctx.field.2316, align 4
  %status.diagnostic.2317 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2317, align 4
  ret void
continue.2315:
  %workspace.slot.2318 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2304, ptr %workspace.slot.2318, align 8
  %workspace.slot.2319 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2320 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 258, ptr %outputs, i32 1, ptr %workspace.slot.2319)
  switch i32 %record.make.status.2320, label %runtime.invalid.result.2326 [ i32 0, label %runtime.success.2321 i32 1, label %runtime.invalid.request.2322 i32 2, label %runtime.invalid.reference.2323 i32 3, label %runtime.scratch.capacity.2324 i32 4, label %runtime.retained.capacity.2325 ]
runtime.invalid.request.2322:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2323:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2324:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2325:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2326:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2321:
  %record.make.handle.2327 = load i64, ptr %workspace.slot.2319, align 8
  %ctx.field.2328 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2329 = load i32, ptr %ctx.field.2328, align 4
  %steps.next.2330 = add i32 %steps.current.2329, 1
  store i32 %steps.next.2330, ptr %ctx.field.2328, align 4
  %steps.over.2331 = icmp ugt i32 %steps.next.2330, 10000
  br i1 %steps.over.2331, label %failure.2332, label %continue.2333
failure.2332:
  %ctx.field.2334 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 203, ptr %ctx.field.2334, align 4
  %status.diagnostic.2335 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2335, align 4
  ret void
continue.2333:
  %depth.exceeded.2336 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2336, label %failure.2337, label %continue.2338
failure.2337:
  %ctx.field.2339 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 204, ptr %ctx.field.2339, align 4
  %status.diagnostic.2340 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2340, align 4
  ret void
continue.2338:
  %workspace.slot.2341 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2327, ptr %workspace.slot.2341, align 8
  %workspace.slot.2342 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2343 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 6, ptr %outputs, i32 1, ptr %workspace.slot.2342)
  switch i32 %record.make.status.2343, label %runtime.invalid.result.2349 [ i32 0, label %runtime.success.2344 i32 1, label %runtime.invalid.request.2345 i32 2, label %runtime.invalid.reference.2346 i32 3, label %runtime.scratch.capacity.2347 i32 4, label %runtime.retained.capacity.2348 ]
runtime.invalid.request.2345:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2346:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2347:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2348:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2349:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2344:
  %record.make.handle.2350 = load i64, ptr %workspace.slot.2342, align 8
  %ctx.field.2351 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2352 = load i32, ptr %ctx.field.2351, align 4
  %steps.next.2353 = add i32 %steps.current.2352, 1
  store i32 %steps.next.2353, ptr %ctx.field.2351, align 4
  %steps.over.2354 = icmp ugt i32 %steps.next.2353, 10000
  br i1 %steps.over.2354, label %failure.2355, label %continue.2356
failure.2355:
  %ctx.field.2357 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 205, ptr %ctx.field.2357, align 4
  %status.diagnostic.2358 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2358, align 4
  ret void
continue.2356:
  %depth.exceeded.2359 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2359, label %failure.2360, label %continue.2361
failure.2360:
  %ctx.field.2362 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 206, ptr %ctx.field.2362, align 4
  %status.diagnostic.2363 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2363, align 4
  ret void
continue.2361:
  %workspace.slot.2364 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2350, ptr %workspace.slot.2364, align 8
  %workspace.slot.2365 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2366 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 7, ptr %outputs, i32 1, ptr %workspace.slot.2365)
  switch i32 %record.make.status.2366, label %runtime.invalid.result.2372 [ i32 0, label %runtime.success.2367 i32 1, label %runtime.invalid.request.2368 i32 2, label %runtime.invalid.reference.2369 i32 3, label %runtime.scratch.capacity.2370 i32 4, label %runtime.retained.capacity.2371 ]
runtime.invalid.request.2368:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2369:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2370:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2371:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2372:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2367:
  %record.make.handle.2373 = load i64, ptr %workspace.slot.2365, align 8
  %ctx.field.2374 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2375 = load i32, ptr %ctx.field.2374, align 4
  %steps.next.2376 = add i32 %steps.current.2375, 1
  store i32 %steps.next.2376, ptr %ctx.field.2374, align 4
  %steps.over.2377 = icmp ugt i32 %steps.next.2376, 10000
  br i1 %steps.over.2377, label %failure.2378, label %continue.2379
failure.2378:
  %ctx.field.2380 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 207, ptr %ctx.field.2380, align 4
  %status.diagnostic.2381 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2381, align 4
  ret void
continue.2379:
  %depth.exceeded.2382 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2382, label %failure.2383, label %continue.2384
failure.2383:
  %ctx.field.2385 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 208, ptr %ctx.field.2385, align 4
  %status.diagnostic.2386 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2386, align 4
  ret void
continue.2384:
  %workspace.slot.2387 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2373, ptr %workspace.slot.2387, align 8
  %workspace.slot.2388 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2389 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 8, ptr %outputs, i32 1, ptr %workspace.slot.2388)
  switch i32 %record.make.status.2389, label %runtime.invalid.result.2395 [ i32 0, label %runtime.success.2390 i32 1, label %runtime.invalid.request.2391 i32 2, label %runtime.invalid.reference.2392 i32 3, label %runtime.scratch.capacity.2393 i32 4, label %runtime.retained.capacity.2394 ]
runtime.invalid.request.2391:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2392:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2393:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2394:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2395:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2390:
  %record.make.handle.2396 = load i64, ptr %workspace.slot.2388, align 8
  %ctx.field.2397 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2398 = load i32, ptr %ctx.field.2397, align 4
  %steps.next.2399 = add i32 %steps.current.2398, 1
  store i32 %steps.next.2399, ptr %ctx.field.2397, align 4
  %steps.over.2400 = icmp ugt i32 %steps.next.2399, 10000
  br i1 %steps.over.2400, label %failure.2401, label %continue.2402
failure.2401:
  %ctx.field.2403 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 209, ptr %ctx.field.2403, align 4
  %status.diagnostic.2404 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2404, align 4
  ret void
continue.2402:
  %depth.exceeded.2405 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2405, label %failure.2406, label %continue.2407
failure.2406:
  %ctx.field.2408 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 210, ptr %ctx.field.2408, align 4
  %status.diagnostic.2409 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2409, align 4
  ret void
continue.2407:
  %workspace.slot.2410 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2396, ptr %workspace.slot.2410, align 8
  %workspace.slot.2411 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2412 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 9, ptr %outputs, i32 1, ptr %workspace.slot.2411)
  switch i32 %record.make.status.2412, label %runtime.invalid.result.2418 [ i32 0, label %runtime.success.2413 i32 1, label %runtime.invalid.request.2414 i32 2, label %runtime.invalid.reference.2415 i32 3, label %runtime.scratch.capacity.2416 i32 4, label %runtime.retained.capacity.2417 ]
runtime.invalid.request.2414:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2415:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2416:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2417:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2418:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2413:
  %record.make.handle.2419 = load i64, ptr %workspace.slot.2411, align 8
  %ctx.field.2420 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2421 = load i32, ptr %ctx.field.2420, align 4
  %steps.next.2422 = add i32 %steps.current.2421, 1
  store i32 %steps.next.2422, ptr %ctx.field.2420, align 4
  %steps.over.2423 = icmp ugt i32 %steps.next.2422, 10000
  br i1 %steps.over.2423, label %failure.2424, label %continue.2425
failure.2424:
  %ctx.field.2426 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 211, ptr %ctx.field.2426, align 4
  %status.diagnostic.2427 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2427, align 4
  ret void
continue.2425:
  %depth.exceeded.2428 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2428, label %failure.2429, label %continue.2430
failure.2429:
  %ctx.field.2431 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 212, ptr %ctx.field.2431, align 4
  %status.diagnostic.2432 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2432, align 4
  ret void
continue.2430:
  %workspace.slot.2433 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2419, ptr %workspace.slot.2433, align 8
  %workspace.slot.2434 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2435 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 10, ptr %outputs, i32 1, ptr %workspace.slot.2434)
  switch i32 %record.make.status.2435, label %runtime.invalid.result.2441 [ i32 0, label %runtime.success.2436 i32 1, label %runtime.invalid.request.2437 i32 2, label %runtime.invalid.reference.2438 i32 3, label %runtime.scratch.capacity.2439 i32 4, label %runtime.retained.capacity.2440 ]
runtime.invalid.request.2437:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2438:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2439:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2440:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2441:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2436:
  %record.make.handle.2442 = load i64, ptr %workspace.slot.2434, align 8
  %ctx.field.2443 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2444 = load i32, ptr %ctx.field.2443, align 4
  %steps.next.2445 = add i32 %steps.current.2444, 1
  store i32 %steps.next.2445, ptr %ctx.field.2443, align 4
  %steps.over.2446 = icmp ugt i32 %steps.next.2445, 10000
  br i1 %steps.over.2446, label %failure.2447, label %continue.2448
failure.2447:
  %ctx.field.2449 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 213, ptr %ctx.field.2449, align 4
  %status.diagnostic.2450 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2450, align 4
  ret void
continue.2448:
  %depth.exceeded.2451 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2451, label %failure.2452, label %continue.2453
failure.2452:
  %ctx.field.2454 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 214, ptr %ctx.field.2454, align 4
  %status.diagnostic.2455 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2455, align 4
  ret void
continue.2453:
  %workspace.slot.2456 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2442, ptr %workspace.slot.2456, align 8
  %workspace.slot.2457 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2458 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 11, ptr %outputs, i32 1, ptr %workspace.slot.2457)
  switch i32 %record.make.status.2458, label %runtime.invalid.result.2464 [ i32 0, label %runtime.success.2459 i32 1, label %runtime.invalid.request.2460 i32 2, label %runtime.invalid.reference.2461 i32 3, label %runtime.scratch.capacity.2462 i32 4, label %runtime.retained.capacity.2463 ]
runtime.invalid.request.2460:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2461:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2462:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2463:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2464:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2459:
  %record.make.handle.2465 = load i64, ptr %workspace.slot.2457, align 8
  %ctx.field.2466 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2467 = load i32, ptr %ctx.field.2466, align 4
  %steps.next.2468 = add i32 %steps.current.2467, 1
  store i32 %steps.next.2468, ptr %ctx.field.2466, align 4
  %steps.over.2469 = icmp ugt i32 %steps.next.2468, 10000
  br i1 %steps.over.2469, label %failure.2470, label %continue.2471
failure.2470:
  %ctx.field.2472 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 215, ptr %ctx.field.2472, align 4
  %status.diagnostic.2473 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2473, align 4
  ret void
continue.2471:
  %depth.exceeded.2474 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2474, label %failure.2475, label %continue.2476
failure.2475:
  %ctx.field.2477 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 216, ptr %ctx.field.2477, align 4
  %status.diagnostic.2478 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2478, align 4
  ret void
continue.2476:
  %workspace.slot.2479 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2465, ptr %workspace.slot.2479, align 8
  %workspace.slot.2480 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2481 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 12, ptr %outputs, i32 1, ptr %workspace.slot.2480)
  switch i32 %record.make.status.2481, label %runtime.invalid.result.2487 [ i32 0, label %runtime.success.2482 i32 1, label %runtime.invalid.request.2483 i32 2, label %runtime.invalid.reference.2484 i32 3, label %runtime.scratch.capacity.2485 i32 4, label %runtime.retained.capacity.2486 ]
runtime.invalid.request.2483:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2484:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2485:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2486:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2487:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2482:
  %record.make.handle.2488 = load i64, ptr %workspace.slot.2480, align 8
  %ctx.field.2489 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2490 = load i32, ptr %ctx.field.2489, align 4
  %steps.next.2491 = add i32 %steps.current.2490, 1
  store i32 %steps.next.2491, ptr %ctx.field.2489, align 4
  %steps.over.2492 = icmp ugt i32 %steps.next.2491, 10000
  br i1 %steps.over.2492, label %failure.2493, label %continue.2494
failure.2493:
  %ctx.field.2495 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 217, ptr %ctx.field.2495, align 4
  %status.diagnostic.2496 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2496, align 4
  ret void
continue.2494:
  %depth.exceeded.2497 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2497, label %failure.2498, label %continue.2499
failure.2498:
  %ctx.field.2500 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 218, ptr %ctx.field.2500, align 4
  %status.diagnostic.2501 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2501, align 4
  ret void
continue.2499:
  %workspace.slot.2502 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2488, ptr %workspace.slot.2502, align 8
  %workspace.slot.2503 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2504 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 13, ptr %outputs, i32 1, ptr %workspace.slot.2503)
  switch i32 %record.make.status.2504, label %runtime.invalid.result.2510 [ i32 0, label %runtime.success.2505 i32 1, label %runtime.invalid.request.2506 i32 2, label %runtime.invalid.reference.2507 i32 3, label %runtime.scratch.capacity.2508 i32 4, label %runtime.retained.capacity.2509 ]
runtime.invalid.request.2506:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2507:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2508:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2509:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2510:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2505:
  %record.make.handle.2511 = load i64, ptr %workspace.slot.2503, align 8
  %ctx.field.2512 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2513 = load i32, ptr %ctx.field.2512, align 4
  %steps.next.2514 = add i32 %steps.current.2513, 1
  store i32 %steps.next.2514, ptr %ctx.field.2512, align 4
  %steps.over.2515 = icmp ugt i32 %steps.next.2514, 10000
  br i1 %steps.over.2515, label %failure.2516, label %continue.2517
failure.2516:
  %ctx.field.2518 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 219, ptr %ctx.field.2518, align 4
  %status.diagnostic.2519 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2519, align 4
  ret void
continue.2517:
  %depth.exceeded.2520 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2520, label %failure.2521, label %continue.2522
failure.2521:
  %ctx.field.2523 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 220, ptr %ctx.field.2523, align 4
  %status.diagnostic.2524 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2524, align 4
  ret void
continue.2522:
  %workspace.slot.2525 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2511, ptr %workspace.slot.2525, align 8
  %workspace.slot.2526 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2527 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 14, ptr %outputs, i32 1, ptr %workspace.slot.2526)
  switch i32 %record.make.status.2527, label %runtime.invalid.result.2533 [ i32 0, label %runtime.success.2528 i32 1, label %runtime.invalid.request.2529 i32 2, label %runtime.invalid.reference.2530 i32 3, label %runtime.scratch.capacity.2531 i32 4, label %runtime.retained.capacity.2532 ]
runtime.invalid.request.2529:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2530:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2531:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2532:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2533:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2528:
  %record.make.handle.2534 = load i64, ptr %workspace.slot.2526, align 8
  %ctx.field.2535 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2536 = load i32, ptr %ctx.field.2535, align 4
  %steps.next.2537 = add i32 %steps.current.2536, 1
  store i32 %steps.next.2537, ptr %ctx.field.2535, align 4
  %steps.over.2538 = icmp ugt i32 %steps.next.2537, 10000
  br i1 %steps.over.2538, label %failure.2539, label %continue.2540
failure.2539:
  %ctx.field.2541 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 221, ptr %ctx.field.2541, align 4
  %status.diagnostic.2542 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2542, align 4
  ret void
continue.2540:
  %depth.exceeded.2543 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2543, label %failure.2544, label %continue.2545
failure.2544:
  %ctx.field.2546 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 222, ptr %ctx.field.2546, align 4
  %status.diagnostic.2547 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2547, align 4
  ret void
continue.2545:
  %workspace.slot.2548 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2534, ptr %workspace.slot.2548, align 8
  %workspace.slot.2549 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2550 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 15, ptr %outputs, i32 1, ptr %workspace.slot.2549)
  switch i32 %record.make.status.2550, label %runtime.invalid.result.2556 [ i32 0, label %runtime.success.2551 i32 1, label %runtime.invalid.request.2552 i32 2, label %runtime.invalid.reference.2553 i32 3, label %runtime.scratch.capacity.2554 i32 4, label %runtime.retained.capacity.2555 ]
runtime.invalid.request.2552:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2553:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2554:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2555:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2556:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2551:
  %record.make.handle.2557 = load i64, ptr %workspace.slot.2549, align 8
  %ctx.field.2558 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2559 = load i32, ptr %ctx.field.2558, align 4
  %steps.next.2560 = add i32 %steps.current.2559, 1
  store i32 %steps.next.2560, ptr %ctx.field.2558, align 4
  %steps.over.2561 = icmp ugt i32 %steps.next.2560, 10000
  br i1 %steps.over.2561, label %failure.2562, label %continue.2563
failure.2562:
  %ctx.field.2564 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 223, ptr %ctx.field.2564, align 4
  %status.diagnostic.2565 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2565, align 4
  ret void
continue.2563:
  %depth.exceeded.2566 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2566, label %failure.2567, label %continue.2568
failure.2567:
  %ctx.field.2569 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 224, ptr %ctx.field.2569, align 4
  %status.diagnostic.2570 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2570, align 4
  ret void
continue.2568:
  %workspace.slot.2571 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2557, ptr %workspace.slot.2571, align 8
  %workspace.slot.2572 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2573 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 17, ptr %outputs, i32 1, ptr %workspace.slot.2572)
  switch i32 %record.make.status.2573, label %runtime.invalid.result.2579 [ i32 0, label %runtime.success.2574 i32 1, label %runtime.invalid.request.2575 i32 2, label %runtime.invalid.reference.2576 i32 3, label %runtime.scratch.capacity.2577 i32 4, label %runtime.retained.capacity.2578 ]
runtime.invalid.request.2575:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2576:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2577:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2578:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2579:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2574:
  %record.make.handle.2580 = load i64, ptr %workspace.slot.2572, align 8
  %ctx.field.2581 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2582 = load i32, ptr %ctx.field.2581, align 4
  %steps.next.2583 = add i32 %steps.current.2582, 1
  store i32 %steps.next.2583, ptr %ctx.field.2581, align 4
  %steps.over.2584 = icmp ugt i32 %steps.next.2583, 10000
  br i1 %steps.over.2584, label %failure.2585, label %continue.2586
failure.2585:
  %ctx.field.2587 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 225, ptr %ctx.field.2587, align 4
  %status.diagnostic.2588 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2588, align 4
  ret void
continue.2586:
  %depth.exceeded.2589 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2589, label %failure.2590, label %continue.2591
failure.2590:
  %ctx.field.2592 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 226, ptr %ctx.field.2592, align 4
  %status.diagnostic.2593 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2593, align 4
  ret void
continue.2591:
  %workspace.slot.2594 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2580, ptr %workspace.slot.2594, align 8
  %workspace.slot.2595 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2596 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 18, ptr %outputs, i32 1, ptr %workspace.slot.2595)
  switch i32 %record.make.status.2596, label %runtime.invalid.result.2602 [ i32 0, label %runtime.success.2597 i32 1, label %runtime.invalid.request.2598 i32 2, label %runtime.invalid.reference.2599 i32 3, label %runtime.scratch.capacity.2600 i32 4, label %runtime.retained.capacity.2601 ]
runtime.invalid.request.2598:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2599:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2600:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2601:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2602:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2597:
  %record.make.handle.2603 = load i64, ptr %workspace.slot.2595, align 8
  %ctx.field.2604 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2605 = load i32, ptr %ctx.field.2604, align 4
  %steps.next.2606 = add i32 %steps.current.2605, 1
  store i32 %steps.next.2606, ptr %ctx.field.2604, align 4
  %steps.over.2607 = icmp ugt i32 %steps.next.2606, 10000
  br i1 %steps.over.2607, label %failure.2608, label %continue.2609
failure.2608:
  %ctx.field.2610 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 227, ptr %ctx.field.2610, align 4
  %status.diagnostic.2611 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2611, align 4
  ret void
continue.2609:
  %depth.exceeded.2612 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2612, label %failure.2613, label %continue.2614
failure.2613:
  %ctx.field.2615 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 228, ptr %ctx.field.2615, align 4
  %status.diagnostic.2616 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2616, align 4
  ret void
continue.2614:
  %workspace.slot.2617 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2603, ptr %workspace.slot.2617, align 8
  %workspace.slot.2618 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2619 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 19, ptr %outputs, i32 1, ptr %workspace.slot.2618)
  switch i32 %record.make.status.2619, label %runtime.invalid.result.2625 [ i32 0, label %runtime.success.2620 i32 1, label %runtime.invalid.request.2621 i32 2, label %runtime.invalid.reference.2622 i32 3, label %runtime.scratch.capacity.2623 i32 4, label %runtime.retained.capacity.2624 ]
runtime.invalid.request.2621:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2622:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2623:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2624:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2625:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2620:
  %record.make.handle.2626 = load i64, ptr %workspace.slot.2618, align 8
  %ctx.field.2627 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2628 = load i32, ptr %ctx.field.2627, align 4
  %steps.next.2629 = add i32 %steps.current.2628, 1
  store i32 %steps.next.2629, ptr %ctx.field.2627, align 4
  %steps.over.2630 = icmp ugt i32 %steps.next.2629, 10000
  br i1 %steps.over.2630, label %failure.2631, label %continue.2632
failure.2631:
  %ctx.field.2633 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 229, ptr %ctx.field.2633, align 4
  %status.diagnostic.2634 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2634, align 4
  ret void
continue.2632:
  %depth.exceeded.2635 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2635, label %failure.2636, label %continue.2637
failure.2636:
  %ctx.field.2638 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 230, ptr %ctx.field.2638, align 4
  %status.diagnostic.2639 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2639, align 4
  ret void
continue.2637:
  %workspace.slot.2640 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2626, ptr %workspace.slot.2640, align 8
  %workspace.slot.2641 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2642 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 20, ptr %outputs, i32 1, ptr %workspace.slot.2641)
  switch i32 %record.make.status.2642, label %runtime.invalid.result.2648 [ i32 0, label %runtime.success.2643 i32 1, label %runtime.invalid.request.2644 i32 2, label %runtime.invalid.reference.2645 i32 3, label %runtime.scratch.capacity.2646 i32 4, label %runtime.retained.capacity.2647 ]
runtime.invalid.request.2644:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2645:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2646:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2647:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2648:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2643:
  %record.make.handle.2649 = load i64, ptr %workspace.slot.2641, align 8
  %ctx.field.2650 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2651 = load i32, ptr %ctx.field.2650, align 4
  %steps.next.2652 = add i32 %steps.current.2651, 1
  store i32 %steps.next.2652, ptr %ctx.field.2650, align 4
  %steps.over.2653 = icmp ugt i32 %steps.next.2652, 10000
  br i1 %steps.over.2653, label %failure.2654, label %continue.2655
failure.2654:
  %ctx.field.2656 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 231, ptr %ctx.field.2656, align 4
  %status.diagnostic.2657 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2657, align 4
  ret void
continue.2655:
  %depth.exceeded.2658 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2658, label %failure.2659, label %continue.2660
failure.2659:
  %ctx.field.2661 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 232, ptr %ctx.field.2661, align 4
  %status.diagnostic.2662 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2662, align 4
  ret void
continue.2660:
  %workspace.slot.2663 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2649, ptr %workspace.slot.2663, align 8
  %workspace.slot.2664 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2665 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 21, ptr %outputs, i32 1, ptr %workspace.slot.2664)
  switch i32 %record.make.status.2665, label %runtime.invalid.result.2671 [ i32 0, label %runtime.success.2666 i32 1, label %runtime.invalid.request.2667 i32 2, label %runtime.invalid.reference.2668 i32 3, label %runtime.scratch.capacity.2669 i32 4, label %runtime.retained.capacity.2670 ]
runtime.invalid.request.2667:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2668:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2669:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2670:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2671:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2666:
  %record.make.handle.2672 = load i64, ptr %workspace.slot.2664, align 8
  %ctx.field.2673 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2674 = load i32, ptr %ctx.field.2673, align 4
  %steps.next.2675 = add i32 %steps.current.2674, 1
  store i32 %steps.next.2675, ptr %ctx.field.2673, align 4
  %steps.over.2676 = icmp ugt i32 %steps.next.2675, 10000
  br i1 %steps.over.2676, label %failure.2677, label %continue.2678
failure.2677:
  %ctx.field.2679 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 233, ptr %ctx.field.2679, align 4
  %status.diagnostic.2680 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2680, align 4
  ret void
continue.2678:
  %depth.exceeded.2681 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2681, label %failure.2682, label %continue.2683
failure.2682:
  %ctx.field.2684 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 234, ptr %ctx.field.2684, align 4
  %status.diagnostic.2685 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2685, align 4
  ret void
continue.2683:
  %workspace.slot.2686 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2672, ptr %workspace.slot.2686, align 8
  %workspace.slot.2687 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2688 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 22, ptr %outputs, i32 1, ptr %workspace.slot.2687)
  switch i32 %record.make.status.2688, label %runtime.invalid.result.2694 [ i32 0, label %runtime.success.2689 i32 1, label %runtime.invalid.request.2690 i32 2, label %runtime.invalid.reference.2691 i32 3, label %runtime.scratch.capacity.2692 i32 4, label %runtime.retained.capacity.2693 ]
runtime.invalid.request.2690:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2691:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2692:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2693:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2694:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2689:
  %record.make.handle.2695 = load i64, ptr %workspace.slot.2687, align 8
  %ctx.field.2696 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2697 = load i32, ptr %ctx.field.2696, align 4
  %steps.next.2698 = add i32 %steps.current.2697, 1
  store i32 %steps.next.2698, ptr %ctx.field.2696, align 4
  %steps.over.2699 = icmp ugt i32 %steps.next.2698, 10000
  br i1 %steps.over.2699, label %failure.2700, label %continue.2701
failure.2700:
  %ctx.field.2702 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 235, ptr %ctx.field.2702, align 4
  %status.diagnostic.2703 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2703, align 4
  ret void
continue.2701:
  %depth.exceeded.2704 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2704, label %failure.2705, label %continue.2706
failure.2705:
  %ctx.field.2707 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 236, ptr %ctx.field.2707, align 4
  %status.diagnostic.2708 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2708, align 4
  ret void
continue.2706:
  %workspace.slot.2709 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2695, ptr %workspace.slot.2709, align 8
  %workspace.slot.2710 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2711 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 23, ptr %outputs, i32 1, ptr %workspace.slot.2710)
  switch i32 %record.make.status.2711, label %runtime.invalid.result.2717 [ i32 0, label %runtime.success.2712 i32 1, label %runtime.invalid.request.2713 i32 2, label %runtime.invalid.reference.2714 i32 3, label %runtime.scratch.capacity.2715 i32 4, label %runtime.retained.capacity.2716 ]
runtime.invalid.request.2713:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2714:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2715:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2716:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2717:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2712:
  %record.make.handle.2718 = load i64, ptr %workspace.slot.2710, align 8
  %ctx.field.2719 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2720 = load i32, ptr %ctx.field.2719, align 4
  %steps.next.2721 = add i32 %steps.current.2720, 1
  store i32 %steps.next.2721, ptr %ctx.field.2719, align 4
  %steps.over.2722 = icmp ugt i32 %steps.next.2721, 10000
  br i1 %steps.over.2722, label %failure.2723, label %continue.2724
failure.2723:
  %ctx.field.2725 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 237, ptr %ctx.field.2725, align 4
  %status.diagnostic.2726 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2726, align 4
  ret void
continue.2724:
  %depth.exceeded.2727 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2727, label %failure.2728, label %continue.2729
failure.2728:
  %ctx.field.2730 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 238, ptr %ctx.field.2730, align 4
  %status.diagnostic.2731 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2731, align 4
  ret void
continue.2729:
  %workspace.slot.2732 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2718, ptr %workspace.slot.2732, align 8
  %workspace.slot.2733 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2734 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 24, ptr %outputs, i32 1, ptr %workspace.slot.2733)
  switch i32 %record.make.status.2734, label %runtime.invalid.result.2740 [ i32 0, label %runtime.success.2735 i32 1, label %runtime.invalid.request.2736 i32 2, label %runtime.invalid.reference.2737 i32 3, label %runtime.scratch.capacity.2738 i32 4, label %runtime.retained.capacity.2739 ]
runtime.invalid.request.2736:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2737:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2738:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2739:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2740:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2735:
  %record.make.handle.2741 = load i64, ptr %workspace.slot.2733, align 8
  %ctx.field.2742 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2743 = load i32, ptr %ctx.field.2742, align 4
  %steps.next.2744 = add i32 %steps.current.2743, 1
  store i32 %steps.next.2744, ptr %ctx.field.2742, align 4
  %steps.over.2745 = icmp ugt i32 %steps.next.2744, 10000
  br i1 %steps.over.2745, label %failure.2746, label %continue.2747
failure.2746:
  %ctx.field.2748 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 239, ptr %ctx.field.2748, align 4
  %status.diagnostic.2749 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2749, align 4
  ret void
continue.2747:
  %depth.exceeded.2750 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2750, label %failure.2751, label %continue.2752
failure.2751:
  %ctx.field.2753 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 240, ptr %ctx.field.2753, align 4
  %status.diagnostic.2754 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2754, align 4
  ret void
continue.2752:
  %workspace.slot.2755 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2741, ptr %workspace.slot.2755, align 8
  %workspace.slot.2756 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2757 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 25, ptr %outputs, i32 1, ptr %workspace.slot.2756)
  switch i32 %record.make.status.2757, label %runtime.invalid.result.2763 [ i32 0, label %runtime.success.2758 i32 1, label %runtime.invalid.request.2759 i32 2, label %runtime.invalid.reference.2760 i32 3, label %runtime.scratch.capacity.2761 i32 4, label %runtime.retained.capacity.2762 ]
runtime.invalid.request.2759:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2760:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2761:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2762:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2763:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2758:
  %record.make.handle.2764 = load i64, ptr %workspace.slot.2756, align 8
  %ctx.field.2765 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2766 = load i32, ptr %ctx.field.2765, align 4
  %steps.next.2767 = add i32 %steps.current.2766, 1
  store i32 %steps.next.2767, ptr %ctx.field.2765, align 4
  %steps.over.2768 = icmp ugt i32 %steps.next.2767, 10000
  br i1 %steps.over.2768, label %failure.2769, label %continue.2770
failure.2769:
  %ctx.field.2771 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 241, ptr %ctx.field.2771, align 4
  %status.diagnostic.2772 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2772, align 4
  ret void
continue.2770:
  %depth.exceeded.2773 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2773, label %failure.2774, label %continue.2775
failure.2774:
  %ctx.field.2776 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 242, ptr %ctx.field.2776, align 4
  %status.diagnostic.2777 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2777, align 4
  ret void
continue.2775:
  %workspace.slot.2778 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2764, ptr %workspace.slot.2778, align 8
  %workspace.slot.2779 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2780 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 26, ptr %outputs, i32 1, ptr %workspace.slot.2779)
  switch i32 %record.make.status.2780, label %runtime.invalid.result.2786 [ i32 0, label %runtime.success.2781 i32 1, label %runtime.invalid.request.2782 i32 2, label %runtime.invalid.reference.2783 i32 3, label %runtime.scratch.capacity.2784 i32 4, label %runtime.retained.capacity.2785 ]
runtime.invalid.request.2782:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2783:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2784:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2785:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2786:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2781:
  %record.make.handle.2787 = load i64, ptr %workspace.slot.2779, align 8
  %ctx.field.2788 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2789 = load i32, ptr %ctx.field.2788, align 4
  %steps.next.2790 = add i32 %steps.current.2789, 1
  store i32 %steps.next.2790, ptr %ctx.field.2788, align 4
  %steps.over.2791 = icmp ugt i32 %steps.next.2790, 10000
  br i1 %steps.over.2791, label %failure.2792, label %continue.2793
failure.2792:
  %ctx.field.2794 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 243, ptr %ctx.field.2794, align 4
  %status.diagnostic.2795 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2795, align 4
  ret void
continue.2793:
  %depth.exceeded.2796 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2796, label %failure.2797, label %continue.2798
failure.2797:
  %ctx.field.2799 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 244, ptr %ctx.field.2799, align 4
  %status.diagnostic.2800 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2800, align 4
  ret void
continue.2798:
  %workspace.slot.2801 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2787, ptr %workspace.slot.2801, align 8
  %workspace.slot.2802 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2803 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 28, ptr %outputs, i32 1, ptr %workspace.slot.2802)
  switch i32 %record.make.status.2803, label %runtime.invalid.result.2809 [ i32 0, label %runtime.success.2804 i32 1, label %runtime.invalid.request.2805 i32 2, label %runtime.invalid.reference.2806 i32 3, label %runtime.scratch.capacity.2807 i32 4, label %runtime.retained.capacity.2808 ]
runtime.invalid.request.2805:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2806:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2807:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2808:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2809:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2804:
  %record.make.handle.2810 = load i64, ptr %workspace.slot.2802, align 8
  %ctx.field.2811 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2812 = load i32, ptr %ctx.field.2811, align 4
  %steps.next.2813 = add i32 %steps.current.2812, 1
  store i32 %steps.next.2813, ptr %ctx.field.2811, align 4
  %steps.over.2814 = icmp ugt i32 %steps.next.2813, 10000
  br i1 %steps.over.2814, label %failure.2815, label %continue.2816
failure.2815:
  %ctx.field.2817 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 245, ptr %ctx.field.2817, align 4
  %status.diagnostic.2818 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2818, align 4
  ret void
continue.2816:
  %depth.exceeded.2819 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2819, label %failure.2820, label %continue.2821
failure.2820:
  %ctx.field.2822 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 246, ptr %ctx.field.2822, align 4
  %status.diagnostic.2823 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2823, align 4
  ret void
continue.2821:
  %workspace.slot.2824 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2810, ptr %workspace.slot.2824, align 8
  %workspace.slot.2825 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2826 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 29, ptr %outputs, i32 1, ptr %workspace.slot.2825)
  switch i32 %record.make.status.2826, label %runtime.invalid.result.2832 [ i32 0, label %runtime.success.2827 i32 1, label %runtime.invalid.request.2828 i32 2, label %runtime.invalid.reference.2829 i32 3, label %runtime.scratch.capacity.2830 i32 4, label %runtime.retained.capacity.2831 ]
runtime.invalid.request.2828:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2829:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2830:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2831:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2832:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2827:
  %record.make.handle.2833 = load i64, ptr %workspace.slot.2825, align 8
  %ctx.field.2834 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2835 = load i32, ptr %ctx.field.2834, align 4
  %steps.next.2836 = add i32 %steps.current.2835, 1
  store i32 %steps.next.2836, ptr %ctx.field.2834, align 4
  %steps.over.2837 = icmp ugt i32 %steps.next.2836, 10000
  br i1 %steps.over.2837, label %failure.2838, label %continue.2839
failure.2838:
  %ctx.field.2840 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 247, ptr %ctx.field.2840, align 4
  %status.diagnostic.2841 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2841, align 4
  ret void
continue.2839:
  %depth.exceeded.2842 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2842, label %failure.2843, label %continue.2844
failure.2843:
  %ctx.field.2845 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 248, ptr %ctx.field.2845, align 4
  %status.diagnostic.2846 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2846, align 4
  ret void
continue.2844:
  %workspace.slot.2847 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2833, ptr %workspace.slot.2847, align 8
  %workspace.slot.2848 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2849 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 30, ptr %outputs, i32 1, ptr %workspace.slot.2848)
  switch i32 %record.make.status.2849, label %runtime.invalid.result.2855 [ i32 0, label %runtime.success.2850 i32 1, label %runtime.invalid.request.2851 i32 2, label %runtime.invalid.reference.2852 i32 3, label %runtime.scratch.capacity.2853 i32 4, label %runtime.retained.capacity.2854 ]
runtime.invalid.request.2851:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2852:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2853:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2854:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2855:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2850:
  %record.make.handle.2856 = load i64, ptr %workspace.slot.2848, align 8
  %ctx.field.2857 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2858 = load i32, ptr %ctx.field.2857, align 4
  %steps.next.2859 = add i32 %steps.current.2858, 1
  store i32 %steps.next.2859, ptr %ctx.field.2857, align 4
  %steps.over.2860 = icmp ugt i32 %steps.next.2859, 10000
  br i1 %steps.over.2860, label %failure.2861, label %continue.2862
failure.2861:
  %ctx.field.2863 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 249, ptr %ctx.field.2863, align 4
  %status.diagnostic.2864 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2864, align 4
  ret void
continue.2862:
  %depth.exceeded.2865 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2865, label %failure.2866, label %continue.2867
failure.2866:
  %ctx.field.2868 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 250, ptr %ctx.field.2868, align 4
  %status.diagnostic.2869 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2869, align 4
  ret void
continue.2867:
  %workspace.slot.2870 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2856, ptr %workspace.slot.2870, align 8
  %workspace.slot.2871 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2872 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 31, ptr %outputs, i32 1, ptr %workspace.slot.2871)
  switch i32 %record.make.status.2872, label %runtime.invalid.result.2878 [ i32 0, label %runtime.success.2873 i32 1, label %runtime.invalid.request.2874 i32 2, label %runtime.invalid.reference.2875 i32 3, label %runtime.scratch.capacity.2876 i32 4, label %runtime.retained.capacity.2877 ]
runtime.invalid.request.2874:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2875:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2876:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2877:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2878:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2873:
  %record.make.handle.2879 = load i64, ptr %workspace.slot.2871, align 8
  %ctx.field.2880 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2881 = load i32, ptr %ctx.field.2880, align 4
  %steps.next.2882 = add i32 %steps.current.2881, 1
  store i32 %steps.next.2882, ptr %ctx.field.2880, align 4
  %steps.over.2883 = icmp ugt i32 %steps.next.2882, 10000
  br i1 %steps.over.2883, label %failure.2884, label %continue.2885
failure.2884:
  %ctx.field.2886 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 251, ptr %ctx.field.2886, align 4
  %status.diagnostic.2887 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2887, align 4
  ret void
continue.2885:
  %depth.exceeded.2888 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2888, label %failure.2889, label %continue.2890
failure.2889:
  %ctx.field.2891 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 252, ptr %ctx.field.2891, align 4
  %status.diagnostic.2892 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2892, align 4
  ret void
continue.2890:
  %workspace.slot.2893 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2879, ptr %workspace.slot.2893, align 8
  %workspace.slot.2894 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2895 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 32, ptr %outputs, i32 1, ptr %workspace.slot.2894)
  switch i32 %record.make.status.2895, label %runtime.invalid.result.2901 [ i32 0, label %runtime.success.2896 i32 1, label %runtime.invalid.request.2897 i32 2, label %runtime.invalid.reference.2898 i32 3, label %runtime.scratch.capacity.2899 i32 4, label %runtime.retained.capacity.2900 ]
runtime.invalid.request.2897:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2898:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2899:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2900:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2901:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2896:
  %record.make.handle.2902 = load i64, ptr %workspace.slot.2894, align 8
  %ctx.field.2903 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2904 = load i32, ptr %ctx.field.2903, align 4
  %steps.next.2905 = add i32 %steps.current.2904, 1
  store i32 %steps.next.2905, ptr %ctx.field.2903, align 4
  %steps.over.2906 = icmp ugt i32 %steps.next.2905, 10000
  br i1 %steps.over.2906, label %failure.2907, label %continue.2908
failure.2907:
  %ctx.field.2909 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 253, ptr %ctx.field.2909, align 4
  %status.diagnostic.2910 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2910, align 4
  ret void
continue.2908:
  %depth.exceeded.2911 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2911, label %failure.2912, label %continue.2913
failure.2912:
  %ctx.field.2914 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 254, ptr %ctx.field.2914, align 4
  %status.diagnostic.2915 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2915, align 4
  ret void
continue.2913:
  %workspace.slot.2916 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2902, ptr %workspace.slot.2916, align 8
  %workspace.slot.2917 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2918 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 33, ptr %outputs, i32 1, ptr %workspace.slot.2917)
  switch i32 %record.make.status.2918, label %runtime.invalid.result.2924 [ i32 0, label %runtime.success.2919 i32 1, label %runtime.invalid.request.2920 i32 2, label %runtime.invalid.reference.2921 i32 3, label %runtime.scratch.capacity.2922 i32 4, label %runtime.retained.capacity.2923 ]
runtime.invalid.request.2920:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2921:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2922:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2923:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2924:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2919:
  %record.make.handle.2925 = load i64, ptr %workspace.slot.2917, align 8
  %ctx.field.2926 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2927 = load i32, ptr %ctx.field.2926, align 4
  %steps.next.2928 = add i32 %steps.current.2927, 1
  store i32 %steps.next.2928, ptr %ctx.field.2926, align 4
  %steps.over.2929 = icmp ugt i32 %steps.next.2928, 10000
  br i1 %steps.over.2929, label %failure.2930, label %continue.2931
failure.2930:
  %ctx.field.2932 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 255, ptr %ctx.field.2932, align 4
  %status.diagnostic.2933 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2933, align 4
  ret void
continue.2931:
  %depth.exceeded.2934 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2934, label %failure.2935, label %continue.2936
failure.2935:
  %ctx.field.2937 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 256, ptr %ctx.field.2937, align 4
  %status.diagnostic.2938 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2938, align 4
  ret void
continue.2936:
  %workspace.slot.2939 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2925, ptr %workspace.slot.2939, align 8
  %workspace.slot.2940 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2941 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 34, ptr %outputs, i32 1, ptr %workspace.slot.2940)
  switch i32 %record.make.status.2941, label %runtime.invalid.result.2947 [ i32 0, label %runtime.success.2942 i32 1, label %runtime.invalid.request.2943 i32 2, label %runtime.invalid.reference.2944 i32 3, label %runtime.scratch.capacity.2945 i32 4, label %runtime.retained.capacity.2946 ]
runtime.invalid.request.2943:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2944:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2945:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2946:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2947:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2942:
  %record.make.handle.2948 = load i64, ptr %workspace.slot.2940, align 8
  %ctx.field.2949 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2950 = load i32, ptr %ctx.field.2949, align 4
  %steps.next.2951 = add i32 %steps.current.2950, 1
  store i32 %steps.next.2951, ptr %ctx.field.2949, align 4
  %steps.over.2952 = icmp ugt i32 %steps.next.2951, 10000
  br i1 %steps.over.2952, label %failure.2953, label %continue.2954
failure.2953:
  %ctx.field.2955 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 257, ptr %ctx.field.2955, align 4
  %status.diagnostic.2956 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2956, align 4
  ret void
continue.2954:
  %depth.exceeded.2957 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2957, label %failure.2958, label %continue.2959
failure.2958:
  %ctx.field.2960 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 258, ptr %ctx.field.2960, align 4
  %status.diagnostic.2961 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2961, align 4
  ret void
continue.2959:
  %workspace.slot.2962 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2948, ptr %workspace.slot.2962, align 8
  %workspace.slot.2963 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2964 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 35, ptr %outputs, i32 1, ptr %workspace.slot.2963)
  switch i32 %record.make.status.2964, label %runtime.invalid.result.2970 [ i32 0, label %runtime.success.2965 i32 1, label %runtime.invalid.request.2966 i32 2, label %runtime.invalid.reference.2967 i32 3, label %runtime.scratch.capacity.2968 i32 4, label %runtime.retained.capacity.2969 ]
runtime.invalid.request.2966:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2967:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2968:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2969:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2970:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2965:
  %record.make.handle.2971 = load i64, ptr %workspace.slot.2963, align 8
  %ctx.field.2972 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2973 = load i32, ptr %ctx.field.2972, align 4
  %steps.next.2974 = add i32 %steps.current.2973, 1
  store i32 %steps.next.2974, ptr %ctx.field.2972, align 4
  %steps.over.2975 = icmp ugt i32 %steps.next.2974, 10000
  br i1 %steps.over.2975, label %failure.2976, label %continue.2977
failure.2976:
  %ctx.field.2978 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 259, ptr %ctx.field.2978, align 4
  %status.diagnostic.2979 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2979, align 4
  ret void
continue.2977:
  %depth.exceeded.2980 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.2980, label %failure.2981, label %continue.2982
failure.2981:
  %ctx.field.2983 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 260, ptr %ctx.field.2983, align 4
  %status.diagnostic.2984 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.2984, align 4
  ret void
continue.2982:
  %workspace.slot.2985 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2971, ptr %workspace.slot.2985, align 8
  %workspace.slot.2986 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.2987 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 36, ptr %outputs, i32 1, ptr %workspace.slot.2986)
  switch i32 %record.make.status.2987, label %runtime.invalid.result.2993 [ i32 0, label %runtime.success.2988 i32 1, label %runtime.invalid.request.2989 i32 2, label %runtime.invalid.reference.2990 i32 3, label %runtime.scratch.capacity.2991 i32 4, label %runtime.retained.capacity.2992 ]
runtime.invalid.request.2989:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.2990:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.2991:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.2992:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.2993:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.2988:
  %record.make.handle.2994 = load i64, ptr %workspace.slot.2986, align 8
  %ctx.field.2995 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.2996 = load i32, ptr %ctx.field.2995, align 4
  %steps.next.2997 = add i32 %steps.current.2996, 1
  store i32 %steps.next.2997, ptr %ctx.field.2995, align 4
  %steps.over.2998 = icmp ugt i32 %steps.next.2997, 10000
  br i1 %steps.over.2998, label %failure.2999, label %continue.3000
failure.2999:
  %ctx.field.3001 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 261, ptr %ctx.field.3001, align 4
  %status.diagnostic.3002 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3002, align 4
  ret void
continue.3000:
  %depth.exceeded.3003 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3003, label %failure.3004, label %continue.3005
failure.3004:
  %ctx.field.3006 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 262, ptr %ctx.field.3006, align 4
  %status.diagnostic.3007 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3007, align 4
  ret void
continue.3005:
  %workspace.slot.3008 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.2994, ptr %workspace.slot.3008, align 8
  %workspace.slot.3009 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3010 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 37, ptr %outputs, i32 1, ptr %workspace.slot.3009)
  switch i32 %record.make.status.3010, label %runtime.invalid.result.3016 [ i32 0, label %runtime.success.3011 i32 1, label %runtime.invalid.request.3012 i32 2, label %runtime.invalid.reference.3013 i32 3, label %runtime.scratch.capacity.3014 i32 4, label %runtime.retained.capacity.3015 ]
runtime.invalid.request.3012:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3013:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3014:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3015:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3016:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3011:
  %record.make.handle.3017 = load i64, ptr %workspace.slot.3009, align 8
  %ctx.field.3018 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3019 = load i32, ptr %ctx.field.3018, align 4
  %steps.next.3020 = add i32 %steps.current.3019, 1
  store i32 %steps.next.3020, ptr %ctx.field.3018, align 4
  %steps.over.3021 = icmp ugt i32 %steps.next.3020, 10000
  br i1 %steps.over.3021, label %failure.3022, label %continue.3023
failure.3022:
  %ctx.field.3024 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 263, ptr %ctx.field.3024, align 4
  %status.diagnostic.3025 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3025, align 4
  ret void
continue.3023:
  %depth.exceeded.3026 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3026, label %failure.3027, label %continue.3028
failure.3027:
  %ctx.field.3029 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 264, ptr %ctx.field.3029, align 4
  %status.diagnostic.3030 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3030, align 4
  ret void
continue.3028:
  %workspace.slot.3031 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3017, ptr %workspace.slot.3031, align 8
  %workspace.slot.3032 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3033 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 39, ptr %outputs, i32 1, ptr %workspace.slot.3032)
  switch i32 %record.make.status.3033, label %runtime.invalid.result.3039 [ i32 0, label %runtime.success.3034 i32 1, label %runtime.invalid.request.3035 i32 2, label %runtime.invalid.reference.3036 i32 3, label %runtime.scratch.capacity.3037 i32 4, label %runtime.retained.capacity.3038 ]
runtime.invalid.request.3035:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3036:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3037:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3038:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3039:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3034:
  %record.make.handle.3040 = load i64, ptr %workspace.slot.3032, align 8
  %ctx.field.3041 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3042 = load i32, ptr %ctx.field.3041, align 4
  %steps.next.3043 = add i32 %steps.current.3042, 1
  store i32 %steps.next.3043, ptr %ctx.field.3041, align 4
  %steps.over.3044 = icmp ugt i32 %steps.next.3043, 10000
  br i1 %steps.over.3044, label %failure.3045, label %continue.3046
failure.3045:
  %ctx.field.3047 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 265, ptr %ctx.field.3047, align 4
  %status.diagnostic.3048 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3048, align 4
  ret void
continue.3046:
  %depth.exceeded.3049 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3049, label %failure.3050, label %continue.3051
failure.3050:
  %ctx.field.3052 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 266, ptr %ctx.field.3052, align 4
  %status.diagnostic.3053 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3053, align 4
  ret void
continue.3051:
  %workspace.slot.3054 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3040, ptr %workspace.slot.3054, align 8
  %workspace.slot.3055 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3056 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 40, ptr %outputs, i32 1, ptr %workspace.slot.3055)
  switch i32 %record.make.status.3056, label %runtime.invalid.result.3062 [ i32 0, label %runtime.success.3057 i32 1, label %runtime.invalid.request.3058 i32 2, label %runtime.invalid.reference.3059 i32 3, label %runtime.scratch.capacity.3060 i32 4, label %runtime.retained.capacity.3061 ]
runtime.invalid.request.3058:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3059:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3060:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3061:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3062:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3057:
  %record.make.handle.3063 = load i64, ptr %workspace.slot.3055, align 8
  %ctx.field.3064 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3065 = load i32, ptr %ctx.field.3064, align 4
  %steps.next.3066 = add i32 %steps.current.3065, 1
  store i32 %steps.next.3066, ptr %ctx.field.3064, align 4
  %steps.over.3067 = icmp ugt i32 %steps.next.3066, 10000
  br i1 %steps.over.3067, label %failure.3068, label %continue.3069
failure.3068:
  %ctx.field.3070 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 267, ptr %ctx.field.3070, align 4
  %status.diagnostic.3071 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3071, align 4
  ret void
continue.3069:
  %depth.exceeded.3072 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3072, label %failure.3073, label %continue.3074
failure.3073:
  %ctx.field.3075 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 268, ptr %ctx.field.3075, align 4
  %status.diagnostic.3076 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3076, align 4
  ret void
continue.3074:
  %workspace.slot.3077 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3063, ptr %workspace.slot.3077, align 8
  %workspace.slot.3078 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3079 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 41, ptr %outputs, i32 1, ptr %workspace.slot.3078)
  switch i32 %record.make.status.3079, label %runtime.invalid.result.3085 [ i32 0, label %runtime.success.3080 i32 1, label %runtime.invalid.request.3081 i32 2, label %runtime.invalid.reference.3082 i32 3, label %runtime.scratch.capacity.3083 i32 4, label %runtime.retained.capacity.3084 ]
runtime.invalid.request.3081:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3082:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3083:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3084:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3085:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3080:
  %record.make.handle.3086 = load i64, ptr %workspace.slot.3078, align 8
  %ctx.field.3087 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3088 = load i32, ptr %ctx.field.3087, align 4
  %steps.next.3089 = add i32 %steps.current.3088, 1
  store i32 %steps.next.3089, ptr %ctx.field.3087, align 4
  %steps.over.3090 = icmp ugt i32 %steps.next.3089, 10000
  br i1 %steps.over.3090, label %failure.3091, label %continue.3092
failure.3091:
  %ctx.field.3093 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 269, ptr %ctx.field.3093, align 4
  %status.diagnostic.3094 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3094, align 4
  ret void
continue.3092:
  %depth.exceeded.3095 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3095, label %failure.3096, label %continue.3097
failure.3096:
  %ctx.field.3098 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 270, ptr %ctx.field.3098, align 4
  %status.diagnostic.3099 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3099, align 4
  ret void
continue.3097:
  %workspace.slot.3100 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3086, ptr %workspace.slot.3100, align 8
  %workspace.slot.3101 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3102 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 42, ptr %outputs, i32 1, ptr %workspace.slot.3101)
  switch i32 %record.make.status.3102, label %runtime.invalid.result.3108 [ i32 0, label %runtime.success.3103 i32 1, label %runtime.invalid.request.3104 i32 2, label %runtime.invalid.reference.3105 i32 3, label %runtime.scratch.capacity.3106 i32 4, label %runtime.retained.capacity.3107 ]
runtime.invalid.request.3104:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3105:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3106:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3107:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3108:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3103:
  %record.make.handle.3109 = load i64, ptr %workspace.slot.3101, align 8
  %ctx.field.3110 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3111 = load i32, ptr %ctx.field.3110, align 4
  %steps.next.3112 = add i32 %steps.current.3111, 1
  store i32 %steps.next.3112, ptr %ctx.field.3110, align 4
  %steps.over.3113 = icmp ugt i32 %steps.next.3112, 10000
  br i1 %steps.over.3113, label %failure.3114, label %continue.3115
failure.3114:
  %ctx.field.3116 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 271, ptr %ctx.field.3116, align 4
  %status.diagnostic.3117 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3117, align 4
  ret void
continue.3115:
  %depth.exceeded.3118 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3118, label %failure.3119, label %continue.3120
failure.3119:
  %ctx.field.3121 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 272, ptr %ctx.field.3121, align 4
  %status.diagnostic.3122 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3122, align 4
  ret void
continue.3120:
  %workspace.slot.3123 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3109, ptr %workspace.slot.3123, align 8
  %workspace.slot.3124 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3125 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 43, ptr %outputs, i32 1, ptr %workspace.slot.3124)
  switch i32 %record.make.status.3125, label %runtime.invalid.result.3131 [ i32 0, label %runtime.success.3126 i32 1, label %runtime.invalid.request.3127 i32 2, label %runtime.invalid.reference.3128 i32 3, label %runtime.scratch.capacity.3129 i32 4, label %runtime.retained.capacity.3130 ]
runtime.invalid.request.3127:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3128:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3129:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3130:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3131:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3126:
  %record.make.handle.3132 = load i64, ptr %workspace.slot.3124, align 8
  %ctx.field.3133 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3134 = load i32, ptr %ctx.field.3133, align 4
  %steps.next.3135 = add i32 %steps.current.3134, 1
  store i32 %steps.next.3135, ptr %ctx.field.3133, align 4
  %steps.over.3136 = icmp ugt i32 %steps.next.3135, 10000
  br i1 %steps.over.3136, label %failure.3137, label %continue.3138
failure.3137:
  %ctx.field.3139 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 273, ptr %ctx.field.3139, align 4
  %status.diagnostic.3140 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3140, align 4
  ret void
continue.3138:
  %depth.exceeded.3141 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3141, label %failure.3142, label %continue.3143
failure.3142:
  %ctx.field.3144 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 274, ptr %ctx.field.3144, align 4
  %status.diagnostic.3145 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3145, align 4
  ret void
continue.3143:
  %workspace.slot.3146 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3132, ptr %workspace.slot.3146, align 8
  %workspace.slot.3147 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3148 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 44, ptr %outputs, i32 1, ptr %workspace.slot.3147)
  switch i32 %record.make.status.3148, label %runtime.invalid.result.3154 [ i32 0, label %runtime.success.3149 i32 1, label %runtime.invalid.request.3150 i32 2, label %runtime.invalid.reference.3151 i32 3, label %runtime.scratch.capacity.3152 i32 4, label %runtime.retained.capacity.3153 ]
runtime.invalid.request.3150:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3151:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3152:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3153:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3154:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3149:
  %record.make.handle.3155 = load i64, ptr %workspace.slot.3147, align 8
  %ctx.field.3156 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3157 = load i32, ptr %ctx.field.3156, align 4
  %steps.next.3158 = add i32 %steps.current.3157, 1
  store i32 %steps.next.3158, ptr %ctx.field.3156, align 4
  %steps.over.3159 = icmp ugt i32 %steps.next.3158, 10000
  br i1 %steps.over.3159, label %failure.3160, label %continue.3161
failure.3160:
  %ctx.field.3162 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 275, ptr %ctx.field.3162, align 4
  %status.diagnostic.3163 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3163, align 4
  ret void
continue.3161:
  %depth.exceeded.3164 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3164, label %failure.3165, label %continue.3166
failure.3165:
  %ctx.field.3167 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 276, ptr %ctx.field.3167, align 4
  %status.diagnostic.3168 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3168, align 4
  ret void
continue.3166:
  %workspace.slot.3169 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3155, ptr %workspace.slot.3169, align 8
  %workspace.slot.3170 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3171 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 45, ptr %outputs, i32 1, ptr %workspace.slot.3170)
  switch i32 %record.make.status.3171, label %runtime.invalid.result.3177 [ i32 0, label %runtime.success.3172 i32 1, label %runtime.invalid.request.3173 i32 2, label %runtime.invalid.reference.3174 i32 3, label %runtime.scratch.capacity.3175 i32 4, label %runtime.retained.capacity.3176 ]
runtime.invalid.request.3173:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3174:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3175:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3176:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3177:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3172:
  %record.make.handle.3178 = load i64, ptr %workspace.slot.3170, align 8
  %ctx.field.3179 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3180 = load i32, ptr %ctx.field.3179, align 4
  %steps.next.3181 = add i32 %steps.current.3180, 1
  store i32 %steps.next.3181, ptr %ctx.field.3179, align 4
  %steps.over.3182 = icmp ugt i32 %steps.next.3181, 10000
  br i1 %steps.over.3182, label %failure.3183, label %continue.3184
failure.3183:
  %ctx.field.3185 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 277, ptr %ctx.field.3185, align 4
  %status.diagnostic.3186 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3186, align 4
  ret void
continue.3184:
  %depth.exceeded.3187 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3187, label %failure.3188, label %continue.3189
failure.3188:
  %ctx.field.3190 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 278, ptr %ctx.field.3190, align 4
  %status.diagnostic.3191 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3191, align 4
  ret void
continue.3189:
  %workspace.slot.3192 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3178, ptr %workspace.slot.3192, align 8
  %workspace.slot.3193 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3194 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 46, ptr %outputs, i32 1, ptr %workspace.slot.3193)
  switch i32 %record.make.status.3194, label %runtime.invalid.result.3200 [ i32 0, label %runtime.success.3195 i32 1, label %runtime.invalid.request.3196 i32 2, label %runtime.invalid.reference.3197 i32 3, label %runtime.scratch.capacity.3198 i32 4, label %runtime.retained.capacity.3199 ]
runtime.invalid.request.3196:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3197:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3198:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3199:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3200:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3195:
  %record.make.handle.3201 = load i64, ptr %workspace.slot.3193, align 8
  %ctx.field.3202 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3203 = load i32, ptr %ctx.field.3202, align 4
  %steps.next.3204 = add i32 %steps.current.3203, 1
  store i32 %steps.next.3204, ptr %ctx.field.3202, align 4
  %steps.over.3205 = icmp ugt i32 %steps.next.3204, 10000
  br i1 %steps.over.3205, label %failure.3206, label %continue.3207
failure.3206:
  %ctx.field.3208 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 279, ptr %ctx.field.3208, align 4
  %status.diagnostic.3209 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3209, align 4
  ret void
continue.3207:
  %depth.exceeded.3210 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3210, label %failure.3211, label %continue.3212
failure.3211:
  %ctx.field.3213 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 280, ptr %ctx.field.3213, align 4
  %status.diagnostic.3214 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3214, align 4
  ret void
continue.3212:
  %workspace.slot.3215 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3201, ptr %workspace.slot.3215, align 8
  %workspace.slot.3216 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3217 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 47, ptr %outputs, i32 1, ptr %workspace.slot.3216)
  switch i32 %record.make.status.3217, label %runtime.invalid.result.3223 [ i32 0, label %runtime.success.3218 i32 1, label %runtime.invalid.request.3219 i32 2, label %runtime.invalid.reference.3220 i32 3, label %runtime.scratch.capacity.3221 i32 4, label %runtime.retained.capacity.3222 ]
runtime.invalid.request.3219:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3220:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3221:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3222:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3223:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3218:
  %record.make.handle.3224 = load i64, ptr %workspace.slot.3216, align 8
  %ctx.field.3225 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3226 = load i32, ptr %ctx.field.3225, align 4
  %steps.next.3227 = add i32 %steps.current.3226, 1
  store i32 %steps.next.3227, ptr %ctx.field.3225, align 4
  %steps.over.3228 = icmp ugt i32 %steps.next.3227, 10000
  br i1 %steps.over.3228, label %failure.3229, label %continue.3230
failure.3229:
  %ctx.field.3231 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 281, ptr %ctx.field.3231, align 4
  %status.diagnostic.3232 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3232, align 4
  ret void
continue.3230:
  %depth.exceeded.3233 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3233, label %failure.3234, label %continue.3235
failure.3234:
  %ctx.field.3236 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 282, ptr %ctx.field.3236, align 4
  %status.diagnostic.3237 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3237, align 4
  ret void
continue.3235:
  %workspace.slot.3238 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3224, ptr %workspace.slot.3238, align 8
  %workspace.slot.3239 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3240 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 48, ptr %outputs, i32 1, ptr %workspace.slot.3239)
  switch i32 %record.make.status.3240, label %runtime.invalid.result.3246 [ i32 0, label %runtime.success.3241 i32 1, label %runtime.invalid.request.3242 i32 2, label %runtime.invalid.reference.3243 i32 3, label %runtime.scratch.capacity.3244 i32 4, label %runtime.retained.capacity.3245 ]
runtime.invalid.request.3242:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3243:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3244:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3245:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3246:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3241:
  %record.make.handle.3247 = load i64, ptr %workspace.slot.3239, align 8
  %ctx.field.3248 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3249 = load i32, ptr %ctx.field.3248, align 4
  %steps.next.3250 = add i32 %steps.current.3249, 1
  store i32 %steps.next.3250, ptr %ctx.field.3248, align 4
  %steps.over.3251 = icmp ugt i32 %steps.next.3250, 10000
  br i1 %steps.over.3251, label %failure.3252, label %continue.3253
failure.3252:
  %ctx.field.3254 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 283, ptr %ctx.field.3254, align 4
  %status.diagnostic.3255 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3255, align 4
  ret void
continue.3253:
  %depth.exceeded.3256 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3256, label %failure.3257, label %continue.3258
failure.3257:
  %ctx.field.3259 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 284, ptr %ctx.field.3259, align 4
  %status.diagnostic.3260 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3260, align 4
  ret void
continue.3258:
  %workspace.slot.3261 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3247, ptr %workspace.slot.3261, align 8
  %workspace.slot.3262 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3263 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 50, ptr %outputs, i32 1, ptr %workspace.slot.3262)
  switch i32 %record.make.status.3263, label %runtime.invalid.result.3269 [ i32 0, label %runtime.success.3264 i32 1, label %runtime.invalid.request.3265 i32 2, label %runtime.invalid.reference.3266 i32 3, label %runtime.scratch.capacity.3267 i32 4, label %runtime.retained.capacity.3268 ]
runtime.invalid.request.3265:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3266:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3267:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3268:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3269:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3264:
  %record.make.handle.3270 = load i64, ptr %workspace.slot.3262, align 8
  %ctx.field.3271 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3272 = load i32, ptr %ctx.field.3271, align 4
  %steps.next.3273 = add i32 %steps.current.3272, 1
  store i32 %steps.next.3273, ptr %ctx.field.3271, align 4
  %steps.over.3274 = icmp ugt i32 %steps.next.3273, 10000
  br i1 %steps.over.3274, label %failure.3275, label %continue.3276
failure.3275:
  %ctx.field.3277 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 285, ptr %ctx.field.3277, align 4
  %status.diagnostic.3278 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3278, align 4
  ret void
continue.3276:
  %depth.exceeded.3279 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3279, label %failure.3280, label %continue.3281
failure.3280:
  %ctx.field.3282 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 286, ptr %ctx.field.3282, align 4
  %status.diagnostic.3283 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3283, align 4
  ret void
continue.3281:
  %workspace.slot.3284 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3270, ptr %workspace.slot.3284, align 8
  %workspace.slot.3285 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3286 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 51, ptr %outputs, i32 1, ptr %workspace.slot.3285)
  switch i32 %record.make.status.3286, label %runtime.invalid.result.3292 [ i32 0, label %runtime.success.3287 i32 1, label %runtime.invalid.request.3288 i32 2, label %runtime.invalid.reference.3289 i32 3, label %runtime.scratch.capacity.3290 i32 4, label %runtime.retained.capacity.3291 ]
runtime.invalid.request.3288:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3289:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3290:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3291:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3292:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3287:
  %record.make.handle.3293 = load i64, ptr %workspace.slot.3285, align 8
  %ctx.field.3294 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3295 = load i32, ptr %ctx.field.3294, align 4
  %steps.next.3296 = add i32 %steps.current.3295, 1
  store i32 %steps.next.3296, ptr %ctx.field.3294, align 4
  %steps.over.3297 = icmp ugt i32 %steps.next.3296, 10000
  br i1 %steps.over.3297, label %failure.3298, label %continue.3299
failure.3298:
  %ctx.field.3300 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 287, ptr %ctx.field.3300, align 4
  %status.diagnostic.3301 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3301, align 4
  ret void
continue.3299:
  %depth.exceeded.3302 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3302, label %failure.3303, label %continue.3304
failure.3303:
  %ctx.field.3305 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 288, ptr %ctx.field.3305, align 4
  %status.diagnostic.3306 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3306, align 4
  ret void
continue.3304:
  %workspace.slot.3307 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3293, ptr %workspace.slot.3307, align 8
  %workspace.slot.3308 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3309 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 52, ptr %outputs, i32 1, ptr %workspace.slot.3308)
  switch i32 %record.make.status.3309, label %runtime.invalid.result.3315 [ i32 0, label %runtime.success.3310 i32 1, label %runtime.invalid.request.3311 i32 2, label %runtime.invalid.reference.3312 i32 3, label %runtime.scratch.capacity.3313 i32 4, label %runtime.retained.capacity.3314 ]
runtime.invalid.request.3311:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3312:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3313:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3314:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3315:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3310:
  %record.make.handle.3316 = load i64, ptr %workspace.slot.3308, align 8
  %ctx.field.3317 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3318 = load i32, ptr %ctx.field.3317, align 4
  %steps.next.3319 = add i32 %steps.current.3318, 1
  store i32 %steps.next.3319, ptr %ctx.field.3317, align 4
  %steps.over.3320 = icmp ugt i32 %steps.next.3319, 10000
  br i1 %steps.over.3320, label %failure.3321, label %continue.3322
failure.3321:
  %ctx.field.3323 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 289, ptr %ctx.field.3323, align 4
  %status.diagnostic.3324 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3324, align 4
  ret void
continue.3322:
  %depth.exceeded.3325 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3325, label %failure.3326, label %continue.3327
failure.3326:
  %ctx.field.3328 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 290, ptr %ctx.field.3328, align 4
  %status.diagnostic.3329 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3329, align 4
  ret void
continue.3327:
  %workspace.slot.3330 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3316, ptr %workspace.slot.3330, align 8
  %workspace.slot.3331 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3332 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 53, ptr %outputs, i32 1, ptr %workspace.slot.3331)
  switch i32 %record.make.status.3332, label %runtime.invalid.result.3338 [ i32 0, label %runtime.success.3333 i32 1, label %runtime.invalid.request.3334 i32 2, label %runtime.invalid.reference.3335 i32 3, label %runtime.scratch.capacity.3336 i32 4, label %runtime.retained.capacity.3337 ]
runtime.invalid.request.3334:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3335:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3336:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3337:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3338:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3333:
  %record.make.handle.3339 = load i64, ptr %workspace.slot.3331, align 8
  %ctx.field.3340 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3341 = load i32, ptr %ctx.field.3340, align 4
  %steps.next.3342 = add i32 %steps.current.3341, 1
  store i32 %steps.next.3342, ptr %ctx.field.3340, align 4
  %steps.over.3343 = icmp ugt i32 %steps.next.3342, 10000
  br i1 %steps.over.3343, label %failure.3344, label %continue.3345
failure.3344:
  %ctx.field.3346 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 291, ptr %ctx.field.3346, align 4
  %status.diagnostic.3347 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3347, align 4
  ret void
continue.3345:
  %depth.exceeded.3348 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3348, label %failure.3349, label %continue.3350
failure.3349:
  %ctx.field.3351 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 292, ptr %ctx.field.3351, align 4
  %status.diagnostic.3352 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3352, align 4
  ret void
continue.3350:
  %workspace.slot.3353 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3339, ptr %workspace.slot.3353, align 8
  %workspace.slot.3354 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3355 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 54, ptr %outputs, i32 1, ptr %workspace.slot.3354)
  switch i32 %record.make.status.3355, label %runtime.invalid.result.3361 [ i32 0, label %runtime.success.3356 i32 1, label %runtime.invalid.request.3357 i32 2, label %runtime.invalid.reference.3358 i32 3, label %runtime.scratch.capacity.3359 i32 4, label %runtime.retained.capacity.3360 ]
runtime.invalid.request.3357:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3358:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3359:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3360:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3361:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3356:
  %record.make.handle.3362 = load i64, ptr %workspace.slot.3354, align 8
  %ctx.field.3363 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3364 = load i32, ptr %ctx.field.3363, align 4
  %steps.next.3365 = add i32 %steps.current.3364, 1
  store i32 %steps.next.3365, ptr %ctx.field.3363, align 4
  %steps.over.3366 = icmp ugt i32 %steps.next.3365, 10000
  br i1 %steps.over.3366, label %failure.3367, label %continue.3368
failure.3367:
  %ctx.field.3369 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 293, ptr %ctx.field.3369, align 4
  %status.diagnostic.3370 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3370, align 4
  ret void
continue.3368:
  %depth.exceeded.3371 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3371, label %failure.3372, label %continue.3373
failure.3372:
  %ctx.field.3374 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 294, ptr %ctx.field.3374, align 4
  %status.diagnostic.3375 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3375, align 4
  ret void
continue.3373:
  %workspace.slot.3376 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3362, ptr %workspace.slot.3376, align 8
  %workspace.slot.3377 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3378 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 55, ptr %outputs, i32 1, ptr %workspace.slot.3377)
  switch i32 %record.make.status.3378, label %runtime.invalid.result.3384 [ i32 0, label %runtime.success.3379 i32 1, label %runtime.invalid.request.3380 i32 2, label %runtime.invalid.reference.3381 i32 3, label %runtime.scratch.capacity.3382 i32 4, label %runtime.retained.capacity.3383 ]
runtime.invalid.request.3380:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3381:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3382:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3383:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3384:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3379:
  %record.make.handle.3385 = load i64, ptr %workspace.slot.3377, align 8
  %ctx.field.3386 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3387 = load i32, ptr %ctx.field.3386, align 4
  %steps.next.3388 = add i32 %steps.current.3387, 1
  store i32 %steps.next.3388, ptr %ctx.field.3386, align 4
  %steps.over.3389 = icmp ugt i32 %steps.next.3388, 10000
  br i1 %steps.over.3389, label %failure.3390, label %continue.3391
failure.3390:
  %ctx.field.3392 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 295, ptr %ctx.field.3392, align 4
  %status.diagnostic.3393 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3393, align 4
  ret void
continue.3391:
  %depth.exceeded.3394 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3394, label %failure.3395, label %continue.3396
failure.3395:
  %ctx.field.3397 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 296, ptr %ctx.field.3397, align 4
  %status.diagnostic.3398 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3398, align 4
  ret void
continue.3396:
  %workspace.slot.3399 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3385, ptr %workspace.slot.3399, align 8
  %workspace.slot.3400 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3401 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 56, ptr %outputs, i32 1, ptr %workspace.slot.3400)
  switch i32 %record.make.status.3401, label %runtime.invalid.result.3407 [ i32 0, label %runtime.success.3402 i32 1, label %runtime.invalid.request.3403 i32 2, label %runtime.invalid.reference.3404 i32 3, label %runtime.scratch.capacity.3405 i32 4, label %runtime.retained.capacity.3406 ]
runtime.invalid.request.3403:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3404:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3405:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3406:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3407:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3402:
  %record.make.handle.3408 = load i64, ptr %workspace.slot.3400, align 8
  %ctx.field.3409 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3410 = load i32, ptr %ctx.field.3409, align 4
  %steps.next.3411 = add i32 %steps.current.3410, 1
  store i32 %steps.next.3411, ptr %ctx.field.3409, align 4
  %steps.over.3412 = icmp ugt i32 %steps.next.3411, 10000
  br i1 %steps.over.3412, label %failure.3413, label %continue.3414
failure.3413:
  %ctx.field.3415 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 297, ptr %ctx.field.3415, align 4
  %status.diagnostic.3416 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3416, align 4
  ret void
continue.3414:
  %depth.exceeded.3417 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3417, label %failure.3418, label %continue.3419
failure.3418:
  %ctx.field.3420 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 298, ptr %ctx.field.3420, align 4
  %status.diagnostic.3421 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3421, align 4
  ret void
continue.3419:
  %workspace.slot.3422 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3408, ptr %workspace.slot.3422, align 8
  %workspace.slot.3423 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3424 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 57, ptr %outputs, i32 1, ptr %workspace.slot.3423)
  switch i32 %record.make.status.3424, label %runtime.invalid.result.3430 [ i32 0, label %runtime.success.3425 i32 1, label %runtime.invalid.request.3426 i32 2, label %runtime.invalid.reference.3427 i32 3, label %runtime.scratch.capacity.3428 i32 4, label %runtime.retained.capacity.3429 ]
runtime.invalid.request.3426:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3427:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3428:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3429:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3430:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3425:
  %record.make.handle.3431 = load i64, ptr %workspace.slot.3423, align 8
  %ctx.field.3432 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3433 = load i32, ptr %ctx.field.3432, align 4
  %steps.next.3434 = add i32 %steps.current.3433, 1
  store i32 %steps.next.3434, ptr %ctx.field.3432, align 4
  %steps.over.3435 = icmp ugt i32 %steps.next.3434, 10000
  br i1 %steps.over.3435, label %failure.3436, label %continue.3437
failure.3436:
  %ctx.field.3438 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 299, ptr %ctx.field.3438, align 4
  %status.diagnostic.3439 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3439, align 4
  ret void
continue.3437:
  %depth.exceeded.3440 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3440, label %failure.3441, label %continue.3442
failure.3441:
  %ctx.field.3443 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 300, ptr %ctx.field.3443, align 4
  %status.diagnostic.3444 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3444, align 4
  ret void
continue.3442:
  %workspace.slot.3445 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3431, ptr %workspace.slot.3445, align 8
  %workspace.slot.3446 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3447 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 58, ptr %outputs, i32 1, ptr %workspace.slot.3446)
  switch i32 %record.make.status.3447, label %runtime.invalid.result.3453 [ i32 0, label %runtime.success.3448 i32 1, label %runtime.invalid.request.3449 i32 2, label %runtime.invalid.reference.3450 i32 3, label %runtime.scratch.capacity.3451 i32 4, label %runtime.retained.capacity.3452 ]
runtime.invalid.request.3449:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3450:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3451:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3452:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3453:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3448:
  %record.make.handle.3454 = load i64, ptr %workspace.slot.3446, align 8
  %ctx.field.3455 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3456 = load i32, ptr %ctx.field.3455, align 4
  %steps.next.3457 = add i32 %steps.current.3456, 1
  store i32 %steps.next.3457, ptr %ctx.field.3455, align 4
  %steps.over.3458 = icmp ugt i32 %steps.next.3457, 10000
  br i1 %steps.over.3458, label %failure.3459, label %continue.3460
failure.3459:
  %ctx.field.3461 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 301, ptr %ctx.field.3461, align 4
  %status.diagnostic.3462 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3462, align 4
  ret void
continue.3460:
  %depth.exceeded.3463 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3463, label %failure.3464, label %continue.3465
failure.3464:
  %ctx.field.3466 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 302, ptr %ctx.field.3466, align 4
  %status.diagnostic.3467 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3467, align 4
  ret void
continue.3465:
  %workspace.slot.3468 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3454, ptr %workspace.slot.3468, align 8
  %workspace.slot.3469 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3470 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 59, ptr %outputs, i32 1, ptr %workspace.slot.3469)
  switch i32 %record.make.status.3470, label %runtime.invalid.result.3476 [ i32 0, label %runtime.success.3471 i32 1, label %runtime.invalid.request.3472 i32 2, label %runtime.invalid.reference.3473 i32 3, label %runtime.scratch.capacity.3474 i32 4, label %runtime.retained.capacity.3475 ]
runtime.invalid.request.3472:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3473:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3474:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3475:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3476:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3471:
  %record.make.handle.3477 = load i64, ptr %workspace.slot.3469, align 8
  %ctx.field.3478 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3479 = load i32, ptr %ctx.field.3478, align 4
  %steps.next.3480 = add i32 %steps.current.3479, 1
  store i32 %steps.next.3480, ptr %ctx.field.3478, align 4
  %steps.over.3481 = icmp ugt i32 %steps.next.3480, 10000
  br i1 %steps.over.3481, label %failure.3482, label %continue.3483
failure.3482:
  %ctx.field.3484 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 303, ptr %ctx.field.3484, align 4
  %status.diagnostic.3485 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3485, align 4
  ret void
continue.3483:
  %depth.exceeded.3486 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3486, label %failure.3487, label %continue.3488
failure.3487:
  %ctx.field.3489 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 304, ptr %ctx.field.3489, align 4
  %status.diagnostic.3490 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3490, align 4
  ret void
continue.3488:
  %workspace.slot.3491 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3477, ptr %workspace.slot.3491, align 8
  %workspace.slot.3492 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3493 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 61, ptr %outputs, i32 1, ptr %workspace.slot.3492)
  switch i32 %record.make.status.3493, label %runtime.invalid.result.3499 [ i32 0, label %runtime.success.3494 i32 1, label %runtime.invalid.request.3495 i32 2, label %runtime.invalid.reference.3496 i32 3, label %runtime.scratch.capacity.3497 i32 4, label %runtime.retained.capacity.3498 ]
runtime.invalid.request.3495:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3496:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3497:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3498:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3499:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3494:
  %record.make.handle.3500 = load i64, ptr %workspace.slot.3492, align 8
  %ctx.field.3501 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3502 = load i32, ptr %ctx.field.3501, align 4
  %steps.next.3503 = add i32 %steps.current.3502, 1
  store i32 %steps.next.3503, ptr %ctx.field.3501, align 4
  %steps.over.3504 = icmp ugt i32 %steps.next.3503, 10000
  br i1 %steps.over.3504, label %failure.3505, label %continue.3506
failure.3505:
  %ctx.field.3507 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 305, ptr %ctx.field.3507, align 4
  %status.diagnostic.3508 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3508, align 4
  ret void
continue.3506:
  %depth.exceeded.3509 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3509, label %failure.3510, label %continue.3511
failure.3510:
  %ctx.field.3512 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 306, ptr %ctx.field.3512, align 4
  %status.diagnostic.3513 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3513, align 4
  ret void
continue.3511:
  %workspace.slot.3514 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3500, ptr %workspace.slot.3514, align 8
  %workspace.slot.3515 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3516 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 62, ptr %outputs, i32 1, ptr %workspace.slot.3515)
  switch i32 %record.make.status.3516, label %runtime.invalid.result.3522 [ i32 0, label %runtime.success.3517 i32 1, label %runtime.invalid.request.3518 i32 2, label %runtime.invalid.reference.3519 i32 3, label %runtime.scratch.capacity.3520 i32 4, label %runtime.retained.capacity.3521 ]
runtime.invalid.request.3518:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3519:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3520:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3521:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3522:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3517:
  %record.make.handle.3523 = load i64, ptr %workspace.slot.3515, align 8
  %ctx.field.3524 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3525 = load i32, ptr %ctx.field.3524, align 4
  %steps.next.3526 = add i32 %steps.current.3525, 1
  store i32 %steps.next.3526, ptr %ctx.field.3524, align 4
  %steps.over.3527 = icmp ugt i32 %steps.next.3526, 10000
  br i1 %steps.over.3527, label %failure.3528, label %continue.3529
failure.3528:
  %ctx.field.3530 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 307, ptr %ctx.field.3530, align 4
  %status.diagnostic.3531 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3531, align 4
  ret void
continue.3529:
  %depth.exceeded.3532 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3532, label %failure.3533, label %continue.3534
failure.3533:
  %ctx.field.3535 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 308, ptr %ctx.field.3535, align 4
  %status.diagnostic.3536 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3536, align 4
  ret void
continue.3534:
  %workspace.slot.3537 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3523, ptr %workspace.slot.3537, align 8
  %workspace.slot.3538 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3539 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 63, ptr %outputs, i32 1, ptr %workspace.slot.3538)
  switch i32 %record.make.status.3539, label %runtime.invalid.result.3545 [ i32 0, label %runtime.success.3540 i32 1, label %runtime.invalid.request.3541 i32 2, label %runtime.invalid.reference.3542 i32 3, label %runtime.scratch.capacity.3543 i32 4, label %runtime.retained.capacity.3544 ]
runtime.invalid.request.3541:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3542:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3543:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3544:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3545:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3540:
  %record.make.handle.3546 = load i64, ptr %workspace.slot.3538, align 8
  %ctx.field.3547 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3548 = load i32, ptr %ctx.field.3547, align 4
  %steps.next.3549 = add i32 %steps.current.3548, 1
  store i32 %steps.next.3549, ptr %ctx.field.3547, align 4
  %steps.over.3550 = icmp ugt i32 %steps.next.3549, 10000
  br i1 %steps.over.3550, label %failure.3551, label %continue.3552
failure.3551:
  %ctx.field.3553 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 309, ptr %ctx.field.3553, align 4
  %status.diagnostic.3554 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3554, align 4
  ret void
continue.3552:
  %depth.exceeded.3555 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3555, label %failure.3556, label %continue.3557
failure.3556:
  %ctx.field.3558 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 310, ptr %ctx.field.3558, align 4
  %status.diagnostic.3559 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3559, align 4
  ret void
continue.3557:
  %workspace.slot.3560 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3546, ptr %workspace.slot.3560, align 8
  %workspace.slot.3561 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3562 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 64, ptr %outputs, i32 1, ptr %workspace.slot.3561)
  switch i32 %record.make.status.3562, label %runtime.invalid.result.3568 [ i32 0, label %runtime.success.3563 i32 1, label %runtime.invalid.request.3564 i32 2, label %runtime.invalid.reference.3565 i32 3, label %runtime.scratch.capacity.3566 i32 4, label %runtime.retained.capacity.3567 ]
runtime.invalid.request.3564:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3565:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3566:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3567:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3568:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3563:
  %record.make.handle.3569 = load i64, ptr %workspace.slot.3561, align 8
  %ctx.field.3570 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3571 = load i32, ptr %ctx.field.3570, align 4
  %steps.next.3572 = add i32 %steps.current.3571, 1
  store i32 %steps.next.3572, ptr %ctx.field.3570, align 4
  %steps.over.3573 = icmp ugt i32 %steps.next.3572, 10000
  br i1 %steps.over.3573, label %failure.3574, label %continue.3575
failure.3574:
  %ctx.field.3576 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 311, ptr %ctx.field.3576, align 4
  %status.diagnostic.3577 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3577, align 4
  ret void
continue.3575:
  %depth.exceeded.3578 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3578, label %failure.3579, label %continue.3580
failure.3579:
  %ctx.field.3581 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 312, ptr %ctx.field.3581, align 4
  %status.diagnostic.3582 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3582, align 4
  ret void
continue.3580:
  %workspace.slot.3583 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3569, ptr %workspace.slot.3583, align 8
  %workspace.slot.3584 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3585 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 65, ptr %outputs, i32 1, ptr %workspace.slot.3584)
  switch i32 %record.make.status.3585, label %runtime.invalid.result.3591 [ i32 0, label %runtime.success.3586 i32 1, label %runtime.invalid.request.3587 i32 2, label %runtime.invalid.reference.3588 i32 3, label %runtime.scratch.capacity.3589 i32 4, label %runtime.retained.capacity.3590 ]
runtime.invalid.request.3587:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3588:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3589:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3590:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3591:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3586:
  %record.make.handle.3592 = load i64, ptr %workspace.slot.3584, align 8
  %ctx.field.3593 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3594 = load i32, ptr %ctx.field.3593, align 4
  %steps.next.3595 = add i32 %steps.current.3594, 1
  store i32 %steps.next.3595, ptr %ctx.field.3593, align 4
  %steps.over.3596 = icmp ugt i32 %steps.next.3595, 10000
  br i1 %steps.over.3596, label %failure.3597, label %continue.3598
failure.3597:
  %ctx.field.3599 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 313, ptr %ctx.field.3599, align 4
  %status.diagnostic.3600 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3600, align 4
  ret void
continue.3598:
  %depth.exceeded.3601 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3601, label %failure.3602, label %continue.3603
failure.3602:
  %ctx.field.3604 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 314, ptr %ctx.field.3604, align 4
  %status.diagnostic.3605 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3605, align 4
  ret void
continue.3603:
  %workspace.slot.3606 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3592, ptr %workspace.slot.3606, align 8
  %workspace.slot.3607 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3608 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 66, ptr %outputs, i32 1, ptr %workspace.slot.3607)
  switch i32 %record.make.status.3608, label %runtime.invalid.result.3614 [ i32 0, label %runtime.success.3609 i32 1, label %runtime.invalid.request.3610 i32 2, label %runtime.invalid.reference.3611 i32 3, label %runtime.scratch.capacity.3612 i32 4, label %runtime.retained.capacity.3613 ]
runtime.invalid.request.3610:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3611:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3612:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3613:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3614:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3609:
  %record.make.handle.3615 = load i64, ptr %workspace.slot.3607, align 8
  %ctx.field.3616 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3617 = load i32, ptr %ctx.field.3616, align 4
  %steps.next.3618 = add i32 %steps.current.3617, 1
  store i32 %steps.next.3618, ptr %ctx.field.3616, align 4
  %steps.over.3619 = icmp ugt i32 %steps.next.3618, 10000
  br i1 %steps.over.3619, label %failure.3620, label %continue.3621
failure.3620:
  %ctx.field.3622 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 315, ptr %ctx.field.3622, align 4
  %status.diagnostic.3623 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3623, align 4
  ret void
continue.3621:
  %depth.exceeded.3624 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3624, label %failure.3625, label %continue.3626
failure.3625:
  %ctx.field.3627 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 316, ptr %ctx.field.3627, align 4
  %status.diagnostic.3628 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3628, align 4
  ret void
continue.3626:
  %workspace.slot.3629 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3615, ptr %workspace.slot.3629, align 8
  %workspace.slot.3630 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3631 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 67, ptr %outputs, i32 1, ptr %workspace.slot.3630)
  switch i32 %record.make.status.3631, label %runtime.invalid.result.3637 [ i32 0, label %runtime.success.3632 i32 1, label %runtime.invalid.request.3633 i32 2, label %runtime.invalid.reference.3634 i32 3, label %runtime.scratch.capacity.3635 i32 4, label %runtime.retained.capacity.3636 ]
runtime.invalid.request.3633:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3634:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3635:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3636:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3637:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3632:
  %record.make.handle.3638 = load i64, ptr %workspace.slot.3630, align 8
  %ctx.field.3639 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3640 = load i32, ptr %ctx.field.3639, align 4
  %steps.next.3641 = add i32 %steps.current.3640, 1
  store i32 %steps.next.3641, ptr %ctx.field.3639, align 4
  %steps.over.3642 = icmp ugt i32 %steps.next.3641, 10000
  br i1 %steps.over.3642, label %failure.3643, label %continue.3644
failure.3643:
  %ctx.field.3645 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 317, ptr %ctx.field.3645, align 4
  %status.diagnostic.3646 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3646, align 4
  ret void
continue.3644:
  %depth.exceeded.3647 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3647, label %failure.3648, label %continue.3649
failure.3648:
  %ctx.field.3650 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 318, ptr %ctx.field.3650, align 4
  %status.diagnostic.3651 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3651, align 4
  ret void
continue.3649:
  %workspace.slot.3652 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3638, ptr %workspace.slot.3652, align 8
  %workspace.slot.3653 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3654 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 68, ptr %outputs, i32 1, ptr %workspace.slot.3653)
  switch i32 %record.make.status.3654, label %runtime.invalid.result.3660 [ i32 0, label %runtime.success.3655 i32 1, label %runtime.invalid.request.3656 i32 2, label %runtime.invalid.reference.3657 i32 3, label %runtime.scratch.capacity.3658 i32 4, label %runtime.retained.capacity.3659 ]
runtime.invalid.request.3656:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3657:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3658:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3659:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3660:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3655:
  %record.make.handle.3661 = load i64, ptr %workspace.slot.3653, align 8
  %ctx.field.3662 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3663 = load i32, ptr %ctx.field.3662, align 4
  %steps.next.3664 = add i32 %steps.current.3663, 1
  store i32 %steps.next.3664, ptr %ctx.field.3662, align 4
  %steps.over.3665 = icmp ugt i32 %steps.next.3664, 10000
  br i1 %steps.over.3665, label %failure.3666, label %continue.3667
failure.3666:
  %ctx.field.3668 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 319, ptr %ctx.field.3668, align 4
  %status.diagnostic.3669 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3669, align 4
  ret void
continue.3667:
  %depth.exceeded.3670 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3670, label %failure.3671, label %continue.3672
failure.3671:
  %ctx.field.3673 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 320, ptr %ctx.field.3673, align 4
  %status.diagnostic.3674 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3674, align 4
  ret void
continue.3672:
  %workspace.slot.3675 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3661, ptr %workspace.slot.3675, align 8
  %workspace.slot.3676 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3677 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 69, ptr %outputs, i32 1, ptr %workspace.slot.3676)
  switch i32 %record.make.status.3677, label %runtime.invalid.result.3683 [ i32 0, label %runtime.success.3678 i32 1, label %runtime.invalid.request.3679 i32 2, label %runtime.invalid.reference.3680 i32 3, label %runtime.scratch.capacity.3681 i32 4, label %runtime.retained.capacity.3682 ]
runtime.invalid.request.3679:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3680:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3681:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3682:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3683:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3678:
  %record.make.handle.3684 = load i64, ptr %workspace.slot.3676, align 8
  %ctx.field.3685 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3686 = load i32, ptr %ctx.field.3685, align 4
  %steps.next.3687 = add i32 %steps.current.3686, 1
  store i32 %steps.next.3687, ptr %ctx.field.3685, align 4
  %steps.over.3688 = icmp ugt i32 %steps.next.3687, 10000
  br i1 %steps.over.3688, label %failure.3689, label %continue.3690
failure.3689:
  %ctx.field.3691 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 321, ptr %ctx.field.3691, align 4
  %status.diagnostic.3692 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3692, align 4
  ret void
continue.3690:
  %depth.exceeded.3693 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3693, label %failure.3694, label %continue.3695
failure.3694:
  %ctx.field.3696 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 322, ptr %ctx.field.3696, align 4
  %status.diagnostic.3697 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3697, align 4
  ret void
continue.3695:
  %workspace.slot.3698 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3684, ptr %workspace.slot.3698, align 8
  %workspace.slot.3699 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3700 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 70, ptr %outputs, i32 1, ptr %workspace.slot.3699)
  switch i32 %record.make.status.3700, label %runtime.invalid.result.3706 [ i32 0, label %runtime.success.3701 i32 1, label %runtime.invalid.request.3702 i32 2, label %runtime.invalid.reference.3703 i32 3, label %runtime.scratch.capacity.3704 i32 4, label %runtime.retained.capacity.3705 ]
runtime.invalid.request.3702:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3703:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3704:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3705:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3706:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3701:
  %record.make.handle.3707 = load i64, ptr %workspace.slot.3699, align 8
  %ctx.field.3708 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3709 = load i32, ptr %ctx.field.3708, align 4
  %steps.next.3710 = add i32 %steps.current.3709, 1
  store i32 %steps.next.3710, ptr %ctx.field.3708, align 4
  %steps.over.3711 = icmp ugt i32 %steps.next.3710, 10000
  br i1 %steps.over.3711, label %failure.3712, label %continue.3713
failure.3712:
  %ctx.field.3714 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 323, ptr %ctx.field.3714, align 4
  %status.diagnostic.3715 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3715, align 4
  ret void
continue.3713:
  %depth.exceeded.3716 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3716, label %failure.3717, label %continue.3718
failure.3717:
  %ctx.field.3719 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 324, ptr %ctx.field.3719, align 4
  %status.diagnostic.3720 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3720, align 4
  ret void
continue.3718:
  %workspace.slot.3721 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3707, ptr %workspace.slot.3721, align 8
  %workspace.slot.3722 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3723 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 72, ptr %outputs, i32 1, ptr %workspace.slot.3722)
  switch i32 %record.make.status.3723, label %runtime.invalid.result.3729 [ i32 0, label %runtime.success.3724 i32 1, label %runtime.invalid.request.3725 i32 2, label %runtime.invalid.reference.3726 i32 3, label %runtime.scratch.capacity.3727 i32 4, label %runtime.retained.capacity.3728 ]
runtime.invalid.request.3725:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3726:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3727:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3728:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3729:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3724:
  %record.make.handle.3730 = load i64, ptr %workspace.slot.3722, align 8
  %ctx.field.3731 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3732 = load i32, ptr %ctx.field.3731, align 4
  %steps.next.3733 = add i32 %steps.current.3732, 1
  store i32 %steps.next.3733, ptr %ctx.field.3731, align 4
  %steps.over.3734 = icmp ugt i32 %steps.next.3733, 10000
  br i1 %steps.over.3734, label %failure.3735, label %continue.3736
failure.3735:
  %ctx.field.3737 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 325, ptr %ctx.field.3737, align 4
  %status.diagnostic.3738 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3738, align 4
  ret void
continue.3736:
  %depth.exceeded.3739 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3739, label %failure.3740, label %continue.3741
failure.3740:
  %ctx.field.3742 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 326, ptr %ctx.field.3742, align 4
  %status.diagnostic.3743 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3743, align 4
  ret void
continue.3741:
  %workspace.slot.3744 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3730, ptr %workspace.slot.3744, align 8
  %workspace.slot.3745 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3746 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 73, ptr %outputs, i32 1, ptr %workspace.slot.3745)
  switch i32 %record.make.status.3746, label %runtime.invalid.result.3752 [ i32 0, label %runtime.success.3747 i32 1, label %runtime.invalid.request.3748 i32 2, label %runtime.invalid.reference.3749 i32 3, label %runtime.scratch.capacity.3750 i32 4, label %runtime.retained.capacity.3751 ]
runtime.invalid.request.3748:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3749:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3750:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3751:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3752:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3747:
  %record.make.handle.3753 = load i64, ptr %workspace.slot.3745, align 8
  %ctx.field.3754 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3755 = load i32, ptr %ctx.field.3754, align 4
  %steps.next.3756 = add i32 %steps.current.3755, 1
  store i32 %steps.next.3756, ptr %ctx.field.3754, align 4
  %steps.over.3757 = icmp ugt i32 %steps.next.3756, 10000
  br i1 %steps.over.3757, label %failure.3758, label %continue.3759
failure.3758:
  %ctx.field.3760 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 327, ptr %ctx.field.3760, align 4
  %status.diagnostic.3761 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3761, align 4
  ret void
continue.3759:
  %depth.exceeded.3762 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3762, label %failure.3763, label %continue.3764
failure.3763:
  %ctx.field.3765 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 328, ptr %ctx.field.3765, align 4
  %status.diagnostic.3766 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3766, align 4
  ret void
continue.3764:
  %workspace.slot.3767 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3753, ptr %workspace.slot.3767, align 8
  %workspace.slot.3768 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3769 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 74, ptr %outputs, i32 1, ptr %workspace.slot.3768)
  switch i32 %record.make.status.3769, label %runtime.invalid.result.3775 [ i32 0, label %runtime.success.3770 i32 1, label %runtime.invalid.request.3771 i32 2, label %runtime.invalid.reference.3772 i32 3, label %runtime.scratch.capacity.3773 i32 4, label %runtime.retained.capacity.3774 ]
runtime.invalid.request.3771:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3772:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3773:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3774:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3775:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3770:
  %record.make.handle.3776 = load i64, ptr %workspace.slot.3768, align 8
  %ctx.field.3777 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3778 = load i32, ptr %ctx.field.3777, align 4
  %steps.next.3779 = add i32 %steps.current.3778, 1
  store i32 %steps.next.3779, ptr %ctx.field.3777, align 4
  %steps.over.3780 = icmp ugt i32 %steps.next.3779, 10000
  br i1 %steps.over.3780, label %failure.3781, label %continue.3782
failure.3781:
  %ctx.field.3783 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 329, ptr %ctx.field.3783, align 4
  %status.diagnostic.3784 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3784, align 4
  ret void
continue.3782:
  %depth.exceeded.3785 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3785, label %failure.3786, label %continue.3787
failure.3786:
  %ctx.field.3788 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 330, ptr %ctx.field.3788, align 4
  %status.diagnostic.3789 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3789, align 4
  ret void
continue.3787:
  %workspace.slot.3790 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3776, ptr %workspace.slot.3790, align 8
  %workspace.slot.3791 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3792 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 75, ptr %outputs, i32 1, ptr %workspace.slot.3791)
  switch i32 %record.make.status.3792, label %runtime.invalid.result.3798 [ i32 0, label %runtime.success.3793 i32 1, label %runtime.invalid.request.3794 i32 2, label %runtime.invalid.reference.3795 i32 3, label %runtime.scratch.capacity.3796 i32 4, label %runtime.retained.capacity.3797 ]
runtime.invalid.request.3794:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3795:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3796:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3797:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3798:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3793:
  %record.make.handle.3799 = load i64, ptr %workspace.slot.3791, align 8
  %ctx.field.3800 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3801 = load i32, ptr %ctx.field.3800, align 4
  %steps.next.3802 = add i32 %steps.current.3801, 1
  store i32 %steps.next.3802, ptr %ctx.field.3800, align 4
  %steps.over.3803 = icmp ugt i32 %steps.next.3802, 10000
  br i1 %steps.over.3803, label %failure.3804, label %continue.3805
failure.3804:
  %ctx.field.3806 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 331, ptr %ctx.field.3806, align 4
  %status.diagnostic.3807 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3807, align 4
  ret void
continue.3805:
  %depth.exceeded.3808 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3808, label %failure.3809, label %continue.3810
failure.3809:
  %ctx.field.3811 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 332, ptr %ctx.field.3811, align 4
  %status.diagnostic.3812 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3812, align 4
  ret void
continue.3810:
  %workspace.slot.3813 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3799, ptr %workspace.slot.3813, align 8
  %workspace.slot.3814 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3815 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 76, ptr %outputs, i32 1, ptr %workspace.slot.3814)
  switch i32 %record.make.status.3815, label %runtime.invalid.result.3821 [ i32 0, label %runtime.success.3816 i32 1, label %runtime.invalid.request.3817 i32 2, label %runtime.invalid.reference.3818 i32 3, label %runtime.scratch.capacity.3819 i32 4, label %runtime.retained.capacity.3820 ]
runtime.invalid.request.3817:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3818:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3819:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3820:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3821:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3816:
  %record.make.handle.3822 = load i64, ptr %workspace.slot.3814, align 8
  %ctx.field.3823 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3824 = load i32, ptr %ctx.field.3823, align 4
  %steps.next.3825 = add i32 %steps.current.3824, 1
  store i32 %steps.next.3825, ptr %ctx.field.3823, align 4
  %steps.over.3826 = icmp ugt i32 %steps.next.3825, 10000
  br i1 %steps.over.3826, label %failure.3827, label %continue.3828
failure.3827:
  %ctx.field.3829 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 333, ptr %ctx.field.3829, align 4
  %status.diagnostic.3830 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3830, align 4
  ret void
continue.3828:
  %depth.exceeded.3831 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3831, label %failure.3832, label %continue.3833
failure.3832:
  %ctx.field.3834 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 334, ptr %ctx.field.3834, align 4
  %status.diagnostic.3835 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3835, align 4
  ret void
continue.3833:
  %workspace.slot.3836 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3822, ptr %workspace.slot.3836, align 8
  %workspace.slot.3837 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3838 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 77, ptr %outputs, i32 1, ptr %workspace.slot.3837)
  switch i32 %record.make.status.3838, label %runtime.invalid.result.3844 [ i32 0, label %runtime.success.3839 i32 1, label %runtime.invalid.request.3840 i32 2, label %runtime.invalid.reference.3841 i32 3, label %runtime.scratch.capacity.3842 i32 4, label %runtime.retained.capacity.3843 ]
runtime.invalid.request.3840:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3841:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3842:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3843:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3844:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3839:
  %record.make.handle.3845 = load i64, ptr %workspace.slot.3837, align 8
  %ctx.field.3846 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3847 = load i32, ptr %ctx.field.3846, align 4
  %steps.next.3848 = add i32 %steps.current.3847, 1
  store i32 %steps.next.3848, ptr %ctx.field.3846, align 4
  %steps.over.3849 = icmp ugt i32 %steps.next.3848, 10000
  br i1 %steps.over.3849, label %failure.3850, label %continue.3851
failure.3850:
  %ctx.field.3852 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 335, ptr %ctx.field.3852, align 4
  %status.diagnostic.3853 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3853, align 4
  ret void
continue.3851:
  %depth.exceeded.3854 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3854, label %failure.3855, label %continue.3856
failure.3855:
  %ctx.field.3857 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 336, ptr %ctx.field.3857, align 4
  %status.diagnostic.3858 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3858, align 4
  ret void
continue.3856:
  %workspace.slot.3859 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3845, ptr %workspace.slot.3859, align 8
  %workspace.slot.3860 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3861 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 78, ptr %outputs, i32 1, ptr %workspace.slot.3860)
  switch i32 %record.make.status.3861, label %runtime.invalid.result.3867 [ i32 0, label %runtime.success.3862 i32 1, label %runtime.invalid.request.3863 i32 2, label %runtime.invalid.reference.3864 i32 3, label %runtime.scratch.capacity.3865 i32 4, label %runtime.retained.capacity.3866 ]
runtime.invalid.request.3863:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3864:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3865:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3866:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3867:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3862:
  %record.make.handle.3868 = load i64, ptr %workspace.slot.3860, align 8
  %ctx.field.3869 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3870 = load i32, ptr %ctx.field.3869, align 4
  %steps.next.3871 = add i32 %steps.current.3870, 1
  store i32 %steps.next.3871, ptr %ctx.field.3869, align 4
  %steps.over.3872 = icmp ugt i32 %steps.next.3871, 10000
  br i1 %steps.over.3872, label %failure.3873, label %continue.3874
failure.3873:
  %ctx.field.3875 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 337, ptr %ctx.field.3875, align 4
  %status.diagnostic.3876 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3876, align 4
  ret void
continue.3874:
  %depth.exceeded.3877 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3877, label %failure.3878, label %continue.3879
failure.3878:
  %ctx.field.3880 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 338, ptr %ctx.field.3880, align 4
  %status.diagnostic.3881 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3881, align 4
  ret void
continue.3879:
  %workspace.slot.3882 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3868, ptr %workspace.slot.3882, align 8
  %workspace.slot.3883 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3884 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 79, ptr %outputs, i32 1, ptr %workspace.slot.3883)
  switch i32 %record.make.status.3884, label %runtime.invalid.result.3890 [ i32 0, label %runtime.success.3885 i32 1, label %runtime.invalid.request.3886 i32 2, label %runtime.invalid.reference.3887 i32 3, label %runtime.scratch.capacity.3888 i32 4, label %runtime.retained.capacity.3889 ]
runtime.invalid.request.3886:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3887:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3888:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3889:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3890:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3885:
  %record.make.handle.3891 = load i64, ptr %workspace.slot.3883, align 8
  %ctx.field.3892 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3893 = load i32, ptr %ctx.field.3892, align 4
  %steps.next.3894 = add i32 %steps.current.3893, 1
  store i32 %steps.next.3894, ptr %ctx.field.3892, align 4
  %steps.over.3895 = icmp ugt i32 %steps.next.3894, 10000
  br i1 %steps.over.3895, label %failure.3896, label %continue.3897
failure.3896:
  %ctx.field.3898 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 339, ptr %ctx.field.3898, align 4
  %status.diagnostic.3899 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3899, align 4
  ret void
continue.3897:
  %depth.exceeded.3900 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3900, label %failure.3901, label %continue.3902
failure.3901:
  %ctx.field.3903 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 340, ptr %ctx.field.3903, align 4
  %status.diagnostic.3904 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3904, align 4
  ret void
continue.3902:
  %workspace.slot.3905 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3891, ptr %workspace.slot.3905, align 8
  %workspace.slot.3906 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3907 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 80, ptr %outputs, i32 1, ptr %workspace.slot.3906)
  switch i32 %record.make.status.3907, label %runtime.invalid.result.3913 [ i32 0, label %runtime.success.3908 i32 1, label %runtime.invalid.request.3909 i32 2, label %runtime.invalid.reference.3910 i32 3, label %runtime.scratch.capacity.3911 i32 4, label %runtime.retained.capacity.3912 ]
runtime.invalid.request.3909:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3910:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3911:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3912:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3913:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3908:
  %record.make.handle.3914 = load i64, ptr %workspace.slot.3906, align 8
  %ctx.field.3915 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3916 = load i32, ptr %ctx.field.3915, align 4
  %steps.next.3917 = add i32 %steps.current.3916, 1
  store i32 %steps.next.3917, ptr %ctx.field.3915, align 4
  %steps.over.3918 = icmp ugt i32 %steps.next.3917, 10000
  br i1 %steps.over.3918, label %failure.3919, label %continue.3920
failure.3919:
  %ctx.field.3921 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 341, ptr %ctx.field.3921, align 4
  %status.diagnostic.3922 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3922, align 4
  ret void
continue.3920:
  %depth.exceeded.3923 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3923, label %failure.3924, label %continue.3925
failure.3924:
  %ctx.field.3926 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 342, ptr %ctx.field.3926, align 4
  %status.diagnostic.3927 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3927, align 4
  ret void
continue.3925:
  %workspace.slot.3928 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3914, ptr %workspace.slot.3928, align 8
  %workspace.slot.3929 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3930 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 81, ptr %outputs, i32 1, ptr %workspace.slot.3929)
  switch i32 %record.make.status.3930, label %runtime.invalid.result.3936 [ i32 0, label %runtime.success.3931 i32 1, label %runtime.invalid.request.3932 i32 2, label %runtime.invalid.reference.3933 i32 3, label %runtime.scratch.capacity.3934 i32 4, label %runtime.retained.capacity.3935 ]
runtime.invalid.request.3932:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3933:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3934:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3935:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3936:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3931:
  %record.make.handle.3937 = load i64, ptr %workspace.slot.3929, align 8
  %ctx.field.3938 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3939 = load i32, ptr %ctx.field.3938, align 4
  %steps.next.3940 = add i32 %steps.current.3939, 1
  store i32 %steps.next.3940, ptr %ctx.field.3938, align 4
  %steps.over.3941 = icmp ugt i32 %steps.next.3940, 10000
  br i1 %steps.over.3941, label %failure.3942, label %continue.3943
failure.3942:
  %ctx.field.3944 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 343, ptr %ctx.field.3944, align 4
  %status.diagnostic.3945 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3945, align 4
  ret void
continue.3943:
  %depth.exceeded.3946 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3946, label %failure.3947, label %continue.3948
failure.3947:
  %ctx.field.3949 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 344, ptr %ctx.field.3949, align 4
  %status.diagnostic.3950 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3950, align 4
  ret void
continue.3948:
  %workspace.slot.3951 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3937, ptr %workspace.slot.3951, align 8
  %workspace.slot.3952 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3953 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 83, ptr %outputs, i32 1, ptr %workspace.slot.3952)
  switch i32 %record.make.status.3953, label %runtime.invalid.result.3959 [ i32 0, label %runtime.success.3954 i32 1, label %runtime.invalid.request.3955 i32 2, label %runtime.invalid.reference.3956 i32 3, label %runtime.scratch.capacity.3957 i32 4, label %runtime.retained.capacity.3958 ]
runtime.invalid.request.3955:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3956:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3957:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3958:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3959:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3954:
  %record.make.handle.3960 = load i64, ptr %workspace.slot.3952, align 8
  %ctx.field.3961 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3962 = load i32, ptr %ctx.field.3961, align 4
  %steps.next.3963 = add i32 %steps.current.3962, 1
  store i32 %steps.next.3963, ptr %ctx.field.3961, align 4
  %steps.over.3964 = icmp ugt i32 %steps.next.3963, 10000
  br i1 %steps.over.3964, label %failure.3965, label %continue.3966
failure.3965:
  %ctx.field.3967 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 345, ptr %ctx.field.3967, align 4
  %status.diagnostic.3968 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3968, align 4
  ret void
continue.3966:
  %depth.exceeded.3969 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3969, label %failure.3970, label %continue.3971
failure.3970:
  %ctx.field.3972 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 346, ptr %ctx.field.3972, align 4
  %status.diagnostic.3973 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3973, align 4
  ret void
continue.3971:
  %workspace.slot.3974 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3960, ptr %workspace.slot.3974, align 8
  %workspace.slot.3975 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3976 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 84, ptr %outputs, i32 1, ptr %workspace.slot.3975)
  switch i32 %record.make.status.3976, label %runtime.invalid.result.3982 [ i32 0, label %runtime.success.3977 i32 1, label %runtime.invalid.request.3978 i32 2, label %runtime.invalid.reference.3979 i32 3, label %runtime.scratch.capacity.3980 i32 4, label %runtime.retained.capacity.3981 ]
runtime.invalid.request.3978:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.3979:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.3980:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.3981:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.3982:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.3977:
  %record.make.handle.3983 = load i64, ptr %workspace.slot.3975, align 8
  %ctx.field.3984 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.3985 = load i32, ptr %ctx.field.3984, align 4
  %steps.next.3986 = add i32 %steps.current.3985, 1
  store i32 %steps.next.3986, ptr %ctx.field.3984, align 4
  %steps.over.3987 = icmp ugt i32 %steps.next.3986, 10000
  br i1 %steps.over.3987, label %failure.3988, label %continue.3989
failure.3988:
  %ctx.field.3990 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 347, ptr %ctx.field.3990, align 4
  %status.diagnostic.3991 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3991, align 4
  ret void
continue.3989:
  %depth.exceeded.3992 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.3992, label %failure.3993, label %continue.3994
failure.3993:
  %ctx.field.3995 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 348, ptr %ctx.field.3995, align 4
  %status.diagnostic.3996 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.3996, align 4
  ret void
continue.3994:
  %workspace.slot.3997 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.3983, ptr %workspace.slot.3997, align 8
  %workspace.slot.3998 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.3999 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 85, ptr %outputs, i32 1, ptr %workspace.slot.3998)
  switch i32 %record.make.status.3999, label %runtime.invalid.result.4005 [ i32 0, label %runtime.success.4000 i32 1, label %runtime.invalid.request.4001 i32 2, label %runtime.invalid.reference.4002 i32 3, label %runtime.scratch.capacity.4003 i32 4, label %runtime.retained.capacity.4004 ]
runtime.invalid.request.4001:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4002:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4003:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4004:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4005:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4000:
  %record.make.handle.4006 = load i64, ptr %workspace.slot.3998, align 8
  %ctx.field.4007 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4008 = load i32, ptr %ctx.field.4007, align 4
  %steps.next.4009 = add i32 %steps.current.4008, 1
  store i32 %steps.next.4009, ptr %ctx.field.4007, align 4
  %steps.over.4010 = icmp ugt i32 %steps.next.4009, 10000
  br i1 %steps.over.4010, label %failure.4011, label %continue.4012
failure.4011:
  %ctx.field.4013 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 349, ptr %ctx.field.4013, align 4
  %status.diagnostic.4014 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4014, align 4
  ret void
continue.4012:
  %depth.exceeded.4015 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4015, label %failure.4016, label %continue.4017
failure.4016:
  %ctx.field.4018 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 350, ptr %ctx.field.4018, align 4
  %status.diagnostic.4019 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4019, align 4
  ret void
continue.4017:
  %workspace.slot.4020 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4006, ptr %workspace.slot.4020, align 8
  %workspace.slot.4021 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4022 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 86, ptr %outputs, i32 1, ptr %workspace.slot.4021)
  switch i32 %record.make.status.4022, label %runtime.invalid.result.4028 [ i32 0, label %runtime.success.4023 i32 1, label %runtime.invalid.request.4024 i32 2, label %runtime.invalid.reference.4025 i32 3, label %runtime.scratch.capacity.4026 i32 4, label %runtime.retained.capacity.4027 ]
runtime.invalid.request.4024:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4025:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4026:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4027:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4028:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4023:
  %record.make.handle.4029 = load i64, ptr %workspace.slot.4021, align 8
  %ctx.field.4030 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4031 = load i32, ptr %ctx.field.4030, align 4
  %steps.next.4032 = add i32 %steps.current.4031, 1
  store i32 %steps.next.4032, ptr %ctx.field.4030, align 4
  %steps.over.4033 = icmp ugt i32 %steps.next.4032, 10000
  br i1 %steps.over.4033, label %failure.4034, label %continue.4035
failure.4034:
  %ctx.field.4036 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 351, ptr %ctx.field.4036, align 4
  %status.diagnostic.4037 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4037, align 4
  ret void
continue.4035:
  %depth.exceeded.4038 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4038, label %failure.4039, label %continue.4040
failure.4039:
  %ctx.field.4041 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 352, ptr %ctx.field.4041, align 4
  %status.diagnostic.4042 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4042, align 4
  ret void
continue.4040:
  %workspace.slot.4043 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4029, ptr %workspace.slot.4043, align 8
  %workspace.slot.4044 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4045 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 87, ptr %outputs, i32 1, ptr %workspace.slot.4044)
  switch i32 %record.make.status.4045, label %runtime.invalid.result.4051 [ i32 0, label %runtime.success.4046 i32 1, label %runtime.invalid.request.4047 i32 2, label %runtime.invalid.reference.4048 i32 3, label %runtime.scratch.capacity.4049 i32 4, label %runtime.retained.capacity.4050 ]
runtime.invalid.request.4047:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4048:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4049:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4050:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4051:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4046:
  %record.make.handle.4052 = load i64, ptr %workspace.slot.4044, align 8
  %ctx.field.4053 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4054 = load i32, ptr %ctx.field.4053, align 4
  %steps.next.4055 = add i32 %steps.current.4054, 1
  store i32 %steps.next.4055, ptr %ctx.field.4053, align 4
  %steps.over.4056 = icmp ugt i32 %steps.next.4055, 10000
  br i1 %steps.over.4056, label %failure.4057, label %continue.4058
failure.4057:
  %ctx.field.4059 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 353, ptr %ctx.field.4059, align 4
  %status.diagnostic.4060 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4060, align 4
  ret void
continue.4058:
  %depth.exceeded.4061 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4061, label %failure.4062, label %continue.4063
failure.4062:
  %ctx.field.4064 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 354, ptr %ctx.field.4064, align 4
  %status.diagnostic.4065 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4065, align 4
  ret void
continue.4063:
  %workspace.slot.4066 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4052, ptr %workspace.slot.4066, align 8
  %workspace.slot.4067 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4068 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 88, ptr %outputs, i32 1, ptr %workspace.slot.4067)
  switch i32 %record.make.status.4068, label %runtime.invalid.result.4074 [ i32 0, label %runtime.success.4069 i32 1, label %runtime.invalid.request.4070 i32 2, label %runtime.invalid.reference.4071 i32 3, label %runtime.scratch.capacity.4072 i32 4, label %runtime.retained.capacity.4073 ]
runtime.invalid.request.4070:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4071:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4072:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4073:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4074:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4069:
  %record.make.handle.4075 = load i64, ptr %workspace.slot.4067, align 8
  %ctx.field.4076 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4077 = load i32, ptr %ctx.field.4076, align 4
  %steps.next.4078 = add i32 %steps.current.4077, 1
  store i32 %steps.next.4078, ptr %ctx.field.4076, align 4
  %steps.over.4079 = icmp ugt i32 %steps.next.4078, 10000
  br i1 %steps.over.4079, label %failure.4080, label %continue.4081
failure.4080:
  %ctx.field.4082 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 355, ptr %ctx.field.4082, align 4
  %status.diagnostic.4083 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4083, align 4
  ret void
continue.4081:
  %depth.exceeded.4084 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4084, label %failure.4085, label %continue.4086
failure.4085:
  %ctx.field.4087 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 356, ptr %ctx.field.4087, align 4
  %status.diagnostic.4088 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4088, align 4
  ret void
continue.4086:
  %workspace.slot.4089 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4075, ptr %workspace.slot.4089, align 8
  %workspace.slot.4090 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4091 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 89, ptr %outputs, i32 1, ptr %workspace.slot.4090)
  switch i32 %record.make.status.4091, label %runtime.invalid.result.4097 [ i32 0, label %runtime.success.4092 i32 1, label %runtime.invalid.request.4093 i32 2, label %runtime.invalid.reference.4094 i32 3, label %runtime.scratch.capacity.4095 i32 4, label %runtime.retained.capacity.4096 ]
runtime.invalid.request.4093:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4094:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4095:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4096:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4097:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4092:
  %record.make.handle.4098 = load i64, ptr %workspace.slot.4090, align 8
  %ctx.field.4099 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4100 = load i32, ptr %ctx.field.4099, align 4
  %steps.next.4101 = add i32 %steps.current.4100, 1
  store i32 %steps.next.4101, ptr %ctx.field.4099, align 4
  %steps.over.4102 = icmp ugt i32 %steps.next.4101, 10000
  br i1 %steps.over.4102, label %failure.4103, label %continue.4104
failure.4103:
  %ctx.field.4105 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 357, ptr %ctx.field.4105, align 4
  %status.diagnostic.4106 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4106, align 4
  ret void
continue.4104:
  %depth.exceeded.4107 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4107, label %failure.4108, label %continue.4109
failure.4108:
  %ctx.field.4110 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 358, ptr %ctx.field.4110, align 4
  %status.diagnostic.4111 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4111, align 4
  ret void
continue.4109:
  %workspace.slot.4112 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4098, ptr %workspace.slot.4112, align 8
  %workspace.slot.4113 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4114 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 90, ptr %outputs, i32 1, ptr %workspace.slot.4113)
  switch i32 %record.make.status.4114, label %runtime.invalid.result.4120 [ i32 0, label %runtime.success.4115 i32 1, label %runtime.invalid.request.4116 i32 2, label %runtime.invalid.reference.4117 i32 3, label %runtime.scratch.capacity.4118 i32 4, label %runtime.retained.capacity.4119 ]
runtime.invalid.request.4116:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4117:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4118:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4119:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4120:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4115:
  %record.make.handle.4121 = load i64, ptr %workspace.slot.4113, align 8
  %ctx.field.4122 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4123 = load i32, ptr %ctx.field.4122, align 4
  %steps.next.4124 = add i32 %steps.current.4123, 1
  store i32 %steps.next.4124, ptr %ctx.field.4122, align 4
  %steps.over.4125 = icmp ugt i32 %steps.next.4124, 10000
  br i1 %steps.over.4125, label %failure.4126, label %continue.4127
failure.4126:
  %ctx.field.4128 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 359, ptr %ctx.field.4128, align 4
  %status.diagnostic.4129 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4129, align 4
  ret void
continue.4127:
  %depth.exceeded.4130 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4130, label %failure.4131, label %continue.4132
failure.4131:
  %ctx.field.4133 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 360, ptr %ctx.field.4133, align 4
  %status.diagnostic.4134 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4134, align 4
  ret void
continue.4132:
  %workspace.slot.4135 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4121, ptr %workspace.slot.4135, align 8
  %workspace.slot.4136 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4137 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 91, ptr %outputs, i32 1, ptr %workspace.slot.4136)
  switch i32 %record.make.status.4137, label %runtime.invalid.result.4143 [ i32 0, label %runtime.success.4138 i32 1, label %runtime.invalid.request.4139 i32 2, label %runtime.invalid.reference.4140 i32 3, label %runtime.scratch.capacity.4141 i32 4, label %runtime.retained.capacity.4142 ]
runtime.invalid.request.4139:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4140:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4141:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4142:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4143:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4138:
  %record.make.handle.4144 = load i64, ptr %workspace.slot.4136, align 8
  %ctx.field.4145 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4146 = load i32, ptr %ctx.field.4145, align 4
  %steps.next.4147 = add i32 %steps.current.4146, 1
  store i32 %steps.next.4147, ptr %ctx.field.4145, align 4
  %steps.over.4148 = icmp ugt i32 %steps.next.4147, 10000
  br i1 %steps.over.4148, label %failure.4149, label %continue.4150
failure.4149:
  %ctx.field.4151 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 361, ptr %ctx.field.4151, align 4
  %status.diagnostic.4152 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4152, align 4
  ret void
continue.4150:
  %depth.exceeded.4153 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4153, label %failure.4154, label %continue.4155
failure.4154:
  %ctx.field.4156 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 362, ptr %ctx.field.4156, align 4
  %status.diagnostic.4157 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4157, align 4
  ret void
continue.4155:
  %workspace.slot.4158 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4144, ptr %workspace.slot.4158, align 8
  %workspace.slot.4159 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4160 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 92, ptr %outputs, i32 1, ptr %workspace.slot.4159)
  switch i32 %record.make.status.4160, label %runtime.invalid.result.4166 [ i32 0, label %runtime.success.4161 i32 1, label %runtime.invalid.request.4162 i32 2, label %runtime.invalid.reference.4163 i32 3, label %runtime.scratch.capacity.4164 i32 4, label %runtime.retained.capacity.4165 ]
runtime.invalid.request.4162:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4163:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4164:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4165:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4166:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4161:
  %record.make.handle.4167 = load i64, ptr %workspace.slot.4159, align 8
  %ctx.field.4168 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4169 = load i32, ptr %ctx.field.4168, align 4
  %steps.next.4170 = add i32 %steps.current.4169, 1
  store i32 %steps.next.4170, ptr %ctx.field.4168, align 4
  %steps.over.4171 = icmp ugt i32 %steps.next.4170, 10000
  br i1 %steps.over.4171, label %failure.4172, label %continue.4173
failure.4172:
  %ctx.field.4174 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 363, ptr %ctx.field.4174, align 4
  %status.diagnostic.4175 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4175, align 4
  ret void
continue.4173:
  %depth.exceeded.4176 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4176, label %failure.4177, label %continue.4178
failure.4177:
  %ctx.field.4179 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 364, ptr %ctx.field.4179, align 4
  %status.diagnostic.4180 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4180, align 4
  ret void
continue.4178:
  %workspace.slot.4181 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4167, ptr %workspace.slot.4181, align 8
  %workspace.slot.4182 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4183 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 94, ptr %outputs, i32 1, ptr %workspace.slot.4182)
  switch i32 %record.make.status.4183, label %runtime.invalid.result.4189 [ i32 0, label %runtime.success.4184 i32 1, label %runtime.invalid.request.4185 i32 2, label %runtime.invalid.reference.4186 i32 3, label %runtime.scratch.capacity.4187 i32 4, label %runtime.retained.capacity.4188 ]
runtime.invalid.request.4185:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4186:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4187:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4188:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4189:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4184:
  %record.make.handle.4190 = load i64, ptr %workspace.slot.4182, align 8
  %ctx.field.4191 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4192 = load i32, ptr %ctx.field.4191, align 4
  %steps.next.4193 = add i32 %steps.current.4192, 1
  store i32 %steps.next.4193, ptr %ctx.field.4191, align 4
  %steps.over.4194 = icmp ugt i32 %steps.next.4193, 10000
  br i1 %steps.over.4194, label %failure.4195, label %continue.4196
failure.4195:
  %ctx.field.4197 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 365, ptr %ctx.field.4197, align 4
  %status.diagnostic.4198 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4198, align 4
  ret void
continue.4196:
  %depth.exceeded.4199 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4199, label %failure.4200, label %continue.4201
failure.4200:
  %ctx.field.4202 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 366, ptr %ctx.field.4202, align 4
  %status.diagnostic.4203 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4203, align 4
  ret void
continue.4201:
  %workspace.slot.4204 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4190, ptr %workspace.slot.4204, align 8
  %workspace.slot.4205 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4206 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 95, ptr %outputs, i32 1, ptr %workspace.slot.4205)
  switch i32 %record.make.status.4206, label %runtime.invalid.result.4212 [ i32 0, label %runtime.success.4207 i32 1, label %runtime.invalid.request.4208 i32 2, label %runtime.invalid.reference.4209 i32 3, label %runtime.scratch.capacity.4210 i32 4, label %runtime.retained.capacity.4211 ]
runtime.invalid.request.4208:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4209:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4210:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4211:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4212:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4207:
  %record.make.handle.4213 = load i64, ptr %workspace.slot.4205, align 8
  %ctx.field.4214 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4215 = load i32, ptr %ctx.field.4214, align 4
  %steps.next.4216 = add i32 %steps.current.4215, 1
  store i32 %steps.next.4216, ptr %ctx.field.4214, align 4
  %steps.over.4217 = icmp ugt i32 %steps.next.4216, 10000
  br i1 %steps.over.4217, label %failure.4218, label %continue.4219
failure.4218:
  %ctx.field.4220 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 367, ptr %ctx.field.4220, align 4
  %status.diagnostic.4221 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4221, align 4
  ret void
continue.4219:
  %depth.exceeded.4222 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4222, label %failure.4223, label %continue.4224
failure.4223:
  %ctx.field.4225 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 368, ptr %ctx.field.4225, align 4
  %status.diagnostic.4226 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4226, align 4
  ret void
continue.4224:
  %workspace.slot.4227 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4213, ptr %workspace.slot.4227, align 8
  %workspace.slot.4228 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4229 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 96, ptr %outputs, i32 1, ptr %workspace.slot.4228)
  switch i32 %record.make.status.4229, label %runtime.invalid.result.4235 [ i32 0, label %runtime.success.4230 i32 1, label %runtime.invalid.request.4231 i32 2, label %runtime.invalid.reference.4232 i32 3, label %runtime.scratch.capacity.4233 i32 4, label %runtime.retained.capacity.4234 ]
runtime.invalid.request.4231:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4232:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4233:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4234:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4235:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4230:
  %record.make.handle.4236 = load i64, ptr %workspace.slot.4228, align 8
  %ctx.field.4237 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4238 = load i32, ptr %ctx.field.4237, align 4
  %steps.next.4239 = add i32 %steps.current.4238, 1
  store i32 %steps.next.4239, ptr %ctx.field.4237, align 4
  %steps.over.4240 = icmp ugt i32 %steps.next.4239, 10000
  br i1 %steps.over.4240, label %failure.4241, label %continue.4242
failure.4241:
  %ctx.field.4243 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 369, ptr %ctx.field.4243, align 4
  %status.diagnostic.4244 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4244, align 4
  ret void
continue.4242:
  %depth.exceeded.4245 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4245, label %failure.4246, label %continue.4247
failure.4246:
  %ctx.field.4248 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 370, ptr %ctx.field.4248, align 4
  %status.diagnostic.4249 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4249, align 4
  ret void
continue.4247:
  %workspace.slot.4250 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4236, ptr %workspace.slot.4250, align 8
  %workspace.slot.4251 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4252 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 97, ptr %outputs, i32 1, ptr %workspace.slot.4251)
  switch i32 %record.make.status.4252, label %runtime.invalid.result.4258 [ i32 0, label %runtime.success.4253 i32 1, label %runtime.invalid.request.4254 i32 2, label %runtime.invalid.reference.4255 i32 3, label %runtime.scratch.capacity.4256 i32 4, label %runtime.retained.capacity.4257 ]
runtime.invalid.request.4254:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4255:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4256:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4257:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4258:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4253:
  %record.make.handle.4259 = load i64, ptr %workspace.slot.4251, align 8
  %ctx.field.4260 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4261 = load i32, ptr %ctx.field.4260, align 4
  %steps.next.4262 = add i32 %steps.current.4261, 1
  store i32 %steps.next.4262, ptr %ctx.field.4260, align 4
  %steps.over.4263 = icmp ugt i32 %steps.next.4262, 10000
  br i1 %steps.over.4263, label %failure.4264, label %continue.4265
failure.4264:
  %ctx.field.4266 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 371, ptr %ctx.field.4266, align 4
  %status.diagnostic.4267 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4267, align 4
  ret void
continue.4265:
  %depth.exceeded.4268 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4268, label %failure.4269, label %continue.4270
failure.4269:
  %ctx.field.4271 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 372, ptr %ctx.field.4271, align 4
  %status.diagnostic.4272 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4272, align 4
  ret void
continue.4270:
  %workspace.slot.4273 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4259, ptr %workspace.slot.4273, align 8
  %workspace.slot.4274 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4275 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 98, ptr %outputs, i32 1, ptr %workspace.slot.4274)
  switch i32 %record.make.status.4275, label %runtime.invalid.result.4281 [ i32 0, label %runtime.success.4276 i32 1, label %runtime.invalid.request.4277 i32 2, label %runtime.invalid.reference.4278 i32 3, label %runtime.scratch.capacity.4279 i32 4, label %runtime.retained.capacity.4280 ]
runtime.invalid.request.4277:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4278:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4279:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4280:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4281:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4276:
  %record.make.handle.4282 = load i64, ptr %workspace.slot.4274, align 8
  %ctx.field.4283 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4284 = load i32, ptr %ctx.field.4283, align 4
  %steps.next.4285 = add i32 %steps.current.4284, 1
  store i32 %steps.next.4285, ptr %ctx.field.4283, align 4
  %steps.over.4286 = icmp ugt i32 %steps.next.4285, 10000
  br i1 %steps.over.4286, label %failure.4287, label %continue.4288
failure.4287:
  %ctx.field.4289 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 373, ptr %ctx.field.4289, align 4
  %status.diagnostic.4290 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4290, align 4
  ret void
continue.4288:
  %depth.exceeded.4291 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4291, label %failure.4292, label %continue.4293
failure.4292:
  %ctx.field.4294 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 374, ptr %ctx.field.4294, align 4
  %status.diagnostic.4295 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4295, align 4
  ret void
continue.4293:
  %workspace.slot.4296 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4282, ptr %workspace.slot.4296, align 8
  %workspace.slot.4297 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4298 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 99, ptr %outputs, i32 1, ptr %workspace.slot.4297)
  switch i32 %record.make.status.4298, label %runtime.invalid.result.4304 [ i32 0, label %runtime.success.4299 i32 1, label %runtime.invalid.request.4300 i32 2, label %runtime.invalid.reference.4301 i32 3, label %runtime.scratch.capacity.4302 i32 4, label %runtime.retained.capacity.4303 ]
runtime.invalid.request.4300:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4301:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4302:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4303:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4304:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4299:
  %record.make.handle.4305 = load i64, ptr %workspace.slot.4297, align 8
  %ctx.field.4306 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4307 = load i32, ptr %ctx.field.4306, align 4
  %steps.next.4308 = add i32 %steps.current.4307, 1
  store i32 %steps.next.4308, ptr %ctx.field.4306, align 4
  %steps.over.4309 = icmp ugt i32 %steps.next.4308, 10000
  br i1 %steps.over.4309, label %failure.4310, label %continue.4311
failure.4310:
  %ctx.field.4312 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 375, ptr %ctx.field.4312, align 4
  %status.diagnostic.4313 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4313, align 4
  ret void
continue.4311:
  %depth.exceeded.4314 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4314, label %failure.4315, label %continue.4316
failure.4315:
  %ctx.field.4317 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 376, ptr %ctx.field.4317, align 4
  %status.diagnostic.4318 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4318, align 4
  ret void
continue.4316:
  %workspace.slot.4319 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4305, ptr %workspace.slot.4319, align 8
  %workspace.slot.4320 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4321 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 100, ptr %outputs, i32 1, ptr %workspace.slot.4320)
  switch i32 %record.make.status.4321, label %runtime.invalid.result.4327 [ i32 0, label %runtime.success.4322 i32 1, label %runtime.invalid.request.4323 i32 2, label %runtime.invalid.reference.4324 i32 3, label %runtime.scratch.capacity.4325 i32 4, label %runtime.retained.capacity.4326 ]
runtime.invalid.request.4323:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4324:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4325:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4326:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4327:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4322:
  %record.make.handle.4328 = load i64, ptr %workspace.slot.4320, align 8
  %ctx.field.4329 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4330 = load i32, ptr %ctx.field.4329, align 4
  %steps.next.4331 = add i32 %steps.current.4330, 1
  store i32 %steps.next.4331, ptr %ctx.field.4329, align 4
  %steps.over.4332 = icmp ugt i32 %steps.next.4331, 10000
  br i1 %steps.over.4332, label %failure.4333, label %continue.4334
failure.4333:
  %ctx.field.4335 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 377, ptr %ctx.field.4335, align 4
  %status.diagnostic.4336 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4336, align 4
  ret void
continue.4334:
  %depth.exceeded.4337 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4337, label %failure.4338, label %continue.4339
failure.4338:
  %ctx.field.4340 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 378, ptr %ctx.field.4340, align 4
  %status.diagnostic.4341 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4341, align 4
  ret void
continue.4339:
  %workspace.slot.4342 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4328, ptr %workspace.slot.4342, align 8
  %workspace.slot.4343 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4344 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 101, ptr %outputs, i32 1, ptr %workspace.slot.4343)
  switch i32 %record.make.status.4344, label %runtime.invalid.result.4350 [ i32 0, label %runtime.success.4345 i32 1, label %runtime.invalid.request.4346 i32 2, label %runtime.invalid.reference.4347 i32 3, label %runtime.scratch.capacity.4348 i32 4, label %runtime.retained.capacity.4349 ]
runtime.invalid.request.4346:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4347:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4348:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4349:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4350:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4345:
  %record.make.handle.4351 = load i64, ptr %workspace.slot.4343, align 8
  %ctx.field.4352 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4353 = load i32, ptr %ctx.field.4352, align 4
  %steps.next.4354 = add i32 %steps.current.4353, 1
  store i32 %steps.next.4354, ptr %ctx.field.4352, align 4
  %steps.over.4355 = icmp ugt i32 %steps.next.4354, 10000
  br i1 %steps.over.4355, label %failure.4356, label %continue.4357
failure.4356:
  %ctx.field.4358 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 379, ptr %ctx.field.4358, align 4
  %status.diagnostic.4359 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4359, align 4
  ret void
continue.4357:
  %depth.exceeded.4360 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4360, label %failure.4361, label %continue.4362
failure.4361:
  %ctx.field.4363 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 380, ptr %ctx.field.4363, align 4
  %status.diagnostic.4364 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4364, align 4
  ret void
continue.4362:
  %workspace.slot.4365 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4351, ptr %workspace.slot.4365, align 8
  %workspace.slot.4366 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4367 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 102, ptr %outputs, i32 1, ptr %workspace.slot.4366)
  switch i32 %record.make.status.4367, label %runtime.invalid.result.4373 [ i32 0, label %runtime.success.4368 i32 1, label %runtime.invalid.request.4369 i32 2, label %runtime.invalid.reference.4370 i32 3, label %runtime.scratch.capacity.4371 i32 4, label %runtime.retained.capacity.4372 ]
runtime.invalid.request.4369:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4370:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4371:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4372:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4373:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4368:
  %record.make.handle.4374 = load i64, ptr %workspace.slot.4366, align 8
  %ctx.field.4375 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4376 = load i32, ptr %ctx.field.4375, align 4
  %steps.next.4377 = add i32 %steps.current.4376, 1
  store i32 %steps.next.4377, ptr %ctx.field.4375, align 4
  %steps.over.4378 = icmp ugt i32 %steps.next.4377, 10000
  br i1 %steps.over.4378, label %failure.4379, label %continue.4380
failure.4379:
  %ctx.field.4381 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 381, ptr %ctx.field.4381, align 4
  %status.diagnostic.4382 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4382, align 4
  ret void
continue.4380:
  %depth.exceeded.4383 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4383, label %failure.4384, label %continue.4385
failure.4384:
  %ctx.field.4386 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 382, ptr %ctx.field.4386, align 4
  %status.diagnostic.4387 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4387, align 4
  ret void
continue.4385:
  %workspace.slot.4388 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4374, ptr %workspace.slot.4388, align 8
  %workspace.slot.4389 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4390 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 103, ptr %outputs, i32 1, ptr %workspace.slot.4389)
  switch i32 %record.make.status.4390, label %runtime.invalid.result.4396 [ i32 0, label %runtime.success.4391 i32 1, label %runtime.invalid.request.4392 i32 2, label %runtime.invalid.reference.4393 i32 3, label %runtime.scratch.capacity.4394 i32 4, label %runtime.retained.capacity.4395 ]
runtime.invalid.request.4392:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4393:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4394:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4395:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4396:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4391:
  %record.make.handle.4397 = load i64, ptr %workspace.slot.4389, align 8
  %ctx.field.4398 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4399 = load i32, ptr %ctx.field.4398, align 4
  %steps.next.4400 = add i32 %steps.current.4399, 1
  store i32 %steps.next.4400, ptr %ctx.field.4398, align 4
  %steps.over.4401 = icmp ugt i32 %steps.next.4400, 10000
  br i1 %steps.over.4401, label %failure.4402, label %continue.4403
failure.4402:
  %ctx.field.4404 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 383, ptr %ctx.field.4404, align 4
  %status.diagnostic.4405 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4405, align 4
  ret void
continue.4403:
  %depth.exceeded.4406 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4406, label %failure.4407, label %continue.4408
failure.4407:
  %ctx.field.4409 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 384, ptr %ctx.field.4409, align 4
  %status.diagnostic.4410 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4410, align 4
  ret void
continue.4408:
  %workspace.slot.4411 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4397, ptr %workspace.slot.4411, align 8
  %workspace.slot.4412 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4413 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 105, ptr %outputs, i32 1, ptr %workspace.slot.4412)
  switch i32 %record.make.status.4413, label %runtime.invalid.result.4419 [ i32 0, label %runtime.success.4414 i32 1, label %runtime.invalid.request.4415 i32 2, label %runtime.invalid.reference.4416 i32 3, label %runtime.scratch.capacity.4417 i32 4, label %runtime.retained.capacity.4418 ]
runtime.invalid.request.4415:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4416:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4417:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4418:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4419:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4414:
  %record.make.handle.4420 = load i64, ptr %workspace.slot.4412, align 8
  %ctx.field.4421 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4422 = load i32, ptr %ctx.field.4421, align 4
  %steps.next.4423 = add i32 %steps.current.4422, 1
  store i32 %steps.next.4423, ptr %ctx.field.4421, align 4
  %steps.over.4424 = icmp ugt i32 %steps.next.4423, 10000
  br i1 %steps.over.4424, label %failure.4425, label %continue.4426
failure.4425:
  %ctx.field.4427 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 385, ptr %ctx.field.4427, align 4
  %status.diagnostic.4428 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4428, align 4
  ret void
continue.4426:
  %depth.exceeded.4429 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4429, label %failure.4430, label %continue.4431
failure.4430:
  %ctx.field.4432 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 386, ptr %ctx.field.4432, align 4
  %status.diagnostic.4433 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4433, align 4
  ret void
continue.4431:
  %workspace.slot.4434 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4420, ptr %workspace.slot.4434, align 8
  %workspace.slot.4435 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4436 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 106, ptr %outputs, i32 1, ptr %workspace.slot.4435)
  switch i32 %record.make.status.4436, label %runtime.invalid.result.4442 [ i32 0, label %runtime.success.4437 i32 1, label %runtime.invalid.request.4438 i32 2, label %runtime.invalid.reference.4439 i32 3, label %runtime.scratch.capacity.4440 i32 4, label %runtime.retained.capacity.4441 ]
runtime.invalid.request.4438:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4439:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4440:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4441:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4442:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4437:
  %record.make.handle.4443 = load i64, ptr %workspace.slot.4435, align 8
  %ctx.field.4444 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4445 = load i32, ptr %ctx.field.4444, align 4
  %steps.next.4446 = add i32 %steps.current.4445, 1
  store i32 %steps.next.4446, ptr %ctx.field.4444, align 4
  %steps.over.4447 = icmp ugt i32 %steps.next.4446, 10000
  br i1 %steps.over.4447, label %failure.4448, label %continue.4449
failure.4448:
  %ctx.field.4450 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 387, ptr %ctx.field.4450, align 4
  %status.diagnostic.4451 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4451, align 4
  ret void
continue.4449:
  %depth.exceeded.4452 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4452, label %failure.4453, label %continue.4454
failure.4453:
  %ctx.field.4455 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 388, ptr %ctx.field.4455, align 4
  %status.diagnostic.4456 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4456, align 4
  ret void
continue.4454:
  %workspace.slot.4457 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4443, ptr %workspace.slot.4457, align 8
  %workspace.slot.4458 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4459 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 107, ptr %outputs, i32 1, ptr %workspace.slot.4458)
  switch i32 %record.make.status.4459, label %runtime.invalid.result.4465 [ i32 0, label %runtime.success.4460 i32 1, label %runtime.invalid.request.4461 i32 2, label %runtime.invalid.reference.4462 i32 3, label %runtime.scratch.capacity.4463 i32 4, label %runtime.retained.capacity.4464 ]
runtime.invalid.request.4461:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4462:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4463:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4464:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4465:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4460:
  %record.make.handle.4466 = load i64, ptr %workspace.slot.4458, align 8
  %ctx.field.4467 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4468 = load i32, ptr %ctx.field.4467, align 4
  %steps.next.4469 = add i32 %steps.current.4468, 1
  store i32 %steps.next.4469, ptr %ctx.field.4467, align 4
  %steps.over.4470 = icmp ugt i32 %steps.next.4469, 10000
  br i1 %steps.over.4470, label %failure.4471, label %continue.4472
failure.4471:
  %ctx.field.4473 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 389, ptr %ctx.field.4473, align 4
  %status.diagnostic.4474 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4474, align 4
  ret void
continue.4472:
  %depth.exceeded.4475 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4475, label %failure.4476, label %continue.4477
failure.4476:
  %ctx.field.4478 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 390, ptr %ctx.field.4478, align 4
  %status.diagnostic.4479 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4479, align 4
  ret void
continue.4477:
  %workspace.slot.4480 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4466, ptr %workspace.slot.4480, align 8
  %workspace.slot.4481 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4482 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 108, ptr %outputs, i32 1, ptr %workspace.slot.4481)
  switch i32 %record.make.status.4482, label %runtime.invalid.result.4488 [ i32 0, label %runtime.success.4483 i32 1, label %runtime.invalid.request.4484 i32 2, label %runtime.invalid.reference.4485 i32 3, label %runtime.scratch.capacity.4486 i32 4, label %runtime.retained.capacity.4487 ]
runtime.invalid.request.4484:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4485:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4486:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4487:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4488:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4483:
  %record.make.handle.4489 = load i64, ptr %workspace.slot.4481, align 8
  %ctx.field.4490 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4491 = load i32, ptr %ctx.field.4490, align 4
  %steps.next.4492 = add i32 %steps.current.4491, 1
  store i32 %steps.next.4492, ptr %ctx.field.4490, align 4
  %steps.over.4493 = icmp ugt i32 %steps.next.4492, 10000
  br i1 %steps.over.4493, label %failure.4494, label %continue.4495
failure.4494:
  %ctx.field.4496 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 391, ptr %ctx.field.4496, align 4
  %status.diagnostic.4497 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4497, align 4
  ret void
continue.4495:
  %depth.exceeded.4498 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4498, label %failure.4499, label %continue.4500
failure.4499:
  %ctx.field.4501 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 392, ptr %ctx.field.4501, align 4
  %status.diagnostic.4502 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4502, align 4
  ret void
continue.4500:
  %workspace.slot.4503 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4489, ptr %workspace.slot.4503, align 8
  %workspace.slot.4504 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4505 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 109, ptr %outputs, i32 1, ptr %workspace.slot.4504)
  switch i32 %record.make.status.4505, label %runtime.invalid.result.4511 [ i32 0, label %runtime.success.4506 i32 1, label %runtime.invalid.request.4507 i32 2, label %runtime.invalid.reference.4508 i32 3, label %runtime.scratch.capacity.4509 i32 4, label %runtime.retained.capacity.4510 ]
runtime.invalid.request.4507:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4508:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4509:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4510:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4511:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4506:
  %record.make.handle.4512 = load i64, ptr %workspace.slot.4504, align 8
  %ctx.field.4513 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4514 = load i32, ptr %ctx.field.4513, align 4
  %steps.next.4515 = add i32 %steps.current.4514, 1
  store i32 %steps.next.4515, ptr %ctx.field.4513, align 4
  %steps.over.4516 = icmp ugt i32 %steps.next.4515, 10000
  br i1 %steps.over.4516, label %failure.4517, label %continue.4518
failure.4517:
  %ctx.field.4519 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 393, ptr %ctx.field.4519, align 4
  %status.diagnostic.4520 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4520, align 4
  ret void
continue.4518:
  %depth.exceeded.4521 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4521, label %failure.4522, label %continue.4523
failure.4522:
  %ctx.field.4524 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 394, ptr %ctx.field.4524, align 4
  %status.diagnostic.4525 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4525, align 4
  ret void
continue.4523:
  %workspace.slot.4526 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4512, ptr %workspace.slot.4526, align 8
  %workspace.slot.4527 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4528 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 110, ptr %outputs, i32 1, ptr %workspace.slot.4527)
  switch i32 %record.make.status.4528, label %runtime.invalid.result.4534 [ i32 0, label %runtime.success.4529 i32 1, label %runtime.invalid.request.4530 i32 2, label %runtime.invalid.reference.4531 i32 3, label %runtime.scratch.capacity.4532 i32 4, label %runtime.retained.capacity.4533 ]
runtime.invalid.request.4530:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4531:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4532:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4533:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4534:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4529:
  %record.make.handle.4535 = load i64, ptr %workspace.slot.4527, align 8
  %ctx.field.4536 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4537 = load i32, ptr %ctx.field.4536, align 4
  %steps.next.4538 = add i32 %steps.current.4537, 1
  store i32 %steps.next.4538, ptr %ctx.field.4536, align 4
  %steps.over.4539 = icmp ugt i32 %steps.next.4538, 10000
  br i1 %steps.over.4539, label %failure.4540, label %continue.4541
failure.4540:
  %ctx.field.4542 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 395, ptr %ctx.field.4542, align 4
  %status.diagnostic.4543 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4543, align 4
  ret void
continue.4541:
  %depth.exceeded.4544 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4544, label %failure.4545, label %continue.4546
failure.4545:
  %ctx.field.4547 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 396, ptr %ctx.field.4547, align 4
  %status.diagnostic.4548 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4548, align 4
  ret void
continue.4546:
  %workspace.slot.4549 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4535, ptr %workspace.slot.4549, align 8
  %workspace.slot.4550 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4551 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 111, ptr %outputs, i32 1, ptr %workspace.slot.4550)
  switch i32 %record.make.status.4551, label %runtime.invalid.result.4557 [ i32 0, label %runtime.success.4552 i32 1, label %runtime.invalid.request.4553 i32 2, label %runtime.invalid.reference.4554 i32 3, label %runtime.scratch.capacity.4555 i32 4, label %runtime.retained.capacity.4556 ]
runtime.invalid.request.4553:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4554:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4555:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4556:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4557:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4552:
  %record.make.handle.4558 = load i64, ptr %workspace.slot.4550, align 8
  %ctx.field.4559 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4560 = load i32, ptr %ctx.field.4559, align 4
  %steps.next.4561 = add i32 %steps.current.4560, 1
  store i32 %steps.next.4561, ptr %ctx.field.4559, align 4
  %steps.over.4562 = icmp ugt i32 %steps.next.4561, 10000
  br i1 %steps.over.4562, label %failure.4563, label %continue.4564
failure.4563:
  %ctx.field.4565 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 397, ptr %ctx.field.4565, align 4
  %status.diagnostic.4566 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4566, align 4
  ret void
continue.4564:
  %depth.exceeded.4567 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4567, label %failure.4568, label %continue.4569
failure.4568:
  %ctx.field.4570 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 398, ptr %ctx.field.4570, align 4
  %status.diagnostic.4571 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4571, align 4
  ret void
continue.4569:
  %workspace.slot.4572 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4558, ptr %workspace.slot.4572, align 8
  %workspace.slot.4573 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4574 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 112, ptr %outputs, i32 1, ptr %workspace.slot.4573)
  switch i32 %record.make.status.4574, label %runtime.invalid.result.4580 [ i32 0, label %runtime.success.4575 i32 1, label %runtime.invalid.request.4576 i32 2, label %runtime.invalid.reference.4577 i32 3, label %runtime.scratch.capacity.4578 i32 4, label %runtime.retained.capacity.4579 ]
runtime.invalid.request.4576:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4577:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4578:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4579:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4580:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4575:
  %record.make.handle.4581 = load i64, ptr %workspace.slot.4573, align 8
  %ctx.field.4582 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4583 = load i32, ptr %ctx.field.4582, align 4
  %steps.next.4584 = add i32 %steps.current.4583, 1
  store i32 %steps.next.4584, ptr %ctx.field.4582, align 4
  %steps.over.4585 = icmp ugt i32 %steps.next.4584, 10000
  br i1 %steps.over.4585, label %failure.4586, label %continue.4587
failure.4586:
  %ctx.field.4588 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 399, ptr %ctx.field.4588, align 4
  %status.diagnostic.4589 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4589, align 4
  ret void
continue.4587:
  %depth.exceeded.4590 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4590, label %failure.4591, label %continue.4592
failure.4591:
  %ctx.field.4593 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 400, ptr %ctx.field.4593, align 4
  %status.diagnostic.4594 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4594, align 4
  ret void
continue.4592:
  %workspace.slot.4595 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4581, ptr %workspace.slot.4595, align 8
  %workspace.slot.4596 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4597 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 113, ptr %outputs, i32 1, ptr %workspace.slot.4596)
  switch i32 %record.make.status.4597, label %runtime.invalid.result.4603 [ i32 0, label %runtime.success.4598 i32 1, label %runtime.invalid.request.4599 i32 2, label %runtime.invalid.reference.4600 i32 3, label %runtime.scratch.capacity.4601 i32 4, label %runtime.retained.capacity.4602 ]
runtime.invalid.request.4599:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4600:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4601:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4602:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4603:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4598:
  %record.make.handle.4604 = load i64, ptr %workspace.slot.4596, align 8
  %ctx.field.4605 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4606 = load i32, ptr %ctx.field.4605, align 4
  %steps.next.4607 = add i32 %steps.current.4606, 1
  store i32 %steps.next.4607, ptr %ctx.field.4605, align 4
  %steps.over.4608 = icmp ugt i32 %steps.next.4607, 10000
  br i1 %steps.over.4608, label %failure.4609, label %continue.4610
failure.4609:
  %ctx.field.4611 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 401, ptr %ctx.field.4611, align 4
  %status.diagnostic.4612 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4612, align 4
  ret void
continue.4610:
  %depth.exceeded.4613 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4613, label %failure.4614, label %continue.4615
failure.4614:
  %ctx.field.4616 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 402, ptr %ctx.field.4616, align 4
  %status.diagnostic.4617 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4617, align 4
  ret void
continue.4615:
  %workspace.slot.4618 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4604, ptr %workspace.slot.4618, align 8
  %workspace.slot.4619 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4620 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 114, ptr %outputs, i32 1, ptr %workspace.slot.4619)
  switch i32 %record.make.status.4620, label %runtime.invalid.result.4626 [ i32 0, label %runtime.success.4621 i32 1, label %runtime.invalid.request.4622 i32 2, label %runtime.invalid.reference.4623 i32 3, label %runtime.scratch.capacity.4624 i32 4, label %runtime.retained.capacity.4625 ]
runtime.invalid.request.4622:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4623:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4624:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4625:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4626:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4621:
  %record.make.handle.4627 = load i64, ptr %workspace.slot.4619, align 8
  %ctx.field.4628 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4629 = load i32, ptr %ctx.field.4628, align 4
  %steps.next.4630 = add i32 %steps.current.4629, 1
  store i32 %steps.next.4630, ptr %ctx.field.4628, align 4
  %steps.over.4631 = icmp ugt i32 %steps.next.4630, 10000
  br i1 %steps.over.4631, label %failure.4632, label %continue.4633
failure.4632:
  %ctx.field.4634 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 403, ptr %ctx.field.4634, align 4
  %status.diagnostic.4635 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4635, align 4
  ret void
continue.4633:
  %depth.exceeded.4636 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4636, label %failure.4637, label %continue.4638
failure.4637:
  %ctx.field.4639 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 404, ptr %ctx.field.4639, align 4
  %status.diagnostic.4640 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4640, align 4
  ret void
continue.4638:
  %workspace.slot.4641 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4627, ptr %workspace.slot.4641, align 8
  %workspace.slot.4642 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4643 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 117, ptr %outputs, i32 1, ptr %workspace.slot.4642)
  switch i32 %record.make.status.4643, label %runtime.invalid.result.4649 [ i32 0, label %runtime.success.4644 i32 1, label %runtime.invalid.request.4645 i32 2, label %runtime.invalid.reference.4646 i32 3, label %runtime.scratch.capacity.4647 i32 4, label %runtime.retained.capacity.4648 ]
runtime.invalid.request.4645:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4646:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4647:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4648:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4649:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4644:
  %record.make.handle.4650 = load i64, ptr %workspace.slot.4642, align 8
  %ctx.field.4651 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4652 = load i32, ptr %ctx.field.4651, align 4
  %steps.next.4653 = add i32 %steps.current.4652, 1
  store i32 %steps.next.4653, ptr %ctx.field.4651, align 4
  %steps.over.4654 = icmp ugt i32 %steps.next.4653, 10000
  br i1 %steps.over.4654, label %failure.4655, label %continue.4656
failure.4655:
  %ctx.field.4657 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 405, ptr %ctx.field.4657, align 4
  %status.diagnostic.4658 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4658, align 4
  ret void
continue.4656:
  %depth.exceeded.4659 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4659, label %failure.4660, label %continue.4661
failure.4660:
  %ctx.field.4662 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 406, ptr %ctx.field.4662, align 4
  %status.diagnostic.4663 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4663, align 4
  ret void
continue.4661:
  %workspace.slot.4664 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4650, ptr %workspace.slot.4664, align 8
  %workspace.slot.4665 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4666 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 118, ptr %outputs, i32 1, ptr %workspace.slot.4665)
  switch i32 %record.make.status.4666, label %runtime.invalid.result.4672 [ i32 0, label %runtime.success.4667 i32 1, label %runtime.invalid.request.4668 i32 2, label %runtime.invalid.reference.4669 i32 3, label %runtime.scratch.capacity.4670 i32 4, label %runtime.retained.capacity.4671 ]
runtime.invalid.request.4668:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4669:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4670:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4671:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4672:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4667:
  %record.make.handle.4673 = load i64, ptr %workspace.slot.4665, align 8
  %ctx.field.4674 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4675 = load i32, ptr %ctx.field.4674, align 4
  %steps.next.4676 = add i32 %steps.current.4675, 1
  store i32 %steps.next.4676, ptr %ctx.field.4674, align 4
  %steps.over.4677 = icmp ugt i32 %steps.next.4676, 10000
  br i1 %steps.over.4677, label %failure.4678, label %continue.4679
failure.4678:
  %ctx.field.4680 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 407, ptr %ctx.field.4680, align 4
  %status.diagnostic.4681 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4681, align 4
  ret void
continue.4679:
  %depth.exceeded.4682 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4682, label %failure.4683, label %continue.4684
failure.4683:
  %ctx.field.4685 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 408, ptr %ctx.field.4685, align 4
  %status.diagnostic.4686 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4686, align 4
  ret void
continue.4684:
  %workspace.slot.4687 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4673, ptr %workspace.slot.4687, align 8
  %workspace.slot.4688 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4689 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 119, ptr %outputs, i32 1, ptr %workspace.slot.4688)
  switch i32 %record.make.status.4689, label %runtime.invalid.result.4695 [ i32 0, label %runtime.success.4690 i32 1, label %runtime.invalid.request.4691 i32 2, label %runtime.invalid.reference.4692 i32 3, label %runtime.scratch.capacity.4693 i32 4, label %runtime.retained.capacity.4694 ]
runtime.invalid.request.4691:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4692:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4693:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4694:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4695:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4690:
  %record.make.handle.4696 = load i64, ptr %workspace.slot.4688, align 8
  %ctx.field.4697 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4698 = load i32, ptr %ctx.field.4697, align 4
  %steps.next.4699 = add i32 %steps.current.4698, 1
  store i32 %steps.next.4699, ptr %ctx.field.4697, align 4
  %steps.over.4700 = icmp ugt i32 %steps.next.4699, 10000
  br i1 %steps.over.4700, label %failure.4701, label %continue.4702
failure.4701:
  %ctx.field.4703 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 409, ptr %ctx.field.4703, align 4
  %status.diagnostic.4704 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4704, align 4
  ret void
continue.4702:
  %depth.exceeded.4705 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4705, label %failure.4706, label %continue.4707
failure.4706:
  %ctx.field.4708 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 410, ptr %ctx.field.4708, align 4
  %status.diagnostic.4709 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4709, align 4
  ret void
continue.4707:
  %workspace.slot.4710 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4696, ptr %workspace.slot.4710, align 8
  %workspace.slot.4711 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4712 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 120, ptr %outputs, i32 1, ptr %workspace.slot.4711)
  switch i32 %record.make.status.4712, label %runtime.invalid.result.4718 [ i32 0, label %runtime.success.4713 i32 1, label %runtime.invalid.request.4714 i32 2, label %runtime.invalid.reference.4715 i32 3, label %runtime.scratch.capacity.4716 i32 4, label %runtime.retained.capacity.4717 ]
runtime.invalid.request.4714:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4715:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4716:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4717:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4718:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4713:
  %record.make.handle.4719 = load i64, ptr %workspace.slot.4711, align 8
  %ctx.field.4720 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4721 = load i32, ptr %ctx.field.4720, align 4
  %steps.next.4722 = add i32 %steps.current.4721, 1
  store i32 %steps.next.4722, ptr %ctx.field.4720, align 4
  %steps.over.4723 = icmp ugt i32 %steps.next.4722, 10000
  br i1 %steps.over.4723, label %failure.4724, label %continue.4725
failure.4724:
  %ctx.field.4726 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 411, ptr %ctx.field.4726, align 4
  %status.diagnostic.4727 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4727, align 4
  ret void
continue.4725:
  %depth.exceeded.4728 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4728, label %failure.4729, label %continue.4730
failure.4729:
  %ctx.field.4731 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 412, ptr %ctx.field.4731, align 4
  %status.diagnostic.4732 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4732, align 4
  ret void
continue.4730:
  %workspace.slot.4733 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4719, ptr %workspace.slot.4733, align 8
  %workspace.slot.4734 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4735 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 121, ptr %outputs, i32 1, ptr %workspace.slot.4734)
  switch i32 %record.make.status.4735, label %runtime.invalid.result.4741 [ i32 0, label %runtime.success.4736 i32 1, label %runtime.invalid.request.4737 i32 2, label %runtime.invalid.reference.4738 i32 3, label %runtime.scratch.capacity.4739 i32 4, label %runtime.retained.capacity.4740 ]
runtime.invalid.request.4737:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4738:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4739:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4740:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4741:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4736:
  %record.make.handle.4742 = load i64, ptr %workspace.slot.4734, align 8
  %ctx.field.4743 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4744 = load i32, ptr %ctx.field.4743, align 4
  %steps.next.4745 = add i32 %steps.current.4744, 1
  store i32 %steps.next.4745, ptr %ctx.field.4743, align 4
  %steps.over.4746 = icmp ugt i32 %steps.next.4745, 10000
  br i1 %steps.over.4746, label %failure.4747, label %continue.4748
failure.4747:
  %ctx.field.4749 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 413, ptr %ctx.field.4749, align 4
  %status.diagnostic.4750 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4750, align 4
  ret void
continue.4748:
  %depth.exceeded.4751 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4751, label %failure.4752, label %continue.4753
failure.4752:
  %ctx.field.4754 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 414, ptr %ctx.field.4754, align 4
  %status.diagnostic.4755 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4755, align 4
  ret void
continue.4753:
  %workspace.slot.4756 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4742, ptr %workspace.slot.4756, align 8
  %workspace.slot.4757 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4758 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 122, ptr %outputs, i32 1, ptr %workspace.slot.4757)
  switch i32 %record.make.status.4758, label %runtime.invalid.result.4764 [ i32 0, label %runtime.success.4759 i32 1, label %runtime.invalid.request.4760 i32 2, label %runtime.invalid.reference.4761 i32 3, label %runtime.scratch.capacity.4762 i32 4, label %runtime.retained.capacity.4763 ]
runtime.invalid.request.4760:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4761:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4762:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4763:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4764:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4759:
  %record.make.handle.4765 = load i64, ptr %workspace.slot.4757, align 8
  %ctx.field.4766 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4767 = load i32, ptr %ctx.field.4766, align 4
  %steps.next.4768 = add i32 %steps.current.4767, 1
  store i32 %steps.next.4768, ptr %ctx.field.4766, align 4
  %steps.over.4769 = icmp ugt i32 %steps.next.4768, 10000
  br i1 %steps.over.4769, label %failure.4770, label %continue.4771
failure.4770:
  %ctx.field.4772 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 415, ptr %ctx.field.4772, align 4
  %status.diagnostic.4773 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4773, align 4
  ret void
continue.4771:
  %depth.exceeded.4774 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4774, label %failure.4775, label %continue.4776
failure.4775:
  %ctx.field.4777 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 416, ptr %ctx.field.4777, align 4
  %status.diagnostic.4778 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4778, align 4
  ret void
continue.4776:
  %workspace.slot.4779 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4765, ptr %workspace.slot.4779, align 8
  %workspace.slot.4780 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4781 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 123, ptr %outputs, i32 1, ptr %workspace.slot.4780)
  switch i32 %record.make.status.4781, label %runtime.invalid.result.4787 [ i32 0, label %runtime.success.4782 i32 1, label %runtime.invalid.request.4783 i32 2, label %runtime.invalid.reference.4784 i32 3, label %runtime.scratch.capacity.4785 i32 4, label %runtime.retained.capacity.4786 ]
runtime.invalid.request.4783:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4784:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4785:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4786:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4787:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4782:
  %record.make.handle.4788 = load i64, ptr %workspace.slot.4780, align 8
  %ctx.field.4789 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4790 = load i32, ptr %ctx.field.4789, align 4
  %steps.next.4791 = add i32 %steps.current.4790, 1
  store i32 %steps.next.4791, ptr %ctx.field.4789, align 4
  %steps.over.4792 = icmp ugt i32 %steps.next.4791, 10000
  br i1 %steps.over.4792, label %failure.4793, label %continue.4794
failure.4793:
  %ctx.field.4795 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 417, ptr %ctx.field.4795, align 4
  %status.diagnostic.4796 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4796, align 4
  ret void
continue.4794:
  %depth.exceeded.4797 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4797, label %failure.4798, label %continue.4799
failure.4798:
  %ctx.field.4800 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 418, ptr %ctx.field.4800, align 4
  %status.diagnostic.4801 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4801, align 4
  ret void
continue.4799:
  %workspace.slot.4802 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4788, ptr %workspace.slot.4802, align 8
  %workspace.slot.4803 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4804 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 124, ptr %outputs, i32 1, ptr %workspace.slot.4803)
  switch i32 %record.make.status.4804, label %runtime.invalid.result.4810 [ i32 0, label %runtime.success.4805 i32 1, label %runtime.invalid.request.4806 i32 2, label %runtime.invalid.reference.4807 i32 3, label %runtime.scratch.capacity.4808 i32 4, label %runtime.retained.capacity.4809 ]
runtime.invalid.request.4806:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4807:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4808:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4809:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4810:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4805:
  %record.make.handle.4811 = load i64, ptr %workspace.slot.4803, align 8
  %ctx.field.4812 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4813 = load i32, ptr %ctx.field.4812, align 4
  %steps.next.4814 = add i32 %steps.current.4813, 1
  store i32 %steps.next.4814, ptr %ctx.field.4812, align 4
  %steps.over.4815 = icmp ugt i32 %steps.next.4814, 10000
  br i1 %steps.over.4815, label %failure.4816, label %continue.4817
failure.4816:
  %ctx.field.4818 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 419, ptr %ctx.field.4818, align 4
  %status.diagnostic.4819 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4819, align 4
  ret void
continue.4817:
  %depth.exceeded.4820 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4820, label %failure.4821, label %continue.4822
failure.4821:
  %ctx.field.4823 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 420, ptr %ctx.field.4823, align 4
  %status.diagnostic.4824 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4824, align 4
  ret void
continue.4822:
  %workspace.slot.4825 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4811, ptr %workspace.slot.4825, align 8
  %workspace.slot.4826 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4827 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 125, ptr %outputs, i32 1, ptr %workspace.slot.4826)
  switch i32 %record.make.status.4827, label %runtime.invalid.result.4833 [ i32 0, label %runtime.success.4828 i32 1, label %runtime.invalid.request.4829 i32 2, label %runtime.invalid.reference.4830 i32 3, label %runtime.scratch.capacity.4831 i32 4, label %runtime.retained.capacity.4832 ]
runtime.invalid.request.4829:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4830:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4831:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4832:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4833:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4828:
  %record.make.handle.4834 = load i64, ptr %workspace.slot.4826, align 8
  %ctx.field.4835 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4836 = load i32, ptr %ctx.field.4835, align 4
  %steps.next.4837 = add i32 %steps.current.4836, 1
  store i32 %steps.next.4837, ptr %ctx.field.4835, align 4
  %steps.over.4838 = icmp ugt i32 %steps.next.4837, 10000
  br i1 %steps.over.4838, label %failure.4839, label %continue.4840
failure.4839:
  %ctx.field.4841 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 421, ptr %ctx.field.4841, align 4
  %status.diagnostic.4842 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4842, align 4
  ret void
continue.4840:
  %depth.exceeded.4843 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4843, label %failure.4844, label %continue.4845
failure.4844:
  %ctx.field.4846 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 422, ptr %ctx.field.4846, align 4
  %status.diagnostic.4847 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4847, align 4
  ret void
continue.4845:
  %workspace.slot.4848 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4834, ptr %workspace.slot.4848, align 8
  %workspace.slot.4849 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4850 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 126, ptr %outputs, i32 1, ptr %workspace.slot.4849)
  switch i32 %record.make.status.4850, label %runtime.invalid.result.4856 [ i32 0, label %runtime.success.4851 i32 1, label %runtime.invalid.request.4852 i32 2, label %runtime.invalid.reference.4853 i32 3, label %runtime.scratch.capacity.4854 i32 4, label %runtime.retained.capacity.4855 ]
runtime.invalid.request.4852:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4853:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4854:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4855:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4856:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4851:
  %record.make.handle.4857 = load i64, ptr %workspace.slot.4849, align 8
  %ctx.field.4858 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4859 = load i32, ptr %ctx.field.4858, align 4
  %steps.next.4860 = add i32 %steps.current.4859, 1
  store i32 %steps.next.4860, ptr %ctx.field.4858, align 4
  %steps.over.4861 = icmp ugt i32 %steps.next.4860, 10000
  br i1 %steps.over.4861, label %failure.4862, label %continue.4863
failure.4862:
  %ctx.field.4864 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 423, ptr %ctx.field.4864, align 4
  %status.diagnostic.4865 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4865, align 4
  ret void
continue.4863:
  %depth.exceeded.4866 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4866, label %failure.4867, label %continue.4868
failure.4867:
  %ctx.field.4869 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 424, ptr %ctx.field.4869, align 4
  %status.diagnostic.4870 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4870, align 4
  ret void
continue.4868:
  %workspace.slot.4871 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4857, ptr %workspace.slot.4871, align 8
  %workspace.slot.4872 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4873 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 128, ptr %outputs, i32 1, ptr %workspace.slot.4872)
  switch i32 %record.make.status.4873, label %runtime.invalid.result.4879 [ i32 0, label %runtime.success.4874 i32 1, label %runtime.invalid.request.4875 i32 2, label %runtime.invalid.reference.4876 i32 3, label %runtime.scratch.capacity.4877 i32 4, label %runtime.retained.capacity.4878 ]
runtime.invalid.request.4875:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4876:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4877:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4878:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4879:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4874:
  %record.make.handle.4880 = load i64, ptr %workspace.slot.4872, align 8
  %ctx.field.4881 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4882 = load i32, ptr %ctx.field.4881, align 4
  %steps.next.4883 = add i32 %steps.current.4882, 1
  store i32 %steps.next.4883, ptr %ctx.field.4881, align 4
  %steps.over.4884 = icmp ugt i32 %steps.next.4883, 10000
  br i1 %steps.over.4884, label %failure.4885, label %continue.4886
failure.4885:
  %ctx.field.4887 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 425, ptr %ctx.field.4887, align 4
  %status.diagnostic.4888 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4888, align 4
  ret void
continue.4886:
  %depth.exceeded.4889 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4889, label %failure.4890, label %continue.4891
failure.4890:
  %ctx.field.4892 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 426, ptr %ctx.field.4892, align 4
  %status.diagnostic.4893 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4893, align 4
  ret void
continue.4891:
  %workspace.slot.4894 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4880, ptr %workspace.slot.4894, align 8
  %workspace.slot.4895 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4896 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 129, ptr %outputs, i32 1, ptr %workspace.slot.4895)
  switch i32 %record.make.status.4896, label %runtime.invalid.result.4902 [ i32 0, label %runtime.success.4897 i32 1, label %runtime.invalid.request.4898 i32 2, label %runtime.invalid.reference.4899 i32 3, label %runtime.scratch.capacity.4900 i32 4, label %runtime.retained.capacity.4901 ]
runtime.invalid.request.4898:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4899:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4900:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4901:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4902:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4897:
  %record.make.handle.4903 = load i64, ptr %workspace.slot.4895, align 8
  %ctx.field.4904 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4905 = load i32, ptr %ctx.field.4904, align 4
  %steps.next.4906 = add i32 %steps.current.4905, 1
  store i32 %steps.next.4906, ptr %ctx.field.4904, align 4
  %steps.over.4907 = icmp ugt i32 %steps.next.4906, 10000
  br i1 %steps.over.4907, label %failure.4908, label %continue.4909
failure.4908:
  %ctx.field.4910 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 427, ptr %ctx.field.4910, align 4
  %status.diagnostic.4911 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4911, align 4
  ret void
continue.4909:
  %depth.exceeded.4912 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4912, label %failure.4913, label %continue.4914
failure.4913:
  %ctx.field.4915 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 428, ptr %ctx.field.4915, align 4
  %status.diagnostic.4916 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4916, align 4
  ret void
continue.4914:
  %workspace.slot.4917 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4903, ptr %workspace.slot.4917, align 8
  %workspace.slot.4918 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4919 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 130, ptr %outputs, i32 1, ptr %workspace.slot.4918)
  switch i32 %record.make.status.4919, label %runtime.invalid.result.4925 [ i32 0, label %runtime.success.4920 i32 1, label %runtime.invalid.request.4921 i32 2, label %runtime.invalid.reference.4922 i32 3, label %runtime.scratch.capacity.4923 i32 4, label %runtime.retained.capacity.4924 ]
runtime.invalid.request.4921:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4922:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4923:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4924:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4925:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4920:
  %record.make.handle.4926 = load i64, ptr %workspace.slot.4918, align 8
  %ctx.field.4927 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4928 = load i32, ptr %ctx.field.4927, align 4
  %steps.next.4929 = add i32 %steps.current.4928, 1
  store i32 %steps.next.4929, ptr %ctx.field.4927, align 4
  %steps.over.4930 = icmp ugt i32 %steps.next.4929, 10000
  br i1 %steps.over.4930, label %failure.4931, label %continue.4932
failure.4931:
  %ctx.field.4933 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 429, ptr %ctx.field.4933, align 4
  %status.diagnostic.4934 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4934, align 4
  ret void
continue.4932:
  %depth.exceeded.4935 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4935, label %failure.4936, label %continue.4937
failure.4936:
  %ctx.field.4938 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 430, ptr %ctx.field.4938, align 4
  %status.diagnostic.4939 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4939, align 4
  ret void
continue.4937:
  %workspace.slot.4940 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4926, ptr %workspace.slot.4940, align 8
  %workspace.slot.4941 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4942 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 131, ptr %outputs, i32 1, ptr %workspace.slot.4941)
  switch i32 %record.make.status.4942, label %runtime.invalid.result.4948 [ i32 0, label %runtime.success.4943 i32 1, label %runtime.invalid.request.4944 i32 2, label %runtime.invalid.reference.4945 i32 3, label %runtime.scratch.capacity.4946 i32 4, label %runtime.retained.capacity.4947 ]
runtime.invalid.request.4944:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4945:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4946:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4947:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4948:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4943:
  %record.make.handle.4949 = load i64, ptr %workspace.slot.4941, align 8
  %ctx.field.4950 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4951 = load i32, ptr %ctx.field.4950, align 4
  %steps.next.4952 = add i32 %steps.current.4951, 1
  store i32 %steps.next.4952, ptr %ctx.field.4950, align 4
  %steps.over.4953 = icmp ugt i32 %steps.next.4952, 10000
  br i1 %steps.over.4953, label %failure.4954, label %continue.4955
failure.4954:
  %ctx.field.4956 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 431, ptr %ctx.field.4956, align 4
  %status.diagnostic.4957 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4957, align 4
  ret void
continue.4955:
  %depth.exceeded.4958 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4958, label %failure.4959, label %continue.4960
failure.4959:
  %ctx.field.4961 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 432, ptr %ctx.field.4961, align 4
  %status.diagnostic.4962 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4962, align 4
  ret void
continue.4960:
  %workspace.slot.4963 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4949, ptr %workspace.slot.4963, align 8
  %workspace.slot.4964 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4965 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 132, ptr %outputs, i32 1, ptr %workspace.slot.4964)
  switch i32 %record.make.status.4965, label %runtime.invalid.result.4971 [ i32 0, label %runtime.success.4966 i32 1, label %runtime.invalid.request.4967 i32 2, label %runtime.invalid.reference.4968 i32 3, label %runtime.scratch.capacity.4969 i32 4, label %runtime.retained.capacity.4970 ]
runtime.invalid.request.4967:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4968:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4969:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4970:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4971:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4966:
  %record.make.handle.4972 = load i64, ptr %workspace.slot.4964, align 8
  %ctx.field.4973 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4974 = load i32, ptr %ctx.field.4973, align 4
  %steps.next.4975 = add i32 %steps.current.4974, 1
  store i32 %steps.next.4975, ptr %ctx.field.4973, align 4
  %steps.over.4976 = icmp ugt i32 %steps.next.4975, 10000
  br i1 %steps.over.4976, label %failure.4977, label %continue.4978
failure.4977:
  %ctx.field.4979 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 433, ptr %ctx.field.4979, align 4
  %status.diagnostic.4980 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4980, align 4
  ret void
continue.4978:
  %depth.exceeded.4981 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.4981, label %failure.4982, label %continue.4983
failure.4982:
  %ctx.field.4984 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 434, ptr %ctx.field.4984, align 4
  %status.diagnostic.4985 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.4985, align 4
  ret void
continue.4983:
  %workspace.slot.4986 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4972, ptr %workspace.slot.4986, align 8
  %workspace.slot.4987 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.4988 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 133, ptr %outputs, i32 1, ptr %workspace.slot.4987)
  switch i32 %record.make.status.4988, label %runtime.invalid.result.4994 [ i32 0, label %runtime.success.4989 i32 1, label %runtime.invalid.request.4990 i32 2, label %runtime.invalid.reference.4991 i32 3, label %runtime.scratch.capacity.4992 i32 4, label %runtime.retained.capacity.4993 ]
runtime.invalid.request.4990:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.4991:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.4992:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.4993:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.4994:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.4989:
  %record.make.handle.4995 = load i64, ptr %workspace.slot.4987, align 8
  %ctx.field.4996 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.4997 = load i32, ptr %ctx.field.4996, align 4
  %steps.next.4998 = add i32 %steps.current.4997, 1
  store i32 %steps.next.4998, ptr %ctx.field.4996, align 4
  %steps.over.4999 = icmp ugt i32 %steps.next.4998, 10000
  br i1 %steps.over.4999, label %failure.5000, label %continue.5001
failure.5000:
  %ctx.field.5002 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 435, ptr %ctx.field.5002, align 4
  %status.diagnostic.5003 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5003, align 4
  ret void
continue.5001:
  %depth.exceeded.5004 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5004, label %failure.5005, label %continue.5006
failure.5005:
  %ctx.field.5007 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 436, ptr %ctx.field.5007, align 4
  %status.diagnostic.5008 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5008, align 4
  ret void
continue.5006:
  %workspace.slot.5009 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.4995, ptr %workspace.slot.5009, align 8
  %workspace.slot.5010 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5011 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 134, ptr %outputs, i32 1, ptr %workspace.slot.5010)
  switch i32 %record.make.status.5011, label %runtime.invalid.result.5017 [ i32 0, label %runtime.success.5012 i32 1, label %runtime.invalid.request.5013 i32 2, label %runtime.invalid.reference.5014 i32 3, label %runtime.scratch.capacity.5015 i32 4, label %runtime.retained.capacity.5016 ]
runtime.invalid.request.5013:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5014:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5015:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5016:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5017:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5012:
  %record.make.handle.5018 = load i64, ptr %workspace.slot.5010, align 8
  %ctx.field.5019 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5020 = load i32, ptr %ctx.field.5019, align 4
  %steps.next.5021 = add i32 %steps.current.5020, 1
  store i32 %steps.next.5021, ptr %ctx.field.5019, align 4
  %steps.over.5022 = icmp ugt i32 %steps.next.5021, 10000
  br i1 %steps.over.5022, label %failure.5023, label %continue.5024
failure.5023:
  %ctx.field.5025 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 437, ptr %ctx.field.5025, align 4
  %status.diagnostic.5026 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5026, align 4
  ret void
continue.5024:
  %depth.exceeded.5027 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5027, label %failure.5028, label %continue.5029
failure.5028:
  %ctx.field.5030 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 438, ptr %ctx.field.5030, align 4
  %status.diagnostic.5031 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5031, align 4
  ret void
continue.5029:
  %workspace.slot.5032 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5018, ptr %workspace.slot.5032, align 8
  %workspace.slot.5033 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5034 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 135, ptr %outputs, i32 1, ptr %workspace.slot.5033)
  switch i32 %record.make.status.5034, label %runtime.invalid.result.5040 [ i32 0, label %runtime.success.5035 i32 1, label %runtime.invalid.request.5036 i32 2, label %runtime.invalid.reference.5037 i32 3, label %runtime.scratch.capacity.5038 i32 4, label %runtime.retained.capacity.5039 ]
runtime.invalid.request.5036:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5037:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5038:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5039:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5040:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5035:
  %record.make.handle.5041 = load i64, ptr %workspace.slot.5033, align 8
  %ctx.field.5042 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5043 = load i32, ptr %ctx.field.5042, align 4
  %steps.next.5044 = add i32 %steps.current.5043, 1
  store i32 %steps.next.5044, ptr %ctx.field.5042, align 4
  %steps.over.5045 = icmp ugt i32 %steps.next.5044, 10000
  br i1 %steps.over.5045, label %failure.5046, label %continue.5047
failure.5046:
  %ctx.field.5048 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 439, ptr %ctx.field.5048, align 4
  %status.diagnostic.5049 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5049, align 4
  ret void
continue.5047:
  %depth.exceeded.5050 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5050, label %failure.5051, label %continue.5052
failure.5051:
  %ctx.field.5053 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 440, ptr %ctx.field.5053, align 4
  %status.diagnostic.5054 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5054, align 4
  ret void
continue.5052:
  %workspace.slot.5055 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5041, ptr %workspace.slot.5055, align 8
  %workspace.slot.5056 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5057 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 136, ptr %outputs, i32 1, ptr %workspace.slot.5056)
  switch i32 %record.make.status.5057, label %runtime.invalid.result.5063 [ i32 0, label %runtime.success.5058 i32 1, label %runtime.invalid.request.5059 i32 2, label %runtime.invalid.reference.5060 i32 3, label %runtime.scratch.capacity.5061 i32 4, label %runtime.retained.capacity.5062 ]
runtime.invalid.request.5059:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5060:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5061:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5062:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5063:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5058:
  %record.make.handle.5064 = load i64, ptr %workspace.slot.5056, align 8
  %ctx.field.5065 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5066 = load i32, ptr %ctx.field.5065, align 4
  %steps.next.5067 = add i32 %steps.current.5066, 1
  store i32 %steps.next.5067, ptr %ctx.field.5065, align 4
  %steps.over.5068 = icmp ugt i32 %steps.next.5067, 10000
  br i1 %steps.over.5068, label %failure.5069, label %continue.5070
failure.5069:
  %ctx.field.5071 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 441, ptr %ctx.field.5071, align 4
  %status.diagnostic.5072 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5072, align 4
  ret void
continue.5070:
  %depth.exceeded.5073 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5073, label %failure.5074, label %continue.5075
failure.5074:
  %ctx.field.5076 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 442, ptr %ctx.field.5076, align 4
  %status.diagnostic.5077 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5077, align 4
  ret void
continue.5075:
  %workspace.slot.5078 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5064, ptr %workspace.slot.5078, align 8
  %workspace.slot.5079 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5080 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 137, ptr %outputs, i32 1, ptr %workspace.slot.5079)
  switch i32 %record.make.status.5080, label %runtime.invalid.result.5086 [ i32 0, label %runtime.success.5081 i32 1, label %runtime.invalid.request.5082 i32 2, label %runtime.invalid.reference.5083 i32 3, label %runtime.scratch.capacity.5084 i32 4, label %runtime.retained.capacity.5085 ]
runtime.invalid.request.5082:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5083:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5084:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5085:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5086:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5081:
  %record.make.handle.5087 = load i64, ptr %workspace.slot.5079, align 8
  %ctx.field.5088 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5089 = load i32, ptr %ctx.field.5088, align 4
  %steps.next.5090 = add i32 %steps.current.5089, 1
  store i32 %steps.next.5090, ptr %ctx.field.5088, align 4
  %steps.over.5091 = icmp ugt i32 %steps.next.5090, 10000
  br i1 %steps.over.5091, label %failure.5092, label %continue.5093
failure.5092:
  %ctx.field.5094 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 443, ptr %ctx.field.5094, align 4
  %status.diagnostic.5095 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5095, align 4
  ret void
continue.5093:
  %depth.exceeded.5096 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5096, label %failure.5097, label %continue.5098
failure.5097:
  %ctx.field.5099 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 444, ptr %ctx.field.5099, align 4
  %status.diagnostic.5100 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5100, align 4
  ret void
continue.5098:
  %workspace.slot.5101 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5087, ptr %workspace.slot.5101, align 8
  %workspace.slot.5102 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5103 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 139, ptr %outputs, i32 1, ptr %workspace.slot.5102)
  switch i32 %record.make.status.5103, label %runtime.invalid.result.5109 [ i32 0, label %runtime.success.5104 i32 1, label %runtime.invalid.request.5105 i32 2, label %runtime.invalid.reference.5106 i32 3, label %runtime.scratch.capacity.5107 i32 4, label %runtime.retained.capacity.5108 ]
runtime.invalid.request.5105:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5106:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5107:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5108:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5109:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5104:
  %record.make.handle.5110 = load i64, ptr %workspace.slot.5102, align 8
  %ctx.field.5111 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5112 = load i32, ptr %ctx.field.5111, align 4
  %steps.next.5113 = add i32 %steps.current.5112, 1
  store i32 %steps.next.5113, ptr %ctx.field.5111, align 4
  %steps.over.5114 = icmp ugt i32 %steps.next.5113, 10000
  br i1 %steps.over.5114, label %failure.5115, label %continue.5116
failure.5115:
  %ctx.field.5117 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 445, ptr %ctx.field.5117, align 4
  %status.diagnostic.5118 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5118, align 4
  ret void
continue.5116:
  %depth.exceeded.5119 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5119, label %failure.5120, label %continue.5121
failure.5120:
  %ctx.field.5122 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 446, ptr %ctx.field.5122, align 4
  %status.diagnostic.5123 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5123, align 4
  ret void
continue.5121:
  %workspace.slot.5124 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5110, ptr %workspace.slot.5124, align 8
  %workspace.slot.5125 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5126 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 140, ptr %outputs, i32 1, ptr %workspace.slot.5125)
  switch i32 %record.make.status.5126, label %runtime.invalid.result.5132 [ i32 0, label %runtime.success.5127 i32 1, label %runtime.invalid.request.5128 i32 2, label %runtime.invalid.reference.5129 i32 3, label %runtime.scratch.capacity.5130 i32 4, label %runtime.retained.capacity.5131 ]
runtime.invalid.request.5128:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5129:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5130:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5131:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5132:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5127:
  %record.make.handle.5133 = load i64, ptr %workspace.slot.5125, align 8
  %ctx.field.5134 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5135 = load i32, ptr %ctx.field.5134, align 4
  %steps.next.5136 = add i32 %steps.current.5135, 1
  store i32 %steps.next.5136, ptr %ctx.field.5134, align 4
  %steps.over.5137 = icmp ugt i32 %steps.next.5136, 10000
  br i1 %steps.over.5137, label %failure.5138, label %continue.5139
failure.5138:
  %ctx.field.5140 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 447, ptr %ctx.field.5140, align 4
  %status.diagnostic.5141 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5141, align 4
  ret void
continue.5139:
  %depth.exceeded.5142 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5142, label %failure.5143, label %continue.5144
failure.5143:
  %ctx.field.5145 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 448, ptr %ctx.field.5145, align 4
  %status.diagnostic.5146 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5146, align 4
  ret void
continue.5144:
  %workspace.slot.5147 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5133, ptr %workspace.slot.5147, align 8
  %workspace.slot.5148 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5149 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 141, ptr %outputs, i32 1, ptr %workspace.slot.5148)
  switch i32 %record.make.status.5149, label %runtime.invalid.result.5155 [ i32 0, label %runtime.success.5150 i32 1, label %runtime.invalid.request.5151 i32 2, label %runtime.invalid.reference.5152 i32 3, label %runtime.scratch.capacity.5153 i32 4, label %runtime.retained.capacity.5154 ]
runtime.invalid.request.5151:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5152:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5153:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5154:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5155:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5150:
  %record.make.handle.5156 = load i64, ptr %workspace.slot.5148, align 8
  %ctx.field.5157 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5158 = load i32, ptr %ctx.field.5157, align 4
  %steps.next.5159 = add i32 %steps.current.5158, 1
  store i32 %steps.next.5159, ptr %ctx.field.5157, align 4
  %steps.over.5160 = icmp ugt i32 %steps.next.5159, 10000
  br i1 %steps.over.5160, label %failure.5161, label %continue.5162
failure.5161:
  %ctx.field.5163 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 449, ptr %ctx.field.5163, align 4
  %status.diagnostic.5164 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5164, align 4
  ret void
continue.5162:
  %depth.exceeded.5165 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5165, label %failure.5166, label %continue.5167
failure.5166:
  %ctx.field.5168 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 450, ptr %ctx.field.5168, align 4
  %status.diagnostic.5169 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5169, align 4
  ret void
continue.5167:
  %workspace.slot.5170 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5156, ptr %workspace.slot.5170, align 8
  %workspace.slot.5171 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5172 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 142, ptr %outputs, i32 1, ptr %workspace.slot.5171)
  switch i32 %record.make.status.5172, label %runtime.invalid.result.5178 [ i32 0, label %runtime.success.5173 i32 1, label %runtime.invalid.request.5174 i32 2, label %runtime.invalid.reference.5175 i32 3, label %runtime.scratch.capacity.5176 i32 4, label %runtime.retained.capacity.5177 ]
runtime.invalid.request.5174:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5175:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5176:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5177:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5178:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5173:
  %record.make.handle.5179 = load i64, ptr %workspace.slot.5171, align 8
  %ctx.field.5180 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5181 = load i32, ptr %ctx.field.5180, align 4
  %steps.next.5182 = add i32 %steps.current.5181, 1
  store i32 %steps.next.5182, ptr %ctx.field.5180, align 4
  %steps.over.5183 = icmp ugt i32 %steps.next.5182, 10000
  br i1 %steps.over.5183, label %failure.5184, label %continue.5185
failure.5184:
  %ctx.field.5186 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 451, ptr %ctx.field.5186, align 4
  %status.diagnostic.5187 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5187, align 4
  ret void
continue.5185:
  %depth.exceeded.5188 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5188, label %failure.5189, label %continue.5190
failure.5189:
  %ctx.field.5191 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 452, ptr %ctx.field.5191, align 4
  %status.diagnostic.5192 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5192, align 4
  ret void
continue.5190:
  %workspace.slot.5193 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5179, ptr %workspace.slot.5193, align 8
  %workspace.slot.5194 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5195 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 143, ptr %outputs, i32 1, ptr %workspace.slot.5194)
  switch i32 %record.make.status.5195, label %runtime.invalid.result.5201 [ i32 0, label %runtime.success.5196 i32 1, label %runtime.invalid.request.5197 i32 2, label %runtime.invalid.reference.5198 i32 3, label %runtime.scratch.capacity.5199 i32 4, label %runtime.retained.capacity.5200 ]
runtime.invalid.request.5197:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5198:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5199:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5200:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5201:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5196:
  %record.make.handle.5202 = load i64, ptr %workspace.slot.5194, align 8
  %ctx.field.5203 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5204 = load i32, ptr %ctx.field.5203, align 4
  %steps.next.5205 = add i32 %steps.current.5204, 1
  store i32 %steps.next.5205, ptr %ctx.field.5203, align 4
  %steps.over.5206 = icmp ugt i32 %steps.next.5205, 10000
  br i1 %steps.over.5206, label %failure.5207, label %continue.5208
failure.5207:
  %ctx.field.5209 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 453, ptr %ctx.field.5209, align 4
  %status.diagnostic.5210 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5210, align 4
  ret void
continue.5208:
  %depth.exceeded.5211 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5211, label %failure.5212, label %continue.5213
failure.5212:
  %ctx.field.5214 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 454, ptr %ctx.field.5214, align 4
  %status.diagnostic.5215 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5215, align 4
  ret void
continue.5213:
  %workspace.slot.5216 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5202, ptr %workspace.slot.5216, align 8
  %workspace.slot.5217 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5218 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 144, ptr %outputs, i32 1, ptr %workspace.slot.5217)
  switch i32 %record.make.status.5218, label %runtime.invalid.result.5224 [ i32 0, label %runtime.success.5219 i32 1, label %runtime.invalid.request.5220 i32 2, label %runtime.invalid.reference.5221 i32 3, label %runtime.scratch.capacity.5222 i32 4, label %runtime.retained.capacity.5223 ]
runtime.invalid.request.5220:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5221:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5222:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5223:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5224:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5219:
  %record.make.handle.5225 = load i64, ptr %workspace.slot.5217, align 8
  %ctx.field.5226 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5227 = load i32, ptr %ctx.field.5226, align 4
  %steps.next.5228 = add i32 %steps.current.5227, 1
  store i32 %steps.next.5228, ptr %ctx.field.5226, align 4
  %steps.over.5229 = icmp ugt i32 %steps.next.5228, 10000
  br i1 %steps.over.5229, label %failure.5230, label %continue.5231
failure.5230:
  %ctx.field.5232 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 455, ptr %ctx.field.5232, align 4
  %status.diagnostic.5233 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5233, align 4
  ret void
continue.5231:
  %depth.exceeded.5234 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5234, label %failure.5235, label %continue.5236
failure.5235:
  %ctx.field.5237 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 456, ptr %ctx.field.5237, align 4
  %status.diagnostic.5238 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5238, align 4
  ret void
continue.5236:
  %workspace.slot.5239 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5225, ptr %workspace.slot.5239, align 8
  %workspace.slot.5240 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5241 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 145, ptr %outputs, i32 1, ptr %workspace.slot.5240)
  switch i32 %record.make.status.5241, label %runtime.invalid.result.5247 [ i32 0, label %runtime.success.5242 i32 1, label %runtime.invalid.request.5243 i32 2, label %runtime.invalid.reference.5244 i32 3, label %runtime.scratch.capacity.5245 i32 4, label %runtime.retained.capacity.5246 ]
runtime.invalid.request.5243:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5244:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5245:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5246:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5247:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5242:
  %record.make.handle.5248 = load i64, ptr %workspace.slot.5240, align 8
  %ctx.field.5249 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5250 = load i32, ptr %ctx.field.5249, align 4
  %steps.next.5251 = add i32 %steps.current.5250, 1
  store i32 %steps.next.5251, ptr %ctx.field.5249, align 4
  %steps.over.5252 = icmp ugt i32 %steps.next.5251, 10000
  br i1 %steps.over.5252, label %failure.5253, label %continue.5254
failure.5253:
  %ctx.field.5255 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 457, ptr %ctx.field.5255, align 4
  %status.diagnostic.5256 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5256, align 4
  ret void
continue.5254:
  %depth.exceeded.5257 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5257, label %failure.5258, label %continue.5259
failure.5258:
  %ctx.field.5260 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 458, ptr %ctx.field.5260, align 4
  %status.diagnostic.5261 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5261, align 4
  ret void
continue.5259:
  %workspace.slot.5262 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5248, ptr %workspace.slot.5262, align 8
  %workspace.slot.5263 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5264 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 146, ptr %outputs, i32 1, ptr %workspace.slot.5263)
  switch i32 %record.make.status.5264, label %runtime.invalid.result.5270 [ i32 0, label %runtime.success.5265 i32 1, label %runtime.invalid.request.5266 i32 2, label %runtime.invalid.reference.5267 i32 3, label %runtime.scratch.capacity.5268 i32 4, label %runtime.retained.capacity.5269 ]
runtime.invalid.request.5266:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5267:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5268:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5269:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5270:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5265:
  %record.make.handle.5271 = load i64, ptr %workspace.slot.5263, align 8
  %ctx.field.5272 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5273 = load i32, ptr %ctx.field.5272, align 4
  %steps.next.5274 = add i32 %steps.current.5273, 1
  store i32 %steps.next.5274, ptr %ctx.field.5272, align 4
  %steps.over.5275 = icmp ugt i32 %steps.next.5274, 10000
  br i1 %steps.over.5275, label %failure.5276, label %continue.5277
failure.5276:
  %ctx.field.5278 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 459, ptr %ctx.field.5278, align 4
  %status.diagnostic.5279 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5279, align 4
  ret void
continue.5277:
  %depth.exceeded.5280 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5280, label %failure.5281, label %continue.5282
failure.5281:
  %ctx.field.5283 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 460, ptr %ctx.field.5283, align 4
  %status.diagnostic.5284 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5284, align 4
  ret void
continue.5282:
  %workspace.slot.5285 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5271, ptr %workspace.slot.5285, align 8
  %workspace.slot.5286 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5287 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 147, ptr %outputs, i32 1, ptr %workspace.slot.5286)
  switch i32 %record.make.status.5287, label %runtime.invalid.result.5293 [ i32 0, label %runtime.success.5288 i32 1, label %runtime.invalid.request.5289 i32 2, label %runtime.invalid.reference.5290 i32 3, label %runtime.scratch.capacity.5291 i32 4, label %runtime.retained.capacity.5292 ]
runtime.invalid.request.5289:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5290:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5291:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5292:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5293:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5288:
  %record.make.handle.5294 = load i64, ptr %workspace.slot.5286, align 8
  %ctx.field.5295 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5296 = load i32, ptr %ctx.field.5295, align 4
  %steps.next.5297 = add i32 %steps.current.5296, 1
  store i32 %steps.next.5297, ptr %ctx.field.5295, align 4
  %steps.over.5298 = icmp ugt i32 %steps.next.5297, 10000
  br i1 %steps.over.5298, label %failure.5299, label %continue.5300
failure.5299:
  %ctx.field.5301 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 461, ptr %ctx.field.5301, align 4
  %status.diagnostic.5302 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5302, align 4
  ret void
continue.5300:
  %depth.exceeded.5303 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5303, label %failure.5304, label %continue.5305
failure.5304:
  %ctx.field.5306 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 462, ptr %ctx.field.5306, align 4
  %status.diagnostic.5307 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5307, align 4
  ret void
continue.5305:
  %workspace.slot.5308 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5294, ptr %workspace.slot.5308, align 8
  %workspace.slot.5309 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5310 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 148, ptr %outputs, i32 1, ptr %workspace.slot.5309)
  switch i32 %record.make.status.5310, label %runtime.invalid.result.5316 [ i32 0, label %runtime.success.5311 i32 1, label %runtime.invalid.request.5312 i32 2, label %runtime.invalid.reference.5313 i32 3, label %runtime.scratch.capacity.5314 i32 4, label %runtime.retained.capacity.5315 ]
runtime.invalid.request.5312:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5313:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5314:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5315:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5316:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5311:
  %record.make.handle.5317 = load i64, ptr %workspace.slot.5309, align 8
  %ctx.field.5318 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5319 = load i32, ptr %ctx.field.5318, align 4
  %steps.next.5320 = add i32 %steps.current.5319, 1
  store i32 %steps.next.5320, ptr %ctx.field.5318, align 4
  %steps.over.5321 = icmp ugt i32 %steps.next.5320, 10000
  br i1 %steps.over.5321, label %failure.5322, label %continue.5323
failure.5322:
  %ctx.field.5324 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 463, ptr %ctx.field.5324, align 4
  %status.diagnostic.5325 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5325, align 4
  ret void
continue.5323:
  %depth.exceeded.5326 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5326, label %failure.5327, label %continue.5328
failure.5327:
  %ctx.field.5329 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 464, ptr %ctx.field.5329, align 4
  %status.diagnostic.5330 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5330, align 4
  ret void
continue.5328:
  %workspace.slot.5331 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5317, ptr %workspace.slot.5331, align 8
  %workspace.slot.5332 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5333 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 150, ptr %outputs, i32 1, ptr %workspace.slot.5332)
  switch i32 %record.make.status.5333, label %runtime.invalid.result.5339 [ i32 0, label %runtime.success.5334 i32 1, label %runtime.invalid.request.5335 i32 2, label %runtime.invalid.reference.5336 i32 3, label %runtime.scratch.capacity.5337 i32 4, label %runtime.retained.capacity.5338 ]
runtime.invalid.request.5335:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5336:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5337:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5338:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5339:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5334:
  %record.make.handle.5340 = load i64, ptr %workspace.slot.5332, align 8
  %ctx.field.5341 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5342 = load i32, ptr %ctx.field.5341, align 4
  %steps.next.5343 = add i32 %steps.current.5342, 1
  store i32 %steps.next.5343, ptr %ctx.field.5341, align 4
  %steps.over.5344 = icmp ugt i32 %steps.next.5343, 10000
  br i1 %steps.over.5344, label %failure.5345, label %continue.5346
failure.5345:
  %ctx.field.5347 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 465, ptr %ctx.field.5347, align 4
  %status.diagnostic.5348 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5348, align 4
  ret void
continue.5346:
  %depth.exceeded.5349 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5349, label %failure.5350, label %continue.5351
failure.5350:
  %ctx.field.5352 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 466, ptr %ctx.field.5352, align 4
  %status.diagnostic.5353 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5353, align 4
  ret void
continue.5351:
  %workspace.slot.5354 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5340, ptr %workspace.slot.5354, align 8
  %workspace.slot.5355 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5356 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 151, ptr %outputs, i32 1, ptr %workspace.slot.5355)
  switch i32 %record.make.status.5356, label %runtime.invalid.result.5362 [ i32 0, label %runtime.success.5357 i32 1, label %runtime.invalid.request.5358 i32 2, label %runtime.invalid.reference.5359 i32 3, label %runtime.scratch.capacity.5360 i32 4, label %runtime.retained.capacity.5361 ]
runtime.invalid.request.5358:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5359:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5360:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5361:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5362:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5357:
  %record.make.handle.5363 = load i64, ptr %workspace.slot.5355, align 8
  %ctx.field.5364 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5365 = load i32, ptr %ctx.field.5364, align 4
  %steps.next.5366 = add i32 %steps.current.5365, 1
  store i32 %steps.next.5366, ptr %ctx.field.5364, align 4
  %steps.over.5367 = icmp ugt i32 %steps.next.5366, 10000
  br i1 %steps.over.5367, label %failure.5368, label %continue.5369
failure.5368:
  %ctx.field.5370 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 467, ptr %ctx.field.5370, align 4
  %status.diagnostic.5371 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5371, align 4
  ret void
continue.5369:
  %depth.exceeded.5372 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5372, label %failure.5373, label %continue.5374
failure.5373:
  %ctx.field.5375 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 468, ptr %ctx.field.5375, align 4
  %status.diagnostic.5376 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5376, align 4
  ret void
continue.5374:
  %workspace.slot.5377 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5363, ptr %workspace.slot.5377, align 8
  %workspace.slot.5378 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5379 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 152, ptr %outputs, i32 1, ptr %workspace.slot.5378)
  switch i32 %record.make.status.5379, label %runtime.invalid.result.5385 [ i32 0, label %runtime.success.5380 i32 1, label %runtime.invalid.request.5381 i32 2, label %runtime.invalid.reference.5382 i32 3, label %runtime.scratch.capacity.5383 i32 4, label %runtime.retained.capacity.5384 ]
runtime.invalid.request.5381:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5382:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5383:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5384:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5385:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5380:
  %record.make.handle.5386 = load i64, ptr %workspace.slot.5378, align 8
  %ctx.field.5387 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5388 = load i32, ptr %ctx.field.5387, align 4
  %steps.next.5389 = add i32 %steps.current.5388, 1
  store i32 %steps.next.5389, ptr %ctx.field.5387, align 4
  %steps.over.5390 = icmp ugt i32 %steps.next.5389, 10000
  br i1 %steps.over.5390, label %failure.5391, label %continue.5392
failure.5391:
  %ctx.field.5393 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 469, ptr %ctx.field.5393, align 4
  %status.diagnostic.5394 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5394, align 4
  ret void
continue.5392:
  %depth.exceeded.5395 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5395, label %failure.5396, label %continue.5397
failure.5396:
  %ctx.field.5398 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 470, ptr %ctx.field.5398, align 4
  %status.diagnostic.5399 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5399, align 4
  ret void
continue.5397:
  %workspace.slot.5400 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5386, ptr %workspace.slot.5400, align 8
  %workspace.slot.5401 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5402 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 153, ptr %outputs, i32 1, ptr %workspace.slot.5401)
  switch i32 %record.make.status.5402, label %runtime.invalid.result.5408 [ i32 0, label %runtime.success.5403 i32 1, label %runtime.invalid.request.5404 i32 2, label %runtime.invalid.reference.5405 i32 3, label %runtime.scratch.capacity.5406 i32 4, label %runtime.retained.capacity.5407 ]
runtime.invalid.request.5404:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5405:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5406:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5407:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5408:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5403:
  %record.make.handle.5409 = load i64, ptr %workspace.slot.5401, align 8
  %ctx.field.5410 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5411 = load i32, ptr %ctx.field.5410, align 4
  %steps.next.5412 = add i32 %steps.current.5411, 1
  store i32 %steps.next.5412, ptr %ctx.field.5410, align 4
  %steps.over.5413 = icmp ugt i32 %steps.next.5412, 10000
  br i1 %steps.over.5413, label %failure.5414, label %continue.5415
failure.5414:
  %ctx.field.5416 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 471, ptr %ctx.field.5416, align 4
  %status.diagnostic.5417 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5417, align 4
  ret void
continue.5415:
  %depth.exceeded.5418 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5418, label %failure.5419, label %continue.5420
failure.5419:
  %ctx.field.5421 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 472, ptr %ctx.field.5421, align 4
  %status.diagnostic.5422 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5422, align 4
  ret void
continue.5420:
  %workspace.slot.5423 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5409, ptr %workspace.slot.5423, align 8
  %workspace.slot.5424 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5425 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 154, ptr %outputs, i32 1, ptr %workspace.slot.5424)
  switch i32 %record.make.status.5425, label %runtime.invalid.result.5431 [ i32 0, label %runtime.success.5426 i32 1, label %runtime.invalid.request.5427 i32 2, label %runtime.invalid.reference.5428 i32 3, label %runtime.scratch.capacity.5429 i32 4, label %runtime.retained.capacity.5430 ]
runtime.invalid.request.5427:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5428:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5429:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5430:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5431:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5426:
  %record.make.handle.5432 = load i64, ptr %workspace.slot.5424, align 8
  %ctx.field.5433 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5434 = load i32, ptr %ctx.field.5433, align 4
  %steps.next.5435 = add i32 %steps.current.5434, 1
  store i32 %steps.next.5435, ptr %ctx.field.5433, align 4
  %steps.over.5436 = icmp ugt i32 %steps.next.5435, 10000
  br i1 %steps.over.5436, label %failure.5437, label %continue.5438
failure.5437:
  %ctx.field.5439 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 473, ptr %ctx.field.5439, align 4
  %status.diagnostic.5440 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5440, align 4
  ret void
continue.5438:
  %depth.exceeded.5441 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5441, label %failure.5442, label %continue.5443
failure.5442:
  %ctx.field.5444 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 474, ptr %ctx.field.5444, align 4
  %status.diagnostic.5445 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5445, align 4
  ret void
continue.5443:
  %workspace.slot.5446 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5432, ptr %workspace.slot.5446, align 8
  %workspace.slot.5447 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5448 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 155, ptr %outputs, i32 1, ptr %workspace.slot.5447)
  switch i32 %record.make.status.5448, label %runtime.invalid.result.5454 [ i32 0, label %runtime.success.5449 i32 1, label %runtime.invalid.request.5450 i32 2, label %runtime.invalid.reference.5451 i32 3, label %runtime.scratch.capacity.5452 i32 4, label %runtime.retained.capacity.5453 ]
runtime.invalid.request.5450:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5451:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5452:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5453:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5454:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5449:
  %record.make.handle.5455 = load i64, ptr %workspace.slot.5447, align 8
  %ctx.field.5456 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5457 = load i32, ptr %ctx.field.5456, align 4
  %steps.next.5458 = add i32 %steps.current.5457, 1
  store i32 %steps.next.5458, ptr %ctx.field.5456, align 4
  %steps.over.5459 = icmp ugt i32 %steps.next.5458, 10000
  br i1 %steps.over.5459, label %failure.5460, label %continue.5461
failure.5460:
  %ctx.field.5462 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 475, ptr %ctx.field.5462, align 4
  %status.diagnostic.5463 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5463, align 4
  ret void
continue.5461:
  %depth.exceeded.5464 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5464, label %failure.5465, label %continue.5466
failure.5465:
  %ctx.field.5467 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 476, ptr %ctx.field.5467, align 4
  %status.diagnostic.5468 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5468, align 4
  ret void
continue.5466:
  %workspace.slot.5469 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5455, ptr %workspace.slot.5469, align 8
  %workspace.slot.5470 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5471 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 156, ptr %outputs, i32 1, ptr %workspace.slot.5470)
  switch i32 %record.make.status.5471, label %runtime.invalid.result.5477 [ i32 0, label %runtime.success.5472 i32 1, label %runtime.invalid.request.5473 i32 2, label %runtime.invalid.reference.5474 i32 3, label %runtime.scratch.capacity.5475 i32 4, label %runtime.retained.capacity.5476 ]
runtime.invalid.request.5473:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5474:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5475:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5476:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5477:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5472:
  %record.make.handle.5478 = load i64, ptr %workspace.slot.5470, align 8
  %ctx.field.5479 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5480 = load i32, ptr %ctx.field.5479, align 4
  %steps.next.5481 = add i32 %steps.current.5480, 1
  store i32 %steps.next.5481, ptr %ctx.field.5479, align 4
  %steps.over.5482 = icmp ugt i32 %steps.next.5481, 10000
  br i1 %steps.over.5482, label %failure.5483, label %continue.5484
failure.5483:
  %ctx.field.5485 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 477, ptr %ctx.field.5485, align 4
  %status.diagnostic.5486 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5486, align 4
  ret void
continue.5484:
  %depth.exceeded.5487 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5487, label %failure.5488, label %continue.5489
failure.5488:
  %ctx.field.5490 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 478, ptr %ctx.field.5490, align 4
  %status.diagnostic.5491 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5491, align 4
  ret void
continue.5489:
  %workspace.slot.5492 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5478, ptr %workspace.slot.5492, align 8
  %workspace.slot.5493 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5494 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 157, ptr %outputs, i32 1, ptr %workspace.slot.5493)
  switch i32 %record.make.status.5494, label %runtime.invalid.result.5500 [ i32 0, label %runtime.success.5495 i32 1, label %runtime.invalid.request.5496 i32 2, label %runtime.invalid.reference.5497 i32 3, label %runtime.scratch.capacity.5498 i32 4, label %runtime.retained.capacity.5499 ]
runtime.invalid.request.5496:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5497:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5498:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5499:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5500:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5495:
  %record.make.handle.5501 = load i64, ptr %workspace.slot.5493, align 8
  %ctx.field.5502 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5503 = load i32, ptr %ctx.field.5502, align 4
  %steps.next.5504 = add i32 %steps.current.5503, 1
  store i32 %steps.next.5504, ptr %ctx.field.5502, align 4
  %steps.over.5505 = icmp ugt i32 %steps.next.5504, 10000
  br i1 %steps.over.5505, label %failure.5506, label %continue.5507
failure.5506:
  %ctx.field.5508 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 479, ptr %ctx.field.5508, align 4
  %status.diagnostic.5509 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5509, align 4
  ret void
continue.5507:
  %depth.exceeded.5510 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5510, label %failure.5511, label %continue.5512
failure.5511:
  %ctx.field.5513 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 480, ptr %ctx.field.5513, align 4
  %status.diagnostic.5514 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5514, align 4
  ret void
continue.5512:
  %workspace.slot.5515 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5501, ptr %workspace.slot.5515, align 8
  %workspace.slot.5516 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5517 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 158, ptr %outputs, i32 1, ptr %workspace.slot.5516)
  switch i32 %record.make.status.5517, label %runtime.invalid.result.5523 [ i32 0, label %runtime.success.5518 i32 1, label %runtime.invalid.request.5519 i32 2, label %runtime.invalid.reference.5520 i32 3, label %runtime.scratch.capacity.5521 i32 4, label %runtime.retained.capacity.5522 ]
runtime.invalid.request.5519:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5520:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5521:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5522:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5523:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5518:
  %record.make.handle.5524 = load i64, ptr %workspace.slot.5516, align 8
  %ctx.field.5525 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5526 = load i32, ptr %ctx.field.5525, align 4
  %steps.next.5527 = add i32 %steps.current.5526, 1
  store i32 %steps.next.5527, ptr %ctx.field.5525, align 4
  %steps.over.5528 = icmp ugt i32 %steps.next.5527, 10000
  br i1 %steps.over.5528, label %failure.5529, label %continue.5530
failure.5529:
  %ctx.field.5531 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 481, ptr %ctx.field.5531, align 4
  %status.diagnostic.5532 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5532, align 4
  ret void
continue.5530:
  %depth.exceeded.5533 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5533, label %failure.5534, label %continue.5535
failure.5534:
  %ctx.field.5536 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 482, ptr %ctx.field.5536, align 4
  %status.diagnostic.5537 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5537, align 4
  ret void
continue.5535:
  %workspace.slot.5538 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5524, ptr %workspace.slot.5538, align 8
  %workspace.slot.5539 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5540 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 159, ptr %outputs, i32 1, ptr %workspace.slot.5539)
  switch i32 %record.make.status.5540, label %runtime.invalid.result.5546 [ i32 0, label %runtime.success.5541 i32 1, label %runtime.invalid.request.5542 i32 2, label %runtime.invalid.reference.5543 i32 3, label %runtime.scratch.capacity.5544 i32 4, label %runtime.retained.capacity.5545 ]
runtime.invalid.request.5542:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5543:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5544:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5545:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5546:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5541:
  %record.make.handle.5547 = load i64, ptr %workspace.slot.5539, align 8
  %ctx.field.5548 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5549 = load i32, ptr %ctx.field.5548, align 4
  %steps.next.5550 = add i32 %steps.current.5549, 1
  store i32 %steps.next.5550, ptr %ctx.field.5548, align 4
  %steps.over.5551 = icmp ugt i32 %steps.next.5550, 10000
  br i1 %steps.over.5551, label %failure.5552, label %continue.5553
failure.5552:
  %ctx.field.5554 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 483, ptr %ctx.field.5554, align 4
  %status.diagnostic.5555 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5555, align 4
  ret void
continue.5553:
  %depth.exceeded.5556 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5556, label %failure.5557, label %continue.5558
failure.5557:
  %ctx.field.5559 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 484, ptr %ctx.field.5559, align 4
  %status.diagnostic.5560 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5560, align 4
  ret void
continue.5558:
  %workspace.slot.5561 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5547, ptr %workspace.slot.5561, align 8
  %workspace.slot.5562 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5563 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 161, ptr %outputs, i32 1, ptr %workspace.slot.5562)
  switch i32 %record.make.status.5563, label %runtime.invalid.result.5569 [ i32 0, label %runtime.success.5564 i32 1, label %runtime.invalid.request.5565 i32 2, label %runtime.invalid.reference.5566 i32 3, label %runtime.scratch.capacity.5567 i32 4, label %runtime.retained.capacity.5568 ]
runtime.invalid.request.5565:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5566:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5567:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5568:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5569:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5564:
  %record.make.handle.5570 = load i64, ptr %workspace.slot.5562, align 8
  %ctx.field.5571 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5572 = load i32, ptr %ctx.field.5571, align 4
  %steps.next.5573 = add i32 %steps.current.5572, 1
  store i32 %steps.next.5573, ptr %ctx.field.5571, align 4
  %steps.over.5574 = icmp ugt i32 %steps.next.5573, 10000
  br i1 %steps.over.5574, label %failure.5575, label %continue.5576
failure.5575:
  %ctx.field.5577 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 485, ptr %ctx.field.5577, align 4
  %status.diagnostic.5578 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5578, align 4
  ret void
continue.5576:
  %depth.exceeded.5579 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5579, label %failure.5580, label %continue.5581
failure.5580:
  %ctx.field.5582 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 486, ptr %ctx.field.5582, align 4
  %status.diagnostic.5583 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5583, align 4
  ret void
continue.5581:
  %workspace.slot.5584 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5570, ptr %workspace.slot.5584, align 8
  %workspace.slot.5585 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5586 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 162, ptr %outputs, i32 1, ptr %workspace.slot.5585)
  switch i32 %record.make.status.5586, label %runtime.invalid.result.5592 [ i32 0, label %runtime.success.5587 i32 1, label %runtime.invalid.request.5588 i32 2, label %runtime.invalid.reference.5589 i32 3, label %runtime.scratch.capacity.5590 i32 4, label %runtime.retained.capacity.5591 ]
runtime.invalid.request.5588:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5589:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5590:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5591:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5592:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5587:
  %record.make.handle.5593 = load i64, ptr %workspace.slot.5585, align 8
  %ctx.field.5594 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5595 = load i32, ptr %ctx.field.5594, align 4
  %steps.next.5596 = add i32 %steps.current.5595, 1
  store i32 %steps.next.5596, ptr %ctx.field.5594, align 4
  %steps.over.5597 = icmp ugt i32 %steps.next.5596, 10000
  br i1 %steps.over.5597, label %failure.5598, label %continue.5599
failure.5598:
  %ctx.field.5600 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 487, ptr %ctx.field.5600, align 4
  %status.diagnostic.5601 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5601, align 4
  ret void
continue.5599:
  %depth.exceeded.5602 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5602, label %failure.5603, label %continue.5604
failure.5603:
  %ctx.field.5605 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 488, ptr %ctx.field.5605, align 4
  %status.diagnostic.5606 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5606, align 4
  ret void
continue.5604:
  %workspace.slot.5607 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5593, ptr %workspace.slot.5607, align 8
  %workspace.slot.5608 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5609 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 163, ptr %outputs, i32 1, ptr %workspace.slot.5608)
  switch i32 %record.make.status.5609, label %runtime.invalid.result.5615 [ i32 0, label %runtime.success.5610 i32 1, label %runtime.invalid.request.5611 i32 2, label %runtime.invalid.reference.5612 i32 3, label %runtime.scratch.capacity.5613 i32 4, label %runtime.retained.capacity.5614 ]
runtime.invalid.request.5611:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5612:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5613:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5614:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5615:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5610:
  %record.make.handle.5616 = load i64, ptr %workspace.slot.5608, align 8
  %ctx.field.5617 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5618 = load i32, ptr %ctx.field.5617, align 4
  %steps.next.5619 = add i32 %steps.current.5618, 1
  store i32 %steps.next.5619, ptr %ctx.field.5617, align 4
  %steps.over.5620 = icmp ugt i32 %steps.next.5619, 10000
  br i1 %steps.over.5620, label %failure.5621, label %continue.5622
failure.5621:
  %ctx.field.5623 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 489, ptr %ctx.field.5623, align 4
  %status.diagnostic.5624 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5624, align 4
  ret void
continue.5622:
  %depth.exceeded.5625 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5625, label %failure.5626, label %continue.5627
failure.5626:
  %ctx.field.5628 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 490, ptr %ctx.field.5628, align 4
  %status.diagnostic.5629 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5629, align 4
  ret void
continue.5627:
  %workspace.slot.5630 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5616, ptr %workspace.slot.5630, align 8
  %workspace.slot.5631 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5632 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 164, ptr %outputs, i32 1, ptr %workspace.slot.5631)
  switch i32 %record.make.status.5632, label %runtime.invalid.result.5638 [ i32 0, label %runtime.success.5633 i32 1, label %runtime.invalid.request.5634 i32 2, label %runtime.invalid.reference.5635 i32 3, label %runtime.scratch.capacity.5636 i32 4, label %runtime.retained.capacity.5637 ]
runtime.invalid.request.5634:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5635:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5636:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5637:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5638:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5633:
  %record.make.handle.5639 = load i64, ptr %workspace.slot.5631, align 8
  %ctx.field.5640 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5641 = load i32, ptr %ctx.field.5640, align 4
  %steps.next.5642 = add i32 %steps.current.5641, 1
  store i32 %steps.next.5642, ptr %ctx.field.5640, align 4
  %steps.over.5643 = icmp ugt i32 %steps.next.5642, 10000
  br i1 %steps.over.5643, label %failure.5644, label %continue.5645
failure.5644:
  %ctx.field.5646 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 491, ptr %ctx.field.5646, align 4
  %status.diagnostic.5647 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5647, align 4
  ret void
continue.5645:
  %depth.exceeded.5648 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5648, label %failure.5649, label %continue.5650
failure.5649:
  %ctx.field.5651 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 492, ptr %ctx.field.5651, align 4
  %status.diagnostic.5652 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5652, align 4
  ret void
continue.5650:
  %workspace.slot.5653 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5639, ptr %workspace.slot.5653, align 8
  %workspace.slot.5654 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5655 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 165, ptr %outputs, i32 1, ptr %workspace.slot.5654)
  switch i32 %record.make.status.5655, label %runtime.invalid.result.5661 [ i32 0, label %runtime.success.5656 i32 1, label %runtime.invalid.request.5657 i32 2, label %runtime.invalid.reference.5658 i32 3, label %runtime.scratch.capacity.5659 i32 4, label %runtime.retained.capacity.5660 ]
runtime.invalid.request.5657:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5658:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5659:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5660:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5661:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5656:
  %record.make.handle.5662 = load i64, ptr %workspace.slot.5654, align 8
  %ctx.field.5663 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5664 = load i32, ptr %ctx.field.5663, align 4
  %steps.next.5665 = add i32 %steps.current.5664, 1
  store i32 %steps.next.5665, ptr %ctx.field.5663, align 4
  %steps.over.5666 = icmp ugt i32 %steps.next.5665, 10000
  br i1 %steps.over.5666, label %failure.5667, label %continue.5668
failure.5667:
  %ctx.field.5669 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 493, ptr %ctx.field.5669, align 4
  %status.diagnostic.5670 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5670, align 4
  ret void
continue.5668:
  %depth.exceeded.5671 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5671, label %failure.5672, label %continue.5673
failure.5672:
  %ctx.field.5674 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 494, ptr %ctx.field.5674, align 4
  %status.diagnostic.5675 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5675, align 4
  ret void
continue.5673:
  %workspace.slot.5676 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5662, ptr %workspace.slot.5676, align 8
  %workspace.slot.5677 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5678 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 166, ptr %outputs, i32 1, ptr %workspace.slot.5677)
  switch i32 %record.make.status.5678, label %runtime.invalid.result.5684 [ i32 0, label %runtime.success.5679 i32 1, label %runtime.invalid.request.5680 i32 2, label %runtime.invalid.reference.5681 i32 3, label %runtime.scratch.capacity.5682 i32 4, label %runtime.retained.capacity.5683 ]
runtime.invalid.request.5680:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5681:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5682:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5683:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5684:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5679:
  %record.make.handle.5685 = load i64, ptr %workspace.slot.5677, align 8
  %ctx.field.5686 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5687 = load i32, ptr %ctx.field.5686, align 4
  %steps.next.5688 = add i32 %steps.current.5687, 1
  store i32 %steps.next.5688, ptr %ctx.field.5686, align 4
  %steps.over.5689 = icmp ugt i32 %steps.next.5688, 10000
  br i1 %steps.over.5689, label %failure.5690, label %continue.5691
failure.5690:
  %ctx.field.5692 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 495, ptr %ctx.field.5692, align 4
  %status.diagnostic.5693 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5693, align 4
  ret void
continue.5691:
  %depth.exceeded.5694 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5694, label %failure.5695, label %continue.5696
failure.5695:
  %ctx.field.5697 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 496, ptr %ctx.field.5697, align 4
  %status.diagnostic.5698 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5698, align 4
  ret void
continue.5696:
  %workspace.slot.5699 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5685, ptr %workspace.slot.5699, align 8
  %workspace.slot.5700 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5701 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 167, ptr %outputs, i32 1, ptr %workspace.slot.5700)
  switch i32 %record.make.status.5701, label %runtime.invalid.result.5707 [ i32 0, label %runtime.success.5702 i32 1, label %runtime.invalid.request.5703 i32 2, label %runtime.invalid.reference.5704 i32 3, label %runtime.scratch.capacity.5705 i32 4, label %runtime.retained.capacity.5706 ]
runtime.invalid.request.5703:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5704:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5705:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5706:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5707:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5702:
  %record.make.handle.5708 = load i64, ptr %workspace.slot.5700, align 8
  %ctx.field.5709 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5710 = load i32, ptr %ctx.field.5709, align 4
  %steps.next.5711 = add i32 %steps.current.5710, 1
  store i32 %steps.next.5711, ptr %ctx.field.5709, align 4
  %steps.over.5712 = icmp ugt i32 %steps.next.5711, 10000
  br i1 %steps.over.5712, label %failure.5713, label %continue.5714
failure.5713:
  %ctx.field.5715 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 497, ptr %ctx.field.5715, align 4
  %status.diagnostic.5716 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5716, align 4
  ret void
continue.5714:
  %depth.exceeded.5717 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5717, label %failure.5718, label %continue.5719
failure.5718:
  %ctx.field.5720 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 498, ptr %ctx.field.5720, align 4
  %status.diagnostic.5721 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5721, align 4
  ret void
continue.5719:
  %workspace.slot.5722 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5708, ptr %workspace.slot.5722, align 8
  %workspace.slot.5723 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5724 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 168, ptr %outputs, i32 1, ptr %workspace.slot.5723)
  switch i32 %record.make.status.5724, label %runtime.invalid.result.5730 [ i32 0, label %runtime.success.5725 i32 1, label %runtime.invalid.request.5726 i32 2, label %runtime.invalid.reference.5727 i32 3, label %runtime.scratch.capacity.5728 i32 4, label %runtime.retained.capacity.5729 ]
runtime.invalid.request.5726:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5727:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5728:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5729:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5730:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5725:
  %record.make.handle.5731 = load i64, ptr %workspace.slot.5723, align 8
  %ctx.field.5732 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5733 = load i32, ptr %ctx.field.5732, align 4
  %steps.next.5734 = add i32 %steps.current.5733, 1
  store i32 %steps.next.5734, ptr %ctx.field.5732, align 4
  %steps.over.5735 = icmp ugt i32 %steps.next.5734, 10000
  br i1 %steps.over.5735, label %failure.5736, label %continue.5737
failure.5736:
  %ctx.field.5738 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 499, ptr %ctx.field.5738, align 4
  %status.diagnostic.5739 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5739, align 4
  ret void
continue.5737:
  %depth.exceeded.5740 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5740, label %failure.5741, label %continue.5742
failure.5741:
  %ctx.field.5743 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 500, ptr %ctx.field.5743, align 4
  %status.diagnostic.5744 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5744, align 4
  ret void
continue.5742:
  %workspace.slot.5745 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5731, ptr %workspace.slot.5745, align 8
  %workspace.slot.5746 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5747 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 169, ptr %outputs, i32 1, ptr %workspace.slot.5746)
  switch i32 %record.make.status.5747, label %runtime.invalid.result.5753 [ i32 0, label %runtime.success.5748 i32 1, label %runtime.invalid.request.5749 i32 2, label %runtime.invalid.reference.5750 i32 3, label %runtime.scratch.capacity.5751 i32 4, label %runtime.retained.capacity.5752 ]
runtime.invalid.request.5749:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5750:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5751:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5752:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5753:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5748:
  %record.make.handle.5754 = load i64, ptr %workspace.slot.5746, align 8
  %ctx.field.5755 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5756 = load i32, ptr %ctx.field.5755, align 4
  %steps.next.5757 = add i32 %steps.current.5756, 1
  store i32 %steps.next.5757, ptr %ctx.field.5755, align 4
  %steps.over.5758 = icmp ugt i32 %steps.next.5757, 10000
  br i1 %steps.over.5758, label %failure.5759, label %continue.5760
failure.5759:
  %ctx.field.5761 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 501, ptr %ctx.field.5761, align 4
  %status.diagnostic.5762 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5762, align 4
  ret void
continue.5760:
  %depth.exceeded.5763 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5763, label %failure.5764, label %continue.5765
failure.5764:
  %ctx.field.5766 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 502, ptr %ctx.field.5766, align 4
  %status.diagnostic.5767 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5767, align 4
  ret void
continue.5765:
  %workspace.slot.5768 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5754, ptr %workspace.slot.5768, align 8
  %workspace.slot.5769 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5770 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 170, ptr %outputs, i32 1, ptr %workspace.slot.5769)
  switch i32 %record.make.status.5770, label %runtime.invalid.result.5776 [ i32 0, label %runtime.success.5771 i32 1, label %runtime.invalid.request.5772 i32 2, label %runtime.invalid.reference.5773 i32 3, label %runtime.scratch.capacity.5774 i32 4, label %runtime.retained.capacity.5775 ]
runtime.invalid.request.5772:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5773:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5774:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5775:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5776:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5771:
  %record.make.handle.5777 = load i64, ptr %workspace.slot.5769, align 8
  %ctx.field.5778 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5779 = load i32, ptr %ctx.field.5778, align 4
  %steps.next.5780 = add i32 %steps.current.5779, 1
  store i32 %steps.next.5780, ptr %ctx.field.5778, align 4
  %steps.over.5781 = icmp ugt i32 %steps.next.5780, 10000
  br i1 %steps.over.5781, label %failure.5782, label %continue.5783
failure.5782:
  %ctx.field.5784 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 503, ptr %ctx.field.5784, align 4
  %status.diagnostic.5785 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5785, align 4
  ret void
continue.5783:
  %depth.exceeded.5786 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5786, label %failure.5787, label %continue.5788
failure.5787:
  %ctx.field.5789 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 504, ptr %ctx.field.5789, align 4
  %status.diagnostic.5790 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5790, align 4
  ret void
continue.5788:
  %workspace.slot.5791 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5777, ptr %workspace.slot.5791, align 8
  %workspace.slot.5792 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5793 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 172, ptr %outputs, i32 1, ptr %workspace.slot.5792)
  switch i32 %record.make.status.5793, label %runtime.invalid.result.5799 [ i32 0, label %runtime.success.5794 i32 1, label %runtime.invalid.request.5795 i32 2, label %runtime.invalid.reference.5796 i32 3, label %runtime.scratch.capacity.5797 i32 4, label %runtime.retained.capacity.5798 ]
runtime.invalid.request.5795:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5796:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5797:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5798:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5799:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5794:
  %record.make.handle.5800 = load i64, ptr %workspace.slot.5792, align 8
  %ctx.field.5801 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5802 = load i32, ptr %ctx.field.5801, align 4
  %steps.next.5803 = add i32 %steps.current.5802, 1
  store i32 %steps.next.5803, ptr %ctx.field.5801, align 4
  %steps.over.5804 = icmp ugt i32 %steps.next.5803, 10000
  br i1 %steps.over.5804, label %failure.5805, label %continue.5806
failure.5805:
  %ctx.field.5807 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 505, ptr %ctx.field.5807, align 4
  %status.diagnostic.5808 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5808, align 4
  ret void
continue.5806:
  %depth.exceeded.5809 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5809, label %failure.5810, label %continue.5811
failure.5810:
  %ctx.field.5812 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 506, ptr %ctx.field.5812, align 4
  %status.diagnostic.5813 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5813, align 4
  ret void
continue.5811:
  %workspace.slot.5814 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5800, ptr %workspace.slot.5814, align 8
  %workspace.slot.5815 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5816 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 173, ptr %outputs, i32 1, ptr %workspace.slot.5815)
  switch i32 %record.make.status.5816, label %runtime.invalid.result.5822 [ i32 0, label %runtime.success.5817 i32 1, label %runtime.invalid.request.5818 i32 2, label %runtime.invalid.reference.5819 i32 3, label %runtime.scratch.capacity.5820 i32 4, label %runtime.retained.capacity.5821 ]
runtime.invalid.request.5818:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5819:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5820:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5821:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5822:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5817:
  %record.make.handle.5823 = load i64, ptr %workspace.slot.5815, align 8
  %ctx.field.5824 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5825 = load i32, ptr %ctx.field.5824, align 4
  %steps.next.5826 = add i32 %steps.current.5825, 1
  store i32 %steps.next.5826, ptr %ctx.field.5824, align 4
  %steps.over.5827 = icmp ugt i32 %steps.next.5826, 10000
  br i1 %steps.over.5827, label %failure.5828, label %continue.5829
failure.5828:
  %ctx.field.5830 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 507, ptr %ctx.field.5830, align 4
  %status.diagnostic.5831 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5831, align 4
  ret void
continue.5829:
  %depth.exceeded.5832 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5832, label %failure.5833, label %continue.5834
failure.5833:
  %ctx.field.5835 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 508, ptr %ctx.field.5835, align 4
  %status.diagnostic.5836 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5836, align 4
  ret void
continue.5834:
  %workspace.slot.5837 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5823, ptr %workspace.slot.5837, align 8
  %workspace.slot.5838 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5839 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 174, ptr %outputs, i32 1, ptr %workspace.slot.5838)
  switch i32 %record.make.status.5839, label %runtime.invalid.result.5845 [ i32 0, label %runtime.success.5840 i32 1, label %runtime.invalid.request.5841 i32 2, label %runtime.invalid.reference.5842 i32 3, label %runtime.scratch.capacity.5843 i32 4, label %runtime.retained.capacity.5844 ]
runtime.invalid.request.5841:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5842:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5843:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5844:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5845:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5840:
  %record.make.handle.5846 = load i64, ptr %workspace.slot.5838, align 8
  %ctx.field.5847 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5848 = load i32, ptr %ctx.field.5847, align 4
  %steps.next.5849 = add i32 %steps.current.5848, 1
  store i32 %steps.next.5849, ptr %ctx.field.5847, align 4
  %steps.over.5850 = icmp ugt i32 %steps.next.5849, 10000
  br i1 %steps.over.5850, label %failure.5851, label %continue.5852
failure.5851:
  %ctx.field.5853 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 509, ptr %ctx.field.5853, align 4
  %status.diagnostic.5854 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5854, align 4
  ret void
continue.5852:
  %depth.exceeded.5855 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5855, label %failure.5856, label %continue.5857
failure.5856:
  %ctx.field.5858 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 510, ptr %ctx.field.5858, align 4
  %status.diagnostic.5859 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5859, align 4
  ret void
continue.5857:
  %workspace.slot.5860 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5846, ptr %workspace.slot.5860, align 8
  %workspace.slot.5861 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5862 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 175, ptr %outputs, i32 1, ptr %workspace.slot.5861)
  switch i32 %record.make.status.5862, label %runtime.invalid.result.5868 [ i32 0, label %runtime.success.5863 i32 1, label %runtime.invalid.request.5864 i32 2, label %runtime.invalid.reference.5865 i32 3, label %runtime.scratch.capacity.5866 i32 4, label %runtime.retained.capacity.5867 ]
runtime.invalid.request.5864:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5865:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5866:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5867:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5868:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5863:
  %record.make.handle.5869 = load i64, ptr %workspace.slot.5861, align 8
  %ctx.field.5870 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5871 = load i32, ptr %ctx.field.5870, align 4
  %steps.next.5872 = add i32 %steps.current.5871, 1
  store i32 %steps.next.5872, ptr %ctx.field.5870, align 4
  %steps.over.5873 = icmp ugt i32 %steps.next.5872, 10000
  br i1 %steps.over.5873, label %failure.5874, label %continue.5875
failure.5874:
  %ctx.field.5876 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 511, ptr %ctx.field.5876, align 4
  %status.diagnostic.5877 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5877, align 4
  ret void
continue.5875:
  %depth.exceeded.5878 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5878, label %failure.5879, label %continue.5880
failure.5879:
  %ctx.field.5881 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 512, ptr %ctx.field.5881, align 4
  %status.diagnostic.5882 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5882, align 4
  ret void
continue.5880:
  %workspace.slot.5883 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5869, ptr %workspace.slot.5883, align 8
  %workspace.slot.5884 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5885 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 176, ptr %outputs, i32 1, ptr %workspace.slot.5884)
  switch i32 %record.make.status.5885, label %runtime.invalid.result.5891 [ i32 0, label %runtime.success.5886 i32 1, label %runtime.invalid.request.5887 i32 2, label %runtime.invalid.reference.5888 i32 3, label %runtime.scratch.capacity.5889 i32 4, label %runtime.retained.capacity.5890 ]
runtime.invalid.request.5887:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5888:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5889:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5890:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5891:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5886:
  %record.make.handle.5892 = load i64, ptr %workspace.slot.5884, align 8
  %ctx.field.5893 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5894 = load i32, ptr %ctx.field.5893, align 4
  %steps.next.5895 = add i32 %steps.current.5894, 1
  store i32 %steps.next.5895, ptr %ctx.field.5893, align 4
  %steps.over.5896 = icmp ugt i32 %steps.next.5895, 10000
  br i1 %steps.over.5896, label %failure.5897, label %continue.5898
failure.5897:
  %ctx.field.5899 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 513, ptr %ctx.field.5899, align 4
  %status.diagnostic.5900 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5900, align 4
  ret void
continue.5898:
  %depth.exceeded.5901 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5901, label %failure.5902, label %continue.5903
failure.5902:
  %ctx.field.5904 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 514, ptr %ctx.field.5904, align 4
  %status.diagnostic.5905 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5905, align 4
  ret void
continue.5903:
  %workspace.slot.5906 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %record.make.handle.5892, ptr %workspace.slot.5906, align 8
  %workspace.slot.5907 = getelementptr inbounds i64, ptr %outputs, i64 1
  %record.make.status.5908 = call i32 @al_runtime_make_record(ptr %ctx, ptr @agentlang_program, i32 177, ptr %outputs, i32 1, ptr %workspace.slot.5907)
  switch i32 %record.make.status.5908, label %runtime.invalid.result.5914 [ i32 0, label %runtime.success.5909 i32 1, label %runtime.invalid.request.5910 i32 2, label %runtime.invalid.reference.5911 i32 3, label %runtime.scratch.capacity.5912 i32 4, label %runtime.retained.capacity.5913 ]
runtime.invalid.request.5910:
  store i32 2, ptr %status, align 4
  ret void
runtime.invalid.reference.5911:
  store i32 5, ptr %status, align 4
  ret void
runtime.scratch.capacity.5912:
  store i32 3, ptr %status, align 4
  ret void
runtime.retained.capacity.5913:
  store i32 4, ptr %status, align 4
  ret void
runtime.invalid.result.5914:
  store i32 2, ptr %status, align 4
  ret void
runtime.success.5909:
  %record.make.handle.5915 = load i64, ptr %workspace.slot.5907, align 8
  br label %value.limit.failure.5916
value.limit.failure.5916:
  %ctx.field.5918 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 515, ptr %ctx.field.5918, align 4
  %status.diagnostic.5919 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5919, align 4
  ret void
value.limit.continue.5917:
  %ctx.field.5920 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5921 = load i32, ptr %ctx.field.5920, align 4
  %steps.next.5922 = add i32 %steps.current.5921, 1
  store i32 %steps.next.5922, ptr %ctx.field.5920, align 4
  %steps.over.5923 = icmp ugt i32 %steps.next.5922, 10000
  br i1 %steps.over.5923, label %failure.5924, label %continue.5925
failure.5924:
  %ctx.field.5926 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 516, ptr %ctx.field.5926, align 4
  %status.diagnostic.5927 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5927, align 4
  ret void
continue.5925:
  %depth.exceeded.5928 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.5928, label %failure.5929, label %continue.5930
failure.5929:
  %ctx.field.5931 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 517, ptr %ctx.field.5931, align 4
  %status.diagnostic.5932 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5932, align 4
  ret void
continue.5930:
  %ctx.field.5933 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5934 = load i32, ptr %ctx.field.5933, align 4
  %steps.next.5935 = add i32 %steps.current.5934, 1
  store i32 %steps.next.5935, ptr %ctx.field.5933, align 4
  %steps.over.5936 = icmp ugt i32 %steps.next.5935, 10000
  br i1 %steps.over.5936, label %failure.5937, label %continue.5938
failure.5937:
  %ctx.field.5939 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 518, ptr %ctx.field.5939, align 4
  %status.diagnostic.5940 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5940, align 4
  ret void
continue.5938:
  br label %if.merge.19
if.else.18:
  %ctx.field.5941 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.5942 = load i32, ptr %ctx.field.5941, align 4
  %steps.next.5943 = add i32 %steps.current.5942, 1
  store i32 %steps.next.5943, ptr %ctx.field.5941, align 4
  %steps.over.5944 = icmp ugt i32 %steps.next.5943, 10000
  br i1 %steps.over.5944, label %failure.5945, label %continue.5946
failure.5945:
  %ctx.field.5947 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 519, ptr %ctx.field.5947, align 4
  %status.diagnostic.5948 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.5948, align 4
  ret void
continue.5946:
  br label %if.merge.19
if.merge.19:
  %stack.phi.5949 = phi i64 [ 1, %continue.5938 ], [ 2, %continue.5946 ]
  %output.ptr.5950 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %stack.phi.5949, ptr %output.ptr.5950, align 8
  ret void
}

define dllexport i32 @agentlang_output_capacity() { ret i32 2 }

define dllexport void @agentlang_abi_layout(ptr %output) {
entry:
  %size.ptr = getelementptr %NativeExecutionContext, ptr null, i32 1
  %size = ptrtoint ptr %size.ptr to i64
  %align.ptr = getelementptr %NativeExecutionContextAlignmentProbe, ptr null, i32 0, i32 1
  %alignment = ptrtoint ptr %align.ptr to i64
  %field0.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 0
  %field0 = ptrtoint ptr %field0.ptr to i64
  %field1.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 1
  %field1 = ptrtoint ptr %field1.ptr to i64
  %field2.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 2
  %field2 = ptrtoint ptr %field2.ptr to i64
  %field3.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 3
  %field3 = ptrtoint ptr %field3.ptr to i64
  %field4.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 4
  %field4 = ptrtoint ptr %field4.ptr to i64
  %field5.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 5
  %field5 = ptrtoint ptr %field5.ptr to i64
  %field6.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 6
  %field6 = ptrtoint ptr %field6.ptr to i64
  %field7.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 7
  %field7 = ptrtoint ptr %field7.ptr to i64
  %field8.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 8
  %field8 = ptrtoint ptr %field8.ptr to i64
  %field9.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 9
  %field9 = ptrtoint ptr %field9.ptr to i64
  %field10.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 10
  %field10 = ptrtoint ptr %field10.ptr to i64
  %items = alloca [13 x i64], align 8
  %out0 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 0
  store i64 %size, ptr %out0, align 8
  %out1 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 1
  store i64 %alignment, ptr %out1, align 8
  %out2 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 2
  store i64 %field0, ptr %out2, align 8
  %out3 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 3
  store i64 %field1, ptr %out3, align 8
  %out4 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 4
  store i64 %field2, ptr %out4, align 8
  %out5 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 5
  store i64 %field3, ptr %out5, align 8
  %out6 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 6
  store i64 %field4, ptr %out6, align 8
  %out7 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 7
  store i64 %field5, ptr %out7, align 8
  %out8 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 8
  store i64 %field6, ptr %out8, align 8
  %out9 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 9
  store i64 %field7, ptr %out9, align 8
  %out10 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 10
  store i64 %field8, ptr %out10, align 8
  %out11 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 11
  store i64 %field9, ptr %out11, align 8
  %out12 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 12
  store i64 %field10, ptr %out12, align 8
  %item0 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 0
  %value0 = load i64, ptr %item0, align 8
  %dest0 = getelementptr inbounds i64, ptr %output, i64 0
  store i64 %value0, ptr %dest0, align 8
  %item1 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 1
  %value1 = load i64, ptr %item1, align 8
  %dest1 = getelementptr inbounds i64, ptr %output, i64 1
  store i64 %value1, ptr %dest1, align 8
  %item2 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 2
  %value2 = load i64, ptr %item2, align 8
  %dest2 = getelementptr inbounds i64, ptr %output, i64 2
  store i64 %value2, ptr %dest2, align 8
  %item3 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 3
  %value3 = load i64, ptr %item3, align 8
  %dest3 = getelementptr inbounds i64, ptr %output, i64 3
  store i64 %value3, ptr %dest3, align 8
  %item4 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 4
  %value4 = load i64, ptr %item4, align 8
  %dest4 = getelementptr inbounds i64, ptr %output, i64 4
  store i64 %value4, ptr %dest4, align 8
  %item5 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 5
  %value5 = load i64, ptr %item5, align 8
  %dest5 = getelementptr inbounds i64, ptr %output, i64 5
  store i64 %value5, ptr %dest5, align 8
  %item6 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 6
  %value6 = load i64, ptr %item6, align 8
  %dest6 = getelementptr inbounds i64, ptr %output, i64 6
  store i64 %value6, ptr %dest6, align 8
  %item7 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 7
  %value7 = load i64, ptr %item7, align 8
  %dest7 = getelementptr inbounds i64, ptr %output, i64 7
  store i64 %value7, ptr %dest7, align 8
  %item8 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 8
  %value8 = load i64, ptr %item8, align 8
  %dest8 = getelementptr inbounds i64, ptr %output, i64 8
  store i64 %value8, ptr %dest8, align 8
  %item9 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 9
  %value9 = load i64, ptr %item9, align 8
  %dest9 = getelementptr inbounds i64, ptr %output, i64 9
  store i64 %value9, ptr %dest9, align 8
  %item10 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 10
  %value10 = load i64, ptr %item10, align 8
  %dest10 = getelementptr inbounds i64, ptr %output, i64 10
  store i64 %value10, ptr %dest10, align 8
  %item11 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 11
  %value11 = load i64, ptr %item11, align 8
  %dest11 = getelementptr inbounds i64, ptr %output, i64 11
  store i64 %value11, ptr %dest11, align 8
  %item12 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 12
  %value12 = load i64, ptr %item12, align 8
  %dest12 = getelementptr inbounds i64, ptr %output, i64 12
  store i64 %value12, ptr %dest12, align 8
  ret void
}

define dllexport void @agentlang_execute(ptr %ctx, ptr %outputs, i32 %capacity, ptr %status) {
entry:
  %validation.result = call i32 @al_runtime_validate_request(ptr %ctx, ptr %outputs, i32 1, i32 %capacity, ptr %status, i32 2)
  %request.valid = icmp eq i32 %validation.result, 0
  br i1 %request.valid, label %request.accepted, label %request.rejected
request.rejected:
  ret void
request.accepted:
  %steps.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  store i32 0, ptr %steps.ptr, align 4
  %error.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 -1, ptr %error.ptr, align 4
  %reserved.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 3
  store i32 0, ptr %reserved.ptr, align 4
  %arg0.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 4
  store i64 0, ptr %arg0.ptr, align 8
  %arg1.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 5
  store i64 0, ptr %arg1.ptr, align 8
  %workspace.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 8
  %workspace = load ptr, ptr %workspace.ptr, align 8
  call void @agentlang_body(ptr %ctx, ptr %workspace, ptr %status, i32 0)
  %body.status = load i32, ptr %status, align 4
  %body.succeeded = icmp eq i32 %body.status, 0
  br i1 %body.succeeded, label %promote, label %body.failed
body.failed:
  ret void
promote:
  %promote.result = call i32 @al_runtime_promote(ptr %ctx, ptr @agentlang_program, ptr %workspace, ptr @agentlang_root_type_ids, i32 1, ptr %outputs, i32 %capacity)
  switch i32 %promote.result, label %promote.invalid [ i32 0, label %promote.succeeded i32 1, label %promote.invalid.request i32 2, label %promote.invalid.reference i32 3, label %promote.scratch.capacity i32 4, label %promote.retained.capacity ]
promote.invalid:
  store i32 2, ptr %status, align 4
  ret void
promote.invalid.request:
  store i32 2, ptr %status, align 4
  ret void
promote.invalid.reference:
  store i32 5, ptr %status, align 4
  ret void
promote.scratch.capacity:
  store i32 3, ptr %status, align 4
  ret void
promote.retained.capacity:
  store i32 4, ptr %status, align 4
  ret void
promote.succeeded:
  ret void
}

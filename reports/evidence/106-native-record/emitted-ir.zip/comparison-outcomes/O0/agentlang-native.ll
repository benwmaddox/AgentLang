target triple = "x86_64-pc-windows-msvc"
%NativeExecutionContext = type { i32, i32, i32, i32, i64, i64, ptr, ptr, ptr, i32, i32 }
%NativeExecutionContextAlignmentProbe = type { i8, %NativeExecutionContext }
%NativeTypeDescriptor = type { i32, i32, ptr }
%NativeProgramDescriptor = type { ptr, i32, i32 }
declare i32 @al_runtime_validate_request(ptr, ptr, i32, i32, ptr, i32)
declare i32 @al_runtime_make_record(ptr, ptr, i32, ptr, i32, ptr)
declare i32 @al_runtime_get_field(ptr, ptr, i32, i64, i32, ptr)
declare i32 @al_runtime_equal(ptr, ptr, i32, i64, i64, ptr)
declare i32 @al_runtime_promote(ptr, ptr, ptr, ptr, i32, ptr, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

@agentlang_type_descriptors = private constant [3 x %NativeTypeDescriptor] [%NativeTypeDescriptor { i32 1, i32 0, ptr null }, %NativeTypeDescriptor { i32 2, i32 0, ptr null }, %NativeTypeDescriptor { i32 3, i32 0, ptr null }]
@agentlang_program = private constant %NativeProgramDescriptor { ptr getelementptr inbounds ([3 x %NativeTypeDescriptor], ptr @agentlang_type_descriptors, i32 0, i32 0), i32 3, i32 0 }
@agentlang_root_type_ids = private constant [8 x i32] [i32 1, i32 1, i32 1, i32 1, i32 1, i32 1, i32 1, i32 1]

define internal void @agentlang_body(ptr %ctx, ptr %outputs, ptr %status, i32 %depth) {
entry:
  %ctx.field.0 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1 = load i32, ptr %ctx.field.0, align 4
  %steps.next.2 = add i32 %steps.current.1, 1
  store i32 %steps.next.2, ptr %ctx.field.0, align 4
  %steps.over.3 = icmp ugt i32 %steps.next.2, 10000
  br i1 %steps.over.3, label %failure.4, label %continue.5
failure.4:
  %ctx.field.6 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 0, ptr %ctx.field.6, align 4
  %status.diagnostic.7 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7, align 4
  ret void
continue.5:
  %ctx.field.8 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9 = load i32, ptr %ctx.field.8, align 4
  %steps.next.10 = add i32 %steps.current.9, 1
  store i32 %steps.next.10, ptr %ctx.field.8, align 4
  %steps.over.11 = icmp ugt i32 %steps.next.10, 10000
  br i1 %steps.over.11, label %failure.12, label %continue.13
failure.12:
  %ctx.field.14 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1, ptr %ctx.field.14, align 4
  %status.diagnostic.15 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.15, align 4
  ret void
continue.13:
  %ctx.field.16 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.17 = load i32, ptr %ctx.field.16, align 4
  %steps.next.18 = add i32 %steps.current.17, 1
  store i32 %steps.next.18, ptr %ctx.field.16, align 4
  %steps.over.19 = icmp ugt i32 %steps.next.18, 10000
  br i1 %steps.over.19, label %failure.20, label %continue.21
failure.20:
  %ctx.field.22 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 2, ptr %ctx.field.22, align 4
  %status.diagnostic.23 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.23, align 4
  ret void
continue.21:
  %depth.exceeded.24 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.24, label %failure.25, label %continue.26
failure.25:
  %ctx.field.27 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 3, ptr %ctx.field.27, align 4
  %status.diagnostic.28 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.28, align 4
  ret void
continue.26:
  %int.compare.29 = icmp slt i64 1, 2
  %bool.slot.30 = zext i1 %int.compare.29 to i64
  %ctx.field.31 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.32 = load i32, ptr %ctx.field.31, align 4
  %steps.next.33 = add i32 %steps.current.32, 1
  store i32 %steps.next.33, ptr %ctx.field.31, align 4
  %steps.over.34 = icmp ugt i32 %steps.next.33, 10000
  br i1 %steps.over.34, label %failure.35, label %continue.36
failure.35:
  %ctx.field.37 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 4, ptr %ctx.field.37, align 4
  %status.diagnostic.38 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.38, align 4
  ret void
continue.36:
  %ctx.field.39 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.40 = load i32, ptr %ctx.field.39, align 4
  %steps.next.41 = add i32 %steps.current.40, 1
  store i32 %steps.next.41, ptr %ctx.field.39, align 4
  %steps.over.42 = icmp ugt i32 %steps.next.41, 10000
  br i1 %steps.over.42, label %failure.43, label %continue.44
failure.43:
  %ctx.field.45 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 5, ptr %ctx.field.45, align 4
  %status.diagnostic.46 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.46, align 4
  ret void
continue.44:
  %ctx.field.47 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.48 = load i32, ptr %ctx.field.47, align 4
  %steps.next.49 = add i32 %steps.current.48, 1
  store i32 %steps.next.49, ptr %ctx.field.47, align 4
  %steps.over.50 = icmp ugt i32 %steps.next.49, 10000
  br i1 %steps.over.50, label %failure.51, label %continue.52
failure.51:
  %ctx.field.53 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 6, ptr %ctx.field.53, align 4
  %status.diagnostic.54 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.54, align 4
  ret void
continue.52:
  %depth.exceeded.55 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.55, label %failure.56, label %continue.57
failure.56:
  %ctx.field.58 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 7, ptr %ctx.field.58, align 4
  %status.diagnostic.59 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.59, align 4
  ret void
continue.57:
  %int.compare.60 = icmp slt i64 2, 1
  %bool.slot.61 = zext i1 %int.compare.60 to i64
  %ctx.field.62 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.63 = load i32, ptr %ctx.field.62, align 4
  %steps.next.64 = add i32 %steps.current.63, 1
  store i32 %steps.next.64, ptr %ctx.field.62, align 4
  %steps.over.65 = icmp ugt i32 %steps.next.64, 10000
  br i1 %steps.over.65, label %failure.66, label %continue.67
failure.66:
  %ctx.field.68 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 8, ptr %ctx.field.68, align 4
  %status.diagnostic.69 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.69, align 4
  ret void
continue.67:
  %ctx.field.70 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.71 = load i32, ptr %ctx.field.70, align 4
  %steps.next.72 = add i32 %steps.current.71, 1
  store i32 %steps.next.72, ptr %ctx.field.70, align 4
  %steps.over.73 = icmp ugt i32 %steps.next.72, 10000
  br i1 %steps.over.73, label %failure.74, label %continue.75
failure.74:
  %ctx.field.76 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 9, ptr %ctx.field.76, align 4
  %status.diagnostic.77 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.77, align 4
  ret void
continue.75:
  %ctx.field.78 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.79 = load i32, ptr %ctx.field.78, align 4
  %steps.next.80 = add i32 %steps.current.79, 1
  store i32 %steps.next.80, ptr %ctx.field.78, align 4
  %steps.over.81 = icmp ugt i32 %steps.next.80, 10000
  br i1 %steps.over.81, label %failure.82, label %continue.83
failure.82:
  %ctx.field.84 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 10, ptr %ctx.field.84, align 4
  %status.diagnostic.85 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.85, align 4
  ret void
continue.83:
  %depth.exceeded.86 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.86, label %failure.87, label %continue.88
failure.87:
  %ctx.field.89 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 11, ptr %ctx.field.89, align 4
  %status.diagnostic.90 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.90, align 4
  ret void
continue.88:
  %int.compare.91 = icmp sgt i64 2, 1
  %bool.slot.92 = zext i1 %int.compare.91 to i64
  %ctx.field.93 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.94 = load i32, ptr %ctx.field.93, align 4
  %steps.next.95 = add i32 %steps.current.94, 1
  store i32 %steps.next.95, ptr %ctx.field.93, align 4
  %steps.over.96 = icmp ugt i32 %steps.next.95, 10000
  br i1 %steps.over.96, label %failure.97, label %continue.98
failure.97:
  %ctx.field.99 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 12, ptr %ctx.field.99, align 4
  %status.diagnostic.100 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.100, align 4
  ret void
continue.98:
  %ctx.field.101 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.102 = load i32, ptr %ctx.field.101, align 4
  %steps.next.103 = add i32 %steps.current.102, 1
  store i32 %steps.next.103, ptr %ctx.field.101, align 4
  %steps.over.104 = icmp ugt i32 %steps.next.103, 10000
  br i1 %steps.over.104, label %failure.105, label %continue.106
failure.105:
  %ctx.field.107 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 13, ptr %ctx.field.107, align 4
  %status.diagnostic.108 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.108, align 4
  ret void
continue.106:
  %ctx.field.109 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.110 = load i32, ptr %ctx.field.109, align 4
  %steps.next.111 = add i32 %steps.current.110, 1
  store i32 %steps.next.111, ptr %ctx.field.109, align 4
  %steps.over.112 = icmp ugt i32 %steps.next.111, 10000
  br i1 %steps.over.112, label %failure.113, label %continue.114
failure.113:
  %ctx.field.115 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 14, ptr %ctx.field.115, align 4
  %status.diagnostic.116 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.116, align 4
  ret void
continue.114:
  %depth.exceeded.117 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.117, label %failure.118, label %continue.119
failure.118:
  %ctx.field.120 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 15, ptr %ctx.field.120, align 4
  %status.diagnostic.121 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.121, align 4
  ret void
continue.119:
  %int.compare.122 = icmp sgt i64 1, 2
  %bool.slot.123 = zext i1 %int.compare.122 to i64
  %ctx.field.124 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.125 = load i32, ptr %ctx.field.124, align 4
  %steps.next.126 = add i32 %steps.current.125, 1
  store i32 %steps.next.126, ptr %ctx.field.124, align 4
  %steps.over.127 = icmp ugt i32 %steps.next.126, 10000
  br i1 %steps.over.127, label %failure.128, label %continue.129
failure.128:
  %ctx.field.130 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 16, ptr %ctx.field.130, align 4
  %status.diagnostic.131 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.131, align 4
  ret void
continue.129:
  %ctx.field.132 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.133 = load i32, ptr %ctx.field.132, align 4
  %steps.next.134 = add i32 %steps.current.133, 1
  store i32 %steps.next.134, ptr %ctx.field.132, align 4
  %steps.over.135 = icmp ugt i32 %steps.next.134, 10000
  br i1 %steps.over.135, label %failure.136, label %continue.137
failure.136:
  %ctx.field.138 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 17, ptr %ctx.field.138, align 4
  %status.diagnostic.139 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.139, align 4
  ret void
continue.137:
  %ctx.field.140 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.141 = load i32, ptr %ctx.field.140, align 4
  %steps.next.142 = add i32 %steps.current.141, 1
  store i32 %steps.next.142, ptr %ctx.field.140, align 4
  %steps.over.143 = icmp ugt i32 %steps.next.142, 10000
  br i1 %steps.over.143, label %failure.144, label %continue.145
failure.144:
  %ctx.field.146 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 18, ptr %ctx.field.146, align 4
  %status.diagnostic.147 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.147, align 4
  ret void
continue.145:
  %depth.exceeded.148 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.148, label %failure.149, label %continue.150
failure.149:
  %ctx.field.151 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 19, ptr %ctx.field.151, align 4
  %status.diagnostic.152 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.152, align 4
  ret void
continue.150:
  %int.compare.153 = icmp sle i64 2, 2
  %bool.slot.154 = zext i1 %int.compare.153 to i64
  %ctx.field.155 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.156 = load i32, ptr %ctx.field.155, align 4
  %steps.next.157 = add i32 %steps.current.156, 1
  store i32 %steps.next.157, ptr %ctx.field.155, align 4
  %steps.over.158 = icmp ugt i32 %steps.next.157, 10000
  br i1 %steps.over.158, label %failure.159, label %continue.160
failure.159:
  %ctx.field.161 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 20, ptr %ctx.field.161, align 4
  %status.diagnostic.162 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.162, align 4
  ret void
continue.160:
  %ctx.field.163 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.164 = load i32, ptr %ctx.field.163, align 4
  %steps.next.165 = add i32 %steps.current.164, 1
  store i32 %steps.next.165, ptr %ctx.field.163, align 4
  %steps.over.166 = icmp ugt i32 %steps.next.165, 10000
  br i1 %steps.over.166, label %failure.167, label %continue.168
failure.167:
  %ctx.field.169 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 21, ptr %ctx.field.169, align 4
  %status.diagnostic.170 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.170, align 4
  ret void
continue.168:
  %ctx.field.171 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.172 = load i32, ptr %ctx.field.171, align 4
  %steps.next.173 = add i32 %steps.current.172, 1
  store i32 %steps.next.173, ptr %ctx.field.171, align 4
  %steps.over.174 = icmp ugt i32 %steps.next.173, 10000
  br i1 %steps.over.174, label %failure.175, label %continue.176
failure.175:
  %ctx.field.177 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 22, ptr %ctx.field.177, align 4
  %status.diagnostic.178 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.178, align 4
  ret void
continue.176:
  %depth.exceeded.179 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.179, label %failure.180, label %continue.181
failure.180:
  %ctx.field.182 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 23, ptr %ctx.field.182, align 4
  %status.diagnostic.183 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.183, align 4
  ret void
continue.181:
  %int.compare.184 = icmp sle i64 2, 1
  %bool.slot.185 = zext i1 %int.compare.184 to i64
  %ctx.field.186 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.187 = load i32, ptr %ctx.field.186, align 4
  %steps.next.188 = add i32 %steps.current.187, 1
  store i32 %steps.next.188, ptr %ctx.field.186, align 4
  %steps.over.189 = icmp ugt i32 %steps.next.188, 10000
  br i1 %steps.over.189, label %failure.190, label %continue.191
failure.190:
  %ctx.field.192 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 24, ptr %ctx.field.192, align 4
  %status.diagnostic.193 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.193, align 4
  ret void
continue.191:
  %ctx.field.194 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.195 = load i32, ptr %ctx.field.194, align 4
  %steps.next.196 = add i32 %steps.current.195, 1
  store i32 %steps.next.196, ptr %ctx.field.194, align 4
  %steps.over.197 = icmp ugt i32 %steps.next.196, 10000
  br i1 %steps.over.197, label %failure.198, label %continue.199
failure.198:
  %ctx.field.200 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 25, ptr %ctx.field.200, align 4
  %status.diagnostic.201 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.201, align 4
  ret void
continue.199:
  %ctx.field.202 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.203 = load i32, ptr %ctx.field.202, align 4
  %steps.next.204 = add i32 %steps.current.203, 1
  store i32 %steps.next.204, ptr %ctx.field.202, align 4
  %steps.over.205 = icmp ugt i32 %steps.next.204, 10000
  br i1 %steps.over.205, label %failure.206, label %continue.207
failure.206:
  %ctx.field.208 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 26, ptr %ctx.field.208, align 4
  %status.diagnostic.209 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.209, align 4
  ret void
continue.207:
  %depth.exceeded.210 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.210, label %failure.211, label %continue.212
failure.211:
  %ctx.field.213 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 27, ptr %ctx.field.213, align 4
  %status.diagnostic.214 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.214, align 4
  ret void
continue.212:
  %int.compare.215 = icmp sge i64 2, 2
  %bool.slot.216 = zext i1 %int.compare.215 to i64
  %ctx.field.217 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.218 = load i32, ptr %ctx.field.217, align 4
  %steps.next.219 = add i32 %steps.current.218, 1
  store i32 %steps.next.219, ptr %ctx.field.217, align 4
  %steps.over.220 = icmp ugt i32 %steps.next.219, 10000
  br i1 %steps.over.220, label %failure.221, label %continue.222
failure.221:
  %ctx.field.223 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 28, ptr %ctx.field.223, align 4
  %status.diagnostic.224 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.224, align 4
  ret void
continue.222:
  %ctx.field.225 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.226 = load i32, ptr %ctx.field.225, align 4
  %steps.next.227 = add i32 %steps.current.226, 1
  store i32 %steps.next.227, ptr %ctx.field.225, align 4
  %steps.over.228 = icmp ugt i32 %steps.next.227, 10000
  br i1 %steps.over.228, label %failure.229, label %continue.230
failure.229:
  %ctx.field.231 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 29, ptr %ctx.field.231, align 4
  %status.diagnostic.232 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.232, align 4
  ret void
continue.230:
  %ctx.field.233 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.234 = load i32, ptr %ctx.field.233, align 4
  %steps.next.235 = add i32 %steps.current.234, 1
  store i32 %steps.next.235, ptr %ctx.field.233, align 4
  %steps.over.236 = icmp ugt i32 %steps.next.235, 10000
  br i1 %steps.over.236, label %failure.237, label %continue.238
failure.237:
  %ctx.field.239 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 30, ptr %ctx.field.239, align 4
  %status.diagnostic.240 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.240, align 4
  ret void
continue.238:
  %depth.exceeded.241 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.241, label %failure.242, label %continue.243
failure.242:
  %ctx.field.244 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 31, ptr %ctx.field.244, align 4
  %status.diagnostic.245 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.245, align 4
  ret void
continue.243:
  %int.compare.246 = icmp sge i64 1, 2
  %bool.slot.247 = zext i1 %int.compare.246 to i64
  %output.ptr.248 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %bool.slot.30, ptr %output.ptr.248, align 8
  %output.ptr.249 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 %bool.slot.61, ptr %output.ptr.249, align 8
  %output.ptr.250 = getelementptr inbounds i64, ptr %outputs, i64 2
  store i64 %bool.slot.92, ptr %output.ptr.250, align 8
  %output.ptr.251 = getelementptr inbounds i64, ptr %outputs, i64 3
  store i64 %bool.slot.123, ptr %output.ptr.251, align 8
  %output.ptr.252 = getelementptr inbounds i64, ptr %outputs, i64 4
  store i64 %bool.slot.154, ptr %output.ptr.252, align 8
  %output.ptr.253 = getelementptr inbounds i64, ptr %outputs, i64 5
  store i64 %bool.slot.185, ptr %output.ptr.253, align 8
  %output.ptr.254 = getelementptr inbounds i64, ptr %outputs, i64 6
  store i64 %bool.slot.216, ptr %output.ptr.254, align 8
  %output.ptr.255 = getelementptr inbounds i64, ptr %outputs, i64 7
  store i64 %bool.slot.247, ptr %output.ptr.255, align 8
  ret void
}

define dllexport i32 @agentlang_output_capacity() { ret i32 8 }

define dllexport void @agentlang_abi_layout(ptr %output) {
entry:
  %size.ptr = getelementptr %NativeExecutionContext, ptr null, i32 1
  %size = ptrtoint ptr %size.ptr to i64
  %align.ptr = getelementptr %NativeExecutionContextAlignmentProbe, ptr null, i32 0, i32 1
  %alignment = ptrtoint ptr %align.ptr to i64
  %field0.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 0
  %field0 = ptrtoint ptr %field0.ptr to i64
  %field1.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 1
  %field1 = ptrtoint ptr %field1.ptr to i64
  %field2.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 2
  %field2 = ptrtoint ptr %field2.ptr to i64
  %field3.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 3
  %field3 = ptrtoint ptr %field3.ptr to i64
  %field4.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 4
  %field4 = ptrtoint ptr %field4.ptr to i64
  %field5.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 5
  %field5 = ptrtoint ptr %field5.ptr to i64
  %field6.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 6
  %field6 = ptrtoint ptr %field6.ptr to i64
  %field7.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 7
  %field7 = ptrtoint ptr %field7.ptr to i64
  %field8.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 8
  %field8 = ptrtoint ptr %field8.ptr to i64
  %field9.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 9
  %field9 = ptrtoint ptr %field9.ptr to i64
  %field10.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 10
  %field10 = ptrtoint ptr %field10.ptr to i64
  %items = alloca [13 x i64], align 8
  %out0 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 0
  store i64 %size, ptr %out0, align 8
  %out1 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 1
  store i64 %alignment, ptr %out1, align 8
  %out2 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 2
  store i64 %field0, ptr %out2, align 8
  %out3 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 3
  store i64 %field1, ptr %out3, align 8
  %out4 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 4
  store i64 %field2, ptr %out4, align 8
  %out5 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 5
  store i64 %field3, ptr %out5, align 8
  %out6 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 6
  store i64 %field4, ptr %out6, align 8
  %out7 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 7
  store i64 %field5, ptr %out7, align 8
  %out8 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 8
  store i64 %field6, ptr %out8, align 8
  %out9 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 9
  store i64 %field7, ptr %out9, align 8
  %out10 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 10
  store i64 %field8, ptr %out10, align 8
  %out11 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 11
  store i64 %field9, ptr %out11, align 8
  %out12 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 12
  store i64 %field10, ptr %out12, align 8
  %item0 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 0
  %value0 = load i64, ptr %item0, align 8
  %dest0 = getelementptr inbounds i64, ptr %output, i64 0
  store i64 %value0, ptr %dest0, align 8
  %item1 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 1
  %value1 = load i64, ptr %item1, align 8
  %dest1 = getelementptr inbounds i64, ptr %output, i64 1
  store i64 %value1, ptr %dest1, align 8
  %item2 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 2
  %value2 = load i64, ptr %item2, align 8
  %dest2 = getelementptr inbounds i64, ptr %output, i64 2
  store i64 %value2, ptr %dest2, align 8
  %item3 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 3
  %value3 = load i64, ptr %item3, align 8
  %dest3 = getelementptr inbounds i64, ptr %output, i64 3
  store i64 %value3, ptr %dest3, align 8
  %item4 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 4
  %value4 = load i64, ptr %item4, align 8
  %dest4 = getelementptr inbounds i64, ptr %output, i64 4
  store i64 %value4, ptr %dest4, align 8
  %item5 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 5
  %value5 = load i64, ptr %item5, align 8
  %dest5 = getelementptr inbounds i64, ptr %output, i64 5
  store i64 %value5, ptr %dest5, align 8
  %item6 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 6
  %value6 = load i64, ptr %item6, align 8
  %dest6 = getelementptr inbounds i64, ptr %output, i64 6
  store i64 %value6, ptr %dest6, align 8
  %item7 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 7
  %value7 = load i64, ptr %item7, align 8
  %dest7 = getelementptr inbounds i64, ptr %output, i64 7
  store i64 %value7, ptr %dest7, align 8
  %item8 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 8
  %value8 = load i64, ptr %item8, align 8
  %dest8 = getelementptr inbounds i64, ptr %output, i64 8
  store i64 %value8, ptr %dest8, align 8
  %item9 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 9
  %value9 = load i64, ptr %item9, align 8
  %dest9 = getelementptr inbounds i64, ptr %output, i64 9
  store i64 %value9, ptr %dest9, align 8
  %item10 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 10
  %value10 = load i64, ptr %item10, align 8
  %dest10 = getelementptr inbounds i64, ptr %output, i64 10
  store i64 %value10, ptr %dest10, align 8
  %item11 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 11
  %value11 = load i64, ptr %item11, align 8
  %dest11 = getelementptr inbounds i64, ptr %output, i64 11
  store i64 %value11, ptr %dest11, align 8
  %item12 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 12
  %value12 = load i64, ptr %item12, align 8
  %dest12 = getelementptr inbounds i64, ptr %output, i64 12
  store i64 %value12, ptr %dest12, align 8
  ret void
}

define dllexport void @agentlang_execute(ptr %ctx, ptr %outputs, i32 %capacity, ptr %status) {
entry:
  %validation.result = call i32 @al_runtime_validate_request(ptr %ctx, ptr %outputs, i32 8, i32 %capacity, ptr %status, i32 8)
  %request.valid = icmp eq i32 %validation.result, 0
  br i1 %request.valid, label %request.accepted, label %request.rejected
request.rejected:
  ret void
request.accepted:
  %steps.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  store i32 0, ptr %steps.ptr, align 4
  %error.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 -1, ptr %error.ptr, align 4
  %reserved.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 3
  store i32 0, ptr %reserved.ptr, align 4
  %arg0.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 4
  store i64 0, ptr %arg0.ptr, align 8
  %arg1.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 5
  store i64 0, ptr %arg1.ptr, align 8
  %workspace.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 8
  %workspace = load ptr, ptr %workspace.ptr, align 8
  call void @agentlang_body(ptr %ctx, ptr %workspace, ptr %status, i32 0)
  %body.status = load i32, ptr %status, align 4
  %body.succeeded = icmp eq i32 %body.status, 0
  br i1 %body.succeeded, label %promote, label %body.failed
body.failed:
  ret void
promote:
  %promote.result = call i32 @al_runtime_promote(ptr %ctx, ptr @agentlang_program, ptr %workspace, ptr @agentlang_root_type_ids, i32 8, ptr %outputs, i32 %capacity)
  switch i32 %promote.result, label %promote.invalid [ i32 0, label %promote.succeeded i32 1, label %promote.invalid.request i32 2, label %promote.invalid.reference i32 3, label %promote.scratch.capacity i32 4, label %promote.retained.capacity ]
promote.invalid:
  store i32 2, ptr %status, align 4
  ret void
promote.invalid.request:
  store i32 2, ptr %status, align 4
  ret void
promote.invalid.reference:
  store i32 5, ptr %status, align 4
  ret void
promote.scratch.capacity:
  store i32 3, ptr %status, align 4
  ret void
promote.retained.capacity:
  store i32 4, ptr %status, align 4
  ret void
promote.succeeded:
  ret void
}

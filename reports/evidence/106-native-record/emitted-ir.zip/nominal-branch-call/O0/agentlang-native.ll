target triple = "x86_64-pc-windows-msvc"
%NativeExecutionContext = type { i32, i32, i32, i32, i64, i64, ptr, ptr, ptr, i32, i32 }
%NativeExecutionContextAlignmentProbe = type { i8, %NativeExecutionContext }
%NativeTypeDescriptor = type { i32, i32, ptr }
%NativeProgramDescriptor = type { ptr, i32, i32 }
declare i32 @al_runtime_validate_request(ptr, ptr, i32, i32, ptr, i32)
declare i32 @al_runtime_make_record(ptr, ptr, i32, ptr, i32, ptr)
declare i32 @al_runtime_get_field(ptr, ptr, i32, i64, i32, ptr)
declare i32 @al_runtime_equal(ptr, ptr, i32, i64, i64, ptr)
declare i32 @al_runtime_promote(ptr, ptr, ptr, ptr, i32, ptr, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

@agentlang_type_descriptors = private constant [4 x %NativeTypeDescriptor] [%NativeTypeDescriptor { i32 1, i32 0, ptr null }, %NativeTypeDescriptor { i32 2, i32 0, ptr null }, %NativeTypeDescriptor { i32 3, i32 0, ptr null }, %NativeTypeDescriptor { i32 1, i32 0, ptr null }]
@agentlang_program = private constant %NativeProgramDescriptor { ptr getelementptr inbounds ([4 x %NativeTypeDescriptor], ptr @agentlang_type_descriptors, i32 0, i32 0), i32 4, i32 0 }
@agentlang_root_type_ids = private constant [5 x i32] [i32 3, i32 1, i32 0, i32 1, i32 1]

define internal void @agentlang_body(ptr %ctx, ptr %outputs, ptr %status, i32 %depth) {
entry:
  %ctx.field.0 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1 = load i32, ptr %ctx.field.0, align 4
  %steps.next.2 = add i32 %steps.current.1, 1
  store i32 %steps.next.2, ptr %ctx.field.0, align 4
  %steps.over.3 = icmp ugt i32 %steps.next.2, 10000
  br i1 %steps.over.3, label %failure.4, label %continue.5
failure.4:
  %ctx.field.6 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 0, ptr %ctx.field.6, align 4
  %status.diagnostic.7 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7, align 4
  ret void
continue.5:
  %ctx.field.8 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.9 = load i32, ptr %ctx.field.8, align 4
  %steps.next.10 = add i32 %steps.current.9, 1
  store i32 %steps.next.10, ptr %ctx.field.8, align 4
  %steps.over.11 = icmp ugt i32 %steps.next.10, 10000
  br i1 %steps.over.11, label %failure.12, label %continue.13
failure.12:
  %ctx.field.14 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 1, ptr %ctx.field.14, align 4
  %status.diagnostic.15 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.15, align 4
  ret void
continue.13:
  %depth.exceeded.16 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.16, label %failure.17, label %continue.18
failure.17:
  %ctx.field.19 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 2, ptr %ctx.field.19, align 4
  %status.diagnostic.20 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.20, align 4
  ret void
continue.18:
  %ctx.field.21 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.22 = load i32, ptr %ctx.field.21, align 4
  %steps.next.23 = add i32 %steps.current.22, 1
  store i32 %steps.next.23, ptr %ctx.field.21, align 4
  %steps.over.24 = icmp ugt i32 %steps.next.23, 10000
  br i1 %steps.over.24, label %failure.25, label %continue.26
failure.25:
  %ctx.field.27 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 3, ptr %ctx.field.27, align 4
  %status.diagnostic.28 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.28, align 4
  ret void
continue.26:
  %ctx.field.29 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.30 = load i32, ptr %ctx.field.29, align 4
  %steps.next.31 = add i32 %steps.current.30, 1
  store i32 %steps.next.31, ptr %ctx.field.29, align 4
  %steps.over.32 = icmp ugt i32 %steps.next.31, 10000
  br i1 %steps.over.32, label %failure.33, label %continue.34
failure.33:
  %ctx.field.35 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 4, ptr %ctx.field.35, align 4
  %status.diagnostic.36 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.36, align 4
  ret void
continue.34:
  %ctx.field.37 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.38 = load i32, ptr %ctx.field.37, align 4
  %steps.next.39 = add i32 %steps.current.38, 1
  store i32 %steps.next.39, ptr %ctx.field.37, align 4
  %steps.over.40 = icmp ugt i32 %steps.next.39, 10000
  br i1 %steps.over.40, label %failure.41, label %continue.42
failure.41:
  %ctx.field.43 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 5, ptr %ctx.field.43, align 4
  %status.diagnostic.44 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.44, align 4
  ret void
continue.42:
  %if.condition.45 = icmp ne i64 0, 0
  br i1 %if.condition.45, label %if.then.46, label %if.else.47
if.then.46:
  %ctx.field.49 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.50 = load i32, ptr %ctx.field.49, align 4
  %steps.next.51 = add i32 %steps.current.50, 1
  store i32 %steps.next.51, ptr %ctx.field.49, align 4
  %steps.over.52 = icmp ugt i32 %steps.next.51, 10000
  br i1 %steps.over.52, label %failure.53, label %continue.54
failure.53:
  %ctx.field.55 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 6, ptr %ctx.field.55, align 4
  %status.diagnostic.56 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.56, align 4
  ret void
continue.54:
  %ctx.field.57 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.58 = load i32, ptr %ctx.field.57, align 4
  %steps.next.59 = add i32 %steps.current.58, 1
  store i32 %steps.next.59, ptr %ctx.field.57, align 4
  %steps.over.60 = icmp ugt i32 %steps.next.59, 10000
  br i1 %steps.over.60, label %failure.61, label %continue.62
failure.61:
  %ctx.field.63 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 7, ptr %ctx.field.63, align 4
  %status.diagnostic.64 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.64, align 4
  ret void
continue.62:
  %depth.exceeded.65 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.65, label %failure.66, label %continue.67
failure.66:
  %ctx.field.68 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 8, ptr %ctx.field.68, align 4
  %status.diagnostic.69 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.69, align 4
  ret void
continue.67:
  br label %if.merge.48
if.else.47:
  %ctx.field.70 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.71 = load i32, ptr %ctx.field.70, align 4
  %steps.next.72 = add i32 %steps.current.71, 1
  store i32 %steps.next.72, ptr %ctx.field.70, align 4
  %steps.over.73 = icmp ugt i32 %steps.next.72, 10000
  br i1 %steps.over.73, label %failure.74, label %continue.75
failure.74:
  %ctx.field.76 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 9, ptr %ctx.field.76, align 4
  %status.diagnostic.77 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.77, align 4
  ret void
continue.75:
  br label %if.merge.48
if.merge.48:
  %stack.phi.78 = phi i64 [ 20, %continue.67 ], [ 10, %continue.75 ]
  %local.phi.79 = phi i64 [ 10, %continue.67 ], [ 10, %continue.75 ]
  %ctx.field.80 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.81 = load i32, ptr %ctx.field.80, align 4
  %steps.next.82 = add i32 %steps.current.81, 1
  store i32 %steps.next.82, ptr %ctx.field.80, align 4
  %steps.over.83 = icmp ugt i32 %steps.next.82, 10000
  br i1 %steps.over.83, label %failure.84, label %continue.85
failure.84:
  %ctx.field.86 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 10, ptr %ctx.field.86, align 4
  %status.diagnostic.87 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.87, align 4
  ret void
continue.85:
  %depth.exceeded.88 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.88, label %failure.89, label %continue.90
failure.89:
  %ctx.field.91 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 11, ptr %ctx.field.91, align 4
  %status.diagnostic.92 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.92, align 4
  ret void
continue.90:
  %call.depth.93 = add i32 %depth, 1
  call void @agentlang_fn_91ab365923187a0c81826fb6a707ae269d2ba6c99e0bcc784476644e64fa33df_r1(ptr %ctx, ptr %outputs, ptr %status, i32 %call.depth.93, i64 %stack.phi.78)
  %callee.status.94 = load i32, ptr %status, align 4
  %callee.succeeded.95 = icmp eq i32 %callee.status.94, 0
  br i1 %callee.succeeded.95, label %callee.continue.97, label %callee.failure.96
callee.failure.96:
  ret void
callee.continue.97:
  %call.output.ptr.98 = getelementptr inbounds i64, ptr %outputs, i64 0
  %call.output.99 = load i64, ptr %call.output.ptr.98, align 8
  %ctx.field.100 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.101 = load i32, ptr %ctx.field.100, align 4
  %steps.next.102 = add i32 %steps.current.101, 1
  store i32 %steps.next.102, ptr %ctx.field.100, align 4
  %steps.over.103 = icmp ugt i32 %steps.next.102, 10000
  br i1 %steps.over.103, label %failure.104, label %continue.105
failure.104:
  %ctx.field.106 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 12, ptr %ctx.field.106, align 4
  %status.diagnostic.107 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.107, align 4
  ret void
continue.105:
  %depth.exceeded.108 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.108, label %failure.109, label %continue.110
failure.109:
  %ctx.field.111 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 13, ptr %ctx.field.111, align 4
  %status.diagnostic.112 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.112, align 4
  ret void
continue.110:
  %ctx.field.113 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.114 = load i32, ptr %ctx.field.113, align 4
  %steps.next.115 = add i32 %steps.current.114, 1
  store i32 %steps.next.115, ptr %ctx.field.113, align 4
  %steps.over.116 = icmp ugt i32 %steps.next.115, 10000
  br i1 %steps.over.116, label %failure.117, label %continue.118
failure.117:
  %ctx.field.119 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 14, ptr %ctx.field.119, align 4
  %status.diagnostic.120 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.120, align 4
  ret void
continue.118:
  %ctx.field.121 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.122 = load i32, ptr %ctx.field.121, align 4
  %steps.next.123 = add i32 %steps.current.122, 1
  store i32 %steps.next.123, ptr %ctx.field.121, align 4
  %steps.over.124 = icmp ugt i32 %steps.next.123, 10000
  br i1 %steps.over.124, label %failure.125, label %continue.126
failure.125:
  %ctx.field.127 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 15, ptr %ctx.field.127, align 4
  %status.diagnostic.128 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.128, align 4
  ret void
continue.126:
  %depth.exceeded.129 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.129, label %failure.130, label %continue.131
failure.130:
  %ctx.field.132 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 16, ptr %ctx.field.132, align 4
  %status.diagnostic.133 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.133, align 4
  ret void
continue.131:
  %ctx.field.134 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.135 = load i32, ptr %ctx.field.134, align 4
  %steps.next.136 = add i32 %steps.current.135, 1
  store i32 %steps.next.136, ptr %ctx.field.134, align 4
  %steps.over.137 = icmp ugt i32 %steps.next.136, 10000
  br i1 %steps.over.137, label %failure.138, label %continue.139
failure.138:
  %ctx.field.140 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 17, ptr %ctx.field.140, align 4
  %status.diagnostic.141 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.141, align 4
  ret void
continue.139:
  %depth.exceeded.142 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.142, label %failure.143, label %continue.144
failure.143:
  %ctx.field.145 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 18, ptr %ctx.field.145, align 4
  %status.diagnostic.146 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.146, align 4
  ret void
continue.144:
  %ctx.field.147 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.148 = load i32, ptr %ctx.field.147, align 4
  %steps.next.149 = add i32 %steps.current.148, 1
  store i32 %steps.next.149, ptr %ctx.field.147, align 4
  %steps.over.150 = icmp ugt i32 %steps.next.149, 10000
  br i1 %steps.over.150, label %failure.151, label %continue.152
failure.151:
  %ctx.field.153 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 19, ptr %ctx.field.153, align 4
  %status.diagnostic.154 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.154, align 4
  ret void
continue.152:
  %ctx.field.155 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.156 = load i32, ptr %ctx.field.155, align 4
  %steps.next.157 = add i32 %steps.current.156, 1
  store i32 %steps.next.157, ptr %ctx.field.155, align 4
  %steps.over.158 = icmp ugt i32 %steps.next.157, 10000
  br i1 %steps.over.158, label %failure.159, label %continue.160
failure.159:
  %ctx.field.161 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 20, ptr %ctx.field.161, align 4
  %status.diagnostic.162 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.162, align 4
  ret void
continue.160:
  %depth.exceeded.163 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.163, label %failure.164, label %continue.165
failure.164:
  %ctx.field.166 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 21, ptr %ctx.field.166, align 4
  %status.diagnostic.167 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.167, align 4
  ret void
continue.165:
  %ctx.field.168 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.169 = load i32, ptr %ctx.field.168, align 4
  %steps.next.170 = add i32 %steps.current.169, 1
  store i32 %steps.next.170, ptr %ctx.field.168, align 4
  %steps.over.171 = icmp ugt i32 %steps.next.170, 10000
  br i1 %steps.over.171, label %failure.172, label %continue.173
failure.172:
  %ctx.field.174 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 22, ptr %ctx.field.174, align 4
  %status.diagnostic.175 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.175, align 4
  ret void
continue.173:
  %depth.exceeded.176 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.176, label %failure.177, label %continue.178
failure.177:
  %ctx.field.179 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 23, ptr %ctx.field.179, align 4
  %status.diagnostic.180 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.180, align 4
  ret void
continue.178:
  %ctx.field.181 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.182 = load i32, ptr %ctx.field.181, align 4
  %steps.next.183 = add i32 %steps.current.182, 1
  store i32 %steps.next.183, ptr %ctx.field.181, align 4
  %steps.over.184 = icmp ugt i32 %steps.next.183, 10000
  br i1 %steps.over.184, label %failure.185, label %continue.186
failure.185:
  %ctx.field.187 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 24, ptr %ctx.field.187, align 4
  %status.diagnostic.188 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.188, align 4
  ret void
continue.186:
  %depth.exceeded.189 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.189, label %failure.190, label %continue.191
failure.190:
  %ctx.field.192 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 25, ptr %ctx.field.192, align 4
  %status.diagnostic.193 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.193, align 4
  ret void
continue.191:
  %ctx.field.194 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.195 = load i32, ptr %ctx.field.194, align 4
  %steps.next.196 = add i32 %steps.current.195, 1
  store i32 %steps.next.196, ptr %ctx.field.194, align 4
  %steps.over.197 = icmp ugt i32 %steps.next.196, 10000
  br i1 %steps.over.197, label %failure.198, label %continue.199
failure.198:
  %ctx.field.200 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 26, ptr %ctx.field.200, align 4
  %status.diagnostic.201 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.201, align 4
  ret void
continue.199:
  %depth.exceeded.202 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.202, label %failure.203, label %continue.204
failure.203:
  %ctx.field.205 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 27, ptr %ctx.field.205, align 4
  %status.diagnostic.206 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.206, align 4
  ret void
continue.204:
  %ctx.field.207 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.208 = load i32, ptr %ctx.field.207, align 4
  %steps.next.209 = add i32 %steps.current.208, 1
  store i32 %steps.next.209, ptr %ctx.field.207, align 4
  %steps.over.210 = icmp ugt i32 %steps.next.209, 10000
  br i1 %steps.over.210, label %failure.211, label %continue.212
failure.211:
  %ctx.field.213 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 28, ptr %ctx.field.213, align 4
  %status.diagnostic.214 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.214, align 4
  ret void
continue.212:
  %ctx.field.215 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.216 = load i32, ptr %ctx.field.215, align 4
  %steps.next.217 = add i32 %steps.current.216, 1
  store i32 %steps.next.217, ptr %ctx.field.215, align 4
  %steps.over.218 = icmp ugt i32 %steps.next.217, 10000
  br i1 %steps.over.218, label %failure.219, label %continue.220
failure.219:
  %ctx.field.221 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 29, ptr %ctx.field.221, align 4
  %status.diagnostic.222 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.222, align 4
  ret void
continue.220:
  %depth.exceeded.223 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.223, label %failure.224, label %continue.225
failure.224:
  %ctx.field.226 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 30, ptr %ctx.field.226, align 4
  %status.diagnostic.227 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.227, align 4
  ret void
continue.225:
  %ctx.field.228 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.229 = load i32, ptr %ctx.field.228, align 4
  %steps.next.230 = add i32 %steps.current.229, 1
  store i32 %steps.next.230, ptr %ctx.field.228, align 4
  %steps.over.231 = icmp ugt i32 %steps.next.230, 10000
  br i1 %steps.over.231, label %failure.232, label %continue.233
failure.232:
  %ctx.field.234 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 31, ptr %ctx.field.234, align 4
  %status.diagnostic.235 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.235, align 4
  ret void
continue.233:
  %ctx.field.236 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.237 = load i32, ptr %ctx.field.236, align 4
  %steps.next.238 = add i32 %steps.current.237, 1
  store i32 %steps.next.238, ptr %ctx.field.236, align 4
  %steps.over.239 = icmp ugt i32 %steps.next.238, 10000
  br i1 %steps.over.239, label %failure.240, label %continue.241
failure.240:
  %ctx.field.242 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 32, ptr %ctx.field.242, align 4
  %status.diagnostic.243 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.243, align 4
  ret void
continue.241:
  %depth.exceeded.244 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.244, label %failure.245, label %continue.246
failure.245:
  %ctx.field.247 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 33, ptr %ctx.field.247, align 4
  %status.diagnostic.248 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.248, align 4
  ret void
continue.246:
  %ctx.field.249 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.250 = load i32, ptr %ctx.field.249, align 4
  %steps.next.251 = add i32 %steps.current.250, 1
  store i32 %steps.next.251, ptr %ctx.field.249, align 4
  %steps.over.252 = icmp ugt i32 %steps.next.251, 10000
  br i1 %steps.over.252, label %failure.253, label %continue.254
failure.253:
  %ctx.field.255 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 34, ptr %ctx.field.255, align 4
  %status.diagnostic.256 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.256, align 4
  ret void
continue.254:
  %depth.exceeded.257 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.257, label %failure.258, label %continue.259
failure.258:
  %ctx.field.260 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 35, ptr %ctx.field.260, align 4
  %status.diagnostic.261 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.261, align 4
  ret void
continue.259:
  %scalar.equals.262 = icmp eq i64 1, 1
  %bool.slot.263 = zext i1 %scalar.equals.262 to i64
  %ctx.field.264 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.265 = load i32, ptr %ctx.field.264, align 4
  %steps.next.266 = add i32 %steps.current.265, 1
  store i32 %steps.next.266, ptr %ctx.field.264, align 4
  %steps.over.267 = icmp ugt i32 %steps.next.266, 10000
  br i1 %steps.over.267, label %failure.268, label %continue.269
failure.268:
  %ctx.field.270 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 36, ptr %ctx.field.270, align 4
  %status.diagnostic.271 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.271, align 4
  ret void
continue.269:
  %ctx.field.272 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.273 = load i32, ptr %ctx.field.272, align 4
  %steps.next.274 = add i32 %steps.current.273, 1
  store i32 %steps.next.274, ptr %ctx.field.272, align 4
  %steps.over.275 = icmp ugt i32 %steps.next.274, 10000
  br i1 %steps.over.275, label %failure.276, label %continue.277
failure.276:
  %ctx.field.278 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 37, ptr %ctx.field.278, align 4
  %status.diagnostic.279 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.279, align 4
  ret void
continue.277:
  %depth.exceeded.280 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.280, label %failure.281, label %continue.282
failure.281:
  %ctx.field.283 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 38, ptr %ctx.field.283, align 4
  %status.diagnostic.284 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.284, align 4
  ret void
continue.282:
  %ctx.field.285 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.286 = load i32, ptr %ctx.field.285, align 4
  %steps.next.287 = add i32 %steps.current.286, 1
  store i32 %steps.next.287, ptr %ctx.field.285, align 4
  %steps.over.288 = icmp ugt i32 %steps.next.287, 10000
  br i1 %steps.over.288, label %failure.289, label %continue.290
failure.289:
  %ctx.field.291 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 39, ptr %ctx.field.291, align 4
  %status.diagnostic.292 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.292, align 4
  ret void
continue.290:
  %ctx.field.293 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.294 = load i32, ptr %ctx.field.293, align 4
  %steps.next.295 = add i32 %steps.current.294, 1
  store i32 %steps.next.295, ptr %ctx.field.293, align 4
  %steps.over.296 = icmp ugt i32 %steps.next.295, 10000
  br i1 %steps.over.296, label %failure.297, label %continue.298
failure.297:
  %ctx.field.299 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 40, ptr %ctx.field.299, align 4
  %status.diagnostic.300 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.300, align 4
  ret void
continue.298:
  %depth.exceeded.301 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.301, label %failure.302, label %continue.303
failure.302:
  %ctx.field.304 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 41, ptr %ctx.field.304, align 4
  %status.diagnostic.305 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.305, align 4
  ret void
continue.303:
  %ctx.field.306 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.307 = load i32, ptr %ctx.field.306, align 4
  %steps.next.308 = add i32 %steps.current.307, 1
  store i32 %steps.next.308, ptr %ctx.field.306, align 4
  %steps.over.309 = icmp ugt i32 %steps.next.308, 10000
  br i1 %steps.over.309, label %failure.310, label %continue.311
failure.310:
  %ctx.field.312 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 42, ptr %ctx.field.312, align 4
  %status.diagnostic.313 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.313, align 4
  ret void
continue.311:
  %depth.exceeded.314 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.314, label %failure.315, label %continue.316
failure.315:
  %ctx.field.317 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 43, ptr %ctx.field.317, align 4
  %status.diagnostic.318 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.318, align 4
  ret void
continue.316:
  %scalar.equals.319 = icmp eq i64 1, 2
  %bool.slot.320 = zext i1 %scalar.equals.319 to i64
  %output.ptr.321 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %call.output.99, ptr %output.ptr.321, align 8
  %output.ptr.322 = getelementptr inbounds i64, ptr %outputs, i64 1
  store i64 1, ptr %output.ptr.322, align 8
  %output.ptr.323 = getelementptr inbounds i64, ptr %outputs, i64 2
  store i64 %call.output.99, ptr %output.ptr.323, align 8
  %output.ptr.324 = getelementptr inbounds i64, ptr %outputs, i64 3
  store i64 %bool.slot.263, ptr %output.ptr.324, align 8
  %output.ptr.325 = getelementptr inbounds i64, ptr %outputs, i64 4
  store i64 %bool.slot.320, ptr %output.ptr.325, align 8
  ret void
}

define internal void @agentlang_fn_91ab365923187a0c81826fb6a707ae269d2ba6c99e0bcc784476644e64fa33df_r1(ptr %ctx, ptr %outputs, ptr %status, i32 %depth, i64 %arg0) {
entry:
  %ctx.field.0 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.1 = load i32, ptr %ctx.field.0, align 4
  %steps.next.2 = add i32 %steps.current.1, 1
  store i32 %steps.next.2, ptr %ctx.field.0, align 4
  %steps.over.3 = icmp ugt i32 %steps.next.2, 10000
  br i1 %steps.over.3, label %failure.4, label %continue.5
failure.4:
  %ctx.field.6 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 44, ptr %ctx.field.6, align 4
  %status.diagnostic.7 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.7, align 4
  ret void
continue.5:
  %depth.exceeded.8 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.8, label %failure.9, label %continue.10
failure.9:
  %ctx.field.11 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 45, ptr %ctx.field.11, align 4
  %status.diagnostic.12 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.12, align 4
  ret void
continue.10:
  %ctx.field.13 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  %steps.current.14 = load i32, ptr %ctx.field.13, align 4
  %steps.next.15 = add i32 %steps.current.14, 1
  store i32 %steps.next.15, ptr %ctx.field.13, align 4
  %steps.over.16 = icmp ugt i32 %steps.next.15, 10000
  br i1 %steps.over.16, label %failure.17, label %continue.18
failure.17:
  %ctx.field.19 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 46, ptr %ctx.field.19, align 4
  %status.diagnostic.20 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.20, align 4
  ret void
continue.18:
  %depth.exceeded.21 = icmp ugt i32 %depth, 64
  br i1 %depth.exceeded.21, label %failure.22, label %continue.23
failure.22:
  %ctx.field.24 = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 47, ptr %ctx.field.24, align 4
  %status.diagnostic.25 = getelementptr inbounds i32, ptr %status, i64 0
  store i32 1, ptr %status.diagnostic.25, align 4
  ret void
continue.23:
  %output.ptr.26 = getelementptr inbounds i64, ptr %outputs, i64 0
  store i64 %arg0, ptr %output.ptr.26, align 8
  ret void
}

define dllexport i32 @agentlang_output_capacity() { ret i32 5 }

define dllexport void @agentlang_abi_layout(ptr %output) {
entry:
  %size.ptr = getelementptr %NativeExecutionContext, ptr null, i32 1
  %size = ptrtoint ptr %size.ptr to i64
  %align.ptr = getelementptr %NativeExecutionContextAlignmentProbe, ptr null, i32 0, i32 1
  %alignment = ptrtoint ptr %align.ptr to i64
  %field0.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 0
  %field0 = ptrtoint ptr %field0.ptr to i64
  %field1.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 1
  %field1 = ptrtoint ptr %field1.ptr to i64
  %field2.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 2
  %field2 = ptrtoint ptr %field2.ptr to i64
  %field3.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 3
  %field3 = ptrtoint ptr %field3.ptr to i64
  %field4.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 4
  %field4 = ptrtoint ptr %field4.ptr to i64
  %field5.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 5
  %field5 = ptrtoint ptr %field5.ptr to i64
  %field6.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 6
  %field6 = ptrtoint ptr %field6.ptr to i64
  %field7.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 7
  %field7 = ptrtoint ptr %field7.ptr to i64
  %field8.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 8
  %field8 = ptrtoint ptr %field8.ptr to i64
  %field9.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 9
  %field9 = ptrtoint ptr %field9.ptr to i64
  %field10.ptr = getelementptr %NativeExecutionContext, ptr null, i32 0, i32 10
  %field10 = ptrtoint ptr %field10.ptr to i64
  %items = alloca [13 x i64], align 8
  %out0 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 0
  store i64 %size, ptr %out0, align 8
  %out1 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 1
  store i64 %alignment, ptr %out1, align 8
  %out2 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 2
  store i64 %field0, ptr %out2, align 8
  %out3 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 3
  store i64 %field1, ptr %out3, align 8
  %out4 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 4
  store i64 %field2, ptr %out4, align 8
  %out5 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 5
  store i64 %field3, ptr %out5, align 8
  %out6 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 6
  store i64 %field4, ptr %out6, align 8
  %out7 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 7
  store i64 %field5, ptr %out7, align 8
  %out8 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 8
  store i64 %field6, ptr %out8, align 8
  %out9 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 9
  store i64 %field7, ptr %out9, align 8
  %out10 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 10
  store i64 %field8, ptr %out10, align 8
  %out11 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 11
  store i64 %field9, ptr %out11, align 8
  %out12 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 12
  store i64 %field10, ptr %out12, align 8
  %item0 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 0
  %value0 = load i64, ptr %item0, align 8
  %dest0 = getelementptr inbounds i64, ptr %output, i64 0
  store i64 %value0, ptr %dest0, align 8
  %item1 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 1
  %value1 = load i64, ptr %item1, align 8
  %dest1 = getelementptr inbounds i64, ptr %output, i64 1
  store i64 %value1, ptr %dest1, align 8
  %item2 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 2
  %value2 = load i64, ptr %item2, align 8
  %dest2 = getelementptr inbounds i64, ptr %output, i64 2
  store i64 %value2, ptr %dest2, align 8
  %item3 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 3
  %value3 = load i64, ptr %item3, align 8
  %dest3 = getelementptr inbounds i64, ptr %output, i64 3
  store i64 %value3, ptr %dest3, align 8
  %item4 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 4
  %value4 = load i64, ptr %item4, align 8
  %dest4 = getelementptr inbounds i64, ptr %output, i64 4
  store i64 %value4, ptr %dest4, align 8
  %item5 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 5
  %value5 = load i64, ptr %item5, align 8
  %dest5 = getelementptr inbounds i64, ptr %output, i64 5
  store i64 %value5, ptr %dest5, align 8
  %item6 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 6
  %value6 = load i64, ptr %item6, align 8
  %dest6 = getelementptr inbounds i64, ptr %output, i64 6
  store i64 %value6, ptr %dest6, align 8
  %item7 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 7
  %value7 = load i64, ptr %item7, align 8
  %dest7 = getelementptr inbounds i64, ptr %output, i64 7
  store i64 %value7, ptr %dest7, align 8
  %item8 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 8
  %value8 = load i64, ptr %item8, align 8
  %dest8 = getelementptr inbounds i64, ptr %output, i64 8
  store i64 %value8, ptr %dest8, align 8
  %item9 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 9
  %value9 = load i64, ptr %item9, align 8
  %dest9 = getelementptr inbounds i64, ptr %output, i64 9
  store i64 %value9, ptr %dest9, align 8
  %item10 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 10
  %value10 = load i64, ptr %item10, align 8
  %dest10 = getelementptr inbounds i64, ptr %output, i64 10
  store i64 %value10, ptr %dest10, align 8
  %item11 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 11
  %value11 = load i64, ptr %item11, align 8
  %dest11 = getelementptr inbounds i64, ptr %output, i64 11
  store i64 %value11, ptr %dest11, align 8
  %item12 = getelementptr inbounds [13 x i64], ptr %items, i64 0, i64 12
  %value12 = load i64, ptr %item12, align 8
  %dest12 = getelementptr inbounds i64, ptr %output, i64 12
  store i64 %value12, ptr %dest12, align 8
  ret void
}

define dllexport void @agentlang_execute(ptr %ctx, ptr %outputs, i32 %capacity, ptr %status) {
entry:
  %validation.result = call i32 @al_runtime_validate_request(ptr %ctx, ptr %outputs, i32 5, i32 %capacity, ptr %status, i32 5)
  %request.valid = icmp eq i32 %validation.result, 0
  br i1 %request.valid, label %request.accepted, label %request.rejected
request.rejected:
  ret void
request.accepted:
  %steps.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 1
  store i32 0, ptr %steps.ptr, align 4
  %error.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 2
  store i32 -1, ptr %error.ptr, align 4
  %reserved.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 3
  store i32 0, ptr %reserved.ptr, align 4
  %arg0.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 4
  store i64 0, ptr %arg0.ptr, align 8
  %arg1.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 5
  store i64 0, ptr %arg1.ptr, align 8
  %workspace.ptr = getelementptr %NativeExecutionContext, ptr %ctx, i32 0, i32 8
  %workspace = load ptr, ptr %workspace.ptr, align 8
  call void @agentlang_body(ptr %ctx, ptr %workspace, ptr %status, i32 0)
  %body.status = load i32, ptr %status, align 4
  %body.succeeded = icmp eq i32 %body.status, 0
  br i1 %body.succeeded, label %promote, label %body.failed
body.failed:
  ret void
promote:
  %promote.result = call i32 @al_runtime_promote(ptr %ctx, ptr @agentlang_program, ptr %workspace, ptr @agentlang_root_type_ids, i32 5, ptr %outputs, i32 %capacity)
  switch i32 %promote.result, label %promote.invalid [ i32 0, label %promote.succeeded i32 1, label %promote.invalid.request i32 2, label %promote.invalid.reference i32 3, label %promote.scratch.capacity i32 4, label %promote.retained.capacity ]
promote.invalid:
  store i32 2, ptr %status, align 4
  ret void
promote.invalid.request:
  store i32 2, ptr %status, align 4
  ret void
promote.invalid.reference:
  store i32 5, ptr %status, align 4
  ret void
promote.scratch.capacity:
  store i32 3, ptr %status, align 4
  ret void
promote.retained.capacity:
  store i32 4, ptr %status, align 4
  ret void
promote.succeeded:
  ret void
}

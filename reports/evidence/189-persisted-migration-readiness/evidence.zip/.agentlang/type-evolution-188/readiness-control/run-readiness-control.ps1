#requires -Version 7.5
[CmdletBinding()]
param(
    [ValidatePattern('^[a-z0-9][a-z0-9-]{2,47}$')]
    [string]$RunId = ('readiness-' + [DateTime]::UtcNow.ToString('yyyyMMddTHHmmssZ').ToLowerInvariant() + '-' + [Guid]::NewGuid().ToString('N').Substring(0, 8))
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$script:Repo = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..\..'))
$script:Control = [IO.Path]::GetFullPath($PSScriptRoot)
$script:GateRoot = Join-Path $script:Repo '.agentlang/type-evolution-188'
$script:Seed = Join-Path $script:Repo '.agentlang/efficacy-maintenance-184/seed-draft/projects/draft-009/flow-retained/project'
$script:Patch = Join-Path $script:GateRoot 'readiness-source/atomic-migration.patch.flow'
$script:PreparationPinsPath = Join-Path $script:Control 'preparation-pins.json'
$script:RunRoot = Join-Path (Join-Path $script:Control 'runs') $RunId
$script:Utf8 = [Text.UTF8Encoding]::new($false, $true)
$script:AllowedOperations = @(
    'callers', 'commit', 'context', 'define', 'dependencies', 'describe', 'diff', 'effects', 'eval', 'example', 'examples',
    'failed-tests', 'graph', 'help', 'history', 'ir', 'replace-word', 'search', 'search-dependency', 'search-output',
    'search-type', 'source', 'task.begin', 'task.commit', 'task.log', 'task.status', 'test', 'test-all', 'tests',
    'transitive-callers', 'transitive-dependencies', 'type-of', 'words'
)
$script:TypeNames = @('Scan', 'ScanInput', 'ShipmentScanLookup')
$script:OwnerNames = @(
    'shipment.batch-step', 'shipment.find-scan', 'shipment.ingest', 'shipment.ingest-batch',
    'shipment.ingest-rule', 'shipment.scan-lookup-step', 'store.shipment', 'store.shipment-lookup-step',
    'store.shipment-replacement-step', 'store.with-shipment'
)
$script:CasOwnerNames = @(
    'shipment.batch-step', 'shipment.find-scan', 'shipment.ingest', 'shipment.ingest-batch',
    'shipment.ingest-rule', 'shipment.scan-lookup-step'
)
$script:AllTypes = @('BatchState', 'Scan', 'ScanError', 'ScanInput', 'Shipment', 'ShipmentId', 'ShipmentReplacement', 'ShipmentScanLookup', 'Store', 'StoreShipmentLookup')
$script:MigrationSession = $null
$script:ReloadSession = $null
$script:RunEvidence = $null

function Get-Property([object]$Value, [string]$Name) {
    if ($null -eq $Value) { return $null }
    if ($Value -is [Collections.IDictionary]) {
        if ($Value.Contains($Name)) { return $Value[$Name] }
        return $null
    }
    $property = $Value.PSObject.Properties[$Name]
    if ($null -eq $property) { return $null }
    return $property.Value
}

function Require([bool]$Condition, [string]$Message) {
    if (-not $Condition) { throw $Message }
}

function Get-Sha256([string]$Path) {
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Read-Json([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw "Required JSON file is missing: $Path" }
    return Get-Content -LiteralPath $Path -Raw | ConvertFrom-Json -AsHashtable -DateKind String -Depth 100
}

function Write-Json([string]$Path, [object]$Value) {
    $parent = Split-Path -Parent $Path
    [void][IO.Directory]::CreateDirectory($parent)
    [IO.File]::WriteAllText($Path, (ConvertTo-Json -InputObject $Value -Depth 100) + [Environment]::NewLine, [Text.UTF8Encoding]::new($false))
}

function Assert-InRepo([string]$Path, [string]$Label) {
    $full = [IO.Path]::GetFullPath($Path)
    $relative = [IO.Path]::GetRelativePath($script:Repo, $full)
    Require (-not [IO.Path]::IsPathRooted($relative) -and $relative -ne '..' -and -not $relative.StartsWith('..' + [IO.Path]::DirectorySeparatorChar, [StringComparison]::Ordinal)) "$Label escapes the repository: $full"
    return $full
}

function Assert-TextEqual([string]$Actual, [string]$Expected, [string]$Label) {
    Require ([StringComparer]::Ordinal.Equals($Actual, $Expected)) "$Label differs."
}

function Assert-StringSet([object[]]$Actual, [object[]]$Expected, [string]$Label) {
    $a = @($Actual | ForEach-Object { [string]$_ } | Sort-Object -CaseSensitive)
    $e = @($Expected | ForEach-Object { [string]$_ } | Sort-Object -CaseSensitive)
    Require ($a.Count -eq $e.Count) "$Label count differs: actual=$($a.Count), expected=$($e.Count)."
    for ($i = 0; $i -lt $a.Count; $i++) { Assert-TextEqual $a[$i] $e[$i] "$Label[$i]" }
}

function Get-TreeInventory([string]$Root) {
    $rootFull = [IO.Path]::GetFullPath($Root)
    $items = @(Get-ChildItem -LiteralPath $rootFull -Force -Recurse)
    foreach ($item in $items) {
        Require (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -eq 0) "Refusing a reparse point in evidence tree: $($item.FullName)"
    }
    $files = [Collections.Generic.List[object]]::new()
    foreach ($item in $items | Where-Object { -not $_.PSIsContainer }) {
        $files.Add([ordered]@{
            path = [IO.Path]::GetRelativePath($rootFull, $item.FullName).Replace('\', '/')
            bytes = [long]$item.Length
            sha256 = Get-Sha256 $item.FullName
        })
    }
    return @($files | Sort-Object -Property path -CaseSensitive)
}

function Assert-TreeEqual([object[]]$Actual, [object[]]$Expected, [string]$Label) {
    Require ($Actual.Count -eq $Expected.Count) "$Label file count differs: actual=$($Actual.Count), expected=$($Expected.Count)."
    $expectedByPath = [Collections.Generic.Dictionary[string, object]]::new([StringComparer]::Ordinal)
    foreach ($file in $Expected) { $expectedByPath.Add([string]$file.path, $file) }
    foreach ($file in $Actual) {
        $path = [string]$file.path
        Require ($expectedByPath.ContainsKey($path)) "$Label contains an unexpected path: $path"
        $other = $expectedByPath[$path]
        Require ([long]$file.bytes -eq [long]$other.bytes -and [string]$file.sha256 -ceq [string]$other.sha256) "$Label differs at $path"
    }
}

function Copy-TreeContents([string]$Source, [string]$Destination) {
    Require (-not (Test-Path -LiteralPath $Destination)) "Refusing to overwrite an existing copy target: $Destination"
    [void][IO.Directory]::CreateDirectory($Destination)
    foreach ($item in Get-ChildItem -LiteralPath $Source -Force) {
        Copy-Item -LiteralPath $item.FullName -Destination $Destination -Recurse -Force
    }
}

function Get-ManifestSnapshot([string]$ProjectPath, [int]$ExpectedFormat) {
    Require (@(3, 6) -contains $ExpectedFormat) "Unsupported expected persisted manifest format: $ExpectedFormat"
    $pointerPath = Join-Path $ProjectPath '.agentlang/store/CURRENT'
    $pointer = Read-Json $pointerPath
    Require ([int](Get-Property $pointer 'formatVersion') -eq 1 -and (Get-Property $pointer 'kind') -ceq 'manifest') "Unsupported CURRENT pointer in $ProjectPath"
    $manifestPath = Join-Path $ProjectPath ('.agentlang/store/manifests/' + (Get-Property $pointer 'manifestHash') + '.json')
    Require (Test-Path -LiteralPath $manifestPath -PathType Leaf) "CURRENT-selected manifest is missing in $ProjectPath"
    Require ((Get-Sha256 $manifestPath) -ceq [string](Get-Property $pointer 'manifestHash')) "CURRENT-selected manifest hash is wrong in $ProjectPath"
    $manifest = Read-Json $manifestPath
    Require ([int](Get-Property $manifest 'formatVersion') -eq $ExpectedFormat) "Expected persisted manifest format $ExpectedFormat in $ProjectPath"
    $hasTypeRevisions = $manifest -is [Collections.IDictionary] -and $manifest.Contains('typeRevisions')
    if ($ExpectedFormat -eq 3) {
        Require (-not $hasTypeRevisions) "Format-3 manifest unexpectedly declares typeRevisions in $ProjectPath"
    } else {
        Require $hasTypeRevisions "Format-6 manifest is missing typeRevisions in $ProjectPath"
    }
    $wordMap = [ordered]@{}
    foreach ($head in @($manifest.words)) { $wordMap[[string]$head.currentName] = $head }
    $typeMap = [ordered]@{}
    foreach ($type in @($manifest.types)) {
        $name = [string]$type.name
        $typeMap[$name] = $type
        $objectPath = Join-Path $ProjectPath ('.agentlang/store/objects/' + $type.definition.hash + '.agent')
        Require (Test-Path -LiteralPath $objectPath -PathType Leaf) "Missing current type source object for $name"
        Require ((Get-Sha256 $objectPath) -ceq [string]$type.definition.hash) "Current type source object hash mismatch for $name"
        $type.source = [IO.File]::ReadAllText($objectPath, $script:Utf8).Replace("`r`n", "`n")
        $typeMap[$name] = $type
    }
    $typeRevisionMap = [ordered]@{}
    if ($ExpectedFormat -eq 6) {
        foreach ($group in @($manifest.typeRevisions | Group-Object -Property name)) {
            $name = [string]$group.Name
            Require ($typeMap.Contains($name)) "Format-6 history has no current type head for $name"
            $rows = @($group.Group | Sort-Object -Property revision)
            for ($ordinal = 1; $ordinal -le $rows.Count; $ordinal++) {
                $row = $rows[$ordinal - 1]
                Require ([long]$row.revision -eq $ordinal) "Type history for $name is not contiguous at revision $ordinal"
                $objectPath = Join-Path $ProjectPath ('.agentlang/store/objects/' + $row.definition.hash + '.agent')
                Require (Test-Path -LiteralPath $objectPath -PathType Leaf) "Missing historical type source object for $name revision $ordinal"
                Require ((Get-Sha256 $objectPath) -ceq [string]$row.definition.hash) "Historical type source object hash mismatch for $name revision $ordinal"
                $row['source'] = [IO.File]::ReadAllText($objectPath, $script:Utf8).Replace("`r`n", "`n")
            }
            $typeRevisionMap[$name] = $rows
        }
    }
    $caseMap = [ordered]@{}
    foreach ($owner in $script:OwnerNames) {
        $head = $wordMap[$owner]
        Require ($null -ne $head) "Manifest has no current owner $owner in $ProjectPath"
        $revisions = @($manifest.revisions | Where-Object { $_.wordId -ceq $head.wordId -and [long]$_.revision -eq [long]$head.currentRevision })
        Require ($revisions.Count -eq 1) "Manifest has an ambiguous current revision for $owner in $ProjectPath"
        $revision = $revisions[0]
        foreach ($kind in @('tests', 'examples')) {
            foreach ($reference in @($revision[$kind])) {
                $objectPath = Join-Path $ProjectPath ('.agentlang/store/objects/' + $reference.hash + '.agent')
                Require (Test-Path -LiteralPath $objectPath -PathType Leaf) "Missing $kind source object $($reference.hash) for $owner"
                $objectHash = Get-Sha256 $objectPath
                Require ($objectHash -ceq [string]$reference.hash) "Source-object hash mismatch for $owner/$kind/$($reference.hash)"
                $source = [IO.File]::ReadAllText($objectPath, $script:Utf8).Replace("`r`n", "`n")
                $found = [regex]::Matches($source, '(?ms)^(test|example)\s+([^\s{]+)\s*\{.*?^\}')
                Require ($found.Count -eq 1) "Expected one attached case in $objectPath"
                $case = $found[0]
                $caseKind = $case.Groups[1].Value
                $caseName = $case.Groups[2].Value
                $key = $caseKind + ':' + $caseName
                Require (-not $caseMap.Contains($key)) "Duplicate attached case $key in manifest $ProjectPath"
                $caseMap[$key] = [ordered]@{ owner = $owner; kind = $caseKind; name = $caseName; source = $case.Value; sourceHash = $objectHash }
            }
        }
    }
    return [ordered]@{
        currentSha256 = Get-Sha256 $pointerPath
        generation = [long]$pointer.generation
        manifestHash = [string]$pointer.manifestHash
        manifestSha256 = Get-Sha256 $manifestPath
        format = [int]$manifest.formatVersion
        words = $wordMap
        types = $typeMap
        typeRevisions = $typeRevisionMap
        cases = $caseMap
        wordNames = @($wordMap.Keys)
        typeNames = @($typeMap.Keys)
        caseNames = @($caseMap.Keys)
    }
}

function Assert-GateAndPins {
    $validationPath = Join-Path $script:GateRoot 'full-validation.json'
    $exitPath = Join-Path $script:GateRoot 'full-validation-exit.json'
    $runtimePinsPath = Join-Path $script:GateRoot 'accepted-runtime-pins.json'
    $validation = Read-Json $validationPath
    $exitReceipt = Read-Json $exitPath
    Require ((Get-Property $validation 'passed') -eq $true) 'Full validation has not passed.'
    Require ([long](Get-Property $exitReceipt 'exitCode') -eq 0) 'Full validation terminal exit code is not zero.'
    Require (-not [string]::IsNullOrWhiteSpace([string](Get-Property $exitReceipt 'endedUtc'))) 'Full validation has no terminal timestamp.'
    $checks = @(Get-Property $validation 'checks')
    Require ($checks.Count -eq 37) "Expected all 37 full-validation checks; found $($checks.Count)."
    $failed = @($checks | Where-Object { [long](Get-Property $_ 'exitCode') -ne 0 })
    Require ($failed.Count -eq 0) "Full validation has $($failed.Count) failing checks."

    $pins = Read-Json $script:PreparationPinsPath
    Require ((Get-Property $pins 'allPinsMatch') -eq $true) 'Preparation pin receipt is not marked matched.'
    $preparerPin = Get-Property $pins 'preparationScript'
    $preparerPath = Assert-InRepo (Join-Path $script:Repo ([string](Get-Property $preparerPin 'path'))) 'Local oracle preparer'
    Require (Test-Path -LiteralPath $preparerPath -PathType Leaf) 'Pinned local oracle preparer is missing.'
    Require ((Get-Sha256 $preparerPath) -ceq [string](Get-Property $preparerPin 'sha256')) 'Pinned local oracle preparer changed.'
    $protocol = Get-Property $pins 'retained2Protocol'
    Require ((Get-Property $protocol 'profile') -ceq 'agentlang') 'Frozen retained-2 profile changed.'
    Require ((@($protocol.capabilities)).Count -eq 0) 'Frozen retained-2 protocol must use the empty capability default.'
    Require ((@($protocol.operations) -join ',') -ceq ($script:AllowedOperations -join ',')) 'Script allowlist differs from the exact frozen retained-2 operation order.'
    Require ((Get-Property $protocol 'clock') -ceq '2000-01-01T00:00:00Z' -and [long]$protocol.maxRequestBytes -eq 262144 -and [long]$protocol.maxResponseBytes -eq 524288 -and [long]$protocol.exchangeTimeoutMilliseconds -eq 120000 -and [long]$protocol.maxExchanges -eq 100) 'Frozen retained-2 limits or clock changed.'
    $seedPins = Get-Property $pins 'seed'
    Require (Test-Path -LiteralPath $script:Seed -PathType Container) 'Frozen persisted seed is missing.'
    $currentPath = Join-Path $script:Seed '.agentlang/store/CURRENT'
    Require ((Get-Sha256 $currentPath) -ceq [string]$seedPins.currentSha256) 'Frozen seed CURRENT hash changed.'
    $pointer = Read-Json $currentPath
    Require ([int]$pointer.formatVersion -eq 1 -and [long]$pointer.generation -eq [long]$seedPins.generation -and [string]$pointer.manifestHash -ceq [string]$seedPins.manifestHash) 'Frozen seed CURRENT fields changed.'
    $manifestPath = Join-Path $script:Seed ('.agentlang/store/manifests/' + $pointer.manifestHash + '.json')
    Require ((Get-Sha256 $manifestPath) -ceq [string]$seedPins.selectedManifestSha256) 'Frozen format-3 manifest hash changed.'
    $manifest = Read-Json $manifestPath
    Require ([int]$manifest.formatVersion -eq 3 -and [int]$seedPins.selectedManifestFormat -eq 3) 'Frozen seed is not the audited format-3 manifest.'
    foreach ($item in @(
        [ordered]@{ path = (Join-Path $script:Seed 'dictionary.agent'); expected = $seedPins.dictionarySha256 },
        [ordered]@{ path = (Join-Path $script:Seed 'history/task-0001.json'); expected = $seedPins.historyTask0001Sha256 },
        [ordered]@{ path = (Join-Path $script:GateRoot 'readiness-source/atomic-migration.patch.flow'); expected = $pins.sourcePatchSha256 },
        [ordered]@{ path = (Join-Path $script:GateRoot 'inherited-evidence-audit.json'); expected = $pins.inheritedEvidenceAudit.receiptSha256 },
        [ordered]@{ path = (Join-Path $script:Repo '.agentlang/efficacy-maintenance-184/dispatch-gate.json'); expected = ($pins.frozen184Pins | Where-Object name -CEQ 'dispatch-gate.json').expectedSha256 },
        [ordered]@{ path = (Join-Path $script:Repo '.agentlang/efficacy-maintenance-184/trials/actors.json'); expected = ($pins.frozen184Pins | Where-Object name -CEQ 'trials/actors.json').expectedSha256 }
    )) {
        Require (Test-Path -LiteralPath $item.path -PathType Leaf) "Pinned file is missing: $($item.path)"
        Require ((Get-Sha256 $item.path) -ceq [string]$item.expected) "Pinned file changed: $($item.path)"
    }
    $inherited = Read-Json (Join-Path $script:GateRoot 'inherited-evidence-audit.json')
    Require ((Get-Property $inherited 'passed') -eq $true -and [long]$inherited.tests -eq 21 -and [long]$inherited.examples -eq 3 -and [long]$inherited.adapted -eq 16) 'Inherited evidence source audit is incomplete or failed.'
    $auditRows = @($inherited.rows)
    $adaptedRows = @($auditRows | Where-Object { $_.adapted -eq $true })
    $failedReversals = @($auditRows | Where-Object { $_.typedWrapperReversalMatches -ne $true })
    Require ($auditRows.Count -eq 24 -and $adaptedRows.Count -eq 16 -and $failedReversals.Count -eq 0) 'Inherited evidence rows do not prove all 16 exact wrapper reversals.'
    Require (@($adaptedRows | Where-Object { $_.case.StartsWith('test:', [StringComparison]::Ordinal) }).Count -eq 13 -and @($adaptedRows | Where-Object { $_.case.StartsWith('example:', [StringComparison]::Ordinal) }).Count -eq 3) 'Inherited adaptation counts are not 13 tests plus 3 examples.'

    $sourcePins = Read-Json (Join-Path $script:GateRoot 'source-pins.json')
    foreach ($sourcePin in @($sourcePins.files)) {
        $path = Assert-InRepo (Join-Path $script:Repo $sourcePin.path) 'Source pin'
        Require (Test-Path -LiteralPath $path -PathType Leaf) "Pinned source is missing: $($sourcePin.path)"
        Require ((Get-Sha256 $path) -ceq [string]$sourcePin.sha256) "Source used by the full gate changed: $($sourcePin.path)"
    }

    $hostReceipt = Read-Json (Join-Path $script:GateRoot 'full-validation.subagent-host-v2.json')
    $matchedReceipt = Read-Json (Join-Path $script:GateRoot 'full-validation.matched-snapshots.json')
    $renewalReceipt = Read-Json (Join-Path $script:GateRoot 'full-validation.renewal-acceptance-gate.json')
    Require ((Get-Property $hostReceipt 'outcome') -ceq 'passed' -and [long]$hostReceipt.failedCheckCount -eq 0) 'The full-gate V2 host verification receipt did not pass.'
    Require ((Get-Property $matchedReceipt 'passed') -eq $true -and (Get-Property $renewalReceipt 'passed') -eq $true) 'A required accepted-runtime component receipt did not pass.'
    Require (Test-Path -LiteralPath $runtimePinsPath -PathType Leaf) 'Accepted runtime pins are missing; no binary hash may be inferred from source pins.'
    $runtimePins = Read-Json $runtimePinsPath
    Require ([string](Get-Property $runtimePins 'baseRevision') -ceq [string](Get-Property $sourcePins 'baseRevision')) 'Accepted runtime pins do not match the source-pinned base revision.'
    Require ([long](Get-Property $runtimePins 'format') -eq 1 -and (Get-Property $runtimePins 'fullGatePassed') -eq $true -and [long](Get-Property $runtimePins 'fullGateExitCode') -eq 0 -and [long](Get-Property $runtimePins 'fullGateChecks') -eq 37) 'Accepted runtime pins do not identify the passing terminal full gate.'
    $runtimeFiles = @(Get-Property $runtimePins 'files')
    Require ($runtimeFiles.Count -ge 4) 'Accepted runtime pins must include CLI, Core, deps, and runtimeconfig files.'
    $runtimeRows = [Collections.Generic.List[object]]::new()
    foreach ($file in $runtimeFiles) {
        $rawPath = [string](Get-Property $file 'path')
        $expectedHash = [string](Get-Property $file 'sha256')
        Require (-not [string]::IsNullOrWhiteSpace($rawPath) -and $expectedHash -match '^[0-9a-f]{64}$') 'Accepted runtime pin needs a path and lowercase SHA-256.'
        $path = if ([IO.Path]::IsPathRooted($rawPath)) { Assert-InRepo $rawPath 'Accepted runtime file' } else { Assert-InRepo (Join-Path $script:Repo $rawPath) 'Accepted runtime file' }
        Require (Test-Path -LiteralPath $path -PathType Leaf) "Accepted runtime file is missing: $path"
        $actualHash = Get-Sha256 $path
        Require ($actualHash -ceq $expectedHash) "Accepted runtime file hash changed: $path"
        $runtimeRows.Add([ordered]@{ path = [IO.Path]::GetRelativePath($script:Repo, $path).Replace('\', '/'); sha256 = $actualHash; name = [IO.Path]::GetFileName($path) })
    }
    $cliRows = @($runtimeRows | Where-Object { $_.name -ceq 'AgentLang.Cli.dll' })
    $coreRows = @($runtimeRows | Where-Object { $_.name -ceq 'AgentLang.Core.dll' })
    $depsRows = @($runtimeRows | Where-Object { $_.name -match '\.deps\.json$' })
    $configRows = @($runtimeRows | Where-Object { $_.name -match '\.runtimeconfig\.json$' })
    Require ($cliRows.Count -eq 1 -and $coreRows.Count -eq 1 -and $depsRows.Count -ge 1 -and $configRows.Count -ge 1) 'Accepted runtime pins do not cover the CLI, Core, deps, and runtimeconfig files.'
    $cliPath = Join-Path $script:Repo $cliRows[0].path
    $cliHash = [string]$cliRows[0].sha256
    Require ([string](Get-Property $runtimePins 'cliDll') -ceq $cliRows[0].path) 'Accepted runtime CLI path differs from the runtime file inventory.'
    $hostCliRows = @($hostReceipt.cliFiles | Where-Object { $_.name -ceq 'AgentLang.Cli.dll' })
    Require ($hostCliRows.Count -eq 1 -and [string]$hostCliRows[0].sha256 -ceq $cliHash) 'Accepted runtime CLI pin differs from the V2 acceptance receipt.'
    Require ([string]$matchedReceipt.cliSha256 -ceq $cliHash -and [string]$renewalReceipt.cliSha256 -ceq $cliHash) 'Accepted runtime CLI pin differs from an acceptance component receipt.'
    Require ([string]$hostReceipt.cliDll -ceq $cliPath) 'Accepted CLI path differs from the V2 acceptance receipt.'
    foreach ($wrapper in @($hostReceipt.wrapperFiles)) {
        $acceptedWrapper = @($runtimeRows | Where-Object { $_.path -ceq [string]$wrapper.path })
        Require ($acceptedWrapper.Count -eq 1 -and [string]$acceptedWrapper[0].sha256 -ceq [string]$wrapper.sha256) "Accepted runtime pins do not match verified V2 wrapper $($wrapper.path)."
    }

    $patchHash = Get-Sha256 $script:Patch
    Require ($patchHash -ceq [string]$pins.sourcePatchSha256 -and $patchHash -ceq [string]$inherited.patchHash) 'Atomic migration source patch pin changed.'
    $patchText = [IO.File]::ReadAllText($script:Patch, $script:Utf8).Replace("`r`n", "`n")
    $patchCases = [ordered]@{}
    foreach ($match in [regex]::Matches($patchText, '(?ms)^(test|example)\s+([^\s{]+)\s*\{.*?^\}')) {
        $key = $match.Groups[1].Value + ':' + $match.Groups[2].Value
        Require (-not $patchCases.Contains($key)) "Duplicate inline case in migration source: $key"
        $patchCases[$key] = $match.Value
    }
    $patchTests = @($patchCases.Keys | Where-Object { $_.StartsWith('test:', [StringComparison]::Ordinal) })
    $patchInheritedTests = @($adaptedRows | Where-Object { $_.case.StartsWith('test:', [StringComparison]::Ordinal) } | Where-Object { $patchCases.Contains([string]$_.case) })
    $patchNewTests = @($patchTests | Where-Object { -not $auditRows.case.Contains($_) })
    Require ($patchTests.Count -eq 20 -and $patchInheritedTests.Count -eq 13 -and $patchNewTests.Count -eq 7) 'Migration source must contain 13 inherited tests and exactly seven replay additions.'
    Require (@($patchCases.Keys | Where-Object { $_.StartsWith('example:', [StringComparison]::Ordinal) }).Count -eq 3) 'Migration source must retain exactly three examples.'
    $declaredFunctions = @([regex]::Matches($patchText, '(?m)^fn\s+([^\s(]+)\s*\(') | ForEach-Object { $_.Groups[1].Value })
    Assert-StringSet $declaredFunctions $script:CasOwnerNames 'Atomic patch owner set'

    return [ordered]@{
        fullValidationSha256 = Get-Sha256 $validationPath
        terminalExitSha256 = Get-Sha256 $exitPath
        sourcePinsSha256 = Get-Sha256 (Join-Path $script:GateRoot 'source-pins.json')
        acceptedRuntimePinsSha256 = Get-Sha256 $runtimePinsPath
        acceptedCliPath = $cliPath
        acceptedCliSha256 = $cliHash
        acceptedRuntimeFiles = @($runtimeRows)
        frozenSeedCurrentSha256 = Get-Sha256 $currentPath
        frozenSeedManifestHash = [string]$pointer.manifestHash
        frozenSeedManifestFormat = [int]$manifest.formatVersion
        migrationPatchSha256 = $patchHash
        inheritedAuditSha256 = Get-Sha256 (Join-Path $script:GateRoot 'inherited-evidence-audit.json')
        allowedOperations = $script:AllowedOperations
        allowedOperationsArgument = $script:AllowedOperations -join ','
        ownerCasSet = $script:CasOwnerNames
        typeCasSet = $script:TypeNames
        checkCount = $checks.Count
    }
}

function Start-Child([string]$FileName, [string[]]$Arguments, [string]$WorkingDirectory) {
    $start = [Diagnostics.ProcessStartInfo]::new()
    $start.FileName = $FileName
    $start.WorkingDirectory = $WorkingDirectory
    $start.UseShellExecute = $false
    $start.CreateNoWindow = $true
    $start.RedirectStandardInput = $true
    $start.RedirectStandardOutput = $true
    $start.RedirectStandardError = $true
    $start.StandardInputEncoding = [Text.UTF8Encoding]::new($false)
    $start.StandardOutputEncoding = [Text.UTF8Encoding]::new($false)
    $start.StandardErrorEncoding = [Text.UTF8Encoding]::new($false)
    foreach ($argument in $Arguments) { $start.ArgumentList.Add([string]$argument) }
    $process = [Diagnostics.Process]::new()
    $process.StartInfo = $start
    Require ($process.Start()) "Could not start process: $FileName"
    $process.EnableRaisingEvents = $true
    return [ordered]@{ process = $process; stderrTask = $process.StandardError.ReadToEndAsync(); stdoutTask = $process.StandardOutput.ReadToEndAsync() }
}

function Invoke-Child([string]$FileName, [string[]]$Arguments, [string]$WorkingDirectory, [int]$TimeoutMilliseconds, [string]$StdoutPath, [string]$StderrPath) {
    $child = Start-Child $FileName $Arguments $WorkingDirectory
    $process = $child.process
    if (-not $process.WaitForExit($TimeoutMilliseconds)) {
        try { $process.Kill($true) } catch { }
        [void]$process.WaitForExit(5000)
        throw "External command timed out after ${TimeoutMilliseconds}ms: $FileName"
    }
    $stdout = $child.stdoutTask.GetAwaiter().GetResult()
    $stderr = $child.stderrTask.GetAwaiter().GetResult()
    [IO.File]::WriteAllText($StdoutPath, $stdout, [Text.UTF8Encoding]::new($false))
    [IO.File]::WriteAllText($StderrPath, $stderr, [Text.UTF8Encoding]::new($false))
    $code = $process.ExitCode
    $process.Dispose()
    return [ordered]@{ exitCode = $code; stdout = $stdout; stderr = $stderr }
}

function Start-V2Session([string]$Name, [string]$ProjectPath, [string]$TracePath, [string]$TranscriptPath, [string]$CliPath) {
    $pwsh = (Get-Command pwsh -ErrorAction Stop).Source
    $hostScript = Join-Path $script:Repo 'scripts/Start-SubagentTrialHostV2.ps1'
    $args = @(
        '-NoLogo', '-NoProfile', '-NonInteractive', '-File', $hostScript,
        '-CliDll', $CliPath, '-ProjectPath', $ProjectPath, '-TracePath', $TracePath,
        '-AllowedOperations', ($script:AllowedOperations -join ','), '-Profile', 'agentlang',
        '-ClockValue', '2000-01-01T00:00:00Z', '-MaxRequestBytes', '262144', '-MaxResponseBytes', '524288',
        '-ExchangeTimeoutMilliseconds', '120000', '-MaxExchanges', '100'
    )
    $start = [Diagnostics.ProcessStartInfo]::new()
    $start.FileName = $pwsh
    $start.WorkingDirectory = $script:Repo
    $start.UseShellExecute = $false
    $start.CreateNoWindow = $true
    $start.RedirectStandardInput = $true
    $start.RedirectStandardOutput = $true
    $start.RedirectStandardError = $true
    $start.StandardInputEncoding = [Text.UTF8Encoding]::new($false)
    $start.StandardOutputEncoding = [Text.UTF8Encoding]::new($false)
    $start.StandardErrorEncoding = [Text.UTF8Encoding]::new($false)
    foreach ($argument in $args) { $start.ArgumentList.Add([string]$argument) }
    $process = [Diagnostics.Process]::new()
    $process.StartInfo = $start
    Require ($process.Start()) "Could not start the V2 host: $pwsh"
    $stderrTask = $process.StandardError.ReadToEndAsync()
    return [ordered]@{
        name = $Name; process = $process; stderrTask = $stderrTask
        tracePath = $TracePath; transcriptPath = $TranscriptPath; requestCount = 0; closed = $false; exitCode = $null
        cliPath = $CliPath
    }
}

function Add-Transcript([object]$Session, [object]$Row) {
    $line = ConvertTo-Json -InputObject $Row -Compress -Depth 100
    [IO.File]::AppendAllText($Session.transcriptPath, $line + [Environment]::NewLine, [Text.UTF8Encoding]::new($false))
}

function Invoke-V2([object]$Session, [Collections.IDictionary]$Request) {
    Require (-not $Session.closed -and -not $Session.process.HasExited) "V2 session '$($Session.name)' is not active."
    $wire = ConvertTo-Json -InputObject $Request -Compress -Depth 100
    Require (-not $wire.Contains("`n") -and -not $wire.Contains("`r")) 'Generated JSONL request contains an embedded line break.'
    $Session.process.StandardInput.WriteLine($wire)
    $Session.process.StandardInput.Flush()
    $responseTask = $Session.process.StandardOutput.ReadLineAsync()
    if (-not $responseTask.Wait(125000)) {
        try { $Session.process.Kill($true) } catch { }
        throw "V2 response timed out for $($Request.op); the partial trace and transcript are retained."
    }
    $raw = $responseTask.GetAwaiter().GetResult()
    Require ($null -ne $raw -and $raw.Length -gt 0) "V2 host returned no response for $($Request.op)."
    $response = ConvertFrom-Json -InputObject $raw -AsHashtable -DateKind String -Depth 100
    $Session.requestCount = [int]$Session.requestCount + 1
    Add-Transcript $Session ([ordered]@{ index = $Session.requestCount; request = $Request; response = $response; rawResponse = $raw })
    Require ((Get-Property $response 'ok') -eq $true) ("V2 operation {0} failed: {1}" -f $Request.op, (ConvertTo-Json -InputObject $response -Compress -Depth 20))
    return $response
}

function Close-V2Session([object]$Session, [string]$AuditName) {
    if ($null -eq $Session) { return $null }
    $closeError = $null
    if (-not $Session.closed) {
        try {
            if (-not $Session.process.HasExited) {
                $Session.process.StandardInput.WriteLine('{"op":"host.close"}')
                $Session.process.StandardInput.Flush()
                $Session.process.StandardInput.Close()
                Require ($Session.process.WaitForExit(15000)) "V2 host did not exit after host.close: $($Session.name)"
            }
        } catch { $closeError = $_.Exception.Message }
        $Session.closed = $true
    }
    if (-not $Session.process.HasExited) {
        try { $Session.process.Kill($true); [void]$Session.process.WaitForExit(5000) } catch { }
    }
    if ($Session.process.HasExited) { $Session.exitCode = $Session.process.ExitCode }
    $stdout = ''
    $stderr = ''
    try { $stdout = $Session.process.StandardOutput.ReadToEnd() } catch { }
    try { if ($Session.stderrTask.IsCompleted) { $stderr = $Session.stderrTask.GetAwaiter().GetResult() } } catch { }
    [IO.File]::WriteAllText((Join-Path $script:RunEvidence ($AuditName + '.host-stdout.txt')), $stdout, [Text.UTF8Encoding]::new($false))
    [IO.File]::WriteAllText((Join-Path $script:RunEvidence ($AuditName + '.host-stderr.txt')), $stderr, [Text.UTF8Encoding]::new($false))
    $auditPath = Join-Path $script:Repo 'scripts/Audit-SubagentTrialTerminationV2.ps1'
    $pwsh = (Get-Command pwsh -ErrorAction Stop).Source
    $audit = Invoke-Child $pwsh @('-NoLogo', '-NoProfile', '-NonInteractive', '-File', $auditPath, '-TracePath', $Session.tracePath) `
        $script:Repo 30000 (Join-Path $script:RunEvidence ($AuditName + '.audit-stdout.txt')) (Join-Path $script:RunEvidence ($AuditName + '.audit-stderr.txt'))
    $receipt = [ordered]@{
        name = $Session.name; tracePath = [IO.Path]::GetRelativePath($script:RunRoot, $Session.tracePath).Replace('\', '/')
        traceSha256 = if (Test-Path -LiteralPath $Session.tracePath -PathType Leaf) { Get-Sha256 $Session.tracePath } else { $null }
        transcriptSha256 = if (Test-Path -LiteralPath $Session.transcriptPath -PathType Leaf) { Get-Sha256 $Session.transcriptPath } else { $null }
        hostExitCode = $Session.exitCode; requestCount = $Session.requestCount; auditExitCode = $audit.exitCode
        auditStdout = $audit.stdout; closeError = $closeError
    }
    Write-Json (Join-Path $script:RunEvidence ($AuditName + '.termination.json')) $receipt
    Require ($null -eq $closeError) "V2 session close failed: $closeError"
    Require ([int]$Session.exitCode -eq 0) "V2 host process exited $($Session.exitCode): $($Session.name)"
    Require ([int]$audit.exitCode -eq 0) "V2 terminal trace audit failed for $($Session.name)."
    $Session.process.Dispose()
    return $receipt
}

function Invoke-Read([object]$Session, [string]$Operation, [string]$Key, [string]$Value, [switch]$IncludeSource) {
    $request = [ordered]@{ op = $Operation; $Key = $Value }
    if ($IncludeSource) { $request.includeSource = $true }
    return Invoke-V2 $Session $request
}

function Get-Signature([object]$Description) {
    return [ordered]@{ inputs = @($Description.inputs); outputs = @($Description.outputs); parameters = @($Description.parameters) }
}

function Compare-Signature([object]$Before, [object]$After, [string]$Owner) {
    if ($Owner -ceq 'shipment.find-scan') {
        Assert-TextEqual (ConvertTo-Json -InputObject @($After.inputs) -Compress -Depth 20) (ConvertTo-Json -InputObject @('Shipment', 'TrackingReference') -Compress -Depth 20) "$Owner migrated input order"
        Assert-TextEqual (ConvertTo-Json -InputObject @($After.outputs) -Compress -Depth 20) (ConvertTo-Json -InputObject @($Before.outputs) -Compress -Depth 20) "$Owner output order"
        $parameters = @($After.parameters)
        $beforeParameters = @($Before.parameters)
        Require ($parameters.Count -eq 2 -and $beforeParameters.Count -eq 2) "$Owner parameter count changed."
        $expectedParameters = @(
            [ordered]@{ name = [string]$beforeParameters[0].name; type = [string]$beforeParameters[0].type },
            [ordered]@{ name = [string]$beforeParameters[1].name; type = 'TrackingReference' }
        )
        Require ($expectedParameters[0].name -ceq 'shipment' -and $expectedParameters[0].type -ceq 'Shipment' -and $expectedParameters[1].name -ceq 'reference' -and $beforeParameters[1].type -ceq 'String') "$Owner parameter baseline does not match the expected migration."
        Assert-TextEqual (ConvertTo-Json -InputObject $parameters -Compress -Depth 20) (ConvertTo-Json -InputObject $expectedParameters -Compress -Depth 20) "$Owner parameter order and types"
    } else {
        Assert-TextEqual (ConvertTo-Json -InputObject (Get-Signature $After) -Compress -Depth 20) (ConvertTo-Json -InputObject (Get-Signature $Before) -Compress -Depth 20) "$Owner signature"
    }
}

function Get-CasesFromTests([object]$Rows) {
    $cases = [ordered]@{}
    foreach ($row in @($Rows)) {
        $owner = [string]$row.word
        $localName = [string]$row.name
        Require (-not [string]::IsNullOrWhiteSpace($owner) -and -not [string]::IsNullOrWhiteSpace($localName)) 'Runtime test source is missing its owner or local case name.'
        $qualifiedName = $owner + '/' + $localName
        $key = 'test:' + $qualifiedName
        Require (-not $cases.Contains($key)) "Duplicate runtime test source $key"
        $found = [regex]::Matches(([string]$row.source).Replace("`r`n", "`n"), '(?ms)^(test|example)\s+([^\s{]+)\s*\{.*?^\}')
        Require ($found.Count -eq 1) "Expected one complete test source for $key"
        Require ($found[0].Groups[1].Value -ceq 'test' -and $found[0].Groups[2].Value -ceq $qualifiedName) "Runtime test source header does not match owner/local name $qualifiedName"
        $cases[$key] = [ordered]@{ owner = $owner; kind = 'test'; name = $qualifiedName; source = $found[0].Value; sourceHash = [string]$row.sourceHash }
    }
    return $cases
}

function Assert-ExamplesMatchManifest([string]$Owner, [object[]]$RuntimeNames, [object]$Cases, [string]$Label) {
    $expectedLocalNames = @()
    foreach ($case in @($Cases.Values | Where-Object { $_.owner -ceq $Owner -and $_.kind -ceq 'example' })) {
        $prefix = $Owner + '/'
        $qualifiedName = [string]$case.name
        Require ($qualifiedName.StartsWith($prefix, [StringComparison]::Ordinal)) "Manifest example name is not qualified by owner $Owner"
        $expectedLocalNames += $qualifiedName.Substring($prefix.Length)
    }
    Assert-StringSet @($RuntimeNames) $expectedLocalNames $Label
}

function Assert-CasePreservation([object]$BeforeCases, [object]$AfterCases, [object]$PatchCases, [object]$InheritedAudit) {
    $beforeNames = @($BeforeCases.Keys)
    $afterNames = @($AfterCases.Keys)
    $patchNames = @($PatchCases.Keys)
    $expectedPost = @($beforeNames) + @($patchNames | Where-Object { -not $BeforeCases.Contains($_) })
    Assert-StringSet $afterNames $expectedPost 'Persisted attachment inventory after migration'
    $adapted = @{}
    foreach ($row in @($InheritedAudit.rows | Where-Object { $_.adapted })) { $adapted[[string]$row.case] = $true }
    $inheritedCount = 0
    foreach ($key in $beforeNames) {
        $inheritedCount++
        $baseline = [string]$BeforeCases[$key].source
        $observed = [string]$AfterCases[$key].source
        if ($PatchCases.Contains($key)) {
            $patch = [string]$PatchCases[$key]
            Assert-TextEqual $observed $patch "Persisted patch case $key"
        } else {
            Assert-TextEqual $observed $baseline "Unchanged inherited case $key"
        }
        if ($adapted.ContainsKey($key)) {
            $reversed = [regex]::Replace($observed, 'TrackingReference\.new\(("(?:\\.|[^"\\])*")\)', '$1')
            Assert-TextEqual $reversed $baseline "Exact inherited source after reversing only nominal wrappers for $key"
        } else {
            Assert-TextEqual $observed $baseline "Unadapted inherited source $key"
        }
    }
    foreach ($key in $patchNames) {
        if (-not $BeforeCases.Contains($key)) {
            Require ($key.StartsWith('test:', [StringComparison]::Ordinal)) "Unexpected non-test attachment was added: $key"
            Assert-TextEqual ([string]$AfterCases[$key].source) ([string]$PatchCases[$key]) "New replay test $key"
        }
    }
    Require ($inheritedCount -eq 24 -and $adapted.Count -eq 16) 'Inherited attachment inventory or adapted-case count changed.'
    Require (@($AfterCases.Keys | Where-Object { $_.StartsWith('test:', [StringComparison]::Ordinal) }).Count -eq 28) 'Expected 28 persisted tests after migration.'
    Require (@($AfterCases.Keys | Where-Object { $_.StartsWith('example:', [StringComparison]::Ordinal) }).Count -eq 3) 'Expected 3 persisted examples after migration.'
}

function Assert-TestResults([object]$Response, [int]$ExpectedCount, [string]$Label) {
    $results = @((Get-Property (Get-Property $Response 'data') 'results'))
    Require ($results.Count -eq $ExpectedCount) "$Label returned $($results.Count) tests; expected $ExpectedCount."
    $failed = @($results | Where-Object { (Get-Property $_ 'passed') -ne $true })
    Require ($failed.Count -eq 0) "$Label has $($failed.Count) failing tests."
    return $results
}

function Assert-ManifestEvolution([object]$Before, [object]$After) {
    Assert-StringSet @($Before.wordNames) @($After.wordNames) 'Persistent function owner names'
    foreach ($owner in $script:OwnerNames) {
        $old = $Before.words[$owner]
        $new = $After.words[$owner]
        Require ([string]$old.wordId -ceq [string]$new.wordId) "Persistent identity changed for $owner"
        if ($script:CasOwnerNames -ccontains $owner) {
            Require ([long]$new.currentRevision -gt [long]$old.currentRevision) "CAS owner revision did not advance for $owner"
        } else {
            Require ([long]$new.currentRevision -eq [long]$old.currentRevision) "Unchanged owner revision advanced for $owner"
        }
    }
    $expectedTypes = @($Before.typeNames) + @('TrackingReference')
    Assert-StringSet @($After.typeNames) $expectedTypes 'Persisted nominal type inventory'
    foreach ($typeName in $Before.typeNames) {
        $oldHash = [string]$Before.types[$typeName].definition.hash
        $newHash = [string]$After.types[$typeName].definition.hash
        if ($script:TypeNames -ccontains $typeName) {
            Require ($oldHash -cne $newHash) "Type source did not advance for $typeName"
        } else {
            Require ($oldHash -ceq $newHash) "Unchanged type source changed for $typeName"
        }
    }
}

function Compare-RuntimeOwner([object]$Before, [object]$After, [string]$Owner) {
    Require ([string]$Before.id -ceq [string]$After.id) "Owner ID changed for $Owner"
    Require ([string]$Before.maturity -ceq [string]$After.maturity) "Owner maturity changed for $Owner"
    Compare-Signature $Before $After $Owner
    if ($script:CasOwnerNames -ccontains $Owner) {
        Require ([long]$After.revision -gt [long]$Before.revision) "Runtime revision failed to advance under CAS for $Owner"
    } else {
        Require ([long]$After.revision -eq [long]$Before.revision) "Unchanged owner runtime revision advanced for $Owner"
    }
}

function Assert-History([object]$BeforeTypes, [object]$BeforeSources, [object]$AfterTypes, [object]$AfterSources, [object]$AfterHistories, [object]$AfterManifest) {
    Assert-StringSet @($AfterManifest.typeRevisions.Keys) $script:TypeNames 'Format-6 retained type-history names'
    foreach ($name in @($script:TypeNames) + @('TrackingReference')) {
        $history = @((Get-Property (Get-Property $AfterHistories[$name] 'data') 'revisions'))
        $priorRows = @()
        if ($AfterManifest.typeRevisions.Contains($name)) { $priorRows = @($AfterManifest.typeRevisions[$name]) }
        $expectedCurrentRevision = $priorRows.Count + 1
        Require ([long]$AfterTypes[$name].revision -eq $expectedCurrentRevision -and $history.Count -eq $expectedCurrentRevision) "History ordinal for $name differs between runtime and format-6 manifest."
        foreach ($prior in $priorRows) {
            $matchingPrior = @($history | Where-Object { [long]$_.revision -eq [long]$prior.revision -and [string]$_.sourceHash -ceq [string]$prior.definition.hash -and [string]$_.source -ceq [string]$prior.source -and $_.current -eq $false })
            Require ($matchingPrior.Count -eq 1) "History for $name does not match manifest's exact prior source/hash at revision $($prior.revision)."
        }
        $manifestHead = $AfterManifest.types[$name]
        Require ([string]$AfterTypes[$name].sourceHash -ceq [string]$manifestHead.definition.hash -and [string]$AfterSources[$name] -ceq [string]$manifestHead.source) "Current type source differs from format-6 manifest head for $name."
        $currentRows = @($history | Where-Object { [long]$_.revision -eq $expectedCurrentRevision -and [string]$_.sourceHash -ceq [string]$manifestHead.definition.hash -and [string]$_.source -ceq [string]$manifestHead.source -and $_.current -eq $true })
        Require ($currentRows.Count -eq 1) "History for $name is missing its exact current manifest head."
        if ($script:TypeNames -ccontains $name) {
            $oldHash = [string]$BeforeTypes[$name].sourceHash
            $oldSource = [string]$BeforeSources[$name]
            $oldRows = @($history | Where-Object { [string]$_.sourceHash -ceq $oldHash -and [string]$_.source -ceq $oldSource -and $_.current -eq $false })
            Require ($oldRows.Count -eq 1) "History for $name does not retain the exact previous source and hash as non-current."
            Require ([string]$AfterTypes[$name].sourceHash -cne $oldHash) "Current type source hash did not change for $name"
            Require ([string]$AfterSources[$name] -cne $oldSource) "Current type source text did not change for $name"
        }
    }
}

function Invoke-Scorer([string]$CapturedProject, [string]$CliPath) {
    $oracleRoot = Join-Path $script:Control 'oracle'
    $oracleReceiptPath = Join-Path $script:Control 'local-oracle-copy-receipt.json'
    $oracleSourceRoot = Join-Path $script:Repo 'experiments/AgentLang.SubagentTrials/typed-reference-maintenance-184/oracle'
    $upstreamHashes = [ordered]@{
        'score_reference.py' = '4d674aefeb9c79b992bd372835d26e4d289f570c8aded1f90990777dcf1d8659'
        'model.py' = 'ce7f674ac361139476c1b21c7ec9a32158babac32b385efeb26c1a552cba61a8'
        'cases.json' = '1ff64efdff553279d835137cdff7ceaa6e27c3d4d74ff7f1621dc6f02beb5e22'
    }
    $evidenceRootFrom = 'EVIDENCE = REPO / ".agentlang/efficacy-maintenance-184/oracle-draft"'
    $evidenceRootTo = 'EVIDENCE = HERE.parent / "oracle-results"'
    if (-not (Test-Path -LiteralPath $oracleRoot -PathType Container)) {
        $prepare = Join-Path $script:Control 'prepare-local-oracle.ps1'
        $pwsh = (Get-Command pwsh -ErrorAction Stop).Source
        $prep = Invoke-Child $pwsh @('-NoLogo', '-NoProfile', '-NonInteractive', '-File', $prepare) $script:Repo 120000 `
            (Join-Path $script:RunEvidence 'oracle-prepare.stdout.txt') (Join-Path $script:RunEvidence 'oracle-prepare.stderr.txt')
        Require ($prep.exitCode -eq 0) 'Pinned local scorer preparation failed.'
    }
    $oracleReceipt = Read-Json $oracleReceiptPath
    Require ([string]$oracleReceipt.upstreamDirectory -ceq 'experiments/AgentLang.SubagentTrials/typed-reference-maintenance-184/oracle') 'Local scorer receipt names the wrong frozen upstream directory.'
    Require ([string]$oracleReceipt.localDirectory -ceq [IO.Path]::GetRelativePath($script:Repo, $oracleRoot).Replace('\', '/')) 'Local scorer receipt names the wrong disposable copy directory.'
    Require ([string]$oracleReceipt.scorerEvidenceRootEdit.from -ceq $evidenceRootFrom -and [string]$oracleReceipt.scorerEvidenceRootEdit.to -ceq $evidenceRootTo) 'Local scorer receipt records an unexpected evidence-root edit.'
    $receiptRows = @($oracleReceipt.files)
    Assert-StringSet @($receiptRows | ForEach-Object { $_.name }) @('score_reference.py', 'model.py', 'cases.json') 'Local scorer receipt file names'
    foreach ($name in @('score_reference.py', 'model.py', 'cases.json')) {
        $upstreamPath = Join-Path $oracleSourceRoot $name
        Require (Test-Path -LiteralPath $upstreamPath -PathType Leaf) "Frozen scorer input is missing: $name"
        $upstreamHash = Get-Sha256 $upstreamPath
        Require ($upstreamHash -ceq [string]$upstreamHashes[$name]) "Frozen scorer input changed: $name"
        $localPath = Join-Path $oracleRoot $name
        Require (Test-Path -LiteralPath $localPath -PathType Leaf) "Local scorer input is missing: $name"
        $row = @($receiptRows | Where-Object name -CEQ $name)
        Require ($row.Count -eq 1 -and [string]$row[0].upstreamSha256 -ceq $upstreamHash) "Local scorer receipt has the wrong frozen-source hash for $name"
        $expectedLocalHash = $upstreamHash
        if ($name -ceq 'score_reference.py') {
            $upstreamText = [IO.File]::ReadAllText($upstreamPath, $script:Utf8)
            $first = $upstreamText.IndexOf($evidenceRootFrom, [StringComparison]::Ordinal)
            Require ($first -ge 0 -and $first -eq $upstreamText.LastIndexOf($evidenceRootFrom, [StringComparison]::Ordinal)) 'Frozen scorer no longer has exactly one pinned evidence-root line.'
            $expectedText = $upstreamText.Replace($evidenceRootFrom, $evidenceRootTo)
            $localText = [IO.File]::ReadAllText($localPath, $script:Utf8)
            Assert-TextEqual $localText $expectedText 'Derived local scorer source'
            $expectedBytes = [Text.UTF8Encoding]::new($false).GetBytes($expectedText)
            $expectedLocalHash = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($expectedBytes)).ToLowerInvariant()
        }
        $actualLocalHash = Get-Sha256 $localPath
        Require ($actualLocalHash -ceq $expectedLocalHash -and [string]$row[0].localSha256 -ceq $expectedLocalHash) "Local scorer pin differs from the independently derived expected file: $name"
    }
    $python = (Get-Command python -ErrorAction Stop).Source
    $scorer = Join-Path $oracleRoot 'score_reference.py'
    $oracleStdout = Join-Path $script:RunEvidence 'oracle-summary.json'
    $oracleStderr = Join-Path $script:RunEvidence 'oracle-stderr.txt'
    $result = Invoke-Child $python @($scorer, '--arm', 'flow', '--project', $CapturedProject, '--cli', $CliPath, '--label', $RunId) `
        $script:Repo 3600000 $oracleStdout $oracleStderr
    Require ($result.exitCode -eq 0) 'Independent 18-case scorer process reported a setup failure.'
    $summary = ConvertFrom-Json -InputObject $result.stdout -AsHashtable -DateKind String -Depth 100
    Require ((Get-Property $summary 'status') -ceq 'pass') 'Independent 18-case scorer did not pass.'
    Require ([long]$summary.behavior.expectedCaseCount -eq 18 -and [long]$summary.behavior.executedCaseCount -eq 18 -and [long]$summary.behavior.passedCaseCount -eq 18) 'Independent scorer did not pass all 18 behavior cases.'
    Require ($summary.referenceConstruction.nominalPositiveControlPassed -eq $true) 'Nominal TrackingReference positive control failed.'
    Require ($summary.typeNegativeControls.status -ceq 'pass') 'Nominal type negative controls failed.'
    Require ($summary.staticTypeMetadata.bothNamedTrackingReference -eq $true) 'TrackingReference type metadata was not confirmed.'
    Require ($summary.helperSignature.status -ceq 'pass') 'Public helper signature control failed.'
    Require ($summary.participantSourceUnchanged -eq $true) 'Independent scorer changed the captured participant project.'
    return [ordered]@{
        exitCode = $result.exitCode; outputPath = [IO.Path]::GetRelativePath($script:Control, $oracleStdout).Replace('\', '/')
        status = $summary.status; expectedCases = $summary.behavior.expectedCaseCount; executedCases = $summary.behavior.executedCaseCount
        passedCases = $summary.behavior.passedCaseCount; nominalPositiveControl = $summary.referenceConstruction.nominalPositiveControlPassed
        negativeControls = $summary.typeNegativeControls.status; helperSignature = $summary.helperSignature.status
        scorerSourceSha256 = Get-Sha256 $scorer; localScorerReceiptSha256 = Get-Sha256 $oracleReceiptPath
    }
}

# All gate, seed, source, and binary checks happen before a new run directory or participant copy is created.
$preflight = Assert-GateAndPins
Require (-not (Test-Path -LiteralPath $script:RunRoot)) "Scoped readiness run already exists; choose a fresh RunId: $script:RunRoot"

[void][IO.Directory]::CreateDirectory($script:RunRoot)
$script:RunEvidence = Join-Path $script:RunRoot 'evidence'
[void][IO.Directory]::CreateDirectory($script:RunEvidence)
$participantRoot = Join-Path $script:RunRoot 'participant'
$workProject = Join-Path $participantRoot 'work'
$tracePath = Join-Path $script:RunEvidence 'migration-trace.jsonl'
$transcriptPath = Join-Path $script:RunEvidence 'migration-transcript.jsonl'
$capturedRoot = Join-Path $script:RunRoot 'captured'
$capturedProject = Join-Path $capturedRoot 'project'
$reloadTrace = Join-Path $script:RunEvidence 'reload-trace.jsonl'
$reloadTranscript = Join-Path $script:RunEvidence 'reload-transcript.jsonl'
$failureReceiptPath = Join-Path $script:RunEvidence 'failure.json'

try {
    Write-Json (Join-Path $script:RunEvidence 'preflight.json') $preflight
    $seedInventory = Get-TreeInventory $script:Seed
    Write-Json (Join-Path $script:RunEvidence 'frozen-seed-inventory.json') $seedInventory
    Copy-TreeContents $script:Seed $workProject
    $workInventory = Get-TreeInventory $workProject
    Assert-TreeEqual $workInventory $seedInventory 'Fresh participant copy, including hidden persisted inputs'
    Write-Json (Join-Path $script:RunEvidence 'participant-copy-inventory.json') $workInventory
    $beforeManifest = Get-ManifestSnapshot $workProject 3
    Require ($beforeManifest.format -eq 3 -and $beforeManifest.manifestHash -ceq $preflight.frozenSeedManifestHash) 'Fresh participant is not the exact frozen format-3 seed.'
    Require (@($beforeManifest.cases.Keys | Where-Object { $_.StartsWith('test:', [StringComparison]::Ordinal) }).Count -eq 21) 'Persisted seed does not contain exactly 21 attached tests.'
    Require (@($beforeManifest.cases.Keys | Where-Object { $_.StartsWith('example:', [StringComparison]::Ordinal) }).Count -eq 3) 'Persisted seed does not contain exactly three examples.'

    $patchText = [IO.File]::ReadAllText($script:Patch, $script:Utf8).Replace("`r`n", "`n")
    $patchCases = [ordered]@{}
    foreach ($match in [regex]::Matches($patchText, '(?ms)^(test|example)\s+([^\s{]+)\s*\{.*?^\}')) { $patchCases[$match.Groups[1].Value + ':' + $match.Groups[2].Value] = $match.Value }
    $inheritedAudit = Read-Json (Join-Path $script:GateRoot 'inherited-evidence-audit.json')

    $script:MigrationSession = Start-V2Session 'migration' $workProject $tracePath $transcriptPath $preflight.acceptedCliPath
    $beforeTypeDescriptions = [ordered]@{}
    $beforeTypeSources = [ordered]@{}
    $beforeTypeHistories = [ordered]@{}
    foreach ($name in $script:TypeNames) {
        $beforeTypeDescriptions[$name] = (Invoke-Read $script:MigrationSession 'describe' 'type' $name).data
        $beforeTypeSources[$name] = (Invoke-Read $script:MigrationSession 'source' 'type' $name).data
        $beforeTypeHistories[$name] = Invoke-Read $script:MigrationSession 'history' 'type' $name
    }
    $beforeOwners = [ordered]@{}
    $beforeTests = [ordered]@{}
    $beforeExamples = [ordered]@{}
    foreach ($owner in $script:OwnerNames) {
        $beforeOwners[$owner] = (Invoke-Read $script:MigrationSession 'describe' 'word' $owner).data
        $beforeTests[$owner] = (Invoke-Read $script:MigrationSession 'tests' 'word' $owner -IncludeSource).data
        $beforeExamples[$owner] = (Invoke-Read $script:MigrationSession 'examples' 'word' $owner).data
    }
    $runtimeBaselineTests = [Collections.Generic.List[object]]::new()
    foreach ($owner in $script:OwnerNames) {
        foreach ($row in @($beforeTests[$owner])) { $runtimeBaselineTests.Add($row) }
        Assert-ExamplesMatchManifest $owner @($beforeExamples[$owner]) $beforeManifest.cases "Baseline example names for $owner"
    }
    Require ($runtimeBaselineTests.Count -eq 21) 'V2 baseline did not enumerate all 21 attached test sources.'
    $runtimeBaselineMap = Get-CasesFromTests $runtimeBaselineTests.ToArray()
    foreach ($key in $runtimeBaselineMap.Keys) {
        Require ($beforeManifest.cases.Contains($key)) "Baseline V2 test is absent from persisted manifest: $key"
        Assert-TextEqual ([string]$runtimeBaselineMap[$key].source) ([string]$beforeManifest.cases[$key].source) "Baseline test source $key"
    }
    Write-Json (Join-Path $script:RunEvidence 'baseline-v2.json') ([ordered]@{
        typeDescriptions = $beforeTypeDescriptions; typeSources = $beforeTypeSources; typeHistories = $beforeTypeHistories
        ownerDescriptions = $beforeOwners; tests = $beforeTests; examples = $beforeExamples
        manifest = [ordered]@{ currentSha256 = $beforeManifest.currentSha256; generation = $beforeManifest.generation; hash = $beforeManifest.manifestHash; format = $beforeManifest.format }
        typeCas = [ordered]@{}; ownerCas = [ordered]@{}
    })
    $expectedTypeSources = [ordered]@{}
    foreach ($name in $script:TypeNames) { $expectedTypeSources[$name] = [string]$beforeTypeDescriptions[$name].sourceHash }
    $expectedRevisions = [ordered]@{}
    foreach ($name in $script:CasOwnerNames) { $expectedRevisions[$name] = [long]$beforeOwners[$name].revision }
    Write-Json (Join-Path $script:RunEvidence 'cas-tokens.json') ([ordered]@{ typeSources = $expectedTypeSources; ownerRevisions = $expectedRevisions })

    $goal = 'Atomically migrate retained shipment references to TrackingReference and preserve the attached study evidence.'
    [void](Invoke-V2 $script:MigrationSession ([ordered]@{ op = 'task.begin'; goal = $goal }))
    $sourceText = [IO.File]::ReadAllText($script:Patch, $script:Utf8)
    $definition = [ordered]@{
        op = 'define'; frontend = 'flow'; syntaxVersion = 2; replace = $true; source = $sourceText
        expectedTypeSources = $expectedTypeSources; expectedRevisions = $expectedRevisions
    }
    $defineResponse = Invoke-V2 $script:MigrationSession $definition
    Require ((Get-Property $defineResponse 'kind') -ceq 'defined') 'Atomic type-evolution define did not stage successfully.'
    $testResponse = Invoke-V2 $script:MigrationSession ([ordered]@{ op = 'test-all' })
    $testRows = Assert-TestResults $testResponse 28 'Staged full test run'
    $commitResponse = Invoke-V2 $script:MigrationSession ([ordered]@{ op = 'commit'; word = 'shipment.find-scan'; library = $true })
    Require ((Get-Property $commitResponse 'kind') -ceq 'commit') 'Atomic library commit did not succeed.'
    $commitTests = @((Get-Property $commitResponse 'data'))
    Require ($commitTests.Count -gt 0) 'Library commit returned no attached test results.'
    $taskLogBeforeFinalize = (Invoke-V2 $script:MigrationSession ([ordered]@{ op = 'task.log' })).data
    Require ([long]$taskLogBeforeFinalize.testsRun -gt 0 -and [long]$taskLogBeforeFinalize.testsFailed -eq 0) 'Task log before finalization has no passing test evidence.'
    $taskFinalize = Invoke-V2 $script:MigrationSession ([ordered]@{ op = 'task.commit' })
    Require ((Get-Property $taskFinalize 'kind') -ceq 'task.commit' -and (Get-Property $taskFinalize.data 'active') -eq $false) 'Task finalization did not complete.'
    $taskLogAfterFinalize = (Invoke-V2 $script:MigrationSession ([ordered]@{ op = 'task.log' })).data
    Require ([long]$taskLogAfterFinalize.testsRun -gt 0 -and [long]$taskLogAfterFinalize.testsFailed -eq 0) 'Final task log lacks passing test evidence.'
    $migrationTermination = Close-V2Session $script:MigrationSession 'migration'
    $script:MigrationSession = $null
    Write-Json (Join-Path $script:RunEvidence 'migration-lifecycle.json') ([ordered]@{
        defined = $defineResponse; testCount = $testRows.Count; passedTestCount = @($testRows | Where-Object passed).Count
        commitKind = $commitResponse.kind; commitTestResults = $commitTests; taskLogBeforeFinalize = $taskLogBeforeFinalize
        taskFinalize = $taskFinalize; taskLogAfterFinalize = $taskLogAfterFinalize; termination = $migrationTermination
    })

    # Only an explicitly closed and audited migration process may be captured.
    $postWorkInventory = Get-TreeInventory $workProject
    Copy-TreeContents $workProject $capturedProject
    $capturedInventory = Get-TreeInventory $capturedProject
    Assert-TreeEqual $capturedInventory $postWorkInventory 'Post-termination captured project'
    Write-Json (Join-Path $script:RunEvidence 'captured-project-inventory.json') $capturedInventory
    $afterManifest = Get-ManifestSnapshot $capturedProject 6
    Require ($afterManifest.format -eq 6) 'Captured participant did not persist a format-6 manifest.'
    Assert-ManifestEvolution $beforeManifest $afterManifest

    $script:ReloadSession = Start-V2Session 'fresh-process-reload' $capturedProject $reloadTrace $reloadTranscript $preflight.acceptedCliPath
    $afterTypeDescriptions = [ordered]@{}
    $afterTypeSources = [ordered]@{}
    $afterTypeHistories = [ordered]@{}
    foreach ($name in @($script:TypeNames) + @('TrackingReference')) {
        $afterTypeDescriptions[$name] = (Invoke-Read $script:ReloadSession 'describe' 'type' $name).data
        $afterTypeSources[$name] = (Invoke-Read $script:ReloadSession 'source' 'type' $name).data
        $afterTypeHistories[$name] = Invoke-Read $script:ReloadSession 'history' 'type' $name
        $manifestType = $afterManifest.types[$name]
        Require ($null -ne $manifestType) "Captured manifest omits type $name"
        Require ([string]$afterTypeDescriptions[$name].sourceHash -ceq [string]$manifestType.definition.hash) "Fresh-process type hash differs from persisted object for $name"
        $objectPath = Join-Path $capturedProject ('.agentlang/store/objects/' + $manifestType.definition.hash + '.agent')
        Require ((Get-Sha256 $objectPath) -ceq [string]$manifestType.definition.hash) "Captured type object hash differs for $name"
    }
    Assert-History $beforeTypeDescriptions $beforeTypeSources $afterTypeDescriptions $afterTypeSources $afterTypeHistories $afterManifest
    foreach ($name in $script:TypeNames) { Require ($afterTypeDescriptions[$name].status -ceq 'persistent') "Migrated type $name is not persistent." }
    Require ($afterTypeDescriptions.TrackingReference.status -ceq 'persistent') 'TrackingReference is not persistent.'

    $afterOwners = [ordered]@{}
    $afterTests = [ordered]@{}
    $afterExamples = [ordered]@{}
    $runtimePostTests = [Collections.Generic.List[object]]::new()
    foreach ($owner in $script:OwnerNames) {
        $afterOwners[$owner] = (Invoke-Read $script:ReloadSession 'describe' 'word' $owner).data
        $afterTests[$owner] = (Invoke-Read $script:ReloadSession 'tests' 'word' $owner -IncludeSource).data
        $afterExamples[$owner] = (Invoke-Read $script:ReloadSession 'examples' 'word' $owner).data
        Compare-RuntimeOwner $beforeOwners[$owner] $afterOwners[$owner] $owner
        foreach ($row in @($afterTests[$owner])) { $runtimePostTests.Add($row) }
        Assert-ExamplesMatchManifest $owner @($afterExamples[$owner]) $afterManifest.cases "Captured example names for $owner"
    }
    $runtimePostMap = Get-CasesFromTests $runtimePostTests.ToArray()
    Require ($runtimePostTests.Count -eq 28) 'Fresh process did not enumerate all 28 attached tests.'
    foreach ($key in $runtimePostMap.Keys) {
        Require ($afterManifest.cases.Contains($key)) "Fresh-process test source is absent from the captured manifest: $key"
        Assert-TextEqual ([string]$runtimePostMap[$key].source) ([string]$afterManifest.cases[$key].source) "Reloaded test source $key"
    }
    Assert-CasePreservation $beforeManifest.cases $afterManifest.cases $patchCases $inheritedAudit
    $reloadTestResponse = Invoke-V2 $script:ReloadSession ([ordered]@{ op = 'test-all' })
    $reloadResults = Assert-TestResults $reloadTestResponse 28 'Fresh-process full test run'
    $reloadTermination = Close-V2Session $script:ReloadSession 'reload'
    $script:ReloadSession = $null
    $afterReloadInventory = Get-TreeInventory $capturedProject
    Assert-TreeEqual $afterReloadInventory $capturedInventory 'Read-only fresh-process reload'

    $preservationReceipt = [ordered]@{
        passed = $true; cloneIncludedHiddenFiles = $true; seedFormat = $beforeManifest.format; capturedFormat = $afterManifest.format
        seedManifestHash = $beforeManifest.manifestHash; capturedManifestHash = $afterManifest.manifestHash
        typeCasNames = $script:TypeNames; ownerCasNames = $script:CasOwnerNames
        ownerIdsMaturityAndSignatures = $afterOwners; baselineOwners = $beforeOwners
        currentTypes = $afterTypeDescriptions; currentTypeSources = $afterTypeSources; typeHistories = $afterTypeHistories
        baselineCases = $beforeManifest.cases; capturedCases = $afterManifest.cases
        inheritedCaseCount = $beforeManifest.cases.Count; adaptedCaseCount = $inheritedAudit.adapted
        capturedCaseCount = $afterManifest.cases.Count; testCountAfterMigration = $testRows.Count; reloadTestCount = $reloadResults.Count
        migrationTermination = $migrationTermination; reloadTermination = $reloadTermination
        participantFilesBeforeReload = $capturedInventory.Count; participantFilesAfterReload = $afterReloadInventory.Count
    }
    Write-Json (Join-Path $script:RunEvidence 'preservation-history-receipt.json') $preservationReceipt

    $oracleReceipt = Invoke-Scorer $capturedProject $preflight.acceptedCliPath
    Write-Json (Join-Path $script:RunEvidence 'oracle-receipt.json') $oracleReceipt
    $final = [ordered]@{
        status = 'passed'; runId = $RunId; runRoot = [IO.Path]::GetRelativePath($script:Repo, $script:RunRoot).Replace('\', '/')
        acceptedCliSha256 = $preflight.acceptedCliSha256; seedManifestHash = $beforeManifest.manifestHash
        capturedManifestHash = $afterManifest.manifestHash; migrationTraceSha256 = $migrationTermination.traceSha256
        reloadTraceSha256 = $reloadTermination.traceSha256; testCount = $testRows.Count; oracle = $oracleReceipt
        preservationReceipt = 'evidence/preservation-history-receipt.json'
    }
    Write-Json (Join-Path $script:RunEvidence 'readiness-control-receipt.json') $final
    Write-Output (ConvertTo-Json -InputObject $final -Compress -Depth 20)
}
catch {
    if ($null -ne $script:MigrationSession) { try { [void](Close-V2Session $script:MigrationSession 'migration-failed') } catch { } }
    if ($null -ne $script:ReloadSession) { try { [void](Close-V2Session $script:ReloadSession 'reload-failed') } catch { } }
    $failure = [ordered]@{
        status = 'failed'; runId = $RunId; error = $_.Exception.Message
        stack = $_.ScriptStackTrace; acceptedCliSha256 = if ($null -ne $preflight) { $preflight.acceptedCliSha256 } else { $null }
        runRoot = if (Test-Path -LiteralPath $script:RunRoot) { [IO.Path]::GetRelativePath($script:Repo, $script:RunRoot).Replace('\', '/') } else { $null }
        preservedPartialArtifacts = if (Test-Path -LiteralPath $script:RunRoot) { @(Get-TreeInventory $script:RunRoot) } else { @() }
    }
    if ($null -ne $script:RunEvidence -and (Test-Path -LiteralPath $script:RunEvidence)) { Write-Json $failureReceiptPath $failure }
    [Console]::Error.WriteLine((ConvertTo-Json -InputObject $failure -Compress -Depth 20))
    throw
}

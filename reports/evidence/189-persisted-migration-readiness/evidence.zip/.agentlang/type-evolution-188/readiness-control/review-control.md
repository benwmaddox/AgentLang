# Bounded readiness-control source review

Snapshot: 2026-10-10. This reviewer read only `run-readiness-control.ps1`, `prepare-local-oracle.ps1`, and `protocol-recipe.md`; no migration, build, test, oracle, host, network, or tracked-file operation was run. Source worker froze these files for review; the runner was edited once during review to fix the first finding below.

| File | Reviewed SHA-256 |
| --- | --- |
| `run-readiness-control.ps1` | `1171797FD94B8F76655277529D08018010CF10FE5E05720DD406FDE152203324` |
| `prepare-local-oracle.ps1` | `E4F8C2C1FBB8844C6C816FFE06A7247B151E0A140B1A0D3A1EFEFD290800878B` |
| `protocol-recipe.md` | `EB79D957AFE8A36BC283C4E0FFC144C3D956ACB48C83A0A02CE1A8376231CBDB` |

## Findings

1. **Resolved in reviewed runner snapshot — preflight variable order.** Initial runner hash `5595FD29EE37923AB2441461F00E2BAA805919326E33B2BEAE724A29B4D90B39` read `$runtimePins` before assigning it. With `Set-StrictMode -Version Latest`, preflight would fail before cloning. The current runner loads accepted runtime pins at lines 273-275 before comparing `baseRevision`.
2. **Resolved in reviewed runner snapshot — reused local scorer pinning.** An earlier runner trusted mutable local scorer hashes from its adjacent receipt when `oracle/` already existed. The current runner independently hashes the pinned upstream scorer/model/cases, derives the exact one-line evidence-root substitution, checks local text and byte hash, and checks the receipt against these independent values before running Python (`run-readiness-control.ps1:651-697`). The preparation helper applies the same pinned substitution (`prepare-local-oracle.ps1:11-60`).

## Scope and source evidence

The runner's preflight checks the terminal 37-check gate, the exact retained-2 allowlist/profile/clock/limits, source and runtime pins, frozen format-3 CURRENT and selected manifest, patch and inherited-case audit (`:211-342`). It inventories and clones the full persisted project including hidden files (`:703-714`); derives three type and six word CAS tokens from V2 describe responses (`:721-759`); stages one Flow/2 define, requires 28 passing tests, commits by a group member, finalizes the task, and audits host termination before capture (`:761-795`). It verifies captured format 6, owner IDs/maturity/signatures, three prior type sources and histories, 21 inherited tests, three examples, seven added tests, and 28 reload test results (`:796-856`). The recipe is aligned with this control flow and limits. These are source assertions, not evidence that the runner has executed successfully.

The source worker confirmed from Runtime source that format-6 `typeRevisions` stores displaced prior rows and runtime history appends the current type head; the runner's `priorRows.Count + 1` ordinal check (`:624-649`) follows that shape. The worker also confirmed inherited patch constructors use `TrackingReference.new(...)`, matching the reversal expression (`:563`). Root and worker checked that V2 `tests(includeSource)` rows have owner in `.word`, local name in `.name`, and an owner-qualified source header, while `examples` returns local-name strings; the runner's normalization (`:515-540`) follows those shapes. These are source-shape confirmations, not execution evidence.

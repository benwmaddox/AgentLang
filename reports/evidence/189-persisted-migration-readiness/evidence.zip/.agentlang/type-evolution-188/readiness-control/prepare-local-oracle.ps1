#requires -Version 7.0
[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$repo = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..\..'))
$sourceRoot = Join-Path $repo 'experiments/AgentLang.SubagentTrials/typed-reference-maintenance-184/oracle'
$targetRoot = Join-Path $PSScriptRoot 'oracle'
$expected = [ordered]@{
    'score_reference.py' = '4d674aefeb9c79b992bd372835d26e4d289f570c8aded1f90990777dcf1d8659'
    'model.py' = 'ce7f674ac361139476c1b21c7ec9a32158babac32b385efeb26c1a552cba61a8'
    'cases.json' = '1ff64efdff553279d835137cdff7ceaa6e27c3d4d74ff7f1621dc6f02beb5e22'
}
$from = 'EVIDENCE = REPO / ".agentlang/efficacy-maintenance-184/oracle-draft"'
$to = 'EVIDENCE = HERE.parent / "oracle-results"'

if (Test-Path -LiteralPath $targetRoot) {
    throw "Refusing to overwrite existing local oracle directory: $targetRoot"
}
foreach ($name in $expected.Keys) {
    $source = Join-Path $sourceRoot $name
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "Missing pinned oracle input: $source" }
    $actualHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $source).Hash.ToLowerInvariant()
    if ($actualHash -cne $expected[$name]) { throw "Pinned oracle input changed: $source ($actualHash)" }
}

$scoreSource = Join-Path $sourceRoot 'score_reference.py'
$scoreText = [IO.File]::ReadAllText($scoreSource, [Text.UTF8Encoding]::new($false, $true))
$first = $scoreText.IndexOf($from, [StringComparison]::Ordinal)
if ($first -lt 0 -or $first -ne $scoreText.LastIndexOf($from, [StringComparison]::Ordinal)) {
    throw 'Expected exactly one frozen scorer evidence-root line.'
}
$derivedScore = $scoreText.Replace($from, $to)

[void](New-Item -ItemType Directory -Path $targetRoot)
foreach ($name in @('model.py', 'cases.json')) {
    Copy-Item -LiteralPath (Join-Path $sourceRoot $name) -Destination (Join-Path $targetRoot $name)
}
[IO.File]::WriteAllText((Join-Path $targetRoot 'score_reference.py'), $derivedScore, [Text.UTF8Encoding]::new($false))

$files = foreach ($name in @('score_reference.py', 'model.py', 'cases.json')) {
    $source = Join-Path $sourceRoot $name
    $copy = Join-Path $targetRoot $name
    [pscustomobject]@{
        name = $name
        upstreamSha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $source).Hash.ToLowerInvariant()
        localSha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $copy).Hash.ToLowerInvariant()
    }
}
$receipt = [ordered]@{
    purpose = 'Local copy of the frozen 184 independent scorer; the only scorer edit redirects output away from frozen 184 evidence.'
    upstreamDirectory = [IO.Path]::GetRelativePath($repo, $sourceRoot).Replace('\', '/')
    localDirectory = [IO.Path]::GetRelativePath($repo, $targetRoot).Replace('\', '/')
    scorerEvidenceRootEdit = [ordered]@{ from = $from; to = $to }
    files = @($files)
}
$receiptPath = Join-Path $PSScriptRoot 'local-oracle-copy-receipt.json'
[IO.File]::WriteAllText($receiptPath, ($receipt | ConvertTo-Json -Depth 6) + [Environment]::NewLine, [Text.UTF8Encoding]::new($false))
Write-Output (ConvertTo-Json -InputObject $receipt -Depth 6 -Compress)

# Persisted-seed readiness control

Preparation only. Run after the accepted StageB CLI and its acceptance receipt are available. No migration, broker session, build, test, or oracle has been run from this directory.

## Frozen source and patch

Start only from the dispatch-selected persisted project:

    .agentlang/efficacy-maintenance-184/seed-draft/projects/draft-009/flow-retained/project

Its CURRENT selects a format-3 manifest. The audited pins are CURRENT SHA-256 35392f0dd027efc2f145f146b8e9e02b50088cde2dda309da25c818ce320a80f, selected manifest hash and file SHA-256 f6ddf24bb78014908fc45d1e4f464baeb6c6b3b2cff693b7c140d18eacd29a6f, dictionary.agent SHA-256 228d35945892c59e0cb682b1fb85549053718f99ab53cf75fafc42e14a723e20, and history/task-0001.json SHA-256 5bc69cdc849a9284aaea089d5d0d0696e1693efff81f521bfece6bf0a0392ee3. Dispatch gate and retained-2 actor pins are recorded in readiness-source/persisted-seed-source-audit.md. Recheck all pins before each run. Do not use retained-1's candidate, recreate the project from Flow source, or write under efficacy-maintenance-184.

Copy the entire persisted project, including hidden .agentlang files, to a fresh runs/<run-id>/participant/work directory. Keep trace and evidence paths outside that project. Record equal before/after file inventories for source and clone before the host starts.

The migration draft is readiness-source/atomic-migration.patch.flow, SHA-256 ef8c9bc22ec5e38c059e924f3439dbbd6aadee814085aa9a11328ad257c97e85. The root-owned inherited source audit receipt currently reports passed=true, 21 baseline tests, 3 examples, and 16/16 adapted cases exact after reversing only nominal constructor wrappers.

The patch adds TrackingReference : String, changes Scan.reference, ScanInput.reference, ShipmentScanLookup.target, and shipment.find-scan's reference parameter to TrackingReference, then updates shipment.ingest-rule. Equality stays exact, empty values remain valid, status is validated before replay deduplication, and the original first scan remains. No helper is needed. Type-CAS keys are exactly Scan, ScanInput, ShipmentScanLookup. Six owner-CAS keys are shipment.batch-step, shipment.find-scan, shipment.ingest, shipment.ingest-batch, shipment.ingest-rule, shipment.scan-lookup-step. TrackingReference is new and has no prior CAS token.

## V2 migration session

Use the CLI produced by the accepted StageB validation and compare its SHA-256 to that acceptance receipt. Do not build another CLI. Launch the existing V2 host from a terminal that can send and receive JSONL:

    pwsh -NoProfile -File scripts/Start-SubagentTrialHostV2.ps1 -CliDll <accepted-fresh-AgentLang.Cli.dll> -ProjectPath .agentlang/type-evolution-188/readiness-control/runs/<run-id>/participant/work -TracePath .agentlang/type-evolution-188/readiness-control/runs/<run-id>/evidence/migration-trace.jsonl -AllowedOperations 'callers,commit,context,define,dependencies,describe,diff,effects,eval,example,examples,failed-tests,graph,help,history,ir,replace-word,search,search-dependency,search-output,search-type,source,task.begin,task.commit,task.log,task.status,test,test-all,tests,transitive-callers,transitive-dependencies,type-of,words' -Profile agentlang -ClockValue '2000-01-01T00:00:00Z' -MaxRequestBytes 262144 -MaxResponseBytes 524288 -ExchangeTimeoutMilliseconds 120000 -MaxExchanges 100

This uses the frozen retained participant profile, operations, clock and limits. Capabilities are omitted so the host uses its empty default. The reserved one-field transport request {"op":"host.close"} is not an allowed runtime operation. The frozen operations omit task.abort; do not expand the allowlist.

Before staging, send these requests and retain the full V2 trace:

    {"op":"describe","type":"Scan"}
    {"op":"describe","type":"ScanInput"}
    {"op":"describe","type":"ShipmentScanLookup"}
    {"op":"source","type":"Scan"}
    {"op":"source","type":"ScanInput"}
    {"op":"source","type":"ShipmentScanLookup"}
    {"op":"describe","word":"shipment.batch-step"}
    {"op":"describe","word":"shipment.find-scan"}
    {"op":"describe","word":"shipment.ingest"}
    {"op":"describe","word":"shipment.ingest-batch"}
    {"op":"describe","word":"shipment.ingest-rule"}
    {"op":"describe","word":"shipment.scan-lookup-step"}
    {"op":"describe","word":"store.shipment"}
    {"op":"describe","word":"store.shipment-lookup-step"}
    {"op":"describe","word":"store.shipment-replacement-step"}
    {"op":"describe","word":"store.with-shipment"}

Also request tests with includeSource=true and examples for each of those ten words. Save the responses as the seed preservation baseline. The tests operation returns source; examples returns names. The seed manifest's example-definition references and object bytes provide exact example source evidence.

Read current sourceHash values from the three describe(type) responses and current revision values from the six owner describe(word) responses. Do not use on-disk object hashes as runtime CAS tokens. Then send task.begin and one atomic define request. Set frontend=flow, syntaxVersion=2, replace=true; source must be the exact patch file contents. The request's expectedTypeSources object must have exactly Scan, ScanInput, ShipmentScanLookup, with the three fresh describe(type) hashes. Its expectedRevisions object must have exactly the six owner names above, with fresh describe(word) revisions.

Require define success, then send test-all and require all 28 cases to pass: 21 persisted tests plus seven additions. Publish with one request:

    {"op":"commit","word":"shipment.find-scan","library":true}

Selecting shipment.find-scan selects the full touched atomic type-evolution group. Runtime commit logic preserves the existing maturity of the other selected owners and checks library coverage for each selected library owner, including shipment.scan-lookup-step. Require commit success and actual test results. Then request task.log, task.commit, and task.log again. Require task.commit success and a final log with nonzero tests and zero failures.

End with the exact one-field host.close transport request; wait for the host and runtime to exit normally. Audit the terminal trace:

    pwsh -NoProfile -File scripts/Audit-SubagentTrialTerminationV2.ps1 -TracePath <absolute-migration-trace>

Capture only after the trace is terminal and audited. Copy work to the new sibling runs/<run-id>/captured/project directory. Record inventories, trace hash, host/runtime exit codes, CURRENT pointer, selected manifest and captured-project hashes. Do not use capture_candidate.py because it writes under frozen efficacy-maintenance-184 outputs. Do not edit trial language source files directly.

## Fresh-process reload and preservation checks

Start a second V2 host with the same accepted CLI, profile, empty capabilities, allowlist, clock, and limits against captured/project; use a new sibling trace. This session is read-only: do not send define, commit, task.begin, or other mutating operations.

Query describe(type) and history(type) for Scan, ScanInput, ShipmentScanLookup, and TrackingReference. The old three histories must include their exact baseline source text and hashes as non-current revisions; TrackingReference history must show its current source. Keep current metadata separate from historical sources.

Query describe(word), tests with includeSource=true, and examples for all ten inventoried owners. Compare pre/post IDs and maturity for all ten. Compare signatures independently: shipment.ingest(Store, ScanInput) and shipment.ingest-batch(Store, List<ScanInput>) are unchanged; shipment.find-scan may change its reference parameter to TrackingReference; the callback and rule must compile against the same snapshot. Owner-CAS revisions may advance even when source body/signature is unchanged.

Preserve the 21 inherited tests and 3 examples, plus the seven requested tests named in the patch (28 tests total). Compare exact source from tests includeSource responses and use the source-audit receipt for wrapper reversal. The examples operation only returns names, so compare the original and captured manifest example-definition hashes and source bytes by following their object references; this is a read-only post-capture audit. Close and audit the reload host normally. Its trace must name captured/project and a new runtime process.

## Independent 18-case oracle

The frozen scorer writes to efficacy-maintenance-184/oracle-draft. Running it in place would alter frozen study outputs. After authorization, prepare its local copy:

    pwsh -NoProfile -File .agentlang/type-evolution-188/readiness-control/prepare-local-oracle.ps1

That script pins the frozen scorer, model and cases hashes and changes only the scorer's evidence-root constant to readiness-control/oracle-results. It saves upstream and local hashes. Then run the copy against the captured persisted project with the same accepted fresh CLI:

    python .agentlang/type-evolution-188/readiness-control/oracle/score_reference.py --arm flow --project .agentlang/type-evolution-188/readiness-control/runs/<run-id>/captured/project --cli <accepted-fresh-AgentLang.Cli.dll> --label <run-id>

Require pass, 18/18 behavior cases, nominal positive construction, rejection of both String and ShipmentId negative controls, and helper signature pass. The scorer checks participant-project unchanged status and writes only into disposable scoring copies under oracle-results. It does not establish task finalization, inherited attachment preservation, library qualification, or reload; retain the separate V2 and source receipts.

## Bounded uncertainties

This recipe is based on current Runtime request shapes, the actual V2 host and auditor, frozen retained-2 protocol data, docs/TYPE-EVOLUTION.md, and the type-diagnostic-186 readiness plan. examples has no includeSource option in the frozen allowlist, so exact example-source preservation requires read-only inspection of captured manifest object references. No protocol or build trial has been run as part of this preparation.

#!/usr/bin/env python3
"""Create a bounded, hash-verified evidence snapshot for runtime milestone 229."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import zipfile
from pathlib import Path
from typing import Any


REPO = Path(__file__).resolve().parents[3]
STUDY = ".agentlang/float-contract-229"
STACK_RUN = ".agentlang/owning-stack-003/verification-08308efe6c824f47a1de61b8ff915d21"
REPORT = "reports/229-canonical-float-text.md"
OUT = Path("reports/evidence/229-canonical-float-text")
ARCHIVE = OUT / "candidate-and-validation.zip"
INDEX = OUT / "index.json"
INNER = "MANIFEST.json"

SOURCE_FILES = [
    "README.md",
    "docs/PRD.md",
    "docs/ROADMAP.md",
    REPORT,
    "scripts/Current-MatchedRenewalFixture.ps1",
    "scripts/Verify-FlowMatchedRenewalFixtures.ps1",
    "scripts/Verify-FlowRenewalAcceptanceGate.ps1",
    "scripts/Verify-FlowRenewalReplay.ps1",
    "scripts/Verify-MatchedRenewalSnapshots.ps1",
    "scripts/Verify-NativeValueStack.ps1",
    "scripts/Verify-OwningMailbox.ps1",
    "src/AgentLang.Core/AgentLang.Core.fsproj",
    "src/AgentLang.Core/FloatText.fs",
    "src/AgentLang.Core/Core.fs",
    "src/AgentLang.Core/FlowSyntax.fs",
    "src/AgentLang.Core/IrFormatting.fs",
    "src/AgentLang.Core/IrInterpreter.fs",
    "src/AgentLang.Core/Source.fs",
    "src/AgentLang.Core/TypedIR.fs",
    "src/AgentLang.Core/ValueInspection.fs",
    "src/AgentLang.Llvm/AgentLang.Llvm.fsproj",
    "src/AgentLang.Llvm/LlvmToolchain.fs",
    "src/AgentLang.Llvm/NativeStackUsage.fs",
    "src/AgentLang.Llvm/OwningStackAot.fs",
    "src/AgentLang.Llvm/native/float_format.h",
    "src/AgentLang.Llvm/native/owning_stack_runtime.c",
    "src/AgentLang.Llvm/native/owning_stack_runtime.h",
    "src/AgentLang.Llvm/native/owning_stack_runtime_test.c",
    "tests/AgentLang.Flow.Tests/AgentLang.Flow.Tests.fsproj",
    "tests/AgentLang.Flow.Tests/Program.fs",
    "tests/AgentLang.Flow.Runtime.Tests/AgentLang.Flow.Runtime.Tests.fsproj",
    "tests/AgentLang.Flow.Runtime.Tests/Program.fs",
    "tests/AgentLang.Acceptance/AgentLang.Acceptance.fsproj",
    "tests/AgentLang.Acceptance/Program.fs",
    "tests/AgentLang.IR.Formatting.Tests/AgentLang.IR.Formatting.Tests.fsproj",
    "tests/AgentLang.IR.Formatting.Tests/Program.fs",
    "tests/AgentLang.IR.Interpreter.Tests/AgentLang.IR.Interpreter.Tests.fsproj",
    "tests/AgentLang.IR.Interpreter.Tests/Program.fs",
    "tests/AgentLang.Llvm.Tests/AgentLang.Llvm.Tests.fsproj",
    "tests/AgentLang.Llvm.Tests/Program.fs",
    "tests/AgentLang.Llvm.Tests/ArenaLifetimeTests.fs",
    "tests/AgentLang.Source.Tests/AgentLang.Source.Tests.fsproj",
    "tests/AgentLang.Source.Tests/Program.fs",
    "tests/AgentLang.ValueInspection.Tests/AgentLang.ValueInspection.Tests.fsproj",
    "tests/AgentLang.ValueInspection.Tests/Program.fs",
    "tests/fixtures/native-conformance/native-value-stack.json",
    "tests/fixtures/native-conformance/float-shortest-oracle.py",
    "tests/fixtures/native-conformance/float-shortest-oracle.json",
]

FOCUSED_RECEIPTS = [
    ".agentlang/reports/flow-matched-renewal-fixtures.json",
    ".agentlang/reports/matched-renewal-snapshots.json",
    ".agentlang/reports/flow-renewal-acceptance-gate.json",
    ".agentlang/reports/flow-renewal-replay.json",
    ".agentlang/float-contract-229/current-fixtures/snapshot-verification/flat-596a986739444a28a38c9c2b7ea34a8a/project/current-fixture-evidence.json",
    ".agentlang/float-contract-229/current-fixtures/snapshot-verification/growing-3a6f09c15e8c438189b627e5ea5457f3/project/current-fixture-evidence.json",
    ".agentlang/float-contract-229/current-fixtures/acceptance-gate/55339324342046e4ae5d2f9218a49525/missing-word/project/current-fixture-evidence.json",
    ".agentlang/float-contract-229/current-fixtures/acceptance-gate/55339324342046e4ae5d2f9218a49525/premium-only-annual-discount/project/current-fixture-evidence.json",
    ".agentlang/float-contract-229/current-fixtures/acceptance-gate/55339324342046e4ae5d2f9218a49525/hardcoded-balance/project/current-fixture-evidence.json",
    ".agentlang/float-contract-229/current-fixtures/replay/3970e8b2b2da4dfcbc705ad96edff0ca/project/current-fixture-evidence.json",
    ".agentlang/owning-mailbox-001/integration-run-b9084dae7140460fa003bef9b8a218a1/integration-evidence.json",
    ".agentlang/refined-mailbox-180/runner/integration-run-b9084dae7140460fa003bef9b8a218a1/integration-evidence.json",
]

FINAL_NATIVE_FRAME_RECEIPTS = [
    ".agentlang/native-validation/tests-b79f5d8d54b84af3b0aa31f083f3b537/native-stack-screen/O0/agentlang-native.su",
    ".agentlang/native-validation/tests-b79f5d8d54b84af3b0aa31f083f3b537/native-stack-screen/O0/agentlang-arena-runtime.su",
    ".agentlang/native-validation/tests-b79f5d8d54b84af3b0aa31f083f3b537/native-stack-screen/O2/agentlang-native.su",
    ".agentlang/native-validation/tests-b79f5d8d54b84af3b0aa31f083f3b537/native-stack-screen/O2/agentlang-arena-runtime.su",
]

SELECTED_NATIVE = [
    ".agentlang/float-contract-229/native/legacy-float-entry-rejection/O0/agentlang-native.ll",
]
for case in (
    "owning-float-aggregate-transport",
    "owning-float-direct-roundtrip",
    "owning-float-to-string-literal",
):
    for opt in ("O0", "O2"):
        SELECTED_NATIVE.append(f".agentlang/float-contract-229/native/{case}/{opt}/owning-stack-native.ll")
        SELECTED_NATIVE.append(f".agentlang/float-contract-229/native/{case}/{opt}/agentlang-native.su")
        SELECTED_NATIVE.append(f".agentlang/float-contract-229/native/{case}/{opt}/agentlang-arena-runtime.su")

TEXT_EVIDENCE_SUFFIXES = {".json", ".log", ".md", ".txt", ".flow"}
EXCLUDED_SUFFIXES = {".dll", ".exe", ".lib", ".obj", ".pdb", ".so", ".dylib", ".cache", ".exp"}

ITEMS: dict[str, tuple[Path | None, bytes | None, str]] = {}
EXCLUDED: dict[str, int] = {}


def sha256(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def add_bytes(member: str, raw: bytes, group: str) -> None:
    name = member.replace("\\", "/")
    if name in ITEMS or name == INNER:
        raise ValueError(f"duplicate archive member: {name}")
    ITEMS[name] = (None, raw, group)


def add_file(path: str | Path, group: str, member: str | None = None) -> None:
    source = Path(path)
    source = source if source.is_absolute() else REPO / source
    if not source.is_file():
        raise FileNotFoundError(source)
    name = (member or source.relative_to(REPO).as_posix()).replace("\\", "/")
    if name in ITEMS or name == INNER:
        raise ValueError(f"duplicate archive member: {name}")
    ITEMS[name] = (source, None, group)


def add_tree_files(root_rel: str, group: str, suffixes: set[str]) -> None:
    root = REPO / root_rel
    if not root.is_dir():
        raise FileNotFoundError(root)
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        rel_parts = path.relative_to(root).parts
        if any(part.lower() in {"build", "bin", "obj", "native-runtime"} for part in rel_parts):
            EXCLUDED["build-or-copied-runtime-directory"] = EXCLUDED.get("build-or-copied-runtime-directory", 0) + 1
            continue
        suffix = path.suffix.lower()
        if suffix in EXCLUDED_SUFFIXES:
            EXCLUDED[f"binary-or-generated:{suffix}"] = EXCLUDED.get(f"binary-or-generated:{suffix}", 0) + 1
            continue
        if suffix not in suffixes:
            EXCLUDED[f"unselected:{suffix or '<no-extension>'}"] = EXCLUDED.get(f"unselected:{suffix or '<no-extension>'}", 0) + 1
            continue
        add_file(path, group)


def read_bytes(source: Path | None, embedded: bytes | None) -> bytes:
    if source is not None:
        return source.read_bytes()
    assert embedded is not None
    return embedded


def member_row(name: str, value: tuple[Path | None, bytes | None, str]) -> dict[str, Any]:
    source, embedded, group = value
    data = read_bytes(source, embedded)
    return {
        "path": name,
        "group": group,
        "bytes": len(data),
        "sha256": sha256(data),
        "source": source.relative_to(REPO).as_posix() if source is not None else "generated",
    }


def prior_reference(study: str) -> dict[str, Any]:
    evidence = REPO / "reports/evidence" / study
    archive_path = evidence / "candidate-and-validation.zip"
    index_path = evidence / "index.json"
    index = json.loads(index_path.read_text(encoding="utf-8"))
    archive_hash = sha256(archive_path.read_bytes())
    advertised_hash = index.get("sha256", index.get("archiveSha256"))
    if archive_hash != advertised_hash:
        raise ValueError(f"{study} archive hash disagrees with its index")
    records = index.get("members", [])
    with zipfile.ZipFile(archive_path, "r") as old_zip:
        names = old_zip.namelist()
        if len(names) != len(set(names)) or len(names) != len(records):
            raise ValueError(f"{study} archive/index member-count mismatch")
        indexed = {}
        for record in records:
            name = record.get("name", record.get("path"))
            if not name or name in indexed:
                raise ValueError(f"{study} index has missing or duplicate member name")
            indexed[name] = record
        if set(names) != set(indexed):
            raise ValueError(f"{study} archive/index membership mismatch")
        for name, record in indexed.items():
            data = old_zip.read(name)
            expected_size = record.get("bytes", record.get("size"))
            expected_hash = record.get("sha256", record.get("hash"))
            if len(data) != expected_size or sha256(data) != expected_hash:
                raise ValueError(f"{study} prior member verification failed: {name}")
    return {
        "study": study,
        "status": index.get("status"),
        "archivePath": (evidence / "candidate-and-validation.zip").relative_to(REPO).as_posix(),
        "archiveBytes": archive_path.stat().st_size,
        "archiveSha256": archive_hash,
        "indexPath": (evidence / "index.json").relative_to(REPO).as_posix(),
        "indexSha256": sha256(index_path.read_bytes()),
        "memberCount": len(records),
        "verified": True,
        "note": "Exact prior failed/candidate evidence is cross-referenced and remains in its original archive; it is not copied into this package.",
    }


def collect_inputs() -> list[dict[str, Any]]:
    for path in SOURCE_FILES:
        group = "report-snapshot" if path == REPORT else "candidate-source-and-tests"
        add_file(path, group)

    study_root = REPO / STUDY
    if not study_root.is_dir():
        raise FileNotFoundError(study_root)
    for path in sorted(study_root.iterdir()):
        if path.is_file():
            add_file(path, "raw-validation-log-and-review")
    add_tree_files(f"{STUDY}/managed", "managed-validation-raw", TEXT_EVIDENCE_SUFFIXES)
    add_tree_files(f"{STUDY}/native", "native-validation-raw", TEXT_EVIDENCE_SUFFIXES)
    add_file(f"{STUDY}/current-fixtures/review.md", "current-fixture-review")
    for path in FOCUSED_RECEIPTS:
        add_file(path, "focused-verifier-and-current-fixture-receipt")
    for path in FINAL_NATIVE_FRAME_RECEIPTS:
        add_file(path, "final-native-verifier-frame-receipt")
    for path in SELECTED_NATIVE:
        add_file(path, "selected-native-llvm-and-frame-receipts")

    stack_root = REPO / STACK_RUN
    if not stack_root.is_dir():
        raise FileNotFoundError(stack_root)
    for path in sorted(stack_root.iterdir()):
        if path.is_file() and path.suffix.lower() in TEXT_EVIDENCE_SUFFIXES:
            add_file(path, "passed-native-value-stack-terminal-evidence")
    # Do not traverse compiler-temp, native-output or dotnet-artifacts here.

    prior = {
        "224": prior_reference("224-native-float-format-findings"),
        "225": prior_reference("225-native-machine-frame-screening"),
    }
    add_bytes("evidence/prior-candidate-cross-references.json",
              (json.dumps(prior, indent=2, sort_keys=True) + "\n").encode("utf-8"),
              "prior-failed-evidence-cross-references")
    helper = Path(__file__).resolve()
    add_file(helper, "archive-helper", "evidence/package-helper.py")
    return [member_row(name, ITEMS[name]) for name in sorted(ITEMS)]


def package() -> dict[str, Any]:
    if not (REPO / REPORT).is_file():
        raise FileNotFoundError(f"final report is not present: {REPORT}")
    records = collect_inputs()
    prior = json.loads(ITEMS["evidence/prior-candidate-cross-references.json"][1].decode("utf-8"))
    manifest = {
        "format": "canonical-float-text-runtime-milestone-229-v1",
        "reportSnapshot": REPORT,
        "priorEvidence": prior,
        "sourcePins": [
            {"path": row["path"], "bytes": row["bytes"], "sha256": row["sha256"]}
            for row in records
            if row["group"] == "candidate-source-and-tests"
        ],
        "members": records,
        "exclusions": {
            "notTraversed": [
                f"{STUDY}/native/build/**",
                f"{STUDY}/current-fixtures/**/project/** (only the six final current-fixture-evidence.json receipts are retained)",
                ".agentlang/native-validation/run-5d98faf67c4b45d8ad9186f73d489515/** (fresh build artifacts; summary is retained in the final native host log)",
                ".agentlang/native-validation/tests-b79f5d8d54b84af3b0aa31f083f3b537/** (binaries and generated LLVM omitted; only four native-stack-screen .su receipts are retained)",
                f"{STACK_RUN}/compiler-temp/**",
                f"{STACK_RUN}/dotnet-artifacts/**",
                f"{STACK_RUN}/native-output/**",
                "reports/evidence/224-native-float-format-findings/** (cross-reference only)",
                "reports/evidence/225-native-machine-frame-screening/** (cross-reference only)",
            ],
            "filteredCounts": dict(sorted(EXCLUDED.items())),
            "policy": "Include current source/docs/tests with explicit source pins, raw text/JSON validation receipts including failed and successful full-gate and native-final host logs, the four focused verifier JSONs, only the six final current-fixture-evidence.json receipts, OwningMailbox and refinedMailbox integration receipts, four frame receipts from the passing final native verifier, the current-fixture review, the Python oracle fixture, root terminal value-stack evidence, and only selected focused LLVM .ll/.su files. Exclude runtime/build binaries, build/obj trees, duplicate copied native-runtime source, generated current-fixture project copies, other final-verifier generated output, and large generated assembly outputs.",
        },
    }
    inner = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode("utf-8")
    all_items = dict(ITEMS)
    all_items[INNER] = (None, inner, "archive-member-manifest")
    all_records = [member_row(name, all_items[name]) for name in sorted(all_items)]

    out_abs = REPO / OUT
    out_abs.mkdir(parents=True, exist_ok=True)
    archive_abs = REPO / ARCHIVE
    index_abs = REPO / INDEX
    temporary = archive_abs.with_suffix(".zip.tmp")
    with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as out_zip:
        for name in sorted(all_items):
            source, embedded, _ = all_items[name]
            data = read_bytes(source, embedded)
            info = zipfile.ZipInfo(name, date_time=(2026, 10, 11, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            out_zip.writestr(info, data)
    os.replace(temporary, archive_abs)

    with zipfile.ZipFile(archive_abs, "r") as out_zip:
        names = out_zip.namelist()
        if len(names) != len(set(names)) or set(names) != {row["path"] for row in all_records}:
            raise RuntimeError("archive membership mismatch")
        for row in all_records:
            data = out_zip.read(row["path"])
            if len(data) != row["bytes"] or sha256(data) != row["sha256"]:
                raise RuntimeError(f"archive member mismatch: {row['path']}")
        if json.loads(out_zip.read(INNER)) != manifest:
            raise RuntimeError("embedded manifest mismatch")

    changed = []
    for row in records:
        source, embedded, _ = ITEMS[row["path"]]
        data = read_bytes(source, embedded)
        if len(data) != row["bytes"] or sha256(data) != row["sha256"]:
            changed.append(row["path"])
    if changed:
        raise RuntimeError("source changed during packaging: " + ", ".join(changed[:10]))

    index = {
        **manifest,
        "zip": ARCHIVE.as_posix(),
        "sha256": sha256(archive_abs.read_bytes()),
        "archiveBytes": archive_abs.stat().st_size,
        "memberCount": len(all_records),
        "verifiedAllMembers": True,
        "sourceRecheck": "unchanged",
        "members": all_records,
    }
    index_abs.write_text(json.dumps(index, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    with zipfile.ZipFile(archive_abs, "r") as out_zip:
        for row in index["members"]:
            data = out_zip.read(row["path"])
            if len(data) != row["bytes"] or sha256(data) != row["sha256"]:
                raise RuntimeError(f"final index verification failed: {row['path']}")
    return {
        "zip": ARCHIVE.as_posix(),
        "index": INDEX.as_posix(),
        "sha256": index["sha256"],
        "archiveBytes": index["archiveBytes"],
        "members": len(all_records),
        "verifiedAllMembers": True,
        "excludedCounts": index["exclusions"]["filteredCounts"],
        "priorArchives": {name: ref["archiveSha256"] for name, ref in prior.items()},
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seal", action="store_true", help="write the candidate archive after coordinator readiness confirmation")
    args = parser.parse_args()
    if not args.seal:
        parser.error("pass --seal only after the coordinator confirms all gates and report readiness")
    print(json.dumps(package(), indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# Float snapshot failure investigation

Read-only inspection of the frozen Growing snapshot and the three failing consumers. No code, verifier, snapshot, or historical evidence was edited; actor trial/context files were not opened.

## Finding

The Growing failure is an old aggregate-export spelling mismatch. The authoritative seed `experiments/AgentLang.SubagentTrials/matched-renewal-001/fixtures/flow/growing.agent` spells integral Float literals with a decimal (`80.0`, `100.0`, `250.0`, and expected `80.0`, `90.0`, `225.0`, `100.0`). The immutable manifest-backed test objects retain those spellings; for example `snapshots/growing/store/objects/148337b3c5a1071a9a726219ed40eb93ff810f95bb039beb82150cb5285cbdb8.agent` contains `balance = 100.0` and `=> 90.0`, and the stored word definition retains `float::multiply(balance, 0.9)`.

By contrast, the frozen Growing `projectSource` object `snapshots/growing/store/objects/ec5743bfaaeaf42cd84f671f91b73260b1b79706e86345112694910b8620a306.agent` contains the same integral spellings as `80`, `100`, `250`, `90`, `225`, and so on. The non-integral `0.9` is unchanged. Manifest `480feeaec8a8ad5d860349890bbbe151b2345f7c746f1400e926da68eb181521` is FormatVersion 3 and points to this aggregate plus the unmodified Flow/1 source objects. Flat has no authored Float-bearing tests and its historic restore/load path passes.

`Runtime.fs` builds `exportText` from the manifest-backed objects at `validateStoredProject` and requires byte-for-byte equality with the stored aggregate for FormatVersion >= 2 (`Runtime.fs:2642-2657`). That is where this fails, before the stored aggregate is interpreted. `FlowParser.fs:729-732` parses an integer token as `LInt` before trying `Double.TryParse` for `LFloat`; therefore changing the verifier to parse/canonicalize the old aggregate as though its bare `100` were the same AST literal as manifest `100.0` would erase a real literal-type distinction. This is not evidence that the authoritative source objects changed value or type: they still parse as Float. The safe fix is to generate disposable current-format snapshots through Runtime and keep the integrity check strict.

The three reported gates all restore this exact Growing bundle and fail at CLI construction, before their intended assertions: `Verify-MatchedRenewalSnapshots.ps1`, `Verify-FlowRenewalAcceptanceGate.ps1`, and `Verify-FlowRenewalReplay.ps1`. The host log records the same `STORAGE_PROJECT_MISMATCH` at `Runtime.fs:2657` for all three.

## Smallest safe fixture plan

Reuse the staging/commit/reload sequence already in `scripts/Verify-FlowMatchedRenewalFixtures.ps1` (`Get-ProjectProfile`, approximately lines 79-150) as one shared current-fixture helper, or factor that sequence into a small helper consumed by that verifier and the three failing gates. The helper should:

1. Read only the authoritative Flow seed `fixtures/flow/growing.agent` and verify its SHA-256 against `snapshots/growing/bundle.json:seedSourceSha256`.
2. Create a new, isolated project; submit the seed with CLI `define` (`frontend=flow`, current default Flow/1), commit `Customer`, `Subscription`, then `customer.premium?` and `customer.discounted-balance` as library words, and call `snapshot.save`.
3. Capture the generated word IDs and manifest hash from Runtime responses. In a separate CLI process, call `snapshot.load`, `words`, and `test-all`; verify the saved hash round-trips, both identities remain unchanged, the two expected word names/signatures and two records remain, exactly the existing seven test names run, all seven pass, and `customer.renewal-balance` is absent.

This follows existing app APIs; no direct manifest/object editing or `Storage.commit` fixture handcrafting is needed. Runtime `define` assigns new word IDs with `Guid.NewGuid()` (`Runtime.fs:339`), so a fresh CLI-built baseline cannot retain the frozen literal IDs. Keep the historic ID/hash checks on the frozen bundle itself, and make the runtime round-trip assertion compare each generated ID with that same run's captured baseline ID. This preserves the stable-identity guarantee without pretending newly generated IDs equal the historical ones.

Keep `Restore-MatchedRenewalSnapshot.ps1` byte-exact. For the snapshot gate, retain its bundle hash/size validation, exact historic manifest-hash check, “existing destination refused” check, and copied-bundle `CURRENT` tamper rejection; do not launch the current Runtime on the old Growing aggregate. Use the generated fixture for the runtime load, identity, and seven-test assertions. The acceptance-gate and replay scripts should use the same generated Growing fixture for their baseline. In replay, source the expected seed IDs from the helper's capture, then continue asserting they survive the replay and task commit. Leave the seven accepted-case expectations and existing 15-test replay counts unchanged.

`Storage.commit` already requires the provided ProjectSource bytes to equal `exportText` (`Storage.fs:1652-1657`), and Runtime produces both from its current `sourceFor` output before publishing. `FlowSource.renderLiteral` currently routes `LFloat` through `FloatText.format` (`FlowSyntax.fs:485-488`). Using normal `define`/`commit`/`snapshot.save` therefore creates a coherent current export, manifest, and source-object graph; `snapshot.load` exercises the unchanged strict validation. The standalone `format` operation only returns formatted source for inspection (`Runtime.fs:5990-6013`); it does not update a durable project, so it is not a fixture-repair mechanism.

There is no existing negative test found for Runtime's `STORAGE_PROJECT_MISMATCH` on a modified derived `dictionary.agent`, nor for Storage's `STORAGE_EXPORT_MISMATCH` branch. Existing negatives cover changed bundle bytes (`Verify-MatchedRenewalSnapshots.ps1`) and content-addressed object tampering/hash rejection (`AgentLang.Storage.Tests`). They are useful and should remain, but they do not test this exact aggregate-source check. If a focused negative is wanted, copy a generated current fixture, alter only its derived export's `100.0` to `100`, then assert a fresh CLI fails with `STORAGE_PROJECT_MISMATCH`; leave immutable source objects and manifest untouched.

## Affected scripts and validation

The focused changes would be one shared fixture helper (factored from `Verify-FlowMatchedRenewalFixtures.ps1`) plus the three consumers: `Verify-MatchedRenewalSnapshots.ps1`, `Verify-FlowRenewalAcceptanceGate.ps1`, and `Verify-FlowRenewalReplay.ps1`. `Restore-MatchedRenewalSnapshot.ps1`, `Runtime.fs`, `Storage.fs`, the frozen bundles, accepted trial artifacts, and historical evidence need no edits.

After implementation, build the CLI and run the existing fixture verifier and all three focused gates against that exact Release DLL, followed by the repository's full-validation command. Example focused invocations:

```powershell
dotnet build src/AgentLang.Cli/AgentLang.Cli.fsproj -c Release
pwsh -NoProfile -File scripts/Verify-FlowMatchedRenewalFixtures.ps1 -CliDll src/AgentLang.Cli/bin/Release/net9.0/AgentLang.Cli.dll
pwsh -NoProfile -File scripts/Verify-MatchedRenewalSnapshots.ps1 -CliDll src/AgentLang.Cli/bin/Release/net9.0/AgentLang.Cli.dll
pwsh -NoProfile -File scripts/Verify-FlowRenewalAcceptanceGate.ps1 -CliDll src/AgentLang.Cli/bin/Release/net9.0/AgentLang.Cli.dll
pwsh -NoProfile -File scripts/Verify-FlowRenewalReplay.ps1 -CliDll src/AgentLang.Cli/bin/Release/net9.0/AgentLang.Cli.dll
```

No tests or commands were run during this read-only investigation.

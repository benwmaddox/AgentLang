# Current matched-renewal fixture review

Read-only source review, 2026-10-11. No CLI/build run while the shared validation session owns it.

## Findings and resolution

1. **Resolved:** The first draft of `scripts/Verify-MatchedRenewalSnapshots.ps1` checked `$manifest.manifestHash`, but frozen manifest JSON has no such member. The worker changed this to compare the manifest file's SHA-256 with the pinned content hash.
2. **Resolved:** The first draft of `scripts/Current-MatchedRenewalFixture.ps1` did not explicitly compare save and load manifest identities. The worker now captures the named snapshot metadata and committed `CURRENT` pointer after seed generation and compares both with `snapshot.load`'s hash and name. Runtime's `snapshot.save` response has no hash.

## Checks retained in the inspected diff

- `Runtime.fs` and storage code are untouched by the fixture patch; the strict `STORAGE_PROJECT_MISMATCH` path remains in `validateStoredProject`.
- The snapshot verifier pins both historical `bundle.json` SHA-256 values, manifest hashes, and the two Growing word IDs, and the restore helper still verifies frozen file sizes and SHA-256 values before copying. It retains the existing-destination and modified `CURRENT` rejection checks.
- The helper checks the authoritative seed hash, exact seven Growing test names and all passing results, generated word IDs across a fresh-process reload, two record fields, both word signatures, and absence of the renewal solution.
- Replay still checks fifteen passing tests before and after commit and the generated seed IDs through replay.

Static final pass found no additional fixture-specific regression or path issue. Focused verifier validation and full `Validate.ps1` remain with the main validation session; this reviewer did not run the shared CLI.

%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [7 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 1, i32 1, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 2, i32 2, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 4, i32 5, i32 0, i32 2, i32 16, i32 16, i32 16, i32 16, i32 0 }, %AlOwningTypeDescriptor { i32 9, i32 6, i32 2, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 9, i32 9, i32 2, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 7, i32 10, i32 2, i32 2, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 2 }, %AlOwningTypeDescriptor { i32 8, i32 11, i32 4, i32 2, i32 16, i32 16, i32 16, i32 16, i32 2 }], align 4
@al_owning_fields = private constant [6 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 4, i32 0, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 1, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 4, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 4294967295, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 4, i32 8, i32 0, i32 0 }, %AlOwningFieldDescriptor { i32 0, i32 8, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 4, ptr @al_owning_types, i32 7, ptr @al_owning_fields, i32 6 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_locate_sum_case(ptr, ptr, i32, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_float_format(ptr, i64, ptr, ptr, i32)
declare i32 @al_owning_float_string_write(ptr, i32, i32, ptr, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal_typed(ptr, ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %local.active.2 = alloca i1, align 1
  %local.offset.3 = alloca i32, align 4
  %local.extent.4 = alloca i32, align 4
  %local.payload.5 = alloca i32, align 4
  %local.owner.end.6 = alloca i32, align 4
  %local.type.7 = alloca i32, align 4
  %call.arguments.150 = alloca [1 x %AlOwningDescriptor], align 4
  %call.results.161 = alloca [1 x %AlOwningDescriptor], align 4
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %context.field.10 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.11 = load i32, ptr %context.field.10, align 4
  %context.field.12 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.13 = load i32, ptr %context.field.12, align 4
  %context.field.14 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.15 = load i32, ptr %context.field.14, align 4
  %frame.entered.16 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.17 = icmp eq i32 %frame.entered.16, 0
  br i1 %frame.enter.ok.17, label %frame.enter.continue.18, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.18:
  %descriptor.element.19 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 0
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 1
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %descriptor.field.24 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 2
  %descriptor.value.25 = load i32, ptr %descriptor.field.24, align 4
  %descriptor.field.26 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 3
  %descriptor.value.27 = load i32, ptr %descriptor.field.26, align 4
  %descriptor.field.28 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 4
  %descriptor.value.29 = load i32, ptr %descriptor.field.28, align 4
  %argument.type.valid.30 = icmp eq i32 %descriptor.value.21, 9
  br i1 %argument.type.valid.30, label %argument.type.ok.31, label %frame.failure.0
argument.type.ok.31:
  %context.field.32 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.33 = load i32, ptr %context.field.32, align 4
  %stack.sub.36 = sub i32 %descriptor.value.29, %descriptor.value.23
  %descriptor.owner.inside.34 = icmp ule i32 %descriptor.value.29, %context.value.33
  %descriptor.offset.inside.35 = icmp ule i32 %descriptor.value.23, %descriptor.value.29
  %descriptor.extent.inside.37 = icmp ule i32 %descriptor.value.25, %stack.sub.36
  %descriptor.payload.inside.38 = icmp ule i32 %descriptor.value.27, %descriptor.value.25
  %descriptor.owner.offset.valid.39 = and i1 %descriptor.owner.inside.34, %descriptor.offset.inside.35
  %descriptor.range.inside.41 = and i1 %descriptor.owner.offset.valid.39, %descriptor.extent.inside.37
  %descriptor.range.valid.40 = and i1 %descriptor.range.inside.41, %descriptor.payload.inside.38
  %descriptor.type.valid.42 = icmp eq i32 9, 9
  %descriptor.valid.43 = and i1 %descriptor.range.valid.40, %descriptor.type.valid.42
  br i1 %descriptor.valid.43, label %descriptor.valid.44, label %descriptor.invalid.45
descriptor.invalid.45:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.44:
  %descriptor.initialized.status.46 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.23, i32 %descriptor.value.25)
  %helper.ok.47 = icmp eq i32 %descriptor.initialized.status.46, 0
  br i1 %helper.ok.47, label %helper.continue.48, label %frame.failure.0
helper.continue.48:
  %step.status.49 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.50 = icmp eq i32 %step.status.49, 0
  br i1 %helper.ok.50, label %helper.continue.51, label %frame.failure.0
helper.continue.51:
  store i1 true, ptr %local.active.2, align 1
  store i32 %descriptor.value.23, ptr %local.offset.3, align 4
  store i32 %descriptor.value.25, ptr %local.extent.4, align 4
  store i32 %descriptor.value.27, ptr %local.payload.5, align 4
  store i32 %descriptor.value.29, ptr %local.owner.end.6, align 4
  store i32 9, ptr %local.type.7, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 9, i32 %descriptor.value.23, i32 20, i32 %descriptor.value.27, i32 %descriptor.value.29, i32 %descriptor.value.25)
  %context.field.52 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.53 = load i32, ptr %context.field.52, align 4
  %runtime.ok.54 = icmp eq i32 %context.value.53, 0
  br i1 %runtime.ok.54, label %runtime.continue.55, label %frame.failure.0
runtime.continue.55:
  %local.is.active.56 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.56, label %local.descriptor.active.57, label %local.descriptor.inactive.58
local.descriptor.active.57:
  %local.check.offset.60 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.61 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.62 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.63 = load i32, ptr %local.owner.end.6, align 4
  %context.field.64 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.65 = load i32, ptr %context.field.64, align 4
  %stack.sub.68 = sub i32 %local.check.owner.end.63, %local.check.offset.60
  %descriptor.owner.inside.66 = icmp ule i32 %local.check.owner.end.63, %context.value.65
  %descriptor.offset.inside.67 = icmp ule i32 %local.check.offset.60, %local.check.owner.end.63
  %descriptor.extent.inside.69 = icmp ule i32 %local.check.extent.61, %stack.sub.68
  %descriptor.payload.inside.70 = icmp ule i32 %local.check.payload.62, %local.check.extent.61
  %descriptor.owner.offset.valid.71 = and i1 %descriptor.owner.inside.66, %descriptor.offset.inside.67
  %descriptor.range.inside.73 = and i1 %descriptor.owner.offset.valid.71, %descriptor.extent.inside.69
  %descriptor.range.valid.72 = and i1 %descriptor.range.inside.73, %descriptor.payload.inside.70
  br i1 %descriptor.range.valid.72, label %descriptor.valid.74, label %descriptor.invalid.75
descriptor.invalid.75:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.74:
  %descriptor.initialized.status.76 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.60, i32 %local.check.extent.61)
  %helper.ok.77 = icmp eq i32 %descriptor.initialized.status.76, 0
  br i1 %helper.ok.77, label %helper.continue.78, label %frame.failure.0
helper.continue.78:
  br label %local.descriptor.checked.59
local.descriptor.inactive.58:
  br label %local.descriptor.checked.59
local.descriptor.checked.59:
  %step.status.79 = call i32 @al_owning_charge_step(ptr %ctx, i32 2)
  %helper.ok.80 = icmp eq i32 %step.status.79, 0
  br i1 %helper.ok.80, label %helper.continue.81, label %frame.failure.0
helper.continue.81:
  %local.resolved.offset.82 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.83 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.84 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.85 = load i32, ptr %local.owner.end.6, align 4
  %context.field.86 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.87 = load i32, ptr %context.field.86, align 4
  %stack.sub.90 = sub i32 %local.resolved.owner.end.85, %local.resolved.offset.82
  %descriptor.owner.inside.88 = icmp ule i32 %local.resolved.owner.end.85, %context.value.87
  %descriptor.offset.inside.89 = icmp ule i32 %local.resolved.offset.82, %local.resolved.owner.end.85
  %descriptor.extent.inside.91 = icmp ule i32 %local.resolved.extent.83, %stack.sub.90
  %descriptor.payload.inside.92 = icmp ule i32 %local.resolved.payload.84, %local.resolved.extent.83
  %descriptor.owner.offset.valid.93 = and i1 %descriptor.owner.inside.88, %descriptor.offset.inside.89
  %descriptor.range.inside.95 = and i1 %descriptor.owner.offset.valid.93, %descriptor.extent.inside.91
  %descriptor.range.valid.94 = and i1 %descriptor.range.inside.95, %descriptor.payload.inside.92
  %descriptor.type.valid.96 = icmp eq i32 9, 9
  %descriptor.valid.97 = and i1 %descriptor.range.valid.94, %descriptor.type.valid.96
  br i1 %descriptor.valid.97, label %descriptor.valid.98, label %descriptor.invalid.99
descriptor.invalid.99:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.98:
  %descriptor.initialized.status.100 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.82, i32 %local.resolved.extent.83)
  %helper.ok.101 = icmp eq i32 %descriptor.initialized.status.100, 0
  br i1 %helper.ok.101, label %helper.continue.102, label %frame.failure.0
helper.continue.102:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 9, i32 %local.resolved.offset.82, i32 20, i32 %local.resolved.payload.84, i32 %local.resolved.owner.end.85, i32 %local.resolved.extent.83)
  %context.field.103 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.104 = load i32, ptr %context.field.103, align 4
  %runtime.ok.105 = icmp eq i32 %context.value.104, 0
  br i1 %runtime.ok.105, label %runtime.continue.106, label %frame.failure.0
runtime.continue.106:
  %context.field.107 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.108 = load i32, ptr %context.field.107, align 4
  %stack.sub.111 = sub i32 %local.resolved.owner.end.85, %local.resolved.offset.82
  %descriptor.owner.inside.109 = icmp ule i32 %local.resolved.owner.end.85, %context.value.108
  %descriptor.offset.inside.110 = icmp ule i32 %local.resolved.offset.82, %local.resolved.owner.end.85
  %descriptor.extent.inside.112 = icmp ule i32 %local.resolved.extent.83, %stack.sub.111
  %descriptor.payload.inside.113 = icmp ule i32 %local.resolved.payload.84, %local.resolved.extent.83
  %descriptor.owner.offset.valid.114 = and i1 %descriptor.owner.inside.109, %descriptor.offset.inside.110
  %descriptor.range.inside.116 = and i1 %descriptor.owner.offset.valid.114, %descriptor.extent.inside.112
  %descriptor.range.valid.115 = and i1 %descriptor.range.inside.116, %descriptor.payload.inside.113
  %descriptor.type.valid.117 = icmp eq i32 9, 9
  %descriptor.valid.118 = and i1 %descriptor.range.valid.115, %descriptor.type.valid.117
  br i1 %descriptor.valid.118, label %descriptor.valid.119, label %descriptor.invalid.120
descriptor.invalid.120:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.119:
  %descriptor.initialized.status.121 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.82, i32 %local.resolved.extent.83)
  %helper.ok.122 = icmp eq i32 %descriptor.initialized.status.121, 0
  br i1 %helper.ok.122, label %helper.continue.123, label %frame.failure.0
helper.continue.123:
  %local.is.active.124 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.124, label %local.descriptor.active.125, label %local.descriptor.inactive.126
local.descriptor.active.125:
  %local.check.offset.128 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.129 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.130 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.131 = load i32, ptr %local.owner.end.6, align 4
  %context.field.132 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.133 = load i32, ptr %context.field.132, align 4
  %stack.sub.136 = sub i32 %local.check.owner.end.131, %local.check.offset.128
  %descriptor.owner.inside.134 = icmp ule i32 %local.check.owner.end.131, %context.value.133
  %descriptor.offset.inside.135 = icmp ule i32 %local.check.offset.128, %local.check.owner.end.131
  %descriptor.extent.inside.137 = icmp ule i32 %local.check.extent.129, %stack.sub.136
  %descriptor.payload.inside.138 = icmp ule i32 %local.check.payload.130, %local.check.extent.129
  %descriptor.owner.offset.valid.139 = and i1 %descriptor.owner.inside.134, %descriptor.offset.inside.135
  %descriptor.range.inside.141 = and i1 %descriptor.owner.offset.valid.139, %descriptor.extent.inside.137
  %descriptor.range.valid.140 = and i1 %descriptor.range.inside.141, %descriptor.payload.inside.138
  br i1 %descriptor.range.valid.140, label %descriptor.valid.142, label %descriptor.invalid.143
descriptor.invalid.143:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.142:
  %descriptor.initialized.status.144 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.128, i32 %local.check.extent.129)
  %helper.ok.145 = icmp eq i32 %descriptor.initialized.status.144, 0
  br i1 %helper.ok.145, label %helper.continue.146, label %frame.failure.0
helper.continue.146:
  br label %local.descriptor.checked.127
local.descriptor.inactive.126:
  br label %local.descriptor.checked.127
local.descriptor.checked.127:
  %step.status.147 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.148 = icmp eq i32 %step.status.147, 0
  br i1 %helper.ok.148, label %helper.continue.149, label %frame.failure.0
helper.continue.149:
  %descriptor.element.151 = getelementptr inbounds %AlOwningDescriptor, ptr %call.arguments.150, i32 0
  %descriptor.field.152 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.151, i32 0, i32 0
  store i32 9, ptr %descriptor.field.152, align 4
  %descriptor.field.153 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.151, i32 0, i32 1
  store i32 %local.resolved.offset.82, ptr %descriptor.field.153, align 4
  %descriptor.field.154 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.151, i32 0, i32 2
  store i32 %local.resolved.extent.83, ptr %descriptor.field.154, align 4
  %descriptor.field.155 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.151, i32 0, i32 3
  store i32 %local.resolved.payload.84, ptr %descriptor.field.155, align 4
  %descriptor.field.156 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.151, i32 0, i32 4
  store i32 %local.resolved.owner.end.85, ptr %descriptor.field.156, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 9, i32 %local.resolved.offset.82, i32 20, i32 %local.resolved.payload.84, i32 %local.resolved.owner.end.85, i32 %local.resolved.extent.83)
  %context.field.157 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.158 = load i32, ptr %context.field.157, align 4
  %runtime.ok.159 = icmp eq i32 %context.value.158, 0
  br i1 %runtime.ok.159, label %runtime.continue.160, label %frame.failure.0
runtime.continue.160:
  %callee.status.162 = call i32 @agentlang_word_0000(ptr %ctx, ptr %call.arguments.150, ptr %call.results.161, i32 4)
  %helper.ok.163 = icmp eq i32 %callee.status.162, 0
  br i1 %helper.ok.163, label %helper.continue.164, label %frame.failure.0
helper.continue.164:
  %descriptor.element.165 = getelementptr inbounds %AlOwningDescriptor, ptr %call.results.161, i32 0
  %descriptor.field.166 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.165, i32 0, i32 0
  %descriptor.value.167 = load i32, ptr %descriptor.field.166, align 4
  %descriptor.field.168 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.165, i32 0, i32 1
  %descriptor.value.169 = load i32, ptr %descriptor.field.168, align 4
  %descriptor.field.170 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.165, i32 0, i32 2
  %descriptor.value.171 = load i32, ptr %descriptor.field.170, align 4
  %descriptor.field.172 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.165, i32 0, i32 3
  %descriptor.value.173 = load i32, ptr %descriptor.field.172, align 4
  %descriptor.field.174 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.165, i32 0, i32 4
  %descriptor.value.175 = load i32, ptr %descriptor.field.174, align 4
  %callee.result.type.valid.176 = icmp eq i32 %descriptor.value.167, 9
  br i1 %callee.result.type.valid.176, label %callee.result.type.ok.177, label %frame.failure.0
callee.result.type.ok.177:
  %context.field.178 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.179 = load i32, ptr %context.field.178, align 4
  %stack.sub.182 = sub i32 %descriptor.value.175, %descriptor.value.169
  %descriptor.owner.inside.180 = icmp ule i32 %descriptor.value.175, %context.value.179
  %descriptor.offset.inside.181 = icmp ule i32 %descriptor.value.169, %descriptor.value.175
  %descriptor.extent.inside.183 = icmp ule i32 %descriptor.value.171, %stack.sub.182
  %descriptor.payload.inside.184 = icmp ule i32 %descriptor.value.173, %descriptor.value.171
  %descriptor.owner.offset.valid.185 = and i1 %descriptor.owner.inside.180, %descriptor.offset.inside.181
  %descriptor.range.inside.187 = and i1 %descriptor.owner.offset.valid.185, %descriptor.extent.inside.183
  %descriptor.range.valid.186 = and i1 %descriptor.range.inside.187, %descriptor.payload.inside.184
  %descriptor.type.valid.188 = icmp eq i32 9, 9
  %descriptor.valid.189 = and i1 %descriptor.range.valid.186, %descriptor.type.valid.188
  br i1 %descriptor.valid.189, label %descriptor.valid.190, label %descriptor.invalid.191
descriptor.invalid.191:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.190:
  %descriptor.initialized.status.192 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.169, i32 %descriptor.value.171)
  %helper.ok.193 = icmp eq i32 %descriptor.initialized.status.192, 0
  br i1 %helper.ok.193, label %helper.continue.194, label %frame.failure.0
helper.continue.194:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 9, i32 %descriptor.value.169, i32 20, i32 %descriptor.value.173, i32 %descriptor.value.175, i32 %descriptor.value.171)
  %context.field.195 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.196 = load i32, ptr %context.field.195, align 4
  %runtime.ok.197 = icmp eq i32 %context.value.196, 0
  br i1 %runtime.ok.197, label %runtime.continue.198, label %frame.failure.0
runtime.continue.198:
  %context.field.199 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.200 = load i32, ptr %context.field.199, align 4
  %stack.sub.203 = sub i32 %descriptor.value.175, %descriptor.value.169
  %descriptor.owner.inside.201 = icmp ule i32 %descriptor.value.175, %context.value.200
  %descriptor.offset.inside.202 = icmp ule i32 %descriptor.value.169, %descriptor.value.175
  %descriptor.extent.inside.204 = icmp ule i32 %descriptor.value.171, %stack.sub.203
  %descriptor.payload.inside.205 = icmp ule i32 %descriptor.value.173, %descriptor.value.171
  %descriptor.owner.offset.valid.206 = and i1 %descriptor.owner.inside.201, %descriptor.offset.inside.202
  %descriptor.range.inside.208 = and i1 %descriptor.owner.offset.valid.206, %descriptor.extent.inside.204
  %descriptor.range.valid.207 = and i1 %descriptor.range.inside.208, %descriptor.payload.inside.205
  %descriptor.type.valid.209 = icmp eq i32 9, 9
  %descriptor.valid.210 = and i1 %descriptor.range.valid.207, %descriptor.type.valid.209
  br i1 %descriptor.valid.210, label %descriptor.valid.211, label %descriptor.invalid.212
descriptor.invalid.212:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.211:
  %descriptor.initialized.status.213 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.169, i32 %descriptor.value.171)
  %helper.ok.214 = icmp eq i32 %descriptor.initialized.status.213, 0
  br i1 %helper.ok.214, label %helper.continue.215, label %frame.failure.0
helper.continue.215:
  %local.is.active.216 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.216, label %local.descriptor.active.217, label %local.descriptor.inactive.218
local.descriptor.active.217:
  %local.check.offset.220 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.221 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.222 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.223 = load i32, ptr %local.owner.end.6, align 4
  %context.field.224 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.225 = load i32, ptr %context.field.224, align 4
  %stack.sub.228 = sub i32 %local.check.owner.end.223, %local.check.offset.220
  %descriptor.owner.inside.226 = icmp ule i32 %local.check.owner.end.223, %context.value.225
  %descriptor.offset.inside.227 = icmp ule i32 %local.check.offset.220, %local.check.owner.end.223
  %descriptor.extent.inside.229 = icmp ule i32 %local.check.extent.221, %stack.sub.228
  %descriptor.payload.inside.230 = icmp ule i32 %local.check.payload.222, %local.check.extent.221
  %descriptor.owner.offset.valid.231 = and i1 %descriptor.owner.inside.226, %descriptor.offset.inside.227
  %descriptor.range.inside.233 = and i1 %descriptor.owner.offset.valid.231, %descriptor.extent.inside.229
  %descriptor.range.valid.232 = and i1 %descriptor.range.inside.233, %descriptor.payload.inside.230
  br i1 %descriptor.range.valid.232, label %descriptor.valid.234, label %descriptor.invalid.235
descriptor.invalid.235:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.234:
  %descriptor.initialized.status.236 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.220, i32 %local.check.extent.221)
  %helper.ok.237 = icmp eq i32 %descriptor.initialized.status.236, 0
  br i1 %helper.ok.237, label %helper.continue.238, label %frame.failure.0
helper.continue.238:
  br label %local.descriptor.checked.219
local.descriptor.inactive.218:
  br label %local.descriptor.checked.219
local.descriptor.checked.219:
  %step.status.239 = call i32 @al_owning_charge_step(ptr %ctx, i32 5)
  %helper.ok.240 = icmp eq i32 %step.status.239, 0
  br i1 %helper.ok.240, label %helper.continue.241, label %frame.failure.0
helper.continue.241:
  %local.resolved.offset.242 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.243 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.244 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.245 = load i32, ptr %local.owner.end.6, align 4
  %context.field.246 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.247 = load i32, ptr %context.field.246, align 4
  %stack.sub.250 = sub i32 %local.resolved.owner.end.245, %local.resolved.offset.242
  %descriptor.owner.inside.248 = icmp ule i32 %local.resolved.owner.end.245, %context.value.247
  %descriptor.offset.inside.249 = icmp ule i32 %local.resolved.offset.242, %local.resolved.owner.end.245
  %descriptor.extent.inside.251 = icmp ule i32 %local.resolved.extent.243, %stack.sub.250
  %descriptor.payload.inside.252 = icmp ule i32 %local.resolved.payload.244, %local.resolved.extent.243
  %descriptor.owner.offset.valid.253 = and i1 %descriptor.owner.inside.248, %descriptor.offset.inside.249
  %descriptor.range.inside.255 = and i1 %descriptor.owner.offset.valid.253, %descriptor.extent.inside.251
  %descriptor.range.valid.254 = and i1 %descriptor.range.inside.255, %descriptor.payload.inside.252
  %descriptor.type.valid.256 = icmp eq i32 9, 9
  %descriptor.valid.257 = and i1 %descriptor.range.valid.254, %descriptor.type.valid.256
  br i1 %descriptor.valid.257, label %descriptor.valid.258, label %descriptor.invalid.259
descriptor.invalid.259:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.258:
  %descriptor.initialized.status.260 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.242, i32 %local.resolved.extent.243)
  %helper.ok.261 = icmp eq i32 %descriptor.initialized.status.260, 0
  br i1 %helper.ok.261, label %helper.continue.262, label %frame.failure.0
helper.continue.262:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 9, i32 %local.resolved.offset.242, i32 20, i32 %local.resolved.payload.244, i32 %local.resolved.owner.end.245, i32 %local.resolved.extent.243)
  %context.field.263 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.264 = load i32, ptr %context.field.263, align 4
  %runtime.ok.265 = icmp eq i32 %context.value.264, 0
  br i1 %runtime.ok.265, label %runtime.continue.266, label %frame.failure.0
runtime.continue.266:
  %context.field.267 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.268 = load i32, ptr %context.field.267, align 4
  %stack.sub.271 = sub i32 %descriptor.value.175, %descriptor.value.169
  %descriptor.owner.inside.269 = icmp ule i32 %descriptor.value.175, %context.value.268
  %descriptor.offset.inside.270 = icmp ule i32 %descriptor.value.169, %descriptor.value.175
  %descriptor.extent.inside.272 = icmp ule i32 %descriptor.value.171, %stack.sub.271
  %descriptor.payload.inside.273 = icmp ule i32 %descriptor.value.173, %descriptor.value.171
  %descriptor.owner.offset.valid.274 = and i1 %descriptor.owner.inside.269, %descriptor.offset.inside.270
  %descriptor.range.inside.276 = and i1 %descriptor.owner.offset.valid.274, %descriptor.extent.inside.272
  %descriptor.range.valid.275 = and i1 %descriptor.range.inside.276, %descriptor.payload.inside.273
  %descriptor.type.valid.277 = icmp eq i32 9, 9
  %descriptor.valid.278 = and i1 %descriptor.range.valid.275, %descriptor.type.valid.277
  br i1 %descriptor.valid.278, label %descriptor.valid.279, label %descriptor.invalid.280
descriptor.invalid.280:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.279:
  %descriptor.initialized.status.281 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.169, i32 %descriptor.value.171)
  %helper.ok.282 = icmp eq i32 %descriptor.initialized.status.281, 0
  br i1 %helper.ok.282, label %helper.continue.283, label %frame.failure.0
helper.continue.283:
  %context.field.284 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.285 = load i32, ptr %context.field.284, align 4
  %stack.sub.288 = sub i32 %local.resolved.owner.end.245, %local.resolved.offset.242
  %descriptor.owner.inside.286 = icmp ule i32 %local.resolved.owner.end.245, %context.value.285
  %descriptor.offset.inside.287 = icmp ule i32 %local.resolved.offset.242, %local.resolved.owner.end.245
  %descriptor.extent.inside.289 = icmp ule i32 %local.resolved.extent.243, %stack.sub.288
  %descriptor.payload.inside.290 = icmp ule i32 %local.resolved.payload.244, %local.resolved.extent.243
  %descriptor.owner.offset.valid.291 = and i1 %descriptor.owner.inside.286, %descriptor.offset.inside.287
  %descriptor.range.inside.293 = and i1 %descriptor.owner.offset.valid.291, %descriptor.extent.inside.289
  %descriptor.range.valid.292 = and i1 %descriptor.range.inside.293, %descriptor.payload.inside.290
  %descriptor.type.valid.294 = icmp eq i32 9, 9
  %descriptor.valid.295 = and i1 %descriptor.range.valid.292, %descriptor.type.valid.294
  br i1 %descriptor.valid.295, label %descriptor.valid.296, label %descriptor.invalid.297
descriptor.invalid.297:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.296:
  %descriptor.initialized.status.298 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.242, i32 %local.resolved.extent.243)
  %helper.ok.299 = icmp eq i32 %descriptor.initialized.status.298, 0
  br i1 %helper.ok.299, label %helper.continue.300, label %frame.failure.0
helper.continue.300:
  %local.is.active.301 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.301, label %local.descriptor.active.302, label %local.descriptor.inactive.303
local.descriptor.active.302:
  %local.check.offset.305 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.306 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.307 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.308 = load i32, ptr %local.owner.end.6, align 4
  %context.field.309 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.310 = load i32, ptr %context.field.309, align 4
  %stack.sub.313 = sub i32 %local.check.owner.end.308, %local.check.offset.305
  %descriptor.owner.inside.311 = icmp ule i32 %local.check.owner.end.308, %context.value.310
  %descriptor.offset.inside.312 = icmp ule i32 %local.check.offset.305, %local.check.owner.end.308
  %descriptor.extent.inside.314 = icmp ule i32 %local.check.extent.306, %stack.sub.313
  %descriptor.payload.inside.315 = icmp ule i32 %local.check.payload.307, %local.check.extent.306
  %descriptor.owner.offset.valid.316 = and i1 %descriptor.owner.inside.311, %descriptor.offset.inside.312
  %descriptor.range.inside.318 = and i1 %descriptor.owner.offset.valid.316, %descriptor.extent.inside.314
  %descriptor.range.valid.317 = and i1 %descriptor.range.inside.318, %descriptor.payload.inside.315
  br i1 %descriptor.range.valid.317, label %descriptor.valid.319, label %descriptor.invalid.320
descriptor.invalid.320:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.319:
  %descriptor.initialized.status.321 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.305, i32 %local.check.extent.306)
  %helper.ok.322 = icmp eq i32 %descriptor.initialized.status.321, 0
  br i1 %helper.ok.322, label %helper.continue.323, label %frame.failure.0
helper.continue.323:
  br label %local.descriptor.checked.304
local.descriptor.inactive.303:
  br label %local.descriptor.checked.304
local.descriptor.checked.304:
  %step.status.324 = call i32 @al_owning_charge_step(ptr %ctx, i32 6)
  %helper.ok.325 = icmp eq i32 %step.status.324, 0
  br i1 %helper.ok.325, label %helper.continue.326, label %frame.failure.0
helper.continue.326:
  %context.field.327 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.328 = load i32, ptr %context.field.327, align 4
  %inline.target.depth.within.interpreter.limit.329 = icmp ule i32 %context.value.328, 65
  br i1 %inline.target.depth.within.interpreter.limit.329, label %inline.target.depth.ok.330, label %inline.target.depth.invalid.331
inline.target.depth.invalid.331:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 7, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.330:
  %context.field.332 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.333 = load i32, ptr %context.field.332, align 4
  %stack.sub.336 = sub i32 %descriptor.value.175, %descriptor.value.169
  %descriptor.owner.inside.334 = icmp ule i32 %descriptor.value.175, %context.value.333
  %descriptor.offset.inside.335 = icmp ule i32 %descriptor.value.169, %descriptor.value.175
  %descriptor.extent.inside.337 = icmp ule i32 %descriptor.value.171, %stack.sub.336
  %descriptor.payload.inside.338 = icmp ule i32 %descriptor.value.173, %descriptor.value.171
  %descriptor.owner.offset.valid.339 = and i1 %descriptor.owner.inside.334, %descriptor.offset.inside.335
  %descriptor.range.inside.341 = and i1 %descriptor.owner.offset.valid.339, %descriptor.extent.inside.337
  %descriptor.range.valid.340 = and i1 %descriptor.range.inside.341, %descriptor.payload.inside.338
  %descriptor.type.valid.342 = icmp eq i32 9, 9
  %descriptor.valid.343 = and i1 %descriptor.range.valid.340, %descriptor.type.valid.342
  br i1 %descriptor.valid.343, label %descriptor.valid.344, label %descriptor.invalid.345
descriptor.invalid.345:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.344:
  %descriptor.initialized.status.346 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.169, i32 %descriptor.value.171)
  %helper.ok.347 = icmp eq i32 %descriptor.initialized.status.346, 0
  br i1 %helper.ok.347, label %helper.continue.348, label %frame.failure.0
helper.continue.348:
  %context.field.349 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.350 = load i32, ptr %context.field.349, align 4
  %stack.sub.353 = sub i32 %local.resolved.owner.end.245, %local.resolved.offset.242
  %descriptor.owner.inside.351 = icmp ule i32 %local.resolved.owner.end.245, %context.value.350
  %descriptor.offset.inside.352 = icmp ule i32 %local.resolved.offset.242, %local.resolved.owner.end.245
  %descriptor.extent.inside.354 = icmp ule i32 %local.resolved.extent.243, %stack.sub.353
  %descriptor.payload.inside.355 = icmp ule i32 %local.resolved.payload.244, %local.resolved.extent.243
  %descriptor.owner.offset.valid.356 = and i1 %descriptor.owner.inside.351, %descriptor.offset.inside.352
  %descriptor.range.inside.358 = and i1 %descriptor.owner.offset.valid.356, %descriptor.extent.inside.354
  %descriptor.range.valid.357 = and i1 %descriptor.range.inside.358, %descriptor.payload.inside.355
  %descriptor.type.valid.359 = icmp eq i32 6, 6
  %descriptor.valid.360 = and i1 %descriptor.range.valid.357, %descriptor.type.valid.359
  br i1 %descriptor.valid.360, label %descriptor.valid.361, label %descriptor.invalid.362
descriptor.invalid.362:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.361:
  %descriptor.initialized.status.363 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.242, i32 %local.resolved.extent.243)
  %helper.ok.364 = icmp eq i32 %descriptor.initialized.status.363, 0
  br i1 %helper.ok.364, label %helper.continue.365, label %frame.failure.0
helper.continue.365:
  %local.is.active.366 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.366, label %local.descriptor.active.367, label %local.descriptor.inactive.368
local.descriptor.active.367:
  %local.check.offset.370 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.371 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.372 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.373 = load i32, ptr %local.owner.end.6, align 4
  %context.field.374 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.375 = load i32, ptr %context.field.374, align 4
  %stack.sub.378 = sub i32 %local.check.owner.end.373, %local.check.offset.370
  %descriptor.owner.inside.376 = icmp ule i32 %local.check.owner.end.373, %context.value.375
  %descriptor.offset.inside.377 = icmp ule i32 %local.check.offset.370, %local.check.owner.end.373
  %descriptor.extent.inside.379 = icmp ule i32 %local.check.extent.371, %stack.sub.378
  %descriptor.payload.inside.380 = icmp ule i32 %local.check.payload.372, %local.check.extent.371
  %descriptor.owner.offset.valid.381 = and i1 %descriptor.owner.inside.376, %descriptor.offset.inside.377
  %descriptor.range.inside.383 = and i1 %descriptor.owner.offset.valid.381, %descriptor.extent.inside.379
  %descriptor.range.valid.382 = and i1 %descriptor.range.inside.383, %descriptor.payload.inside.380
  br i1 %descriptor.range.valid.382, label %descriptor.valid.384, label %descriptor.invalid.385
descriptor.invalid.385:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.384:
  %descriptor.initialized.status.386 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.370, i32 %local.check.extent.371)
  %helper.ok.387 = icmp eq i32 %descriptor.initialized.status.386, 0
  br i1 %helper.ok.387, label %helper.continue.388, label %frame.failure.0
helper.continue.388:
  br label %local.descriptor.checked.369
local.descriptor.inactive.368:
  br label %local.descriptor.checked.369
local.descriptor.checked.369:
  %step.status.389 = call i32 @al_owning_charge_step(ptr %ctx, i32 8)
  %helper.ok.390 = icmp eq i32 %step.status.389, 0
  br i1 %helper.ok.390, label %helper.continue.391, label %frame.failure.0
helper.continue.391:
  %local.resolved.offset.392 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.393 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.394 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.395 = load i32, ptr %local.owner.end.6, align 4
  %context.field.396 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.397 = load i32, ptr %context.field.396, align 4
  %stack.sub.400 = sub i32 %local.resolved.owner.end.395, %local.resolved.offset.392
  %descriptor.owner.inside.398 = icmp ule i32 %local.resolved.owner.end.395, %context.value.397
  %descriptor.offset.inside.399 = icmp ule i32 %local.resolved.offset.392, %local.resolved.owner.end.395
  %descriptor.extent.inside.401 = icmp ule i32 %local.resolved.extent.393, %stack.sub.400
  %descriptor.payload.inside.402 = icmp ule i32 %local.resolved.payload.394, %local.resolved.extent.393
  %descriptor.owner.offset.valid.403 = and i1 %descriptor.owner.inside.398, %descriptor.offset.inside.399
  %descriptor.range.inside.405 = and i1 %descriptor.owner.offset.valid.403, %descriptor.extent.inside.401
  %descriptor.range.valid.404 = and i1 %descriptor.range.inside.405, %descriptor.payload.inside.402
  %descriptor.type.valid.406 = icmp eq i32 9, 9
  %descriptor.valid.407 = and i1 %descriptor.range.valid.404, %descriptor.type.valid.406
  br i1 %descriptor.valid.407, label %descriptor.valid.408, label %descriptor.invalid.409
descriptor.invalid.409:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.408:
  %descriptor.initialized.status.410 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.392, i32 %local.resolved.extent.393)
  %helper.ok.411 = icmp eq i32 %descriptor.initialized.status.410, 0
  br i1 %helper.ok.411, label %helper.continue.412, label %frame.failure.0
helper.continue.412:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 9, i32 %local.resolved.offset.392, i32 20, i32 %local.resolved.payload.394, i32 %local.resolved.owner.end.395, i32 %local.resolved.extent.393)
  %context.field.413 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.414 = load i32, ptr %context.field.413, align 4
  %runtime.ok.415 = icmp eq i32 %context.value.414, 0
  br i1 %runtime.ok.415, label %runtime.continue.416, label %frame.failure.0
runtime.continue.416:
  %context.field.417 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.418 = load i32, ptr %context.field.417, align 4
  %stack.sub.421 = sub i32 %descriptor.value.175, %descriptor.value.169
  %descriptor.owner.inside.419 = icmp ule i32 %descriptor.value.175, %context.value.418
  %descriptor.offset.inside.420 = icmp ule i32 %descriptor.value.169, %descriptor.value.175
  %descriptor.extent.inside.422 = icmp ule i32 %descriptor.value.171, %stack.sub.421
  %descriptor.payload.inside.423 = icmp ule i32 %descriptor.value.173, %descriptor.value.171
  %descriptor.owner.offset.valid.424 = and i1 %descriptor.owner.inside.419, %descriptor.offset.inside.420
  %descriptor.range.inside.426 = and i1 %descriptor.owner.offset.valid.424, %descriptor.extent.inside.422
  %descriptor.range.valid.425 = and i1 %descriptor.range.inside.426, %descriptor.payload.inside.423
  %descriptor.type.valid.427 = icmp eq i32 9, 9
  %descriptor.valid.428 = and i1 %descriptor.range.valid.425, %descriptor.type.valid.427
  br i1 %descriptor.valid.428, label %descriptor.valid.429, label %descriptor.invalid.430
descriptor.invalid.430:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.429:
  %descriptor.initialized.status.431 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.169, i32 %descriptor.value.171)
  %helper.ok.432 = icmp eq i32 %descriptor.initialized.status.431, 0
  br i1 %helper.ok.432, label %helper.continue.433, label %frame.failure.0
helper.continue.433:
  %context.field.434 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.435 = load i32, ptr %context.field.434, align 4
  %stack.sub.438 = sub i32 %local.resolved.owner.end.245, %local.resolved.offset.242
  %descriptor.owner.inside.436 = icmp ule i32 %local.resolved.owner.end.245, %context.value.435
  %descriptor.offset.inside.437 = icmp ule i32 %local.resolved.offset.242, %local.resolved.owner.end.245
  %descriptor.extent.inside.439 = icmp ule i32 %local.resolved.extent.243, %stack.sub.438
  %descriptor.payload.inside.440 = icmp ule i32 %local.resolved.payload.244, %local.resolved.extent.243
  %descriptor.owner.offset.valid.441 = and i1 %descriptor.owner.inside.436, %descriptor.offset.inside.437
  %descriptor.range.inside.443 = and i1 %descriptor.owner.offset.valid.441, %descriptor.extent.inside.439
  %descriptor.range.valid.442 = and i1 %descriptor.range.inside.443, %descriptor.payload.inside.440
  %descriptor.type.valid.444 = icmp eq i32 6, 6
  %descriptor.valid.445 = and i1 %descriptor.range.valid.442, %descriptor.type.valid.444
  br i1 %descriptor.valid.445, label %descriptor.valid.446, label %descriptor.invalid.447
descriptor.invalid.447:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.446:
  %descriptor.initialized.status.448 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.242, i32 %local.resolved.extent.243)
  %helper.ok.449 = icmp eq i32 %descriptor.initialized.status.448, 0
  br i1 %helper.ok.449, label %helper.continue.450, label %frame.failure.0
helper.continue.450:
  %context.field.451 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.452 = load i32, ptr %context.field.451, align 4
  %stack.sub.455 = sub i32 %local.resolved.owner.end.395, %local.resolved.offset.392
  %descriptor.owner.inside.453 = icmp ule i32 %local.resolved.owner.end.395, %context.value.452
  %descriptor.offset.inside.454 = icmp ule i32 %local.resolved.offset.392, %local.resolved.owner.end.395
  %descriptor.extent.inside.456 = icmp ule i32 %local.resolved.extent.393, %stack.sub.455
  %descriptor.payload.inside.457 = icmp ule i32 %local.resolved.payload.394, %local.resolved.extent.393
  %descriptor.owner.offset.valid.458 = and i1 %descriptor.owner.inside.453, %descriptor.offset.inside.454
  %descriptor.range.inside.460 = and i1 %descriptor.owner.offset.valid.458, %descriptor.extent.inside.456
  %descriptor.range.valid.459 = and i1 %descriptor.range.inside.460, %descriptor.payload.inside.457
  %descriptor.type.valid.461 = icmp eq i32 9, 9
  %descriptor.valid.462 = and i1 %descriptor.range.valid.459, %descriptor.type.valid.461
  br i1 %descriptor.valid.462, label %descriptor.valid.463, label %descriptor.invalid.464
descriptor.invalid.464:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.463:
  %descriptor.initialized.status.465 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.392, i32 %local.resolved.extent.393)
  %helper.ok.466 = icmp eq i32 %descriptor.initialized.status.465, 0
  br i1 %helper.ok.466, label %helper.continue.467, label %frame.failure.0
helper.continue.467:
  %local.is.active.468 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.468, label %local.descriptor.active.469, label %local.descriptor.inactive.470
local.descriptor.active.469:
  %local.check.offset.472 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.473 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.474 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.475 = load i32, ptr %local.owner.end.6, align 4
  %context.field.476 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.477 = load i32, ptr %context.field.476, align 4
  %stack.sub.480 = sub i32 %local.check.owner.end.475, %local.check.offset.472
  %descriptor.owner.inside.478 = icmp ule i32 %local.check.owner.end.475, %context.value.477
  %descriptor.offset.inside.479 = icmp ule i32 %local.check.offset.472, %local.check.owner.end.475
  %descriptor.extent.inside.481 = icmp ule i32 %local.check.extent.473, %stack.sub.480
  %descriptor.payload.inside.482 = icmp ule i32 %local.check.payload.474, %local.check.extent.473
  %descriptor.owner.offset.valid.483 = and i1 %descriptor.owner.inside.478, %descriptor.offset.inside.479
  %descriptor.range.inside.485 = and i1 %descriptor.owner.offset.valid.483, %descriptor.extent.inside.481
  %descriptor.range.valid.484 = and i1 %descriptor.range.inside.485, %descriptor.payload.inside.482
  br i1 %descriptor.range.valid.484, label %descriptor.valid.486, label %descriptor.invalid.487
descriptor.invalid.487:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.486:
  %descriptor.initialized.status.488 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.472, i32 %local.check.extent.473)
  %helper.ok.489 = icmp eq i32 %descriptor.initialized.status.488, 0
  br i1 %helper.ok.489, label %helper.continue.490, label %frame.failure.0
helper.continue.490:
  br label %local.descriptor.checked.471
local.descriptor.inactive.470:
  br label %local.descriptor.checked.471
local.descriptor.checked.471:
  %step.status.491 = call i32 @al_owning_charge_step(ptr %ctx, i32 9)
  %helper.ok.492 = icmp eq i32 %step.status.491, 0
  br i1 %helper.ok.492, label %helper.continue.493, label %frame.failure.0
helper.continue.493:
  %context.field.494 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.495 = load i32, ptr %context.field.494, align 4
  %stack.offset.496 = add i32 %context.value.495, 8
  %reserve.status.497 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.496, i32 10)
  %reserve.ok.498 = icmp eq i32 %reserve.status.497, 0
  br i1 %reserve.ok.498, label %reserve.continue.499, label %frame.failure.0
reserve.continue.499:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.495, i64 1, i32 2)
  %context.field.500 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.501 = load i32, ptr %context.field.500, align 4
  %runtime.ok.502 = icmp eq i32 %context.value.501, 0
  br i1 %runtime.ok.502, label %runtime.continue.503, label %frame.failure.0
runtime.continue.503:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.504 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.505 = load i32, ptr %context.field.504, align 4
  %runtime.ok.506 = icmp eq i32 %context.value.505, 0
  br i1 %runtime.ok.506, label %runtime.continue.507, label %frame.failure.0
runtime.continue.507:
  %context.field.508 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.509 = load i32, ptr %context.field.508, align 4
  %stack.sub.512 = sub i32 %descriptor.value.175, %descriptor.value.169
  %descriptor.owner.inside.510 = icmp ule i32 %descriptor.value.175, %context.value.509
  %descriptor.offset.inside.511 = icmp ule i32 %descriptor.value.169, %descriptor.value.175
  %descriptor.extent.inside.513 = icmp ule i32 %descriptor.value.171, %stack.sub.512
  %descriptor.payload.inside.514 = icmp ule i32 %descriptor.value.173, %descriptor.value.171
  %descriptor.owner.offset.valid.515 = and i1 %descriptor.owner.inside.510, %descriptor.offset.inside.511
  %descriptor.range.inside.517 = and i1 %descriptor.owner.offset.valid.515, %descriptor.extent.inside.513
  %descriptor.range.valid.516 = and i1 %descriptor.range.inside.517, %descriptor.payload.inside.514
  %descriptor.type.valid.518 = icmp eq i32 9, 9
  %descriptor.valid.519 = and i1 %descriptor.range.valid.516, %descriptor.type.valid.518
  br i1 %descriptor.valid.519, label %descriptor.valid.520, label %descriptor.invalid.521
descriptor.invalid.521:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.520:
  %descriptor.initialized.status.522 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.169, i32 %descriptor.value.171)
  %helper.ok.523 = icmp eq i32 %descriptor.initialized.status.522, 0
  br i1 %helper.ok.523, label %helper.continue.524, label %frame.failure.0
helper.continue.524:
  %context.field.525 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.526 = load i32, ptr %context.field.525, align 4
  %stack.sub.529 = sub i32 %local.resolved.owner.end.245, %local.resolved.offset.242
  %descriptor.owner.inside.527 = icmp ule i32 %local.resolved.owner.end.245, %context.value.526
  %descriptor.offset.inside.528 = icmp ule i32 %local.resolved.offset.242, %local.resolved.owner.end.245
  %descriptor.extent.inside.530 = icmp ule i32 %local.resolved.extent.243, %stack.sub.529
  %descriptor.payload.inside.531 = icmp ule i32 %local.resolved.payload.244, %local.resolved.extent.243
  %descriptor.owner.offset.valid.532 = and i1 %descriptor.owner.inside.527, %descriptor.offset.inside.528
  %descriptor.range.inside.534 = and i1 %descriptor.owner.offset.valid.532, %descriptor.extent.inside.530
  %descriptor.range.valid.533 = and i1 %descriptor.range.inside.534, %descriptor.payload.inside.531
  %descriptor.type.valid.535 = icmp eq i32 6, 6
  %descriptor.valid.536 = and i1 %descriptor.range.valid.533, %descriptor.type.valid.535
  br i1 %descriptor.valid.536, label %descriptor.valid.537, label %descriptor.invalid.538
descriptor.invalid.538:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.537:
  %descriptor.initialized.status.539 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.242, i32 %local.resolved.extent.243)
  %helper.ok.540 = icmp eq i32 %descriptor.initialized.status.539, 0
  br i1 %helper.ok.540, label %helper.continue.541, label %frame.failure.0
helper.continue.541:
  %context.field.542 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.543 = load i32, ptr %context.field.542, align 4
  %stack.sub.546 = sub i32 %local.resolved.owner.end.395, %local.resolved.offset.392
  %descriptor.owner.inside.544 = icmp ule i32 %local.resolved.owner.end.395, %context.value.543
  %descriptor.offset.inside.545 = icmp ule i32 %local.resolved.offset.392, %local.resolved.owner.end.395
  %descriptor.extent.inside.547 = icmp ule i32 %local.resolved.extent.393, %stack.sub.546
  %descriptor.payload.inside.548 = icmp ule i32 %local.resolved.payload.394, %local.resolved.extent.393
  %descriptor.owner.offset.valid.549 = and i1 %descriptor.owner.inside.544, %descriptor.offset.inside.545
  %descriptor.range.inside.551 = and i1 %descriptor.owner.offset.valid.549, %descriptor.extent.inside.547
  %descriptor.range.valid.550 = and i1 %descriptor.range.inside.551, %descriptor.payload.inside.548
  %descriptor.type.valid.552 = icmp eq i32 9, 9
  %descriptor.valid.553 = and i1 %descriptor.range.valid.550, %descriptor.type.valid.552
  br i1 %descriptor.valid.553, label %descriptor.valid.554, label %descriptor.invalid.555
descriptor.invalid.555:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.554:
  %descriptor.initialized.status.556 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.392, i32 %local.resolved.extent.393)
  %helper.ok.557 = icmp eq i32 %descriptor.initialized.status.556, 0
  br i1 %helper.ok.557, label %helper.continue.558, label %frame.failure.0
helper.continue.558:
  %context.field.559 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.560 = load i32, ptr %context.field.559, align 4
  %stack.sub.563 = sub i32 %stack.offset.496, %context.value.495
  %descriptor.owner.inside.561 = icmp ule i32 %stack.offset.496, %context.value.560
  %descriptor.offset.inside.562 = icmp ule i32 %context.value.495, %stack.offset.496
  %descriptor.extent.inside.564 = icmp ule i32 8, %stack.sub.563
  %descriptor.payload.inside.565 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.566 = and i1 %descriptor.owner.inside.561, %descriptor.offset.inside.562
  %descriptor.range.inside.568 = and i1 %descriptor.owner.offset.valid.566, %descriptor.extent.inside.564
  %descriptor.range.valid.567 = and i1 %descriptor.range.inside.568, %descriptor.payload.inside.565
  %descriptor.type.valid.569 = icmp eq i32 2, 2
  %descriptor.valid.570 = and i1 %descriptor.range.valid.567, %descriptor.type.valid.569
  br i1 %descriptor.valid.570, label %descriptor.valid.571, label %descriptor.invalid.572
descriptor.invalid.572:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.571:
  %descriptor.initialized.status.573 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.495, i32 8)
  %helper.ok.574 = icmp eq i32 %descriptor.initialized.status.573, 0
  br i1 %helper.ok.574, label %helper.continue.575, label %frame.failure.0
helper.continue.575:
  %local.is.active.576 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.576, label %local.descriptor.active.577, label %local.descriptor.inactive.578
local.descriptor.active.577:
  %local.check.offset.580 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.581 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.582 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.583 = load i32, ptr %local.owner.end.6, align 4
  %context.field.584 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.585 = load i32, ptr %context.field.584, align 4
  %stack.sub.588 = sub i32 %local.check.owner.end.583, %local.check.offset.580
  %descriptor.owner.inside.586 = icmp ule i32 %local.check.owner.end.583, %context.value.585
  %descriptor.offset.inside.587 = icmp ule i32 %local.check.offset.580, %local.check.owner.end.583
  %descriptor.extent.inside.589 = icmp ule i32 %local.check.extent.581, %stack.sub.588
  %descriptor.payload.inside.590 = icmp ule i32 %local.check.payload.582, %local.check.extent.581
  %descriptor.owner.offset.valid.591 = and i1 %descriptor.owner.inside.586, %descriptor.offset.inside.587
  %descriptor.range.inside.593 = and i1 %descriptor.owner.offset.valid.591, %descriptor.extent.inside.589
  %descriptor.range.valid.592 = and i1 %descriptor.range.inside.593, %descriptor.payload.inside.590
  br i1 %descriptor.range.valid.592, label %descriptor.valid.594, label %descriptor.invalid.595
descriptor.invalid.595:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.594:
  %descriptor.initialized.status.596 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.580, i32 %local.check.extent.581)
  %helper.ok.597 = icmp eq i32 %descriptor.initialized.status.596, 0
  br i1 %helper.ok.597, label %helper.continue.598, label %frame.failure.0
helper.continue.598:
  br label %local.descriptor.checked.579
local.descriptor.inactive.578:
  br label %local.descriptor.checked.579
local.descriptor.checked.579:
  %step.status.599 = call i32 @al_owning_charge_step(ptr %ctx, i32 11)
  %helper.ok.600 = icmp eq i32 %step.status.599, 0
  br i1 %helper.ok.600, label %helper.continue.601, label %frame.failure.0
helper.continue.601:
  %context.field.602 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.603 = load i32, ptr %context.field.602, align 4
  %inline.target.depth.within.interpreter.limit.604 = icmp ule i32 %context.value.603, 65
  br i1 %inline.target.depth.within.interpreter.limit.604, label %inline.target.depth.ok.605, label %inline.target.depth.invalid.606
inline.target.depth.invalid.606:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 12, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.605:
  %stack.offset.607 = add i32 0, %local.resolved.payload.394
  %stack.offset.608 = add i32 %stack.offset.607, 8
  %stack.offset.609 = add i32 0, %local.resolved.extent.393
  %stack.offset.610 = add i32 %stack.offset.609, 8
  %context.field.611 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.612 = load i32, ptr %context.field.611, align 4
  %stack.offset.613 = add i32 %context.value.612, %stack.offset.610
  %reserve.status.614 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.613, i32 13)
  %reserve.ok.615 = icmp eq i32 %reserve.status.614, 0
  br i1 %reserve.ok.615, label %reserve.continue.616, label %frame.failure.0
reserve.continue.616:
  %stack.offset.617 = add i32 %context.value.612, 0
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.617, i32 %local.resolved.offset.392, i32 %local.resolved.extent.393, i32 %local.resolved.payload.394, i32 9, i32 6)
  %context.field.618 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.619 = load i32, ptr %context.field.618, align 4
  %runtime.ok.620 = icmp eq i32 %context.value.619, 0
  br i1 %runtime.ok.620, label %runtime.continue.621, label %frame.failure.0
runtime.continue.621:
  %stack.offset.622 = add i32 0, %local.resolved.extent.393
  %stack.offset.623 = add i32 %context.value.612, %stack.offset.622
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.623, i32 %context.value.495, i32 8, i32 8, i32 2, i32 6)
  %context.field.624 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.625 = load i32, ptr %context.field.624, align 4
  %runtime.ok.626 = icmp eq i32 %context.value.625, 0
  br i1 %runtime.ok.626, label %runtime.continue.627, label %frame.failure.0
runtime.continue.627:
  %stack.offset.628 = add i32 %stack.offset.622, 8
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 5, i32 %context.value.612, i32 %stack.offset.610, i32 %stack.offset.608, i32 0, i32 0)
  %context.field.629 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.630 = load i32, ptr %context.field.629, align 4
  %runtime.ok.631 = icmp eq i32 %context.value.630, 0
  br i1 %runtime.ok.631, label %runtime.continue.632, label %frame.failure.0
runtime.continue.632:
  %context.field.633 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.634 = load i32, ptr %context.field.633, align 4
  %stack.sub.637 = sub i32 %descriptor.value.175, %descriptor.value.169
  %descriptor.owner.inside.635 = icmp ule i32 %descriptor.value.175, %context.value.634
  %descriptor.offset.inside.636 = icmp ule i32 %descriptor.value.169, %descriptor.value.175
  %descriptor.extent.inside.638 = icmp ule i32 %descriptor.value.171, %stack.sub.637
  %descriptor.payload.inside.639 = icmp ule i32 %descriptor.value.173, %descriptor.value.171
  %descriptor.owner.offset.valid.640 = and i1 %descriptor.owner.inside.635, %descriptor.offset.inside.636
  %descriptor.range.inside.642 = and i1 %descriptor.owner.offset.valid.640, %descriptor.extent.inside.638
  %descriptor.range.valid.641 = and i1 %descriptor.range.inside.642, %descriptor.payload.inside.639
  %descriptor.type.valid.643 = icmp eq i32 9, 9
  %descriptor.valid.644 = and i1 %descriptor.range.valid.641, %descriptor.type.valid.643
  br i1 %descriptor.valid.644, label %descriptor.valid.645, label %descriptor.invalid.646
descriptor.invalid.646:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.645:
  %descriptor.initialized.status.647 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.169, i32 %descriptor.value.171)
  %helper.ok.648 = icmp eq i32 %descriptor.initialized.status.647, 0
  br i1 %helper.ok.648, label %helper.continue.649, label %frame.failure.0
helper.continue.649:
  %context.field.650 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.651 = load i32, ptr %context.field.650, align 4
  %stack.sub.654 = sub i32 %local.resolved.owner.end.245, %local.resolved.offset.242
  %descriptor.owner.inside.652 = icmp ule i32 %local.resolved.owner.end.245, %context.value.651
  %descriptor.offset.inside.653 = icmp ule i32 %local.resolved.offset.242, %local.resolved.owner.end.245
  %descriptor.extent.inside.655 = icmp ule i32 %local.resolved.extent.243, %stack.sub.654
  %descriptor.payload.inside.656 = icmp ule i32 %local.resolved.payload.244, %local.resolved.extent.243
  %descriptor.owner.offset.valid.657 = and i1 %descriptor.owner.inside.652, %descriptor.offset.inside.653
  %descriptor.range.inside.659 = and i1 %descriptor.owner.offset.valid.657, %descriptor.extent.inside.655
  %descriptor.range.valid.658 = and i1 %descriptor.range.inside.659, %descriptor.payload.inside.656
  %descriptor.type.valid.660 = icmp eq i32 6, 6
  %descriptor.valid.661 = and i1 %descriptor.range.valid.658, %descriptor.type.valid.660
  br i1 %descriptor.valid.661, label %descriptor.valid.662, label %descriptor.invalid.663
descriptor.invalid.663:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.662:
  %descriptor.initialized.status.664 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.242, i32 %local.resolved.extent.243)
  %helper.ok.665 = icmp eq i32 %descriptor.initialized.status.664, 0
  br i1 %helper.ok.665, label %helper.continue.666, label %frame.failure.0
helper.continue.666:
  %context.field.667 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.668 = load i32, ptr %context.field.667, align 4
  %stack.sub.671 = sub i32 %stack.offset.613, %context.value.612
  %descriptor.owner.inside.669 = icmp ule i32 %stack.offset.613, %context.value.668
  %descriptor.offset.inside.670 = icmp ule i32 %context.value.612, %stack.offset.613
  %descriptor.extent.inside.672 = icmp ule i32 %stack.offset.610, %stack.sub.671
  %descriptor.payload.inside.673 = icmp ule i32 %stack.offset.608, %stack.offset.610
  %descriptor.owner.offset.valid.674 = and i1 %descriptor.owner.inside.669, %descriptor.offset.inside.670
  %descriptor.range.inside.676 = and i1 %descriptor.owner.offset.valid.674, %descriptor.extent.inside.672
  %descriptor.range.valid.675 = and i1 %descriptor.range.inside.676, %descriptor.payload.inside.673
  %descriptor.type.valid.677 = icmp eq i32 5, 5
  %descriptor.valid.678 = and i1 %descriptor.range.valid.675, %descriptor.type.valid.677
  br i1 %descriptor.valid.678, label %descriptor.valid.679, label %descriptor.invalid.680
descriptor.invalid.680:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.679:
  %descriptor.initialized.status.681 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.612, i32 %stack.offset.610)
  %helper.ok.682 = icmp eq i32 %descriptor.initialized.status.681, 0
  br i1 %helper.ok.682, label %helper.continue.683, label %frame.failure.0
helper.continue.683:
  %local.is.active.684 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.684, label %local.descriptor.active.685, label %local.descriptor.inactive.686
local.descriptor.active.685:
  %local.check.offset.688 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.689 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.690 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.691 = load i32, ptr %local.owner.end.6, align 4
  %context.field.692 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.693 = load i32, ptr %context.field.692, align 4
  %stack.sub.696 = sub i32 %local.check.owner.end.691, %local.check.offset.688
  %descriptor.owner.inside.694 = icmp ule i32 %local.check.owner.end.691, %context.value.693
  %descriptor.offset.inside.695 = icmp ule i32 %local.check.offset.688, %local.check.owner.end.691
  %descriptor.extent.inside.697 = icmp ule i32 %local.check.extent.689, %stack.sub.696
  %descriptor.payload.inside.698 = icmp ule i32 %local.check.payload.690, %local.check.extent.689
  %descriptor.owner.offset.valid.699 = and i1 %descriptor.owner.inside.694, %descriptor.offset.inside.695
  %descriptor.range.inside.701 = and i1 %descriptor.owner.offset.valid.699, %descriptor.extent.inside.697
  %descriptor.range.valid.700 = and i1 %descriptor.range.inside.701, %descriptor.payload.inside.698
  br i1 %descriptor.range.valid.700, label %descriptor.valid.702, label %descriptor.invalid.703
descriptor.invalid.703:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.702:
  %descriptor.initialized.status.704 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.688, i32 %local.check.extent.689)
  %helper.ok.705 = icmp eq i32 %descriptor.initialized.status.704, 0
  br i1 %helper.ok.705, label %helper.continue.706, label %frame.failure.0
helper.continue.706:
  br label %local.descriptor.checked.687
local.descriptor.inactive.686:
  br label %local.descriptor.checked.687
local.descriptor.checked.687:
  %step.status.707 = call i32 @al_owning_charge_step(ptr %ctx, i32 14)
  %helper.ok.708 = icmp eq i32 %step.status.707, 0
  br i1 %helper.ok.708, label %helper.continue.709, label %frame.failure.0
helper.continue.709:
  %local.resolved.offset.710 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.711 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.712 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.713 = load i32, ptr %local.owner.end.6, align 4
  %context.field.714 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.715 = load i32, ptr %context.field.714, align 4
  %stack.sub.718 = sub i32 %local.resolved.owner.end.713, %local.resolved.offset.710
  %descriptor.owner.inside.716 = icmp ule i32 %local.resolved.owner.end.713, %context.value.715
  %descriptor.offset.inside.717 = icmp ule i32 %local.resolved.offset.710, %local.resolved.owner.end.713
  %descriptor.extent.inside.719 = icmp ule i32 %local.resolved.extent.711, %stack.sub.718
  %descriptor.payload.inside.720 = icmp ule i32 %local.resolved.payload.712, %local.resolved.extent.711
  %descriptor.owner.offset.valid.721 = and i1 %descriptor.owner.inside.716, %descriptor.offset.inside.717
  %descriptor.range.inside.723 = and i1 %descriptor.owner.offset.valid.721, %descriptor.extent.inside.719
  %descriptor.range.valid.722 = and i1 %descriptor.range.inside.723, %descriptor.payload.inside.720
  %descriptor.type.valid.724 = icmp eq i32 9, 9
  %descriptor.valid.725 = and i1 %descriptor.range.valid.722, %descriptor.type.valid.724
  br i1 %descriptor.valid.725, label %descriptor.valid.726, label %descriptor.invalid.727
descriptor.invalid.727:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.726:
  %descriptor.initialized.status.728 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.710, i32 %local.resolved.extent.711)
  %helper.ok.729 = icmp eq i32 %descriptor.initialized.status.728, 0
  br i1 %helper.ok.729, label %helper.continue.730, label %frame.failure.0
helper.continue.730:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 9, i32 %local.resolved.offset.710, i32 20, i32 %local.resolved.payload.712, i32 %local.resolved.owner.end.713, i32 %local.resolved.extent.711)
  %context.field.731 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.732 = load i32, ptr %context.field.731, align 4
  %runtime.ok.733 = icmp eq i32 %context.value.732, 0
  br i1 %runtime.ok.733, label %runtime.continue.734, label %frame.failure.0
runtime.continue.734:
  %context.field.735 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.736 = load i32, ptr %context.field.735, align 4
  %stack.sub.739 = sub i32 %descriptor.value.175, %descriptor.value.169
  %descriptor.owner.inside.737 = icmp ule i32 %descriptor.value.175, %context.value.736
  %descriptor.offset.inside.738 = icmp ule i32 %descriptor.value.169, %descriptor.value.175
  %descriptor.extent.inside.740 = icmp ule i32 %descriptor.value.171, %stack.sub.739
  %descriptor.payload.inside.741 = icmp ule i32 %descriptor.value.173, %descriptor.value.171
  %descriptor.owner.offset.valid.742 = and i1 %descriptor.owner.inside.737, %descriptor.offset.inside.738
  %descriptor.range.inside.744 = and i1 %descriptor.owner.offset.valid.742, %descriptor.extent.inside.740
  %descriptor.range.valid.743 = and i1 %descriptor.range.inside.744, %descriptor.payload.inside.741
  %descriptor.type.valid.745 = icmp eq i32 9, 9
  %descriptor.valid.746 = and i1 %descriptor.range.valid.743, %descriptor.type.valid.745
  br i1 %descriptor.valid.746, label %descriptor.valid.747, label %descriptor.invalid.748
descriptor.invalid.748:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.747:
  %descriptor.initialized.status.749 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.169, i32 %descriptor.value.171)
  %helper.ok.750 = icmp eq i32 %descriptor.initialized.status.749, 0
  br i1 %helper.ok.750, label %helper.continue.751, label %frame.failure.0
helper.continue.751:
  %context.field.752 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.753 = load i32, ptr %context.field.752, align 4
  %stack.sub.756 = sub i32 %local.resolved.owner.end.245, %local.resolved.offset.242
  %descriptor.owner.inside.754 = icmp ule i32 %local.resolved.owner.end.245, %context.value.753
  %descriptor.offset.inside.755 = icmp ule i32 %local.resolved.offset.242, %local.resolved.owner.end.245
  %descriptor.extent.inside.757 = icmp ule i32 %local.resolved.extent.243, %stack.sub.756
  %descriptor.payload.inside.758 = icmp ule i32 %local.resolved.payload.244, %local.resolved.extent.243
  %descriptor.owner.offset.valid.759 = and i1 %descriptor.owner.inside.754, %descriptor.offset.inside.755
  %descriptor.range.inside.761 = and i1 %descriptor.owner.offset.valid.759, %descriptor.extent.inside.757
  %descriptor.range.valid.760 = and i1 %descriptor.range.inside.761, %descriptor.payload.inside.758
  %descriptor.type.valid.762 = icmp eq i32 6, 6
  %descriptor.valid.763 = and i1 %descriptor.range.valid.760, %descriptor.type.valid.762
  br i1 %descriptor.valid.763, label %descriptor.valid.764, label %descriptor.invalid.765
descriptor.invalid.765:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.764:
  %descriptor.initialized.status.766 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.242, i32 %local.resolved.extent.243)
  %helper.ok.767 = icmp eq i32 %descriptor.initialized.status.766, 0
  br i1 %helper.ok.767, label %helper.continue.768, label %frame.failure.0
helper.continue.768:
  %context.field.769 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.770 = load i32, ptr %context.field.769, align 4
  %stack.sub.773 = sub i32 %stack.offset.613, %context.value.612
  %descriptor.owner.inside.771 = icmp ule i32 %stack.offset.613, %context.value.770
  %descriptor.offset.inside.772 = icmp ule i32 %context.value.612, %stack.offset.613
  %descriptor.extent.inside.774 = icmp ule i32 %stack.offset.610, %stack.sub.773
  %descriptor.payload.inside.775 = icmp ule i32 %stack.offset.608, %stack.offset.610
  %descriptor.owner.offset.valid.776 = and i1 %descriptor.owner.inside.771, %descriptor.offset.inside.772
  %descriptor.range.inside.778 = and i1 %descriptor.owner.offset.valid.776, %descriptor.extent.inside.774
  %descriptor.range.valid.777 = and i1 %descriptor.range.inside.778, %descriptor.payload.inside.775
  %descriptor.type.valid.779 = icmp eq i32 5, 5
  %descriptor.valid.780 = and i1 %descriptor.range.valid.777, %descriptor.type.valid.779
  br i1 %descriptor.valid.780, label %descriptor.valid.781, label %descriptor.invalid.782
descriptor.invalid.782:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.781:
  %descriptor.initialized.status.783 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.612, i32 %stack.offset.610)
  %helper.ok.784 = icmp eq i32 %descriptor.initialized.status.783, 0
  br i1 %helper.ok.784, label %helper.continue.785, label %frame.failure.0
helper.continue.785:
  %context.field.786 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.787 = load i32, ptr %context.field.786, align 4
  %stack.sub.790 = sub i32 %local.resolved.owner.end.713, %local.resolved.offset.710
  %descriptor.owner.inside.788 = icmp ule i32 %local.resolved.owner.end.713, %context.value.787
  %descriptor.offset.inside.789 = icmp ule i32 %local.resolved.offset.710, %local.resolved.owner.end.713
  %descriptor.extent.inside.791 = icmp ule i32 %local.resolved.extent.711, %stack.sub.790
  %descriptor.payload.inside.792 = icmp ule i32 %local.resolved.payload.712, %local.resolved.extent.711
  %descriptor.owner.offset.valid.793 = and i1 %descriptor.owner.inside.788, %descriptor.offset.inside.789
  %descriptor.range.inside.795 = and i1 %descriptor.owner.offset.valid.793, %descriptor.extent.inside.791
  %descriptor.range.valid.794 = and i1 %descriptor.range.inside.795, %descriptor.payload.inside.792
  %descriptor.type.valid.796 = icmp eq i32 9, 9
  %descriptor.valid.797 = and i1 %descriptor.range.valid.794, %descriptor.type.valid.796
  br i1 %descriptor.valid.797, label %descriptor.valid.798, label %descriptor.invalid.799
descriptor.invalid.799:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.798:
  %descriptor.initialized.status.800 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.710, i32 %local.resolved.extent.711)
  %helper.ok.801 = icmp eq i32 %descriptor.initialized.status.800, 0
  br i1 %helper.ok.801, label %helper.continue.802, label %frame.failure.0
helper.continue.802:
  %local.is.active.803 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.803, label %local.descriptor.active.804, label %local.descriptor.inactive.805
local.descriptor.active.804:
  %local.check.offset.807 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.808 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.809 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.810 = load i32, ptr %local.owner.end.6, align 4
  %context.field.811 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.812 = load i32, ptr %context.field.811, align 4
  %stack.sub.815 = sub i32 %local.check.owner.end.810, %local.check.offset.807
  %descriptor.owner.inside.813 = icmp ule i32 %local.check.owner.end.810, %context.value.812
  %descriptor.offset.inside.814 = icmp ule i32 %local.check.offset.807, %local.check.owner.end.810
  %descriptor.extent.inside.816 = icmp ule i32 %local.check.extent.808, %stack.sub.815
  %descriptor.payload.inside.817 = icmp ule i32 %local.check.payload.809, %local.check.extent.808
  %descriptor.owner.offset.valid.818 = and i1 %descriptor.owner.inside.813, %descriptor.offset.inside.814
  %descriptor.range.inside.820 = and i1 %descriptor.owner.offset.valid.818, %descriptor.extent.inside.816
  %descriptor.range.valid.819 = and i1 %descriptor.range.inside.820, %descriptor.payload.inside.817
  br i1 %descriptor.range.valid.819, label %descriptor.valid.821, label %descriptor.invalid.822
descriptor.invalid.822:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.821:
  %descriptor.initialized.status.823 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.807, i32 %local.check.extent.808)
  %helper.ok.824 = icmp eq i32 %descriptor.initialized.status.823, 0
  br i1 %helper.ok.824, label %helper.continue.825, label %frame.failure.0
helper.continue.825:
  br label %local.descriptor.checked.806
local.descriptor.inactive.805:
  br label %local.descriptor.checked.806
local.descriptor.checked.806:
  %step.status.826 = call i32 @al_owning_charge_step(ptr %ctx, i32 15)
  %helper.ok.827 = icmp eq i32 %step.status.826, 0
  br i1 %helper.ok.827, label %helper.continue.828, label %frame.failure.0
helper.continue.828:
  %context.field.829 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.830 = load i32, ptr %context.field.829, align 4
  %stack.offset.831 = add i32 8, %local.resolved.extent.711
  %stack.offset.832 = add i32 8, %local.resolved.payload.712
  %stack.offset.833 = add i32 %context.value.830, %stack.offset.831
  %reserve.status.834 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.833, i32 16)
  %reserve.ok.835 = icmp eq i32 %reserve.status.834, 0
  br i1 %reserve.ok.835, label %reserve.continue.836, label %frame.failure.0
reserve.continue.836:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.830, i64 0, i32 10)
  %context.field.837 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.838 = load i32, ptr %context.field.837, align 4
  %runtime.ok.839 = icmp eq i32 %context.value.838, 0
  br i1 %runtime.ok.839, label %runtime.continue.840, label %frame.failure.0
runtime.continue.840:
  %stack.offset.841 = add i32 %context.value.830, 8
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.841, i32 %local.resolved.offset.710, i32 %local.resolved.extent.711, i32 %local.resolved.payload.712, i32 9, i32 6)
  %context.field.842 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.843 = load i32, ptr %context.field.842, align 4
  %runtime.ok.844 = icmp eq i32 %context.value.843, 0
  br i1 %runtime.ok.844, label %runtime.continue.845, label %frame.failure.0
runtime.continue.845:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.846 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.847 = load i32, ptr %context.field.846, align 4
  %runtime.ok.848 = icmp eq i32 %context.value.847, 0
  br i1 %runtime.ok.848, label %runtime.continue.849, label %frame.failure.0
runtime.continue.849:
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 10, i32 %context.value.830, i32 %stack.offset.831, i32 %stack.offset.832, i32 %local.resolved.offset.710, i32 %local.resolved.extent.711)
  %context.field.850 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.851 = load i32, ptr %context.field.850, align 4
  %runtime.ok.852 = icmp eq i32 %context.value.851, 0
  br i1 %runtime.ok.852, label %runtime.continue.853, label %frame.failure.0
runtime.continue.853:
  %context.field.854 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.855 = load i32, ptr %context.field.854, align 4
  %stack.sub.858 = sub i32 %descriptor.value.175, %descriptor.value.169
  %descriptor.owner.inside.856 = icmp ule i32 %descriptor.value.175, %context.value.855
  %descriptor.offset.inside.857 = icmp ule i32 %descriptor.value.169, %descriptor.value.175
  %descriptor.extent.inside.859 = icmp ule i32 %descriptor.value.171, %stack.sub.858
  %descriptor.payload.inside.860 = icmp ule i32 %descriptor.value.173, %descriptor.value.171
  %descriptor.owner.offset.valid.861 = and i1 %descriptor.owner.inside.856, %descriptor.offset.inside.857
  %descriptor.range.inside.863 = and i1 %descriptor.owner.offset.valid.861, %descriptor.extent.inside.859
  %descriptor.range.valid.862 = and i1 %descriptor.range.inside.863, %descriptor.payload.inside.860
  %descriptor.type.valid.864 = icmp eq i32 9, 9
  %descriptor.valid.865 = and i1 %descriptor.range.valid.862, %descriptor.type.valid.864
  br i1 %descriptor.valid.865, label %descriptor.valid.866, label %descriptor.invalid.867
descriptor.invalid.867:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.866:
  %descriptor.initialized.status.868 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.169, i32 %descriptor.value.171)
  %helper.ok.869 = icmp eq i32 %descriptor.initialized.status.868, 0
  br i1 %helper.ok.869, label %helper.continue.870, label %frame.failure.0
helper.continue.870:
  %context.field.871 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.872 = load i32, ptr %context.field.871, align 4
  %stack.sub.875 = sub i32 %local.resolved.owner.end.245, %local.resolved.offset.242
  %descriptor.owner.inside.873 = icmp ule i32 %local.resolved.owner.end.245, %context.value.872
  %descriptor.offset.inside.874 = icmp ule i32 %local.resolved.offset.242, %local.resolved.owner.end.245
  %descriptor.extent.inside.876 = icmp ule i32 %local.resolved.extent.243, %stack.sub.875
  %descriptor.payload.inside.877 = icmp ule i32 %local.resolved.payload.244, %local.resolved.extent.243
  %descriptor.owner.offset.valid.878 = and i1 %descriptor.owner.inside.873, %descriptor.offset.inside.874
  %descriptor.range.inside.880 = and i1 %descriptor.owner.offset.valid.878, %descriptor.extent.inside.876
  %descriptor.range.valid.879 = and i1 %descriptor.range.inside.880, %descriptor.payload.inside.877
  %descriptor.type.valid.881 = icmp eq i32 6, 6
  %descriptor.valid.882 = and i1 %descriptor.range.valid.879, %descriptor.type.valid.881
  br i1 %descriptor.valid.882, label %descriptor.valid.883, label %descriptor.invalid.884
descriptor.invalid.884:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.883:
  %descriptor.initialized.status.885 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.242, i32 %local.resolved.extent.243)
  %helper.ok.886 = icmp eq i32 %descriptor.initialized.status.885, 0
  br i1 %helper.ok.886, label %helper.continue.887, label %frame.failure.0
helper.continue.887:
  %context.field.888 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.889 = load i32, ptr %context.field.888, align 4
  %stack.sub.892 = sub i32 %stack.offset.613, %context.value.612
  %descriptor.owner.inside.890 = icmp ule i32 %stack.offset.613, %context.value.889
  %descriptor.offset.inside.891 = icmp ule i32 %context.value.612, %stack.offset.613
  %descriptor.extent.inside.893 = icmp ule i32 %stack.offset.610, %stack.sub.892
  %descriptor.payload.inside.894 = icmp ule i32 %stack.offset.608, %stack.offset.610
  %descriptor.owner.offset.valid.895 = and i1 %descriptor.owner.inside.890, %descriptor.offset.inside.891
  %descriptor.range.inside.897 = and i1 %descriptor.owner.offset.valid.895, %descriptor.extent.inside.893
  %descriptor.range.valid.896 = and i1 %descriptor.range.inside.897, %descriptor.payload.inside.894
  %descriptor.type.valid.898 = icmp eq i32 5, 5
  %descriptor.valid.899 = and i1 %descriptor.range.valid.896, %descriptor.type.valid.898
  br i1 %descriptor.valid.899, label %descriptor.valid.900, label %descriptor.invalid.901
descriptor.invalid.901:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.900:
  %descriptor.initialized.status.902 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.612, i32 %stack.offset.610)
  %helper.ok.903 = icmp eq i32 %descriptor.initialized.status.902, 0
  br i1 %helper.ok.903, label %helper.continue.904, label %frame.failure.0
helper.continue.904:
  %context.field.905 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.906 = load i32, ptr %context.field.905, align 4
  %stack.sub.909 = sub i32 %stack.offset.833, %context.value.830
  %descriptor.owner.inside.907 = icmp ule i32 %stack.offset.833, %context.value.906
  %descriptor.offset.inside.908 = icmp ule i32 %context.value.830, %stack.offset.833
  %descriptor.extent.inside.910 = icmp ule i32 %stack.offset.831, %stack.sub.909
  %descriptor.payload.inside.911 = icmp ule i32 %stack.offset.832, %stack.offset.831
  %descriptor.owner.offset.valid.912 = and i1 %descriptor.owner.inside.907, %descriptor.offset.inside.908
  %descriptor.range.inside.914 = and i1 %descriptor.owner.offset.valid.912, %descriptor.extent.inside.910
  %descriptor.range.valid.913 = and i1 %descriptor.range.inside.914, %descriptor.payload.inside.911
  %descriptor.type.valid.915 = icmp eq i32 10, 10
  %descriptor.valid.916 = and i1 %descriptor.range.valid.913, %descriptor.type.valid.915
  br i1 %descriptor.valid.916, label %descriptor.valid.917, label %descriptor.invalid.918
descriptor.invalid.918:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.917:
  %descriptor.initialized.status.919 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.830, i32 %stack.offset.831)
  %helper.ok.920 = icmp eq i32 %descriptor.initialized.status.919, 0
  br i1 %helper.ok.920, label %helper.continue.921, label %frame.failure.0
helper.continue.921:
  %local.is.active.922 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.922, label %local.descriptor.active.923, label %local.descriptor.inactive.924
local.descriptor.active.923:
  %local.check.offset.926 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.927 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.928 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.929 = load i32, ptr %local.owner.end.6, align 4
  %context.field.930 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.931 = load i32, ptr %context.field.930, align 4
  %stack.sub.934 = sub i32 %local.check.owner.end.929, %local.check.offset.926
  %descriptor.owner.inside.932 = icmp ule i32 %local.check.owner.end.929, %context.value.931
  %descriptor.offset.inside.933 = icmp ule i32 %local.check.offset.926, %local.check.owner.end.929
  %descriptor.extent.inside.935 = icmp ule i32 %local.check.extent.927, %stack.sub.934
  %descriptor.payload.inside.936 = icmp ule i32 %local.check.payload.928, %local.check.extent.927
  %descriptor.owner.offset.valid.937 = and i1 %descriptor.owner.inside.932, %descriptor.offset.inside.933
  %descriptor.range.inside.939 = and i1 %descriptor.owner.offset.valid.937, %descriptor.extent.inside.935
  %descriptor.range.valid.938 = and i1 %descriptor.range.inside.939, %descriptor.payload.inside.936
  br i1 %descriptor.range.valid.938, label %descriptor.valid.940, label %descriptor.invalid.941
descriptor.invalid.941:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.940:
  %descriptor.initialized.status.942 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.926, i32 %local.check.extent.927)
  %helper.ok.943 = icmp eq i32 %descriptor.initialized.status.942, 0
  br i1 %helper.ok.943, label %helper.continue.944, label %frame.failure.0
helper.continue.944:
  br label %local.descriptor.checked.925
local.descriptor.inactive.924:
  br label %local.descriptor.checked.925
local.descriptor.checked.925:
  %step.status.945 = call i32 @al_owning_charge_step(ptr %ctx, i32 17)
  %helper.ok.946 = icmp eq i32 %step.status.945, 0
  br i1 %helper.ok.946, label %helper.continue.947, label %frame.failure.0
helper.continue.947:
  %local.resolved.offset.948 = load i32, ptr %local.offset.3, align 4
  %local.resolved.extent.949 = load i32, ptr %local.extent.4, align 4
  %local.resolved.payload.950 = load i32, ptr %local.payload.5, align 4
  %local.resolved.owner.end.951 = load i32, ptr %local.owner.end.6, align 4
  %context.field.952 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.953 = load i32, ptr %context.field.952, align 4
  %stack.sub.956 = sub i32 %local.resolved.owner.end.951, %local.resolved.offset.948
  %descriptor.owner.inside.954 = icmp ule i32 %local.resolved.owner.end.951, %context.value.953
  %descriptor.offset.inside.955 = icmp ule i32 %local.resolved.offset.948, %local.resolved.owner.end.951
  %descriptor.extent.inside.957 = icmp ule i32 %local.resolved.extent.949, %stack.sub.956
  %descriptor.payload.inside.958 = icmp ule i32 %local.resolved.payload.950, %local.resolved.extent.949
  %descriptor.owner.offset.valid.959 = and i1 %descriptor.owner.inside.954, %descriptor.offset.inside.955
  %descriptor.range.inside.961 = and i1 %descriptor.owner.offset.valid.959, %descriptor.extent.inside.957
  %descriptor.range.valid.960 = and i1 %descriptor.range.inside.961, %descriptor.payload.inside.958
  %descriptor.type.valid.962 = icmp eq i32 9, 9
  %descriptor.valid.963 = and i1 %descriptor.range.valid.960, %descriptor.type.valid.962
  br i1 %descriptor.valid.963, label %descriptor.valid.964, label %descriptor.invalid.965
descriptor.invalid.965:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.964:
  %descriptor.initialized.status.966 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.948, i32 %local.resolved.extent.949)
  %helper.ok.967 = icmp eq i32 %descriptor.initialized.status.966, 0
  br i1 %helper.ok.967, label %helper.continue.968, label %frame.failure.0
helper.continue.968:
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 9, i32 %local.resolved.offset.948, i32 20, i32 %local.resolved.payload.950, i32 %local.resolved.owner.end.951, i32 %local.resolved.extent.949)
  %context.field.969 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.970 = load i32, ptr %context.field.969, align 4
  %runtime.ok.971 = icmp eq i32 %context.value.970, 0
  br i1 %runtime.ok.971, label %runtime.continue.972, label %frame.failure.0
runtime.continue.972:
  %context.field.973 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.974 = load i32, ptr %context.field.973, align 4
  %stack.sub.977 = sub i32 %descriptor.value.175, %descriptor.value.169
  %descriptor.owner.inside.975 = icmp ule i32 %descriptor.value.175, %context.value.974
  %descriptor.offset.inside.976 = icmp ule i32 %descriptor.value.169, %descriptor.value.175
  %descriptor.extent.inside.978 = icmp ule i32 %descriptor.value.171, %stack.sub.977
  %descriptor.payload.inside.979 = icmp ule i32 %descriptor.value.173, %descriptor.value.171
  %descriptor.owner.offset.valid.980 = and i1 %descriptor.owner.inside.975, %descriptor.offset.inside.976
  %descriptor.range.inside.982 = and i1 %descriptor.owner.offset.valid.980, %descriptor.extent.inside.978
  %descriptor.range.valid.981 = and i1 %descriptor.range.inside.982, %descriptor.payload.inside.979
  %descriptor.type.valid.983 = icmp eq i32 9, 9
  %descriptor.valid.984 = and i1 %descriptor.range.valid.981, %descriptor.type.valid.983
  br i1 %descriptor.valid.984, label %descriptor.valid.985, label %descriptor.invalid.986
descriptor.invalid.986:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.985:
  %descriptor.initialized.status.987 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.169, i32 %descriptor.value.171)
  %helper.ok.988 = icmp eq i32 %descriptor.initialized.status.987, 0
  br i1 %helper.ok.988, label %helper.continue.989, label %frame.failure.0
helper.continue.989:
  %context.field.990 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.991 = load i32, ptr %context.field.990, align 4
  %stack.sub.994 = sub i32 %local.resolved.owner.end.245, %local.resolved.offset.242
  %descriptor.owner.inside.992 = icmp ule i32 %local.resolved.owner.end.245, %context.value.991
  %descriptor.offset.inside.993 = icmp ule i32 %local.resolved.offset.242, %local.resolved.owner.end.245
  %descriptor.extent.inside.995 = icmp ule i32 %local.resolved.extent.243, %stack.sub.994
  %descriptor.payload.inside.996 = icmp ule i32 %local.resolved.payload.244, %local.resolved.extent.243
  %descriptor.owner.offset.valid.997 = and i1 %descriptor.owner.inside.992, %descriptor.offset.inside.993
  %descriptor.range.inside.999 = and i1 %descriptor.owner.offset.valid.997, %descriptor.extent.inside.995
  %descriptor.range.valid.998 = and i1 %descriptor.range.inside.999, %descriptor.payload.inside.996
  %descriptor.type.valid.1000 = icmp eq i32 6, 6
  %descriptor.valid.1001 = and i1 %descriptor.range.valid.998, %descriptor.type.valid.1000
  br i1 %descriptor.valid.1001, label %descriptor.valid.1002, label %descriptor.invalid.1003
descriptor.invalid.1003:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1002:
  %descriptor.initialized.status.1004 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.242, i32 %local.resolved.extent.243)
  %helper.ok.1005 = icmp eq i32 %descriptor.initialized.status.1004, 0
  br i1 %helper.ok.1005, label %helper.continue.1006, label %frame.failure.0
helper.continue.1006:
  %context.field.1007 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1008 = load i32, ptr %context.field.1007, align 4
  %stack.sub.1011 = sub i32 %stack.offset.613, %context.value.612
  %descriptor.owner.inside.1009 = icmp ule i32 %stack.offset.613, %context.value.1008
  %descriptor.offset.inside.1010 = icmp ule i32 %context.value.612, %stack.offset.613
  %descriptor.extent.inside.1012 = icmp ule i32 %stack.offset.610, %stack.sub.1011
  %descriptor.payload.inside.1013 = icmp ule i32 %stack.offset.608, %stack.offset.610
  %descriptor.owner.offset.valid.1014 = and i1 %descriptor.owner.inside.1009, %descriptor.offset.inside.1010
  %descriptor.range.inside.1016 = and i1 %descriptor.owner.offset.valid.1014, %descriptor.extent.inside.1012
  %descriptor.range.valid.1015 = and i1 %descriptor.range.inside.1016, %descriptor.payload.inside.1013
  %descriptor.type.valid.1017 = icmp eq i32 5, 5
  %descriptor.valid.1018 = and i1 %descriptor.range.valid.1015, %descriptor.type.valid.1017
  br i1 %descriptor.valid.1018, label %descriptor.valid.1019, label %descriptor.invalid.1020
descriptor.invalid.1020:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1019:
  %descriptor.initialized.status.1021 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.612, i32 %stack.offset.610)
  %helper.ok.1022 = icmp eq i32 %descriptor.initialized.status.1021, 0
  br i1 %helper.ok.1022, label %helper.continue.1023, label %frame.failure.0
helper.continue.1023:
  %context.field.1024 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1025 = load i32, ptr %context.field.1024, align 4
  %stack.sub.1028 = sub i32 %stack.offset.833, %context.value.830
  %descriptor.owner.inside.1026 = icmp ule i32 %stack.offset.833, %context.value.1025
  %descriptor.offset.inside.1027 = icmp ule i32 %context.value.830, %stack.offset.833
  %descriptor.extent.inside.1029 = icmp ule i32 %stack.offset.831, %stack.sub.1028
  %descriptor.payload.inside.1030 = icmp ule i32 %stack.offset.832, %stack.offset.831
  %descriptor.owner.offset.valid.1031 = and i1 %descriptor.owner.inside.1026, %descriptor.offset.inside.1027
  %descriptor.range.inside.1033 = and i1 %descriptor.owner.offset.valid.1031, %descriptor.extent.inside.1029
  %descriptor.range.valid.1032 = and i1 %descriptor.range.inside.1033, %descriptor.payload.inside.1030
  %descriptor.type.valid.1034 = icmp eq i32 10, 10
  %descriptor.valid.1035 = and i1 %descriptor.range.valid.1032, %descriptor.type.valid.1034
  br i1 %descriptor.valid.1035, label %descriptor.valid.1036, label %descriptor.invalid.1037
descriptor.invalid.1037:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1036:
  %descriptor.initialized.status.1038 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.830, i32 %stack.offset.831)
  %helper.ok.1039 = icmp eq i32 %descriptor.initialized.status.1038, 0
  br i1 %helper.ok.1039, label %helper.continue.1040, label %frame.failure.0
helper.continue.1040:
  %context.field.1041 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1042 = load i32, ptr %context.field.1041, align 4
  %stack.sub.1045 = sub i32 %local.resolved.owner.end.951, %local.resolved.offset.948
  %descriptor.owner.inside.1043 = icmp ule i32 %local.resolved.owner.end.951, %context.value.1042
  %descriptor.offset.inside.1044 = icmp ule i32 %local.resolved.offset.948, %local.resolved.owner.end.951
  %descriptor.extent.inside.1046 = icmp ule i32 %local.resolved.extent.949, %stack.sub.1045
  %descriptor.payload.inside.1047 = icmp ule i32 %local.resolved.payload.950, %local.resolved.extent.949
  %descriptor.owner.offset.valid.1048 = and i1 %descriptor.owner.inside.1043, %descriptor.offset.inside.1044
  %descriptor.range.inside.1050 = and i1 %descriptor.owner.offset.valid.1048, %descriptor.extent.inside.1046
  %descriptor.range.valid.1049 = and i1 %descriptor.range.inside.1050, %descriptor.payload.inside.1047
  %descriptor.type.valid.1051 = icmp eq i32 9, 9
  %descriptor.valid.1052 = and i1 %descriptor.range.valid.1049, %descriptor.type.valid.1051
  br i1 %descriptor.valid.1052, label %descriptor.valid.1053, label %descriptor.invalid.1054
descriptor.invalid.1054:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1053:
  %descriptor.initialized.status.1055 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.948, i32 %local.resolved.extent.949)
  %helper.ok.1056 = icmp eq i32 %descriptor.initialized.status.1055, 0
  br i1 %helper.ok.1056, label %helper.continue.1057, label %frame.failure.0
helper.continue.1057:
  %local.is.active.1058 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1058, label %local.descriptor.active.1059, label %local.descriptor.inactive.1060
local.descriptor.active.1059:
  %local.check.offset.1062 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1063 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1064 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1065 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1066 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1067 = load i32, ptr %context.field.1066, align 4
  %stack.sub.1070 = sub i32 %local.check.owner.end.1065, %local.check.offset.1062
  %descriptor.owner.inside.1068 = icmp ule i32 %local.check.owner.end.1065, %context.value.1067
  %descriptor.offset.inside.1069 = icmp ule i32 %local.check.offset.1062, %local.check.owner.end.1065
  %descriptor.extent.inside.1071 = icmp ule i32 %local.check.extent.1063, %stack.sub.1070
  %descriptor.payload.inside.1072 = icmp ule i32 %local.check.payload.1064, %local.check.extent.1063
  %descriptor.owner.offset.valid.1073 = and i1 %descriptor.owner.inside.1068, %descriptor.offset.inside.1069
  %descriptor.range.inside.1075 = and i1 %descriptor.owner.offset.valid.1073, %descriptor.extent.inside.1071
  %descriptor.range.valid.1074 = and i1 %descriptor.range.inside.1075, %descriptor.payload.inside.1072
  br i1 %descriptor.range.valid.1074, label %descriptor.valid.1076, label %descriptor.invalid.1077
descriptor.invalid.1077:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1076:
  %descriptor.initialized.status.1078 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1062, i32 %local.check.extent.1063)
  %helper.ok.1079 = icmp eq i32 %descriptor.initialized.status.1078, 0
  br i1 %helper.ok.1079, label %helper.continue.1080, label %frame.failure.0
helper.continue.1080:
  br label %local.descriptor.checked.1061
local.descriptor.inactive.1060:
  br label %local.descriptor.checked.1061
local.descriptor.checked.1061:
  %step.status.1081 = call i32 @al_owning_charge_step(ptr %ctx, i32 18)
  %helper.ok.1082 = icmp eq i32 %step.status.1081, 0
  br i1 %helper.ok.1082, label %helper.continue.1083, label %frame.failure.0
helper.continue.1083:
  %context.field.1084 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1085 = load i32, ptr %context.field.1084, align 4
  %stack.offset.1086 = add i32 8, %local.resolved.extent.949
  %stack.offset.1087 = add i32 8, %local.resolved.payload.950
  %stack.offset.1088 = add i32 %context.value.1085, %stack.offset.1086
  %reserve.status.1089 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1088, i32 19)
  %reserve.ok.1090 = icmp eq i32 %reserve.status.1089, 0
  br i1 %reserve.ok.1090, label %reserve.continue.1091, label %frame.failure.0
reserve.continue.1091:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.1085, i64 0, i32 11)
  %context.field.1092 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1093 = load i32, ptr %context.field.1092, align 4
  %runtime.ok.1094 = icmp eq i32 %context.value.1093, 0
  br i1 %runtime.ok.1094, label %runtime.continue.1095, label %frame.failure.0
runtime.continue.1095:
  %stack.offset.1096 = add i32 %context.value.1085, 8
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.1096, i32 %local.resolved.offset.948, i32 %local.resolved.extent.949, i32 %local.resolved.payload.950, i32 9, i32 6)
  %context.field.1097 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1098 = load i32, ptr %context.field.1097, align 4
  %runtime.ok.1099 = icmp eq i32 %context.value.1098, 0
  br i1 %runtime.ok.1099, label %runtime.continue.1100, label %frame.failure.0
runtime.continue.1100:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.1101 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1102 = load i32, ptr %context.field.1101, align 4
  %runtime.ok.1103 = icmp eq i32 %context.value.1102, 0
  br i1 %runtime.ok.1103, label %runtime.continue.1104, label %frame.failure.0
runtime.continue.1104:
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 11, i32 %context.value.1085, i32 %stack.offset.1086, i32 %stack.offset.1087, i32 %local.resolved.offset.948, i32 %local.resolved.extent.949)
  %context.field.1105 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1106 = load i32, ptr %context.field.1105, align 4
  %runtime.ok.1107 = icmp eq i32 %context.value.1106, 0
  br i1 %runtime.ok.1107, label %runtime.continue.1108, label %frame.failure.0
runtime.continue.1108:
  %context.field.1109 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1110 = load i32, ptr %context.field.1109, align 4
  %stack.sub.1113 = sub i32 %descriptor.value.175, %descriptor.value.169
  %descriptor.owner.inside.1111 = icmp ule i32 %descriptor.value.175, %context.value.1110
  %descriptor.offset.inside.1112 = icmp ule i32 %descriptor.value.169, %descriptor.value.175
  %descriptor.extent.inside.1114 = icmp ule i32 %descriptor.value.171, %stack.sub.1113
  %descriptor.payload.inside.1115 = icmp ule i32 %descriptor.value.173, %descriptor.value.171
  %descriptor.owner.offset.valid.1116 = and i1 %descriptor.owner.inside.1111, %descriptor.offset.inside.1112
  %descriptor.range.inside.1118 = and i1 %descriptor.owner.offset.valid.1116, %descriptor.extent.inside.1114
  %descriptor.range.valid.1117 = and i1 %descriptor.range.inside.1118, %descriptor.payload.inside.1115
  %descriptor.type.valid.1119 = icmp eq i32 9, 9
  %descriptor.valid.1120 = and i1 %descriptor.range.valid.1117, %descriptor.type.valid.1119
  br i1 %descriptor.valid.1120, label %descriptor.valid.1121, label %descriptor.invalid.1122
descriptor.invalid.1122:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1121:
  %descriptor.initialized.status.1123 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.169, i32 %descriptor.value.171)
  %helper.ok.1124 = icmp eq i32 %descriptor.initialized.status.1123, 0
  br i1 %helper.ok.1124, label %helper.continue.1125, label %frame.failure.0
helper.continue.1125:
  %context.field.1126 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1127 = load i32, ptr %context.field.1126, align 4
  %stack.sub.1130 = sub i32 %local.resolved.owner.end.245, %local.resolved.offset.242
  %descriptor.owner.inside.1128 = icmp ule i32 %local.resolved.owner.end.245, %context.value.1127
  %descriptor.offset.inside.1129 = icmp ule i32 %local.resolved.offset.242, %local.resolved.owner.end.245
  %descriptor.extent.inside.1131 = icmp ule i32 %local.resolved.extent.243, %stack.sub.1130
  %descriptor.payload.inside.1132 = icmp ule i32 %local.resolved.payload.244, %local.resolved.extent.243
  %descriptor.owner.offset.valid.1133 = and i1 %descriptor.owner.inside.1128, %descriptor.offset.inside.1129
  %descriptor.range.inside.1135 = and i1 %descriptor.owner.offset.valid.1133, %descriptor.extent.inside.1131
  %descriptor.range.valid.1134 = and i1 %descriptor.range.inside.1135, %descriptor.payload.inside.1132
  %descriptor.type.valid.1136 = icmp eq i32 6, 6
  %descriptor.valid.1137 = and i1 %descriptor.range.valid.1134, %descriptor.type.valid.1136
  br i1 %descriptor.valid.1137, label %descriptor.valid.1138, label %descriptor.invalid.1139
descriptor.invalid.1139:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1138:
  %descriptor.initialized.status.1140 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.242, i32 %local.resolved.extent.243)
  %helper.ok.1141 = icmp eq i32 %descriptor.initialized.status.1140, 0
  br i1 %helper.ok.1141, label %helper.continue.1142, label %frame.failure.0
helper.continue.1142:
  %context.field.1143 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1144 = load i32, ptr %context.field.1143, align 4
  %stack.sub.1147 = sub i32 %stack.offset.613, %context.value.612
  %descriptor.owner.inside.1145 = icmp ule i32 %stack.offset.613, %context.value.1144
  %descriptor.offset.inside.1146 = icmp ule i32 %context.value.612, %stack.offset.613
  %descriptor.extent.inside.1148 = icmp ule i32 %stack.offset.610, %stack.sub.1147
  %descriptor.payload.inside.1149 = icmp ule i32 %stack.offset.608, %stack.offset.610
  %descriptor.owner.offset.valid.1150 = and i1 %descriptor.owner.inside.1145, %descriptor.offset.inside.1146
  %descriptor.range.inside.1152 = and i1 %descriptor.owner.offset.valid.1150, %descriptor.extent.inside.1148
  %descriptor.range.valid.1151 = and i1 %descriptor.range.inside.1152, %descriptor.payload.inside.1149
  %descriptor.type.valid.1153 = icmp eq i32 5, 5
  %descriptor.valid.1154 = and i1 %descriptor.range.valid.1151, %descriptor.type.valid.1153
  br i1 %descriptor.valid.1154, label %descriptor.valid.1155, label %descriptor.invalid.1156
descriptor.invalid.1156:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1155:
  %descriptor.initialized.status.1157 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.612, i32 %stack.offset.610)
  %helper.ok.1158 = icmp eq i32 %descriptor.initialized.status.1157, 0
  br i1 %helper.ok.1158, label %helper.continue.1159, label %frame.failure.0
helper.continue.1159:
  %context.field.1160 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1161 = load i32, ptr %context.field.1160, align 4
  %stack.sub.1164 = sub i32 %stack.offset.833, %context.value.830
  %descriptor.owner.inside.1162 = icmp ule i32 %stack.offset.833, %context.value.1161
  %descriptor.offset.inside.1163 = icmp ule i32 %context.value.830, %stack.offset.833
  %descriptor.extent.inside.1165 = icmp ule i32 %stack.offset.831, %stack.sub.1164
  %descriptor.payload.inside.1166 = icmp ule i32 %stack.offset.832, %stack.offset.831
  %descriptor.owner.offset.valid.1167 = and i1 %descriptor.owner.inside.1162, %descriptor.offset.inside.1163
  %descriptor.range.inside.1169 = and i1 %descriptor.owner.offset.valid.1167, %descriptor.extent.inside.1165
  %descriptor.range.valid.1168 = and i1 %descriptor.range.inside.1169, %descriptor.payload.inside.1166
  %descriptor.type.valid.1170 = icmp eq i32 10, 10
  %descriptor.valid.1171 = and i1 %descriptor.range.valid.1168, %descriptor.type.valid.1170
  br i1 %descriptor.valid.1171, label %descriptor.valid.1172, label %descriptor.invalid.1173
descriptor.invalid.1173:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1172:
  %descriptor.initialized.status.1174 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.830, i32 %stack.offset.831)
  %helper.ok.1175 = icmp eq i32 %descriptor.initialized.status.1174, 0
  br i1 %helper.ok.1175, label %helper.continue.1176, label %frame.failure.0
helper.continue.1176:
  %context.field.1177 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1178 = load i32, ptr %context.field.1177, align 4
  %stack.sub.1181 = sub i32 %stack.offset.1088, %context.value.1085
  %descriptor.owner.inside.1179 = icmp ule i32 %stack.offset.1088, %context.value.1178
  %descriptor.offset.inside.1180 = icmp ule i32 %context.value.1085, %stack.offset.1088
  %descriptor.extent.inside.1182 = icmp ule i32 %stack.offset.1086, %stack.sub.1181
  %descriptor.payload.inside.1183 = icmp ule i32 %stack.offset.1087, %stack.offset.1086
  %descriptor.owner.offset.valid.1184 = and i1 %descriptor.owner.inside.1179, %descriptor.offset.inside.1180
  %descriptor.range.inside.1186 = and i1 %descriptor.owner.offset.valid.1184, %descriptor.extent.inside.1182
  %descriptor.range.valid.1185 = and i1 %descriptor.range.inside.1186, %descriptor.payload.inside.1183
  %descriptor.type.valid.1187 = icmp eq i32 11, 11
  %descriptor.valid.1188 = and i1 %descriptor.range.valid.1185, %descriptor.type.valid.1187
  br i1 %descriptor.valid.1188, label %descriptor.valid.1189, label %descriptor.invalid.1190
descriptor.invalid.1190:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1189:
  %descriptor.initialized.status.1191 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.1085, i32 %stack.offset.1086)
  %helper.ok.1192 = icmp eq i32 %descriptor.initialized.status.1191, 0
  br i1 %helper.ok.1192, label %helper.continue.1193, label %frame.failure.0
helper.continue.1193:
  %local.is.active.1194 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1194, label %local.descriptor.active.1195, label %local.descriptor.inactive.1196
local.descriptor.active.1195:
  %local.check.offset.1198 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1199 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1200 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1201 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1202 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1203 = load i32, ptr %context.field.1202, align 4
  %stack.sub.1206 = sub i32 %local.check.owner.end.1201, %local.check.offset.1198
  %descriptor.owner.inside.1204 = icmp ule i32 %local.check.owner.end.1201, %context.value.1203
  %descriptor.offset.inside.1205 = icmp ule i32 %local.check.offset.1198, %local.check.owner.end.1201
  %descriptor.extent.inside.1207 = icmp ule i32 %local.check.extent.1199, %stack.sub.1206
  %descriptor.payload.inside.1208 = icmp ule i32 %local.check.payload.1200, %local.check.extent.1199
  %descriptor.owner.offset.valid.1209 = and i1 %descriptor.owner.inside.1204, %descriptor.offset.inside.1205
  %descriptor.range.inside.1211 = and i1 %descriptor.owner.offset.valid.1209, %descriptor.extent.inside.1207
  %descriptor.range.valid.1210 = and i1 %descriptor.range.inside.1211, %descriptor.payload.inside.1208
  br i1 %descriptor.range.valid.1210, label %descriptor.valid.1212, label %descriptor.invalid.1213
descriptor.invalid.1213:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1212:
  %descriptor.initialized.status.1214 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1198, i32 %local.check.extent.1199)
  %helper.ok.1215 = icmp eq i32 %descriptor.initialized.status.1214, 0
  br i1 %helper.ok.1215, label %helper.continue.1216, label %frame.failure.0
helper.continue.1216:
  br label %local.descriptor.checked.1197
local.descriptor.inactive.1196:
  br label %local.descriptor.checked.1197
local.descriptor.checked.1197:
  %step.status.1217 = call i32 @al_owning_charge_step(ptr %ctx, i32 20)
  %helper.ok.1218 = icmp eq i32 %step.status.1217, 0
  br i1 %helper.ok.1218, label %helper.continue.1219, label %frame.failure.0
helper.continue.1219:
  %context.field.1220 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1221 = load i32, ptr %context.field.1220, align 4
  %stack.offset.1222 = add i32 %context.value.1221, 8
  %reserve.status.1223 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1222, i32 21)
  %reserve.ok.1224 = icmp eq i32 %reserve.status.1223, 0
  br i1 %reserve.ok.1224, label %reserve.continue.1225, label %frame.failure.0
reserve.continue.1225:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.1221, i64 11, i32 1)
  %context.field.1226 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1227 = load i32, ptr %context.field.1226, align 4
  %runtime.ok.1228 = icmp eq i32 %context.value.1227, 0
  br i1 %runtime.ok.1228, label %runtime.continue.1229, label %frame.failure.0
runtime.continue.1229:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.1230 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1231 = load i32, ptr %context.field.1230, align 4
  %runtime.ok.1232 = icmp eq i32 %context.value.1231, 0
  br i1 %runtime.ok.1232, label %runtime.continue.1233, label %frame.failure.0
runtime.continue.1233:
  %context.field.1234 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1235 = load i32, ptr %context.field.1234, align 4
  %stack.sub.1238 = sub i32 %descriptor.value.175, %descriptor.value.169
  %descriptor.owner.inside.1236 = icmp ule i32 %descriptor.value.175, %context.value.1235
  %descriptor.offset.inside.1237 = icmp ule i32 %descriptor.value.169, %descriptor.value.175
  %descriptor.extent.inside.1239 = icmp ule i32 %descriptor.value.171, %stack.sub.1238
  %descriptor.payload.inside.1240 = icmp ule i32 %descriptor.value.173, %descriptor.value.171
  %descriptor.owner.offset.valid.1241 = and i1 %descriptor.owner.inside.1236, %descriptor.offset.inside.1237
  %descriptor.range.inside.1243 = and i1 %descriptor.owner.offset.valid.1241, %descriptor.extent.inside.1239
  %descriptor.range.valid.1242 = and i1 %descriptor.range.inside.1243, %descriptor.payload.inside.1240
  %descriptor.type.valid.1244 = icmp eq i32 9, 9
  %descriptor.valid.1245 = and i1 %descriptor.range.valid.1242, %descriptor.type.valid.1244
  br i1 %descriptor.valid.1245, label %descriptor.valid.1246, label %descriptor.invalid.1247
descriptor.invalid.1247:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1246:
  %descriptor.initialized.status.1248 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.169, i32 %descriptor.value.171)
  %helper.ok.1249 = icmp eq i32 %descriptor.initialized.status.1248, 0
  br i1 %helper.ok.1249, label %helper.continue.1250, label %frame.failure.0
helper.continue.1250:
  %context.field.1251 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1252 = load i32, ptr %context.field.1251, align 4
  %stack.sub.1255 = sub i32 %local.resolved.owner.end.245, %local.resolved.offset.242
  %descriptor.owner.inside.1253 = icmp ule i32 %local.resolved.owner.end.245, %context.value.1252
  %descriptor.offset.inside.1254 = icmp ule i32 %local.resolved.offset.242, %local.resolved.owner.end.245
  %descriptor.extent.inside.1256 = icmp ule i32 %local.resolved.extent.243, %stack.sub.1255
  %descriptor.payload.inside.1257 = icmp ule i32 %local.resolved.payload.244, %local.resolved.extent.243
  %descriptor.owner.offset.valid.1258 = and i1 %descriptor.owner.inside.1253, %descriptor.offset.inside.1254
  %descriptor.range.inside.1260 = and i1 %descriptor.owner.offset.valid.1258, %descriptor.extent.inside.1256
  %descriptor.range.valid.1259 = and i1 %descriptor.range.inside.1260, %descriptor.payload.inside.1257
  %descriptor.type.valid.1261 = icmp eq i32 6, 6
  %descriptor.valid.1262 = and i1 %descriptor.range.valid.1259, %descriptor.type.valid.1261
  br i1 %descriptor.valid.1262, label %descriptor.valid.1263, label %descriptor.invalid.1264
descriptor.invalid.1264:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1263:
  %descriptor.initialized.status.1265 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.242, i32 %local.resolved.extent.243)
  %helper.ok.1266 = icmp eq i32 %descriptor.initialized.status.1265, 0
  br i1 %helper.ok.1266, label %helper.continue.1267, label %frame.failure.0
helper.continue.1267:
  %context.field.1268 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1269 = load i32, ptr %context.field.1268, align 4
  %stack.sub.1272 = sub i32 %stack.offset.613, %context.value.612
  %descriptor.owner.inside.1270 = icmp ule i32 %stack.offset.613, %context.value.1269
  %descriptor.offset.inside.1271 = icmp ule i32 %context.value.612, %stack.offset.613
  %descriptor.extent.inside.1273 = icmp ule i32 %stack.offset.610, %stack.sub.1272
  %descriptor.payload.inside.1274 = icmp ule i32 %stack.offset.608, %stack.offset.610
  %descriptor.owner.offset.valid.1275 = and i1 %descriptor.owner.inside.1270, %descriptor.offset.inside.1271
  %descriptor.range.inside.1277 = and i1 %descriptor.owner.offset.valid.1275, %descriptor.extent.inside.1273
  %descriptor.range.valid.1276 = and i1 %descriptor.range.inside.1277, %descriptor.payload.inside.1274
  %descriptor.type.valid.1278 = icmp eq i32 5, 5
  %descriptor.valid.1279 = and i1 %descriptor.range.valid.1276, %descriptor.type.valid.1278
  br i1 %descriptor.valid.1279, label %descriptor.valid.1280, label %descriptor.invalid.1281
descriptor.invalid.1281:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1280:
  %descriptor.initialized.status.1282 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.612, i32 %stack.offset.610)
  %helper.ok.1283 = icmp eq i32 %descriptor.initialized.status.1282, 0
  br i1 %helper.ok.1283, label %helper.continue.1284, label %frame.failure.0
helper.continue.1284:
  %context.field.1285 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1286 = load i32, ptr %context.field.1285, align 4
  %stack.sub.1289 = sub i32 %stack.offset.833, %context.value.830
  %descriptor.owner.inside.1287 = icmp ule i32 %stack.offset.833, %context.value.1286
  %descriptor.offset.inside.1288 = icmp ule i32 %context.value.830, %stack.offset.833
  %descriptor.extent.inside.1290 = icmp ule i32 %stack.offset.831, %stack.sub.1289
  %descriptor.payload.inside.1291 = icmp ule i32 %stack.offset.832, %stack.offset.831
  %descriptor.owner.offset.valid.1292 = and i1 %descriptor.owner.inside.1287, %descriptor.offset.inside.1288
  %descriptor.range.inside.1294 = and i1 %descriptor.owner.offset.valid.1292, %descriptor.extent.inside.1290
  %descriptor.range.valid.1293 = and i1 %descriptor.range.inside.1294, %descriptor.payload.inside.1291
  %descriptor.type.valid.1295 = icmp eq i32 10, 10
  %descriptor.valid.1296 = and i1 %descriptor.range.valid.1293, %descriptor.type.valid.1295
  br i1 %descriptor.valid.1296, label %descriptor.valid.1297, label %descriptor.invalid.1298
descriptor.invalid.1298:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1297:
  %descriptor.initialized.status.1299 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.830, i32 %stack.offset.831)
  %helper.ok.1300 = icmp eq i32 %descriptor.initialized.status.1299, 0
  br i1 %helper.ok.1300, label %helper.continue.1301, label %frame.failure.0
helper.continue.1301:
  %context.field.1302 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1303 = load i32, ptr %context.field.1302, align 4
  %stack.sub.1306 = sub i32 %stack.offset.1088, %context.value.1085
  %descriptor.owner.inside.1304 = icmp ule i32 %stack.offset.1088, %context.value.1303
  %descriptor.offset.inside.1305 = icmp ule i32 %context.value.1085, %stack.offset.1088
  %descriptor.extent.inside.1307 = icmp ule i32 %stack.offset.1086, %stack.sub.1306
  %descriptor.payload.inside.1308 = icmp ule i32 %stack.offset.1087, %stack.offset.1086
  %descriptor.owner.offset.valid.1309 = and i1 %descriptor.owner.inside.1304, %descriptor.offset.inside.1305
  %descriptor.range.inside.1311 = and i1 %descriptor.owner.offset.valid.1309, %descriptor.extent.inside.1307
  %descriptor.range.valid.1310 = and i1 %descriptor.range.inside.1311, %descriptor.payload.inside.1308
  %descriptor.type.valid.1312 = icmp eq i32 11, 11
  %descriptor.valid.1313 = and i1 %descriptor.range.valid.1310, %descriptor.type.valid.1312
  br i1 %descriptor.valid.1313, label %descriptor.valid.1314, label %descriptor.invalid.1315
descriptor.invalid.1315:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1314:
  %descriptor.initialized.status.1316 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.1085, i32 %stack.offset.1086)
  %helper.ok.1317 = icmp eq i32 %descriptor.initialized.status.1316, 0
  br i1 %helper.ok.1317, label %helper.continue.1318, label %frame.failure.0
helper.continue.1318:
  %context.field.1319 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1320 = load i32, ptr %context.field.1319, align 4
  %stack.sub.1323 = sub i32 %stack.offset.1222, %context.value.1221
  %descriptor.owner.inside.1321 = icmp ule i32 %stack.offset.1222, %context.value.1320
  %descriptor.offset.inside.1322 = icmp ule i32 %context.value.1221, %stack.offset.1222
  %descriptor.extent.inside.1324 = icmp ule i32 8, %stack.sub.1323
  %descriptor.payload.inside.1325 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.1326 = and i1 %descriptor.owner.inside.1321, %descriptor.offset.inside.1322
  %descriptor.range.inside.1328 = and i1 %descriptor.owner.offset.valid.1326, %descriptor.extent.inside.1324
  %descriptor.range.valid.1327 = and i1 %descriptor.range.inside.1328, %descriptor.payload.inside.1325
  %descriptor.type.valid.1329 = icmp eq i32 1, 1
  %descriptor.valid.1330 = and i1 %descriptor.range.valid.1327, %descriptor.type.valid.1329
  br i1 %descriptor.valid.1330, label %descriptor.valid.1331, label %descriptor.invalid.1332
descriptor.invalid.1332:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1331:
  %descriptor.initialized.status.1333 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.1221, i32 8)
  %helper.ok.1334 = icmp eq i32 %descriptor.initialized.status.1333, 0
  br i1 %helper.ok.1334, label %helper.continue.1335, label %frame.failure.0
helper.continue.1335:
  %local.is.active.1336 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1336, label %local.descriptor.active.1337, label %local.descriptor.inactive.1338
local.descriptor.active.1337:
  %local.check.offset.1340 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1341 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1342 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1343 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1344 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1345 = load i32, ptr %context.field.1344, align 4
  %stack.sub.1348 = sub i32 %local.check.owner.end.1343, %local.check.offset.1340
  %descriptor.owner.inside.1346 = icmp ule i32 %local.check.owner.end.1343, %context.value.1345
  %descriptor.offset.inside.1347 = icmp ule i32 %local.check.offset.1340, %local.check.owner.end.1343
  %descriptor.extent.inside.1349 = icmp ule i32 %local.check.extent.1341, %stack.sub.1348
  %descriptor.payload.inside.1350 = icmp ule i32 %local.check.payload.1342, %local.check.extent.1341
  %descriptor.owner.offset.valid.1351 = and i1 %descriptor.owner.inside.1346, %descriptor.offset.inside.1347
  %descriptor.range.inside.1353 = and i1 %descriptor.owner.offset.valid.1351, %descriptor.extent.inside.1349
  %descriptor.range.valid.1352 = and i1 %descriptor.range.inside.1353, %descriptor.payload.inside.1350
  br i1 %descriptor.range.valid.1352, label %descriptor.valid.1354, label %descriptor.invalid.1355
descriptor.invalid.1355:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1354:
  %descriptor.initialized.status.1356 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1340, i32 %local.check.extent.1341)
  %helper.ok.1357 = icmp eq i32 %descriptor.initialized.status.1356, 0
  br i1 %helper.ok.1357, label %helper.continue.1358, label %frame.failure.0
helper.continue.1358:
  br label %local.descriptor.checked.1339
local.descriptor.inactive.1338:
  br label %local.descriptor.checked.1339
local.descriptor.checked.1339:
  %step.status.1359 = call i32 @al_owning_charge_step(ptr %ctx, i32 22)
  %helper.ok.1360 = icmp eq i32 %step.status.1359, 0
  br i1 %helper.ok.1360, label %helper.continue.1361, label %frame.failure.0
helper.continue.1361:
  %context.field.1362 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1363 = load i32, ptr %context.field.1362, align 4
  %stack.offset.1364 = add i32 8, 8
  %stack.offset.1365 = add i32 8, 8
  %stack.offset.1366 = add i32 %context.value.1363, %stack.offset.1364
  %reserve.status.1367 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.1366, i32 23)
  %reserve.ok.1368 = icmp eq i32 %reserve.status.1367, 0
  br i1 %reserve.ok.1368, label %reserve.continue.1369, label %frame.failure.0
reserve.continue.1369:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.1363, i64 1, i32 11)
  %context.field.1370 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1371 = load i32, ptr %context.field.1370, align 4
  %runtime.ok.1372 = icmp eq i32 %context.value.1371, 0
  br i1 %runtime.ok.1372, label %runtime.continue.1373, label %frame.failure.0
runtime.continue.1373:
  %stack.offset.1374 = add i32 %context.value.1363, 8
  call void @al_owning_copy_range(ptr %ctx, i32 %stack.offset.1374, i32 %context.value.1221, i32 8, i32 8, i32 1, i32 6)
  %context.field.1375 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1376 = load i32, ptr %context.field.1375, align 4
  %runtime.ok.1377 = icmp eq i32 %context.value.1376, 0
  br i1 %runtime.ok.1377, label %runtime.continue.1378, label %frame.failure.0
runtime.continue.1378:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.1379 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1380 = load i32, ptr %context.field.1379, align 4
  %runtime.ok.1381 = icmp eq i32 %context.value.1380, 0
  br i1 %runtime.ok.1381, label %runtime.continue.1382, label %frame.failure.0
runtime.continue.1382:
  call void @al_owning_record_layout(ptr %ctx, i32 6, i32 11, i32 %context.value.1363, i32 %stack.offset.1364, i32 %stack.offset.1365, i32 %context.value.1221, i32 8)
  %context.field.1383 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1384 = load i32, ptr %context.field.1383, align 4
  %runtime.ok.1385 = icmp eq i32 %context.value.1384, 0
  br i1 %runtime.ok.1385, label %runtime.continue.1386, label %frame.failure.0
runtime.continue.1386:
  %context.field.1387 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1388 = load i32, ptr %context.field.1387, align 4
  %stack.sub.1391 = sub i32 %descriptor.value.175, %descriptor.value.169
  %descriptor.owner.inside.1389 = icmp ule i32 %descriptor.value.175, %context.value.1388
  %descriptor.offset.inside.1390 = icmp ule i32 %descriptor.value.169, %descriptor.value.175
  %descriptor.extent.inside.1392 = icmp ule i32 %descriptor.value.171, %stack.sub.1391
  %descriptor.payload.inside.1393 = icmp ule i32 %descriptor.value.173, %descriptor.value.171
  %descriptor.owner.offset.valid.1394 = and i1 %descriptor.owner.inside.1389, %descriptor.offset.inside.1390
  %descriptor.range.inside.1396 = and i1 %descriptor.owner.offset.valid.1394, %descriptor.extent.inside.1392
  %descriptor.range.valid.1395 = and i1 %descriptor.range.inside.1396, %descriptor.payload.inside.1393
  %descriptor.type.valid.1397 = icmp eq i32 9, 9
  %descriptor.valid.1398 = and i1 %descriptor.range.valid.1395, %descriptor.type.valid.1397
  br i1 %descriptor.valid.1398, label %descriptor.valid.1399, label %descriptor.invalid.1400
descriptor.invalid.1400:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1399:
  %descriptor.initialized.status.1401 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.169, i32 %descriptor.value.171)
  %helper.ok.1402 = icmp eq i32 %descriptor.initialized.status.1401, 0
  br i1 %helper.ok.1402, label %helper.continue.1403, label %frame.failure.0
helper.continue.1403:
  %context.field.1404 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1405 = load i32, ptr %context.field.1404, align 4
  %stack.sub.1408 = sub i32 %local.resolved.owner.end.245, %local.resolved.offset.242
  %descriptor.owner.inside.1406 = icmp ule i32 %local.resolved.owner.end.245, %context.value.1405
  %descriptor.offset.inside.1407 = icmp ule i32 %local.resolved.offset.242, %local.resolved.owner.end.245
  %descriptor.extent.inside.1409 = icmp ule i32 %local.resolved.extent.243, %stack.sub.1408
  %descriptor.payload.inside.1410 = icmp ule i32 %local.resolved.payload.244, %local.resolved.extent.243
  %descriptor.owner.offset.valid.1411 = and i1 %descriptor.owner.inside.1406, %descriptor.offset.inside.1407
  %descriptor.range.inside.1413 = and i1 %descriptor.owner.offset.valid.1411, %descriptor.extent.inside.1409
  %descriptor.range.valid.1412 = and i1 %descriptor.range.inside.1413, %descriptor.payload.inside.1410
  %descriptor.type.valid.1414 = icmp eq i32 6, 6
  %descriptor.valid.1415 = and i1 %descriptor.range.valid.1412, %descriptor.type.valid.1414
  br i1 %descriptor.valid.1415, label %descriptor.valid.1416, label %descriptor.invalid.1417
descriptor.invalid.1417:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1416:
  %descriptor.initialized.status.1418 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.resolved.offset.242, i32 %local.resolved.extent.243)
  %helper.ok.1419 = icmp eq i32 %descriptor.initialized.status.1418, 0
  br i1 %helper.ok.1419, label %helper.continue.1420, label %frame.failure.0
helper.continue.1420:
  %context.field.1421 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1422 = load i32, ptr %context.field.1421, align 4
  %stack.sub.1425 = sub i32 %stack.offset.613, %context.value.612
  %descriptor.owner.inside.1423 = icmp ule i32 %stack.offset.613, %context.value.1422
  %descriptor.offset.inside.1424 = icmp ule i32 %context.value.612, %stack.offset.613
  %descriptor.extent.inside.1426 = icmp ule i32 %stack.offset.610, %stack.sub.1425
  %descriptor.payload.inside.1427 = icmp ule i32 %stack.offset.608, %stack.offset.610
  %descriptor.owner.offset.valid.1428 = and i1 %descriptor.owner.inside.1423, %descriptor.offset.inside.1424
  %descriptor.range.inside.1430 = and i1 %descriptor.owner.offset.valid.1428, %descriptor.extent.inside.1426
  %descriptor.range.valid.1429 = and i1 %descriptor.range.inside.1430, %descriptor.payload.inside.1427
  %descriptor.type.valid.1431 = icmp eq i32 5, 5
  %descriptor.valid.1432 = and i1 %descriptor.range.valid.1429, %descriptor.type.valid.1431
  br i1 %descriptor.valid.1432, label %descriptor.valid.1433, label %descriptor.invalid.1434
descriptor.invalid.1434:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1433:
  %descriptor.initialized.status.1435 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.612, i32 %stack.offset.610)
  %helper.ok.1436 = icmp eq i32 %descriptor.initialized.status.1435, 0
  br i1 %helper.ok.1436, label %helper.continue.1437, label %frame.failure.0
helper.continue.1437:
  %context.field.1438 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1439 = load i32, ptr %context.field.1438, align 4
  %stack.sub.1442 = sub i32 %stack.offset.833, %context.value.830
  %descriptor.owner.inside.1440 = icmp ule i32 %stack.offset.833, %context.value.1439
  %descriptor.offset.inside.1441 = icmp ule i32 %context.value.830, %stack.offset.833
  %descriptor.extent.inside.1443 = icmp ule i32 %stack.offset.831, %stack.sub.1442
  %descriptor.payload.inside.1444 = icmp ule i32 %stack.offset.832, %stack.offset.831
  %descriptor.owner.offset.valid.1445 = and i1 %descriptor.owner.inside.1440, %descriptor.offset.inside.1441
  %descriptor.range.inside.1447 = and i1 %descriptor.owner.offset.valid.1445, %descriptor.extent.inside.1443
  %descriptor.range.valid.1446 = and i1 %descriptor.range.inside.1447, %descriptor.payload.inside.1444
  %descriptor.type.valid.1448 = icmp eq i32 10, 10
  %descriptor.valid.1449 = and i1 %descriptor.range.valid.1446, %descriptor.type.valid.1448
  br i1 %descriptor.valid.1449, label %descriptor.valid.1450, label %descriptor.invalid.1451
descriptor.invalid.1451:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1450:
  %descriptor.initialized.status.1452 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.830, i32 %stack.offset.831)
  %helper.ok.1453 = icmp eq i32 %descriptor.initialized.status.1452, 0
  br i1 %helper.ok.1453, label %helper.continue.1454, label %frame.failure.0
helper.continue.1454:
  %context.field.1455 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1456 = load i32, ptr %context.field.1455, align 4
  %stack.sub.1459 = sub i32 %stack.offset.1088, %context.value.1085
  %descriptor.owner.inside.1457 = icmp ule i32 %stack.offset.1088, %context.value.1456
  %descriptor.offset.inside.1458 = icmp ule i32 %context.value.1085, %stack.offset.1088
  %descriptor.extent.inside.1460 = icmp ule i32 %stack.offset.1086, %stack.sub.1459
  %descriptor.payload.inside.1461 = icmp ule i32 %stack.offset.1087, %stack.offset.1086
  %descriptor.owner.offset.valid.1462 = and i1 %descriptor.owner.inside.1457, %descriptor.offset.inside.1458
  %descriptor.range.inside.1464 = and i1 %descriptor.owner.offset.valid.1462, %descriptor.extent.inside.1460
  %descriptor.range.valid.1463 = and i1 %descriptor.range.inside.1464, %descriptor.payload.inside.1461
  %descriptor.type.valid.1465 = icmp eq i32 11, 11
  %descriptor.valid.1466 = and i1 %descriptor.range.valid.1463, %descriptor.type.valid.1465
  br i1 %descriptor.valid.1466, label %descriptor.valid.1467, label %descriptor.invalid.1468
descriptor.invalid.1468:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1467:
  %descriptor.initialized.status.1469 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.1085, i32 %stack.offset.1086)
  %helper.ok.1470 = icmp eq i32 %descriptor.initialized.status.1469, 0
  br i1 %helper.ok.1470, label %helper.continue.1471, label %frame.failure.0
helper.continue.1471:
  %context.field.1472 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1473 = load i32, ptr %context.field.1472, align 4
  %stack.sub.1476 = sub i32 %stack.offset.1366, %context.value.1363
  %descriptor.owner.inside.1474 = icmp ule i32 %stack.offset.1366, %context.value.1473
  %descriptor.offset.inside.1475 = icmp ule i32 %context.value.1363, %stack.offset.1366
  %descriptor.extent.inside.1477 = icmp ule i32 %stack.offset.1364, %stack.sub.1476
  %descriptor.payload.inside.1478 = icmp ule i32 %stack.offset.1365, %stack.offset.1364
  %descriptor.owner.offset.valid.1479 = and i1 %descriptor.owner.inside.1474, %descriptor.offset.inside.1475
  %descriptor.range.inside.1481 = and i1 %descriptor.owner.offset.valid.1479, %descriptor.extent.inside.1477
  %descriptor.range.valid.1480 = and i1 %descriptor.range.inside.1481, %descriptor.payload.inside.1478
  %descriptor.type.valid.1482 = icmp eq i32 11, 11
  %descriptor.valid.1483 = and i1 %descriptor.range.valid.1480, %descriptor.type.valid.1482
  br i1 %descriptor.valid.1483, label %descriptor.valid.1484, label %descriptor.invalid.1485
descriptor.invalid.1485:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1484:
  %descriptor.initialized.status.1486 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.1363, i32 %stack.offset.1364)
  %helper.ok.1487 = icmp eq i32 %descriptor.initialized.status.1486, 0
  br i1 %helper.ok.1487, label %helper.continue.1488, label %frame.failure.0
helper.continue.1488:
  %local.is.active.1489 = load i1, ptr %local.active.2, align 1
  br i1 %local.is.active.1489, label %local.descriptor.active.1490, label %local.descriptor.inactive.1491
local.descriptor.active.1490:
  %local.check.offset.1493 = load i32, ptr %local.offset.3, align 4
  %local.check.extent.1494 = load i32, ptr %local.extent.4, align 4
  %local.check.payload.1495 = load i32, ptr %local.payload.5, align 4
  %local.check.owner.end.1496 = load i32, ptr %local.owner.end.6, align 4
  %context.field.1497 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.1498 = load i32, ptr %context.field.1497, align 4
  %stack.sub.1501 = sub i32 %local.check.owner.end.1496, %local.check.offset.1493
  %descriptor.owner.inside.1499 = icmp ule i32 %local.check.owner.end.1496, %context.value.1498
  %descriptor.offset.inside.1500 = icmp ule i32 %local.check.offset.1493, %local.check.owner.end.1496
  %descriptor.extent.inside.1502 = icmp ule i32 %local.check.extent.1494, %stack.sub.1501
  %descriptor.payload.inside.1503 = icmp ule i32 %local.check.payload.1495, %local.check.extent.1494
  %descriptor.owner.offset.valid.1504 = and i1 %descriptor.owner.inside.1499, %descriptor.offset.inside.1500
  %descriptor.range.inside.1506 = and i1 %descriptor.owner.offset.valid.1504, %descriptor.extent.inside.1502
  %descriptor.range.valid.1505 = and i1 %descriptor.range.inside.1506, %descriptor.payload.inside.1503
  br i1 %descriptor.range.valid.1505, label %descriptor.valid.1507, label %descriptor.invalid.1508
descriptor.invalid.1508:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.1507:
  %descriptor.initialized.status.1509 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %local.check.offset.1493, i32 %local.check.extent.1494)
  %helper.ok.1510 = icmp eq i32 %descriptor.initialized.status.1509, 0
  br i1 %helper.ok.1510, label %helper.continue.1511, label %frame.failure.0
helper.continue.1511:
  br label %local.descriptor.checked.1492
local.descriptor.inactive.1491:
  br label %local.descriptor.checked.1492
local.descriptor.checked.1492:
  store i1 false, ptr %local.active.2, align 1
  store i32 0, ptr %local.offset.3, align 4
  store i32 0, ptr %local.extent.4, align 4
  store i32 0, ptr %local.payload.5, align 4
  store i32 0, ptr %local.owner.end.6, align 4
  store i32 0, ptr %local.type.7, align 4
  %descriptor.element.1512 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.1513 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1512, i32 0, i32 0
  store i32 9, ptr %descriptor.field.1513, align 4
  %descriptor.field.1514 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1512, i32 0, i32 1
  store i32 %descriptor.value.169, ptr %descriptor.field.1514, align 4
  %descriptor.field.1515 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1512, i32 0, i32 2
  store i32 %descriptor.value.171, ptr %descriptor.field.1515, align 4
  %descriptor.field.1516 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1512, i32 0, i32 3
  store i32 %descriptor.value.173, ptr %descriptor.field.1516, align 4
  %descriptor.field.1517 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1512, i32 0, i32 4
  store i32 %descriptor.value.175, ptr %descriptor.field.1517, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 9, i32 %descriptor.value.169, i32 20, i32 %descriptor.value.173, i32 %descriptor.value.175, i32 %descriptor.value.171)
  %context.field.1518 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1519 = load i32, ptr %context.field.1518, align 4
  %runtime.ok.1520 = icmp eq i32 %context.value.1519, 0
  br i1 %runtime.ok.1520, label %runtime.continue.1521, label %frame.failure.0
runtime.continue.1521:
  %descriptor.element.1522 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 1
  %descriptor.field.1523 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1522, i32 0, i32 0
  store i32 6, ptr %descriptor.field.1523, align 4
  %descriptor.field.1524 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1522, i32 0, i32 1
  store i32 %local.resolved.offset.242, ptr %descriptor.field.1524, align 4
  %descriptor.field.1525 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1522, i32 0, i32 2
  store i32 %local.resolved.extent.243, ptr %descriptor.field.1525, align 4
  %descriptor.field.1526 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1522, i32 0, i32 3
  store i32 %local.resolved.payload.244, ptr %descriptor.field.1526, align 4
  %descriptor.field.1527 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1522, i32 0, i32 4
  store i32 %local.resolved.owner.end.245, ptr %descriptor.field.1527, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 6, i32 %local.resolved.offset.242, i32 20, i32 %local.resolved.payload.244, i32 %local.resolved.owner.end.245, i32 %local.resolved.extent.243)
  %context.field.1528 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1529 = load i32, ptr %context.field.1528, align 4
  %runtime.ok.1530 = icmp eq i32 %context.value.1529, 0
  br i1 %runtime.ok.1530, label %runtime.continue.1531, label %frame.failure.0
runtime.continue.1531:
  %descriptor.element.1532 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 2
  %descriptor.field.1533 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1532, i32 0, i32 0
  store i32 5, ptr %descriptor.field.1533, align 4
  %descriptor.field.1534 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1532, i32 0, i32 1
  store i32 %context.value.612, ptr %descriptor.field.1534, align 4
  %descriptor.field.1535 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1532, i32 0, i32 2
  store i32 %stack.offset.610, ptr %descriptor.field.1535, align 4
  %descriptor.field.1536 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1532, i32 0, i32 3
  store i32 %stack.offset.608, ptr %descriptor.field.1536, align 4
  %descriptor.field.1537 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1532, i32 0, i32 4
  store i32 %stack.offset.613, ptr %descriptor.field.1537, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %context.value.612, i32 20, i32 %stack.offset.608, i32 %stack.offset.613, i32 %stack.offset.610)
  %context.field.1538 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1539 = load i32, ptr %context.field.1538, align 4
  %runtime.ok.1540 = icmp eq i32 %context.value.1539, 0
  br i1 %runtime.ok.1540, label %runtime.continue.1541, label %frame.failure.0
runtime.continue.1541:
  %descriptor.element.1542 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 3
  %descriptor.field.1543 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1542, i32 0, i32 0
  store i32 10, ptr %descriptor.field.1543, align 4
  %descriptor.field.1544 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1542, i32 0, i32 1
  store i32 %context.value.830, ptr %descriptor.field.1544, align 4
  %descriptor.field.1545 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1542, i32 0, i32 2
  store i32 %stack.offset.831, ptr %descriptor.field.1545, align 4
  %descriptor.field.1546 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1542, i32 0, i32 3
  store i32 %stack.offset.832, ptr %descriptor.field.1546, align 4
  %descriptor.field.1547 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1542, i32 0, i32 4
  store i32 %stack.offset.833, ptr %descriptor.field.1547, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 10, i32 %context.value.830, i32 20, i32 %stack.offset.832, i32 %stack.offset.833, i32 %stack.offset.831)
  %context.field.1548 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1549 = load i32, ptr %context.field.1548, align 4
  %runtime.ok.1550 = icmp eq i32 %context.value.1549, 0
  br i1 %runtime.ok.1550, label %runtime.continue.1551, label %frame.failure.0
runtime.continue.1551:
  %descriptor.element.1552 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 4
  %descriptor.field.1553 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1552, i32 0, i32 0
  store i32 11, ptr %descriptor.field.1553, align 4
  %descriptor.field.1554 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1552, i32 0, i32 1
  store i32 %context.value.1085, ptr %descriptor.field.1554, align 4
  %descriptor.field.1555 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1552, i32 0, i32 2
  store i32 %stack.offset.1086, ptr %descriptor.field.1555, align 4
  %descriptor.field.1556 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1552, i32 0, i32 3
  store i32 %stack.offset.1087, ptr %descriptor.field.1556, align 4
  %descriptor.field.1557 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1552, i32 0, i32 4
  store i32 %stack.offset.1088, ptr %descriptor.field.1557, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 11, i32 %context.value.1085, i32 20, i32 %stack.offset.1087, i32 %stack.offset.1088, i32 %stack.offset.1086)
  %context.field.1558 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1559 = load i32, ptr %context.field.1558, align 4
  %runtime.ok.1560 = icmp eq i32 %context.value.1559, 0
  br i1 %runtime.ok.1560, label %runtime.continue.1561, label %frame.failure.0
runtime.continue.1561:
  %descriptor.element.1562 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 5
  %descriptor.field.1563 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1562, i32 0, i32 0
  store i32 11, ptr %descriptor.field.1563, align 4
  %descriptor.field.1564 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1562, i32 0, i32 1
  store i32 %context.value.1363, ptr %descriptor.field.1564, align 4
  %descriptor.field.1565 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1562, i32 0, i32 2
  store i32 %stack.offset.1364, ptr %descriptor.field.1565, align 4
  %descriptor.field.1566 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1562, i32 0, i32 3
  store i32 %stack.offset.1365, ptr %descriptor.field.1566, align 4
  %descriptor.field.1567 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.1562, i32 0, i32 4
  store i32 %stack.offset.1366, ptr %descriptor.field.1567, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 11, i32 %context.value.1363, i32 20, i32 %stack.offset.1365, i32 %stack.offset.1366, i32 %stack.offset.1364)
  %context.field.1568 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.1569 = load i32, ptr %context.field.1568, align 4
  %runtime.ok.1570 = icmp eq i32 %context.value.1569, 0
  br i1 %runtime.ok.1570, label %runtime.continue.1571, label %frame.failure.0
runtime.continue.1571:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.9, i32 0, i32 0, i32 0)
  %context.field.1572 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.1573 = load i32, ptr %context.field.1572, align 4
  %context.field.1574 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.1575 = load i32, ptr %context.field.1574, align 4
  %context.field.1576 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.1577 = load i32, ptr %context.field.1576, align 4
  %stack.offset.1578 = add i32 %context.value.11, %context.value.13
  %stack.offset.1579 = add i32 %context.value.1573, %context.value.1575
  %stack.sub.1580 = sub i32 %stack.offset.1578, %stack.offset.1579
  %stack.sub.1581 = sub i32 %context.value.13, %context.value.1575
  %stack.sub.1582 = sub i32 %context.value.1577, %context.value.15
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.1580, i32 %stack.sub.1581)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.1582)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define internal i32 @agentlang_word_0000(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 9
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 9, 9
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %context.field.43 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.44 = load i32, ptr %context.field.43, align 4
  %stack.sub.45 = sub i32 %context.value.44, %context.value.3
  call void @al_owning_record_layout(ptr %ctx, i32 18, i32 0, i32 %context.value.3, i32 %stack.sub.45, i32 0, i32 0, i32 0)
  %context.field.46 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.47 = load i32, ptr %context.field.46, align 4
  %runtime.ok.48 = icmp eq i32 %context.value.47, 0
  br i1 %runtime.ok.48, label %runtime.continue.49, label %frame.failure.0
runtime.continue.49:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.50 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.51 = load i32, ptr %context.field.50, align 4
  %runtime.ok.52 = icmp eq i32 %context.value.51, 0
  br i1 %runtime.ok.52, label %runtime.continue.53, label %frame.failure.0
runtime.continue.53:
  %descriptor.element.54 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.55 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.54, i32 0, i32 0
  store i32 9, ptr %descriptor.field.55, align 4
  %descriptor.field.56 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.54, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.56, align 4
  %descriptor.field.57 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.54, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.57, align 4
  %descriptor.field.58 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.54, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.58, align 4
  %descriptor.field.59 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.54, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.59, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 9, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.60 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.61 = load i32, ptr %context.field.60, align 4
  %runtime.ok.62 = icmp eq i32 %context.value.61, 0
  br i1 %runtime.ok.62, label %runtime.continue.63, label %frame.failure.0
runtime.continue.63:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.64 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.65 = load i32, ptr %context.field.64, align 4
  %context.field.66 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.67 = load i32, ptr %context.field.66, align 4
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %stack.offset.70 = add i32 %context.value.5, %context.value.7
  %stack.offset.71 = add i32 %context.value.65, %context.value.67
  %stack.sub.72 = sub i32 %stack.offset.70, %stack.offset.71
  %stack.sub.73 = sub i32 %context.value.7, %context.value.67
  %stack.sub.74 = sub i32 %context.value.69, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.72, i32 %stack.sub.73)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.74)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  %entry.input.descriptors.15 = alloca [1 x %AlOwningDescriptor], align 4
  %input.payload.pointer.25 = alloca i32, align 4
  %input.measured.extent.pointer.26 = alloca i32, align 4
  %entry.output.descriptors.57 = alloca [6 x %AlOwningDescriptor], align 4
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 1
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %entry.input.extents.present.10 = icmp ne ptr %input.extents, null
  %entry.input.bytes.present.11 = icmp ne ptr %input, null
  %entry.input.pointers.present.12 = and i1 %entry.input.extents.present.10, %entry.input.bytes.present.11
  br i1 %entry.input.pointers.present.12, label %entry.input.pointers.ok.13, label %entry.input.pointers.invalid.14
entry.input.pointers.invalid.14:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 1, i32 0)
  br label %entry.failure.0
entry.input.pointers.ok.13:
  %input.extent.pointer.16 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.17 = load i32, ptr %input.extent.pointer.16, align 4
  %stack.sub.18 = sub i32 %input.bytes, 0
  %input.offset.within.bytes.19 = icmp ule i32 0, %input.bytes
  %input.extent.within.bytes.20 = icmp ule i32 %input.host.extent.17, %stack.sub.18
  %input.slice.within.bytes.21 = and i1 %input.offset.within.bytes.19, %input.extent.within.bytes.20
  br i1 %input.slice.within.bytes.21, label %input.slice.ready.22, label %input.slice.invalid.23
input.slice.invalid.23:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 24, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.22:
  %host.pointer.24 = getelementptr inbounds i8, ptr %input, i32 0
  %input.measure.status.27 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 4, ptr %host.pointer.24, i32 %input.host.extent.17, i32 0, i32 24, ptr %input.payload.pointer.25, ptr %input.measured.extent.pointer.26)
  %helper.ok.28 = icmp eq i32 %input.measure.status.27, 0
  br i1 %helper.ok.28, label %helper.continue.29, label %entry.failure.0
helper.continue.29:
  %input.measured.payload.30 = load i32, ptr %input.payload.pointer.25, align 4
  %input.measured.extent.31 = load i32, ptr %input.measured.extent.pointer.26, align 4
  %input.extent.exact.32 = icmp eq i32 %input.measured.extent.31, %input.host.extent.17
  br i1 %input.extent.exact.32, label %input.extent.exact.33, label %input.extent.invalid.34
input.extent.invalid.34:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 24, i32 %input.measured.extent.31, i32 %input.host.extent.17)
  br label %entry.failure.0
input.extent.exact.33:
  %stack.offset.35 = add i32 0, %input.host.extent.17
  %input.total.exact.36 = icmp eq i32 %stack.offset.35, %input.bytes
  br i1 %input.total.exact.36, label %input.valid.37, label %input.invalid.38
input.invalid.38:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.35, i32 %input.bytes)
  br label %entry.failure.0
input.valid.37:
  %reserve.status.39 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.35, i32 25)
  %reserve.ok.40 = icmp eq i32 %reserve.status.39, 0
  br i1 %reserve.ok.40, label %reserve.continue.41, label %entry.failure.0
reserve.continue.41:
  %host.pointer.42 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.43 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.42, i32 %input.host.extent.17, i32 0, i32 %input.measured.payload.30, i32 %input.host.extent.17, i32 9, i32 26)
  %helper.ok.44 = icmp eq i32 %input.copy.status.43, 0
  br i1 %helper.ok.44, label %helper.continue.45, label %entry.failure.0
helper.continue.45:
  %stack.offset.46 = add i32 0, %input.host.extent.17
  %descriptor.element.47 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.15, i32 0
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 0
  store i32 9, ptr %descriptor.field.48, align 4
  %descriptor.field.49 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 1
  store i32 0, ptr %descriptor.field.49, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 2
  store i32 %input.host.extent.17, ptr %descriptor.field.50, align 4
  %descriptor.field.51 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 3
  store i32 %input.measured.payload.30, ptr %descriptor.field.51, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.47, i32 0, i32 4
  store i32 %stack.offset.46, ptr %descriptor.field.52, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 9, i32 0, i32 20, i32 %input.measured.payload.30, i32 %stack.offset.46, i32 %input.host.extent.17)
  %context.field.53 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.54 = load i32, ptr %context.field.53, align 4
  %runtime.ok.55 = icmp eq i32 %context.value.54, 0
  br i1 %runtime.ok.55, label %runtime.continue.56, label %entry.failure.0
runtime.continue.56:
  %entry.body.status.58 = call i32 @agentlang_entry_frame(ptr %ctx, ptr %entry.input.descriptors.15, ptr %entry.output.descriptors.57, i32 27)
  %entry.body.ok.59 = icmp eq i32 %entry.body.status.58, 0
  br i1 %entry.body.ok.59, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.60 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.57, i32 0
  %descriptor.field.61 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 0
  %descriptor.value.62 = load i32, ptr %descriptor.field.61, align 4
  %descriptor.field.63 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 1
  %descriptor.value.64 = load i32, ptr %descriptor.field.63, align 4
  %descriptor.field.65 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 2
  %descriptor.value.66 = load i32, ptr %descriptor.field.65, align 4
  %descriptor.field.67 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 3
  %descriptor.value.68 = load i32, ptr %descriptor.field.67, align 4
  %descriptor.field.69 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.60, i32 0, i32 4
  %descriptor.value.70 = load i32, ptr %descriptor.field.69, align 4
  %entry.output.type.valid.71 = icmp eq i32 %descriptor.value.62, 9
  br i1 %entry.output.type.valid.71, label %entry.output.type.ok.72, label %entry.output.type.invalid.73
entry.output.type.invalid.73:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.72:
  %context.field.74 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.75 = load i32, ptr %context.field.74, align 4
  %stack.sub.78 = sub i32 %descriptor.value.70, %descriptor.value.64
  %descriptor.owner.inside.76 = icmp ule i32 %descriptor.value.70, %context.value.75
  %descriptor.offset.inside.77 = icmp ule i32 %descriptor.value.64, %descriptor.value.70
  %descriptor.extent.inside.79 = icmp ule i32 %descriptor.value.66, %stack.sub.78
  %descriptor.payload.inside.80 = icmp ule i32 %descriptor.value.68, %descriptor.value.66
  %descriptor.owner.offset.valid.81 = and i1 %descriptor.owner.inside.76, %descriptor.offset.inside.77
  %descriptor.range.inside.83 = and i1 %descriptor.owner.offset.valid.81, %descriptor.extent.inside.79
  %descriptor.range.valid.82 = and i1 %descriptor.range.inside.83, %descriptor.payload.inside.80
  %descriptor.type.valid.84 = icmp eq i32 9, 9
  %descriptor.valid.85 = and i1 %descriptor.range.valid.82, %descriptor.type.valid.84
  br i1 %descriptor.valid.85, label %descriptor.valid.86, label %descriptor.invalid.87
descriptor.invalid.87:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.86:
  %descriptor.initialized.status.88 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.64, i32 %descriptor.value.66)
  %helper.ok.89 = icmp eq i32 %descriptor.initialized.status.88, 0
  br i1 %helper.ok.89, label %helper.continue.90, label %entry.failure.0
helper.continue.90:
  %entry.output.size.i64.91 = zext i32 %descriptor.value.66 to i64
  %entry.output.total.i64.92 = add i64 0, %entry.output.size.i64.91
  %descriptor.element.93 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.57, i32 1
  %descriptor.field.94 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.93, i32 0, i32 0
  %descriptor.value.95 = load i32, ptr %descriptor.field.94, align 4
  %descriptor.field.96 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.93, i32 0, i32 1
  %descriptor.value.97 = load i32, ptr %descriptor.field.96, align 4
  %descriptor.field.98 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.93, i32 0, i32 2
  %descriptor.value.99 = load i32, ptr %descriptor.field.98, align 4
  %descriptor.field.100 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.93, i32 0, i32 3
  %descriptor.value.101 = load i32, ptr %descriptor.field.100, align 4
  %descriptor.field.102 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.93, i32 0, i32 4
  %descriptor.value.103 = load i32, ptr %descriptor.field.102, align 4
  %entry.output.type.valid.104 = icmp eq i32 %descriptor.value.95, 6
  br i1 %entry.output.type.valid.104, label %entry.output.type.ok.105, label %entry.output.type.invalid.106
entry.output.type.invalid.106:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.105:
  %context.field.107 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.108 = load i32, ptr %context.field.107, align 4
  %stack.sub.111 = sub i32 %descriptor.value.103, %descriptor.value.97
  %descriptor.owner.inside.109 = icmp ule i32 %descriptor.value.103, %context.value.108
  %descriptor.offset.inside.110 = icmp ule i32 %descriptor.value.97, %descriptor.value.103
  %descriptor.extent.inside.112 = icmp ule i32 %descriptor.value.99, %stack.sub.111
  %descriptor.payload.inside.113 = icmp ule i32 %descriptor.value.101, %descriptor.value.99
  %descriptor.owner.offset.valid.114 = and i1 %descriptor.owner.inside.109, %descriptor.offset.inside.110
  %descriptor.range.inside.116 = and i1 %descriptor.owner.offset.valid.114, %descriptor.extent.inside.112
  %descriptor.range.valid.115 = and i1 %descriptor.range.inside.116, %descriptor.payload.inside.113
  %descriptor.type.valid.117 = icmp eq i32 6, 6
  %descriptor.valid.118 = and i1 %descriptor.range.valid.115, %descriptor.type.valid.117
  br i1 %descriptor.valid.118, label %descriptor.valid.119, label %descriptor.invalid.120
descriptor.invalid.120:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.119:
  %descriptor.initialized.status.121 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.97, i32 %descriptor.value.99)
  %helper.ok.122 = icmp eq i32 %descriptor.initialized.status.121, 0
  br i1 %helper.ok.122, label %helper.continue.123, label %entry.failure.0
helper.continue.123:
  %entry.output.size.i64.124 = zext i32 %descriptor.value.99 to i64
  %entry.output.total.i64.125 = add i64 %entry.output.total.i64.92, %entry.output.size.i64.124
  %descriptor.element.126 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.57, i32 2
  %descriptor.field.127 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.126, i32 0, i32 0
  %descriptor.value.128 = load i32, ptr %descriptor.field.127, align 4
  %descriptor.field.129 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.126, i32 0, i32 1
  %descriptor.value.130 = load i32, ptr %descriptor.field.129, align 4
  %descriptor.field.131 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.126, i32 0, i32 2
  %descriptor.value.132 = load i32, ptr %descriptor.field.131, align 4
  %descriptor.field.133 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.126, i32 0, i32 3
  %descriptor.value.134 = load i32, ptr %descriptor.field.133, align 4
  %descriptor.field.135 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.126, i32 0, i32 4
  %descriptor.value.136 = load i32, ptr %descriptor.field.135, align 4
  %entry.output.type.valid.137 = icmp eq i32 %descriptor.value.128, 5
  br i1 %entry.output.type.valid.137, label %entry.output.type.ok.138, label %entry.output.type.invalid.139
entry.output.type.invalid.139:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.138:
  %context.field.140 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.141 = load i32, ptr %context.field.140, align 4
  %stack.sub.144 = sub i32 %descriptor.value.136, %descriptor.value.130
  %descriptor.owner.inside.142 = icmp ule i32 %descriptor.value.136, %context.value.141
  %descriptor.offset.inside.143 = icmp ule i32 %descriptor.value.130, %descriptor.value.136
  %descriptor.extent.inside.145 = icmp ule i32 %descriptor.value.132, %stack.sub.144
  %descriptor.payload.inside.146 = icmp ule i32 %descriptor.value.134, %descriptor.value.132
  %descriptor.owner.offset.valid.147 = and i1 %descriptor.owner.inside.142, %descriptor.offset.inside.143
  %descriptor.range.inside.149 = and i1 %descriptor.owner.offset.valid.147, %descriptor.extent.inside.145
  %descriptor.range.valid.148 = and i1 %descriptor.range.inside.149, %descriptor.payload.inside.146
  %descriptor.type.valid.150 = icmp eq i32 5, 5
  %descriptor.valid.151 = and i1 %descriptor.range.valid.148, %descriptor.type.valid.150
  br i1 %descriptor.valid.151, label %descriptor.valid.152, label %descriptor.invalid.153
descriptor.invalid.153:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.152:
  %descriptor.initialized.status.154 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.130, i32 %descriptor.value.132)
  %helper.ok.155 = icmp eq i32 %descriptor.initialized.status.154, 0
  br i1 %helper.ok.155, label %helper.continue.156, label %entry.failure.0
helper.continue.156:
  %entry.output.size.i64.157 = zext i32 %descriptor.value.132 to i64
  %entry.output.total.i64.158 = add i64 %entry.output.total.i64.125, %entry.output.size.i64.157
  %descriptor.element.159 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.57, i32 3
  %descriptor.field.160 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.159, i32 0, i32 0
  %descriptor.value.161 = load i32, ptr %descriptor.field.160, align 4
  %descriptor.field.162 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.159, i32 0, i32 1
  %descriptor.value.163 = load i32, ptr %descriptor.field.162, align 4
  %descriptor.field.164 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.159, i32 0, i32 2
  %descriptor.value.165 = load i32, ptr %descriptor.field.164, align 4
  %descriptor.field.166 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.159, i32 0, i32 3
  %descriptor.value.167 = load i32, ptr %descriptor.field.166, align 4
  %descriptor.field.168 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.159, i32 0, i32 4
  %descriptor.value.169 = load i32, ptr %descriptor.field.168, align 4
  %entry.output.type.valid.170 = icmp eq i32 %descriptor.value.161, 10
  br i1 %entry.output.type.valid.170, label %entry.output.type.ok.171, label %entry.output.type.invalid.172
entry.output.type.invalid.172:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.171:
  %context.field.173 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.174 = load i32, ptr %context.field.173, align 4
  %stack.sub.177 = sub i32 %descriptor.value.169, %descriptor.value.163
  %descriptor.owner.inside.175 = icmp ule i32 %descriptor.value.169, %context.value.174
  %descriptor.offset.inside.176 = icmp ule i32 %descriptor.value.163, %descriptor.value.169
  %descriptor.extent.inside.178 = icmp ule i32 %descriptor.value.165, %stack.sub.177
  %descriptor.payload.inside.179 = icmp ule i32 %descriptor.value.167, %descriptor.value.165
  %descriptor.owner.offset.valid.180 = and i1 %descriptor.owner.inside.175, %descriptor.offset.inside.176
  %descriptor.range.inside.182 = and i1 %descriptor.owner.offset.valid.180, %descriptor.extent.inside.178
  %descriptor.range.valid.181 = and i1 %descriptor.range.inside.182, %descriptor.payload.inside.179
  %descriptor.type.valid.183 = icmp eq i32 10, 10
  %descriptor.valid.184 = and i1 %descriptor.range.valid.181, %descriptor.type.valid.183
  br i1 %descriptor.valid.184, label %descriptor.valid.185, label %descriptor.invalid.186
descriptor.invalid.186:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.185:
  %descriptor.initialized.status.187 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.163, i32 %descriptor.value.165)
  %helper.ok.188 = icmp eq i32 %descriptor.initialized.status.187, 0
  br i1 %helper.ok.188, label %helper.continue.189, label %entry.failure.0
helper.continue.189:
  %entry.output.size.i64.190 = zext i32 %descriptor.value.165 to i64
  %entry.output.total.i64.191 = add i64 %entry.output.total.i64.158, %entry.output.size.i64.190
  %descriptor.element.192 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.57, i32 4
  %descriptor.field.193 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.192, i32 0, i32 0
  %descriptor.value.194 = load i32, ptr %descriptor.field.193, align 4
  %descriptor.field.195 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.192, i32 0, i32 1
  %descriptor.value.196 = load i32, ptr %descriptor.field.195, align 4
  %descriptor.field.197 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.192, i32 0, i32 2
  %descriptor.value.198 = load i32, ptr %descriptor.field.197, align 4
  %descriptor.field.199 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.192, i32 0, i32 3
  %descriptor.value.200 = load i32, ptr %descriptor.field.199, align 4
  %descriptor.field.201 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.192, i32 0, i32 4
  %descriptor.value.202 = load i32, ptr %descriptor.field.201, align 4
  %entry.output.type.valid.203 = icmp eq i32 %descriptor.value.194, 11
  br i1 %entry.output.type.valid.203, label %entry.output.type.ok.204, label %entry.output.type.invalid.205
entry.output.type.invalid.205:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.204:
  %context.field.206 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.207 = load i32, ptr %context.field.206, align 4
  %stack.sub.210 = sub i32 %descriptor.value.202, %descriptor.value.196
  %descriptor.owner.inside.208 = icmp ule i32 %descriptor.value.202, %context.value.207
  %descriptor.offset.inside.209 = icmp ule i32 %descriptor.value.196, %descriptor.value.202
  %descriptor.extent.inside.211 = icmp ule i32 %descriptor.value.198, %stack.sub.210
  %descriptor.payload.inside.212 = icmp ule i32 %descriptor.value.200, %descriptor.value.198
  %descriptor.owner.offset.valid.213 = and i1 %descriptor.owner.inside.208, %descriptor.offset.inside.209
  %descriptor.range.inside.215 = and i1 %descriptor.owner.offset.valid.213, %descriptor.extent.inside.211
  %descriptor.range.valid.214 = and i1 %descriptor.range.inside.215, %descriptor.payload.inside.212
  %descriptor.type.valid.216 = icmp eq i32 11, 11
  %descriptor.valid.217 = and i1 %descriptor.range.valid.214, %descriptor.type.valid.216
  br i1 %descriptor.valid.217, label %descriptor.valid.218, label %descriptor.invalid.219
descriptor.invalid.219:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.218:
  %descriptor.initialized.status.220 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.196, i32 %descriptor.value.198)
  %helper.ok.221 = icmp eq i32 %descriptor.initialized.status.220, 0
  br i1 %helper.ok.221, label %helper.continue.222, label %entry.failure.0
helper.continue.222:
  %entry.output.size.i64.223 = zext i32 %descriptor.value.198 to i64
  %entry.output.total.i64.224 = add i64 %entry.output.total.i64.191, %entry.output.size.i64.223
  %descriptor.element.225 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.57, i32 5
  %descriptor.field.226 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.225, i32 0, i32 0
  %descriptor.value.227 = load i32, ptr %descriptor.field.226, align 4
  %descriptor.field.228 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.225, i32 0, i32 1
  %descriptor.value.229 = load i32, ptr %descriptor.field.228, align 4
  %descriptor.field.230 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.225, i32 0, i32 2
  %descriptor.value.231 = load i32, ptr %descriptor.field.230, align 4
  %descriptor.field.232 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.225, i32 0, i32 3
  %descriptor.value.233 = load i32, ptr %descriptor.field.232, align 4
  %descriptor.field.234 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.225, i32 0, i32 4
  %descriptor.value.235 = load i32, ptr %descriptor.field.234, align 4
  %entry.output.type.valid.236 = icmp eq i32 %descriptor.value.227, 11
  br i1 %entry.output.type.valid.236, label %entry.output.type.ok.237, label %entry.output.type.invalid.238
entry.output.type.invalid.238:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.237:
  %context.field.239 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.240 = load i32, ptr %context.field.239, align 4
  %stack.sub.243 = sub i32 %descriptor.value.235, %descriptor.value.229
  %descriptor.owner.inside.241 = icmp ule i32 %descriptor.value.235, %context.value.240
  %descriptor.offset.inside.242 = icmp ule i32 %descriptor.value.229, %descriptor.value.235
  %descriptor.extent.inside.244 = icmp ule i32 %descriptor.value.231, %stack.sub.243
  %descriptor.payload.inside.245 = icmp ule i32 %descriptor.value.233, %descriptor.value.231
  %descriptor.owner.offset.valid.246 = and i1 %descriptor.owner.inside.241, %descriptor.offset.inside.242
  %descriptor.range.inside.248 = and i1 %descriptor.owner.offset.valid.246, %descriptor.extent.inside.244
  %descriptor.range.valid.247 = and i1 %descriptor.range.inside.248, %descriptor.payload.inside.245
  %descriptor.type.valid.249 = icmp eq i32 11, 11
  %descriptor.valid.250 = and i1 %descriptor.range.valid.247, %descriptor.type.valid.249
  br i1 %descriptor.valid.250, label %descriptor.valid.251, label %descriptor.invalid.252
descriptor.invalid.252:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.251:
  %descriptor.initialized.status.253 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.229, i32 %descriptor.value.231)
  %helper.ok.254 = icmp eq i32 %descriptor.initialized.status.253, 0
  br i1 %helper.ok.254, label %helper.continue.255, label %entry.failure.0
helper.continue.255:
  %entry.output.size.i64.256 = zext i32 %descriptor.value.231 to i64
  %entry.output.total.i64.257 = add i64 %entry.output.total.i64.224, %entry.output.size.i64.256
  %entry.retained.capacity.i64.258 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.259 = icmp ule i64 %entry.output.total.i64.257, 4294967295
  %entry.retained.required.truncated.260 = trunc i64 %entry.output.total.i64.257 to i32
  %entry.retained.required.261 = select i1 %entry.retained.required.fits.u32.259, i32 %entry.retained.required.truncated.260, i32 4294967295
  %entry.retained.capacity.ok.262 = icmp ule i64 %entry.output.total.i64.257, %entry.retained.capacity.i64.258
  br i1 %entry.retained.capacity.ok.262, label %entry.retained.capacity.ready.263, label %entry.retained.capacity.failure.264
entry.retained.capacity.failure.264:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.261, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.263:
  %host.pointer.265 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.266 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.265, i32 %stack.sub.266, i32 %descriptor.value.64, i32 %descriptor.value.66, i32 9)
  %context.field.267 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.268 = load i32, ptr %context.field.267, align 4
  %runtime.ok.269 = icmp eq i32 %context.value.268, 0
  br i1 %runtime.ok.269, label %runtime.continue.270, label %entry.failure.0
runtime.continue.270:
  %stack.offset.271 = add i32 0, %descriptor.value.66
  %host.pointer.272 = getelementptr inbounds i8, ptr %retained, i32 %stack.offset.271
  %stack.sub.273 = sub i32 %retained.capacity, %stack.offset.271
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.272, i32 %stack.sub.273, i32 %descriptor.value.97, i32 %descriptor.value.99, i32 6)
  %context.field.274 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.275 = load i32, ptr %context.field.274, align 4
  %runtime.ok.276 = icmp eq i32 %context.value.275, 0
  br i1 %runtime.ok.276, label %runtime.continue.277, label %entry.failure.0
runtime.continue.277:
  %stack.offset.278 = add i32 %stack.offset.271, %descriptor.value.99
  %host.pointer.279 = getelementptr inbounds i8, ptr %retained, i32 %stack.offset.278
  %stack.sub.280 = sub i32 %retained.capacity, %stack.offset.278
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.279, i32 %stack.sub.280, i32 %descriptor.value.130, i32 %descriptor.value.132, i32 5)
  %context.field.281 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.282 = load i32, ptr %context.field.281, align 4
  %runtime.ok.283 = icmp eq i32 %context.value.282, 0
  br i1 %runtime.ok.283, label %runtime.continue.284, label %entry.failure.0
runtime.continue.284:
  %stack.offset.285 = add i32 %stack.offset.278, %descriptor.value.132
  %host.pointer.286 = getelementptr inbounds i8, ptr %retained, i32 %stack.offset.285
  %stack.sub.287 = sub i32 %retained.capacity, %stack.offset.285
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.286, i32 %stack.sub.287, i32 %descriptor.value.163, i32 %descriptor.value.165, i32 10)
  %context.field.288 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.289 = load i32, ptr %context.field.288, align 4
  %runtime.ok.290 = icmp eq i32 %context.value.289, 0
  br i1 %runtime.ok.290, label %runtime.continue.291, label %entry.failure.0
runtime.continue.291:
  %stack.offset.292 = add i32 %stack.offset.285, %descriptor.value.165
  %host.pointer.293 = getelementptr inbounds i8, ptr %retained, i32 %stack.offset.292
  %stack.sub.294 = sub i32 %retained.capacity, %stack.offset.292
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.293, i32 %stack.sub.294, i32 %descriptor.value.196, i32 %descriptor.value.198, i32 11)
  %context.field.295 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.296 = load i32, ptr %context.field.295, align 4
  %runtime.ok.297 = icmp eq i32 %context.value.296, 0
  br i1 %runtime.ok.297, label %runtime.continue.298, label %entry.failure.0
runtime.continue.298:
  %stack.offset.299 = add i32 %stack.offset.292, %descriptor.value.198
  %host.pointer.300 = getelementptr inbounds i8, ptr %retained, i32 %stack.offset.299
  %stack.sub.301 = sub i32 %retained.capacity, %stack.offset.299
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.300, i32 %stack.sub.301, i32 %descriptor.value.229, i32 %descriptor.value.231, i32 11)
  %context.field.302 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.303 = load i32, ptr %context.field.302, align 4
  %runtime.ok.304 = icmp eq i32 %context.value.303, 0
  br i1 %runtime.ok.304, label %runtime.continue.305, label %entry.failure.0
runtime.continue.305:
  %stack.offset.306 = add i32 %stack.offset.299, %descriptor.value.231
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.307 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.308 = load i32, ptr %context.field.307, align 4
  %context.field.309 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.310 = load i32, ptr %context.field.309, align 4
  %stack.sub.311 = sub i32 0, %context.value.308
  %stack.sub.312 = sub i32 0, %context.value.310
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.311, i32 %stack.sub.312)
  %context.field.313 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.314 = load i32, ptr %context.field.313, align 4
  %runtime.ok.315 = icmp eq i32 %context.value.314, 0
  br i1 %runtime.ok.315, label %runtime.continue.316, label %entry.failure.0
runtime.continue.316:
  br label %entry.return.status
entry.failure.0:
  %context.field.317 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.318 = load i32, ptr %context.field.317, align 4
  %context.field.319 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.320 = load i32, ptr %context.field.319, align 4
  %context.field.321 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.322 = load i32, ptr %context.field.321, align 4
  %stack.offset.323 = add i32 %context.value.318, %context.value.320
  %stack.sub.324 = sub i32 0, %stack.offset.323
  %stack.sub.325 = sub i32 0, %context.value.320
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.324, i32 %stack.sub.325)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.322)
  br label %entry.return.status
entry.return.status:
  %context.field.326 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.327 = load i32, ptr %context.field.326, align 4
  ret i32 %context.value.327
}


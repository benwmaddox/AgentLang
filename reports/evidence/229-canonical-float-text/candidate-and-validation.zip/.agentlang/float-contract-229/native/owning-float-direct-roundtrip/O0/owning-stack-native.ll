%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [1 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 9, i32 5, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }], align 4
@al_owning_fields = private constant [1 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 0, i32 0, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 4, ptr @al_owning_types, i32 1, ptr @al_owning_fields, i32 0 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_locate_sum_case(ptr, ptr, i32, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_float_format(ptr, i64, ptr, ptr, i32)
declare i32 @al_owning_float_string_write(ptr, i32, i32, ptr, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal_typed(ptr, ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %descriptor.element.13 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 0
  %descriptor.field.14 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 0
  %descriptor.value.15 = load i32, ptr %descriptor.field.14, align 4
  %descriptor.field.16 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 1
  %descriptor.value.17 = load i32, ptr %descriptor.field.16, align 4
  %descriptor.field.18 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 2
  %descriptor.value.19 = load i32, ptr %descriptor.field.18, align 4
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 3
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.13, i32 0, i32 4
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %argument.type.valid.24 = icmp eq i32 %descriptor.value.15, 5
  br i1 %argument.type.valid.24, label %argument.type.ok.25, label %frame.failure.0
argument.type.ok.25:
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %stack.sub.30 = sub i32 %descriptor.value.23, %descriptor.value.17
  %descriptor.owner.inside.28 = icmp ule i32 %descriptor.value.23, %context.value.27
  %descriptor.offset.inside.29 = icmp ule i32 %descriptor.value.17, %descriptor.value.23
  %descriptor.extent.inside.31 = icmp ule i32 %descriptor.value.19, %stack.sub.30
  %descriptor.payload.inside.32 = icmp ule i32 %descriptor.value.21, %descriptor.value.19
  %descriptor.owner.offset.valid.33 = and i1 %descriptor.owner.inside.28, %descriptor.offset.inside.29
  %descriptor.range.inside.35 = and i1 %descriptor.owner.offset.valid.33, %descriptor.extent.inside.31
  %descriptor.range.valid.34 = and i1 %descriptor.range.inside.35, %descriptor.payload.inside.32
  %descriptor.type.valid.36 = icmp eq i32 5, 5
  %descriptor.valid.37 = and i1 %descriptor.range.valid.34, %descriptor.type.valid.36
  br i1 %descriptor.valid.37, label %descriptor.valid.38, label %descriptor.invalid.39
descriptor.invalid.39:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.38:
  %descriptor.initialized.status.40 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.17, i32 %descriptor.value.19)
  %helper.ok.41 = icmp eq i32 %descriptor.initialized.status.40, 0
  br i1 %helper.ok.41, label %helper.continue.42, label %frame.failure.0
helper.continue.42:
  %descriptor.element.43 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 1
  %descriptor.field.44 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 0
  %descriptor.value.45 = load i32, ptr %descriptor.field.44, align 4
  %descriptor.field.46 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 1
  %descriptor.value.47 = load i32, ptr %descriptor.field.46, align 4
  %descriptor.field.48 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 2
  %descriptor.value.49 = load i32, ptr %descriptor.field.48, align 4
  %descriptor.field.50 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 3
  %descriptor.value.51 = load i32, ptr %descriptor.field.50, align 4
  %descriptor.field.52 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.43, i32 0, i32 4
  %descriptor.value.53 = load i32, ptr %descriptor.field.52, align 4
  %argument.type.valid.54 = icmp eq i32 %descriptor.value.45, 5
  br i1 %argument.type.valid.54, label %argument.type.ok.55, label %frame.failure.0
argument.type.ok.55:
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %stack.sub.60 = sub i32 %descriptor.value.53, %descriptor.value.47
  %descriptor.owner.inside.58 = icmp ule i32 %descriptor.value.53, %context.value.57
  %descriptor.offset.inside.59 = icmp ule i32 %descriptor.value.47, %descriptor.value.53
  %descriptor.extent.inside.61 = icmp ule i32 %descriptor.value.49, %stack.sub.60
  %descriptor.payload.inside.62 = icmp ule i32 %descriptor.value.51, %descriptor.value.49
  %descriptor.owner.offset.valid.63 = and i1 %descriptor.owner.inside.58, %descriptor.offset.inside.59
  %descriptor.range.inside.65 = and i1 %descriptor.owner.offset.valid.63, %descriptor.extent.inside.61
  %descriptor.range.valid.64 = and i1 %descriptor.range.inside.65, %descriptor.payload.inside.62
  %descriptor.type.valid.66 = icmp eq i32 5, 5
  %descriptor.valid.67 = and i1 %descriptor.range.valid.64, %descriptor.type.valid.66
  br i1 %descriptor.valid.67, label %descriptor.valid.68, label %descriptor.invalid.69
descriptor.invalid.69:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.68:
  %descriptor.initialized.status.70 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.47, i32 %descriptor.value.49)
  %helper.ok.71 = icmp eq i32 %descriptor.initialized.status.70, 0
  br i1 %helper.ok.71, label %helper.continue.72, label %frame.failure.0
helper.continue.72:
  %descriptor.element.73 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 2
  %descriptor.field.74 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 0
  %descriptor.value.75 = load i32, ptr %descriptor.field.74, align 4
  %descriptor.field.76 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 1
  %descriptor.value.77 = load i32, ptr %descriptor.field.76, align 4
  %descriptor.field.78 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 2
  %descriptor.value.79 = load i32, ptr %descriptor.field.78, align 4
  %descriptor.field.80 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 3
  %descriptor.value.81 = load i32, ptr %descriptor.field.80, align 4
  %descriptor.field.82 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.73, i32 0, i32 4
  %descriptor.value.83 = load i32, ptr %descriptor.field.82, align 4
  %argument.type.valid.84 = icmp eq i32 %descriptor.value.75, 5
  br i1 %argument.type.valid.84, label %argument.type.ok.85, label %frame.failure.0
argument.type.ok.85:
  %context.field.86 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.87 = load i32, ptr %context.field.86, align 4
  %stack.sub.90 = sub i32 %descriptor.value.83, %descriptor.value.77
  %descriptor.owner.inside.88 = icmp ule i32 %descriptor.value.83, %context.value.87
  %descriptor.offset.inside.89 = icmp ule i32 %descriptor.value.77, %descriptor.value.83
  %descriptor.extent.inside.91 = icmp ule i32 %descriptor.value.79, %stack.sub.90
  %descriptor.payload.inside.92 = icmp ule i32 %descriptor.value.81, %descriptor.value.79
  %descriptor.owner.offset.valid.93 = and i1 %descriptor.owner.inside.88, %descriptor.offset.inside.89
  %descriptor.range.inside.95 = and i1 %descriptor.owner.offset.valid.93, %descriptor.extent.inside.91
  %descriptor.range.valid.94 = and i1 %descriptor.range.inside.95, %descriptor.payload.inside.92
  %descriptor.type.valid.96 = icmp eq i32 5, 5
  %descriptor.valid.97 = and i1 %descriptor.range.valid.94, %descriptor.type.valid.96
  br i1 %descriptor.valid.97, label %descriptor.valid.98, label %descriptor.invalid.99
descriptor.invalid.99:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.98:
  %descriptor.initialized.status.100 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.77, i32 %descriptor.value.79)
  %helper.ok.101 = icmp eq i32 %descriptor.initialized.status.100, 0
  br i1 %helper.ok.101, label %helper.continue.102, label %frame.failure.0
helper.continue.102:
  %descriptor.element.103 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 3
  %descriptor.field.104 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.103, i32 0, i32 0
  %descriptor.value.105 = load i32, ptr %descriptor.field.104, align 4
  %descriptor.field.106 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.103, i32 0, i32 1
  %descriptor.value.107 = load i32, ptr %descriptor.field.106, align 4
  %descriptor.field.108 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.103, i32 0, i32 2
  %descriptor.value.109 = load i32, ptr %descriptor.field.108, align 4
  %descriptor.field.110 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.103, i32 0, i32 3
  %descriptor.value.111 = load i32, ptr %descriptor.field.110, align 4
  %descriptor.field.112 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.103, i32 0, i32 4
  %descriptor.value.113 = load i32, ptr %descriptor.field.112, align 4
  %argument.type.valid.114 = icmp eq i32 %descriptor.value.105, 5
  br i1 %argument.type.valid.114, label %argument.type.ok.115, label %frame.failure.0
argument.type.ok.115:
  %context.field.116 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.117 = load i32, ptr %context.field.116, align 4
  %stack.sub.120 = sub i32 %descriptor.value.113, %descriptor.value.107
  %descriptor.owner.inside.118 = icmp ule i32 %descriptor.value.113, %context.value.117
  %descriptor.offset.inside.119 = icmp ule i32 %descriptor.value.107, %descriptor.value.113
  %descriptor.extent.inside.121 = icmp ule i32 %descriptor.value.109, %stack.sub.120
  %descriptor.payload.inside.122 = icmp ule i32 %descriptor.value.111, %descriptor.value.109
  %descriptor.owner.offset.valid.123 = and i1 %descriptor.owner.inside.118, %descriptor.offset.inside.119
  %descriptor.range.inside.125 = and i1 %descriptor.owner.offset.valid.123, %descriptor.extent.inside.121
  %descriptor.range.valid.124 = and i1 %descriptor.range.inside.125, %descriptor.payload.inside.122
  %descriptor.type.valid.126 = icmp eq i32 5, 5
  %descriptor.valid.127 = and i1 %descriptor.range.valid.124, %descriptor.type.valid.126
  br i1 %descriptor.valid.127, label %descriptor.valid.128, label %descriptor.invalid.129
descriptor.invalid.129:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.128:
  %descriptor.initialized.status.130 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.107, i32 %descriptor.value.109)
  %helper.ok.131 = icmp eq i32 %descriptor.initialized.status.130, 0
  br i1 %helper.ok.131, label %helper.continue.132, label %frame.failure.0
helper.continue.132:
  %descriptor.element.133 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 4
  %descriptor.field.134 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.133, i32 0, i32 0
  %descriptor.value.135 = load i32, ptr %descriptor.field.134, align 4
  %descriptor.field.136 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.133, i32 0, i32 1
  %descriptor.value.137 = load i32, ptr %descriptor.field.136, align 4
  %descriptor.field.138 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.133, i32 0, i32 2
  %descriptor.value.139 = load i32, ptr %descriptor.field.138, align 4
  %descriptor.field.140 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.133, i32 0, i32 3
  %descriptor.value.141 = load i32, ptr %descriptor.field.140, align 4
  %descriptor.field.142 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.133, i32 0, i32 4
  %descriptor.value.143 = load i32, ptr %descriptor.field.142, align 4
  %argument.type.valid.144 = icmp eq i32 %descriptor.value.135, 5
  br i1 %argument.type.valid.144, label %argument.type.ok.145, label %frame.failure.0
argument.type.ok.145:
  %context.field.146 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.147 = load i32, ptr %context.field.146, align 4
  %stack.sub.150 = sub i32 %descriptor.value.143, %descriptor.value.137
  %descriptor.owner.inside.148 = icmp ule i32 %descriptor.value.143, %context.value.147
  %descriptor.offset.inside.149 = icmp ule i32 %descriptor.value.137, %descriptor.value.143
  %descriptor.extent.inside.151 = icmp ule i32 %descriptor.value.139, %stack.sub.150
  %descriptor.payload.inside.152 = icmp ule i32 %descriptor.value.141, %descriptor.value.139
  %descriptor.owner.offset.valid.153 = and i1 %descriptor.owner.inside.148, %descriptor.offset.inside.149
  %descriptor.range.inside.155 = and i1 %descriptor.owner.offset.valid.153, %descriptor.extent.inside.151
  %descriptor.range.valid.154 = and i1 %descriptor.range.inside.155, %descriptor.payload.inside.152
  %descriptor.type.valid.156 = icmp eq i32 5, 5
  %descriptor.valid.157 = and i1 %descriptor.range.valid.154, %descriptor.type.valid.156
  br i1 %descriptor.valid.157, label %descriptor.valid.158, label %descriptor.invalid.159
descriptor.invalid.159:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.158:
  %descriptor.initialized.status.160 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.137, i32 %descriptor.value.139)
  %helper.ok.161 = icmp eq i32 %descriptor.initialized.status.160, 0
  br i1 %helper.ok.161, label %helper.continue.162, label %frame.failure.0
helper.continue.162:
  %descriptor.element.163 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 5
  %descriptor.field.164 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.163, i32 0, i32 0
  %descriptor.value.165 = load i32, ptr %descriptor.field.164, align 4
  %descriptor.field.166 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.163, i32 0, i32 1
  %descriptor.value.167 = load i32, ptr %descriptor.field.166, align 4
  %descriptor.field.168 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.163, i32 0, i32 2
  %descriptor.value.169 = load i32, ptr %descriptor.field.168, align 4
  %descriptor.field.170 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.163, i32 0, i32 3
  %descriptor.value.171 = load i32, ptr %descriptor.field.170, align 4
  %descriptor.field.172 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.163, i32 0, i32 4
  %descriptor.value.173 = load i32, ptr %descriptor.field.172, align 4
  %argument.type.valid.174 = icmp eq i32 %descriptor.value.165, 5
  br i1 %argument.type.valid.174, label %argument.type.ok.175, label %frame.failure.0
argument.type.ok.175:
  %context.field.176 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.177 = load i32, ptr %context.field.176, align 4
  %stack.sub.180 = sub i32 %descriptor.value.173, %descriptor.value.167
  %descriptor.owner.inside.178 = icmp ule i32 %descriptor.value.173, %context.value.177
  %descriptor.offset.inside.179 = icmp ule i32 %descriptor.value.167, %descriptor.value.173
  %descriptor.extent.inside.181 = icmp ule i32 %descriptor.value.169, %stack.sub.180
  %descriptor.payload.inside.182 = icmp ule i32 %descriptor.value.171, %descriptor.value.169
  %descriptor.owner.offset.valid.183 = and i1 %descriptor.owner.inside.178, %descriptor.offset.inside.179
  %descriptor.range.inside.185 = and i1 %descriptor.owner.offset.valid.183, %descriptor.extent.inside.181
  %descriptor.range.valid.184 = and i1 %descriptor.range.inside.185, %descriptor.payload.inside.182
  %descriptor.type.valid.186 = icmp eq i32 5, 5
  %descriptor.valid.187 = and i1 %descriptor.range.valid.184, %descriptor.type.valid.186
  br i1 %descriptor.valid.187, label %descriptor.valid.188, label %descriptor.invalid.189
descriptor.invalid.189:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.188:
  %descriptor.initialized.status.190 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.167, i32 %descriptor.value.169)
  %helper.ok.191 = icmp eq i32 %descriptor.initialized.status.190, 0
  br i1 %helper.ok.191, label %helper.continue.192, label %frame.failure.0
helper.continue.192:
  %descriptor.element.193 = getelementptr inbounds %AlOwningDescriptor, ptr %arguments, i32 6
  %descriptor.field.194 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.193, i32 0, i32 0
  %descriptor.value.195 = load i32, ptr %descriptor.field.194, align 4
  %descriptor.field.196 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.193, i32 0, i32 1
  %descriptor.value.197 = load i32, ptr %descriptor.field.196, align 4
  %descriptor.field.198 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.193, i32 0, i32 2
  %descriptor.value.199 = load i32, ptr %descriptor.field.198, align 4
  %descriptor.field.200 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.193, i32 0, i32 3
  %descriptor.value.201 = load i32, ptr %descriptor.field.200, align 4
  %descriptor.field.202 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.193, i32 0, i32 4
  %descriptor.value.203 = load i32, ptr %descriptor.field.202, align 4
  %argument.type.valid.204 = icmp eq i32 %descriptor.value.195, 5
  br i1 %argument.type.valid.204, label %argument.type.ok.205, label %frame.failure.0
argument.type.ok.205:
  %context.field.206 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.207 = load i32, ptr %context.field.206, align 4
  %stack.sub.210 = sub i32 %descriptor.value.203, %descriptor.value.197
  %descriptor.owner.inside.208 = icmp ule i32 %descriptor.value.203, %context.value.207
  %descriptor.offset.inside.209 = icmp ule i32 %descriptor.value.197, %descriptor.value.203
  %descriptor.extent.inside.211 = icmp ule i32 %descriptor.value.199, %stack.sub.210
  %descriptor.payload.inside.212 = icmp ule i32 %descriptor.value.201, %descriptor.value.199
  %descriptor.owner.offset.valid.213 = and i1 %descriptor.owner.inside.208, %descriptor.offset.inside.209
  %descriptor.range.inside.215 = and i1 %descriptor.owner.offset.valid.213, %descriptor.extent.inside.211
  %descriptor.range.valid.214 = and i1 %descriptor.range.inside.215, %descriptor.payload.inside.212
  %descriptor.type.valid.216 = icmp eq i32 5, 5
  %descriptor.valid.217 = and i1 %descriptor.range.valid.214, %descriptor.type.valid.216
  br i1 %descriptor.valid.217, label %descriptor.valid.218, label %descriptor.invalid.219
descriptor.invalid.219:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.218:
  %descriptor.initialized.status.220 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.197, i32 %descriptor.value.199)
  %helper.ok.221 = icmp eq i32 %descriptor.initialized.status.220, 0
  br i1 %helper.ok.221, label %helper.continue.222, label %frame.failure.0
helper.continue.222:
  %context.field.223 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.224 = load i32, ptr %context.field.223, align 4
  %stack.sub.225 = sub i32 %context.value.224, %context.value.3
  call void @al_owning_record_layout(ptr %ctx, i32 18, i32 0, i32 %context.value.3, i32 %stack.sub.225, i32 0, i32 0, i32 0)
  %context.field.226 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.227 = load i32, ptr %context.field.226, align 4
  %runtime.ok.228 = icmp eq i32 %context.value.227, 0
  br i1 %runtime.ok.228, label %runtime.continue.229, label %frame.failure.0
runtime.continue.229:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.230 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.231 = load i32, ptr %context.field.230, align 4
  %runtime.ok.232 = icmp eq i32 %context.value.231, 0
  br i1 %runtime.ok.232, label %runtime.continue.233, label %frame.failure.0
runtime.continue.233:
  %descriptor.element.234 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.235 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.234, i32 0, i32 0
  store i32 5, ptr %descriptor.field.235, align 4
  %descriptor.field.236 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.234, i32 0, i32 1
  store i32 %descriptor.value.17, ptr %descriptor.field.236, align 4
  %descriptor.field.237 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.234, i32 0, i32 2
  store i32 %descriptor.value.19, ptr %descriptor.field.237, align 4
  %descriptor.field.238 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.234, i32 0, i32 3
  store i32 %descriptor.value.21, ptr %descriptor.field.238, align 4
  %descriptor.field.239 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.234, i32 0, i32 4
  store i32 %descriptor.value.23, ptr %descriptor.field.239, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.17, i32 20, i32 %descriptor.value.21, i32 %descriptor.value.23, i32 %descriptor.value.19)
  %context.field.240 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.241 = load i32, ptr %context.field.240, align 4
  %runtime.ok.242 = icmp eq i32 %context.value.241, 0
  br i1 %runtime.ok.242, label %runtime.continue.243, label %frame.failure.0
runtime.continue.243:
  %descriptor.element.244 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 1
  %descriptor.field.245 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.244, i32 0, i32 0
  store i32 5, ptr %descriptor.field.245, align 4
  %descriptor.field.246 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.244, i32 0, i32 1
  store i32 %descriptor.value.47, ptr %descriptor.field.246, align 4
  %descriptor.field.247 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.244, i32 0, i32 2
  store i32 %descriptor.value.49, ptr %descriptor.field.247, align 4
  %descriptor.field.248 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.244, i32 0, i32 3
  store i32 %descriptor.value.51, ptr %descriptor.field.248, align 4
  %descriptor.field.249 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.244, i32 0, i32 4
  store i32 %descriptor.value.53, ptr %descriptor.field.249, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.47, i32 20, i32 %descriptor.value.51, i32 %descriptor.value.53, i32 %descriptor.value.49)
  %context.field.250 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.251 = load i32, ptr %context.field.250, align 4
  %runtime.ok.252 = icmp eq i32 %context.value.251, 0
  br i1 %runtime.ok.252, label %runtime.continue.253, label %frame.failure.0
runtime.continue.253:
  %descriptor.element.254 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 2
  %descriptor.field.255 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.254, i32 0, i32 0
  store i32 5, ptr %descriptor.field.255, align 4
  %descriptor.field.256 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.254, i32 0, i32 1
  store i32 %descriptor.value.77, ptr %descriptor.field.256, align 4
  %descriptor.field.257 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.254, i32 0, i32 2
  store i32 %descriptor.value.79, ptr %descriptor.field.257, align 4
  %descriptor.field.258 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.254, i32 0, i32 3
  store i32 %descriptor.value.81, ptr %descriptor.field.258, align 4
  %descriptor.field.259 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.254, i32 0, i32 4
  store i32 %descriptor.value.83, ptr %descriptor.field.259, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.77, i32 20, i32 %descriptor.value.81, i32 %descriptor.value.83, i32 %descriptor.value.79)
  %context.field.260 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.261 = load i32, ptr %context.field.260, align 4
  %runtime.ok.262 = icmp eq i32 %context.value.261, 0
  br i1 %runtime.ok.262, label %runtime.continue.263, label %frame.failure.0
runtime.continue.263:
  %descriptor.element.264 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 3
  %descriptor.field.265 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.264, i32 0, i32 0
  store i32 5, ptr %descriptor.field.265, align 4
  %descriptor.field.266 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.264, i32 0, i32 1
  store i32 %descriptor.value.107, ptr %descriptor.field.266, align 4
  %descriptor.field.267 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.264, i32 0, i32 2
  store i32 %descriptor.value.109, ptr %descriptor.field.267, align 4
  %descriptor.field.268 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.264, i32 0, i32 3
  store i32 %descriptor.value.111, ptr %descriptor.field.268, align 4
  %descriptor.field.269 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.264, i32 0, i32 4
  store i32 %descriptor.value.113, ptr %descriptor.field.269, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.107, i32 20, i32 %descriptor.value.111, i32 %descriptor.value.113, i32 %descriptor.value.109)
  %context.field.270 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.271 = load i32, ptr %context.field.270, align 4
  %runtime.ok.272 = icmp eq i32 %context.value.271, 0
  br i1 %runtime.ok.272, label %runtime.continue.273, label %frame.failure.0
runtime.continue.273:
  %descriptor.element.274 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 4
  %descriptor.field.275 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.274, i32 0, i32 0
  store i32 5, ptr %descriptor.field.275, align 4
  %descriptor.field.276 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.274, i32 0, i32 1
  store i32 %descriptor.value.137, ptr %descriptor.field.276, align 4
  %descriptor.field.277 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.274, i32 0, i32 2
  store i32 %descriptor.value.139, ptr %descriptor.field.277, align 4
  %descriptor.field.278 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.274, i32 0, i32 3
  store i32 %descriptor.value.141, ptr %descriptor.field.278, align 4
  %descriptor.field.279 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.274, i32 0, i32 4
  store i32 %descriptor.value.143, ptr %descriptor.field.279, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.137, i32 20, i32 %descriptor.value.141, i32 %descriptor.value.143, i32 %descriptor.value.139)
  %context.field.280 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.281 = load i32, ptr %context.field.280, align 4
  %runtime.ok.282 = icmp eq i32 %context.value.281, 0
  br i1 %runtime.ok.282, label %runtime.continue.283, label %frame.failure.0
runtime.continue.283:
  %descriptor.element.284 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 5
  %descriptor.field.285 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.284, i32 0, i32 0
  store i32 5, ptr %descriptor.field.285, align 4
  %descriptor.field.286 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.284, i32 0, i32 1
  store i32 %descriptor.value.167, ptr %descriptor.field.286, align 4
  %descriptor.field.287 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.284, i32 0, i32 2
  store i32 %descriptor.value.169, ptr %descriptor.field.287, align 4
  %descriptor.field.288 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.284, i32 0, i32 3
  store i32 %descriptor.value.171, ptr %descriptor.field.288, align 4
  %descriptor.field.289 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.284, i32 0, i32 4
  store i32 %descriptor.value.173, ptr %descriptor.field.289, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.167, i32 20, i32 %descriptor.value.171, i32 %descriptor.value.173, i32 %descriptor.value.169)
  %context.field.290 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.291 = load i32, ptr %context.field.290, align 4
  %runtime.ok.292 = icmp eq i32 %context.value.291, 0
  br i1 %runtime.ok.292, label %runtime.continue.293, label %frame.failure.0
runtime.continue.293:
  %descriptor.element.294 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 6
  %descriptor.field.295 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.294, i32 0, i32 0
  store i32 5, ptr %descriptor.field.295, align 4
  %descriptor.field.296 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.294, i32 0, i32 1
  store i32 %descriptor.value.197, ptr %descriptor.field.296, align 4
  %descriptor.field.297 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.294, i32 0, i32 2
  store i32 %descriptor.value.199, ptr %descriptor.field.297, align 4
  %descriptor.field.298 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.294, i32 0, i32 3
  store i32 %descriptor.value.201, ptr %descriptor.field.298, align 4
  %descriptor.field.299 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.294, i32 0, i32 4
  store i32 %descriptor.value.203, ptr %descriptor.field.299, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %descriptor.value.197, i32 20, i32 %descriptor.value.201, i32 %descriptor.value.203, i32 %descriptor.value.199)
  %context.field.300 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.301 = load i32, ptr %context.field.300, align 4
  %runtime.ok.302 = icmp eq i32 %context.value.301, 0
  br i1 %runtime.ok.302, label %runtime.continue.303, label %frame.failure.0
runtime.continue.303:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.304 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.305 = load i32, ptr %context.field.304, align 4
  %context.field.306 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.307 = load i32, ptr %context.field.306, align 4
  %context.field.308 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.309 = load i32, ptr %context.field.308, align 4
  %stack.offset.310 = add i32 %context.value.5, %context.value.7
  %stack.offset.311 = add i32 %context.value.305, %context.value.307
  %stack.sub.312 = sub i32 %stack.offset.310, %stack.offset.311
  %stack.sub.313 = sub i32 %context.value.7, %context.value.307
  %stack.sub.314 = sub i32 %context.value.309, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.312, i32 %stack.sub.313)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.314)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  %entry.input.descriptors.15 = alloca [7 x %AlOwningDescriptor], align 4
  %input.payload.pointer.25 = alloca i32, align 4
  %input.measured.extent.pointer.26 = alloca i32, align 4
  %input.payload.pointer.45 = alloca i32, align 4
  %input.measured.extent.pointer.46 = alloca i32, align 4
  %input.payload.pointer.65 = alloca i32, align 4
  %input.measured.extent.pointer.66 = alloca i32, align 4
  %input.payload.pointer.85 = alloca i32, align 4
  %input.measured.extent.pointer.86 = alloca i32, align 4
  %input.payload.pointer.105 = alloca i32, align 4
  %input.measured.extent.pointer.106 = alloca i32, align 4
  %input.payload.pointer.125 = alloca i32, align 4
  %input.measured.extent.pointer.126 = alloca i32, align 4
  %input.payload.pointer.145 = alloca i32, align 4
  %input.measured.extent.pointer.146 = alloca i32, align 4
  %entry.output.descriptors.267 = alloca [7 x %AlOwningDescriptor], align 4
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 7
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 7, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %entry.input.extents.present.10 = icmp ne ptr %input.extents, null
  %entry.input.bytes.present.11 = icmp ne ptr %input, null
  %entry.input.pointers.present.12 = and i1 %entry.input.extents.present.10, %entry.input.bytes.present.11
  br i1 %entry.input.pointers.present.12, label %entry.input.pointers.ok.13, label %entry.input.pointers.invalid.14
entry.input.pointers.invalid.14:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 7, i32 0)
  br label %entry.failure.0
entry.input.pointers.ok.13:
  %input.extent.pointer.16 = getelementptr inbounds i32, ptr %input.extents, i32 0
  %input.host.extent.17 = load i32, ptr %input.extent.pointer.16, align 4
  %stack.sub.18 = sub i32 %input.bytes, 0
  %input.offset.within.bytes.19 = icmp ule i32 0, %input.bytes
  %input.extent.within.bytes.20 = icmp ule i32 %input.host.extent.17, %stack.sub.18
  %input.slice.within.bytes.21 = and i1 %input.offset.within.bytes.19, %input.extent.within.bytes.20
  br i1 %input.slice.within.bytes.21, label %input.slice.ready.22, label %input.slice.invalid.23
input.slice.invalid.23:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 1, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.22:
  %host.pointer.24 = getelementptr inbounds i8, ptr %input, i32 0
  %input.measure.status.27 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 0, ptr %host.pointer.24, i32 %input.host.extent.17, i32 0, i32 1, ptr %input.payload.pointer.25, ptr %input.measured.extent.pointer.26)
  %helper.ok.28 = icmp eq i32 %input.measure.status.27, 0
  br i1 %helper.ok.28, label %helper.continue.29, label %entry.failure.0
helper.continue.29:
  %input.measured.payload.30 = load i32, ptr %input.payload.pointer.25, align 4
  %input.measured.extent.31 = load i32, ptr %input.measured.extent.pointer.26, align 4
  %input.extent.exact.32 = icmp eq i32 %input.measured.extent.31, %input.host.extent.17
  br i1 %input.extent.exact.32, label %input.extent.exact.33, label %input.extent.invalid.34
input.extent.invalid.34:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 1, i32 %input.measured.extent.31, i32 %input.host.extent.17)
  br label %entry.failure.0
input.extent.exact.33:
  %stack.offset.35 = add i32 0, %input.host.extent.17
  %input.extent.pointer.36 = getelementptr inbounds i32, ptr %input.extents, i32 1
  %input.host.extent.37 = load i32, ptr %input.extent.pointer.36, align 4
  %stack.sub.38 = sub i32 %input.bytes, %stack.offset.35
  %input.offset.within.bytes.39 = icmp ule i32 %stack.offset.35, %input.bytes
  %input.extent.within.bytes.40 = icmp ule i32 %input.host.extent.37, %stack.sub.38
  %input.slice.within.bytes.41 = and i1 %input.offset.within.bytes.39, %input.extent.within.bytes.40
  br i1 %input.slice.within.bytes.41, label %input.slice.ready.42, label %input.slice.invalid.43
input.slice.invalid.43:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 2, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.42:
  %host.pointer.44 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.35
  %input.measure.status.47 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 0, ptr %host.pointer.44, i32 %input.host.extent.37, i32 0, i32 2, ptr %input.payload.pointer.45, ptr %input.measured.extent.pointer.46)
  %helper.ok.48 = icmp eq i32 %input.measure.status.47, 0
  br i1 %helper.ok.48, label %helper.continue.49, label %entry.failure.0
helper.continue.49:
  %input.measured.payload.50 = load i32, ptr %input.payload.pointer.45, align 4
  %input.measured.extent.51 = load i32, ptr %input.measured.extent.pointer.46, align 4
  %input.extent.exact.52 = icmp eq i32 %input.measured.extent.51, %input.host.extent.37
  br i1 %input.extent.exact.52, label %input.extent.exact.53, label %input.extent.invalid.54
input.extent.invalid.54:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 2, i32 %input.measured.extent.51, i32 %input.host.extent.37)
  br label %entry.failure.0
input.extent.exact.53:
  %stack.offset.55 = add i32 %stack.offset.35, %input.host.extent.37
  %input.extent.pointer.56 = getelementptr inbounds i32, ptr %input.extents, i32 2
  %input.host.extent.57 = load i32, ptr %input.extent.pointer.56, align 4
  %stack.sub.58 = sub i32 %input.bytes, %stack.offset.55
  %input.offset.within.bytes.59 = icmp ule i32 %stack.offset.55, %input.bytes
  %input.extent.within.bytes.60 = icmp ule i32 %input.host.extent.57, %stack.sub.58
  %input.slice.within.bytes.61 = and i1 %input.offset.within.bytes.59, %input.extent.within.bytes.60
  br i1 %input.slice.within.bytes.61, label %input.slice.ready.62, label %input.slice.invalid.63
input.slice.invalid.63:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 3, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.62:
  %host.pointer.64 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.55
  %input.measure.status.67 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 0, ptr %host.pointer.64, i32 %input.host.extent.57, i32 0, i32 3, ptr %input.payload.pointer.65, ptr %input.measured.extent.pointer.66)
  %helper.ok.68 = icmp eq i32 %input.measure.status.67, 0
  br i1 %helper.ok.68, label %helper.continue.69, label %entry.failure.0
helper.continue.69:
  %input.measured.payload.70 = load i32, ptr %input.payload.pointer.65, align 4
  %input.measured.extent.71 = load i32, ptr %input.measured.extent.pointer.66, align 4
  %input.extent.exact.72 = icmp eq i32 %input.measured.extent.71, %input.host.extent.57
  br i1 %input.extent.exact.72, label %input.extent.exact.73, label %input.extent.invalid.74
input.extent.invalid.74:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 3, i32 %input.measured.extent.71, i32 %input.host.extent.57)
  br label %entry.failure.0
input.extent.exact.73:
  %stack.offset.75 = add i32 %stack.offset.55, %input.host.extent.57
  %input.extent.pointer.76 = getelementptr inbounds i32, ptr %input.extents, i32 3
  %input.host.extent.77 = load i32, ptr %input.extent.pointer.76, align 4
  %stack.sub.78 = sub i32 %input.bytes, %stack.offset.75
  %input.offset.within.bytes.79 = icmp ule i32 %stack.offset.75, %input.bytes
  %input.extent.within.bytes.80 = icmp ule i32 %input.host.extent.77, %stack.sub.78
  %input.slice.within.bytes.81 = and i1 %input.offset.within.bytes.79, %input.extent.within.bytes.80
  br i1 %input.slice.within.bytes.81, label %input.slice.ready.82, label %input.slice.invalid.83
input.slice.invalid.83:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 4, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.82:
  %host.pointer.84 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.75
  %input.measure.status.87 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 0, ptr %host.pointer.84, i32 %input.host.extent.77, i32 0, i32 4, ptr %input.payload.pointer.85, ptr %input.measured.extent.pointer.86)
  %helper.ok.88 = icmp eq i32 %input.measure.status.87, 0
  br i1 %helper.ok.88, label %helper.continue.89, label %entry.failure.0
helper.continue.89:
  %input.measured.payload.90 = load i32, ptr %input.payload.pointer.85, align 4
  %input.measured.extent.91 = load i32, ptr %input.measured.extent.pointer.86, align 4
  %input.extent.exact.92 = icmp eq i32 %input.measured.extent.91, %input.host.extent.77
  br i1 %input.extent.exact.92, label %input.extent.exact.93, label %input.extent.invalid.94
input.extent.invalid.94:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 4, i32 %input.measured.extent.91, i32 %input.host.extent.77)
  br label %entry.failure.0
input.extent.exact.93:
  %stack.offset.95 = add i32 %stack.offset.75, %input.host.extent.77
  %input.extent.pointer.96 = getelementptr inbounds i32, ptr %input.extents, i32 4
  %input.host.extent.97 = load i32, ptr %input.extent.pointer.96, align 4
  %stack.sub.98 = sub i32 %input.bytes, %stack.offset.95
  %input.offset.within.bytes.99 = icmp ule i32 %stack.offset.95, %input.bytes
  %input.extent.within.bytes.100 = icmp ule i32 %input.host.extent.97, %stack.sub.98
  %input.slice.within.bytes.101 = and i1 %input.offset.within.bytes.99, %input.extent.within.bytes.100
  br i1 %input.slice.within.bytes.101, label %input.slice.ready.102, label %input.slice.invalid.103
input.slice.invalid.103:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 5, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.102:
  %host.pointer.104 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.95
  %input.measure.status.107 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 0, ptr %host.pointer.104, i32 %input.host.extent.97, i32 0, i32 5, ptr %input.payload.pointer.105, ptr %input.measured.extent.pointer.106)
  %helper.ok.108 = icmp eq i32 %input.measure.status.107, 0
  br i1 %helper.ok.108, label %helper.continue.109, label %entry.failure.0
helper.continue.109:
  %input.measured.payload.110 = load i32, ptr %input.payload.pointer.105, align 4
  %input.measured.extent.111 = load i32, ptr %input.measured.extent.pointer.106, align 4
  %input.extent.exact.112 = icmp eq i32 %input.measured.extent.111, %input.host.extent.97
  br i1 %input.extent.exact.112, label %input.extent.exact.113, label %input.extent.invalid.114
input.extent.invalid.114:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 5, i32 %input.measured.extent.111, i32 %input.host.extent.97)
  br label %entry.failure.0
input.extent.exact.113:
  %stack.offset.115 = add i32 %stack.offset.95, %input.host.extent.97
  %input.extent.pointer.116 = getelementptr inbounds i32, ptr %input.extents, i32 5
  %input.host.extent.117 = load i32, ptr %input.extent.pointer.116, align 4
  %stack.sub.118 = sub i32 %input.bytes, %stack.offset.115
  %input.offset.within.bytes.119 = icmp ule i32 %stack.offset.115, %input.bytes
  %input.extent.within.bytes.120 = icmp ule i32 %input.host.extent.117, %stack.sub.118
  %input.slice.within.bytes.121 = and i1 %input.offset.within.bytes.119, %input.extent.within.bytes.120
  br i1 %input.slice.within.bytes.121, label %input.slice.ready.122, label %input.slice.invalid.123
input.slice.invalid.123:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 6, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.122:
  %host.pointer.124 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.115
  %input.measure.status.127 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 0, ptr %host.pointer.124, i32 %input.host.extent.117, i32 0, i32 6, ptr %input.payload.pointer.125, ptr %input.measured.extent.pointer.126)
  %helper.ok.128 = icmp eq i32 %input.measure.status.127, 0
  br i1 %helper.ok.128, label %helper.continue.129, label %entry.failure.0
helper.continue.129:
  %input.measured.payload.130 = load i32, ptr %input.payload.pointer.125, align 4
  %input.measured.extent.131 = load i32, ptr %input.measured.extent.pointer.126, align 4
  %input.extent.exact.132 = icmp eq i32 %input.measured.extent.131, %input.host.extent.117
  br i1 %input.extent.exact.132, label %input.extent.exact.133, label %input.extent.invalid.134
input.extent.invalid.134:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 6, i32 %input.measured.extent.131, i32 %input.host.extent.117)
  br label %entry.failure.0
input.extent.exact.133:
  %stack.offset.135 = add i32 %stack.offset.115, %input.host.extent.117
  %input.extent.pointer.136 = getelementptr inbounds i32, ptr %input.extents, i32 6
  %input.host.extent.137 = load i32, ptr %input.extent.pointer.136, align 4
  %stack.sub.138 = sub i32 %input.bytes, %stack.offset.135
  %input.offset.within.bytes.139 = icmp ule i32 %stack.offset.135, %input.bytes
  %input.extent.within.bytes.140 = icmp ule i32 %input.host.extent.137, %stack.sub.138
  %input.slice.within.bytes.141 = and i1 %input.offset.within.bytes.139, %input.extent.within.bytes.140
  br i1 %input.slice.within.bytes.141, label %input.slice.ready.142, label %input.slice.invalid.143
input.slice.invalid.143:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 7, i32 0, i32 0)
  br label %entry.failure.0
input.slice.ready.142:
  %host.pointer.144 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.135
  %input.measure.status.147 = call i32 @al_owning_measure_external_value(ptr %ctx, ptr @al_owning_layout, i32 0, ptr %host.pointer.144, i32 %input.host.extent.137, i32 0, i32 7, ptr %input.payload.pointer.145, ptr %input.measured.extent.pointer.146)
  %helper.ok.148 = icmp eq i32 %input.measure.status.147, 0
  br i1 %helper.ok.148, label %helper.continue.149, label %entry.failure.0
helper.continue.149:
  %input.measured.payload.150 = load i32, ptr %input.payload.pointer.145, align 4
  %input.measured.extent.151 = load i32, ptr %input.measured.extent.pointer.146, align 4
  %input.extent.exact.152 = icmp eq i32 %input.measured.extent.151, %input.host.extent.137
  br i1 %input.extent.exact.152, label %input.extent.exact.153, label %input.extent.invalid.154
input.extent.invalid.154:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 7, i32 %input.measured.extent.151, i32 %input.host.extent.137)
  br label %entry.failure.0
input.extent.exact.153:
  %stack.offset.155 = add i32 %stack.offset.135, %input.host.extent.137
  %input.total.exact.156 = icmp eq i32 %stack.offset.155, %input.bytes
  br i1 %input.total.exact.156, label %input.valid.157, label %input.invalid.158
input.invalid.158:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 %stack.offset.155, i32 %input.bytes)
  br label %entry.failure.0
input.valid.157:
  %reserve.status.159 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.155, i32 8)
  %reserve.ok.160 = icmp eq i32 %reserve.status.159, 0
  br i1 %reserve.ok.160, label %reserve.continue.161, label %entry.failure.0
reserve.continue.161:
  %host.pointer.162 = getelementptr inbounds i8, ptr %input, i32 0
  %input.copy.status.163 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 0, ptr %host.pointer.162, i32 %input.host.extent.17, i32 0, i32 %input.measured.payload.30, i32 %input.host.extent.17, i32 5, i32 9)
  %helper.ok.164 = icmp eq i32 %input.copy.status.163, 0
  br i1 %helper.ok.164, label %helper.continue.165, label %entry.failure.0
helper.continue.165:
  %stack.offset.166 = add i32 0, %input.host.extent.17
  %descriptor.element.167 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.15, i32 0
  %descriptor.field.168 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.167, i32 0, i32 0
  store i32 5, ptr %descriptor.field.168, align 4
  %descriptor.field.169 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.167, i32 0, i32 1
  store i32 0, ptr %descriptor.field.169, align 4
  %descriptor.field.170 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.167, i32 0, i32 2
  store i32 %input.host.extent.17, ptr %descriptor.field.170, align 4
  %descriptor.field.171 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.167, i32 0, i32 3
  store i32 %input.measured.payload.30, ptr %descriptor.field.171, align 4
  %descriptor.field.172 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.167, i32 0, i32 4
  store i32 %stack.offset.166, ptr %descriptor.field.172, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 0, i32 20, i32 %input.measured.payload.30, i32 %stack.offset.166, i32 %input.host.extent.17)
  %context.field.173 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.174 = load i32, ptr %context.field.173, align 4
  %runtime.ok.175 = icmp eq i32 %context.value.174, 0
  br i1 %runtime.ok.175, label %runtime.continue.176, label %entry.failure.0
runtime.continue.176:
  %host.pointer.177 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.35
  %input.copy.status.178 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.35, ptr %host.pointer.177, i32 %input.host.extent.37, i32 0, i32 %input.measured.payload.50, i32 %input.host.extent.37, i32 5, i32 10)
  %helper.ok.179 = icmp eq i32 %input.copy.status.178, 0
  br i1 %helper.ok.179, label %helper.continue.180, label %entry.failure.0
helper.continue.180:
  %stack.offset.181 = add i32 %stack.offset.35, %input.host.extent.37
  %descriptor.element.182 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.15, i32 1
  %descriptor.field.183 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.182, i32 0, i32 0
  store i32 5, ptr %descriptor.field.183, align 4
  %descriptor.field.184 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.182, i32 0, i32 1
  store i32 %stack.offset.35, ptr %descriptor.field.184, align 4
  %descriptor.field.185 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.182, i32 0, i32 2
  store i32 %input.host.extent.37, ptr %descriptor.field.185, align 4
  %descriptor.field.186 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.182, i32 0, i32 3
  store i32 %input.measured.payload.50, ptr %descriptor.field.186, align 4
  %descriptor.field.187 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.182, i32 0, i32 4
  store i32 %stack.offset.181, ptr %descriptor.field.187, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %stack.offset.35, i32 20, i32 %input.measured.payload.50, i32 %stack.offset.181, i32 %input.host.extent.37)
  %context.field.188 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.189 = load i32, ptr %context.field.188, align 4
  %runtime.ok.190 = icmp eq i32 %context.value.189, 0
  br i1 %runtime.ok.190, label %runtime.continue.191, label %entry.failure.0
runtime.continue.191:
  %host.pointer.192 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.55
  %input.copy.status.193 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.55, ptr %host.pointer.192, i32 %input.host.extent.57, i32 0, i32 %input.measured.payload.70, i32 %input.host.extent.57, i32 5, i32 11)
  %helper.ok.194 = icmp eq i32 %input.copy.status.193, 0
  br i1 %helper.ok.194, label %helper.continue.195, label %entry.failure.0
helper.continue.195:
  %stack.offset.196 = add i32 %stack.offset.55, %input.host.extent.57
  %descriptor.element.197 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.15, i32 2
  %descriptor.field.198 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.197, i32 0, i32 0
  store i32 5, ptr %descriptor.field.198, align 4
  %descriptor.field.199 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.197, i32 0, i32 1
  store i32 %stack.offset.55, ptr %descriptor.field.199, align 4
  %descriptor.field.200 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.197, i32 0, i32 2
  store i32 %input.host.extent.57, ptr %descriptor.field.200, align 4
  %descriptor.field.201 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.197, i32 0, i32 3
  store i32 %input.measured.payload.70, ptr %descriptor.field.201, align 4
  %descriptor.field.202 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.197, i32 0, i32 4
  store i32 %stack.offset.196, ptr %descriptor.field.202, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %stack.offset.55, i32 20, i32 %input.measured.payload.70, i32 %stack.offset.196, i32 %input.host.extent.57)
  %context.field.203 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.204 = load i32, ptr %context.field.203, align 4
  %runtime.ok.205 = icmp eq i32 %context.value.204, 0
  br i1 %runtime.ok.205, label %runtime.continue.206, label %entry.failure.0
runtime.continue.206:
  %host.pointer.207 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.75
  %input.copy.status.208 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.75, ptr %host.pointer.207, i32 %input.host.extent.77, i32 0, i32 %input.measured.payload.90, i32 %input.host.extent.77, i32 5, i32 12)
  %helper.ok.209 = icmp eq i32 %input.copy.status.208, 0
  br i1 %helper.ok.209, label %helper.continue.210, label %entry.failure.0
helper.continue.210:
  %stack.offset.211 = add i32 %stack.offset.75, %input.host.extent.77
  %descriptor.element.212 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.15, i32 3
  %descriptor.field.213 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.212, i32 0, i32 0
  store i32 5, ptr %descriptor.field.213, align 4
  %descriptor.field.214 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.212, i32 0, i32 1
  store i32 %stack.offset.75, ptr %descriptor.field.214, align 4
  %descriptor.field.215 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.212, i32 0, i32 2
  store i32 %input.host.extent.77, ptr %descriptor.field.215, align 4
  %descriptor.field.216 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.212, i32 0, i32 3
  store i32 %input.measured.payload.90, ptr %descriptor.field.216, align 4
  %descriptor.field.217 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.212, i32 0, i32 4
  store i32 %stack.offset.211, ptr %descriptor.field.217, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %stack.offset.75, i32 20, i32 %input.measured.payload.90, i32 %stack.offset.211, i32 %input.host.extent.77)
  %context.field.218 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.219 = load i32, ptr %context.field.218, align 4
  %runtime.ok.220 = icmp eq i32 %context.value.219, 0
  br i1 %runtime.ok.220, label %runtime.continue.221, label %entry.failure.0
runtime.continue.221:
  %host.pointer.222 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.95
  %input.copy.status.223 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.95, ptr %host.pointer.222, i32 %input.host.extent.97, i32 0, i32 %input.measured.payload.110, i32 %input.host.extent.97, i32 5, i32 13)
  %helper.ok.224 = icmp eq i32 %input.copy.status.223, 0
  br i1 %helper.ok.224, label %helper.continue.225, label %entry.failure.0
helper.continue.225:
  %stack.offset.226 = add i32 %stack.offset.95, %input.host.extent.97
  %descriptor.element.227 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.15, i32 4
  %descriptor.field.228 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.227, i32 0, i32 0
  store i32 5, ptr %descriptor.field.228, align 4
  %descriptor.field.229 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.227, i32 0, i32 1
  store i32 %stack.offset.95, ptr %descriptor.field.229, align 4
  %descriptor.field.230 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.227, i32 0, i32 2
  store i32 %input.host.extent.97, ptr %descriptor.field.230, align 4
  %descriptor.field.231 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.227, i32 0, i32 3
  store i32 %input.measured.payload.110, ptr %descriptor.field.231, align 4
  %descriptor.field.232 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.227, i32 0, i32 4
  store i32 %stack.offset.226, ptr %descriptor.field.232, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %stack.offset.95, i32 20, i32 %input.measured.payload.110, i32 %stack.offset.226, i32 %input.host.extent.97)
  %context.field.233 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.234 = load i32, ptr %context.field.233, align 4
  %runtime.ok.235 = icmp eq i32 %context.value.234, 0
  br i1 %runtime.ok.235, label %runtime.continue.236, label %entry.failure.0
runtime.continue.236:
  %host.pointer.237 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.115
  %input.copy.status.238 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.115, ptr %host.pointer.237, i32 %input.host.extent.117, i32 0, i32 %input.measured.payload.130, i32 %input.host.extent.117, i32 5, i32 14)
  %helper.ok.239 = icmp eq i32 %input.copy.status.238, 0
  br i1 %helper.ok.239, label %helper.continue.240, label %entry.failure.0
helper.continue.240:
  %stack.offset.241 = add i32 %stack.offset.115, %input.host.extent.117
  %descriptor.element.242 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.15, i32 5
  %descriptor.field.243 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.242, i32 0, i32 0
  store i32 5, ptr %descriptor.field.243, align 4
  %descriptor.field.244 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.242, i32 0, i32 1
  store i32 %stack.offset.115, ptr %descriptor.field.244, align 4
  %descriptor.field.245 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.242, i32 0, i32 2
  store i32 %input.host.extent.117, ptr %descriptor.field.245, align 4
  %descriptor.field.246 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.242, i32 0, i32 3
  store i32 %input.measured.payload.130, ptr %descriptor.field.246, align 4
  %descriptor.field.247 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.242, i32 0, i32 4
  store i32 %stack.offset.241, ptr %descriptor.field.247, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %stack.offset.115, i32 20, i32 %input.measured.payload.130, i32 %stack.offset.241, i32 %input.host.extent.117)
  %context.field.248 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.249 = load i32, ptr %context.field.248, align 4
  %runtime.ok.250 = icmp eq i32 %context.value.249, 0
  br i1 %runtime.ok.250, label %runtime.continue.251, label %entry.failure.0
runtime.continue.251:
  %host.pointer.252 = getelementptr inbounds i8, ptr %input, i32 %stack.offset.135
  %input.copy.status.253 = call i32 @al_owning_copy_external_bounded(ptr %ctx, i32 %stack.offset.135, ptr %host.pointer.252, i32 %input.host.extent.137, i32 0, i32 %input.measured.payload.150, i32 %input.host.extent.137, i32 5, i32 15)
  %helper.ok.254 = icmp eq i32 %input.copy.status.253, 0
  br i1 %helper.ok.254, label %helper.continue.255, label %entry.failure.0
helper.continue.255:
  %stack.offset.256 = add i32 %stack.offset.135, %input.host.extent.137
  %descriptor.element.257 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.input.descriptors.15, i32 6
  %descriptor.field.258 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.257, i32 0, i32 0
  store i32 5, ptr %descriptor.field.258, align 4
  %descriptor.field.259 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.257, i32 0, i32 1
  store i32 %stack.offset.135, ptr %descriptor.field.259, align 4
  %descriptor.field.260 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.257, i32 0, i32 2
  store i32 %input.host.extent.137, ptr %descriptor.field.260, align 4
  %descriptor.field.261 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.257, i32 0, i32 3
  store i32 %input.measured.payload.150, ptr %descriptor.field.261, align 4
  %descriptor.field.262 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.257, i32 0, i32 4
  store i32 %stack.offset.256, ptr %descriptor.field.262, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 5, i32 %stack.offset.135, i32 20, i32 %input.measured.payload.150, i32 %stack.offset.256, i32 %input.host.extent.137)
  %context.field.263 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.264 = load i32, ptr %context.field.263, align 4
  %runtime.ok.265 = icmp eq i32 %context.value.264, 0
  br i1 %runtime.ok.265, label %runtime.continue.266, label %entry.failure.0
runtime.continue.266:
  %entry.body.status.268 = call i32 @agentlang_entry_frame(ptr %ctx, ptr %entry.input.descriptors.15, ptr %entry.output.descriptors.267, i32 16)
  %entry.body.ok.269 = icmp eq i32 %entry.body.status.268, 0
  br i1 %entry.body.ok.269, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.270 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.267, i32 0
  %descriptor.field.271 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.270, i32 0, i32 0
  %descriptor.value.272 = load i32, ptr %descriptor.field.271, align 4
  %descriptor.field.273 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.270, i32 0, i32 1
  %descriptor.value.274 = load i32, ptr %descriptor.field.273, align 4
  %descriptor.field.275 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.270, i32 0, i32 2
  %descriptor.value.276 = load i32, ptr %descriptor.field.275, align 4
  %descriptor.field.277 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.270, i32 0, i32 3
  %descriptor.value.278 = load i32, ptr %descriptor.field.277, align 4
  %descriptor.field.279 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.270, i32 0, i32 4
  %descriptor.value.280 = load i32, ptr %descriptor.field.279, align 4
  %entry.output.type.valid.281 = icmp eq i32 %descriptor.value.272, 5
  br i1 %entry.output.type.valid.281, label %entry.output.type.ok.282, label %entry.output.type.invalid.283
entry.output.type.invalid.283:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.282:
  %context.field.284 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.285 = load i32, ptr %context.field.284, align 4
  %stack.sub.288 = sub i32 %descriptor.value.280, %descriptor.value.274
  %descriptor.owner.inside.286 = icmp ule i32 %descriptor.value.280, %context.value.285
  %descriptor.offset.inside.287 = icmp ule i32 %descriptor.value.274, %descriptor.value.280
  %descriptor.extent.inside.289 = icmp ule i32 %descriptor.value.276, %stack.sub.288
  %descriptor.payload.inside.290 = icmp ule i32 %descriptor.value.278, %descriptor.value.276
  %descriptor.owner.offset.valid.291 = and i1 %descriptor.owner.inside.286, %descriptor.offset.inside.287
  %descriptor.range.inside.293 = and i1 %descriptor.owner.offset.valid.291, %descriptor.extent.inside.289
  %descriptor.range.valid.292 = and i1 %descriptor.range.inside.293, %descriptor.payload.inside.290
  %descriptor.type.valid.294 = icmp eq i32 5, 5
  %descriptor.valid.295 = and i1 %descriptor.range.valid.292, %descriptor.type.valid.294
  br i1 %descriptor.valid.295, label %descriptor.valid.296, label %descriptor.invalid.297
descriptor.invalid.297:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.296:
  %descriptor.initialized.status.298 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.274, i32 %descriptor.value.276)
  %helper.ok.299 = icmp eq i32 %descriptor.initialized.status.298, 0
  br i1 %helper.ok.299, label %helper.continue.300, label %entry.failure.0
helper.continue.300:
  %entry.output.size.i64.301 = zext i32 %descriptor.value.276 to i64
  %entry.output.total.i64.302 = add i64 0, %entry.output.size.i64.301
  %descriptor.element.303 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.267, i32 1
  %descriptor.field.304 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.303, i32 0, i32 0
  %descriptor.value.305 = load i32, ptr %descriptor.field.304, align 4
  %descriptor.field.306 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.303, i32 0, i32 1
  %descriptor.value.307 = load i32, ptr %descriptor.field.306, align 4
  %descriptor.field.308 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.303, i32 0, i32 2
  %descriptor.value.309 = load i32, ptr %descriptor.field.308, align 4
  %descriptor.field.310 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.303, i32 0, i32 3
  %descriptor.value.311 = load i32, ptr %descriptor.field.310, align 4
  %descriptor.field.312 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.303, i32 0, i32 4
  %descriptor.value.313 = load i32, ptr %descriptor.field.312, align 4
  %entry.output.type.valid.314 = icmp eq i32 %descriptor.value.305, 5
  br i1 %entry.output.type.valid.314, label %entry.output.type.ok.315, label %entry.output.type.invalid.316
entry.output.type.invalid.316:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.315:
  %context.field.317 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.318 = load i32, ptr %context.field.317, align 4
  %stack.sub.321 = sub i32 %descriptor.value.313, %descriptor.value.307
  %descriptor.owner.inside.319 = icmp ule i32 %descriptor.value.313, %context.value.318
  %descriptor.offset.inside.320 = icmp ule i32 %descriptor.value.307, %descriptor.value.313
  %descriptor.extent.inside.322 = icmp ule i32 %descriptor.value.309, %stack.sub.321
  %descriptor.payload.inside.323 = icmp ule i32 %descriptor.value.311, %descriptor.value.309
  %descriptor.owner.offset.valid.324 = and i1 %descriptor.owner.inside.319, %descriptor.offset.inside.320
  %descriptor.range.inside.326 = and i1 %descriptor.owner.offset.valid.324, %descriptor.extent.inside.322
  %descriptor.range.valid.325 = and i1 %descriptor.range.inside.326, %descriptor.payload.inside.323
  %descriptor.type.valid.327 = icmp eq i32 5, 5
  %descriptor.valid.328 = and i1 %descriptor.range.valid.325, %descriptor.type.valid.327
  br i1 %descriptor.valid.328, label %descriptor.valid.329, label %descriptor.invalid.330
descriptor.invalid.330:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.329:
  %descriptor.initialized.status.331 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.307, i32 %descriptor.value.309)
  %helper.ok.332 = icmp eq i32 %descriptor.initialized.status.331, 0
  br i1 %helper.ok.332, label %helper.continue.333, label %entry.failure.0
helper.continue.333:
  %entry.output.size.i64.334 = zext i32 %descriptor.value.309 to i64
  %entry.output.total.i64.335 = add i64 %entry.output.total.i64.302, %entry.output.size.i64.334
  %descriptor.element.336 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.267, i32 2
  %descriptor.field.337 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.336, i32 0, i32 0
  %descriptor.value.338 = load i32, ptr %descriptor.field.337, align 4
  %descriptor.field.339 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.336, i32 0, i32 1
  %descriptor.value.340 = load i32, ptr %descriptor.field.339, align 4
  %descriptor.field.341 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.336, i32 0, i32 2
  %descriptor.value.342 = load i32, ptr %descriptor.field.341, align 4
  %descriptor.field.343 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.336, i32 0, i32 3
  %descriptor.value.344 = load i32, ptr %descriptor.field.343, align 4
  %descriptor.field.345 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.336, i32 0, i32 4
  %descriptor.value.346 = load i32, ptr %descriptor.field.345, align 4
  %entry.output.type.valid.347 = icmp eq i32 %descriptor.value.338, 5
  br i1 %entry.output.type.valid.347, label %entry.output.type.ok.348, label %entry.output.type.invalid.349
entry.output.type.invalid.349:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.348:
  %context.field.350 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.351 = load i32, ptr %context.field.350, align 4
  %stack.sub.354 = sub i32 %descriptor.value.346, %descriptor.value.340
  %descriptor.owner.inside.352 = icmp ule i32 %descriptor.value.346, %context.value.351
  %descriptor.offset.inside.353 = icmp ule i32 %descriptor.value.340, %descriptor.value.346
  %descriptor.extent.inside.355 = icmp ule i32 %descriptor.value.342, %stack.sub.354
  %descriptor.payload.inside.356 = icmp ule i32 %descriptor.value.344, %descriptor.value.342
  %descriptor.owner.offset.valid.357 = and i1 %descriptor.owner.inside.352, %descriptor.offset.inside.353
  %descriptor.range.inside.359 = and i1 %descriptor.owner.offset.valid.357, %descriptor.extent.inside.355
  %descriptor.range.valid.358 = and i1 %descriptor.range.inside.359, %descriptor.payload.inside.356
  %descriptor.type.valid.360 = icmp eq i32 5, 5
  %descriptor.valid.361 = and i1 %descriptor.range.valid.358, %descriptor.type.valid.360
  br i1 %descriptor.valid.361, label %descriptor.valid.362, label %descriptor.invalid.363
descriptor.invalid.363:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.362:
  %descriptor.initialized.status.364 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.340, i32 %descriptor.value.342)
  %helper.ok.365 = icmp eq i32 %descriptor.initialized.status.364, 0
  br i1 %helper.ok.365, label %helper.continue.366, label %entry.failure.0
helper.continue.366:
  %entry.output.size.i64.367 = zext i32 %descriptor.value.342 to i64
  %entry.output.total.i64.368 = add i64 %entry.output.total.i64.335, %entry.output.size.i64.367
  %descriptor.element.369 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.267, i32 3
  %descriptor.field.370 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.369, i32 0, i32 0
  %descriptor.value.371 = load i32, ptr %descriptor.field.370, align 4
  %descriptor.field.372 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.369, i32 0, i32 1
  %descriptor.value.373 = load i32, ptr %descriptor.field.372, align 4
  %descriptor.field.374 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.369, i32 0, i32 2
  %descriptor.value.375 = load i32, ptr %descriptor.field.374, align 4
  %descriptor.field.376 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.369, i32 0, i32 3
  %descriptor.value.377 = load i32, ptr %descriptor.field.376, align 4
  %descriptor.field.378 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.369, i32 0, i32 4
  %descriptor.value.379 = load i32, ptr %descriptor.field.378, align 4
  %entry.output.type.valid.380 = icmp eq i32 %descriptor.value.371, 5
  br i1 %entry.output.type.valid.380, label %entry.output.type.ok.381, label %entry.output.type.invalid.382
entry.output.type.invalid.382:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.381:
  %context.field.383 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.384 = load i32, ptr %context.field.383, align 4
  %stack.sub.387 = sub i32 %descriptor.value.379, %descriptor.value.373
  %descriptor.owner.inside.385 = icmp ule i32 %descriptor.value.379, %context.value.384
  %descriptor.offset.inside.386 = icmp ule i32 %descriptor.value.373, %descriptor.value.379
  %descriptor.extent.inside.388 = icmp ule i32 %descriptor.value.375, %stack.sub.387
  %descriptor.payload.inside.389 = icmp ule i32 %descriptor.value.377, %descriptor.value.375
  %descriptor.owner.offset.valid.390 = and i1 %descriptor.owner.inside.385, %descriptor.offset.inside.386
  %descriptor.range.inside.392 = and i1 %descriptor.owner.offset.valid.390, %descriptor.extent.inside.388
  %descriptor.range.valid.391 = and i1 %descriptor.range.inside.392, %descriptor.payload.inside.389
  %descriptor.type.valid.393 = icmp eq i32 5, 5
  %descriptor.valid.394 = and i1 %descriptor.range.valid.391, %descriptor.type.valid.393
  br i1 %descriptor.valid.394, label %descriptor.valid.395, label %descriptor.invalid.396
descriptor.invalid.396:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.395:
  %descriptor.initialized.status.397 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.373, i32 %descriptor.value.375)
  %helper.ok.398 = icmp eq i32 %descriptor.initialized.status.397, 0
  br i1 %helper.ok.398, label %helper.continue.399, label %entry.failure.0
helper.continue.399:
  %entry.output.size.i64.400 = zext i32 %descriptor.value.375 to i64
  %entry.output.total.i64.401 = add i64 %entry.output.total.i64.368, %entry.output.size.i64.400
  %descriptor.element.402 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.267, i32 4
  %descriptor.field.403 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.402, i32 0, i32 0
  %descriptor.value.404 = load i32, ptr %descriptor.field.403, align 4
  %descriptor.field.405 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.402, i32 0, i32 1
  %descriptor.value.406 = load i32, ptr %descriptor.field.405, align 4
  %descriptor.field.407 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.402, i32 0, i32 2
  %descriptor.value.408 = load i32, ptr %descriptor.field.407, align 4
  %descriptor.field.409 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.402, i32 0, i32 3
  %descriptor.value.410 = load i32, ptr %descriptor.field.409, align 4
  %descriptor.field.411 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.402, i32 0, i32 4
  %descriptor.value.412 = load i32, ptr %descriptor.field.411, align 4
  %entry.output.type.valid.413 = icmp eq i32 %descriptor.value.404, 5
  br i1 %entry.output.type.valid.413, label %entry.output.type.ok.414, label %entry.output.type.invalid.415
entry.output.type.invalid.415:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.414:
  %context.field.416 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.417 = load i32, ptr %context.field.416, align 4
  %stack.sub.420 = sub i32 %descriptor.value.412, %descriptor.value.406
  %descriptor.owner.inside.418 = icmp ule i32 %descriptor.value.412, %context.value.417
  %descriptor.offset.inside.419 = icmp ule i32 %descriptor.value.406, %descriptor.value.412
  %descriptor.extent.inside.421 = icmp ule i32 %descriptor.value.408, %stack.sub.420
  %descriptor.payload.inside.422 = icmp ule i32 %descriptor.value.410, %descriptor.value.408
  %descriptor.owner.offset.valid.423 = and i1 %descriptor.owner.inside.418, %descriptor.offset.inside.419
  %descriptor.range.inside.425 = and i1 %descriptor.owner.offset.valid.423, %descriptor.extent.inside.421
  %descriptor.range.valid.424 = and i1 %descriptor.range.inside.425, %descriptor.payload.inside.422
  %descriptor.type.valid.426 = icmp eq i32 5, 5
  %descriptor.valid.427 = and i1 %descriptor.range.valid.424, %descriptor.type.valid.426
  br i1 %descriptor.valid.427, label %descriptor.valid.428, label %descriptor.invalid.429
descriptor.invalid.429:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.428:
  %descriptor.initialized.status.430 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.406, i32 %descriptor.value.408)
  %helper.ok.431 = icmp eq i32 %descriptor.initialized.status.430, 0
  br i1 %helper.ok.431, label %helper.continue.432, label %entry.failure.0
helper.continue.432:
  %entry.output.size.i64.433 = zext i32 %descriptor.value.408 to i64
  %entry.output.total.i64.434 = add i64 %entry.output.total.i64.401, %entry.output.size.i64.433
  %descriptor.element.435 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.267, i32 5
  %descriptor.field.436 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.435, i32 0, i32 0
  %descriptor.value.437 = load i32, ptr %descriptor.field.436, align 4
  %descriptor.field.438 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.435, i32 0, i32 1
  %descriptor.value.439 = load i32, ptr %descriptor.field.438, align 4
  %descriptor.field.440 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.435, i32 0, i32 2
  %descriptor.value.441 = load i32, ptr %descriptor.field.440, align 4
  %descriptor.field.442 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.435, i32 0, i32 3
  %descriptor.value.443 = load i32, ptr %descriptor.field.442, align 4
  %descriptor.field.444 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.435, i32 0, i32 4
  %descriptor.value.445 = load i32, ptr %descriptor.field.444, align 4
  %entry.output.type.valid.446 = icmp eq i32 %descriptor.value.437, 5
  br i1 %entry.output.type.valid.446, label %entry.output.type.ok.447, label %entry.output.type.invalid.448
entry.output.type.invalid.448:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.447:
  %context.field.449 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.450 = load i32, ptr %context.field.449, align 4
  %stack.sub.453 = sub i32 %descriptor.value.445, %descriptor.value.439
  %descriptor.owner.inside.451 = icmp ule i32 %descriptor.value.445, %context.value.450
  %descriptor.offset.inside.452 = icmp ule i32 %descriptor.value.439, %descriptor.value.445
  %descriptor.extent.inside.454 = icmp ule i32 %descriptor.value.441, %stack.sub.453
  %descriptor.payload.inside.455 = icmp ule i32 %descriptor.value.443, %descriptor.value.441
  %descriptor.owner.offset.valid.456 = and i1 %descriptor.owner.inside.451, %descriptor.offset.inside.452
  %descriptor.range.inside.458 = and i1 %descriptor.owner.offset.valid.456, %descriptor.extent.inside.454
  %descriptor.range.valid.457 = and i1 %descriptor.range.inside.458, %descriptor.payload.inside.455
  %descriptor.type.valid.459 = icmp eq i32 5, 5
  %descriptor.valid.460 = and i1 %descriptor.range.valid.457, %descriptor.type.valid.459
  br i1 %descriptor.valid.460, label %descriptor.valid.461, label %descriptor.invalid.462
descriptor.invalid.462:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.461:
  %descriptor.initialized.status.463 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.439, i32 %descriptor.value.441)
  %helper.ok.464 = icmp eq i32 %descriptor.initialized.status.463, 0
  br i1 %helper.ok.464, label %helper.continue.465, label %entry.failure.0
helper.continue.465:
  %entry.output.size.i64.466 = zext i32 %descriptor.value.441 to i64
  %entry.output.total.i64.467 = add i64 %entry.output.total.i64.434, %entry.output.size.i64.466
  %descriptor.element.468 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.267, i32 6
  %descriptor.field.469 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.468, i32 0, i32 0
  %descriptor.value.470 = load i32, ptr %descriptor.field.469, align 4
  %descriptor.field.471 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.468, i32 0, i32 1
  %descriptor.value.472 = load i32, ptr %descriptor.field.471, align 4
  %descriptor.field.473 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.468, i32 0, i32 2
  %descriptor.value.474 = load i32, ptr %descriptor.field.473, align 4
  %descriptor.field.475 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.468, i32 0, i32 3
  %descriptor.value.476 = load i32, ptr %descriptor.field.475, align 4
  %descriptor.field.477 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.468, i32 0, i32 4
  %descriptor.value.478 = load i32, ptr %descriptor.field.477, align 4
  %entry.output.type.valid.479 = icmp eq i32 %descriptor.value.470, 5
  br i1 %entry.output.type.valid.479, label %entry.output.type.ok.480, label %entry.output.type.invalid.481
entry.output.type.invalid.481:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.480:
  %context.field.482 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.483 = load i32, ptr %context.field.482, align 4
  %stack.sub.486 = sub i32 %descriptor.value.478, %descriptor.value.472
  %descriptor.owner.inside.484 = icmp ule i32 %descriptor.value.478, %context.value.483
  %descriptor.offset.inside.485 = icmp ule i32 %descriptor.value.472, %descriptor.value.478
  %descriptor.extent.inside.487 = icmp ule i32 %descriptor.value.474, %stack.sub.486
  %descriptor.payload.inside.488 = icmp ule i32 %descriptor.value.476, %descriptor.value.474
  %descriptor.owner.offset.valid.489 = and i1 %descriptor.owner.inside.484, %descriptor.offset.inside.485
  %descriptor.range.inside.491 = and i1 %descriptor.owner.offset.valid.489, %descriptor.extent.inside.487
  %descriptor.range.valid.490 = and i1 %descriptor.range.inside.491, %descriptor.payload.inside.488
  %descriptor.type.valid.492 = icmp eq i32 5, 5
  %descriptor.valid.493 = and i1 %descriptor.range.valid.490, %descriptor.type.valid.492
  br i1 %descriptor.valid.493, label %descriptor.valid.494, label %descriptor.invalid.495
descriptor.invalid.495:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.494:
  %descriptor.initialized.status.496 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.472, i32 %descriptor.value.474)
  %helper.ok.497 = icmp eq i32 %descriptor.initialized.status.496, 0
  br i1 %helper.ok.497, label %helper.continue.498, label %entry.failure.0
helper.continue.498:
  %entry.output.size.i64.499 = zext i32 %descriptor.value.474 to i64
  %entry.output.total.i64.500 = add i64 %entry.output.total.i64.467, %entry.output.size.i64.499
  %entry.retained.capacity.i64.501 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.502 = icmp ule i64 %entry.output.total.i64.500, 4294967295
  %entry.retained.required.truncated.503 = trunc i64 %entry.output.total.i64.500 to i32
  %entry.retained.required.504 = select i1 %entry.retained.required.fits.u32.502, i32 %entry.retained.required.truncated.503, i32 4294967295
  %entry.retained.capacity.ok.505 = icmp ule i64 %entry.output.total.i64.500, %entry.retained.capacity.i64.501
  br i1 %entry.retained.capacity.ok.505, label %entry.retained.capacity.ready.506, label %entry.retained.capacity.failure.507
entry.retained.capacity.failure.507:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.504, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.506:
  %host.pointer.508 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.509 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.508, i32 %stack.sub.509, i32 %descriptor.value.274, i32 %descriptor.value.276, i32 5)
  %context.field.510 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.511 = load i32, ptr %context.field.510, align 4
  %runtime.ok.512 = icmp eq i32 %context.value.511, 0
  br i1 %runtime.ok.512, label %runtime.continue.513, label %entry.failure.0
runtime.continue.513:
  %stack.offset.514 = add i32 0, %descriptor.value.276
  %host.pointer.515 = getelementptr inbounds i8, ptr %retained, i32 %stack.offset.514
  %stack.sub.516 = sub i32 %retained.capacity, %stack.offset.514
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.515, i32 %stack.sub.516, i32 %descriptor.value.307, i32 %descriptor.value.309, i32 5)
  %context.field.517 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.518 = load i32, ptr %context.field.517, align 4
  %runtime.ok.519 = icmp eq i32 %context.value.518, 0
  br i1 %runtime.ok.519, label %runtime.continue.520, label %entry.failure.0
runtime.continue.520:
  %stack.offset.521 = add i32 %stack.offset.514, %descriptor.value.309
  %host.pointer.522 = getelementptr inbounds i8, ptr %retained, i32 %stack.offset.521
  %stack.sub.523 = sub i32 %retained.capacity, %stack.offset.521
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.522, i32 %stack.sub.523, i32 %descriptor.value.340, i32 %descriptor.value.342, i32 5)
  %context.field.524 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.525 = load i32, ptr %context.field.524, align 4
  %runtime.ok.526 = icmp eq i32 %context.value.525, 0
  br i1 %runtime.ok.526, label %runtime.continue.527, label %entry.failure.0
runtime.continue.527:
  %stack.offset.528 = add i32 %stack.offset.521, %descriptor.value.342
  %host.pointer.529 = getelementptr inbounds i8, ptr %retained, i32 %stack.offset.528
  %stack.sub.530 = sub i32 %retained.capacity, %stack.offset.528
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.529, i32 %stack.sub.530, i32 %descriptor.value.373, i32 %descriptor.value.375, i32 5)
  %context.field.531 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.532 = load i32, ptr %context.field.531, align 4
  %runtime.ok.533 = icmp eq i32 %context.value.532, 0
  br i1 %runtime.ok.533, label %runtime.continue.534, label %entry.failure.0
runtime.continue.534:
  %stack.offset.535 = add i32 %stack.offset.528, %descriptor.value.375
  %host.pointer.536 = getelementptr inbounds i8, ptr %retained, i32 %stack.offset.535
  %stack.sub.537 = sub i32 %retained.capacity, %stack.offset.535
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.536, i32 %stack.sub.537, i32 %descriptor.value.406, i32 %descriptor.value.408, i32 5)
  %context.field.538 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.539 = load i32, ptr %context.field.538, align 4
  %runtime.ok.540 = icmp eq i32 %context.value.539, 0
  br i1 %runtime.ok.540, label %runtime.continue.541, label %entry.failure.0
runtime.continue.541:
  %stack.offset.542 = add i32 %stack.offset.535, %descriptor.value.408
  %host.pointer.543 = getelementptr inbounds i8, ptr %retained, i32 %stack.offset.542
  %stack.sub.544 = sub i32 %retained.capacity, %stack.offset.542
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.543, i32 %stack.sub.544, i32 %descriptor.value.439, i32 %descriptor.value.441, i32 5)
  %context.field.545 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.546 = load i32, ptr %context.field.545, align 4
  %runtime.ok.547 = icmp eq i32 %context.value.546, 0
  br i1 %runtime.ok.547, label %runtime.continue.548, label %entry.failure.0
runtime.continue.548:
  %stack.offset.549 = add i32 %stack.offset.542, %descriptor.value.441
  %host.pointer.550 = getelementptr inbounds i8, ptr %retained, i32 %stack.offset.549
  %stack.sub.551 = sub i32 %retained.capacity, %stack.offset.549
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.550, i32 %stack.sub.551, i32 %descriptor.value.472, i32 %descriptor.value.474, i32 5)
  %context.field.552 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.553 = load i32, ptr %context.field.552, align 4
  %runtime.ok.554 = icmp eq i32 %context.value.553, 0
  br i1 %runtime.ok.554, label %runtime.continue.555, label %entry.failure.0
runtime.continue.555:
  %stack.offset.556 = add i32 %stack.offset.549, %descriptor.value.474
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.557 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.558 = load i32, ptr %context.field.557, align 4
  %context.field.559 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.560 = load i32, ptr %context.field.559, align 4
  %stack.sub.561 = sub i32 0, %context.value.558
  %stack.sub.562 = sub i32 0, %context.value.560
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.561, i32 %stack.sub.562)
  %context.field.563 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.564 = load i32, ptr %context.field.563, align 4
  %runtime.ok.565 = icmp eq i32 %context.value.564, 0
  br i1 %runtime.ok.565, label %runtime.continue.566, label %entry.failure.0
runtime.continue.566:
  br label %entry.return.status
entry.failure.0:
  %context.field.567 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.568 = load i32, ptr %context.field.567, align 4
  %context.field.569 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.570 = load i32, ptr %context.field.569, align 4
  %context.field.571 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.572 = load i32, ptr %context.field.571, align 4
  %stack.offset.573 = add i32 %context.value.568, %context.value.570
  %stack.sub.574 = sub i32 0, %stack.offset.573
  %stack.sub.575 = sub i32 0, %context.value.570
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.574, i32 %stack.sub.575)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.572)
  br label %entry.return.status
entry.return.status:
  %context.field.576 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.577 = load i32, ptr %context.field.576, align 4
  ret i32 %context.value.577
}


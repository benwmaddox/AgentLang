%AlOwningContext = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, i64, i64, i64, i64, i64 }
%AlOwningTypeDescriptor = type { i32, i32, i32, i32, i32, i32, i32, i32, i32 }
%AlOwningFieldDescriptor = type { i32, i32, i32, i32 }
%AlOwningLayout = type { i32, ptr, i32, ptr, i32 }
%AlOwningValueSize = type { i32, i32 }
%AlOwningFieldLocation = type { i32, i32, i32 }
%AlOwningDescriptor = type { i32, i32, i32, i32, i32 }
%AlOwningExternalSlice = type { ptr, i32, i32 }
%AlOwningMailboxOutputSlice = type { i32, i32, i32, i32 }
@al_owning_types = private constant [2 x %AlOwningTypeDescriptor] [%AlOwningTypeDescriptor { i32 5, i32 4, i32 0, i32 0, i32 4294967295, i32 4294967295, i32 8, i32 8, i32 0 }, %AlOwningTypeDescriptor { i32 9, i32 5, i32 0, i32 0, i32 8, i32 8, i32 8, i32 8, i32 0 }], align 4
@al_owning_fields = private constant [1 x %AlOwningFieldDescriptor] [%AlOwningFieldDescriptor { i32 0, i32 0, i32 0, i32 0 }], align 4
@al_owning_layout = private constant %AlOwningLayout { i32 4, ptr @al_owning_types, i32 2, ptr @al_owning_fields, i32 0 }, align 8

declare void @al_owning_begin(ptr)
declare i32 @al_owning_enter_frame(ptr, i32)
declare void @al_owning_leave_frame(ptr)
declare i32 @al_owning_reserve_to(ptr, i32, i32)
declare void @al_owning_release_to(ptr, i32, i32, i32, i32)
declare i64 @al_owning_load_i64(ptr, i32)
declare void @al_owning_store_i64(ptr, i32, i64, i32)
declare void @al_owning_store_token(ptr, i32, i32)
declare void @al_owning_load_local(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_constant(ptr, i32, ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_copy_external_bounded(ptr, i32, ptr, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_measure_value(ptr, ptr, i32, i32, i32, i32, ptr)
declare i32 @al_owning_measure_external_value(ptr, ptr, i32, ptr, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_check_initialized(ptr, i32, i32)
declare i32 @al_owning_locate_field(ptr, ptr, i32, i32, i32, i32, i32, ptr)
declare i32 @al_owning_locate_sum_case(ptr, ptr, i32, i32, i32, i32, ptr, ptr)
declare i32 @al_owning_string_length(ptr, i32, i32, i32, ptr)
declare i32 @al_owning_string_concat_plan(ptr, i32, i32, i32, i32, i32, ptr, ptr, ptr)
declare i32 @al_owning_string_concat_write(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare i32 @al_owning_float_format(ptr, i64, ptr, ptr, i32)
declare i32 @al_owning_float_string_write(ptr, i32, i32, ptr, i32, i32, i32)
declare void @al_owning_move_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_copy_range(ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_duplicate(ptr, i32, i32, i32, i32, i32)
declare void @al_owning_drop(ptr, i32, i32, i32, i32)
declare i32 @al_owning_check_cursor(ptr, i32)
declare i32 @al_owning_charge_step(ptr, i32)
declare void @al_owning_update_live(ptr, i32, i32)
declare void @al_owning_local_reserve(ptr, i32)
declare void @al_owning_local_release(ptr, i32)
declare void @al_owning_record_layout(ptr, i32, i32, i32, i32, i32, i32, i32)
declare void @al_owning_swap(ptr, i32, i32, i32, i32, i32)
declare i32 @al_owning_equal_typed(ptr, ptr, i32, i32, i32, i32, i32, i32)
declare void @al_owning_publish(ptr, ptr, i32, i32, i32, i32)
declare void @al_owning_set_failure(ptr, i32, i32, i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)

define internal i32 @agentlang_entry_frame(ptr %ctx, ptr %arguments, ptr %results, i32 %depth.error) {
entry:
  %float.to.string.ascii.buffer.65 = alloca [32 x i8], align 1
  %float.to.string.length.pointer.67 = alloca i32, align 4
  %context.field.2 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.3 = load i32, ptr %context.field.2, align 4
  %context.field.4 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.5 = load i32, ptr %context.field.4, align 4
  %context.field.6 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.7 = load i32, ptr %context.field.6, align 4
  %context.field.8 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.9 = load i32, ptr %context.field.8, align 4
  %frame.entered.10 = call i32 @al_owning_enter_frame(ptr %ctx, i32 %depth.error)
  %frame.enter.ok.11 = icmp eq i32 %frame.entered.10, 0
  br i1 %frame.enter.ok.11, label %frame.enter.continue.12, label %frame.enter.failure.1
frame.enter.failure.1:
  ret i32 1
frame.enter.continue.12:
  %step.status.13 = call i32 @al_owning_charge_step(ptr %ctx, i32 1)
  %helper.ok.14 = icmp eq i32 %step.status.13, 0
  br i1 %helper.ok.14, label %helper.continue.15, label %frame.failure.0
helper.continue.15:
  %context.field.16 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.17 = load i32, ptr %context.field.16, align 4
  %stack.offset.18 = add i32 %context.value.17, 8
  %reserve.status.19 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.18, i32 2)
  %reserve.ok.20 = icmp eq i32 %reserve.status.19, 0
  br i1 %reserve.ok.20, label %reserve.continue.21, label %frame.failure.0
reserve.continue.21:
  call void @al_owning_store_i64(ptr %ctx, i32 %context.value.17, i64 4906019910204099648, i32 5)
  %context.field.22 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.23 = load i32, ptr %context.field.22, align 4
  %runtime.ok.24 = icmp eq i32 %context.value.23, 0
  br i1 %runtime.ok.24, label %runtime.continue.25, label %frame.failure.0
runtime.continue.25:
  call void @al_owning_update_live(ptr %ctx, i32 8, i32 0)
  %context.field.26 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.27 = load i32, ptr %context.field.26, align 4
  %runtime.ok.28 = icmp eq i32 %context.value.27, 0
  br i1 %runtime.ok.28, label %runtime.continue.29, label %frame.failure.0
runtime.continue.29:
  %context.field.30 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.31 = load i32, ptr %context.field.30, align 4
  %stack.sub.34 = sub i32 %stack.offset.18, %context.value.17
  %descriptor.owner.inside.32 = icmp ule i32 %stack.offset.18, %context.value.31
  %descriptor.offset.inside.33 = icmp ule i32 %context.value.17, %stack.offset.18
  %descriptor.extent.inside.35 = icmp ule i32 8, %stack.sub.34
  %descriptor.payload.inside.36 = icmp ule i32 8, 8
  %descriptor.owner.offset.valid.37 = and i1 %descriptor.owner.inside.32, %descriptor.offset.inside.33
  %descriptor.range.inside.39 = and i1 %descriptor.owner.offset.valid.37, %descriptor.extent.inside.35
  %descriptor.range.valid.38 = and i1 %descriptor.range.inside.39, %descriptor.payload.inside.36
  %descriptor.type.valid.40 = icmp eq i32 5, 5
  %descriptor.valid.41 = and i1 %descriptor.range.valid.38, %descriptor.type.valid.40
  br i1 %descriptor.valid.41, label %descriptor.valid.42, label %descriptor.invalid.43
descriptor.invalid.43:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.42:
  %descriptor.initialized.status.44 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.17, i32 8)
  %helper.ok.45 = icmp eq i32 %descriptor.initialized.status.44, 0
  br i1 %helper.ok.45, label %helper.continue.46, label %frame.failure.0
helper.continue.46:
  %step.status.47 = call i32 @al_owning_charge_step(ptr %ctx, i32 3)
  %helper.ok.48 = icmp eq i32 %step.status.47, 0
  br i1 %helper.ok.48, label %helper.continue.49, label %frame.failure.0
helper.continue.49:
  %context.field.50 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 24
  %context.value.51 = load i32, ptr %context.field.50, align 4
  %inline.target.depth.within.interpreter.limit.52 = icmp ule i32 %context.value.51, 65
  br i1 %inline.target.depth.within.interpreter.limit.52, label %inline.target.depth.ok.53, label %inline.target.depth.invalid.54
inline.target.depth.invalid.54:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 4, i32 0, i32 0)
  br label %frame.failure.0
inline.target.depth.ok.53:
  %float.to.string.input.bits.55 = call i64 @al_owning_load_i64(ptr %ctx, i32 %context.value.17)
  %context.field.56 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.57 = load i32, ptr %context.field.56, align 4
  %runtime.ok.58 = icmp eq i32 %context.value.57, 0
  br i1 %runtime.ok.58, label %runtime.continue.59, label %frame.failure.0
runtime.continue.59:
  %float.to.string.input.exponent.60 = and i64 %float.to.string.input.bits.55, 9218868437227405312
  %float.to.string.input.nonfinite.61 = icmp eq i64 %float.to.string.input.exponent.60, 9218868437227405312
  br i1 %float.to.string.input.nonfinite.61, label %float.to.string.nonfinite.failure.62, label %float.to.string.input.finite.63
float.to.string.nonfinite.failure.62:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 5, i32 0, i32 0)
  %context.diagnostic.float.bits.pointer.64 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 33
  store i64 %float.to.string.input.bits.55, ptr %context.diagnostic.float.bits.pointer.64, align 8
  br label %frame.failure.0
float.to.string.input.finite.63:
  %float.to.string.ascii.66 = getelementptr inbounds [32 x i8], ptr %float.to.string.ascii.buffer.65, i64 0, i64 0
  %float.to.string.format.status.68 = call i32 @al_owning_float_format(ptr %ctx, i64 %float.to.string.input.bits.55, ptr %float.to.string.ascii.66, ptr %float.to.string.length.pointer.67, i32 6)
  %helper.ok.69 = icmp eq i32 %float.to.string.format.status.68, 0
  br i1 %helper.ok.69, label %helper.continue.70, label %frame.failure.0
helper.continue.70:
  %float.to.string.length.71 = load i32, ptr %float.to.string.length.pointer.67, align 4
  %float.to.string.length.valid.72 = icmp ule i32 %float.to.string.length.71, 24
  br i1 %float.to.string.length.valid.72, label %float.to.string.length.ready.74, label %float.to.string.length.failure.73
float.to.string.length.failure.73:
  call void @al_owning_set_failure(ptr %ctx, i32 1, i32 7, i32 %float.to.string.length.71, i32 24)
  br label %frame.failure.0
float.to.string.length.ready.74:
  call void @al_owning_record_layout(ptr %ctx, i32 3, i32 5, i32 %context.value.17, i32 8, i32 8, i32 0, i32 0)
  %context.field.75 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.76 = load i32, ptr %context.field.75, align 4
  %runtime.ok.77 = icmp eq i32 %context.value.76, 0
  br i1 %runtime.ok.77, label %runtime.continue.78, label %frame.failure.0
runtime.continue.78:
  %float.to.string.utf16.length.79 = mul i32 %float.to.string.length.71, 2
  %float.to.string.payload.80 = add i32 %float.to.string.utf16.length.79, 8
  %float.to.string.payload.with.padding.81 = add i32 %float.to.string.payload.80, 7
  %float.to.string.extent.82 = and i32 %float.to.string.payload.with.padding.81, -8
  %context.field.83 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.84 = load i32, ptr %context.field.83, align 4
  %stack.offset.85 = add i32 %context.value.84, %float.to.string.extent.82
  %reserve.status.86 = call i32 @al_owning_reserve_to(ptr %ctx, i32 %stack.offset.85, i32 8)
  %reserve.ok.87 = icmp eq i32 %reserve.status.86, 0
  br i1 %reserve.ok.87, label %reserve.continue.88, label %frame.failure.0
reserve.continue.88:
  %float.to.string.write.status.89 = call i32 @al_owning_float_string_write(ptr %ctx, i32 %context.value.84, i32 %float.to.string.extent.82, ptr %float.to.string.ascii.66, i32 %float.to.string.length.71, i32 4, i32 9)
  %helper.ok.90 = icmp eq i32 %float.to.string.write.status.89, 0
  br i1 %helper.ok.90, label %helper.continue.91, label %frame.failure.0
helper.continue.91:
  call void @al_owning_update_live(ptr %ctx, i32 %float.to.string.payload.80, i32 0)
  %context.field.92 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.93 = load i32, ptr %context.field.92, align 4
  %runtime.ok.94 = icmp eq i32 %context.value.93, 0
  br i1 %runtime.ok.94, label %runtime.continue.95, label %frame.failure.0
runtime.continue.95:
  %context.field.96 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.97 = load i32, ptr %context.field.96, align 4
  %stack.sub.100 = sub i32 %stack.offset.85, %context.value.84
  %descriptor.owner.inside.98 = icmp ule i32 %stack.offset.85, %context.value.97
  %descriptor.offset.inside.99 = icmp ule i32 %context.value.84, %stack.offset.85
  %descriptor.extent.inside.101 = icmp ule i32 %float.to.string.extent.82, %stack.sub.100
  %descriptor.payload.inside.102 = icmp ule i32 %float.to.string.payload.80, %float.to.string.extent.82
  %descriptor.owner.offset.valid.103 = and i1 %descriptor.owner.inside.98, %descriptor.offset.inside.99
  %descriptor.range.inside.105 = and i1 %descriptor.owner.offset.valid.103, %descriptor.extent.inside.101
  %descriptor.range.valid.104 = and i1 %descriptor.range.inside.105, %descriptor.payload.inside.102
  %descriptor.type.valid.106 = icmp eq i32 4, 4
  %descriptor.valid.107 = and i1 %descriptor.range.valid.104, %descriptor.type.valid.106
  br i1 %descriptor.valid.107, label %descriptor.valid.108, label %descriptor.invalid.109
descriptor.invalid.109:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %frame.failure.0
descriptor.valid.108:
  %descriptor.initialized.status.110 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %context.value.84, i32 %float.to.string.extent.82)
  %helper.ok.111 = icmp eq i32 %descriptor.initialized.status.110, 0
  br i1 %helper.ok.111, label %helper.continue.112, label %frame.failure.0
helper.continue.112:
  %descriptor.element.113 = getelementptr inbounds %AlOwningDescriptor, ptr %results, i32 0
  %descriptor.field.114 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.113, i32 0, i32 0
  store i32 4, ptr %descriptor.field.114, align 4
  %descriptor.field.115 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.113, i32 0, i32 1
  store i32 %context.value.84, ptr %descriptor.field.115, align 4
  %descriptor.field.116 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.113, i32 0, i32 2
  store i32 %float.to.string.extent.82, ptr %descriptor.field.116, align 4
  %descriptor.field.117 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.113, i32 0, i32 3
  store i32 %float.to.string.payload.80, ptr %descriptor.field.117, align 4
  %descriptor.field.118 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.113, i32 0, i32 4
  store i32 %stack.offset.85, ptr %descriptor.field.118, align 4
  call void @al_owning_record_layout(ptr %ctx, i32 17, i32 4, i32 %context.value.84, i32 20, i32 %float.to.string.payload.80, i32 %stack.offset.85, i32 %float.to.string.extent.82)
  %context.field.119 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.120 = load i32, ptr %context.field.119, align 4
  %runtime.ok.121 = icmp eq i32 %context.value.120, 0
  br i1 %runtime.ok.121, label %runtime.continue.122, label %frame.failure.0
runtime.continue.122:
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 0
frame.failure.0:
  call void @al_owning_release_to(ptr %ctx, i32 %context.value.3, i32 0, i32 0, i32 0)
  %context.field.123 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.124 = load i32, ptr %context.field.123, align 4
  %context.field.125 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.126 = load i32, ptr %context.field.125, align 4
  %context.field.127 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.128 = load i32, ptr %context.field.127, align 4
  %stack.offset.129 = add i32 %context.value.5, %context.value.7
  %stack.offset.130 = add i32 %context.value.124, %context.value.126
  %stack.sub.131 = sub i32 %stack.offset.129, %stack.offset.130
  %stack.sub.132 = sub i32 %context.value.7, %context.value.126
  %stack.sub.133 = sub i32 %context.value.128, %context.value.9
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.131, i32 %stack.sub.132)
  call void @al_owning_local_release(ptr %ctx, i32 %stack.sub.133)
  call void @al_owning_leave_frame(ptr %ctx)
  ret i32 1
}


define dllexport i32 @agentlang_owning_execute(ptr %ctx, ptr %input, i32 %input.bytes, ptr %input.extents, i32 %input.count, ptr %retained, i32 %retained.capacity) {
entry:
  %entry.output.descriptors.16 = alloca [1 x %AlOwningDescriptor], align 4
  call void @al_owning_begin(ptr %ctx)
  %context.field.3 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.4 = load i32, ptr %context.field.3, align 4
  %entry.context.ok.5 = icmp eq i32 %context.value.4, 0
  br i1 %entry.context.ok.5, label %entry.begin.ok.6, label %entry.failure.0
entry.begin.ok.6:
  %entry.input.count.ok.7 = icmp eq i32 %input.count, 0
  br i1 %entry.input.count.ok.7, label %entry.input.counted.8, label %entry.input.count.failure.9
entry.input.count.failure.9:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 0, i32 %input.count)
  br label %entry.failure.0
entry.input.counted.8:
  %input.total.exact.10 = icmp eq i32 0, %input.bytes
  br i1 %input.total.exact.10, label %input.valid.11, label %input.invalid.12
input.invalid.12:
  call void @al_owning_set_failure(ptr %ctx, i32 4, i32 0, i32 0, i32 %input.bytes)
  br label %entry.failure.0
input.valid.11:
  %reserve.status.13 = call i32 @al_owning_reserve_to(ptr %ctx, i32 0, i32 10)
  %reserve.ok.14 = icmp eq i32 %reserve.status.13, 0
  br i1 %reserve.ok.14, label %reserve.continue.15, label %entry.failure.0
reserve.continue.15:
  %entry.body.status.17 = call i32 @agentlang_entry_frame(ptr %ctx, ptr null, ptr %entry.output.descriptors.16, i32 11)
  %entry.body.ok.18 = icmp eq i32 %entry.body.status.17, 0
  br i1 %entry.body.ok.18, label %entry.success.2, label %entry.body.failure.1
entry.body.failure.1:
  br label %entry.failure.0
entry.success.2:
  %descriptor.element.19 = getelementptr inbounds %AlOwningDescriptor, ptr %entry.output.descriptors.16, i32 0
  %descriptor.field.20 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 0
  %descriptor.value.21 = load i32, ptr %descriptor.field.20, align 4
  %descriptor.field.22 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 1
  %descriptor.value.23 = load i32, ptr %descriptor.field.22, align 4
  %descriptor.field.24 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 2
  %descriptor.value.25 = load i32, ptr %descriptor.field.24, align 4
  %descriptor.field.26 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 3
  %descriptor.value.27 = load i32, ptr %descriptor.field.26, align 4
  %descriptor.field.28 = getelementptr inbounds %AlOwningDescriptor, ptr %descriptor.element.19, i32 0, i32 4
  %descriptor.value.29 = load i32, ptr %descriptor.field.28, align 4
  %entry.output.type.valid.30 = icmp eq i32 %descriptor.value.21, 4
  br i1 %entry.output.type.valid.30, label %entry.output.type.ok.31, label %entry.output.type.invalid.32
entry.output.type.invalid.32:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
entry.output.type.ok.31:
  %context.field.33 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 2
  %context.value.34 = load i32, ptr %context.field.33, align 4
  %stack.sub.37 = sub i32 %descriptor.value.29, %descriptor.value.23
  %descriptor.owner.inside.35 = icmp ule i32 %descriptor.value.29, %context.value.34
  %descriptor.offset.inside.36 = icmp ule i32 %descriptor.value.23, %descriptor.value.29
  %descriptor.extent.inside.38 = icmp ule i32 %descriptor.value.25, %stack.sub.37
  %descriptor.payload.inside.39 = icmp ule i32 %descriptor.value.27, %descriptor.value.25
  %descriptor.owner.offset.valid.40 = and i1 %descriptor.owner.inside.35, %descriptor.offset.inside.36
  %descriptor.range.inside.42 = and i1 %descriptor.owner.offset.valid.40, %descriptor.extent.inside.38
  %descriptor.range.valid.41 = and i1 %descriptor.range.inside.42, %descriptor.payload.inside.39
  %descriptor.type.valid.43 = icmp eq i32 4, 4
  %descriptor.valid.44 = and i1 %descriptor.range.valid.41, %descriptor.type.valid.43
  br i1 %descriptor.valid.44, label %descriptor.valid.45, label %descriptor.invalid.46
descriptor.invalid.46:
  call void @al_owning_set_failure(ptr %ctx, i32 5, i32 0, i32 0, i32 0)
  br label %entry.failure.0
descriptor.valid.45:
  %descriptor.initialized.status.47 = call i32 @al_owning_check_initialized(ptr %ctx, i32 %descriptor.value.23, i32 %descriptor.value.25)
  %helper.ok.48 = icmp eq i32 %descriptor.initialized.status.47, 0
  br i1 %helper.ok.48, label %helper.continue.49, label %entry.failure.0
helper.continue.49:
  %entry.output.size.i64.50 = zext i32 %descriptor.value.25 to i64
  %entry.output.total.i64.51 = add i64 0, %entry.output.size.i64.50
  %entry.retained.capacity.i64.52 = zext i32 %retained.capacity to i64
  %entry.retained.required.fits.u32.53 = icmp ule i64 %entry.output.total.i64.51, 4294967295
  %entry.retained.required.truncated.54 = trunc i64 %entry.output.total.i64.51 to i32
  %entry.retained.required.55 = select i1 %entry.retained.required.fits.u32.53, i32 %entry.retained.required.truncated.54, i32 4294967295
  %entry.retained.capacity.ok.56 = icmp ule i64 %entry.output.total.i64.51, %entry.retained.capacity.i64.52
  br i1 %entry.retained.capacity.ok.56, label %entry.retained.capacity.ready.57, label %entry.retained.capacity.failure.58
entry.retained.capacity.failure.58:
  call void @al_owning_set_failure(ptr %ctx, i32 3, i32 0, i32 %entry.retained.required.55, i32 %retained.capacity)
  br label %entry.failure.0
entry.retained.capacity.ready.57:
  %host.pointer.59 = getelementptr inbounds i8, ptr %retained, i32 0
  %stack.sub.60 = sub i32 %retained.capacity, 0
  call void @al_owning_publish(ptr %ctx, ptr %host.pointer.59, i32 %stack.sub.60, i32 %descriptor.value.23, i32 %descriptor.value.25, i32 4)
  %context.field.61 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.62 = load i32, ptr %context.field.61, align 4
  %runtime.ok.63 = icmp eq i32 %context.value.62, 0
  br i1 %runtime.ok.63, label %runtime.continue.64, label %entry.failure.0
runtime.continue.64:
  %stack.offset.65 = add i32 0, %descriptor.value.25
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  %context.field.66 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.67 = load i32, ptr %context.field.66, align 4
  %context.field.68 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.69 = load i32, ptr %context.field.68, align 4
  %stack.sub.70 = sub i32 0, %context.value.67
  %stack.sub.71 = sub i32 0, %context.value.69
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.70, i32 %stack.sub.71)
  %context.field.72 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.73 = load i32, ptr %context.field.72, align 4
  %runtime.ok.74 = icmp eq i32 %context.value.73, 0
  br i1 %runtime.ok.74, label %runtime.continue.75, label %entry.failure.0
runtime.continue.75:
  br label %entry.return.status
entry.failure.0:
  %context.field.76 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 4
  %context.value.77 = load i32, ptr %context.field.76, align 4
  %context.field.78 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 8
  %context.value.79 = load i32, ptr %context.field.78, align 4
  %context.field.80 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 6
  %context.value.81 = load i32, ptr %context.field.80, align 4
  %stack.offset.82 = add i32 %context.value.77, %context.value.79
  %stack.sub.83 = sub i32 0, %stack.offset.82
  %stack.sub.84 = sub i32 0, %context.value.79
  call void @al_owning_release_to(ptr %ctx, i32 0, i32 0, i32 0, i32 0)
  call void @al_owning_update_live(ptr %ctx, i32 %stack.sub.83, i32 %stack.sub.84)
  call void @al_owning_local_release(ptr %ctx, i32 %context.value.81)
  br label %entry.return.status
entry.return.status:
  %context.field.85 = getelementptr inbounds %AlOwningContext, ptr %ctx, i32 0, i32 19
  %context.value.86 = load i32, ptr %context.field.85, align 4
  ret i32 %context.value.86
}


# Campfire native execution-profile 256

O2 trusted-generated native room GET; StageProfile On in both arms; execution Off/Detailed ABBA; four workers, fixed four-core host mask, fixed affinity-disjoint client mask, concurrency 16, two 15-second repeats per host, 20 warmups per repeat. The pinned 256 client records latency after the full body arrives and before status/body-digest validation; throughput includes validation.

| Run | Profile | Host GETs | Correct req/s | Median repeat P99 upper bound (ms) | Provider ticks / API ticks |
|---|---|---:|---:|---:|---:|
| OffA | off | 80232 | 2671.60 | 22.346 | — |
| DetailedB | detailed | 70793 | 2357.46 | 20.608 | 43.79459975414678 |
| DetailedC | detailed | 71051 | 2365.64 | 20.955 | 43.29568939736789 |
| OffD | off | 79979 | 2663.67 | 22.218 | — |

Combined Detailed throughput change: -11.47%.

## Detailed category means

Per-run category totals and means are in the JSON report. Runtime counters overlap, SQL counters nest inside provider callbacks, and these columns must not be summed into API time.

| Profile | Category | Calls | Failures | Mean µs/call | Calls/host GET |
|---|---|---:|---:|---:|---:|
| DetailedB | reserve_release | 86933804 | 0 | 0.0153 | 1228.0000 |
| DetailedB | initialization_check | 966536829 | 0 | 0.0157 | 13653.0000 |
| DetailedB | arena_copy | 40564389 | 0 | 0.0744 | 573.0000 |
| DetailedB | value_measure | 2831720 | 0 | 0.9340 | 40.0000 |
| DetailedB | external_measure | 495551 | 0 | 2.2695 | 7.0000 |
| DetailedB | structural_locate | 8282781 | 0 | 1.0174 | 117.0000 |
| DetailedB | host_output_commit | 424758 | 0 | 2.4510 | 6.0000 |
| DetailedB | frame_validation | 11397673 | 0 | 0.0164 | 161.0000 |
| DetailedB | other_runtime_validation | 10335778 | 0 | 0.0155 | 146.0000 |
| DetailedB | cookie_verify_session_token | 70793 | 0 | 8.6045 | 1.0000 |
| DetailedB | session_find_by_token | 70793 | 0 | 20.3869 | 1.0000 |
| DetailedB | session_refresh_before | 0 | 0 | — | 0.0000 |
| DetailedB | user_find_by_id | 70793 | 0 | 5.2614 | 1.0000 |
| DetailedB | user_authenticate_bot_key | 0 | 0 | — | 0.0000 |
| DetailedB | browser_version_at_least | 0 | 0 | — | 0.0000 |
| DetailedB | room_find_for_user | 70793 | 0 | 7.6617 | 1.0000 |
| DetailedB | membership_exists | 70793 | 0 | 4.2725 | 1.0000 |
| DetailedB | message_last_page | 70793 | 0 | 544.6932 | 1.0000 |
| DetailedB | sql_prepare | 0 | 0 | — | 0.0000 |
| DetailedB | sql_bind | 637137 | 0 | 0.2381 | 9.0000 |
| DetailedB | sql_step | 6300577 | 0 | 6.1705 | 89.0000 |
| DetailedB | sql_reset | 5734233 | 0 | 0.1293 | 81.0000 |
| DetailedC | reserve_release | 87250628 | 0 | 0.0154 | 1228.0000 |
| DetailedC | initialization_check | 970059303 | 0 | 0.0157 | 13653.0000 |
| DetailedC | arena_copy | 40712223 | 0 | 0.0725 | 573.0000 |
| DetailedC | value_measure | 2842040 | 0 | 0.9375 | 40.0000 |
| DetailedC | external_measure | 497357 | 0 | 2.2701 | 7.0000 |
| DetailedC | structural_locate | 8312967 | 0 | 1.0219 | 117.0000 |
| DetailedC | host_output_commit | 426306 | 0 | 2.4546 | 6.0000 |
| DetailedC | frame_validation | 11439211 | 0 | 0.0165 | 161.0000 |
| DetailedC | other_runtime_validation | 10373446 | 0 | 0.0155 | 146.0000 |
| DetailedC | cookie_verify_session_token | 71051 | 0 | 8.7360 | 1.0000 |
| DetailedC | session_find_by_token | 71051 | 0 | 20.5806 | 1.0000 |
| DetailedC | session_refresh_before | 0 | 0 | — | 0.0000 |
| DetailedC | user_find_by_id | 71051 | 0 | 5.3464 | 1.0000 |
| DetailedC | user_authenticate_bot_key | 0 | 0 | — | 0.0000 |
| DetailedC | browser_version_at_least | 0 | 0 | — | 0.0000 |
| DetailedC | room_find_for_user | 71051 | 0 | 7.6085 | 1.0000 |
| DetailedC | membership_exists | 71051 | 0 | 4.2071 | 1.0000 |
| DetailedC | message_last_page | 71051 | 0 | 533.6906 | 1.0000 |
| DetailedC | sql_prepare | 0 | 0 | — | 0.0000 |
| DetailedC | sql_bind | 639459 | 0 | 0.2490 | 9.0000 |
| DetailedC | sql_step | 6323539 | 0 | 6.0461 | 89.0000 |
| DetailedC | sql_reset | 5755131 | 0 | 0.1275 | 81.0000 |

## Interpretation limits

- Stage timing is enabled in both arms; this estimates incremental detailed runtime counter overhead, not host stage-profiler overhead.
- Worker timer sums overlap in wall time; runtime category totals also overlap; SQL intervals are nested within provider callbacks.
- Client p95/p99 values are histogram upper bounds from successful responses only and remain separate from host QPC means/maxima.
- SQLite step time is not lock-wait time. No lock-cause claim is supported by this steady-state workload.
- The pure cookie SRW lock, adapter active-state guard, and internal SQLite/HTTP.sys/CNG synchronization are outside separately timed wait counters; low operation totals do not establish absence of contention.
- This private Windows HTTP.sys workload is not apples-to-apples with the public Rails/Docker benchmark or a WebSocket-capacity test.

#requires -Version 7.0
# Report 270: one stage-profiled ABBA set (Off/Detailed) of the current room page.
# Builds both hosts from fresh validation runs, fetches the new page hash into a
# private 270 template, then runs the four lifetimes and aggregates.
$ErrorActionPreference = 'Stop'
$repo = 'D:\code\AgentLang'
Set-Location -LiteralPath $repo
$here = $PSScriptRoot
$pwsh = (Get-Process -Id $PID).Path
$builds = @{}
foreach ($profile in 'Off', 'Detailed') {
  $verify = & $pwsh -NoProfile -File scripts/Verify-CampfireNativeRoomRead.ps1 -RuntimeProfile TrustedGenerated -ExecutionProfile $profile 2>&1
  $run = ($verify | Select-String -Pattern 'evidence=(\S+)' | Select-Object -Last 1).Matches[0].Groups[1].Value
  $build = & $pwsh -NoProfile -File scripts/Build-CampfireNativeHttp.ps1 -ValidationRunRoot $run -RuntimeProfile trusted-generated -StageProfile On -Optimization O2 2>&1
  $out = ($build | Select-String -Pattern '^output_root=(.+)$').Matches[0].Groups[1].Value
  $builds[$profile] = Join-Path $out 'O2'
  "built $profile -> $out"
}
$cycle = Get-Content -LiteralPath (Join-Path $here 'Run-Cycle-269.ps1') -Raw
$cycle = $cycle -replace "Off = Join-Path \`$root '[^']+'", ("Off = '" + $builds.Off + "'")
$cycle = $cycle -replace "Detailed = Join-Path \`$root '[^']+'", ("Detailed = '" + $builds.Detailed + "'")
$cycle = $cycle -replace 'Measure-269\.ps1', 'Measure-270.ps1'
Set-Content -LiteralPath (Join-Path $here 'Run-Cycle-270.ps1') -Value $cycle -Encoding utf8NoBOM
$fetch = Get-Content -LiteralPath (Join-Path $here 'Fetch-Hash-269.ps1') -Raw
$fetch = $fetch -replace "Off = Join-Path \`$root '[^']+'", ("Off = '" + $builds.Off + "'")
$fetch = $fetch -replace "Detailed = Join-Path \`$root '[^']+'", ("Detailed = '" + $builds.Detailed + "'")
Set-Content -LiteralPath (Join-Path $here 'Fetch-Hash-270.ps1') -Value $fetch -Encoding utf8NoBOM
$template = Join-Path $repo '.agentlang/campfire-native-http-253/native-smoke/native-measure.config.json'
& $pwsh -NoProfile -File (Join-Path $here 'Fetch-Hash-270.ps1') -RunName p270b-hash -ExecutionProfile Off -TemplatePath $template | Out-Null
$line = Get-Content -LiteralPath (Join-Path $here 'replication-driver/p270b-hash/driver.log') | Select-String 'sha256=([0-9a-f]{64})' | Select-Object -Last 1
$hash = $line.Matches[0].Groups[1].Value
"page: $($line.Line -replace '.*status=', 'status=')"
$config = Get-Content -LiteralPath $template -Raw | ConvertFrom-Json
$config.ExpectedBodySha256 = $hash
$config | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $repo '.agentlang/campfire-native-http-253/native-smoke/native-measure-270.config.json') -Encoding utf8NoBOM
(Get-Content -LiteralPath (Join-Path $here 'Measure.ps1') -Raw) -replace "'native-measure.config.json'", "'native-measure-270.config.json'" |
  Set-Content -LiteralPath (Join-Path $here 'Measure-270.ps1') -Encoding utf8NoBOM
foreach ($pair in @('p270b-off-a Off', 'p270b-detailed-b Detailed', 'p270b-detailed-c Detailed', 'p270b-off-d Off')) {
  $name, $profile = $pair -split ' '
  & $pwsh -NoProfile -File (Join-Path $here 'Run-Cycle-270.ps1') -RunName $name -ExecutionProfile $profile | Select-Object -Last 1
}
python (Join-Path $here 'aggregate_profiles.py') --output (Join-Path $here 'profile-analysis-270.json') --markdown (Join-Path $here 'profile-analysis-270.md') `
  --run OffA=p270b-off-a --run DetailedB=p270b-detailed-b --run DetailedC=p270b-detailed-c --run OffD=p270b-off-d

$ErrorActionPreference = 'Stop'
$receiptRoot188 = Join-Path (Get-Location).Path '.agentlang/type-evolution-188'
$validation188 = Get-Content -LiteralPath (Join-Path $receiptRoot188 'full-validation.json') -Raw | ConvertFrom-Json
$exit188 = Get-Content -LiteralPath (Join-Path $receiptRoot188 'full-validation-exit.json') -Raw | ConvertFrom-Json
if (-not $validation188.passed -or $exit188.exitCode -ne 0 -or $validation188.checks.Count -ne 37 -or @($validation188.checks | Where-Object exitCode -ne 0).Count -ne 0) { throw 'Require complete passing local gate.' }
$sourcePins188 = Get-Content -LiteralPath (Join-Path $receiptRoot188 'source-pins.json') -Raw | ConvertFrom-Json
foreach ($pin188 in $sourcePins188.files) {
    if ((Get-FileHash -LiteralPath $pin188.path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $pin188.sha256) { throw "Source changed after validation: $($pin188.path)" }
}
$hostReceipt188 = Get-Content -LiteralPath (Join-Path $receiptRoot188 'full-validation.subagent-host-v2.json') -Raw | ConvertFrom-Json
if ($hostReceipt188.outcome -ne 'passed') { throw 'Require passing V2 host receipt.' }
$cliDirectory188 = 'src/AgentLang.Cli/bin/Release/net9.0'
foreach ($pin188 in $hostReceipt188.cliFiles) {
    $binary188 = Join-Path $cliDirectory188 $pin188.name
    if ((Get-FileHash -LiteralPath $binary188 -Algorithm SHA256).Hash.ToLowerInvariant() -ne $pin188.sha256) { throw "Validated binary changed: $binary188" }
}
foreach ($pin188 in $hostReceipt188.wrapperFiles) {
    if ((Get-FileHash -LiteralPath $pin188.path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $pin188.sha256) { throw "Validated host script changed: $($pin188.path)" }
}
$paths188 = @($hostReceipt188.cliFiles | ForEach-Object { Join-Path $cliDirectory188 $_.name }) +
    @((Join-Path $cliDirectory188 'AgentLang.Cli.deps.json'), (Join-Path $cliDirectory188 'AgentLang.Cli.runtimeconfig.json')) +
    @($hostReceipt188.wrapperFiles.path)
$files188 = @($paths188 | Sort-Object -Unique | ForEach-Object {
    [ordered]@{path=$_.Replace('\','/'); sha256=(Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash.ToLowerInvariant()}
})
[ordered]@{
    format=1; baseRevision=$sourcePins188.baseRevision
    fullGatePassed=$true; fullGateExitCode=$exit188.exitCode; fullGateChecks=$validation188.checks.Count
    cliDll=(Join-Path $cliDirectory188 'AgentLang.Cli.dll').Replace('\','/')
    files=$files188
} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $receiptRoot188 'accepted-runtime-pins.json') -Encoding utf8
'Accepted runtime pins recorded.'

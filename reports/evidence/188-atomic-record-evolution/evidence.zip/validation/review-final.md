# Atomic record evolution: independent source and acceptance-scope review

Snapshot: 2026-10-10. This reviews the source hashes below; implementation/tests were still being updated by their owners. This is source review, not final execution acceptance.

| File | SHA-256 |
| --- | --- |
| `docs/TYPE-EVOLUTION.md` | `B684F19C6CE312FA329086B730A50ADB36D7CB58D5C848C9C1D5D30F4A373683` |
| `.agentlang/type-history-187/stage-b-implementation-map.md` | `56FACF32A51AD82ADA6EAC4A065CC531FE50B426B995257F7E05DFB7034C1EA8` |
| `src/AgentLang.Core/Runtime.fs` | `845B6D508F91BA928E557A4AE7D493C0E6BB22716E1EE8A3F30C09C555FDDF87` |
| `src/AgentLang.Core/AuthoringHelp.fs` | `1746D9A6B0AE69ECCADD0E7BB3A25222914FCF8AE4B34F80B70F8EB74312F190` |
| `tests/AgentLang.Flow.Runtime.Tests/Program.fs` | `6387232F7C3093A7B40949F7556DAA13D823F21E8D605C63C93E7D2A545A8F7F` |
| `tests/AgentLang.Flow.Runtime.Tests/RecordEvolutionIsolation.fs` | `34836AA9327932162378063BA92E1BDA2366EE1A1CDED50E6CFE19F531E556D9` |
| `tests/AgentLang.Flow.Runtime.Tests/AgentLang.Flow.Runtime.Tests.fsproj` | `A42D9B06F4128ADFD42580BF2E6B47E3FE1A6B735D139A319DFA8F3C0F2B359D` |
| `tests/AgentLang.IR.Tests/Program.fs` | `6F7B4D73C87EE95AF59D72E85C34A7696E0BFBB0FEBA22F81EB2D437389C9A10` |

`git diff --check` for the six code/test paths exited 0. No build, test, storage write probe, remote command, or tracked-file edit was performed by this reviewer.

## Implementation observations

No further concrete code defect found in this bounded pass. The prior group discard, metadata-only generated caller, and late generated-attachment findings are addressed in the reviewed Runtime source: group discard routes through whole-group restore (`Runtime.fs:6925-7011`), generated metadata dependencies feed caller discovery (`Runtime.fs:3791-3822`), and Stack attachment edits to a staged type's generated operations are rejected (`Runtime.fs:3390-3405`). Record/word CAS and new-name classification happen before activation (`Runtime.fs:4198-4567`). Durable projection restores old record/source and word/attachment backups while staged (`Runtime.fs:743-836`); publication expands and checks group membership before a single publish (`Runtime.fs:3624-3736`, `3873-3875`). Generated/user collisions are checked by `effectiveWords` (`Runtime.fs:534-559`); rename/deprecate reject staged candidates (`Runtime.fs:6312-6316`, `6774-6778`). These source facts require test execution for acceptance.

## Acceptance evidence still missing from the new record-evolution tests

These are evidence gaps, not defect claims:

1. **Exactly one existing word replacement:** `Program.fs:1094-1374` exercises zero existing word owners and groups with several replacements, but has no successful one-owner type-CAS transaction. A stale one-owner CAS is rejected at `Program.fs:1195-1203`.
2. **Mixed-group rollback and member selection:** The successful mixed group commits through a new helper (`Program.fs:1212-1247`), while discard and task.abort stage type-only groups (`Program.fs:1359-1374`). Add rollback of a group with a replaced word, adapted cases and a new helper; invoke discard by a word and by a newly added type. Assert original attachments, identities, source and manifest, plus no orphaned group candidate.
3. **Inherited wrapper rejection:** The new matrix rejects incompatible inherited standalone constructor cases (`Program.fs:1209-1210`) and the isolation test rejects removal of a generated operation with retained Stack cases (`RecordEvolutionIsolation.fs:89-168`). It does not show an unchanged incompatible test-file wrapper rejecting the type proposal, nor rejection of an attempted wrapper edit in that proposal.
4. **Failure after staging:** The new tests check stale CAS, failed stage and unrelated commit, but not failed storage commit/write for a selected schema group, or a failed selected group test/coverage gate after staging. Assert that the old manifest and reload remain authoritative.
5. **Library caller gates and collisions:** The matrix retains one library consumer and checks it after publish (`Program.fs:1159-1160`, `1247`, `1355`), but has no type-evolution-specific library caller coverage failure or new generated/user binding collision scenario. Existing word-only coverage tests are separate. Add focused negative cases if these are required for Stage B acceptance.

The new IR test does directly verify stale detached bodies for field rename, reorder, addition and removal (`IR Program.fs:1911-1937`). The new Flow project file compiles `RecordEvolutionIsolation.fs` before `Program.fs`, and the latter invokes it (`Program.fs:6752-6753`). The Parcel path covers field add/remove/rename/order/type change, nominal raw/wrong-type rejection, a new helper and nominal scalars, source history, stable IDs/maturity, unchanged public signature, unrelated publication, and fresh reload. `RecordEvolutionIsolation.fs` adds retained generated case and metadata-only caller scenarios.

The Stage B map additionally calls for a persisted-seed participant protocol migration and its behavior oracle; the Parcel matrix is a synthetic end-to-end example and does not itself supply that readiness control.

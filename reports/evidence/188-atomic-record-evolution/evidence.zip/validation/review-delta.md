# Milestone 188 bounded delta review

Source snapshot: 2026-10-10. No build, test, storage probe, remote command, or tracked-file edit was performed by this reviewer. `git diff --check -- src/AgentLang.Core/Runtime.fs src/AgentLang.Core/AuthoringHelp.fs tests/AgentLang.Flow.Runtime.Tests` exited 0.

| Reviewed file | SHA-256 |
| --- | --- |
| `src/AgentLang.Core/Runtime.fs` | `E1442C614F6C41ABD1657B18B9095027010D1282FB2DC29B916E1CD05C509117` |
| `src/AgentLang.Core/AuthoringHelp.fs` | `D33F3423F99FE986465CC650FCADB025C2409BE9C104D1252D5F2CECA051D63B` |
| `tests/AgentLang.Flow.Runtime.Tests/Program.fs` | `2F268FE33C5C847804EC6D7149E36B1B689389EA03936AB32975D786F5E1853E` |
| `tests/AgentLang.Flow.Runtime.Tests/RecordEvolutionIsolation.fs` | `9001722156D7BF692DB2BED1CD5B5C9B872944BCB754693F54D01F8A7188D202` |
| `tests/AgentLang.Flow.Runtime.Tests/AgentLang.Flow.Runtime.Tests.fsproj` | `A42D9B06F4128ADFD42580BF2E6B47E3FE1A6B735D139A319DFA8F3C0F2B359D` |

## Review result

No concrete code defect identified in this bounded delta. Atomic selection expands through all touched group members and checks completeness (`Runtime.fs:3640-3715`); backup removal, durable compilation, and publish happen after the selected closure is complete (`Runtime.fs:3717-3889`). Staged durable projection restores old record/source and word/attachment rows (`Runtime.fs:743-836`). Discard uses group-wide restoration, and task abort restores its saved executable/storage snapshot. Record and word CAS are checked before activating the proposal. Generated/user/primitive collision checks remain in `effectiveWords`; validator declarations are frozen for existing records and existing validator-word closures remain guarded. This is source reasoning only.

The new tests now cover the prior major evidence gaps: one existing owner (`Program.fs:1522-1549`), no-target publication (`Program.fs:1551-1583`), generated/user and primitive collisions plus immutable record validators (`Program.fs:1212-1288`), blocked source-object write with old manifest authoritative and mixed-group discard by word (`Program.fs:1454-1487`), discard by a newly added type and staged task abort with helper/attachment (`Program.fs:1489-1520`), unchanged persistent library caller coverage failure (`RecordEvolutionIsolation.fs:291-378`), and retained incompatible wrapper plus attempted wrapper edit (`RecordEvolutionIsolation.fs:380-466`). The Parcel matrix still covers zero/many owners, schema field operations, new nominal String types, history, unrelated publication and reload. Generated case and metadata-only caller tests remain in the isolation module.

## Remaining evidence gaps, not code defects

1. `Program.fs:1507-1520` aborts a staged type group, before publication. A commit of a type-CAS group inside a task followed by `task.abort`, checking source/history/manifest after fresh reload, would directly prove restoration of an already published schema. A word-only commit-then-abort test exists at `Program.fs:1050-1058`, but it does not cover type-history rollback.
2. The new validator tests reject changing/removing the record's validator declaration (`Program.fs:1223-1270`). They do not explicitly attempt to replace a word in an existing persistent validator dependency closure in the same type-CAS request. The runtime's frozen-validator guard applies to the declared word names; an explicit negative fixture would prove that path.

This receipt applies only to the hashes above. Its assertions about tests are about source coverage, not execution results.

## Bounded follow-up: two new cases and Help wording

Reviewed snapshot (2026-10-10): `Program.fs` SHA-256 `52C4FE71FE85333D95D267DD03FC0E19075373DD8BFCAF0A4B32631AFA98CA6E`; `AuthoringHelp.fs` SHA-256 `DA7F95EF47A9E34CEE518F7AC7C93ADDC23F2C861D0FEB7311764852C050CDD6`. `git diff --check -- src/AgentLang.Core/AuthoringHelp.fs tests/AgentLang.Flow.Runtime.Tests/Program.fs` exited 0. This follow-up inspected only the two added cases and Help delta, with no build or test execution.

The published-task-abort gap is closed in source coverage (`Program.fs:1522-1556`): it stages and commits a changed record inside a task, observes a seventh type-history revision, aborts, then compares manifest, authored source, history, and word revision both immediately and after a fresh Engine reload. The prior matrix has six revisions (`Program.fs:1432-1434`), and the proposed source differs from the prior source captured before the task.

The validator-closure gap is also addressed in source coverage (`Program.fs:6211-6261`): the request supplies both type-source and word-revision CAS tokens, changes the record layout, attempts to replace its persistent validator word, expects `TYPE_VALIDATOR_FROZEN`, and verifies source, revision, and manifest are unchanged. The proposed validator declaration uses `customer.lookup-valid?` while the baseline uses `customer::lookup-valid?`; this initially looked like a test-isolation issue. Guard inspection shows declaration immutability raises the distinct `FLOW_TYPE_EVOLUTION_VALIDATOR_IMMUTABLE` (`Runtime.fs:4266-4267`), whereas the expected `TYPE_VALIDATOR_FROZEN` arises from the validator-word closure guard (`Runtime.fs:3437-3441`). The test cannot falsely pass through the declaration check. I sent the correction to parent and implementer; matching spelling would improve clarity but is not a demonstrated defect.

The Help delta (`AuthoringHelp.fs:175-190,572-593`) describes `expectedTypeSources`, exact existing-word revision tokens, group publication, immutable validator declarations and scalar/enum schemas, and preserved wrapper behavior consistently with the reviewed contract. No Help defect found in this bounded read.

### Later Program snapshot

`Program.fs` SHA-256 `3EADE238135F120CF1DB8988A9145147951F7F32E52C477F70C27808C87D44A9`; Help remains `DA7F95EF47A9E34CEE518F7AC7C93ADDC23F2C861D0FEB7311764852C050CDD6`. The implementer changed the proposed validator declaration to match the baseline `customer::lookup-valid?` exactly (`Program.fs:6230`). Targeted re-read confirms both added tests retain their assertions (`Program.fs:1522-1556,6211-6261`). `git diff --check` for these two files exited 0. Both prior evidence gaps are resolved in source coverage at this snapshot; no further concrete defect found in this bounded delta. Execution remains with the primary worker.

### Root reconciliation of final fixture changes

The primary agent re-read the subsequent fixture-only changes: Token field `id` became `identifier` to avoid an authored/generated binding collision; retained Stack test/example statements use canonical multiline source; retained-wrapper reload comparisons preserve the complete `data.results` array while excluding coverage-site provenance IDs that change on reload. Exact test/wrapper source comparisons remain. Runtime and Help bytes match the final reviewed hashes above. Final Program SHA-256: `93ADF2A8476E449CBAF9962B37CD4DEA349E7606E5A5309690C54DB9EFD33550`; isolation SHA-256: `E25F75CC6BFC2EF82BCA46758393FFAA13FC6F7B2DFEFCAE9B95984D5B5F0F34`. Worker reports integrated Flow console terminal exit 0, 44 groups / 2,191 assertions; its focused receipt follows separately. This reconciliation is by the primary agent, not a second independent test run.

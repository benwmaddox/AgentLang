# Atomic record evolution: early source review

Snapshot: 2026-10-10. `Runtime.fs` SHA-256 `4AC65924247E141D802E1F2A848E7CA9C37595ADF3D63DA0B68B54BE14DAD437`; `AuthoringHelp.fs` SHA-256 `DFFCA8D6593BD90192B431CE3E3C89BC85167242CDB6945EACB355F79ADF3C0F`.

Scope: read `docs/TYPE-EVOLUTION.md`, `.agentlang/type-history-187/stage-b-implementation-map.md`, the in-progress Runtime/AuthoringHelp diff, and pertinent Runtime callers. `git diff --check -- src/AgentLang.Core/Runtime.fs src/AgentLang.Core/AuthoringHelp.fs` exited 0. No build, test, runtime probe, remote command, or tracked-file edit was performed. This is an early review, not acceptance.

## Findings

1. **High, unfinished path: discard does not restore a group.** `Runtime.fs:838-916` defines `restoreTypeEvolutionGroup`, but public `discard` at `Runtime.fs:6858-6955` still restores/removes only the named word or type. Scenario: stage one record and an adapted word, then discard the record or word. The operation can leave other group members staged against the wrong schema. Route every group member through the whole-group helper before the ordinary branches, recompile, and activate only the restored state. The implementer explicitly said discard/abort wiring is still in progress; treat this as a required unfinished path, not a final defect claim.

2. **Medium, concrete test gate gap: metadata-only generated calls are missed.** `Runtime.fs:3773-3786` identifies metadata affected owners using `expressionTypeReferences` only. That helper at `Runtime.fs:177-194` collects type arguments in container construction, but does not collect calls to generated record operations. Scenario: a persistent authored owner has no record type in its signature or body, while its attached test alone calls `record.field`; after that record changes, this owner is absent from `directTypeAffectedOwners` and `callerResults` (`Runtime.fs:3787-3818`), so publication can skip the test. Include `Compiler.dependencies` from tests/examples against old and proposed generated constructor/accessor names when identifying metadata owners, then run their attached tests. Add a metadata-only generated accessor case.

## Boundary observations

The source hash and word revision checks appear before activation (`Runtime.fs:4182-4195`, `4202-4244`, `4255-4270`). The staged record and source are backed up for durable projection (`Runtime.fs:786-796`). Group closure and completeness checks are present (`Runtime.fs:3621-3696`), and `effectiveWords` detects generated/user collisions (`Runtime.fs:534-559`). These are source observations only, not runtime verification.

No new host capability was observed in this diff. Existing filesystem TOCTOU limits under hostile concurrent directory replacement were outside this bounded review.

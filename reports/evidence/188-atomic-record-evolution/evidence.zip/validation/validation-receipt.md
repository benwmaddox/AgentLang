# Stage B focused validation receipt

Validated 2026-10-10 in the canonical `D:\code\AgentLang` checkout at the accepted base `82d3180ba85aeb0e542dde9a6a6a0376c442e579`. The final implementation/test sources are frozen for the root-owned full gate. No commit, push, remote operation, or full-suite gate was run here.

All commands below used PowerShell with both `TEMP` and `TMP` set to `D:\code\AgentLang\.agentlang\type-evolution-188\temp`, and `/p:NuGetAudit=false` on builds.

## Final focused runs

```powershell
dotnet build tests/AgentLang.Flow.Runtime.Tests/AgentLang.Flow.Runtime.Tests.fsproj --configuration Release --no-restore -m:1 /p:NuGetAudit=false
```

Passed with 0 warnings and 0 errors.

```powershell
dotnet run --no-build --configuration Release --project tests/AgentLang.Flow.Runtime.Tests/AgentLang.Flow.Runtime.Tests.fsproj
```

Passed: 44 groups, 2,191 assertions.

```powershell
dotnet build tests/AgentLang.Storage.Tests/AgentLang.Storage.Tests.fsproj --configuration Release --no-restore -m:1 /p:NuGetAudit=false
```

Passed with 0 warnings and 0 errors.

```powershell
dotnet run --no-build --configuration Release --project tests/AgentLang.Storage.Tests/AgentLang.Storage.Tests.fsproj
```

Passed: 18 groups, 572 assertions.

`git diff --check` passed. Git emitted only its line-ending advisory for the root-owned `docs/TYPE-EVOLUTION.md` change; there were no whitespace errors. The primary implementation/test tracked diff was +1,239/-155 lines across Runtime, help, Flow tests, and the Flow test project file; it excludes the separately owned isolation module and IR test edit.

## Resolved focused attempts

Failure details were emitted in terminal output during the runs and are summarized here; separate raw terminal log files were not saved.

- An intermediate integrated run passed 42 groups and 1,909 assertions before the final rollback and validator-closure regressions were registered. It is superseded by the 44-group final result.
- The single-owner fixture used authored `badge.code` with a generated `badge.code` accessor. Its record field is now `number`.
- The help assertion required the existing phrase `existing scalar`. The final wording preserves that phrase and explicitly says existing record validator declarations remain unchanged; the assertion covers both.
- The all-candidates fixture used authored `token.id` with a generated `token.id` accessor. Its record field is now `identifier`.
- A retained Stack test/example chain was normalized to one statement per line on reload. The fixture now uses that canonical multiline form, and source rows match exactly.
- A wrapper execution comparison included coverage instruction-site IDs that differ between Flow source and persisted revision reload. It now compares complete result rows, including case outcome and active overrides; exact wrapper and case source bytes remain separately compared.
- Review caught and corrected the validator-closure fixture to retain the exact authored `customer::lookup-valid?` declaration before the final run.

The final Flow run covered the field-operation matrix and CAS rejection paths, exact identity/maturity and source history, group commit/discard and failed-write rollback, task abort after schema publication with fresh-reload source/history/revision checks, generated-name collisions, validator immutability and dependency-closure rejection, generated Stack case preservation/guards, metadata-only and library caller closure, wrapper rejection, and the exactly-one-owner case.

## Final SHA-256 source pins

These hashes were computed after the final focused passes and `git diff --check`.

| File | SHA-256 |
| --- | --- |
| `src/AgentLang.Core/Runtime.fs` | `E1442C614F6C41ABD1657B18B9095027010D1282FB2DC29B916E1CD05C509117` |
| `src/AgentLang.Core/AuthoringHelp.fs` | `DA7F95EF47A9E34CEE518F7AC7C93ADDC23F2C861D0FEB7311764852C050CDD6` |
| `tests/AgentLang.Flow.Runtime.Tests/Program.fs` | `93ADF2A8476E449CBAF9962B37CD4DEA349E7606E5A5309690C54DB9EFD33550` |
| `tests/AgentLang.Flow.Runtime.Tests/AgentLang.Flow.Runtime.Tests.fsproj` | `A42D9B06F4128ADFD42580BF2E6B47E3FE1A6B735D139A319DFA8F3C0F2B359D` |
| `tests/AgentLang.Flow.Runtime.Tests/RecordEvolutionIsolation.fs` | `E25F75CC6BFC2EF82BCA46758393FFAA13FC6F7B2DFEFCAE9B95984D5B5F0F34` |
| `tests/AgentLang.IR.Tests/Program.fs` | `6F7B4D73C87EE95AF59D72E85C34A7696E0BFBB0FEBA22F81EB2D437389C9A10` |

The sibling-owned focused IR suite previously reported a Release build with 0 warnings/errors and 21 groups/198 assertions. The root-owned full validation remains the final gate for this source set.

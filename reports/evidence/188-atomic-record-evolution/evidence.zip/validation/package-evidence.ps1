$ErrorActionPreference = 'Stop'
$receiptRoot188 = Join-Path (Get-Location).Path '.agentlang/type-evolution-188'
$validation188 = Get-Content -LiteralPath (Join-Path $receiptRoot188 'full-validation.json') -Raw | ConvertFrom-Json
$exit188 = Get-Content -LiteralPath (Join-Path $receiptRoot188 'full-validation-exit.json') -Raw | ConvertFrom-Json
if (-not $validation188.passed -or $exit188.exitCode -ne 0 -or $validation188.checks.Count -ne 37 -or @($validation188.checks | Where-Object exitCode -ne 0).Count -ne 0) {
    throw 'A complete passing local gate is required before packaging.'
}
$pins188 = Get-Content -LiteralPath (Join-Path $receiptRoot188 'source-pins.json') -Raw | ConvertFrom-Json
foreach ($pin188 in $pins188.files) {
    if ((Get-FileHash -LiteralPath $pin188.path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $pin188.sha256) { throw "Tested source changed: $($pin188.path)" }
}
$staging188 = Join-Path $receiptRoot188 ('package-' + [Guid]::NewGuid().ToString('N'))
$destination188 = Join-Path (Get-Location).Path 'reports/evidence/188-atomic-record-evolution'
New-Item -ItemType Directory -Path $staging188,$destination188 -Force | Out-Null
function Copy-Evidence188([string]$source188, [string]$member188) {
    $target188 = Join-Path $staging188 $member188
    New-Item -ItemType Directory -Path (Split-Path -Parent $target188) -Force | Out-Null
    Copy-Item -LiteralPath $source188 -Destination $target188
}
foreach ($pin188 in $pins188.files) { Copy-Evidence188 $pin188.path ('sources/' + $pin188.path) }
foreach ($file188 in @('full-validation.json','full-validation.log','full-validation-exit.json','source-pins.json','accepted-runtime-pins.json','pin-accepted-runtime.ps1','validation-receipt.md','review-early.md','review-integration.md','review-final.md','review-delta.md','inherited-evidence-audit.json','inherited-evidence-failure-summary.md','audit-inherited-evidence.ps1','run-full-validation.ps1','package-evidence.ps1')) {
    Copy-Evidence188 (Join-Path $receiptRoot188 $file188) ('validation/' + $file188)
}
foreach ($companion188 in Get-ChildItem -LiteralPath $receiptRoot188 -File -Filter 'full-validation.*.json') {
    Copy-Evidence188 $companion188.FullName ('validation/' + $companion188.Name)
}
foreach ($file188 in @('validation.txt','failure-attempts.txt')) {
    Copy-Evidence188 (Join-Path $receiptRoot188 ('ir-snapshot/' + $file188)) ('validation/ir-snapshot/' + $file188)
}
foreach ($file188 in @('atomic-migration.patch.flow','readiness-owner-inventory.md','persisted-seed-source-audit.md')) {
    Copy-Evidence188 (Join-Path $receiptRoot188 ('readiness-source/' + $file188)) ('readiness-source/' + $file188)
}
$members188 = @(Get-ChildItem -LiteralPath $staging188 -File -Recurse | ForEach-Object {
    [ordered]@{path=[IO.Path]::GetRelativePath($staging188,$_.FullName).Replace('\','/'); bytes=$_.Length; sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()}
} | Sort-Object path)
$zip188 = Join-Path $destination188 'evidence.zip'
if (Test-Path -LiteralPath $zip188) { throw 'Do not overwrite accepted evidence.' }
[IO.Compression.ZipFile]::CreateFromDirectory($staging188,$zip188)
$archive188 = [IO.Compression.ZipFile]::OpenRead($zip188)
try {
    if ($archive188.Entries.Count -ne $members188.Count) { throw 'Archive member count differs.' }
    foreach ($member188 in $members188) {
        $entry188 = $archive188.GetEntry($member188.path)
        if ($null -eq $entry188 -or $entry188.Length -ne $member188.bytes) { throw "Archive member differs: $($member188.path)" }
        $stream188 = $entry188.Open()
        try { $hash188 = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream188)).ToLowerInvariant() }
        finally { $stream188.Dispose() }
        if ($hash188 -ne $member188.sha256) { throw "Archive hash differs: $($member188.path)" }
    }
} finally { $archive188.Dispose() }
[ordered]@{
    format=1; report='188-atomic-record-evolution'; baseRevision=$pins188.baseRevision
    testedWorkingSourcePins=$pins188.files
    localValidation=[ordered]@{passed=$true; checks=$validation188.checks.Count; terminalExitCode=$exit188.exitCode}
    archive=[ordered]@{file='evidence.zip'; bytes=(Get-Item -LiteralPath $zip188).Length; sha256=(Get-FileHash -LiteralPath $zip188 -Algorithm SHA256).Hash.ToLowerInvariant()}
    verification=[ordered]@{sourcePinsUnchanged=$true; memberHashes='passed'; count=$members188.Count}
    files=$members188
} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $destination188 'index.json') -Encoding utf8
Get-Content -LiteralPath (Join-Path $destination188 'index.json') -Raw | ConvertFrom-Json | Select-Object archive,verification | ConvertTo-Json -Depth 4

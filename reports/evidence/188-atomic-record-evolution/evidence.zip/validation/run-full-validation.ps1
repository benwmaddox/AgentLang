$ErrorActionPreference = 'Stop'
$repositoryPath = (Get-Location).Path
$receiptRoot = Join-Path $repositoryPath '.agentlang/type-evolution-188'
$temporaryRoot = Join-Path $receiptRoot 'tmp-full'
New-Item -ItemType Directory -Path $temporaryRoot -Force | Out-Null
$env:TEMP = $temporaryRoot
$env:TMP = $temporaryRoot
$paths = @(& git diff --name-only) + @('scripts/Validate.ps1', 'tests/AgentLang.Flow.Runtime.Tests/RecordEvolutionIsolation.fs')
if ($LASTEXITCODE -ne 0) { throw 'Cannot capture source paths.' }
$files = @($paths | Sort-Object -Unique | ForEach-Object {
    [ordered]@{path=$_; sha256=(Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash.ToLowerInvariant()}
})
$baseRevision = (& git rev-parse HEAD | Out-String).Trim()
if ($LASTEXITCODE -ne 0) { throw 'Cannot capture base revision.' }
[ordered]@{baseRevision=$baseRevision; startedUtc=[DateTimeOffset]::UtcNow.ToString('O'); files=$files} |
    ConvertTo-Json -Depth 6 | Set-Content (Join-Path $receiptRoot 'source-pins.json') -Encoding utf8
$logPath = Join-Path $receiptRoot 'full-validation.log'
& pwsh -NoProfile -File scripts/Validate.ps1 -Configuration Release -SerialBuild -SkipPackageAudit -ReportPath .agentlang/type-evolution-188/full-validation.json *> $logPath
$validationExit = $LASTEXITCODE
[ordered]@{exitCode=$validationExit; endedUtc=[DateTimeOffset]::UtcNow.ToString('O')} |
    ConvertTo-Json | Set-Content (Join-Path $receiptRoot 'full-validation-exit.json') -Encoding utf8
Get-Content -LiteralPath $logPath -Tail 9
exit $validationExit

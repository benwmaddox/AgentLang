$ErrorActionPreference = 'Stop'
$seedRoot = Join-Path (Get-Location) '.agentlang/efficacy-maintenance-184/seed-draft/projects/draft-009/flow-retained/project'
$auditRoot = Join-Path (Get-Location) '.agentlang/type-evolution-188'
$pointer = Get-Content -Raw -LiteralPath (Join-Path $seedRoot '.agentlang/store/CURRENT') | ConvertFrom-Json
$manifestPath = Join-Path $seedRoot ".agentlang/store/manifests/$($pointer.manifestHash).json"
$manifest = Get-Content -Raw -LiteralPath $manifestPath | ConvertFrom-Json
$patchPath = Join-Path $auditRoot 'readiness-source/atomic-migration.patch.flow'
$patch = (Get-Content -Raw -LiteralPath $patchPath).Replace("`r`n", "`n")
$casePattern = '(?ms)^(test|example)\s+([^\s{]+)\s*\{.*?^\}'
$draftCases = @{}
foreach ($match in [regex]::Matches($patch, $casePattern)) {
    $key = "$($match.Groups[1].Value):$($match.Groups[2].Value)"
    if ($draftCases.ContainsKey($key)) { throw "Duplicate draft case $key" }
    $draftCases[$key] = $match.Value
}
$rows = [System.Collections.Generic.List[object]]::new()
foreach ($owner in $manifest.words) {
    $revision = @($manifest.revisions | Where-Object { $_.wordId -eq $owner.wordId -and $_.revision -eq $owner.currentRevision })
    if ($revision.Count -ne 1) { throw "Ambiguous revision for $($owner.currentName)" }
    foreach ($kind in @('tests', 'examples')) {
        foreach ($reference in $revision[0].$kind) {
            $objectPath = Join-Path $seedRoot ".agentlang/store/objects/$($reference.hash).agent"
            $objectHash = (Get-FileHash -LiteralPath $objectPath -Algorithm SHA256).Hash.ToLowerInvariant()
            if ($objectHash -ne $reference.hash) { throw "Source object hash mismatch $objectPath" }
            $source = (Get-Content -Raw -LiteralPath $objectPath).Replace("`r`n", "`n")
            $found = [regex]::Matches($source, $casePattern)
            if ($found.Count -ne 1) { throw "Expected one top-level case in $objectPath" }
            $baseline = $found[0]
            $key = "$($baseline.Groups[1].Value):$($baseline.Groups[2].Value)"
            $adapted = $draftCases.ContainsKey($key)
            $equivalent = $true
            if ($adapted) {
                $normalized = [regex]::Replace($draftCases[$key], 'TrackingReference\.new\(("(?:\\.|[^"\\])*")\)', '$1')
                $equivalent = $normalized -ceq $baseline.Value
            }
            $rows.Add([ordered]@{case=$key; sourceHash=$reference.hash; adapted=$adapted; typedWrapperReversalMatches=$equivalent})
        }
    }
}
$testCount = @($rows | Where-Object { $_.case.StartsWith('test:') }).Count
$exampleCount = @($rows | Where-Object { $_.case.StartsWith('example:') }).Count
$failures = @($rows | Where-Object { -not $_.typedWrapperReversalMatches })
$passed = $testCount -eq 21 -and $exampleCount -eq 3 -and $failures.Count -eq 0
[ordered]@{passed=$passed; scope='source preservation only; no runtime or migration executed'; manifestHash=$pointer.manifestHash; patchHash=(Get-FileHash -LiteralPath $patchPath -Algorithm SHA256).Hash.ToLowerInvariant(); tests=$testCount; examples=$exampleCount; adapted=@($rows | Where-Object adapted).Count; rows=$rows} |
    ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $auditRoot 'inherited-evidence-audit.json') -Encoding utf8
Write-Output "Inherited source evidence: tests=$testCount examples=$exampleCount adapted=$(@($rows | Where-Object adapted).Count) failed=$($failures.Count)"
$failures | ForEach-Object { Write-Output $_.case }
if (-not $passed) { exit 1 }

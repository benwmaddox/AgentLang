# Atomic record evolution: integration source review

Snapshot: 2026-10-10. `Runtime.fs` SHA-256 `845B6D508F91BA928E557A4AE7D493C0E6BB22716E1EE8A3F30C09C555FDDF87`; `AuthoringHelp.fs` SHA-256 `1746D9A6B0AE69ECCADD0E7BB3A25222914FCF8AE4B34F80B70F8EB74312F190`.

Scope: read-only inspection of integrated Runtime/AuthoringHelp source and `git diff --check -- src/AgentLang.Core/Runtime.fs src/AgentLang.Core/AuthoringHelp.fs` (exit 0). No build, test, runtime probe, remote operation, or tracked-file edit. Implementation/tests remain in progress; this is not final acceptance.

## Findings and disposition

- **Resolved from early review:** `discard` now routes a word or type belonging to a staged group through `restoreTypeEvolutionGroup` (`Runtime.fs:6925-7011`). Metadata-only generated calls now identify affected owners for the caller test gate (`Runtime.fs:3791-3822`). Source inspection confirms these routes exist; behavior has not been executed here.
- **Discovered and resolved during this review:** The Stack `define` route previously allowed a case to be attached to a generated accessor while its type was staged. Group discard restores authored words and type rows, but not separately edited generated cases (`Runtime.fs:838-916`), so an added case on a removed accessor could strand rollback. The implementation now rejects attachment edits to generated operations owned by a staged type group at `Runtime.fs:3390-3405`. This closes the identified route in the reviewed snapshot.
- **No further concrete defect identified in this bounded pass.** The record CAS verifies exact owner names/hash and persistence before activation (`Runtime.fs:4198-4268`); publication expands selected candidates through group members and dependency closure, checks group completeness, then removes backups together (`Runtime.fs:3624-3736`); durable projection restores the prior record/source and authored word backups while staged (`Runtime.fs:743-836`). These are source observations, not proof from validation.

## Suggested acceptance fixture from source reasoning

To make a retained generated case: define the initial Flow record as a candidate; attach a Stack test/example to its generated candidate accessor or constructor before first commit. `registerParsed` permits generated Candidate metadata (`Runtime.fs:3387-3430`), and committing the type selects generated metadata and runs its tests (`Runtime.fs:3559-3578`, `3760-3765`). After fresh reload, evolution that removes the accessor should reject through `FLOW_TYPE_EVOLUTION_GENERATED_CASE_INCOMPATIBLE` (`Runtime.fs:4590-4600`). No execution was performed in this review.

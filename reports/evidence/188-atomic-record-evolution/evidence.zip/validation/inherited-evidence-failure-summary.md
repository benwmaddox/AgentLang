# Inherited source audit attempt summary

The first root execution of `audit-inherited-evidence.ps1` returned exit 1:
21 tests, 3 examples, 16 adapted cases, and 16 wrapper-reversal mismatches.
Inspection of `shipment.ingest-rule/appends-first-scan` confirmed changed
qualified calls, semicolons, branch order and expression layout in the draft.
These exceeded the allowed nominal-value wrapping adaptation.

The source-preparation agent restored each inherited case from its exact
manifest source object and applied only the necessary nominal String wrappers.
A fresh root execution returned exit 0: the same 21 tests and 3 examples,
16 adapted cases, and zero mismatches. The successful JSON receipt pins the
corrected draft hash. The earlier JSON receipt was overwritten by a rerun;
this summary preserves the observed failure, not the original failing draft
or a reconstruction of its hash.

Neither attempt invoked the language runtime, migration, tests or oracle.

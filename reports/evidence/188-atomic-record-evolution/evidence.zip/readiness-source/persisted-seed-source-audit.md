# Persisted seed manifest and source-object audit

Read-only audit of the exact dispatch-selected retained seed. Inputs were parsed as structured JSON; object contents and file hashes were read without invoking the runtime, broker, migration, tests, or oracle.

## CURRENT and frozen-file hashes

| File/claim | Expected or pinned SHA-256 | Actual SHA-256 | Exact comparison |
|---|---|---|---|
| dispatch-gate.json | 9350b6f58cd6dd394bdeba87375feea9fadac857936291efd6c90e2d7adbf05f; frozen pin=9350b6f58cd6dd394bdeba87375feea9fadac857936291efd6c90e2d7adbf05f | 9350b6f58cd6dd394bdeba87375feea9fadac857936291efd6c90e2d7adbf05f | PASS |
| trials/actors.json | 8ff9e4907603a6630cbc870e8cac6bbe6491e310fcb09cb8514195c316774fdd | 8ff9e4907603a6630cbc870e8cac6bbe6491e310fcb09cb8514195c316774fdd | PASS |
| retained seed dictionary.agent | 228d35945892c59e0cb682b1fb85549053718f99ab53cf75fafc42e14a723e20; frozen pin=228d35945892c59e0cb682b1fb85549053718f99ab53cf75fafc42e14a723e20 | 228d35945892c59e0cb682b1fb85549053718f99ab53cf75fafc42e14a723e20 | PASS |
| retained seed history/task-0001.json | 5bc69cdc849a9284aaea089d5d0d0696e1693efff81f521bfece6bf0a0392ee3; frozen pin=5bc69cdc849a9284aaea089d5d0d0696e1693efff81f521bfece6bf0a0392ee3 | 5bc69cdc849a9284aaea089d5d0d0696e1693efff81f521bfece6bf0a0392ee3 | PASS |
| retained seed .agentlang/store/CURRENT | 35392f0dd027efc2f145f146b8e9e02b50088cde2dda309da25c818ce320a80f; frozen pin=35392f0dd027efc2f145f146b8e9e02b50088cde2dda309da25c818ce320a80f | 35392f0dd027efc2f145f146b8e9e02b50088cde2dda309da25c818ce320a80f | PASS |
| selected manifest file | f6ddf24bb78014908fc45d1e4f464baeb6c6b3b2cff693b7c140d18eacd29a6f; frozen pin=f6ddf24bb78014908fc45d1e4f464baeb6c6b3b2cff693b7c140d18eacd29a6f | f6ddf24bb78014908fc45d1e4f464baeb6c6b3b2cff693b7c140d18eacd29a6f | PASS |

Structured pointer comparison: CURRENT formatVersion=1, generation=10, kind=manifest, manifestHash=f6ddf24bb78014908fc45d1e4f464baeb6c6b3b2cff693b7c140d18eacd29a6f; selected manifest formatVersion=3; inventory pointer/manifest-format claim=PASS.

## Type-source references

| Type | Manifest source hash | Inventory source hash | Object-file SHA-256 | Comparison |
|---|---|---|---|---|
| Scan | c4a07ab84b5b09718e9b6bf9b4693098aa91a611249799c54ed5eae97f68745e | c4a07ab84b5b09718e9b6bf9b4693098aa91a611249799c54ed5eae97f68745e | c4a07ab84b5b09718e9b6bf9b4693098aa91a611249799c54ed5eae97f68745e | PASS |
| ScanInput | 5f0454f7d9c3f857796b091d332dceccd35b7b2cff51ae0b8a0d47e8ddf71863 | 5f0454f7d9c3f857796b091d332dceccd35b7b2cff51ae0b8a0d47e8ddf71863 | 5f0454f7d9c3f857796b091d332dceccd35b7b2cff51ae0b8a0d47e8ddf71863 | PASS |
| ShipmentScanLookup | 454be75d6ae91922693524cd70fc58e3369ebc1c95285956f6c99ede84054174 | 454be75d6ae91922693524cd70fc58e3369ebc1c95285956f6c99ede84054174 | 454be75d6ae91922693524cd70fc58e3369ebc1c95285956f6c99ede84054174 | PASS |

## Function owner ID, revision, maturity, signature, and source object

| Owner | Manifest word ID | Inventory word ID | Current revision | Inventory revision | Maturity | Signature | Source hash / object SHA-256 | All comparisons |
|---|---|---|---:|---:|---|---|---|---|
| shipment.batch-step | word_b3a2cae7072b417687b287f7287c16ae | word_b3a2cae7072b417687b287f7287c16ae | 1 | 1 | project | `(BatchState, ScanInput) -> BatchState` | 5aeef284eac74663aa3732df3e1bd338a026dec477c117e6cf9ea78711da02c8 / 5aeef284eac74663aa3732df3e1bd338a026dec477c117e6cf9ea78711da02c8 | PASS |
| shipment.find-scan | word_242e605ef079454dbc4be3314ed7f8b1 | word_242e605ef079454dbc4be3314ed7f8b1 | 1 | 1 | library | `(Shipment, String) -> Option<Scan>` | 5a4ba156c175d2f4287503fd3c2f36f706375c00221e3b77e1a29bf98e50af05 / 5a4ba156c175d2f4287503fd3c2f36f706375c00221e3b77e1a29bf98e50af05 | PASS |
| shipment.ingest | word_82abda405e7a41198912999ed2ff53ef | word_82abda405e7a41198912999ed2ff53ef | 1 | 1 | project | `(Store, ScanInput) -> Result<Store, ScanError>` | a9c29e99e1e0e93b2364190c1c110a1fe5bf161a8e10aa343595db137b1af88e / a9c29e99e1e0e93b2364190c1c110a1fe5bf161a8e10aa343595db137b1af88e | PASS |
| shipment.ingest-batch | word_bffe5e8f998340519b47bf52b6b8a319 | word_bffe5e8f998340519b47bf52b6b8a319 | 1 | 1 | project | `(Store, List<ScanInput>) -> Result<Store, ScanError>` | 513098c63f235842e156efd7baea135d1693a9cd32785d7d1bdb256a2e4c306f / 513098c63f235842e156efd7baea135d1693a9cd32785d7d1bdb256a2e4c306f | PASS |
| shipment.ingest-rule | word_083888cf63be42f7ab3464c7337f974f | word_083888cf63be42f7ab3464c7337f974f | 1 | 1 | project | `(Shipment, ScanInput) -> Result<Shipment, ScanError>` | 15ebbdd75103701a09c388a7b06eba33c3288819b01535f4f17ce81da6aea363 / 15ebbdd75103701a09c388a7b06eba33c3288819b01535f4f17ce81da6aea363 | PASS |
| shipment.scan-lookup-step | word_3cc74855ad224efc97826471b172a994 | word_3cc74855ad224efc97826471b172a994 | 1 | 1 | library | `(ShipmentScanLookup, Scan) -> ShipmentScanLookup` | 2df107765e3326bf5c0acbd76a23376af50899fbd65240d5aab592a5efb812ec / 2df107765e3326bf5c0acbd76a23376af50899fbd65240d5aab592a5efb812ec | PASS |
| store.shipment | word_f1e5fbe50c154bd8ba7bbdb1ff7a6eed | word_f1e5fbe50c154bd8ba7bbdb1ff7a6eed | 1 | 1 | project | `(ShipmentId, Store) -> Option<Shipment>` | 3d5ab84b5711c9f73a00023369aeb0a717665c43427ffcca93b3dea6b3b4dff2 / 3d5ab84b5711c9f73a00023369aeb0a717665c43427ffcca93b3dea6b3b4dff2 | PASS |
| store.shipment-lookup-step | word_524a2828125849799133b630a0530eb9 | word_524a2828125849799133b630a0530eb9 | 1 | 1 | project | `(StoreShipmentLookup, Shipment) -> StoreShipmentLookup` | 1187cdf670ec3b0591b2aff89c26cbb43928bdb6e90658d1251e0479fb806ae0 / 1187cdf670ec3b0591b2aff89c26cbb43928bdb6e90658d1251e0479fb806ae0 | PASS |
| store.shipment-replacement-step | word_14915ad7658140808d9e35d93e67ae17 | word_14915ad7658140808d9e35d93e67ae17 | 1 | 1 | project | `(ShipmentReplacement, Shipment) -> ShipmentReplacement` | a525bbd715b6f815dbd4cd66094fd01200779948e10edc561c5215f037e83dde / a525bbd715b6f815dbd4cd66094fd01200779948e10edc561c5215f037e83dde | PASS |
| store.with-shipment | word_92d8cdaa85714cd1a95e9045b7ac86f4 | word_92d8cdaa85714cd1a95e9045b7ac86f4 | 1 | 1 | project | `(Store, Shipment) -> Store` | 21f1fcec28acd17d3bac832bf6645fa568445d3c3e29c55f2ad5cb5f4fd20a39 / 21f1fcec28acd17d3bac832bf6645fa568445d3c3e29c55f2ad5cb5f4fd20a39 | PASS |

Selected manifest current-owner attachment totals: 21 tests and 3 examples; inventory count claim comparison=PASS.

## Unchanged attachment-owner source definitions

Each draft definition was extracted from the Flow patch and compared byte-for-byte as text after normalizing line endings and removing only terminal newlines, against the exact manifest-referenced `.agent` source object. The object file SHA-256 was also checked against the manifest hash.

| Owner | Manifest source hash | Object-file SHA-256 | Exact source-text comparison |
|---|---|---|---|
| shipment.batch-step | 5aeef284eac74663aa3732df3e1bd338a026dec477c117e6cf9ea78711da02c8 | 5aeef284eac74663aa3732df3e1bd338a026dec477c117e6cf9ea78711da02c8 | PASS |
| shipment.ingest | a9c29e99e1e0e93b2364190c1c110a1fe5bf161a8e10aa343595db137b1af88e | a9c29e99e1e0e93b2364190c1c110a1fe5bf161a8e10aa343595db137b1af88e | PASS |
| shipment.ingest-batch | 513098c63f235842e156efd7baea135d1693a9cd32785d7d1bdb256a2e4c306f | 513098c63f235842e156efd7baea135d1693a9cd32785d7d1bdb256a2e4c306f | PASS |
| shipment.scan-lookup-step | 2df107765e3326bf5c0acbd76a23376af50899fbd65240d5aab592a5efb812ec | 2df107765e3326bf5c0acbd76a23376af50899fbd65240d5aab592a5efb812ec | PASS |

Audit result: PASS. No runtime, build, test, broker, migration, or oracle was invoked.

# Readiness source inventory and preservation map

This is a source-preparation artifact for a later deterministic positive readiness control. It is not a migrated project or a readiness result. The source patch is at atomic-migration.patch.flow; it is a proposed Flow/2 define payload assembled from the persisted unmigrated seed.

## Seed identity and current heads

The only baseline used for inherited source and attachment inventory is the dispatch input:

- dispatch-gate.json -> seeds.retained: .agentlang/efficacy-maintenance-184/seed-draft/projects/draft-009/flow-retained/project
- The actual dictionary.agent SHA-256 is 228d35945892c59e0cb682b1fb85549053718f99ab53cf75fafc42e14a723e20.
- The actual history/task-0001.json SHA-256 is 5bc69cdc849a9284aaea089d5d0d0696e1693efff81f521bfece6bf0a0392ee3.
- Both match the frozen retained-2 actor’s initial pins in trials/actors.json.
- This seed’s .agentlang/store/CURRENT pointer has formatVersion: 1, generation: 10, and manifest hash f6ddf24bb78014908fc45d1e4f464baeb6c6b3b2cff693b7c140d18eacd29a6f. The manifest it selects has formatVersion: 3. Record this actual input format; do not label the input format 5.
- Frozen-input SHA-256 receipt: dispatch-gate.json=9350b6f58cd6dd394bdeba87375feea9fadac857936291efd6c90e2d7adbf05f; trials/actors.json=8ff9e4907603a6630cbc870e8cac6bbe6491e310fcb09cb8514195c316774fdd; the seed CURRENT pointer=35392f0dd027efc2f145f146b8e9e02b50088cde2dda309da25c818ce320a80f; and the selected manifest file itself=f6ddf24bb78014908fc45d1e4f464baeb6c6b3b2cff693b7c140d18eacd29a6f. The selected manifest-file hash agrees with its filename and CURRENT pointer.
- The selected manifest’s current authored type-source object references are Scan=c4a07ab84b5b09718e9b6bf9b4693098aa91a611249799c54ed5eae97f68745e, ScanInput=5f0454f7d9c3f857796b091d332dceccd35b7b2cff51ae0b8a0d47e8ddf71863 and ShipmentScanLookup=454be75d6ae91922693524cd70fc58e3369ebc1c95285956f6c99ede84054174.
- Those on-disk object references establish which seed was inspected. The control must query the fresh runtime’s describe(type) payload immediately before staging and place the returned current source hashes in expectedTypeSources for exactly Scan, ScanInput, and ShipmentScanLookup. Do not hard-code the object references above as the request’s CAS tokens.
- The seed-draft/controls/correct source was consulted only as a behavioral reference. It is not the starting project and does not replace the persisted seed. The failed retained-1 candidate was not used to derive the draft.

No project files, CURRENT, manifests, frozen 184 inputs, actor copies, or oracle outputs were edited or regenerated.

## Atomic Flow/2 source proposal

atomic-migration.patch.flow contains the three replaced records, a new TrackingReference : String nominal type, the permitted helper signature change, the updated shared ingest rule, all 13 inherited tests and 3 examples whose typed values need adaptation, and seven focused replay tests. It also re-declares all six function owners whose inline test/example attachments change: two with behavior or signature edits and four with their exact baseline bodies/signatures so their attachments can be replaced under owner CAS. The unchanged declarations are CAS participants, not behavioral edits.

Type changes:

- Add unused nominal TrackingReference : String {} with no validator, predicate, trimming, or case conversion.
- Change Scan.reference: String to TrackingReference.
- Change ScanInput.reference: String to TrackingReference.
- Change ShipmentScanLookup.target: String to TrackingReference.
- Change shipment.find-scan’s reference parameter from String to TrackingReference.

shipment.ingest-rule checks status first. After status succeeds, it calls the retained shipment.find-scan for the selected shipment; a match returns the original shipment unchanged, and no match appends one scan. shipment.ingest still selects the shipment before calling the rule, so unknown-shipment precedence is preserved. equals remains exact; an empty reference is valid. The existing callback returns the first matching scan, so replay preserves the first scan and status. Batch entry continues to fold events in order.

No new helper is needed. Retain both shipment.find-scan and shipment.scan-lookup-step as the existing library owners, with their existing IDs and library maturity. Recompile every authored function, attached test, and example against one proposed type snapshot. In particular, recompile the lookup callback and the shipment.ingest-rule -> shipment.ingest -> shipment.batch-step -> shipment.ingest-batch caller chain even where source text or nominal record names stay unchanged.

The public entry points are independent preservation checks. Their source definitions are present unchanged in the patch because their inline evidence is adapted; these are owner-CAS replacements, not behavior or signature edits:

- shipment.ingest(Store, ScanInput) retains its function ID and signature.
- shipment.ingest-batch(Store, List<ScanInput>) retains its function ID and signature.

Their typed inline evidence is adapted. The owner revisions may advance when the new evidence is committed, so compare IDs and signatures separately and do not claim revision preservation.

## Function owner inventory

All ten authored function owners are in the detached recompile and preservation inventory. The revisions shown are the current persisted seed revisions; read describe(word) in the fresh control process and use the returned current revisions for any request CAS.

| Function owner | Persisted ID | Seed revision | Maturity | Persisted signature | Draft action |
|---|---|---:|---|---|---|
| shipment.batch-step | word_b3a2cae7072b417687b287f7287c16ae | 1 | project | (BatchState, ScanInput) -> BatchState | Re-declare unchanged body/signature under owner CAS; adapt 2 attached tests |
| shipment.find-scan | word_242e605ef079454dbc4be3314ed7f8b1 | 1 | library | (Shipment, String) -> Option<Scan> | Keep ID/maturity; change parameter to TrackingReference; adapt 3 tests and 1 example |
| shipment.ingest | word_82abda405e7a41198912999ed2ff53ef | 1 | project | (Store, ScanInput) -> Result<Store, ScanError> | Re-declare unchanged body/signature under owner CAS; adapt 3 tests; add 3 tests |
| shipment.ingest-batch | word_bffe5e8f998340519b47bf52b6b8a319 | 1 | project | (Store, List<ScanInput>) -> Result<Store, ScanError> | Re-declare unchanged body/signature under owner CAS; adapt 1 test; add 4 tests; keep 1 unchanged test |
| shipment.ingest-rule | word_083888cf63be42f7ab3464c7337f974f | 1 | project | (Shipment, ScanInput) -> Result<Shipment, ScanError> | Keep ID/signature; update body; adapt 1 test |
| shipment.scan-lookup-step | word_3cc74855ad224efc97826471b172a994 | 1 | library | (ShipmentScanLookup, Scan) -> ShipmentScanLookup | Re-declare unchanged body/signature under owner CAS; retain ID/maturity; adapt 3 attached tests |
| store.shipment | word_f1e5fbe50c154bd8ba7bbdb1ff7a6eed | 1 | project | (ShipmentId, Store) -> Option<Shipment> | Recompile; keep 2 tests unchanged |
| store.shipment-lookup-step | word_524a2828125849799133b630a0530eb9 | 1 | project | (StoreShipmentLookup, Shipment) -> StoreShipmentLookup | Recompile; keep 3 tests unchanged |
| store.shipment-replacement-step | word_14915ad7658140808d9e35d93e67ae17 | 1 | project | (ShipmentReplacement, Shipment) -> ShipmentReplacement | Recompile; keep 1 test unchanged |
| store.with-shipment | word_92d8cdaa85714cd1a95e9045b7ac86f4 | 1 | project | (Store, Shipment) -> Store | Recompile; keep 1 test unchanged |

The definitions whose Flow source behavior or signature actually changes are shipment.find-scan and shipment.ingest-rule. The patch re-declares unchanged bodies for shipment.batch-step, shipment.ingest, shipment.ingest-batch, and shipment.scan-lookup-step because those owners carry adapted attachments. The six owner-CAS names are shipment.batch-step, shipment.find-scan, shipment.ingest, shipment.ingest-batch, shipment.ingest-rule, and shipment.scan-lookup-step. Read current describe(word) revisions immediately before staging and use those dynamic revisions for every replaced definition or attachment; revisions can advance on any of these owners even when its body and signature are unchanged. Validate preserved IDs, signatures, and library maturity as separate invariants. The expectedTypeSources key set stays exactly the three replaced record owners; TrackingReference is new and has no prior source to compare.

## Inherited test and example map

The seed contains 21 standalone tests and 3 examples. The patch includes 13 adapted inherited tests and 3 adapted examples. Each of these 16 case blocks was copied from its exact manifest-referenced source object; only raw String literals used as migrated reference/target/helper arguments or the expected reference value are wrapped in TrackingReference.new(...). The root-owned source-only audit reverses only those wrappers and compares the full case text to the baseline objects: 21 tests, 3 examples, 16 adapted, 0 mismatches. Its receipt is .agentlang/type-evolution-188/inherited-evidence-audit.json; no source syntax, qualification, branch order, statement punctuation, assertion, or domain value was otherwise changed.

Adapted inherited tests:

- shipment.batch-step: applies-successful-input, keeps-first-error
- shipment.find-scan: empty-shipment, no-match, returns-first-match
- shipment.ingest: invalid-status-for-known-shipment, preserves-unrelated-state, unknown-shipment-precedes-invalid-status
- shipment.ingest-batch: preserves-order-and-stops-at-first-error
- shipment.ingest-rule: appends-first-scan
- shipment.scan-lookup-step: keeps-first-match, match, no-match

Adapted inherited examples:

- shipment.find-scan/first-reference
- shipment.ingest/append-one-scan
- shipment.ingest-batch/ordered-events

These eight inherited tests do not construct or pass a migrated reference and stay unchanged in the inherited project:

- shipment.ingest-batch/empty-is-identity
- store.shipment/no-match
- store.shipment/returns-first-match
- store.shipment-lookup-step/keeps-first-match
- store.shipment-lookup-step/match
- store.shipment-lookup-step/no-match
- store.shipment-replacement-step/replaces-only-the-target
- store.with-shipment/preserves-store-fields-and-order

The seven additions cover invalid status on replay, full-Store replay identity and first-scan retention, same text on another shipment, replay during a batch with first-event retention and ordered new scans, replay against an already populated batch target, valid empty-reference deduplication, and exact case/whitespace distinctions.

The persisted manifest stores per-function inline test and example references and has no test-file wrapper references. The generated constructors/accessors whose element types change are scan.new / scan.reference, scanInput.new / scanInput.reference, and shipmentScanLookup.new / shipmentScanLookup.target; TrackingReference.new is introduced for typed values. All consumers of these generated declarations must compile from the same detached schema snapshot.

The patch is source preparation only. It did not call the broker, invoke define, run tests or the 18-case oracle, commit, capture, or reload a project. The later readiness run must still independently prove atomic publication, preserved entry IDs/signatures and library qualification, inherited evidence, nonzero test count, terminal completion, type history, and fresh-process reload from the actual retained seed.

import json, subprocess, sys
from pathlib import Path
repo=Path.cwd(); out=repo/'.agentlang/dot-calls-155'/sys.argv[1]; out.mkdir()
summary=[]
for name in ['customer','containers','closed-renewal-state','money-ratio','nonempty-interval','refined-types']:
 sources=(['refined-types'] if name=='containers' else ['business-values','business-store'] if name=='money-ratio' else [])+[name]
 requests=[{'op':'define','syntaxVersion':1 if source.startswith('business-') else 2,'source':(repo/'examples'/f'{source}.agent').read_text()} for source in sources]+[{'op':'test-all'}]
 wire=''.join(json.dumps(x)+'\n' for x in requests)
 (out/f'{name}-requests.jsonl').write_text(wire)
 p=subprocess.run(['dotnet','src/AgentLang.Cli/bin/Release/net9.0/AgentLang.Cli.dll','--jsonl'],input=wire.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120)
 (out/f'{name}-responses.jsonl').write_bytes(p.stdout)
 (out/f'{name}-stderr.txt').write_bytes(p.stderr)
 rows=[json.loads(x) for x in p.stdout.decode('utf-8-sig').splitlines() if x]
 assert p.returncode==0 and len(rows)==len(requests) and all(x['ok'] for x in rows),(name,rows)
 tests=rows[-1]['data']['results']; assert tests and all(x['passed'] for x in tests),(name,tests)
 summary.append({'example':name,'sources':sources,'tests':len(tests),'passed':True})
(out/'summary.json').write_text(json.dumps(summary,indent=2)); print(json.dumps(summary))


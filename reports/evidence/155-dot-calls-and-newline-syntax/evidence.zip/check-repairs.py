import json, subprocess
from pathlib import Path
repo=Path.cwd(); root=repo/'.agentlang/dot-calls-155'; output=root/'repair-checks-002'; output.mkdir(exist_ok=False)
checks=[('flow',['dotnet','tests/AgentLang.Flow.Tests/bin/Release/net9.0/AgentLang.Flow.Tests.dll']),
('acceptance',['dotnet','tests/AgentLang.Acceptance/bin/Release/net9.0/AgentLang.Acceptance.dll']),
('discovery',['dotnet','tests/AgentLang.Discovery.Tests/bin/Release/net9.0/AgentLang.Discovery.Tests.dll'])]
for name,script in [('snapshots','Verify-MatchedRenewalSnapshots'),('renewal-gate','Verify-FlowRenewalAcceptanceGate'),('renewal-replay','Verify-FlowRenewalReplay')]:
 checks.append((name,['pwsh','-NoProfile','-File','scripts/'+script+'.ps1','-CliDll','src/AgentLang.Cli/bin/Release/net9.0/AgentLang.Cli.dll','-EvidencePath',str(output/(name+'.json'))]))
results=[]
for name,command in checks:
 with (output/(name+'.log')).open('wb') as log:
  p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 results.append({'name':name,'command':command,'exitCode':p.returncode}); print(name,p.returncode,flush=True)
 (output/'summary.json').write_text(json.dumps(results,indent=2))
 if p.returncode: raise SystemExit(p.returncode)

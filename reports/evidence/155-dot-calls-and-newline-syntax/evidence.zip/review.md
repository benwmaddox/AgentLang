# Flow/2 dot-call milestone 155 review

Static review only; no build or test commands were run. Scope was the Flow parser/lowering/formatter, runtime reference metadata, help text, and focused Flow/runtime tests. The implementation keeps the intended AST distinctions visible: a bound first segment is parsed as a receiver/property path, an unbound dotted call as an exact `Call`, and a leading-dot root/dotted call as `RootCall`/exact `Call`. `FlowLowering.candidatesFor` keeps qualified names exact and fails a receiver-stage lookup without trying the qualified dictionary call. The formatter threads parameter, sequential-let, and match-payload locals and emits a leading-dot escape for a shadowed exact call. The additive `flowReferenceSyntaxVersion: 2` metadata is documented as authoritative even for Flow/1 source.

## Initial finding (historical; resolved in follow-up below)

- **P2 — dotted-name lookahead could absorb a newline-leading dot.** In the initial review snapshot, `src/AgentLang.Core/FlowParser.fs` (`dottedNameAhead` and `parseDottedName`) did not check token line numbers. With no local named `customer`, `parseExpressionWithVersion 2` treated `customer\n.balance(7)` as one exact `customer.balance(7)` call. This violated the contract that a dot at the start of the next line starts a separate exact-root call statement. The follow-up below confirms the lookahead now stops at that line break.

## Original acceptance coverage gaps and follow-up status

- **No fallback: addressed.** `tests/AgentLang.Flow.Tests/Program.fs:834–838` compiles a bound `customer: Int` receiver against an exact `customer.balance(value: Int)` word with an extra stage argument and expects `FLOW_NO_MATCHING_DOT_STAGE`. The exact direct call would otherwise be applicable, so this covers the no-fallback contract.
- **Callback shadowing: addressed.** `tests/AgentLang.Flow.Tests/Program.fs:840–852` uses a parameter named `customer` and asserts `customer.active?` remains a `NamespaceQualified` static callback bound to the exact `customer.active?` word.
- **Persisted legacy source: addressed.** `tests/AgentLang.Flow.Runtime.Tests/Program.fs:3597–3604` reads the committed `customer::balance(7)` source, reloads a fresh Engine before rename, verifies source bytes are unchanged, and runs the legacy caller's test. It does not directly assert serialized `StoredCallForm`, but successful load and execution exercise retained binding attestation.

The initial review found one parser correctness issue, now resolved in the follow-up snapshot. The three original bounded acceptance-test gaps are addressed; no unrelated refactor is requested.

## Follow-up recheck

The newline-lookahead finding above records the earlier snapshot and is **resolved in the snapshot inspected for this follow-up**. SHA-256 of `src/AgentLang.Core/FlowParser.fs` at recheck: `4F04A13AF293D925B0FB707A7A4E4BD4E3CEFF35A236E4EDA5446B636A63B80F`.

At current lines 260–274, `dottedNameAhead` now requires the dot and following identifier to share the preceding token's line. At lines 277–287, `parseDottedName` likewise only consumes a dot and identifier on the same line as the preceding segment. This prevents `customer\n.balance(7)` from being collected as one qualified name during lookahead. The earlier finding remains above as historical review evidence; this status applies to the hash recorded here. No build or tests were run for this recheck.

## Coverage and compatibility follow-up

This review checked the following current snapshots (SHA-256):

- `src/AgentLang.Core/FlowParser.fs`: `F8C660A051AD8A65DF683F652B9A197EDBF27AA2F3E042DFF22CF758877BE37C`
- `src/AgentLang.Core/FlowSyntax.fs`: `46D8687B7133730573290AC56DDCC7FACE02DDDDA47BEBE903701E60A2A5F509`
- `tests/AgentLang.Flow.Tests/Program.fs`: `9E06DB1A2BAC076B097E2222479C4A4E2DD56735A57D39ACEFD402E5710354A0`
- `tests/AgentLang.Flow.Runtime.Tests/Program.fs`: `93FAE33E0221280302FEA238E4E6E69B6D7446136923BDD062E71C9BCE5C463D`

The Float-rendering change uses invariant round-trip formatting and appends `.0` when the shortest representation would parse as an integer. Focused tests cover `100.0`, negative zero, exponent notation, parse/render type preservation, and interpreted value preservation. The multiline initializer renderer now indents continuation lines for Flow/2 lets, destructuring lets, and returns. The nested initializer test asserts the expected indentation exactly and reparses the formatted source idempotently.

Flow/1 nonterminal statement semicolons are still emitted by `FlowSource.renderStatements` (`FlowSyntax.fs:581–605`): the suffix condition appends `;` to every nonfinal statement when the syntax version is 1. The multi-statement Flow/1 fixture now explicitly asserts a rendered nonterminal semicolon.

- **P2 — record/scalar declaration separators were loosened for Flow/1 too (resolved).** The first follow-up found that the shared helper accepted newlines for both syntax versions. The frozen fix now gates the new behavior on `state.SyntaxVersion = 2`: `FlowParser.fs:1188–1194` for record fields, `1204–1206` for record validators, and `1240–1242` for scalar validators. The Flow/1 branches still require `;`; the existing Flow/1 regression at `tests/AgentLang.Flow.Tests/Program.fs:5438–5439` rejects a record field without its semicolon. Flow/1 renderer semicolons are also asserted at `Program.fs:1497–1499`.

The function/test/example statement separator behavior in `parseBlockStatementsUntil` predates this milestone and is not a Flow/1 regression; the resolved finding was limited to newly changed record/scalar declaration separators.

The multiline initializer whitespace is now asserted exactly at `tests/AgentLang.Flow.Tests/Program.fs:1013–1016`, in addition to the idempotent round-trip. The Flow/1 multi-statement fixture now explicitly checks a nonterminal semicolon at `Program.fs:1497–1499`.

For this final static recheck, the current `FlowParser.fs` hash is `F8C660A051AD8A65DF683F652B9A197EDBF27AA2F3E042DFF22CF758877BE37C`; the other reviewed hashes are unchanged from the coverage follow-up above. The parent reports fresh Flow test build 007/test 006 passed with 1,212 assertions. I did not run validation. No further issue was found in this bounded recheck; the known `values.map(.identity)` parser issue remains outside my scope.

No builds or tests were run for this follow-up. The known `values.map(.identity)` parser issue remains outside this review, as requested.

Coordinator validation follow-up: the callback parser repair is included in fresh build 007/test 006, which passes all 1,212 Flow assertions, including values.map(.identity). Later runtime fixture repairs are recorded in their separate numbered build/test logs; the static review hashes above describe its own snapshot.

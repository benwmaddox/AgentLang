import json, re, subprocess, sys
from pathlib import Path

repo = Path(__file__).resolve().parents[2]
run = Path(__file__).parent / sys.argv[1]
run.mkdir(exist_ok=False)
source = (repo / 'docs/CURRENT-SYNTAX.md').read_text(encoding='utf-8')
blocks = re.findall(r'```flow\s*\n(.*?)\n```', source, re.S)
assert blocks
requests = [{'op': 'define', 'frontend': 'flow', 'syntaxVersion': 2, 'source': block} for block in blocks]
requests.append({'op': 'test-all'})
wire = ''.join(json.dumps(r, ensure_ascii=True) + '\n' for r in requests)
(run / 'requests.jsonl').write_text(wire)
proc = subprocess.run(['dotnet', str(repo / 'src/AgentLang.Cli/bin/Release/net9.0/AgentLang.Cli.dll'),
                       '--allow', 'fs.read,fs.write', '--jsonl'], cwd=repo,
                      input=wire.encode('ascii'), stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120)
(run / 'responses.jsonl').write_bytes(proc.stdout)
(run / 'stderr.txt').write_bytes(proc.stderr)
assert proc.returncode == 0
responses = [json.loads(line) for line in proc.stdout.decode('utf-8-sig').splitlines() if line]
assert len(responses) == len(requests)
for response in responses:
    assert response['ok'], response
tests = responses[-1]['data']['results']
assert tests and all(test['passed'] for test in tests), tests
print(json.dumps({'guideBlocks': len(blocks), 'testResponse': responses[-1]}))

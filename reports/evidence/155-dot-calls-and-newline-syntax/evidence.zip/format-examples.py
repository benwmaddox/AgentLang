import hashlib, json, re, subprocess, sys
from pathlib import Path

repo = Path(__file__).resolve().parents[2]
run = Path(__file__).parent / sys.argv[1]
run.mkdir(exist_ok=False)
cli = repo / 'src/AgentLang.Cli/bin/Release/net9.0/AgentLang.Cli.dll'
targets = [p for p in sorted((repo / 'examples').glob('*.agent'))
           if re.search(r'^fn ', p.read_text(encoding='utf-8-sig'), re.M)]
assert len(targets) == 9, 'Review the current example inventory before changing scope.'
originals = {p: p.read_bytes() for p in targets}

def format_batch(sources, label):
    requests = [{'op': 'format', 'frontend': 'flow', 'syntaxVersion': 2, 'source': s} for s in sources]
    wire = ''.join(json.dumps(r, ensure_ascii=True) + '\n' for r in requests)
    (run / (label + '-requests.jsonl')).write_text(wire, encoding='utf-8')
    process = subprocess.run(['dotnet', str(cli), '--jsonl'], input=wire.encode('ascii'),
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=repo, timeout=120)
    (run / (label + '-responses.jsonl')).write_bytes(process.stdout)
    (run / (label + '-stderr.txt')).write_bytes(process.stderr)
    assert process.returncode == 0, process.stderr.decode('utf-8', errors='replace')
    results = [json.loads(line) for line in process.stdout.decode('utf-8-sig').splitlines() if line]
    assert len(results) == len(requests)
    for p, result in zip(targets, results):
        assert result['ok'], (str(p), result)
    return [r['data']['source'] for r in results]

sources = [originals[p].decode('utf-8-sig') for p in targets]
formatted = format_batch(sources, 'first')
assert formatted == format_batch(formatted, 'roundtrip'), 'Formatter must be idempotent.'
manifest = []
for p, source, canonical in zip(targets, sources, formatted):
    assert p.read_bytes() == originals[p], 'Example changed during formatting.'
    (run / p.name).write_bytes(originals[p])
    # Preserve the file's introductory comments; the rest is canonical source.
    prefix = re.match(r'\A(?:(?:[ \t]*#[^\n]*|[ \t]*)\r?\n)*', source).group(0)
    result = (prefix + canonical + '\n').encode('utf-8')
    manifest.append({'path': p.relative_to(repo).as_posix(),
                     'beforeSha256': hashlib.sha256(originals[p]).hexdigest(),
                     'afterSha256': hashlib.sha256(result).hexdigest()})
    p.write_bytes(result)
(run / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'formattedExamples': len(targets), 'idempotent': True, 'run': str(run)}))

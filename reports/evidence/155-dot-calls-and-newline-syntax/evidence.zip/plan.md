# Dot-qualified Flow calls: architecture plan

## Repository findings

- The checkout is `main`; existing untracked retention-trial artifacts are unrelated and must be preserved. No repository `AGENTS.md` was found.
- Flow/1 and Flow/2 source format versions are already persisted in each revision. Runtime reload parses each retained source using that version and compares its stored call bindings with the verified runtime snapshot.
- The current parser maps `namespace::word(...)` to `FlowExpression.Call`, `::word(...)` to `RootCall`, and `receiver.stage(...)` to `DotCall`. `FlowLowering.candidatesFor` resolves dotted call names exactly, while undotted direct names may resolve by short name.
- Flow has no parser lexical-scope state today. The lowerer already carries lexical maps through parameters, sequential lets, and branches. Canonical source rendering also has no scope parameter today.

## Resolution contract

Implement the syntax in the existing Flow/2 format; do not add Flow/3 or change the manifest format. Keep legacy `::` spellings readable in Flow/2 so stored Flow/2 bytes retain their prior meaning. Current documentation and canonical Flow/2 formatting should use dots. Preserve Flow/1 behavior where practical.

In Flow/2, parse an unescaped dotted call in lexical scope as follows:

- If its first segment is a currently bound local, build the existing receiver/property/dot-stage nodes. The local wins, and a missing or inapplicable stage reports its normal local/dot-stage error without trying a namespace candidate.
- Otherwise, build the existing exact `Call` for the complete dotted dictionary name. Dotted names continue to resolve by exact key, never by suffix search.
- A leading dot escapes local shadowing. `.identity(...)` is the exact-root form and keeps `RootCall` / `AbsoluteRoot`; `.customer.balance(...)` is an exact dotted dictionary call and keeps `Call` / `Direct`.
- A non-call `customer.email` with a bound `customer` remains `Property`. An unbound `customer` does not trigger a namespace lookup for property access.

The parser therefore needs a lexical-name scope while parsing word bodies: seed it from parameters; parse a let/destructure initializer in the old scope and add bindings afterward; inherit outer names into each conditional/match branch; add option/result payload names only to their own case body. This classifies `customer.balance(customer)` consistently in the actual word scope. Standalone expression parsing uses an empty lexical scope, so dotted identifier calls there are exact qualified calls unless represented by an unambiguous non-identifier receiver.

In Flow/2, a postfix dot continues a receiver/property chain only when it is on the same source line as the preceding expression token. A dot at the start of a new line begins a new exact leading-dot call statement, so `file.read(source)` followed by `.file.write(destination, contents)` is two statements. Multiline receiver chains are not supported; the formatter keeps ordinary chains on one line. Flow/1 retains its previous line-insensitive postfix parsing.

Special forms retain explicit parsing contexts and existing AST cases:

- Recognize `list.empty<T>`, `option.some<T>`, and `result.ok<T, E>` before local/dot classification; these remain `FlowExpression.Container` and their generic type arguments are unaffected.
- Generated enum constructors such as `RenewalState.pending()` remain exact dotted `Call`s; a bound local named `RenewalState` gets local precedence, while `.RenewalState.pending()` is the exact constructor escape.
- In static callback positions, `values.map(customer.active?)` is a `WordReference` with `NamespaceQualified` qualification, independent of any local named `customer`. `.map(.active?)` is the exact-root callback; `word active?` remains the explicit short callback spelling.
- Validator declarations are scope-free exact references: `validate customer.active?;` selects the dotted name and `validate .active?;` selects the exact root. Their stored semantic target remains the canonical dictionary key.
- Match arms may use a bare single expression (`pending => "Pending"`, `some value => value`, `error reason => handle(reason)`) or a brace block. Lower bare arms to the existing one-`Evaluate` statement block; keep braces for multi-statement arms and for expressions whose bare rendering cannot be reparsed safely.
- Newline-separated declarations and the approved optional semicolons belong to the existing parser/formatter work: record fields and validators, scalar validators, enum cases, and test effect-count assertions. The formatter may omit those semicolons. Do not add any other syntax cleanup.

Canonical rendering must thread the same lexical-name scope through expressions and statements. Seed word rendering with parameters; add let/destructure names only after rendering their initializer; give branch bodies inherited scope plus their own payload binder. When rendering a dotted exact `Call` whose first segment is shadowed, add the leading-dot escape so reparse cannot turn it into a receiver call. Root calls render with the leading dot. Ensure legacy `::` parses into the same AST forms and that canonical render/reparse preserves structural call paths, call forms, and targets.

## Implementation ownership and files

Core parser/formatter/lowering/rewrite ownership:

- `src/AgentLang.Core/FlowParser.fs`: tokenizer and qualified-name helpers; expression/postfix parsing; parser scope setup in `parseWordState`, sequential `parseBlockStatementsUntil` / `parseStatement`, `parseMatch`, and conditional branches; static callback lookahead; validator parsing; newline/optional-semicolon separators.
- `src/AgentLang.Core/FlowSyntax.fs`: retain current AST cases and binding-path shapes; update root-target/reference validation and v2 canonical rendering; thread lexical scope through `renderWord`, `renderStatements`, expression/argument rendering, and match cases; render container/validator paths with dots; omit only the approved optional semicolons.
- `src/AgentLang.Core/FlowLowering.fs`: enforce local-first classification for parsed receiver forms and exact dotted lookup for direct calls; keep candidate resolution exact and errors terminal; audit existing call-event reconciliation so `DotStage`, `Direct`, and `AbsoluteRoot` still reconcile with the same verified target IDs/revisions.
- `src/AgentLang.Core/FlowRewrite.fs`: keep rewrite decisions consistent with the existing `Call`, `RootCall`, and `DotCall` forms; when a receiver-stage rename becomes an exact dotted call, scope-aware rendering must add the escape if needed. Preserve callback qualification, argument order, and structural binding paths.
- `src/AgentLang.Core/AuthoringHelp.fs`: root owns canonical updates to current Flow/2 examples and request descriptions after the core freeze. Do not rewrite archived evidence snapshots.

Durable binding shape should remain compatible. `FlowPersistence.fs` already maps `Direct`, `DotStage`, `AbsoluteRoot`, and static callback qualifications into stored forms. `Runtime.fs` compares complete stored site keys and target identities at reload. Preserve those forms and do not rewrite retained source bytes during load. Old `namespace::word`, `::word`, callbacks, containers, enum constructors, and validator references must still parse to their established AST/binding identities.

## Regression coverage

Add focused cases in `tests/AgentLang.Flow.Tests/Program.fs` for:

- no-local `file.read(path)` as exact namespace call; parameter-local `file.read(path)` as receiver stage; `customer.balance(customer)` under a `customer` parameter; and failure on the local stage without global fallback when a matching namespace word also exists;
- exact escape `.identity(...)` and `.customer.balance(...)` under colliding locals; correct root vs direct binding form;
- `customer.email` property access, receiver chains, and shadowing at parameters, after a let initializer, destructure initializer, and option/result case binders without leaking branch locals;
- `option.some<Int>`, result/list constructors, generated enum constructors, callback names such as `values.map(customer.active?)`, root callbacks, and validator references;
- Flow/2 old-`::` parse compatibility and new dot canonical round-trip, including stable source spans and call-binding paths/forms; Float literal round-trip when the shortest representation otherwise looks like an integer (for example `90.0` and negative zero);
- newline-separated and semicolon-separated approved declarations/effect assertions; bare single-expression match arms with newline/semicolon separators; brace retention for multi-statement arms and safe round-trip of nested if/match/grouping/dot-call expressions; line-leading exact-root calls after a completed statement and nested multiline matches followed by another call statement.

Add integration cases in `tests/AgentLang.Flow.Runtime.Tests/Program.fs` for a retained Flow/2 source using legacy `::` that reloads with its existing `StoredCallBinding`, canonical formatting of new dot calls, and rename/reload when the new exact dotted target shares a prefix with a local. Verify callback binding and tamper detection still compare the stable target identity. Update `scripts/Verify-FlowCallBindings.fsx` only if its source examples/assertions need the new canonical spelling.

Suggested validation after implementation: `dotnet run --project tests/AgentLang.Flow.Tests/AgentLang.Flow.Tests.fsproj -c Release`, `dotnet run --project tests/AgentLang.Flow.Runtime.Tests/AgentLang.Flow.Runtime.Tests.fsproj -c Release`, and `dotnet fsi scripts/Verify-FlowCallBindings.fsx`.

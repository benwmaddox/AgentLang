import hashlib, json, subprocess, zipfile
from pathlib import Path
repo=Path.cwd(); raw=repo/'.agentlang/dot-calls-155'; out=repo/'reports/evidence/155-dot-calls-and-newline-syntax'
validation=json.loads((raw/'validation-002.json').read_text(encoding='utf-8-sig'))
assert validation['passed'] and len(validation['checks'])==37, 'Do not package incomplete or failing validation as a milestone.'
changes=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
tracked=[name for name in changes if name.startswith(('src/','tests/','examples/'))]
identity={'baseRevision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(), 'workingTreeValidation':True,
          'sourceHashes':{name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in tracked},
          'binaryHashes':{name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in ['src/AgentLang.Core/bin/Release/net9.0/AgentLang.Core.dll','src/AgentLang.Cli/bin/Release/net9.0/AgentLang.Cli.dll']}}
(raw/'source-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
(raw/'implementation.diff').write_bytes(subprocess.check_output(['git','diff','--','src','tests','examples']))
out.mkdir(parents=True,exist_ok=False)
files=sorted(p for p in raw.rglob('*') if p.is_file() and 'tmp' not in p.relative_to(raw).parts)
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files: z.write(p,p.relative_to(raw).as_posix())
with zipfile.ZipFile(archive) as z: assert z.testzip() is None
manifest={'archive':'evidence.zip','entries':len(files),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
'note':'Contains failed attempts, aborted first gate, passing final gate, review and plan, example roundtrips, library I/O qualification controls, source hashes and implementation diff. Temporary test directories and binaries omitted. Validation ran on a dirty working tree based on '+identity['baseRevision']+'.'}
(out/'archive.json').write_text(json.dumps(manifest,indent=2)+'\n'); print(json.dumps(manifest))

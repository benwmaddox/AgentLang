import json, subprocess
from pathlib import Path
root=Path.cwd(); run=root/'.agentlang/dot-calls-155/library-io-demo-001'; run.mkdir(exist_ok=False)
function='''fn settings.enabled?(path: String, fallback: Bool) -> Bool {
    effects fs.read
    doc "Reads an on/off flag, using the fallback when the file is absent."

    if file.exists?(path) {
        file.read(path) == "on"
    } else {
        fallback
    }
}'''
cases=[('present-on','    file.write("flag.txt", "on")\n    settings.enabled?("flag.txt", false)','true',2),
       ('present-off','    file.write("flag.txt", "off")\n    settings.enabled?("flag.txt", true)','false',2),
       ('absent-false','    settings.enabled?("flag.txt", false)','false',1),
       ('absent-true','    settings.enabled?("flag.txt", true)','true',1)]
tests=['test settings.enabled?/'+name+' {\n'+body+'\n    => '+expected+' effects {\n        fs.read: '+str(reads)+'\n        fs.write: 0\n    }\n}' for name,body,expected,reads in cases]
source=function+'\n\n'+'\n\n'.join(tests)+'\n'
(run/'library-io.agent').write_text(source)
def execute(name,source):
 project=run/name; project.mkdir()
 requests=[{'op':'define','syntaxVersion':2,'source':source},{'op':'test','word':'settings.enabled?'},{'op':'describe','word':'settings.enabled?'},{'op':'commit','word':'settings.enabled?','library':True},{'op':'describe','word':'settings.enabled?'}]
 wire=''.join(json.dumps(x)+'\n' for x in requests)
 (run/f'{name}-requests.jsonl').write_text(wire)
 proc=subprocess.run(['dotnet','src/AgentLang.Cli/bin/Release/net9.0/AgentLang.Cli.dll','--project',str(project),'--allow','fs.read,fs.write','--jsonl'],input=wire.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120)
 (run/f'{name}-responses.jsonl').write_bytes(proc.stdout); (run/f'{name}-stderr.txt').write_bytes(proc.stderr)
 rows=[json.loads(x) for x in proc.stdout.decode('utf-8-sig').splitlines() if x]; assert proc.returncode==0 and len(rows)==5
 return rows
full=execute('complete',source)
assert all(x['ok'] for x in full),full
assert full[-1]['data']['maturity']=='library', full[-1]
partial=execute('incomplete',function+'\n\n'+tests[0])
assert partial[1]['ok'] and all(x['passed'] for x in partial[1]['data']['results']),partial
assert not partial[3]['ok'],partial
mutant=execute('extra-read',source.replace('        file.read(path) == "on"','        let ignored = file.read(path)\n        file.read(path) == "on"'))
assert any(not x['passed'] for x in mutant[1]['data']['results']),mutant
assert not mutant[3]['ok'],mutant
summary={'complete':{'tests':len(full[1]['data']['results']),'maturity':full[-1]['data']['maturity']},'incompleteCommitError':partial[3]['error'],'extraReadCommitError':mutant[3]['error']}
(run/'summary.json').write_text(json.dumps(summary,indent=2)); print(json.dumps(summary))

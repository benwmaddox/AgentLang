# Source printer review: Flow test source inspection

## Finding

`tests includeSource:true` returns the source object held by the runtime; it does not call a formatter for Flow tests. The response is assembled in `src/AgentLang.Core/Runtime.fs:2828-2872` (`testSourceRows`). For a standalone Flow attachment, it selects `attachment.Source.Content`; for a case inside a test-file wrapper, it selects that case's `SourceText` from `authored.Settings.Tests` and also returns the wrapper's `Settings.SourceText`. The row includes `frontend` and `syntaxVersion`, and computes `sourceHash` over the exact string it returns.

The text stays exact through registration and persistence:

- `FlowParser.sourceSlice` in `src/AgentLang.Core/FlowParser.fs:201-204` slices the original input string between declaration tokens. `parseTestWithVersion` and `parseTestFileSettingsWithVersion` retain the submitted source at `:1410-1425`.
- `registerFlowProjectAddOnlyParsed` in `src/AgentLang.Core/Runtime.fs:4254-4340` uses each parsed test's `SourceText`; wrapper registration uses the parsed wrapper's `SourceText`. The one-word and attachment-only registration routes similarly pass `caseSource`/`parsed.SourceText` into `Storage.sourceObject` and preserve it as `Content` (`Runtime.fs:4456-4510`, `5132-5205`).
- `Storage.sourceObject` (`src/AgentLang.Core/Storage.fs:241-244`) hashes and carries the supplied content unchanged. `readSourceCore` (`:1211-1218`) verifies that hash and decodes the same bytes; `readRevision` (`:1696-1711`) returns those exact definition, test, and example strings.
- On reload, `Runtime.fs:2198-2318` parses the revision's test strings using each attachment's persisted source format and reconstructs attachment `Content` from `revisionContent.TestSources`. For wrappers it reparses the stored wrapper and retains its nested case slices. It does not render either form during this load path.

The semicolon policy belongs to the separate canonical printer. `FlowSource.renderStatements` in `src/AgentLang.Core/FlowSyntax.fs:603-627` appends `;` after each nonfinal statement only when `syntaxVersion = 1`. `FlowSource.renderTest` at `:713-733` uses that helper. The Flow/1 parser permits newline-separated statements (`FlowParser.parseBlockStatementsUntil`, `:492-514`), but the Flow/1 printer chooses semicolons anyway. Flow/2 rendering emits each statement on its own line without a suffix. That matches Flow/2's `fn`, property access, `==`, and leading-dot syntax; those constructs are version-gated in `FlowSyntax.fs:382-409` and `FlowParser.fs:712-782, 901-903`.

There is an important distinction between the printer and the inspected source. The aggregate `dictionary.agent` projection calls `FlowSource.renderTest` for standalone Flow tests (`Runtime.fs:870-872`); the content-addressed attachment objects are separately written from `item.Source.Content` (`:1082-1101`). The format operation also explicitly renders a parsed document (`Runtime.fs:5410-5425`). Thus an aggregate/export or Flow/1 `format` result can contain canonical semicolons while an `includeSource` response remains byte-for-byte authored. If a row says `frontend:"flow"`, `syntaxVersion:2` and its returned source has `.scan...;`, the semicolon was already in that stored source; this checkout's Flow/2 source-inspection and render paths do not synthesize it. If the row reports version 1, that version cannot parse Flow/2-only syntax such as a leading-dot exact reference, property access, or `==`.

## Bounded recommendation

For the requested `fn`/property/`==` convention, keep the source inspection contract exact and ensure seeds are registered and formatted with `syntaxVersion:2`. The default selector is Flow/1 when omitted (`Runtime.fs:3698-3700`), so a seed helper that omits the version is a likely place to check. Read `frontend`, `syntaxVersion`, `source`, and `sourceHash` from the returned row together. If the row is Flow/2 but contains a semicolon, fix the earlier seed producer that authored that byte; changing `testSourceRows` to reformat on read would silently change the meaning of `sourceHash` and contradict current exact-source tests.

If the separate requirement is that the Flow/1 canonical formatter also prefer newline separators, the smallest printer change is to stop adding the Flow/1 suffix in `FlowSyntax.fs:626`; its parser already accepts newline separators. Treat that as a separate compatibility change: it alters canonical Flow/1 formatting and aggregate export bytes, but it will not repair a Flow/2 `includeSource` row whose stored bytes already contain a semicolon. Do not change this printer based only on the inspected-row symptom.

## Tests, hashes, and schema constraints

- Existing end-to-end coverage is `testTestSourceInspection` in `tests/AgentLang.Flow.Runtime.Tests/Program.fs:1274-1458`. It defines newline-authored Flow/2 standalone and wrapped cases, checks exact source and hash during staging and after a fresh `Runtime.Engine` reload, and checks that inspection is read-only. Extend it with at least two adjacent statements in each case and explicit newline/no-semicolon assertions if adding a regression for the study symptom.
- Printer coverage is `testFlow2CanonicalRoundTrip` and `testFlow2TestFileSourceRoundTrip` in `tests/AgentLang.Source.Tests/Program.fs:627-684`. Add a multi-statement body and assert the rendered Flow/2 source remains newline-separated and idempotent. `testFlow2FormatDefinePersistReloadAndRewrite` in `tests/AgentLang.Flow.Runtime.Tests/Program.fs:1530-1645` already checks canonical format, exact source-object bytes/hashes, and persisted version metadata; it is a suitable place to cover format-to-storage behavior.
- Avoid rewriting existing Flow/1 bytes as part of this change. The Flow/1-to-Flow/2 attachment migration coverage at `tests/AgentLang.Flow.Runtime.Tests/Program.fs:2305-2334` checks retention of old source references and bytes, and mixed-version persistence checks per-attachment formats later in that test. If the Flow/1 printer itself changes, add an explicit Flow/1 printer regression and rerun the existing compatibility coverage.
- Hashes are byte contracts: `sourceHash` is SHA-256 of the returned source; standalone attachment references hash the standalone source, while a wrapped case's stored reference hashes the complete wrapper (the response also supplies a separate wrapper hash). Reformatting a persisted source creates a new immutable source reference; any rewritten call bindings must reference the new source object. The current manifest format 5 already records per-attachment frontend/version (`Storage.fs:405-416, 978-1029`), so a newline-only Flow/2 fix requires no schema bump or fixture migration. No separate source fixture is implicated by the existing tests; these cases are inline in the cited test programs.

## Suggested validation after an implementation

These acceptance projects are executable tests, not xUnit projects:

```powershell
dotnet run --project tests/AgentLang.Source.Tests --configuration Release
dotnet run --project tests/AgentLang.Flow.Runtime.Tests --configuration Release
git diff --check
```

No build or test was run for this read-only investigation.

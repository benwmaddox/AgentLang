#requires -Version 7.0
# Report-260 regression gates, run sequentially; each gets its own log and exit code.
$ErrorActionPreference = 'Continue'
$PSNativeCommandUseErrorActionPreference = $false
$repo = 'D:\code\AgentLang'
$out = Join-Path $repo ".agentlang/owning-list-ops-260/gates-$([DateTime]::UtcNow.ToString('yyyyMMddTHHmmssZ'))"
New-Item -ItemType Directory -Path $out -Force | Out-Null
$pwsh = (Get-Process -Id $PID).Path
$llvm = Join-Path $out 'llvm-suite'
$gates = @(
  @{ Name = 'llvm-full-suite'; Cmd = {
      & dotnet build "$repo/tests/AgentLang.Llvm.Tests/AgentLang.Llvm.Tests.fsproj" --artifacts-path "$llvm/build" -c Release -p:NuGetAudit=false -m:1
      if ($LASTEXITCODE -eq 0) { & dotnet "$llvm/build/bin/AgentLang.Llvm.Tests/release/AgentLang.Llvm.Tests.dll" --artifacts-path "$llvm/artifacts" } } }
  @{ Name = 'ir-interpreter'; Cmd = { & dotnet run --project "$repo/tests/AgentLang.IR.Interpreter.Tests" -c Release } }
  @{ Name = 'campfire'; Cmd = { & $pwsh -NoProfile -File "$repo/scripts/Verify-Campfire.ps1" -NoRestore } }
  @{ Name = 'native-value-stack'; Cmd = { & $pwsh -NoProfile -File "$repo/scripts/Verify-NativeValueStack.ps1" } }
  @{ Name = 'owning-mailbox'; Cmd = { & $pwsh -NoProfile -File "$repo/scripts/Verify-OwningMailbox.ps1" } }
  @{ Name = 'ir-parity'; Cmd = { & $pwsh -NoProfile -File "$repo/scripts/Verify-IRParity.ps1" } }
  @{ Name = 'native-conformance'; Cmd = { & $pwsh -NoProfile -File "$repo/scripts/Verify-NativeConformance.ps1" } }
  @{ Name = 'owning-lists'; Cmd = { & dotnet run --project "$repo/tests/AgentLang.OwningLists.Tests" -c Release } }
  @{ Name = 'owning-list-ops'; Cmd = { & dotnet run --project "$repo/tests/AgentLang.OwningListOps.Tests" -c Release } }
  @{ Name = 'room-read-trusted-off'; Cmd = { & $pwsh -NoProfile -File "$repo/scripts/Verify-CampfireNativeRoomRead.ps1" -RuntimeProfile TrustedGenerated -ExecutionProfile Off } }
  @{ Name = 'room-read-diagnostic-off'; Cmd = { & $pwsh -NoProfile -File "$repo/scripts/Verify-CampfireNativeRoomRead.ps1" -RuntimeProfile Diagnostic -ExecutionProfile Off } }
)
$summary = foreach ($gate in $gates) {
  $log = Join-Path $out "$($gate.Name).log"
  $started = Get-Date
  & $gate.Cmd *> $log
  $code = $LASTEXITCODE
  $tail = (Get-Content -LiteralPath $log -Tail 3) -join ' | '
  [pscustomobject]@{ gate = $gate.Name; exit = $code; seconds = [int]((Get-Date) - $started).TotalSeconds; tail = $tail }
}
$summary | ConvertTo-Json -Depth 3 | Set-Content (Join-Path $out 'summary.json') -Encoding utf8NoBOM
$summary | Format-Table gate, exit, seconds -AutoSize | Out-String | Write-Output
Write-Output "out=$out"

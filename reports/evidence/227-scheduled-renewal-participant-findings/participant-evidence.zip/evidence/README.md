# Scheduled renewal participant findings evidence

This package snapshots the finalized participant report and terminal evidence. It includes the retained arm's complete terminal project and durable store, the F# arm's source files only, both terminal trace files, termination audits, independent grader receipts and raw exchanges, participant metrics/finals/review, and the frozen candidate/supplement/dispatch records.

The retained endpoint is read-only and included as the complete terminal project/store. For F#, only the six endpoint source/project files are included. The F# launcher exited without an exchange (`input-eof`); no host.close was observed, no edits or validation occurred, and there is no F# functional grading claim. The independent participant review classifies it as startup/transport failure, not a demonstrated implementation defect.

The raw grading subtree omits disposable project-copy/scoring-copy trees, build artifacts, bin/obj, and temporary directories. The F# endpoint bin/obj directories and unrelated actor paths were not traversed. The preparation archive is linked by its verified SHA-256 in `evidence/preparation-archive-reference.json`.

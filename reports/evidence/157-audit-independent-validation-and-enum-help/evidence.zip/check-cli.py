import json, subprocess
from pathlib import Path

root = Path.cwd()
base = root / '.agentlang/audit-discovery-157'
command = ['dotnet', str(root / 'experiments/AgentLang.Conventional.Cli/bin/Release/net9.0/AgentLang.Conventional.Cli.dll'), '--project', str(root / '.agentlang/io-maintenance-156/scoring/conventional'), '--validation-project', 'AgentLang.IoMaintenance156.Conventional.fsproj', '--jsonl']
result = subprocess.run(command, input='{"op":"validate"}\n', text=True, encoding='utf-8', capture_output=True, timeout=120)
(base / 'conventional/cli-validation.jsonl').write_text(result.stdout, encoding='utf-8')
(base / 'conventional/cli-validation.stderr.txt').write_text(result.stderr, encoding='utf-8')
rows = [json.loads(line) for line in result.stdout.splitlines() if line]
assert result.returncode == 0 and len(rows) == 1 and rows[0]['ok'], result.stdout + result.stderr
assert '-p:NuGetAudit=false' in rows[0]['data']['command'], rows
assert 'SelfTests passed.' in rows[0]['data']['stdout'], rows
print('Fresh conventional CLI validates saved trial implementation with logged audit override.')

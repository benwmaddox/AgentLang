from pathlib import Path
import hashlib, json, subprocess, zipfile

root = Path.cwd()
base = root / '.agentlang/audit-discovery-157'
destination = root / 'reports/evidence/157-audit-independent-validation-and-enum-help'
destination.mkdir(parents=True, exist_ok=True)
archive = destination / 'evidence.zip'
assert not archive.exists()
patch = subprocess.check_output(['git', 'diff', '--binary'], cwd=root)
(base / 'working-change.patch').write_bytes(patch)
files = [p for p in sorted(base.rglob('*')) if p.is_file() and 'tmp' not in p.relative_to(base).parts]
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as out:
    for path in files:
        out.write(path, path.relative_to(base).as_posix())
manifest = {'sourceBaseHead': subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
            'archive': archive.name, 'entries': len(files), 'bytes': archive.stat().st_size,
            'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
            'files': [{'path': p.relative_to(base).as_posix(),'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]}
(destination / 'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    assert all(hashlib.sha256(check.read(item['path'])).hexdigest()==item['sha256'] for item in manifest['files'])
print(json.dumps({k:v for k,v in manifest.items() if k!='files'}))

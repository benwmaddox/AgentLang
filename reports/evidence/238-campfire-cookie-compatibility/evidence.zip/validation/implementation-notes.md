# Campfire cookie compatibility component

## Plan

1. Save a standalone, narrowly selected Rails fixture set and exact upstream license attribution under the cookie test project.
2. Implement an independent net9.0 F# project with fixed `session_token` and `_campfire_session` operations, explicit clock input, bounded JSON/cookie sizes, Rails envelope compatibility, and Rack escaping.
3. Add executable golden and negative tests for key derivation, signing, verification, AES-GCM session cookies, expiry, purpose, legacy fallback, input bounds, and escaping.
4. Run the requested Release build and executable test commands, then record final results and the confirmed fixture pins/counts here.

## Initial validation

Before the project existed, `dotnet build tests/AgentLang.Campfire.Cookies.Tests/AgentLang.Campfire.Cookies.Tests.fsproj -c Release -m:1` failed with `MSB1009: Project file does not exist`. This records the requested initial failure baseline.

After the projects were added, the requested build command attempted a sandbox restore and failed with `NU1900` because the sandbox could not reach the NuGet vulnerability-data endpoint. Root completed a trusted host-side restore with `NuGetAudit=true`; its output is preserved in `host-restore.log`. The sandbox build and test were then run serially with `--no-restore`. NuGet auditing was not disabled.

## Scope

The component is a host compatibility boundary only. It is not an HTTP/authentication implementation or production security proof. The upstream test secret is synthetic and must not be used for production configuration.

## Final validation

The standalone fixture subset records Rust compatibility source commit `6dae2fd3c1a2dce61ca11beb731bcce2b42b67ad`, Rails reference commit `90b330024dec3e757c79b6a7e6568f93da8e3148`, and source/vector hashes and fixture counts in `tests/AgentLang.Campfire.Cookies.Tests/Fixtures/README.md`. It contains 2 key derivation vectors, 4 signed-cookie generation cases, 16 signed-cookie verification cases, 1 encrypted-session generation record, 8 encrypted-session verification cases, and 7 Rack escape records. The standalone JSON fixture SHA-256 is `eb1c6afd57d445dcb327821e2134d8366383c5565ba1c1f2b1b2dfd5f822fae4`; the copied MIT license SHA-256 is `fa0d1454375cbc7701bc13d916c3ae71e613b8ae718321641e678e09409393c4`.

Final sandbox validation, using the already restored assets:

- `dotnet build tests/AgentLang.Campfire.Cookies.Tests/AgentLang.Campfire.Cookies.Tests.fsproj -c Release -m:1 --no-restore` — passed, 0 warnings, 0 errors.
- `dotnet run --project tests/AgentLang.Campfire.Cookies.Tests/AgentLang.Campfire.Cookies.Tests.fsproj -c Release --no-build --no-restore` — passed, 76 assertions across 5 groups.

Coverage includes exact signed-cookie Rails bytes (including literal U+2028/U+2029), key derivation, legacy and purpose handling, tampering, expiry boundaries and malformed/no-zone expiry, encrypted session round trips and randomized IVs, raw cookie boundary versus Rack wire expansion, and fail-closed inputs. Expiry parsing accepts explicit-zone ISO timestamps through seven fractional digits, matching `DateTimeOffset` precision; pinned Rails output uses milliseconds.

This component is only a narrowly scoped compatibility boundary. It is not HTTP/authentication integration or a production security proof; the upstream synthetic secret is test data only.

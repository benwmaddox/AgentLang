open System
open System.IO
open System.Text.Json
open AgentLang.Campfire.Cookies

let run () =
    use fixture = JsonDocument.Parse(File.ReadAllText("tests/AgentLang.Campfire.Cookies.Tests/Fixtures/rails-cookie-vectors.json"))
    let secret = fixture.RootElement.GetProperty("secret_key_base").GetString()
    let now = DateTimeOffset.Parse(fixture.RootElement.GetProperty("now").GetString())
    let service = CookieService.Create(secret) |> Result.defaultWith (fun _ -> failwith "Cannot create fixture cookie service")
    try
        for input in [ "\\u2028"; "\\u2029"; "\\\u2028"; "\\\\u2028"; "\\\\\u2029"; "quote\"backslash\\end" ] do
            let raw = service.SignSessionToken(input, now) |> Result.defaultWith (fun _ -> failwith "Control token rejected")
            if service.VerifySessionToken(raw, now) <> Some input then failwith "Unicode/backslash control changed its input"
        printfn "PASS: six literal-escape and Unicode/backslash controls"
    finally
        (service :> IDisposable).Dispose()

run ()

# Compiler review: native closed enums

Scope: read-only review of `src/AgentLang.Llvm/OwningStackAot.fs` and its Core
IR contracts. No build or tests were run; runtime C and test files were still
being edited during this review.

## Findings

**Versioning decision needed for the emitted mailbox manifest JSON.** The
public `OwningStackTypeLayout` and `OwningStackExecutionResult` record shapes
are unchanged, and `LayoutSchemaVersion = 2` still describes that managed
result. The native descriptor's 36-byte size does not by itself require a
managed result-schema bump. However, the mailbox artifact's serialized
`sharedLayout` now includes `caseCount` (including zero for non-enums), while
`manifestCore.formatVersion` and `manifestCore.abiVersion` remain 1
(`OwningStackAot.fs`, `layoutManifest` / `manifestCore`). Decide whether this
additive JSON field is allowed under format version 1 or whether to bump the
manifest `formatVersion`; keep that separate from the explicit native Layout
ABI 2. Correction: the initial scoped search missed the pre-existing
`scripts/Verify-OwningMailbox.ps1` reader, which already consumed
`manifest.moduleInfo`.

## Reviewed behavior

- The active `emitModule` path calls `emitDynamicModule` for both fixed-only
  and dynamic values; the packed fixed emitter is explicitly marked historical
  and is not selected. The dynamic path emits enum kind 6, appends the case
  count after the existing eight descriptor words, and writes Layout ABI 2.
  Non-enums emit count zero. This matches the selected 36-byte descriptor
  contract; the layout object itself remains unchanged.
- `buildType` models an enum as an 8-byte fixed leaf and records containing
  enums reuse normal inline field offsets. Core rejects empty enums, duplicate
  case names, and nominal name collisions. `validateEnumCall` checks the
  generated target/revision, exact nominal result type, zero inputs, and case
  index. `MatchEnum` validation checks that each verified case index appears
  exactly once and validates every branch. Core IR verification already
  enforces the exact scrutinee type and equal stack/local branch shapes.
- `MakeEnumCase` stores the verified ordinal in one 8-byte slot with the
  nominal type ID. `MatchEnum` switches on that slot, sends invalid ordinals
  through a structured `OWNING_STACK_ENUM_INVALID_TAG` diagnostic, and joins
  branch values by phis for offset, extent, payload, and owner end. It does not
  copy branch payloads. Record construction/projection keep their existing
  inline move behavior.
- Host `measureValue` and `encodeValues` validate the enum name against the
  verified nominal definition and the case against its case table; `decodeValues`
  rejects truncated, negative, or out-of-range tags. Core enforces unique
  nominal names, so the existing `EnumValue(typeName, caseName)` representation
  cannot alias two enum keys in one verified program.
- The active dynamic entry preflights every declared input with
  `al_owning_measure_external_value` before copying or entering the body,
  regardless of whether the IR uses that input. The runtime scanner recurses
  through record fields, so a nested enum is checked by its child descriptor.
  This matches the required invalid-external-value path; `emitFixedModule`'s
  raw-copy gap is irrelevant because that emitter is inactive.
- `ArenaLifetime.fs` still classifies `MakeEnumCase` and `MatchEnum` as
  unmodeled. Its fallback escapes all possible active/live regions and taints
  outputs, which can conservatively block rewinds in enum scopes but cannot
  authorize an unsafe rewind. The emitter adds no graph allocation or enum
  payload copy, so this preserves stable-arena safety at the possible cost of
  retaining extra dead interior space.

## Conclusion

No compiler correctness blocker found in the active emitter, typed constructor
and match path, host encode/decode, or all-input preflight.

## Follow-up

The mailbox manifest versioning decision is resolved: `docs/BACKENDS.md` says
format 1 permits additive inspection fields. The manifest now includes
`layoutAbiVersion = 2` and `typeDescriptorSizeBytes = 36` alongside the new
per-type `caseCount`; mailbox module `abiVersion = 1` and managed execution
result `LayoutSchemaVersion = 2` remain separate contracts. The existing
`scripts/Verify-OwningMailbox.ps1` reader now asserts `formatVersion`,
`layoutAbiVersion`, and `typeDescriptorSizeBytes` against the updated
`owning-mailbox.json` fixture. Thus the additive format-1 policy is documented
and checked. I did not run the validation gate; the root reports it is active
in session 5345.

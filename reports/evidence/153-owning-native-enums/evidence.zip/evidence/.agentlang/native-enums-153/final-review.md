# Final evidence review: native enums 153

The focused native and mailbox gates pass on the repaired source. This does not close full Release validation, which is still pending.

## Evidence checked

| Gate | Result in final evidence | Source stability |
| --- | --- | --- |
| Native value stack, `verification-c9929f1642a64de3b631349aead9f640` | Acceptance summary passes all 36 checks; linked native-value evidence passes with `failureCount: 0` and 946 conformance checks. All 102 enum checks pass across O0/O2; each run covers three cases, nine equalities, two invalid ordinals, and five malformed-input cases. | 45/45 source hashes match before and after. |
| Mailbox integration, `integration-run-b0f05ed417cc48f386d070c10b49e115` | 592/592 checks pass. The emitted module info reports format 1, module ABI 1, layout ABI 2, and a 36-byte type descriptor. | 22/22 hashes match; `sourceInputHashes.unchanged` is true. |
| Mailbox policy, `policy-run-107a81cf7a6a4235b99131179a456e4a` | 741/741 checks pass. | 23/23 before/after hashes match. |
| Real I/O, `io-run-aefa9615d956424bbbb56a672809e36b` | 208,838/208,838 checks pass. The frozen seven-case oracle completed all 12 O0/O2, profile, and RETURN/KEEP combinations; the provider exited gracefully. | 85/85 before/after hashes match, and the frozen oracle hash remained stable through evidence capture. |

The first sandbox real-I/O attempt failed before its cases ran because the local loopback connection returned Windows socket error 10013. The separate host-side retry passed; the report distinguishes these attempts. The oracle's `sha256BeforeNative` hashes the correctness-case file, while `copiedSha256` hashes the sidecar file, so those two values are expected to differ. The evidence separately confirms the oracle hash stayed unchanged before native execution and through the run.

The native evidence supersedes the four extent failures from gate 002: gate 003 passes both undersized-extent cases at O0/O2, along with the direct scanner regressions. The earlier failures remain useful history and are not silently replaced.

## Report and scope review

`reports/153-owning-native-enums.md` accurately distinguishes payload-free enum support in the selected owning-stack LLVM backend from the legacy `LlvmAot` rejection. It also explicitly avoids comparative agent-reliability and throughput claims. `docs/CLOSED-ENUMS.md` and `.agentlang/native-enums-153/compiler/implementation.md` now reflect that backend boundary and the passing focused gates. `.agentlang/native-enums-153/native-review.md` has a final gate-003 addendum that supersedes its earlier pending note.

One sentence in the report is now stale: “Results and limitations will be recorded after implementation and validation” appears before the final results are recorded below it. It should be removed or changed to point to the completed results section. The surrounding acceptance plan and the statement that full Release validation remains pending are still accurate.

Coordinator follow-up: corrected that sentence to point to the focused results
below and explicitly retain the pending full Release boundary.

These artifacts establish correctness for the tested owning-stack paths and mailbox scenarios. They do not establish a performance advantage, a comparative agent-efficacy result, generalized remote-provider behavior, or full Release completion. The gate command skips package audit; it is not package-security evidence. Ordinary UBSan did not link with this MSVC target, while O0/O2 and trap-mode UBSan passed. Payload-carrying enums and native Option/Result layouts remain out of scope.

Coordinator final follow-up: the existing full Release process subsequently
exited zero. `validation-001.json` records 37 passing checks and zero failures;
its business-policy preflight records 98 checks and 30 runs, all passing. This
supersedes the pending full-Release boundary above without changing the scoped
performance, efficacy or sanitizer limitations.

# Native enums compiler slice

Implemented the owning-stack compiler path for verified payload-free enums.

- Enum nominal layouts are fixed 8-byte leaves. The existing nominal type ID identifies the enum; emitted layout descriptors use kind 6 and append the verified case count.
- The module manifest keeps `formatVersion: 1` and callback/module `abiVersion: 1`, and now states `layoutAbiVersion: 2` and `typeDescriptorSizeBytes: 36`. `sharedLayout.caseCount` is additive; the native layout ABI explicitly rejects incompatible descriptor bytes. The managed layout schema remains version 2.
- Host input measurement/encoding accepts only a matching `EnumValue(typeName, caseName)` in the frozen case table. Output decoding maps an in-range ordinal back to that representation and rejects malformed ordinals.
- The active stable-arena emitter writes verified case ordinals inline, lowers exhaustive matches to ordinal switches with a structured invalid-tag failure, and handles enums through ordinary equality, locals, calls, records, projections, and retained publication.
- The active native wrapper checks input count and pointers, bounds every declared input extent against the supplied byte length, and scans every exact input slice before copying inputs or entering the body. This also covers unused roots and nested enum fields.
- `emitFixedModule` remains inactive historical code; public compile paths route through `emitDynamicModule`, which handles fixed records and String-bearing dynamic records.
- Integration review found that `emitSub` writes its operand verbatim, so the wrapper's remaining-input-bytes operand must use the single LLVM sigil `%input.bytes`; the doubled sigil produced invalid `%%input.bytes` IR. The other `%%input.bytes` uses are F# interpolated strings and correctly emit one sigil.

Static validation performed: `git diff --check -- src/AgentLang.Llvm/OwningStackAot.fs` passed. The independent LLVM Release build completed with zero warnings and errors using isolated artifacts at `.agentlang/native-enums-153/compiler-build-001`. Subsequent focused native acceptance passed in `verification-c9929f1642a64de3b631349aead9f640`; mailbox integration, policy and real-I/O gates also passed as listed in report 153. Full local Release validation subsequently passed all 37 checks in `validation-001.json`.

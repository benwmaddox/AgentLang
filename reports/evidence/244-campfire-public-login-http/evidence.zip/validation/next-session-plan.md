# Next Campfire session milestone: logout

Read-only plan based on Rust reference `6dae2fd` and Rails submodule `90b330024dec3e757c79b6a7e6568f93da8e3148`. The checkout is on `feature/campfire-login-http-244` with the 244 work and other existing changes present; preserve them. No builds were run.

## Recommendation and scope boundary

Ship authenticated logout as the next independent application milestone, before first-run setup. Its core depends on the new session restore path and requires one typed session-delete operation plus explicit cookie-reset behavior. It does not depend on account provisioning.

The independently shippable core is `DELETE /session`: pass the existing auth, CSRF, and browser gates; delete the restored current session; reset encrypted session state; expire `session_token`; return `302 Location: /`. That completes server-side session revocation and the sign-out endpoint. It is a partial logout parity milestone until optional push-subscription removal, Cable disconnect, and a working root landing route are migrated.

Complete logout parity also removes `push_subscription_endpoint` for the current user, best-effort resets/disconnects that user's remote connections, and lands on the migrated root page. Current app transport has no push-subscription or Cable adapter, and no `/` route. Keep these as explicit gaps if excluded from the core; the endpoint may still redirect to `/`, but a user following that redirect will not yet reach a migrated welcome/home page.

## Reference behavior

Rails `SessionsController#destroy` removes the optional push subscription, terminates the current session, then redirects to root: `.agentlang/campfire-reference/reference/app/controllers/sessions_controller.rb:19-23,35-38`. `terminate_current_session` destroys `Current.session`, calls `reset_session`, removes the signed authentication cookie, and best-effort disconnects remote connections while logging failures: `reference/app/controllers/concerns/authentication.rb:70-80`. The route is `DELETE /session`: `reference/config/routes.rb:6-11`.

The Rust port matches this in `crates/campfire/src/controllers/sessions.rs:52-58` and `crates/campfire/src/concerns.rs:336-355`; row deletion is `crates/db/src/models/session.rs:118-121`. Existing Rust HTTP acceptance covers sign-out redirect, expired cookie, and the now-unauthenticated protected request at `crates/campfire/src/controllers/presenters/accounts/tests.rs:231-238`.

## Typed contracts and source ownership

- **Persistence/host owner:** In `applications/campfire/Authentication.Persistence/SqliteProvider.fs`, add `DeleteSession(SessionId): Result<unit, DbError>` that deletes only that session row. In `Authentication.Host/CampfireAuthenticationHost.fs`, register `campfire.sessions.destroy`, input `SessionId`, output `Result<Unit, DbError>`, effect `db.write`, and map it to the provider. Keep the operation bound to the typed host manifest. Add the targeted deletion case to `tests/AgentLang.Campfire.Authentication.Persistence.Tests/Program.fs`; extend `tests/AgentLang.Campfire.Authentication.Integration.Tests/Program.fs` if a real Flow-to-provider call needs coverage.
- **Flow policy/contracts owner:** Add a sign-out policy in `authentication.flow` that destroys the `RestoredSession.session.id` and propagates provider failure. Extend `http-types.flow` with `session-destroy` and an explicit signed-out response directive that means “clear auth token and reset encrypted session state.” In `http.flow`/`http-tests.flow`, route `session-destroy` through the normal protected auth path, then apply the existing forgery and browser checks before deletion. Keep the response distinct from `redirect-root`, which currently sets an alert flash.
- **HTTP adapter owner:** In `Http/Transport.fs`, map DELETE `/session` to the protected route and classify it as unsafe for forgery checks; it must use protected cookie parsing, not the public-login cookie path. In `Http/ResponseRenderer.fs` and `finalizeCookies` in `Transport.fs`, render root redirect without a flash and emit expiration for `session_token` plus a reset/clear for `_campfire_session`. Extend `tests/AgentLang.Campfire.Http.Tests/Program.fs` for the real loopback request. The host composition in that test is at lines 358-375; include the new operation through the auth host manifest/provider.

The existing Flow request route enum and response record are at `http-types.flow:1-70`; route mapping is at `Transport.fs:351-412`; response rendering is at `ResponseRenderer.fs:42-101`; cookie finalization is at `Transport.fs:248-299`. `authentication.flow` already restores an exact verified token to a `RestoredSession`, while `CampfireAuthenticationHost.fs:11-31,33-54,239-256` currently supports find/refresh/start but no delete.

## Acceptance and failure behavior

- Flow test: forged or invalid-origin DELETE returns 422 and never invokes `campfire.sessions.destroy`. Authentication reads may happen before forgery rejection, matching the existing restore-then-CSRF order; no deletion may happen.
- Flow/provider failure test: if session deletion returns `DbError`, respond 500 and do not emit a signed-out directive. The transport must not expire cookies or redirect as though sign-out succeeded.
- Persistence test: delete the target session only; its token no longer resolves after reopening, while the user and a second session remain.
- HTTP integration: with a valid signed token and same-origin `Origin`/`Sec-Fetch-Site`, DELETE `/session` returns 302 `/` and an expired `session_token` cookie. A subsequent protected GET with the old cookie redirects to `/session/new`; the database row is absent. Also assert an invalid CSRF request does not delete the session or emit cookie-expiration headers.
- Complete-parity tests, when those adapters/routes exist: supplied push endpoint is deleted only for the authenticated user; remote-connection reset failure is logged but does not fail sign-out; following `/` reaches the migrated root/welcome page.

## Validation commands (after implementation)

Run focused builds and tests, then the repository Campfire gate:

```powershell
dotnet build tests/AgentLang.Campfire.Authentication.Persistence.Tests/AgentLang.Campfire.Authentication.Persistence.Tests.fsproj --configuration Release -m:1 -nr:false
dotnet run --project tests/AgentLang.Campfire.Authentication.Persistence.Tests/AgentLang.Campfire.Authentication.Persistence.Tests.fsproj --configuration Release --no-build --no-restore
dotnet build tests/AgentLang.Campfire.Authentication.Integration.Tests/AgentLang.Campfire.Authentication.Integration.Tests.fsproj --configuration Release -m:1 -nr:false
dotnet run --project tests/AgentLang.Campfire.Authentication.Integration.Tests/AgentLang.Campfire.Authentication.Integration.Tests.fsproj --configuration Release --no-build --no-restore
dotnet build tests/AgentLang.Campfire.Http.Tests/AgentLang.Campfire.Http.Tests.fsproj --configuration Release -m:1 -nr:false
dotnet run --project tests/AgentLang.Campfire.Http.Tests/AgentLang.Campfire.Http.Tests.fsproj --configuration Release --no-build --no-restore
pwsh -NoProfile -File scripts/Verify-Campfire.ps1 -Configuration Release
```

Update `scripts/Verify-Campfire.ps1` source pins for changed/new Flow, adapter, and test files. No command above was run during this planning task.
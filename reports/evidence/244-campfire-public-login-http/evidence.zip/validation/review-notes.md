# Focused login review

Reviewed `applications/campfire/Http/LoginHost.fs`, `Transport.fs`, `ResponseRenderer.fs`, `http-login.flow`, and `http.flow` against the pinned Rust session controller and concerns code.

## Final transport review

- The route-aware cookie filter resolves the unused-cookie edge: within the existing total header/cookie size limits, public login decodes only `_campfire_session`; duplicate or malformed `session_token` and `last_room` values are ignored, while duplicate `_campfire_session` remains a 400 because login needs it for return-to state. Protected routes still decode and validate all three known cookies.
- Both POST routes now pre-read at most 65,537 bytes into a fixed-capacity `MemoryStream` before form parsing or provider invocation. Content-Length above 65,536 returns 413 before cookie parsing/body reads; unknown-length requests read through the 65,537th byte and return 413 before `buildRequest` and providers. Exactly 65,536 bytes reaches form parsing. The request body is rewound for parsing, then the original stream is restored in `finally`; the buffer is disposed after the action. This path does not use disk-backed form buffering.
- Cancellation is passed to `ReadAsync`; cancellation during pre-read propagates before replacing `Request.Body` or invoking providers. If cancellation/failure occurs during parsing or dispatch, the `finally` restores the original body.
- Small malformed forms map to 400, unsupported login media maps to 415, and oversized forms map to 413. Valid protected message forms are parsed from the rewound memory stream and continue through the existing dispatch path.
- I found no remaining issue in the reviewed cookie filtering or bounded body path. No builds or tests were run, and no source files were changed.

## Review corrections and confirmed behavior

- The absence of a hidden authenticity token is consistent with the pinned Rust adapter: `Ctx::verify_authenticity_token` explicitly uses Origin and Sec-Fetch-Site instead of per-request tokens (`crates/kit/src/ctx.rs:198-235`); the view helpers also document that pages carry no token.
- Login form normalization before Flow dispatch is intentional bounded transport work. The required order concerns policy gates, attempt counting, credential verification, and session effects.
- The login path routes around cookie restoration and bot authentication; session-new/create go directly through the forgery and browser checks. Attempt counting starts a non-sliding 180-second window, saturates at eleven, and bounds live keys at 4096.
- Return-to state is encrypted, preserved across a failed submit, consumed after successful login, and validated against the configured public authority before using the path/query. I found no open redirect in this path.
- Password is passed only to the sign-in call; the response renderer only reflects the email and HTML-encodes it. I found no password reflection or logging in the reviewed files.

## Correction

- The earlier flash-persistence finding was incorrect. The local `alert` string builds only the inline HTML; the returned tuple is `(contentType, body, None, None)`, so the outer `RenderedResponse.Alert` is `None` and `finalizeCookies` does not persist it. The failed-login response does not set a session cookie.

No source or tests were changed as part of this review.

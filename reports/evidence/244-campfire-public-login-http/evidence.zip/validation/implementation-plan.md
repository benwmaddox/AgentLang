# Public login milestone plan

Full migration remains the goal. Add real GET/HEAD /session/new and POST /session
using the qualified sign-in library. Preserve old room and message behavior.

Flow owns callback order, attempt threshold and login outcomes. A fixed provider
owns a bounded in-process attempt store (db.write); transport owns bounded form
normalization, fixed HTML, encrypted return-to mutation and signed cookies.

Ownership: Flow worker owns http types/policy/scoped tests/Application startup;
transport worker owns Transport/ResponseRenderer/Http fsproj; HTTP test worker
owns HTTP Program.fs; root owns LoginHost, rate tests, solution, verifier, reports
and evidence. Shared contracts were agreed before edits.

Acceptance: anonymous login bypasses restoration; bans/CSRF/browser checks precede
attempt counting and credentials; fixed ten-attempt three-minute window; failed
credentials never issue a session; signed cookie survives restart and authorizes
room access; encrypted return-to is consumed on success and preserved on failure;
redirect destination cannot leave the configured public authority; credential
values are absent from HTML and saved traces; unknown-length oversized forms
stop before providers; existing 150 assertions remain meaningful.

Validate focused clean Release builds and runtime/rate tests, then the combined
Campfire verifier with audit enabled/restored dependencies. Real HTTP tests run
only on ephemeral loopback with synthetic data. Preserve attempts and update
report/evidence before commit, merge and push. Full layout/assets/help contact,
other routes, live delivery and native runtime remain later migration work.

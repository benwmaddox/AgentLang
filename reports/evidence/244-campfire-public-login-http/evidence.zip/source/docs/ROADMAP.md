# Current delivery roadmap

## Active delivery priority: Campfire implementation

As of 2026-10-11, the primary deliverable is a complete Campfire migration in
this language. Add language and runtime features when the next application step
requires them. The earlier standalone efficacy studies remain evidence; new
reliability observations should come from building and maintaining the application.

The local references are pinned to `basecamp/once-campfire-rust` revision
`6dae2fd3c1a2dce61ca11beb731bcce2b42b67ad` and its Rails source at
`90b330024dec3e757c79b6a7e6568f93da8e3148`. Message administration policy,
session restoration, SQLite-backed message operations and a first authenticated
Kestrel path are implemented. Report 242 passes its focused local gate for
`GET /rooms/:id` and `POST /rooms/:room_id/messages`; the route inventory still
contains 177 reference rows, and these two handlers remain in progress pending
broader compatibility evidence. Do not read the two tested routes as a migration
percentage.

Next, implement logout and first-run account setup, complete compatible
rendering, then implement
live delivery over the Campfire protocol. Continue through the remaining route,
asset, data-migration, background-job and deployment requirements. Preserve the
reference's data, cookie and protocol contracts; record deliberate differences
explicitly. The full migration remains the objective.

Application code belongs in `applications/campfire/`. Keep business decisions
in inspectable language functions and use narrow trusted adapters for storage,
transport and established cryptography. Pure policy tests are an initial component,
not proof of a working server. Subsequent gates must exercise real persistence,
HTTP/WebSockets, cancellation and sustained native operation. The full migration
remains the objective after the first slice passes.

The [sign-in foundation](../reports/243-campfire-sign-in-foundation.md) now passes
strict library qualification and real SQLite/bcrypt checks. New Campfire
dictionaries expose it as a discoverable library. [Public login HTTP](../reports/244-campfire-public-login-http.md)
now passes 302 focused assertions, including bounded forms, fixed-window rate
limiting, cookie issuance and return-to handling. Full login layout/asset parity
remains outstanding.

The inherited-test edit guard is integrated. Room/message and session-restoration
functions now exercise real SQLite through typed host adapters. Cookie compatibility,
authentication storage, library reload and the resolved regression gates pass local
component tests. Authenticated HTTP room listing/message creation and public login
have component validation. Continue session/setup, rendering and live delivery.
Avoid unrelated language research during migration.

Updated 2026-10-12. This is a delivery order and status map, not a replacement
for the [PRD](PRD.md). Reliable agent edits, discovery and reuse of accumulated
typed vocabulary remain the primary research question. Runtime performance and
development cost are separate measurements.

Product target clarification: approach F# in data/structural correctness with
C-family source familiarity; use F# as the primary throughput/RAM baseline.
Higher throughput may justify a modest, predeclared whole-process memory
increase. Use Erlang/OTP as an isolation reference without requiring the full
OTP feature set. Arenas are the general allocation model for language-managed
dynamic values for now. Request/response processing is the first evaluation
workload, with frequent cleanup and separately retained mailbox/I/O state.
Choose arena lifetimes, placement and reuse policies against those product
goals; minimum RAM alone is not the success criterion.
See the [PRD comparison roles](PRD.md#product-targets-and-comparison-roles) and
[runtime evaluation](ASYNC-ARENA-EVALUATION.md#product-baseline-and-requestresponse-workload).

This remains a prototype: breaking changes are expected. Favor one current
design over compatibility layers and routine version proliferation. Update
affected code, examples and tests together; retain historical experiment
evidence without requiring the current runtime to support old contracts.

The current authoring change uses dotted qualified calls, newline separators,
and unbraced single-expression match arms in Flow/2. See the
[current syntax guide](CURRENT-SYNTAX.md) and
[implementation and validation report](../reports/155-dot-calls-and-newline-syntax.md).
This is a usability revision; it does not establish an agent-efficacy advantage.

Priority update: an efficacy report comes first; efficient LLVM execution with
interpreter/JIT/AOT and a chosen memory design comes second. See
[report 101](../reports/101-approach-efficacy-review.md). Flow/2 is complete (report 100), and the guided repair comparison (report 102)
is complete: all three conditions repaired the defect, with no reliability
superiority established. Native conformance and arena selection should
not wait for every optional feature or proof of a comparative advantage.

## 1. Validate reliability beyond easy composition

The [fresh comparison result](../reports/222-typed-batch-fresh-results.md) closes
with both implementations passing nine behavior cases, but only F# preserving
the full assigned edit scope. AgentLang changes one inherited fixture and its
raw scorer also exposes a separate punctuation-sensitive type gate. No comparative
reliability advantage is established. The
[inspection and accounting update](../reports/223-semantic-type-inspection-and-test-counts.md)
adds checked semantic type metadata and explicit test execution summaries.
Future contract checks should consume that metadata; historical frozen oracles
remain unchanged. Retain explicit fixture preservation review and held-out
acceptance tests alongside library coverage.
The [prior efficacy decision](../reports/219-efficacy-after-typed-batch-maintenance.md)
records correct preserved typed-contract maintenance in both continuation seeds,
with assisted/failed finalization kept separate from source correctness. It called
for the fresh retained/F# comparison now closed in report 222, with transport
controls disclosed before dispatch. No comparative reliability
advantage is established. The [comparison readiness checkpoint](../reports/220-typed-batch-comparison-readiness.md)
now accepts corrected language/F# controls and equivalent inherited scenarios.
The [fresh comparison protocol](../reports/221-typed-batch-fresh-comparison.md)
is frozen after a preserved launcher setup failure and corrected broker smoke.
Corrected fresh participant outcomes are now closed in report 222.
The [prior decision](../reports/215-efficacy-after-paired-vocabulary-pilot.md)
preserves the earlier negative helper-creation and preservation findings.
The [previous handoff checkpoint](../reports/212-efficacy-after-public-vocabulary-reuse.md)
records a successful later-agent handoff through creator-authored public functions.
Retention benefit and comparative reliability remain unproven. The
[previous decision](../reports/203-efficacy-decision-after-organic-creation.md)
records the organic creator without an eligible optional helper and no successor.
A separately recorded [fresh replication](../reports/210-organic-reuse-replication.md)
of the organic creator opportunity closes with another correct creator: 66/66
independent observations, 145/145 tests and preserved inherited evidence, but no
eligible optional helper. Its frozen stop rule prevents successor dispatch.
The two requested functions still constitute new creator-authored vocabulary;
their later usefulness needs a separate held-out public-function reuse study.
Do not confuse that broader endpoint with spontaneous optional-helper creation.
The [separate public-vocabulary reuse study](../reports/211-public-vocabulary-reuse.md)
pins the accepted 210 creator project and predeclares its two renewal functions
as targets for a fresh developer's held-out batch task. The developer discovers
and production-reuses both through a new batch helper. Independent scoring passes
66/66 original observations, 9/9 held-out batch observations, 152/152 tests and
39 example owners, preserving inherited evidence and both target definitions.
This demonstrates task-required public vocabulary reuse; spontaneous helper
creation and a causal or comparative advantage remain unproven. Next estimate
retention benefit with a matched reset/retained comparison, keeping behavior,
preservation, discovery and production paths as separate endpoints.
The [fresh paired pilot](../reports/213-paired-vocabulary-availability.md) closes
that minimal contrast: both fresh participants pass nine independent cases,
137 common tests and 39 example owners, with inherited evidence preserved.
Retained discovers and production-reuses both renewal functions, using 31 broker
exchanges versus reset's 39. This is encouraging reuse and per-instance traffic
evidence, not a reliability rate, token saving or causal speedup claim. Trial 211
is historical evidence, not its matched retained arm. Next use another small
held-out task to test harder edits, with conventional comparisons and repeated
outcomes required before claiming superior reliability.
The [typed batch failure maintenance study](../experiments/AgentLang.SubagentTrials/typed-batch-failure-216/PLAN.md)
has [reviewed passing preflight](../reports/216-typed-batch-failure-preflight.md):
structured first-failure index/ID/cause, preserved success and
input state, and explicitly reviewed inherited test adaptations. It uses both
accepted terminal 213 projects as unequal continuation seeds. Correct controls
pass 9/9 in both arms and 66 retained regressions; runtime mutations calibrate at
6/9 and 8/9. The [fresh continuation trial](../reports/217-typed-batch-failure-maintenance.md)
closes with correct preserved edits in both: 9/9 migration cases each, 152 retained
tests, 150 reset tests and 66 retained creator regressions. Retained closure needed
a disclosed lifecycle-only instruction; reset sent Ctrl+C and fails its normal
finalization gate. These unequal continuation seeds do not establish a causal
retention effect or reliability superiority. The [publication-help improvement](../reports/218-atomic-record-publication-help.md)
now explains same-session group commit and complete record CAS metadata, with
44 local test groups passing and unchanged validation gates. This post-trial
change adds no efficacy outcome. Disclose transport controls/operation limits in
future trial bootstrap instructions; keep those controls outside language semantics.
The [prior decision](../reports/199-efficacy-decision-after-reference-maintenance.md)
covers the closed typed-reference cohort and its representation supplement in
reports 196 and 197. The [previous checkpoint](../reports/182-efficacy-decision-checkpoint.md)
covers repeated maintenance through 179 and separates native conformance and
activation work through 181 from agent outcomes.
It retains the conclusion of the
[checkpoint through 176](../reports/177-reliability-and-vocabulary-checkpoint.md):
discovery and reuse are demonstrated on
bounded tasks; a comparative reliability advantage remains unproven. Passing
library checks have coexisted with lost assertions and changed examples. This
motivated the predeclared repeated repair/typed-result maintenance sequence
below, using existing brokers and separate behavioral/collateral criteria with
explicit fixture-change exceptions. Avoid more easy composition variants or
new harness infrastructure. Native LLVM/arena conformance remains the secondary
track.

[Report 179](../reports/179-preview-repair-and-record-migration.md) completes
the frozen repair and typed-result migration sequence with two external
Luna/max participants per condition. All six sequences pass each 37-case
projection and preserve inherited evidence. All AgentLang stages publish through
the library gate; all F# stages finish local validation. All brokers finalize
normally. No comparative reliability advantage is
observed; F# uses fewer broker exchanges, and protocol duration/volume do not
measure native service performance or provider tokens. Both retained first-stage
launches shorten their allowlists; derived proposed-state assertions also have
documented weaknesses. Close this bounded sequence and resume native LLVM/arena
conformance; preserve independent behavior and collateral checks in future
maintenance research. Investigate strict-coverage pressure around compiler-proven
unreachable paths or reusable typed error construction without relaxing this
study's gate.

[Report 185](../reports/185-typed-reference-maintenance-results.md) records the
first participant in the next maintenance task. The retained participant
preserved the prior project but could not migrate its persisted record fields:
the frozen authoring routes reject same-name type replacement. The independent
oracle passed 13 of 18 cases; five replay cases failed. This single run is an
environment capability-gap finding, not a balanced efficacy comparison. The
other five participants were not dispatched, and this cohort is closed. The
[atomic type evolution contract](TYPE-EVOLUTION.md) defines the prerequisite.
[Report 188](../reports/188-atomic-record-evolution.md) accepts its implementation
after the full local validation gate. [Report 189](../reports/189-persisted-migration-readiness.md)
checks migration of the original persisted seed through the public interface.
The new [six-participant cohort](../reports/190-typed-reference-maintenance-cohort.md)
is frozen against that accepted runtime; do not pool its results with 185.
[Interim report 191](../reports/191-typed-reference-maintenance-interim.md) records
the first retained participant passing 18 independent cases while preserving
all inherited tests and examples, with unresolved history queries and
near-budget protocol use. [Report 192](../reports/192-reset-reference-maintenance-interim.md)
records a reset participant whose record representation cannot be constructed
by the frozen scalar-only checker: none of its 18 behavior cases executed.
[Report 193](../reports/193-conventional-reference-maintenance-interim.md) records
both F# participants passing 18 cases and preserving inherited assertions.
[Report 195](../reports/195-second-reset-reference-maintenance-interim.md) records
the second reset participant passing 18 cases and preserving inherited evidence.
[Report 196](../reports/196-typed-reference-maintenance-cohort-results.md) closes
the original six-participant cohort. Five candidates pass the original 18-case
checker; reset-1 remains a representation/setup incompatibility. All inherited
tests are preserved, but retained-2 materially rewrites its three examples,
including a replaced fixture. Passing library publication does not establish
evidence preservation. Original snapshots, scores and audits are sealed.
[Report 197](../reports/197-typed-reference-record-supplement.md) closes the
separately labelled representation-adapted check: reset-1 passes the same 18
model cases using its one-field record constructor, with nominal negative
controls and unchanged participant files. Keep that supplemental result
separate from the original setup failure; it does not revise the frozen score.
Assess behavior, evidence preservation, library qualification, finalization and
recovery separately; this pilot does not establish a comparative vocabulary
advantage. [Report 194](../reports/194-native-bool-implementation-plan.md) plans
the next native slice after cohort and supplemental-check closure: Bool-backed
nominal/refined values with canonical encoding admission, unchanged ABIs and
fresh ordinary/mailbox conformance checks.
[Report 198](../reports/198-native-bool-admission.md) accepts this slice after
fresh focused checks, full LLVM/native/mailbox regressions and all 37 local
Release gates. Canonical Bool admission checks full owner-bounded eight-byte
payloads before execution; ABIs are unchanged. Retained preparation failures
and receipt gaps remain explicit. This adds no agent efficacy or throughput
result.


[Report 200](../reports/200-organic-vocabulary-reuse.md) closes the organic
creation pilot after one creator passes all 66 independent observations,
145 tests, examples for 39 owners, library gates and inherited-evidence
preservation. It reuses existing vocabulary but duplicates the renewal bodies
without creating an eligible shared helper. The frozen no-helper stop rule
prevents successor dispatch. Organic accumulation remains unproven; this is
not a comparative reliability result. Do not manufacture or prompt a helper
under the same trial identity. Resume bounded LLVM/arena conformance while
retaining this negative creation endpoint for later research design.

[Report 201](../reports/201-filesystem-control-plane-boundary.md) addresses a
confirmed real-file scope gap: language writes could corrupt the host dictionary
pointer with a valid `fs.write` grant. Host dictionary metadata is now reserved
from language I/O. Storage preservation and normal project file access pass
249 focused assertions and all 37 full local Release checks. This bounded
protection does not establish a hostile-filesystem
sandbox or revise the closed agent trial's pinned runtime.

The [accepted Unit slice](../reports/202-native-unit-canonicality-plan.md)
closes a source-evidenced Unit admission mismatch before widening types: the
managed codec requires zero bytes while the raw C scanner accepts other bits.
Require the same canonical zero after existing owner-bounded readability checks,
retaining active/inactive sum behavior and unchanged layouts. The implemented
slice passes the 50-check native verifier, 52/704 C scanner cases/checks at O0,
O2 and UBSan trap mode, and 777 full LLVM assertions. Default build and normal
UBSan-link limitations remain recorded; the accepted full LLVM build is serial
and audit-disabled. The [reviewed Float plan](../reports/205-native-float-implementation-plan.md)
defines finite numeric support for owning AOT, typed aggregate equality, complete
diagnostic parity and the coordinated ABI audit. [Implementation 206](../reports/206-native-float-conformance.md)
is accepted: finite interpreter inputs pass 155 assertions; owning Float passes
176 focused assertions, the full LLVM suite passes 950, and the 50-check value-stack
gate and owning mailbox integration pass with the coordinated ABI changes. Legacy graph AOT and native Float
formatting remain deferred.
[Findings 224](../reports/224-native-float-format-findings.md) records the .NET
formatter counterexample and failed wide-function test. The PRD now selects
canonical shortest-roundtrip Float text across backends; [report 229](../reports/229-canonical-float-text.md)
accepts the implementation, including exact IR JSON transport: 37 full-suite
checks and 1,008 native assertions pass with package auditing enabled. Retain the original failure evidence;
do not reproduce the host bug or weaken the independent oracle to claim parity.

Before general or untrusted native execution, enforce a post-codegen thread-stack
budget covering spills, calls, helper frames and interop. Existing metadata
counts explicit LLVM `alloca` storage only. A 256-value candidate corpus crashed
the in-process test host; smaller batches preserve coverage, not a safety proof.
Use a worker-process crash boundary for untrusted native work until the budget
is validated. This is separate from arena and mailbox storage sizing.
[Report 225](../reports/225-native-machine-frame-screening.md) implements a
local first step: entry-block scratch allocation and fresh static compiler
receipts with a 64 KiB individual-frame limit. This does not establish a
combined call-chain budget or replace process isolation.

[Report 204](../reports/204-git-control-plane-boundary.md) extends the real-file
boundary to root Git metadata, including pointer files. A fresh solution build,
305 CLI assertions and 2,191 runtime assertions pass. This bounded path policy
does not protect nested repositories or hostile concurrent filesystem changes.

[Report 178](../reports/178-preview-defect-control-calibration.md) calibrates the
first defect-repair stage: three correct controls pass 37 independent cases,
and three faulty controls fail the same eight cases despite passing their saved
tests. Library coverage rejects the untested branch, then accepts it when a
deliberately mistaken expectation covers it. No experimental participants have
been dispatched at that checkpoint. The follow-up task, prompts, preservation
exceptions and controls were frozen for the completed sequence in report 179.

[Report 149](../reports/149-validated-window-reuse.md) and
[report 150](../reports/150-shared-rule-maintenance.md) complete the validated
billing composition/maintenance sequence. Both environments reuse the API and
pass the respective 18 and 48 hidden cases; no language reliability lead is
established. The [earlier efficacy checkpoint](../reports/151-efficacy-checkpoint.md)
closes this microtrial sequence. Next, address the demonstrated empty-occupancy
domain gap using validated nonempty periods and explicit absence, while retaining
independent behavior checks and library gates. Resume native conformance as a
separate secondary track. Keep the mailbox model open: specialized typed
mailboxes/dataflow boundaries are a candidate, not a full actor-framework decision.
Smalltalk-inspired live inspection and scoped dictionary replacement are separate
from adopting an actor object model. Evaluate whether awaiting I/O keeps a mailbox
logically occupied separately from whether its transient arena is retained.
The occupied-period integration and its validation are tracked in
[report 152](../reports/152-occupied-period-domain.md); do not count this
coordinator-designed domain improvement as a new independent agent efficacy trial.

[Report 163](../reports/163-atomic-subscription-handoff.md) completes the next
fresh composition comparison. Both agents discover/reuse the retained
subscription transitions and pass 33 independent cases, including 26 common
valid-reference cases and seven separately classified orphan-reference checks.
AgentLang publishes one library function and finalizes its task; F# also succeeds
with a shorter broker session. Existing implementations are preserved in both
arms. This supports feasibility and voluntary reuse on this task, not a
comparative correctness advantage. Next efficacy work should change or maintain
an existing abstraction and callers under restricted context. Improve returned
Result test examples, keep independent behavior checks and source-access parity,
and avoid more easy composition variants. LLVM/arena work remains secondary.

[Report 171](../reports/171-preview-vocabulary-retention.md) closes a small
retained-versus-reset abstraction probe. Both fresh agents pass 33 independent
cases, preserve all prior definitions/tests, and pass complete saved suites
(141/145 tests respectively). The retained agent discovers the earlier handoff
and writes a smaller wrapper; no reliability lead or context-budget advantage
is established. Correct the shared help-primer request for future trials. Next
efficacy work should stress shared-rule/caller maintenance rather than repeat
this easy composition task. Native refinement work remains a separate track.

[Report 173](../reports/173-handoff-window-maintenance.md) completes the bounded
half-open handoff maintenance comparison in ABBA order. Two fresh language
participants and two fresh F# participants each pass 144 independent outcomes.
Language submissions retain all inherited tests and pass 155/155 saved suites;
F# submissions retain assertions with one disclosed expiry-overlap fixture
adjustment. All reuse the shared policy; none creates a new domain helper.
Different seed suites and supplied patch guards prevent a causal reliability
interpretation. Close this boundary task without a comparative advantage claim.

[Report 175](../reports/175-email-fifo-batch.md) completes that stateful partial-
failure trial: both fresh agents pass six independent FIFO batching cases and
reuse an existing single-message operation. AgentLang qualifies its library
closure and passes 200 saved tests, but rewrites a helper and changes an
inherited example's observable output. F# retains original production functions
and assertions. No comparative reliability advantage is established. Keep the
raw preservation failures separate from behavior and coverage. Address observed
qualified-call and attachment conversion friction; make inherited example output
an explicit preservation contract before another distinct efficacy task. Close
this batch task without more easy variants or new harness infrastructure.

[Report 176](../reports/176-retained-attachment-source-versions.md) addresses that
observed editing friction: retained tests/examples keep their exact source
format across owner revisions, and Flow/2 accepts leading-dot container
constructors and qualified static callbacks. Focused suites and an isolated
replay of the original blocked request pass, including unchanged example output
and all 191 saved tests after fresh reload. All 37 full local checks pass.
This engineering replay does not establish a new agent reliability advantage.
The next efficacy task should exercise maintenance of existing vocabulary with
explicit collateral preservation, rather than repeat this batching task.

[Report 164](../reports/164-result-test-guidance.md) completes the returned-Result
help improvement with executable examples that qualify as library vocabulary.
Fresh participants have now used the updated help. The coordinated signature
staging implementation is described in
[report 165](../reports/165-atomic-function-replacement-staging.md): it checks the
complete proposed dictionary while preserving identities, exact revision checks,
attached cases and publication gates. Focused runtime validation and all 37 full
local Release checks pass. The bounded comparison changes the actual
retained handoff abstraction and two disclosed coordinator-created callers,
with independent dry-run behavior checks in both environments.
[Report 166](../reports/166-handoff-signature-maintenance-agent-pair.md) records
the completed fresh pair: both saved implementations pass 132 independent checks.
The language submission passes all 149 attached tests and library gates, but
weakens two prior test scenarios; F# preserves its prior assertions. This is
maintenance feasibility with no comparative reliability lead. Improve test-body
discoverability before extending this sequence; preserve the distinction between
coverage, behavior and test evidence. Reports and verified evidence archives are saved.

[Report 167](../reports/167-test-source-inspection.md) adds current test-body
inspection to `tests`, including enclosing test-file source and scoped dependency
replacements. Staged and temporary cases are inspectable before publication;
queries do not execute tests or change coverage. Focused runtime and acceptance
validation and all 37 full local checks pass; evidence is archived. A disposable
copy of the actual maintenance seed exposes all five prior handoff cases without
changing files or executing tests. This addresses demonstrated
discovery friction, not a demonstrated cause of lost assertions.
[Report 168](../reports/168-test-source-inspection-agent-probe.md) completes one
fresh follow-up: the agent discovers the source view and passes 132 independent
checks and 150 attached tests, but still drops two prior pre-state assertions.
Close this bounded probe without a comparative reliability claim. Resume native
semantic conformance and arena work; keep collateral preservation explicit in
future held-out efficacy tasks.

[Report 153](../reports/153-owning-native-enums.md) implements closed,
payload-free enums in `OwningStackAot`, using inline values and the selected
stable arena policy. Focused O0/O2 conformance, malformed-input rejection and
mailbox/real-I/O gates pass, including ignored inputs and nested record fields;
all 37 full local Release checks also pass. Layout ABI 2 adds the explicit enum
case count. The tests exposed and now cover a short-input scanner status defect.
This remains separate from choosing actor versus specialized-mailbox semantics;
Option/Result native payload layouts remain subsequent work.

[Report 160](../reports/160-native-option-result.md) tracks that implementation
with focused conformance validated: inline Option/Result payloads, layout ABI 3,
conservative compiler rewinds and isolated malformed-input checks. The full LLVM
regression suite, owning sum parity, mailbox integration/policy and local I/O
regressions and all 37 full Release checks pass. A coherent malformed
None descriptor exposed a missing sentinel rule,
now repaired with before/after evidence. This engineering milestone does not
change the efficacy conclusions below or select the final mailbox memory policy.

[Report 169](../reports/169-native-mailbox-sum-lifecycle.md) tracks the bounded
mailbox integration of nominal Option/Result payloads under RETURN and
KEEP_ASSOCIATED. It exercises real publication/import/suspension/resume APIs,
ordinary helper matches, Error-state re-entry, failure preservation and retry,
and independent serialized-byte/copy oracles. This closes a gap between standalone
sum conformance and the existing String mailbox fixture; it does not select a
memory policy or establish service throughput. Keep native type expansion and
JIT/release work separate from held-out agent maintenance experiments.

[Report 170](../reports/170-native-nominal-int.md) completes unvalidated nominal
Int identity in the selected owning backend. Exact host identities and frozen
generated targets are checked; wrap/unwrap preserves payload and owner range
without copying. The 521-assertion LLVM suite, 94 independent nominal cases at
O0/O2, existing mailbox regressions and all 37 full local Release checks pass.
This adds no new agent-efficacy or throughput result. The
[native typing plan](NATIVE-NOMINALS-IMPLEMENTATION.md) retains bounded
predicate-bearing Int refinements before extending String/Email support. This is
a delivery order, not a weakening of the strong-type requirement. Unsupported
validators must remain explicit errors; preserve a coherent baseline for each gate.

[Report 172](../reports/172-native-refined-int.md) delivers the ordinary owning
Int-backed refinement slice with frozen validator identity, constructor checks
and recursive raw host-input validation before entry execution. Fresh gates
pass: 595 LLVM assertions, 44 native checks, 1,587 mailbox checks and all 37 full
local Release checks. Refined mailbox layouts remain rejected until that boundary
has independent coverage. The bounded validated String slice is tracked below;
general Email validation remains later work. This engineering milestone adds no
agent-efficacy or throughput result.

[Report 174](../reports/174-native-refined-string.md) extends ordinary owning
compilation to validated String-backed nominal values. Exact frozen predicates
run at construction and raw external entry over active nested payloads;
wrap/unwrap preserves owner ranges without payload copying. Its scope and gate
status are recorded in the report. Refined mailbox ingress, general Email
validation, JIT and memory-policy selection remain separate work. This adds no
agent-efficacy or service-throughput claim.

[Report 180](../reports/180-native-refined-mailbox.md) completes refined
Int/String admission at owning mailbox ingress. Recursive active-payload checks
run before handlers; private associated-root resumes retain their existing
boundary. Controller APIs, effects and ABI/layout versions are unchanged.
Direct raw callbacks and real text-controller lifecycles pass O0/O2 with all
three host profiles and both arena policies: 2,255 checks, including 668 refined
checks, plus all 37 full local Release checks. The report retains the failed
first run and disclosed diagnostic/copy oracle corrections. This is native
conformance, with no new efficacy, throughput or security-certification claim.

A development-load follow-up should measure fresh project activation separately
from warm request latency. Report 169 records similar 23â€“25-second fresh CLI
session times across very different request counts and a static-review candidate:
the manifest loader currently compiles its snapshot twice. Consider reusing the
already-validated immutable snapshot before adding caches; retain source/manifest
validation, legacy loading, test-overlay identity and durable-library requalification.
Measure before making a speed claim or skipping any validation.

[Report 181](../reports/181-validated-snapshot-reuse.md) tracks that bounded
refactor: activation and named restore reuse the exact already-validated runtime
snapshot, preserving library requalification and all storage checks. Focused
runtime tests, independent source review and all 37 full local Release checks
pass. Three fresh-process samples per build show no clear startup
improvement (median 11.513 seconds before, 11.615 after); all responses and
project bytes match. Profile activation phases before pursuing further
optimization. This does not add a comparative agent-efficacy result.

[Report 183](../reports/183-native-nominal-string.md) completes the bounded
native typing slice: String-backed nominal wrappers with no predicate use the
existing UTF-16 layout while retaining distinct type identities and owner ranges.
Wrap/unwrap introduces no payload copy. The full local gate passed 37/37;
focused LLVM, independent native and mailbox regression gates also passed.
The raw mailbox callback case does not establish a complete nominal-String
controller lifecycle, a memory-policy choice or comparative agent reliability.

[Report 161](../reports/161-real-files-and-test-isolation.md) tracks real
project-rooted filesystem execution and automatic virtual providers for attached
tests. Focused runtime, CLI and broker checks and all 37 full local Release checks
pass. [Report 162](../reports/162-test-file-dependency-overlays.md) tracks the
source-defined test-file replacement implementation. Focused parser, source,
interpreter, storage, runtime and CLI checks and all 37 full local Release checks
pass. Complete shared source context survives reload and semantic edits;
nested calls and callbacks use typed temporary overlays, with fake execution
excluded from original-function library coverage. This is distinct from provider
simulation. It does not add a new agent-efficacy result.

[Report 154](../reports/154-provider-state-assertion-probe.md) tests an I/O repair
with a fresh agent. Its submission passes three independent cases; its own added
known-path state and exact effect-count assertions reject wrong destination,
wrong contents and redundant writes. This is one guided usability result using
the existing core, not a comparative reliability or retention result. Keep
independent behavior checks: the weak starting test also met library coverage.

[Report 156](../reports/156-state-sensitive-io-maintenance.md) completes a fresh
matched state-sensitive I/O maintenance pair. Both saved implementations pass
nine independent cases; neither reuses the two-operation publisher helper.
AgentLang completes library publication and task commit, with full body/branch
and enum-return coverage. F# participant validation is blocked by NuGet audit
availability; separate coordinator validation passes. No reliability or reuse
advantage is established. Before another comparison, pin offline validation and
address observed enum/test-constructor and UTF-8 transport friction. Keep the
deferred broad retention study deferred; continue native Option/Result
conformance as the separate secondary track.

[Report 157](../reports/157-audit-independent-validation-and-enum-help.md) fixes
vulnerability-feed dependence in conventional validation and adds executable
Flow/2 enum/library-test help. Focused conventional, runtime, discovery and
harness checks pass. This is a tooling follow-up, not another participant trial;
UTF-8 transport friction remains separate. Original report-156 outcomes remain
unchanged.

[Report 158](../reports/158-utf8-trial-transport.md) addresses the UTF-8 transport
friction with explicit broker/CLI encoding and exact-value regression checks.
This removes a known comparison confound; it is not a new agent trial and does
not change report 156's findings. Continue with a bounded efficacy comparison
using the corrected tooling; keep broad retention preparation deferred.

[Report 159](../reports/159-retained-io-vocabulary-follow-on.md) completes that
follow-on. Both participants pass twelve independent publication/mirroring
scenarios. F# reuses the retained safe publisher; AgentLang inspects and tests
it but duplicates its logic. Library coverage is complete, yet voluntary reuse
does not follow. Four frozen control-output reports were compacted after freeze;
the report records that provenance loss separately from unchanged oracle code
and passing post-dispatch controls. Close this small I/O sequence and continue
native Option/Result conformance; do not collect more easy variants or resume
the deferred broad retention preparation.

The interpreter, typed semantic IR, dictionary, task transactions, introspection,
Flow/1 authoring and existing library coverage gates are implemented. Earlier
external-agent comparisons observed reuse; they did not establish a general
reliability or efficiency advantage.

The matched retention study has four of twelve actor attempts recorded. R01
and R03 passed independent acceptance, R02 failed independent behavior, and
R04 was blocked before independent behavior by a verifier bug. See
[the trial plan](VOCABULARY-RETENTION-TRIAL-PLAN.md) and
[the original R04 report](../reports/089-retained-discount-harness-blocked.md).

Separate scratch scoring now passed all 54 independent R04/S07 cases and
confirmed retained-helper reuse and preservation of prior definitions. See
[the supplemental result](../reports/090-retained-discount-supplemental-scoring.md).
This does not repair the original blocked trial or establish a retention benefit.

Next actions:

1. The quick preliminary comparison is complete: all four fresh actors passed
   54 independent S07 cases, starting definitions were preserved, and retained
   helper reuse was observed. Retained made more runtime calls than the language
   controls; F# was equally correct. See [report 099](../reports/099-quick-agent-comparison.md)
   for metadata omissions, fixture friction and limits. This is feasibility
   evidence, not a demonstrated retention advantage.
2. The guided repair comparison is complete (report 102). Proceed with the
   accepted native architecture (report 103) while research continues. Preserve original 003
   on hold and the unfinished 004 runners as unvalidated drafts. The twelve-cell
   repaired study is deferred by the user's instruction to compare sooner;
   its prior freeze requirements still apply if that study is resumed.

3. The location-unhinted repair comparison is complete ([report 109](../reports/109-location-unhinted-repair.md)):
   all three fresh actors pass 54/54 target cases. Both language conditions
   preserve vocabulary; F# also fills two unfinished pricing helpers. This
   supports discovery/repair feasibility, not comparative superiority. Next
   bounded research should use an unfamiliar rule/refactor, current Flow/2,
   equivalent implemented helper topology and independent expected values.
   Avoid repeatedly retesting this one pricing defect or expanding the harness.

4. The subsequent stateful matched-pair repair is complete
   ([report 125](../reports/125-matched-pair-repair.md)): six fresh agents each
   pass twelve independent scenarios. Both retained Flow agents and both F#
   agents reuse the existing helper, and all six final test suites detect the
   two planned regressions. One Flow agent omits task finalization. This supports
   discoverable reuse and enforced publication gates, but still establishes no
   comparative reliability advantage. Further agent trials should target an
   unresolved failure mode or harder vocabulary discovery, rather than repeat
   this small repair. Native storage conformance is separate evidence and must
   not be reported as improved agent efficacy.

5. The R09-inspired payment-summary comparison is complete
   ([report 135](../reports/135-r09-shared-summary-comparison.md)); its accepted
   agent-created seed is documented in [report 134](../reports/134-r09-discovery-study.md).
   All six participants passed thirteen public behavior scenarios, but only the
   two F# participants and the second retained participant met frozen full
   acceptance. The other outcomes separate workflow completion, a private
   helper-signature constraint omitted from the task, and an incomplete shared
   refactor. This small study establishes no comparative reliability advantage.
   Default help now exposes existing compact inventory, targeted search and
   bounded context ([report 136](../reports/136-discovery-help-exposure.md)).
   A fresh guided composition task now passes 14/14 independent cases and
   171/171 project tests, with inherited definitions preserved and actual helper
   reuse ([report 137](../reports/137-guided-discovery-composition.md)). It has
   no old-help or F# control and establishes no comparative improvement. Do not
   repeat this case; the next comparative study must target an unresolved
   reliability failure rather than collect more feasibility wins. Dependency reachability
   is supporting evidence, not proof that duplicated logic has been removed.
   Native runtime throughput remains separate evidence.

6. Shared payment maintenance is complete ([report 141](../reports/141-paid-invoice-maintenance.md)):
   all four participants passed independent behavior and preserved shared structure.
   The strict new-test criterion was unnecessarily prescriptive; retain its recorded
   failures, but assess resulting regression protection in subsequent work. Library
   dependency qualification is now enforced ([report 142](../reports/142-library-dependency-qualification.md));
   its guided helper-test probe establishes local qualification, not an additional
   project-wide defect detection benefit. The reachable subscription-overlap
   comparison ([report 143](../reports/143-subscription-overlap-comparison.md)) is
   complete: one language submission passes 18/19 cases, the other language
   submission and both F# submissions pass 19/19. All own suites and compiled
   boundary mutation checks pass. Complete library coverage did not expose the
   missing empty-interval guard. No language reliability advantage is established.
   A bounded follow-up can compare discovery/reuse of a validated nonempty-period
   abstraction in both environments; do not add mailbox infrastructure as a prerequisite.
   The existing-core prototype is validated in [report 144](../reports/144-nonempty-interval-prototype.md):
   both implementations pass a shared 125-case bounded grid. Later-agent adoption
   and subscription/Instant integration remain untested.
   [Report 145](../reports/145-rental-vocabulary-reuse.md) completes the four-cell
   rental query comparison: all submissions pass 17/17 independent cases and
   their own suites. Neither retained-start agent calls the interval helper;
   both retained agents inspect helper details but use direct arithmetic. No
   reliability or retained-vocabulary advantage is established by this task.
   Both language queries qualify as libraries; validated Rental-returning
   fixture builders remain project-level because finite-projection qualification
   is unsupported. Keep that limit explicit. Further efficacy work should test
   retained domain rules that fit later tasks and improve conventional broker
   discoverability before comparing tool counts; no new mailbox infrastructure
   is required for this research.
   [Report 146](../reports/146-conventional-project-discovery.md) adds conventional
   `inspect()` discovery with bounded file paths and typed operation schemas.
   Focused suites and host inspection-budget checks pass; use the new bootstrap
   in future frozen trials, without revising historical interaction counts or
   claiming an unmeasured reduction in agent errors.
   [Report 147](../reports/147-agent-authored-batch-reuse.md) completes a
   direct retention test: fresh agents attempted batch billing with or without
   the single-rental queries actually authored by report145's flat participants.
   Correct controls pass 18 independent cases in both languages, and compiling
   wrong-aggregation controls fail six. Both F# submissions pass; neither
   AgentLang participant finds the supported Flow/2 fold spelling, and both
   abort. The F# retained participant duplicates rather than calls its helper.
   The AgentLang participants exchanged failed syntax information, so their runs
   cannot be treated as independent observations. Correct the fold metadata/help
   mismatch and tighten trial isolation before a separately identified discovery
   repeat; do not infer a vocabulary benefit from this outcome.
   The feasibility probe also records a library-coverage tradeoff:
   carrying invalid-window errors through a fold makes every branch testable
   but traverses the input even for invalid windows.
   [Report 148](../reports/148-flow-list-discovery.md) corrects list-callback
   discovery: descriptors retain Stack syntax and separately expose Flow/2
   receiver forms; help includes an executable named-callback fold example.
   Focused runtime/CLI suites and the unchanged billing control pass locally.
   A single fresh participant passes the same retained batch task's 18 oracle
   cases and publishes two qualified library functions. It initially calls the
   retained query, sees an uncovered post-fold error branch, then replaces reuse
   with duplicated arithmetic and qualifies the result. The guidance obstacle
   is overcome; retained production reuse is not demonstrated. Next investigate
   validated-input API shapes that avoid redundant error paths without weakening
   coverage. This is a discovery follow-up, not a replacement for report147 or
   a retention estimate.

Acceptance is an evidence-backed review of the declared conditions, including
their limitations. Completing a language feature or passing actor-written tests
alone is not acceptance of the research hypothesis.

## 2. Completed: make the approved examples executable

The [revised examples](EXAMPLE-SYNTAX-MIGRATION.md) now use executable Flow/2 `fn`, plain
record properties, typed `==`, omitted pure effects and metadata spacing.
The explicitly versioned Flow/2 authoring path uses the same verified
semantic IR, with durable source-version selection and an explicit formatter (report 100).
Retain Flow/1 and Stack/1 historical bytes and interpretation.

Validated acceptance includes property/method disambiguation, nominal-type equality
rejection, effect checking before execution, formatter idempotence and
define/test/commit/reload round trips. Migrate executable examples and runtime
help together after these checks pass. Run focused Flow, Source and Storage
suites and applicable full local validation with fresh build outputs that do
not overwrite the frozen experiment binaries. See
[the implementation plan](../reports/085-frontend-library-revision-plan.md).

## 3. Build a lean native execution target and choose memory semantics

The first scalar LLVM AOT implementation is locally validated; see
[report 103](../reports/103-llvm-architecture-and-native-slice.md). The user
authorized this step based on demonstrated capability; comparative reliability
research continues. Implementation language remains open to maintenance needs.

The first standalone native arena/mailbox comparison is complete; see
[report 104](../reports/104-native-arena-mailbox-feasibility.md). All 72 runs
passed. Per-turn backing fell 77â€“80% for suspended workloads with disposable data,
but the retained-only control used more backing and copying. This supports
continuing the candidate, not a production throughput claim or language-wide
lifetime guarantee. Next, specify a narrow retained-value/lifetime contract in
the verified IR and add native conformance before broad runtime integration.
The standalone probe does not implement AgentLang mailboxes or idle trimming.
Native Int/Bool refinement conformance is now validated (252 native assertions);
see [report 105](../reports/105-native-refined-scalars.md). Native record execution
now passes 342 conformance assertions with invocation scratch, atomic retained
outputs and decoding after scratch/DLL disposal; see [report 106](../reports/106-native-record-ownership.md).
[Report 107](../reports/107-native-state-reentry.md) now validates typed state
re-entry with 441 native assertions: retained results feed later invocations
without managed graph decoding, preserving old state on failure. This currently
copies the input graph and live outputs, and requires one verified program
instance. [Report 108](../reports/108-native-mailbox-suspension.md) now passes 120
checks for readable Flow/2 handlers suspending/resuming fixed mailboxes through
one reusable scratch owner, using an explicit .NET experiment host.
[Report 126](../reports/126-native-mailbox-dispatch.md) moves bounded dispatch,
pending state and arena ownership into a standalone native controller, with
versioned entry/type metadata; its integrated verifier passes 353 checks.
The tiny fixture reserves 1,400 bytes for controller/arenas/workspace, not total
process memory. This is not general release certification. Real I/O, provider cancellation and a
genuine whole-request lifetime alternative remain prerequisites for the fair
throughput comparison; holding cleared scratch is not a valid substitute.

Memory priority clarification (2026-10-08): implement and test an owning value
stack for most working data, with explicit retained mailbox state. Values own
nested payloads; duplication creates independent values; moves transfer ownership;
logical drops end value lifetimes without surviving aliases. Physical space is
reclaimed only at compiler-proven dead suffixes or operation-wide reset; dead
interior bytes may remain until then. The stack must also
provide actual payload locality: adjacent owning values and
nested fields occupy nearby bytes, not merely nearby handles. Measure offsets,
extents, padding/reservations and access-pattern performance separately.
The current invocation bump arena/shared record DAG does not implement this.
The next bounded experiment must
exercise variable-sized nested values, copy/move/pop, returned results, surviving
outer values, branch joins and capacity failure, with exact storage oracles.
The fixed-size nested-record stage is complete in
[report 128](../reports/128-owning-value-stack.md): 462 cross-backend checks cover
inline ownership, copy/drop/return placement, local scope restoration and capacity
failures. Working-stack extent stays at 288 bytes across one/eight repetitions,
but fixed reservation and diagnostic overhead prevent a total-memory advantage
claim. This stage alone does not
satisfy the variable-size requirement or select the final representation.
The variable-sized slice is complete in
[report 129](../reports/129-variable-owning-values.md): 796 comparison checks and
the 37-check local Release gate pass. Inline Strings inside acyclic records
preserve UTF-16 code units, including isolated surrogates, with dynamic sizes
and field offsets exposed explicitly. Independent bytes, packed locals, dynamic
returns, failure cleanup and capacity boundaries are checked at O0/O2. The ABI3
control still covers fixed records only. Direct concat peaks at 80 bytes;
the wrapped user-function path peaks at 144 because of extra frames/local loads.
These are conformance counters, not a throughput or process-memory win.
The user subsequently clarified that rare movement and bulk pointer reset are
the intended behavior. Replace eager packing with stable arena payloads and
bounded location metadata. Ordinary bindings, read-only loads, same-arena calls
and returns should not copy payloads; function boundaries alone do not require
region resets. Leave interior dead space until a safe suffix or processing-region
reset. Require saved scope marks and compiler-checked early suffix rewind;
escaping results must prevent unsafe rewind. At request completion, reset the
whole arena or return it to the pool. Verify reset safety, unchanged retained output on failure and repeated-turn
capacity reuse. Measure metadata separately from payload traffic, and compare
with report 129's frozen evidence. This implementation now passes focused native
acceptance and the full local Release gate in
[report 130](../reports/130-stable-arena-rewinds.md).
The owning mailbox bridge now passes focused O0/O2 integration in
[report 131](../reports/131-owning-native-mailboxes.md). It keeps one native lifecycle
controller. Generated entries return locations into live working storage;
the controller publishes the complete output set once into inactive retained
storage before resetting scratch. The 180-check verifier and 122 native assertions
per optimization level cover dynamic String request/response lifetimes and
failure isolation. The 37-check full Release gate and 476-assertion LLVM suite
also pass. The focused two-policy mechanism comparison now passes 234 verifier
checks and 97 native assertions at each optimization level in
[report 132](../reports/132-associated-arena-comparison.md): keeping the actual
arena avoids intermediate publication/reimport, preserves failed-resume retry,
and pins slots that returning scratch makes available to other mailboxes. Both
policies use equal configured storage. Broader local validation also passes:
35 owning-stack checks, 353 native-dispatch checks, all 37 Release checks and
476 LLVM assertions. The bounded real-I/O comparison now passes seven cases
under both policies at O0/O2, including terminal cancellation and retry; see
[report 133](../reports/133-real-io-mailbox-correctness.md). Fresh policy and ordinary
mailbox regressions also pass. The optional reset profile now removes full-capacity
scratch payload clears at checkout/release, with matching policy and socket
behavior ([report 138](../reports/138-native-reset-profile.md)). The opt-in
[trusted-generated profile](../reports/139-trusted-generated-native-profile.md)
removes the remaining diagnostic bitmap storage, poison writes and tracking
scans while preserving serialized input checks and callback boundaries. Its
12-run socket matrix preserves both policies' behavior at O0/O2. The first
[matched load comparison](../reports/140-matched-mailbox-load.md) passes 197
correctness-checked trials plus an independent raw-data audit. Native process
memory is smaller in this fixture; a sixteen-slot KEEP pool recovers throughput
lost by four slots. Native RETURN's best short point fails the 30-second check,
so a general throughput advantage remains unproven. The internal arrival driver
and non-monotonic timing require investigation before service-throughput claims.
The [current readiness check](../reports/207-mailbox-load-readiness.md) rebuilds
the accepted native backend and passes eleven host smoke cases. The focused
[thirty-second sixteen-slot confirmation](../reports/208-sixteen-slot-confirmation.md)
passes all nine behavior checks, but both native policies miss the rejection
gate in every repeat while F# qualifies in all three. Native process memory is
lower in this fixture; copy counters are unmeasured. Preserve both policies and
investigate dispatch/polling/admission timing before another performance ranking.
The [diagnostic slice](../reports/209-mailbox-diagnostics.md) passes eleven fresh
smoke cases with rejection reasons and independently checked logical copy counts.
KEEP avoids suspension-boundary copies but construction copies remain substantial.
The observed overload rejection categories do not establish the cause of the
earlier sixteen-slot confirmation result. Preserve both policies; a bounded
driver-servicing experiment precedes any new performance ranking.
The [completion-service diagnostic](../reports/214-completion-service-diagnostic.md)
adds opt-in ready-queue draining while keeping one-packet service as default.
Eleven fresh smoke and fifteen rotated overload trials pass correctness, accounting
and cleanup. KEEP improves in this short fixture; RETURN ranges overlap and all
groups fail the rejection gate. Both policies remain available. A focused
long-run comparison at the earlier 500/s workload is needed before a ranking.
Keep both arena policies available; return to the primary maintenance-efficacy
comparison below before expanding performance infrastructure. A general actor
framework is not a prerequisite for either experiment.
Native conformance does not
establish service throughput, process RAM or improved agent reliability.
This is not an unresolved preference between packing and bulk reset; see the
[simplicity review](OWNING-STACK-DESIGN-REVIEW.md#stable-arena-payloads-and-bulk-reset-selected-direction).
Rewind placement requires compiler proof; uncertain lifetimes retain storage
until a later proved boundary. Runtime liveness decisions are excluded. Follow
the [stable arena lowering contract](STABLE-ARENA-LOWERING.md).

Deferred research: the user suggested an explicit operation such as
`Allocation.drop(temporary)` that might request compaction. This is an idea,
not selected syntax or part of the current backend work. Distinguish ending a
binding's logical lifetime from relocating surviving payloads. First measure
whether retained dead space is a practical problem. If it is, compare selective
transfer into a fresh arena with in-place compaction. Require compiler proof
that every affected location is controlled and updated, including projected
fields and retained/provider dependencies; pending I/O may make relocation
ineligible. No hidden compaction on ordinary scope exit or drop.

The refined candidate is an explicitly selected region boundary after a deep
function chain, with only its returned values surviving. Move those few results
to the saved region mark and rewind after them when compiler proof permits it.
Evaluate this against retaining the dead space until full reset; measure bytes
recovered, bytes moved and latency. Stack-top placement alone does not prove
safety. A size-based profitability threshold may be dynamic, but lifetime safety
must remain static. The user prefers `let result = compact { ... }` as the
candidate form, with the block's returned value (possibly a record or tuple)
identifying its survivors. Record it as future syntax, not an available feature;
thresholds and detailed semantics remain open. Implementation is deferred until
realistic workloads demonstrate a need. See the
[candidate example and safety rules](STABLE-ARENA-LOWERING.md#allocation-and-lifetime).

Related deferred research: Koka and Perceus, identified by the user on
2026-10-08. Study compiler-inserted last-use drops and reuse analysis that can
implement functional updates in place. Perceus uses precise reference counting;
the compiler's inserted operations can still perform runtime uniqueness checks.
It is not evidence that arbitrary lifetimes or safe mutation are always decided
entirely at compile time. Our adaptation should first investigate statically
proved last-use reuse of existing arena slots without changing source value
semantics, adding reference counting, or relocating unrelated survivors.
If uniqueness or layout suitability cannot be proved, keep the ordinary
allocation path. Measure copy bytes and retained capacity before adopting it.
Sources: [Microsoft Research's Perceus paper](https://www.microsoft.com/en-us/research/publication/perceus-garbage-free-reference-counting-with-reuse/)
and [Koka's reference-counting and reuse examples](https://koka-lang.github.io/koka/doc/book.html).
Final byte encoding remains an experimental choice; shared-graph regions are comparison
controls, not replacements for the owning-value goal. Keep the actual
keep-associated versus return-at-suspension async comparison as the subsequent
throughput decision; mailboxes alone are not the memory differentiator.

The [Midori research note](MIDORI-RESEARCH.md) records relevant primary accounts
and their limits. For later async work, keep suspension explicit, bound queued
bytes/outstanding operations, measure copy costs, and test state changes across
awaits. Midori's linked execution stacks and collected/shared heaps are not
evidence for our owning program-data-stack model.

Include [Goose](GOOSE-RESEARCH.md) as a close memory-layout comparison and a
source of testable alternatives, especially destination construction and
variable-size layout tradeoffs. Review its inferred stack/lifetime rules against
our stricter owning-value contract before adopting them. Repository benchmark
claims require independent replication; no throughput advantage is inferred.

The [owning-stack simplicity review](OWNING-STACK-DESIGN-REVIEW.md) keeps the
source model unchanged while making static placement, dynamic size boundaries,
local cleanup and resource exhaustion explicit. Prefer compiler-derived layout
over adding region/borrow syntax or multiple collection-storage categories.

Research compiler-guided pool sizing from each process-message entry point:
derive fixed layouts and peak call/branch storage, incorporate explicit input
and recursion bounds, and report proven bounds separately from estimates or
unknowns. Combine per-handler sizes with configured executing/suspended owner
counts, retained-state and queue/provider budgets. This follows basic owning-stack
conformance; see [the sizing contract](ASYNC-ARENA-EVALUATION.md#compiler-guided-sizing).

Keep the semantic IR authoritative. Development backends add LLVM
JIT while release builds use LLVM AOT plus a minimal runtime. Research arenas,
an arena-backed program-data stack, bounded mailboxes and suspended-I/O state
with explicit lifetime and buffer rules. Compare whole-request arenas against
per-turn scratch arenas with retained continuations under equal resource limits.
The first native slice establishes bounded interpreter/native agreement for
checked arithmetic, typed values, calls, branches and structured failures, with
versioned layout/ABI fixtures. Use an actual arena/pool prototype to measure
used/reserved/process memory, escaping outputs and cancellation cleanup.
Then expand conformance and implement development JIT generation invalidation
and compiler-free AOT release builds. A small slice does not imply general
native support; the same semantic IR remains authoritative throughout.
The approved [async arena experiment](ASYNC-ARENA-EVALUATION.md) makes per-turn
scratch the main candidate and whole-request arenas the comparison. Measure
sustained successful requests per second at the same enforced memory ceiling
and acceptable tail latency, including slow clients, cancellation and bounded
pending I/O. Record copying, backpressure and whole-process memory as well as
arena accounting before adopting either design.
User clarification (2026-10-08): keep mailbox identity/static state the same in
both arms. Compare keeping its actual stack/scratch associated throughout async
work against returning scratch to the pool at suspension and reacquiring it on
completion. The keep-associated arm must retain real data and avoid unnecessary
promotion copies, not hold a cleared arena artificially. Record memory,
throughput, tail latency, copying and allocation churn under matched limits;
[the explicit comparison contract](ASYNC-ARENA-EVALUATION.md#explicit-comparison-keep-or-return-the-mailbox-stack)
defines this next experiment. The simulated report104 comparison does not
replace the real-I/O comparison.
The latest memory candidate preserves mailbox static state while releasing
unused stack/scratch backing storage after inactivity. Reset safe turn-local
state promptly, retain reusable
capacity within the budget, and measure burst/idle/outlier behavior separately from the arena
lifetime comparison. Long-lived state and outstanding I/O retain their own
cleanup boundaries.
An optional alternative is per-type min/max mailbox pools with fast growth and
slow retirement. Research state identity/routing and safe draining separately;
counts alone do not bound memory or add CPU parallelism to a single thread.
For mailboxes with distinct state, the preferred candidate is `min = max` with
stable identities; stack capacity can still be released independently on idle.
At async suspension, the proposed refinement stores surviving data and resume
state in that same mailbox, returns its stack arena to the pool, and reacquires
stack storage for resumption. No additional processing mailbox is required;
ordering during suspension remains a policy to specify and test.

Runtime organization remains an open design choice. The user is considering
specialized typed mailboxes connected as a data-flow system, with Smalltalk-inspired
live inspection and implementation replacement, rather than committing to a
general actor system. Evaluate functions as the unit of ordinary composition
and mailboxes as state, scheduling and lifetime boundaries; do not require a
mailbox for every function. State retention, async resumption and explicit typed
routing fit this candidate. General spawning, supervision and distribution are
separate decisions. Current native arena/profile work supports the shared
foundation and does not select a general actor framework. AI coding agents
remain external developers, not language-runtime entities.

No current interpreter result proves native footprint, throughput or arena
safety. Require semantic conformance and measured memory, throughput and tail
latency before choosing the model. The proposed long-running Campfire migration
comes after stable language behavior and implemented native memory/runtime
support, as described in [report 088](../reports/088-late-application-migration-research.md).

## 4. Strengthen reusable library contracts

The next approved correctness checkpoint implements the
[structural correctness requirements](STRUCTURAL-CORRECTNESS.md) in bounded
slices: explicit checked ratio/rounding operations, closed state types and
exhaustive decisions, invariant-preserving construction, narrow effectful
execution, and deterministic properties backed by independent expectations.
Inspect existing support before adding mechanisms; a language-native property
framework and general proof system are not prerequisites. Preserve frozen
comparison fixtures and resume efficacy evaluation after the implementation
checkpoint. Track delivered and pending requirements explicitly in its report.

Report 110 delivers the arithmetic slice: exact checked ratios and an authored
total Money scaler using validated unit basis points. [Report 112](../reports/112-closed-domain-states.md)
delivers payload-free Flow/2 enums with verified exhaustive matching and durable
source for project functions. The finite library qualification implementation
is validated locally: it checks direct Bool/enum inputs per
parameter, finite return values with open-composite projections, and actual
target invocation from passing own tests. It rejects unprovable or over-4096
domains and requalifies durable libraries on load and named snapshot restore.
Enum-bearing authored helpers must qualify independently before a library can
reach them. All 37 full local Debug checks pass; see
[the finite coverage contract](FINITE-COVERAGE.md) and [report 116](../reports/116-finite-library-coverage.md).
[Report 117](../reports/117-finite-coverage-adoption.md) tests adoption with one
fresh subagent: it tests both mixed Boolean combinations, qualifies that function,
and honestly keeps an always-populated Option return at project maturity.
Independent behavior and both frozen mutation checks pass. One added test is
redundant; a scripted three-row control passes qualification while missing a
Boolean interaction bug. Evaluate bounded Cartesian coverage separately; no new
policy is adopted from this single trial. For the next structural slice, use
explicit populated-state contracts where presence is guaranteed, then test
legal state transitions without weakening unreachable-alternative diagnostics.
[Report 118](../reports/118-populated-delivery-contract.md) implements one such
narrow slice: an interpreter `list.tail` and a separately loaded Flow/2 delivery
extension use a required `EmailMessage` head inside a populated plan. The focused
Business Transitions runner passed 8 groups / 5,382 assertions, with the original
53 words, 31 types, 154 tests and 44 examples preserved. The extension adds 2
words, 1 type, 7 tests and 3 examples, plus 15 reload checks. All 37 full Debug
checks and 444 separate LLVM assertions pass; no agent-adoption or native List
claim is made. General
cross-field validation and provider-state assertions were pending at that
checkpoint. [Report 119](../reports/119-record-construction-invariants.md)
adds optional whole-record predicates enforced by verified IR, the interpreter
and the supported native record constructor. Focused checks pass: 191 IR,
93 interpreter, 44 formatting, 1,110 Flow, 101 Source, 979 Flow Runtime,
370 Storage, 5,479 business-transition and 455 native assertions. Persistence
and library qualification pass before and after reload. The full Debug run passed 36/37 checks; its sole inspection-script
compatibility failure was repaired and passed 31 assertions separately. Functions returning validated records with finite projections
remain unqualifiable without a proven valid-value domain. This is implementation
evidence, not fresh-agent adoption.

The bounded fresh-agent trial is complete ([report 120](../reports/120-record-validator-adoption.md)):
behavior and reload pass, but the agent misunderstood validator-owned coverage
and left the predicate at project maturity. A separate diagnostic qualified the
same predicate with one correctly owned rejection case.
[Report 121](../reports/121-record-validation-guidance.md) supplies an executable
Flow/2 validator example, exact request selectors and documented caller-view
scopes. A fresh Debug build, 1,023 Flow Runtime assertions and 145 CLI assertions
pass. [Report 122](../reports/122-record-validation-help-adoption.md) completes a
fresh bounds-invariant trial: all ten independent cases and six attached tests
pass after reload, both functions qualify as library, and the durable validator
binding matches. However, all three help requests returned Flow/1, so the new
Flow/2 guidance was never exposed.
[Report 123](../reports/123-versioned-record-help.md) repeats that task with the
same runtime, oracle and scorer, explicitly selecting version-2 help. The fresh
agent saw the example, passed ten independent cases and seven own tests, qualified
both functions and produced no structured errors. This is successful bounded
adoption, not a causal improvement estimate. Pin and verify help versions in
future trials.

[Report 124](../reports/124-efficacy-assessment.md) consolidates efficacy evidence:
reuse and workable edits are observed, but comparative reliability and context
advantages remain unproven. [Report 125](../reports/125-matched-pair-repair.md)
completes the small replicated pair-reminder repair comparison: six fresh agents
(two per retained/reset/conventional condition) each pass 12/12 independent cases.
Both retained Flow and conventional agents reuse their existing helper. One
retained actor omits task.commit despite a correct persisted library revision;
record workflow completion separately. The reset condition is compact, not
reset-rich, and these small samples do not establish a reliability advantage.

Continue the approved native-runtime work in section 3: bounded native dispatch
is validated in report126; next test stack/region lifetime rules and compare the
async arena policies under matched limits.
Do not gate that work on more easy repair variants. Future efficacy trials should
use a held-out multi-function change with collateral-regression opportunities,
independent expected values and unchanged controls. A bounded interface follow-up
should make active-task status visible at close, distinguishing word publication
from completed task logging. Reuse the existing harness; add no comparison
prerequisites without a concrete blocker. Provider-state,
module closure and scoped overrides remain approved work, not prerequisites to
completing all future comparisons. Separately assess
whether unchecked construction inputs need a distinct type or field-based
validation contract; report 120 exposes this reasoning tension but does not
settle the design. Provider-state assertions, explicit module boundaries and
test-local overrides remain pending. Authored library dependency closure is
covered by report 142; owning-backend native enums are covered by report 153.
Use new fixtures and preserve historical research inputs.

After the bounded report 140 runtime comparison, prioritize a small maintenance
comparison using the accepted retained-language and conventional outputs from
report 135. Candidate task: change the existing shared payment-total rule to
include only payments belonging to paid invoices, preserving errors and both
summary callers. Use two fresh agents per language, a frozen independent oracle
covering the helper and both callers, and correct/incorrect preflight controls.
Score behavior, shared structure, collateral changes, tests and finalization
separately. Preserve the helper-provenance distinction: the language helper came
from an earlier agent; the conventional equivalent was supplied. This tests
maintenance of existing vocabulary, not identical prior authorship or a causal
language advantage. Reuse the harness and leave historical submissions untouched.

[Report 141](../reports/141-paid-invoice-maintenance.md) completes this
four-participant maintenance study. All four pass the independent behavioral
oracle and preserve shared structure; both language participants and one F#
participant fail the literal requirement for newly authored overflow/precedence
tests, while inherited coverage remains passing. Strict acceptance is 0/2
language and 1/2 F#; behavioral acceptance is 2/2 in each arm. This small defensive
import-state task does not establish a reliability advantage. Future tasks
should assess the resulting suite rather than require duplicate regressions,
and target normal reachable application behavior where effects, module boundaries
or domain types can catch a concrete mistake. No additional mailbox infrastructure
is required before the next agent comparison.

Report 111's extra-write control passed full library coverage but violated the
IO contract. Make provider-state and effect-count assertions straightforward in
authored tests, and require that control to fail under the stronger tests.
Report 113 implements optional exact effect-count assertions scoped to the target
function. Report 114's fresh-subagent probe repaired the behavior but failed to
adopt the assertion: unversioned help returned Flow/1 guidance while the actor
worked in Flow/2, and its seven tests still accepted the extra-write mutant.
Report 115 repeats the probe with version-2 help requests and an explicit testing
help topic in the primer, keeping runtime, seed and oracle fixed. The fresh actor
used effect assertions; its three relevant tests rejected the restored write and
blocked library replacement. This establishes bounded usability, not comparative
reliability or a causal estimate from two actors. Keep help examples version-matched
in future trials. [Report 154](../reports/154-provider-state-assertion-probe.md)
tests the existing known-path readback mechanism: test bodies can inspect virtual
files after the target call and compare their contents while separately asserting
target effect counts. No additional assertion syntax is needed for that case.
Whole-provider-map equality, event ordering and other provider-state assertion
surfaces remain separate work; known-path observations do not establish them.

[Report 142](../reports/142-library-dependency-qualification.md) implements the
all-authored library dependency closure, including collection callbacks. Library
publication and affected durable callers require qualified authored dependencies
or trusted/generated operations; each library member retains its own test gate.
A fresh guided subagent qualified a wrapper and helper and added a missing own
test that rejects the controlled false-branch defect. This is bounded adoption
evidence, not a matched reliability result. Local validation is complete after
repairing the legacy callback test setup; original failure and rerun are retained.
Explicit module membership and cross-module access enforcement remain pending.
Do not infer modules from dotted names.
Deterministic injectable effects retain capability and declared-effect
enforcement.
Add test-local typed dictionary overrides as well: nested calls can see a scoped
replacement of an IO or ordinary function, then automatic cleanup restores the
original even on failure or cancellation. Keep persistent bindings intact and
exclude mocked bodies from the original implementation's coverage evidence.

Full Cartesian input coverage and MC/DC remain decisions to evaluate, not
silently adopted requirements. Test coverage establishes observed behavior;
compiler exhaustiveness establishes handled alternatives. Require both where
specified. After implementation, run another bounded external-agent study to
test whether the stronger contracts improve edits and recovery.

For every milestone: work on `main`, save the report, run applicable checks
locally, then commit and push together. The separate `prototype` branch has been
retired at the user's request. Automatic CI remains disabled; remote publication
failures are reported separately from local validation results.

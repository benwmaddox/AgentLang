from pathlib import Path
import json,collections,datetime
r=Path('.agentlang/replacement-trial-230')
def summarize(arm):
 p=r/'root/traces'/f'{arm}.jsonl'
 rows=[json.loads(x) for x in p.read_text(encoding='utf-8-sig').splitlines()]
 start=rows[0]; end=rows[-1]; assert end['event']=='session-end'
 exchanges=[x for x in rows if x['event']=='exchange']
 errors=[]
 for x in exchanges:
  raw=x.get('response',{}).get('rawLine')
  try: response=json.loads(raw) if raw else {}
  except Exception: response={}
  if response.get('ok') is False:
   errors.append({'index':x['index'],'operation':x['operation'],'error':response.get('error'),'text':response.get('text')})
 return {'arm':arm,'startedUtc':start['startedUtc'],'finishedUtc':end['finishedUtc'],'brokerSessionSeconds':(datetime.datetime.fromisoformat(end['finishedUtc'])-datetime.datetime.fromisoformat(start['startedUtc'])).total_seconds(),'exchangeCount':len(exchanges),'operations':dict(collections.Counter(x['operation'] for x in exchanges)),'requestWireBytes':sum(x['request'].get('wireUtf8Bytes',0) for x in exchanges),'responseWireBytes':sum(x['response'].get('wireUtf8Bytes',0) for x in exchanges),'rejectedResponses':errors,'termination':end,'llmTokenUsage':None,'tokenLimit':'LLM token usage unavailable; wire bytes are not tokens.'}
if __name__=='__main__':
 result={'study':'replacement-trial-230','metricScope':'broker sessions, excluding coordinator calibration/grading and outside-session agent reasoning','arms':[summarize(arm) for arm in ('fsharp','retained')]}
 target=r/'root/participant-metrics.json'; assert not target.exists(); target.write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({x['arm']:{k:x[k] for k in ('exchangeCount','brokerSessionSeconds','requestWireBytes','responseWireBytes')} for x in result['arms']},indent=2))

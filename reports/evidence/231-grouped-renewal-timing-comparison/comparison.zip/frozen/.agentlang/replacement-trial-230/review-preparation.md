# Replacement trial 230 preparation review

Disposition: no blocker found in the reviewed preparation and public packets. This is a review of setup, source pins, broker entry points, and task fairness only. Oracle controls, scoring, participant behavior, and final dispatch readiness remain separate pending gates.

## Evidence checked

- `prepare.py` pins the accepted 228 participant archive and sidecar, verifies every archived member and the accepted 228 setup/freeze/dispatch/final-review receipts, and compares both current endpoints with their archived final-source inventories before copying. It requires accepted runtime source commit `74cc644cd1fb29290435d332fecabfc5833ad6e9` and a clean tracked checkout. The actual HEAD matches that pin.
- The 230 setup records fresh Release clean/build exit code 0 for both broker CLIs with NuGet audit enabled. All 22 files in each private runtime still match their recorded SHA-256 pins. The task, bootstrap, both packets, four launcher scripts, and both smoke traces match setup/smoke hashes.
- Both prepared actor trees match their respective baseline inventories byte for byte, excluding only the preparer's stated transient directories. The accepted 228 retained endpoint tree is `f34007c2262423bef84f102b84d9833efba1ab73cdbea6233c28847626713a1d`; F# is `2f90d7d2a66c68c04bc625c213ae956dffff2eef42f7cf936fe603df0d28b430`. The setup records zero participant dispatches and F# first launch order.
- `preflight/root-interactive-smoke.json` reports a successful actual TTY startup/one request/`host.close` for each arm, with host and runtime exit codes 0. Its trace hashes match the files. The setup's `preflight.interactiveSmokeStatus` still says `pending-coordinator`; the separate later receipt is the evidence of completion. Carry that receipt into freeze rather than treating the setup field as a current status.

## Scope and boundary

The public task gives both arms the same nominal two-instant record and four-input monthly contract, identifies the actual differing caller graphs, and requires preservation of annual and batch behavior. The F# packet limits edits to `Operations.fs` and `SelfTests.fs` and fixes the existing project for validation. The AgentLang packet asks for a separately persisted record, an atomic three-word `replace:true` batch with live observed revisions, and Flow/2 on `define`/`eval`. Neither packet includes held-out case data or scorer files. No new package or external capability is granted.

Launchers point at arm-specific actor directories and trace files, pass an empty capability list, a fixed clock, and 100-exchange/request-size limits to the existing host. The preflight launchers point at separate disposable project copies. The packet's broker-only and no-web instructions are an application boundary, not OS confinement; `setup.json` says this explicitly. The accepted F# project still references the trusted repository Business project during validation. The broker's path controls must remain the authority for participant writes; the task does not grant direct host shell or network effects.

The preparer uses pinned archive contents and refuses symlinks or overwrites while copying. It does not delete paths or use shell-built file mutations. The archive is accepted through a fixed external SHA-256 manifest before its members are extracted. No path traversal or host escape was observed in the reviewed preparation route.

## Remaining gates

Before freeze/dispatch, the independent oracle review must confirm the scoped preservation allowance, nine common behavior cases, inherited AgentLang regression adaptation, and correct/swap/old-arity/weakened-assertion controls. The actual smoke establishes startup and closure only; it does not establish replacement correctness or participant readiness by itself.

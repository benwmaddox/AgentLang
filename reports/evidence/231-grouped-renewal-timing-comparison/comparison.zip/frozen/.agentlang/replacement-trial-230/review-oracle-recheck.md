# Replacement trial 230 oracle recheck

Disposition for AgentLang: the three preservation issues and the old-arity control are fixed. The corrected arity receipt proves a production caller is rejected before publication. Integrated nine-case plus 66-case scoring is still running at this review point; the separate F# preservation gate is outside this check.

## Rechecked fixes

- `normalize_monthly_test_source` now scans balanced constructor/call parentheses, supports nested and multiline local `RenewalTiming` construction, skips quoted pseudo-calls, and collapses whitespace only outside quoted strings. Pure checks show a valid local migration normalizes equal while changed numeric and quoted assertion literals remain different. `python -B experiments/AgentLang.SubagentTrials/replacement-trial-230/oracle/unit_checks.py` passed with nine exported cases and 66 inherited creator cases identified.
- The durable preservation gate requires zero added `manifest.words` identities. Existing seed records have their generated constructor/accessors at runtime, not as persisted word rows. It still checks the sole added `RenewalTiming` type, the three exact inherited word IDs with one appended revision each, unchanged old revision rows/source objects, and scoped inherited test/example sources.
- The correct control records a built project with 160 passing attached tests. The weakened-assertion copy reports a detected inherited test difference. These are calibration artifacts, not participant outcomes.

## Corrected old-arity control

`build_arity_fault` now submits the three existing functions with exact revisions 1, 1, and 2. The source migrates all six direct monthly test invocations and the scheduled step; only `subscription.renew-batch-step` retains a five-argument production call. The current `arity-gate.json` response is `FLOW_ARGUMENT_ARITY` on that caller, expected 4 and actual 5. The subsequent `COMMIT_NO_CANDIDATES` confirms no candidate was staged. The manifest hash stays `490f6401cb26f148db4320ff48271249ebce4efc194a1d9f052fc5b9ee4b91cb` and the monthly revision stays 1. The three raw JSONL responses equal those recorded in the receipt. This is evidence of the intended prepublication gate, not a participant result.

## Swap control and open items

The swap builder starts from the correct committed control, stages a one-word swapped body using the observed revision, saves the accepted define request, and confirms the durable revision remains unchanged. The scorer prefixes that request to a disposable scoring session, checks the stage response, then evaluates the nine cases against the swapped model. This is a legitimate behavior-only control; it must be described as staged/evaluated, not committed or published. Its final discrimination depends on the pending integrated scoring receipt.

The separate F# seed-file and inherited-assertion preservation gate is being implemented outside this recheck. No conclusion about that gate or participant acceptance follows yet.

# 248 implementation and acceptance

Goal: enable the existing Campfire room host operation in real owning-stack AOT code, then continue to the native room endpoint and full application migration.

Preserve pure compilation and mailbox ABI. Add opt-in exact nominal/schema/effect admission and a fixed statically linked C adapter. Pass provider state per execution, including nested calls; no globals or language imports. Direct-write bounded arena output, validate and commit without payload copying; roll back only its temporary suffix on failure. Pin source/profile/layout/effects in a manifest.

Ownership: backend agent OwningStackAot.fs/LlvmToolchain.fs/project resource wiring; root native helper/header, C fixture, entry-export integration tests and reports. Read-only independent native-helper review.

Acceptance: O0/O2 actual callback with UserId/RoomId -> Result<Option<RoomRow>,DbError>; all DbError/Option variants, UTF16, extreme signed IDs, provider failure, invalid nested tags/lengths/extents, small capacity, preserved prefix and source diagnostics, no additional deep-copy/move, execution-local context. Reject altered nominal schema, extra effects, broader dispatcher, missing adapter and accidental pure execution. Preserve baseline export and all native/Campfire gates.

Commands: Release/no-restore builds; Aot.EntryExport.Tests; Llvm.Tests; Verify-NativeValueStack.ps1 (fresh audited artifacts); Verify-Campfire.ps1 -NoRestore (local loopback gate on host). No CI. Snapshot source hashes, raw logs and generated LLVM; report, commit, merge and push together only after passing.

Limits: fixture is not SQL or an HTTP endpoint; no performance result. Next work expands the native adapter set, lists/int formatting and shared GET/HEAD entry, then real HTTP parity/performance.

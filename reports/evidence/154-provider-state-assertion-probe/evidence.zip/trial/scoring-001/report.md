# Provider-state-154 scoring

The published actor candidate is durable revision 2 of configuration.publish at library maturity. Its manifest hash is 3dc33e6e2deab31580fc7cb8fb84467b1fa94dcb3ade8d1c432b157aa031d50e, and its definition object hash is dfb4c67df691d877cf3e407e87f98c3d7de282be7fe754882228dd2b9184d2a9. The stored task record is inactive with 6 test executions and 0 failures. The original actor’s 13-file inventory is identical before and after this scoring.

On a separate copy, three independent literal cases derived from oracleCases/expectedFinal passed: plain text, empty contents, and Unicode with a line feed. Each asserted source, destination, and neighbor values and exact target effects of one fs.read and one fs.write. The candidate function source was identical before and after attaching the oracle tests, and the copied project’s durable manifest did not change.

The participant’s Flow string was evaluated through the frozen runtime and decoded from its JSON result. The actual value contains U+03A9, one CR, two LFs, and no literal backslash-u text or question marks. The participant’s expected and actual Unicode test values each contain two U+03A9 characters, two CRs, and four LFs.

Three body-only mutants ran only the actor-authored tests. All retained the same test-source SHA-256, 4fc129cdc62552776c827d574089f41f79f1cd8610772a607430f3b5193b9a8e. Wrong destination and wrong contents each passed only returns-unit; their two value assertions failed while target effects remained one read and one write. The redundant same-value write also passed only returns-unit; its two file-state values matched, but both target effect checks observed fs.write=2 instead of 1. All three replace-word attempts returned COMMIT_TESTS_FAILED and retained the original manifest hash and generation.

The participant trace also contains three exploratory request errors: EFFECT_FILE_NOT_FOUND at exchange 10, TRIAL_INVALID_UTF8 at exchange 13, and FLOW_TRAILING_INPUT at exchange 14. They were not attached-test failures; the actor’s task commit reports 6 runs and 0 failures.

One frozen auxiliary wrong-contents expectation represents the Unicode line break as a literal backtick-n sequence. The executable case derived from oracleCases/expectedFinal uses an actual LF and passed. The auxiliary file was preserved unchanged; the separate discrepancy record documents the distinction.

The participant’s empty and Unicode tests concatenate destination, source, and neighbor without separators, so some different file-state tuples could produce the same combined string. The independent oracle cases use separators and keep separately named literal values.

Evidence and exact requests/responses are in this directory. run-broker.ps1 uses the frozen CLI and existing Start-SubagentTrialHostV2 broker; its storage.status smoke passed. No build was run.

The earlier generated summary is retained as final-summary-superseded.json; the current actualsMatchIndependentExpectedValues field is true from oracle-literal-check.json:allActualValuesMatchExpectedFinal.

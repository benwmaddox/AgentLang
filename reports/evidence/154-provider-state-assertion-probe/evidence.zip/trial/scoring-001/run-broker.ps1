[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$ProjectPath,
    [Parameter(Mandatory)][string]$RequestPath,
    [Parameter(Mandatory)][string]$TracePath,
    [Parameter(Mandatory)][string]$ResponsePath,
    [Parameter(Mandatory)][string]$StderrPath
)

$ErrorActionPreference = 'Stop'
$scoreRoot = [System.IO.Path]::GetFullPath($PSScriptRoot)
$scorePrefix = $scoreRoot.TrimEnd([System.IO.Path]::DirectorySeparatorChar) + [System.IO.Path]::DirectorySeparatorChar
function Assert-ScoringChild([string]$Path, [string]$Label) {
    $full = [System.IO.Path]::GetFullPath($Path)
    if (-not $full.StartsWith($scorePrefix, [StringComparison]::OrdinalIgnoreCase)) {
        throw "$Label must remain inside scoring-001."
    }
    return $full
}
$ProjectPath = Assert-ScoringChild $ProjectPath 'ProjectPath'
$RequestPath = Assert-ScoringChild $RequestPath 'RequestPath'
$TracePath = Assert-ScoringChild $TracePath 'TracePath'
$ResponsePath = Assert-ScoringChild $ResponsePath 'ResponsePath'
$StderrPath = Assert-ScoringChild $StderrPath 'StderrPath'
if (Test-Path -LiteralPath $TracePath) { throw 'TracePath already exists; use a unique trace path.' }

$repoRoot = [System.IO.DirectoryInfo]::new($PSScriptRoot).Parent.Parent.Parent.FullName
$providerRoot = Join-Path $repoRoot '.agentlang/provider-state-154'
$runtime = Join-Path $providerRoot 'dispatch-001/runtime-snapshot/AgentLang.Cli.dll'
$expectedRuntimeHash = '3ee742e576c2e6d499f7ebaa968878217f5627218c66bb0ad6b27ec0c589909c'
$actualRuntimeHash = (Get-FileHash -LiteralPath $runtime -Algorithm SHA256).Hash.ToLowerInvariant()
if ($actualRuntimeHash -ne $expectedRuntimeHash) { throw 'Frozen runtime hash did not match dispatch-001.' }
$requests = [System.IO.File]::ReadAllLines($RequestPath)
if ($requests.Count -lt 2 -or $requests[-1] -ne '{"op":"host.close"}') {
    throw 'Request file must end with the reserved host.close transport control.'
}

$pwsh = (Get-Command pwsh.exe).Source
$brokerScript = Join-Path $repoRoot 'scripts/Start-SubagentTrialHostV2.ps1'
$allowed = 'help,words,source,tests,define,test,test-all,commit,replace-word,storage.status,task.begin,task.status,describe,search,eval,context,dependencies,callers,failed-tests,examples,example,effects,type-of,history,task.abort'
$psi = [System.Diagnostics.ProcessStartInfo]::new()
$psi.FileName = $pwsh
$psi.UseShellExecute = $false
$psi.RedirectStandardInput = $true
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true
foreach ($arg in @(
    '-NoLogo', '-NoProfile', '-File', $brokerScript,
    '-CliDll', $runtime,
    '-ProjectPath', $ProjectPath,
    '-TracePath', $TracePath,
    '-AllowedOperations', $allowed,
    '-Profile', 'agentlang',
    '-Capabilities', 'fs.read,fs.write',
    '-ClockValue', '2000-01-01T00:00:00Z',
    '-MaxRequestBytes', '262144',
    '-MaxResponseBytes', '524288',
    '-ExchangeTimeoutMilliseconds', '120000',
    '-MaxExchanges', '100'
)) { $psi.ArgumentList.Add($arg) }

$process = [System.Diagnostics.Process]::new()
$process.StartInfo = $psi
if (-not $process.Start()) { throw 'Could not start the broker process.' }
foreach ($line in $requests) { $process.StandardInput.WriteLine($line) }
$process.StandardInput.Flush()
$process.StandardInput.Close()
$stdout = $process.StandardOutput.ReadToEnd()
$stderr = $process.StandardError.ReadToEnd()
$process.WaitForExit()
[System.IO.File]::WriteAllText($ResponsePath, $stdout, [System.Text.UTF8Encoding]::new($false))
[System.IO.File]::WriteAllText($StderrPath, $stderr, [System.Text.UTF8Encoding]::new($false))
[pscustomobject]@{
    brokerExitCode = $process.ExitCode
    runtimeSha256 = $actualRuntimeHash
    responseBytes = [System.Text.Encoding]::UTF8.GetByteCount($stdout)
    stderrBytes = [System.Text.Encoding]::UTF8.GetByteCount($stderr)
    tracePath = $TracePath
    responsePath = $ResponsePath
} | Format-List
if ($process.ExitCode -ne 0) { exit $process.ExitCode }
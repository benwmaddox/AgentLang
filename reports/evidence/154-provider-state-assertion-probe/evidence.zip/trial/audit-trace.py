import collections, datetime, hashlib, json
from pathlib import Path

root = Path(__file__).parent
path = root / 'dispatch-001/broker-artifacts/trace.jsonl'
rows = [json.loads(line) for line in path.read_text(encoding='utf-8-sig').splitlines()]
exchanges = [r for r in rows if r['event'] == 'exchange']
errors = []
for r in exchanges:
    p = json.loads(r['response']['rawLine'])
    if not p.get('ok'):
        errors.append({'index': r['index'], 'operation': r.get('operation'),
                       'code': p.get('error', {}).get('code'),
                       'source': r['response'].get('source')})
terminal = rows[-1]
assert terminal['event'] == 'session-end'
assert terminal['hostExitCode'] == terminal['runtimeExitCode'] == 0
dispatch = json.loads((root / 'participant-dispatch.json').read_text())
result = {
    'traceSha256': hashlib.sha256(path.read_bytes()).hexdigest(),
    'exchanges': len(exchanges),
    'forwardedExchanges': sum(r['outcome'] == 'forwarded' for r in exchanges),
    'operations': dict(collections.Counter(r.get('operation') or '<invalid-encoding>' for r in exchanges)),
    'errors': errors,
    'requestPayloadBytes': sum(r['request']['payloadUtf8Bytes'] for r in exchanges),
    'responsePayloadBytes': sum(r['response']['payloadUtf8Bytes'] for r in exchanges),
    'dispatchToBrokerCloseSeconds': (datetime.datetime.fromisoformat(terminal['finishedUtc']) - datetime.datetime.fromisoformat(dispatch['dispatchedUtc'])).total_seconds(),
    'terminal': terminal,
    'tokenUsage': None,
    'note': 'Protocol bytes are not token counts or total model context. Agent final self-report omits the earlier EFFECT_FILE_NOT_FOUND eval failure; raw trace is authoritative.'
}
(root / 'trace-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))

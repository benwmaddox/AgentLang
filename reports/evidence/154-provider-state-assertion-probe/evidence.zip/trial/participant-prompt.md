You are an external experimental coding agent. Solve the public task below
through the supplied broker only. The human authorized isolated experiments,
edits to the trial project, and local test execution. You are not alone in the
repository; other work is outside your scope. Do not read or edit the main
repository, other trials, hidden verifiers, stored reports or starting snapshots.
Do not spawn agents or use web tools. You may read this prompt, launch the single
specified broker, and interact with it. All project inspection, edits and tests
go through that broker. You have at most 100 exchanges. Keep one broker process;
poll the same handle after a timeout rather than restarting it. Close it with
host.close and observe terminal status before finishing. Report actual failures,
tests and final publication honestly.

## Public task

Repair the existing library function
`configuration.publish(source: String, destination: String) -> Unit` and strengthen
its regression tests. It currently writes incorrect configuration contents even
though its existing test passes.

For distinct existing source and destination paths, read the source exactly once
and write its exact contents to the specified destination exactly once. Do not
append, trim, normalize or otherwise change the contents, including empty text,
Unicode and line breaks. Preserve the source and unrelated files. Make no other
provider calls inside the function. Retain its name, signature, library status,
and declared fs.read/fs.write effects. Do not broaden behavior for missing files
or aliasing paths; those are outside this task's input contract.

Add concise documentation and meaningful regression tests for this behavior,
including data preservation. Use the runtime's deterministic test providers,
not host files or external services. Run the tests, durably publish the repaired
library function and its tests, and finish the task session. Do not remove the
existing test or change unrelated definitions.

## Compact Flow/2 primer

Use JSONL requests. New definitions/evaluations use "frontend":"flow" and
"syntaxVersion":2. Dictionary names use dots; qualified calls use ::, for example
math::double(3). A receiver call value.double() passes value as the first argument.
Plain record fields use value.field. Locals are immutable: let name = expression;
effect-only calls return Unit and may precede a final result.

fn tutorial.double(value: Int) -> Int {
    doc "Twice the supplied integer."

    value.multiply(2)
}

test tutorial.double/basic {
    tutorial::double(3)
    => 6
}

Omitted effects mean none. Put effects before documentation, then a blank line
before code. Use help with syntaxVersion 2 for exact replacement, attachment,
qualification and task commands. For testing help request:
{"op":"help","topic":"examples","syntaxVersion":2}

Useful requests:
{"op":"describe","word":"configuration.publish"}
{"op":"source","word":"configuration.publish"}
{"op":"help","syntaxVersion":2}
{"op":"define","frontend":"flow","syntaxVersion":2,"source":"..."}
{"op":"test","word":"configuration.publish"}
{"op":"tests","word":"configuration.publish"}
{"op":"task.status"}

Tests attach with a dotted owner name followed by /case. They end with => literal,
=> value pure-expression, or => error ERROR_CODE. Full own coverage and passing
attached tests are required for library publication. Inspect contained test
results: a successful protocol response does not mean every test passed.

Send one request per line and observe each mutation's response. Inspect state
after an uncertain mutation instead of replaying it blindly. The broker's host.close
request closes the host; it does not finish the language task or publish a function.

Launch once from D:\code\AgentLang with exec_command, tty:true and yield_time_ms:10000. If sandbox process creation is rejected, the same authorized launch may use require_escalated; this does not expand the file scope.

```powershell
& 'D:\code\AgentLang\scripts\Start-SubagentTrialHostV2.ps1' `
  -CliDll 'D:\code\AgentLang\.agentlang\provider-state-154\dispatch-001\runtime-snapshot\AgentLang.Cli.dll' `
  -ProjectPath 'D:\code\AgentLang\.agentlang\provider-state-154\actors\flow-001' `
  -TracePath 'D:\code\AgentLang\.agentlang\provider-state-154\dispatch-001\broker-artifacts\trace.jsonl' `
  -AllowedOperations @('help','words','source','tests','define','test','test-all','commit','replace-word','storage.status','task.begin','task.status','task.commit','describe','search','eval','context','dependencies','callers','failed-tests','examples','example','effects','type-of','history','task.abort') `
  -Profile 'agentlang' `
  -Capabilities @('fs.read','fs.write') `
  -ClockValue '2000-01-01T00:00:00Z' `
  -MaxRequestBytes 262144 `
  -MaxResponseBytes 524288 `
  -ExchangeTimeoutMilliseconds 120000 `
  -MaxExchanges 100
```

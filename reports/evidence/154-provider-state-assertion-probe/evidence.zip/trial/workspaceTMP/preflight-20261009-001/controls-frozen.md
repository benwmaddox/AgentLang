# Frozen Flow/2 provider-state controls

These exact source, request, response, and literal-oracle files form the preflight controls. They were run with the recorded Release CLI snapshot; no build was performed. Do not change them before any fresh-agent dispatch. New trials should use a new run directory.

See `source-request-manifest.json` for SHA-256 hashes, `independent-literal-expectations.json` for predeclared literal values/effects, and `result-summary.json` for scored outcomes.
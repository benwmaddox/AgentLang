from pathlib import Path
import datetime
import hashlib
import json
import shutil

base = Path(__file__).resolve().parent
dispatch = base / 'dispatch-001'
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
m = json.loads((dispatch / 'dispatch-manifest.json').read_text(encoding='utf-8-sig'))
for item in m['artifacts'] + m['attemptLogHashes']:
    assert digest(dispatch / item['path']) == item['sha256'], item['path']
runtime = dispatch / 'runtime-snapshot'
assert digest(runtime / 'manifest.json') == m['runtime']['snapshotManifestSha256']
rm = json.loads((runtime / 'manifest.json').read_text(encoding='utf-8-sig'))
for item in rm['copiedFiles']:
    assert digest(runtime / item['path']) == item['sha256'], item['path']
seed = dispatch / 'seed-projects/weak-seed'
actor = base / 'actors/flow-001'
assert not actor.exists(), 'Do not overwrite an existing participant project.'
assert not (dispatch / 'broker-artifacts/trace.jsonl').exists()
shutil.copytree(seed, actor)
def inventory(directory):
    return [{'path': p.relative_to(directory).as_posix(), 'sha256': digest(p)}
            for p in sorted(directory.rglob('*')) if p.is_file()]
seed_files = inventory(seed)
assert seed_files == inventory(actor)
launch = (dispatch / 'broker-launch.md').read_text(encoding='utf-8-sig').split('```powershell\n', 1)[1].split('```', 1)[0].strip()
draft = (base / 'participant-prompt-draft.md').read_text(encoding='utf-8')
prompt = draft.replace('Launch command will be frozen here before dispatch after seed verification.',
    'Launch once from D:\\code\\AgentLang with exec_command, tty:true and yield_time_ms:10000. '
    'If sandbox process creation is rejected, the same authorized launch may use require_escalated; '
    'this does not expand the file scope.\n\n```powershell\n' + launch + '\n```')
prompt_path = base / 'participant-prompt.md'
assert not prompt_path.exists()
prompt_path.write_text(prompt, encoding='utf-8')
metadata = {
    'preparedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'model': 'gpt-6-luna', 'reasoningEffort': 'max', 'forkTurns': 'none',
    'promptPath': str(prompt_path), 'promptSha256': digest(prompt_path),
    'dispatchManifestSha256': digest(dispatch / 'dispatch-manifest.json'),
    'runtimeManifestSha256': digest(runtime / 'manifest.json'),
    'runtimeFilesVerified': len(rm['copiedFiles']),
    'actorProject': str(actor), 'startingInventory': seed_files,
    'scope': 'One external-agent usability probe; not a comparative efficacy estimate.'
}
(base / 'participant-inputs.json').write_text(json.dumps(metadata, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'prompt': str(prompt_path), 'promptSha256': metadata['promptSha256'],
                  'actorFiles': len(seed_files), 'runtimeFilesVerified': len(rm['copiedFiles'])}))

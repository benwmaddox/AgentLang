# Word-only mutation scoring after the actor

Use the actor's exact post-run project as the candidate. First copy that project to one isolated directory per mutant. Never edit the actor project. The independent `oracle-*` tests in `oracle-literal-expectations.json` are for correctness checks in oracle-only copies; do not add them to the actor project and then count them as actor adoption.

For each mutation, start with the copied candidate's own stored `configuration.publish` source and preserve every actor-authored test and example. Change only the function body, then stage that Flow/2 replacement in the copied project with `define` (`replace: true`, the copied word's current `expectedRevision`), run `test`, and attempt `replace-word` to record whether the candidate's own tests block publication. Keep the three variants isolated.

- `wrong-destination`: keep the source read and replace the specified-destination write with one write to a fixed unrelated path.
- `wrong-contents`: keep the source read and write `string::concat(contents, "!")` to the specified destination.
- `redundant-same-value-write`: duplicate the exact specified-destination write.

These are word-only mutants. Do not add or replace tests during mutation scoring. Report each mutant against the actor's tests separately from the independent literal oracle. If the actor has only a weak Unit-result test, that test may still pass even though the independent oracle rejects the candidate; record that distinction directly.
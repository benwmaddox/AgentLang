# Dispatch-001 controls

The seed is intentionally incorrect: `configuration.publish` reads `source` and writes `contents + "-wrong"` to `destination`. Its only attached Flow/2 test checks `Unit`, so it commits despite the wrong file contents. The public task is `inputs/public-task.md`.

The three independent oracle test cases use paths and contents disjoint from the seed example. Each case checks the final source, destination, and unrelated neighbor contents and asserts exact target effects (`fs.read: 1`, `fs.write: 1`). The correct implementation passes all three oracle tests plus the retained weak seed test (4/4). Each wrong-destination and wrong-contents mutant fails all three value checks with effects still 1/1; the redundant same-value-write mutant preserves all final values but fails all three effect checks at 1/2. All variants ran in project copies of the committed seed; none modified the seed project or the actor path.

The Unicode oracle request uses ASCII-only JSON wire bytes with JSON-level `\u` escapes. Decoding the request restores actual U+96EA in the Flow source before it reaches the CLI. The response's formatted result was decoded again as a JSON string and checked for U+96EA and U+000A; both appear twice and no `?` appears.

For the eventual actor run, copy the actor project before running any oracle or mutation operation. The broker launch is in `broker-launch.md`; word-only actor-test mutation procedure is in `word-only-mutation-plan.md`. The broker launch remains a prepared input; no agent was dispatched in this preflight.
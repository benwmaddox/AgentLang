# Broker launch inputs

The actor project will be copied by the coordinator from the committed weak seed at `D:\code\AgentLang\.agentlang\provider-state-154\dispatch-001\seed-projects\weak-seed` to `D:\code\AgentLang\.agentlang\provider-state-154\actors\flow-001`. Run the broker against that actor copy; never attach oracle tests to that directory.

Use the copied Release runtime `D:\code\AgentLang\.agentlang\provider-state-154\dispatch-001\runtime-snapshot\AgentLang.Cli.dll` (SHA-256 is recorded in `dispatch-manifest.json`). The exact PowerShell invocation is:

```powershell
& 'D:\code\AgentLang\scripts\Start-SubagentTrialHostV2.ps1' `
  -CliDll 'D:\code\AgentLang\.agentlang\provider-state-154\dispatch-001\runtime-snapshot\AgentLang.Cli.dll' `
  -ProjectPath 'D:\code\AgentLang\.agentlang\provider-state-154\actors\flow-001' `
  -TracePath 'D:\code\AgentLang\.agentlang\provider-state-154\dispatch-001\broker-artifacts\trace.jsonl' `
  -AllowedOperations @('help','words','source','tests','define','test','test-all','commit','replace-word','storage.status','task.begin','task.status','task.commit','describe','search','eval','context','dependencies','callers','failed-tests','examples','example','effects','type-of','history','task.abort') `
  -Profile 'agentlang' `
  -Capabilities @('fs.read','fs.write') `
  -ClockValue '2000-01-01T00:00:00Z' `
  -MaxRequestBytes 262144 `
  -MaxResponseBytes 524288 `
  -ExchangeTimeoutMilliseconds 120000 `
  -MaxExchanges 100
```

The `host.close` message is a reserved broker transport control and must not be included in `AllowedOperations`. The coordinator creates the actor copy before launching and ensures the trace file does not already exist.
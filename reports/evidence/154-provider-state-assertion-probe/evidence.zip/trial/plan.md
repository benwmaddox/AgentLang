# Flow/2 provider-state assertions: implementation and probe plan

Coordinator decision: accept the existing-language readback approach. Do not
start source changes until milestone 153's active validation and publication
finish. Isolated seed/control preparation may proceed using a recorded snapshot
of the already-built CLI, without tracked-source edits or rebuilds. Keep the
subsequent probe smaller than a new ticket domain: use one
configuration-publication operation with known source, destination and sentinel
paths. Score wrong destination and wrong contents separately from a redundant
same-value write. The first two can preserve exact effect counts yet violate
final state; the last can preserve final state yet violate exact effect counts.
Freeze these independent controls before dispatch. This tests complementary
assertions without introducing another domain vocabulary or harness.

## Finding

The current language can assert the final contents and presence of known virtual-file paths in an authored Flow/2 test without adding syntax or runtime APIs. A test body is a sequence of statements before its `=>` expectation (`FlowTestDefinition.Body` in `src/AgentLang.Core/FlowSyntax.fs:134`; parsing in `src/AgentLang.Core/FlowParser.fs:853`). It can invoke the target, then call `file::read` or `file::exists?` and include those observations in its final value.

`Runtime.checkedByTest` executes that body with a per-test trace and virtual-file map (`src/AgentLang.Core/Runtime.fs:647,2178`). Provider writes and reads update that map (`Runtime.fs:1665`). The target effect counter is active only while the target and nested calls run, so post-call observations do not inflate `effects { ... }`. The expected expression runs in a separate isolated trace and is statically pure (`src/AgentLang.Core/FlowLowering.fs:2544,2573`); state must therefore be read in the actual test body and compared as part of its result.

Test result JSON already exposes actual and expected values (including structured values for expression expectations) and the exact target effect map (`Runtime.fs:2307`). It does not expose the whole virtual-file map. Thus authors can check named final paths using existing provider words, but cannot assert arbitrary map equality or enumerate unknown keys. A same-value write-back leaves final state unchanged, so final-state observation alone cannot catch Report 111's mutation; the existing zero-write count remains necessary.

## Smallest change

Do not add provider-state syntax or change the test AST, parser, interpreter, or result API. Expose the existing read-back pattern in version-matched Flow/2 help and documentation, then lock it down with one focused runtime regression:

- Add a short example to `src/AgentLang.Core/AuthoringHelp.fs` under Flow/2 testing guidance and explain the pure-expectation boundary in `docs/EFFECT-ASSERTIONS.md`. Show a test that calls a target, reads the target path and an unrelated sentinel afterward, and compares the returned observations while keeping the target's exact effect suffix.
- Extend `testEffectCountAssertions` in `tests/AgentLang.Flow.Runtime.Tests/Program.fs` (around line 4050). Its `gate.read` test should seed `gate` and `sentinel`, call the target, read both paths afterward, and return a composed value or small typed record. Assert the observed final values and the target-scoped effect map in the result JSON.
- Make the negative control match Report 111: the mutant reads the existing `gate` contents, writes those same contents back, and returns them. The state/value assertion should still pass because the final map is unchanged; `effects { fs.read: 1; fs.write: 0; }` must fail with `TEST_EFFECT_ASSERTION_FAILED` and block library replacement with `COMMIT_TESTS_FAILED`, leaving the manifest hash unchanged. Keep this control separate from the current “write a new `extra` path” case if both provide useful coverage.

No Flow parser test change is needed: `tests/AgentLang.Flow.Tests/Program.fs:testEffectCountAssertionsFrontend` already covers suffix parsing/rendering, while the runtime test should prove the post-call observation semantics. Help guidance should be requested with `syntaxVersion: 2`, consistent with Reports 114/115.

## Focused probe

Reuse Report 115's versioned-help, one-agent broker procedure and Report 111's separate mutation/scoring approach; do not build another harness. Start from a disposable seeded project, let a fresh external agent use the Flow/2 examples help, and ask it to maintain a stateful support-ticket triage operation: move an eligible open urgent ticket to `triaged`, leave a resolved ticket untouched, preserve its description and a neighboring ticket, and return a clear outcome. This is materially different from invoice reminders and avoids another billing-arithmetic trial. Keep the prompt focused on behavior and authored tests without spelling out the read-back syntax, so the probe can measure whether the help makes the pattern discoverable.

Score the candidate separately for behavior, authored test adoption, and preservation. The independent oracle should check the relevant virtual-file contents and exact provider effects. Apply a disposable mutation that performs an unnecessary same-value write on an existing ticket path; the final-state assertion should remain satisfied while the effect assertion rejects the replacement. Preserve the submitted tests, test output, version-2 help request/response, source snapshot, independent state/effect oracle, mutation result, and broker trace under `.agentlang/provider-state-154/`. This is one usability probe, not a comparative reliability claim.

## Acceptance commands and evidence

Run the focused frontend and runtime suites after implementation:

```powershell
dotnet run --project tests/AgentLang.Flow.Tests/AgentLang.Flow.Tests.fsproj
dotnet run --project tests/AgentLang.Flow.Runtime.Tests/AgentLang.Flow.Runtime.Tests.fsproj
```

The runtime evidence should show the post-call state values in `actual`/`actualStructured`, the target-only counts in `effectAssertion.actual`, and a same-value-write mutant rejected by the library test gate without changing the stored manifest. The agent probe should retain its artifacts in `.agentlang/provider-state-154/`; no broad validation gate is needed for this bounded change.

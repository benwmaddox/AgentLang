Repaired `configuration.publish` to read the source once and write its contents unchanged. Added documentation and two regression tests for empty text, Unicode, line breaks, source and unrelated-file preservation, and exact provider-call counts. Kept the existing return-unit test.

All 3 attached tests pass; coverage is complete. The revision is published as a library word (`maturity: library`, revision 2), and task `task-0001` is committed with zero failed tests.

Two exploratory eval probes failed during investigation—one due to raw Unicode input encoding and one because eval accepts a single expression. Neither affected the published work. `host.close` was acknowledged; polling the same process handle then returned “Unknown process id,” indicating it had exited, though no exit code was provided.

from pathlib import Path
import hashlib, json, zipfile

base = Path(__file__).parent
repo = base.parents[1]
output = repo / 'reports/evidence/154-provider-state-assertion-probe'
output.mkdir(parents=True, exist_ok=True)
archive = output / 'evidence.zip'
allowed = {'.agent', '.json', '.jsonl', '.txt', '.log', '.md', '.py', '.ps1'}
selected = {}
for path in base.rglob('*'):
    if path.is_file() and (path.suffix.lower() in allowed or path.name == 'CURRENT'):
        selected['trial/' + path.relative_to(base).as_posix()] = path
for name in ['scripts/Start-SubagentTrialHostV2.ps1', 'docs/EFFECT-ASSERTIONS.md']:
    selected['source/' + name] = repo / name
manifest = []
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as target:
    for name, path in sorted(selected.items()):
        data = path.read_bytes()
        target.writestr(name, data)
        manifest.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    target.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    assert len(check.namelist()) == len(manifest) + 1
    for item in manifest:
        assert hashlib.sha256(check.read(item['path'])).hexdigest() == item['sha256']
metadata = {'archive': 'evidence.zip', 'entries': len(manifest) + 1,
            'bytes': archive.stat().st_size,
            'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
            'note': 'Contains preparation attempts, frozen inputs, protocol trace, submitted project, scoring copies and raw results. Runtime binaries omitted; their manifests and hashes retained. Source runtime commit b413326.'}
(output / 'archive.json').write_text(json.dumps(metadata, indent=2) + '\n')
print(json.dumps(metadata, indent=2))

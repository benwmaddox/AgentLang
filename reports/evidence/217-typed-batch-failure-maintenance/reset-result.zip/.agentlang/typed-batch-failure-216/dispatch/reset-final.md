# Reset participant terminal disclosure

Participant reports library publication of batch/step at revision 3 and both
new types persistent at revision 1 in session 91085. Targeted suites reportedly
pass batch7/7 and helper6/6, full suite150/150, group library gate13/13.
Independent scoring and source review govern behavior/preservation acceptance.

Two failed definitions were corrected: wrong Flow/2 declaration keyword, and a
request combining new types with a word-only replacement. Host denied close and
other guessed variants; task.commit found no active task. After publication,
participant sent Ctrl+C to terminate the same broker instead of host.close.
Trace lacks session-end; host-side read-only PID probe finds neither original
broker56956 nor runtime70952. The termination audit is a separate failed endpoint;
no restart, replacement broker or retroactive close will repair that endpoint.

Disclosed tool use: exact assigned packet read, authorized launcher, write_stdin
broker/session requests and one collaboration status message to root. No Git,
network or direct filesystem edits reported. Ctrl+C is a disclosed transport
protocol deviation, not a normal broker close. No root implementation/outcome
feedback or post-edit close assistance was given to this arm.

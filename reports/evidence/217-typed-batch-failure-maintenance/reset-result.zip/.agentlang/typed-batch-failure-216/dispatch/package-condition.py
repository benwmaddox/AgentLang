import hashlib
import json
from pathlib import Path
import sys
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parents[3]
study = root / '.agentlang/typed-batch-failure-216'
condition = sys.argv[1]
assert condition in ['reset', 'retained']
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
score = read(study / 'dispatch' / f'{condition}-score.json')
receipt = read(study / 'dispatch' / f'{condition}-scoring-receipt.json')
review = read(study / 'dispatch' / f'{condition}-review.json')
assert review['status'] in ['accepted', 'rejected'], 'Only terminal reviewed results may be sealed'
out = root / 'reports/evidence/217-typed-batch-failure-maintenance'
out.mkdir(parents=True, exist_ok=True)
archive = out / f'{condition}-result.zip'
index = out / f'{condition}-result.index.json'
assert not archive.exists() and not index.exists(), 'Do not overwrite sealed result'
paths = {study / 'traces' / f'{condition}.jsonl'}
for directory in [study / 'actors' / condition, Path(score['evidenceDirectory'])]:
    paths.update(p for p in directory.rglob('*') if p.is_file())
paths.update(p for p in (study / 'dispatch').glob(f'{condition}-*') if p.is_file())
paths.update(study / name for name in ['source-pin.json', 'accepted-runtime-pin.json', 'frozen-inputs.json'])
paths.update(study / 'dispatch' / name for name in ['score-condition.ps1', 'package-condition.py', 'record-dispatch.py'])
members = []
with ZipFile(archive, 'x', ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(paths):
        assert root in p.resolve().parents and p.suffix.lower() not in {'.dll', '.exe', '.pdb', '.pyc'}
        data = p.read_bytes()
        name = p.relative_to(root).as_posix()
        z.writestr(name, data)
        members.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
with ZipFile(archive) as z:
    assert len(z.namelist()) == len(members)
    for row in members:
        data = z.read(row['path'])
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
result = {'status': 'sealed terminal participant result', 'condition': condition,
    'automatedPassed': score['automatedPassed'], 'sourceReview': review['status'],
    'auditExitCode': receipt['auditExitCode'], 'scoreExitCode': receipt['scoreExitCode'],
    'archiveSha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'archiveBytes': archive.stat().st_size,
    'memberCount': len(members), 'members': members,
    'interpretationLimit': 'One continuation arm; no comparative result until both arms close and are reviewed.'}
index.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k != 'members'}, indent=2))

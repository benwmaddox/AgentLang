import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

root = Path(__file__).resolve().parents[3]
study = root / '.agentlang/typed-batch-failure-216'
arm = sys.argv[1]
assert arm in ['retained', 'reset']
packet = root / 'experiments/AgentLang.SubagentTrials/typed-batch-failure-216/preparation/task-packet.md'
launcher = study / 'dispatch' / f'start-{arm}.ps1'
receipt = {'status': 'participant dispatched; no result', 'condition': arm,
    'recordedAtUtc': datetime.now(timezone.utc).isoformat(), 'preparationCommit': 'd562cf4',
    'participant': f'maintenance217_{arm}', 'launchOrder': ['retained', 'reset'],
    'packet': packet.relative_to(root).as_posix(), 'packetSha256': hashlib.sha256(packet.read_bytes()).hexdigest(),
    'launcher': launcher.relative_to(root).as_posix(), 'launcherSha256': hashlib.sha256(launcher.read_bytes()).hexdigest(),
    'model': 'gpt-6-luna', 'reasoning': 'max', 'maxExchanges': 100,
    'filesystemMode': 'virtual', 'capabilities': [], 'isolation': 'fresh context; broker instructions are not OS sandboxing'}
target = study / 'dispatch' / f'{arm}-dispatch.json'
assert not target.exists()
target.write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps(receipt, indent=2))

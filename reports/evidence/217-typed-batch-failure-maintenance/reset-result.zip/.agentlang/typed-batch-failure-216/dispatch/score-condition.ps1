param([Parameter(Mandatory=$true)][ValidateSet('reset','retained')][string]$Condition)
$trialRoot = 'D:\code\AgentLang\.agentlang\typed-batch-failure-216'
& pwsh -NoProfile -File scripts/Audit-SubagentTrialTerminationV2.ps1 `
    -TracePath "$trialRoot\traces\$Condition.jsonl" `
    *> "$trialRoot\dispatch\$Condition-terminal-audit.txt"
$auditCode = $LASTEXITCODE
& python -B experiments/AgentLang.SubagentTrials/typed-batch-failure-216/oracle/score_failure.py `
    --cli "$trialRoot\runtime\AgentLang.Cli.dll" `
    --actor-project "$trialRoot\actors\$Condition" `
    --condition $Condition `
    --seed-project 'D:\code\AgentLang\.agentlang\subscription-handoff-161\seeds\agentlang-project' `
    --baseline-project "$trialRoot\baselines\$Condition" `
    --evidence-root "$trialRoot\scores" `
    > "$trialRoot\dispatch\$Condition-score.json"
$scoreCode = $LASTEXITCODE
@{ condition = $Condition; auditExitCode = $auditCode; scoreExitCode = $scoreCode;
   interpretation = 'automatic behavior/preservation checks; independent source review still required' } |
    ConvertTo-Json | Set-Content "$trialRoot\dispatch\$Condition-scoring-receipt.json"
Write-Output "Audit exit $auditCode; scorer exit $scoreCode"

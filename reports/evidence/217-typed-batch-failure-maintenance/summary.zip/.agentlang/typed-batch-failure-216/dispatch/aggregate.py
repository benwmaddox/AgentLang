import json
from datetime import datetime
from pathlib import Path

study = Path(__file__).resolve().parents[1]
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
conditions = {}
for condition in ['retained', 'reset']:
    score = read(study / 'dispatch' / f'{condition}-score.json')
    receipt = read(study / 'dispatch' / f'{condition}-scoring-receipt.json')
    review = read(study / 'dispatch' / f'{condition}-review.json')
    trace = [json.loads(line) for line in (study / 'traces' / f'{condition}.jsonl').read_text(encoding='utf-8').splitlines() if line.strip()]
    start = next(row for row in trace if row.get('event') == 'session-start')
    end = next((row for row in reversed(trace) if row.get('event') == 'session-end'), None)
    exchanges = [row for row in trace if row.get('event') == 'exchange']
    normal_close = receipt['auditExitCode'] == 0 and end is not None and end['hostExitCode'] == 0 and end['runtimeExitCode'] == 0
    conditions[condition] = {
        'acceptedEdit': score['automatedPassed'] and normal_close and review['status'] == 'accepted',
        'automatedPassed': score['automatedPassed'], 'sourceReview': review['status'],
        'normalFinalization': normal_close, 'behavior': score['caseCounts'],
        'retainedCreatorBehavior': score['retainedCreatorCounts'], 'gates': score['gates'],
        'commonSeedTestCount': score['suite']['commonSeedTestCount'],
        'totalTestCount': score['suite']['totalTestCount'], 'exampleOwnerCount': score['suite']['exampleOwnerCount'],
        'actorProjectFingerprint': score['actorProjectFingerprint'],
        'metrics': {'brokerExchanges': end['exchangeCount'] if end else len(exchanges),
            'exchangeCountBasis': 'terminal host receipt' if end else 'recorded trace exchanges; terminal receipt absent',
            'exchangeRequestWireBytes': sum(row['request']['wireUtf8Bytes'] for row in exchanges),
            'exchangeResponseWireBytes': sum(row['response']['wireUtf8Bytes'] for row in exchanges),
            'brokerDurationSeconds': (datetime.fromisoformat(end['finishedUtc']) - datetime.fromisoformat(start['startedUtc'])).total_seconds() if end else None,
            'hostReportedExchangeErrors': sum(row.get('errorCode') is not None for row in exchanges)}}
summary = {'status': 'closed fresh continuation pilot', 'conditions': conditions,
    'interpretationLimit': 'One fresh agent per unequal continuation project; no causal retention contrast, reliability rate, F# comparison, model token/context measurement or native performance result.'}
target = study / 'dispatch/paired-summary.json'
assert not target.exists(), 'Do not overwrite terminal aggregate'
target.write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary, indent=2))

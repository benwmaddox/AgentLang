import hashlib
import json
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[3]
study = root / '.agentlang/typed-batch-failure-216'
frozen = json.loads((study / 'frozen-inputs.json').read_text(encoding='utf-8'))
after_retained = sys.argv[1:] == ['--after-retained']
assert not sys.argv[1:] or after_retained
verified = 0
for row in frozen['files']:
    if after_retained and row['path'].startswith('.agentlang/typed-batch-failure-216/actors/retained/'):
        continue
    data = (root / row['path']).read_bytes()
    assert len(data) == row['bytes'], row['path']
    assert hashlib.sha256(data).hexdigest() == row['sha256'], row['path']
    verified += 1
if after_retained:
    receipt = json.loads((study / 'dispatch/retained-scoring-receipt.json').read_text(encoding='utf-8'))
    assert receipt['auditExitCode'] == 0
print(json.dumps({'status': 'frozen-inputs-verified', 'files': verified,
                  'allowedChangedInput': 'completed retained actor only' if after_retained else None,
                  'launchOrder': frozen['launchOrder'], 'capabilities': frozen['capabilities']}))

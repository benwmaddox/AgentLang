import hashlib
import json
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[3]
study = root / '.agentlang/typed-batch-failure-216'
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
sys.path.insert(0, str(root / 'experiments/AgentLang.SubagentTrials/typed-batch-failure-216/oracle'))
import score_failure as scorer
prep = read(study / 'preflight/preparation.json')
for row in read(study / 'source-pin.json')['files']:
    assert sha(root / row['path']) == row['sha256']
for row in read(study / 'accepted-runtime-pin.json')['runtimeFiles']:
    assert sha(study / 'runtime' / row['name']) == row['sha256']
arms = {}
positive_run = '20261011T111403757539Z-b833459a'
fault_run = '20261011T112800000000Z-faultcal2'
scores = {'reset': 'reset/reset/20261011T111751Z-01/score.json',
          'retained': 'retained/retained/20261011T111815Z-01/score.json'}
for arm in ['reset', 'retained']:
    for directory in [study / 'baselines' / arm, study / 'actors' / arm,
                      root / '.agentlang/paired-vocabulary-213/actors' / arm]:
        assert scorer.project_fingerprint(directory) == prep['fingerprints'][arm]
    migration = read(study / 'controls' / arm / f'positive-{positive_run}/receipt.json')
    assert migration['status'] == 'positive-migration-passed'
    score = read(study / 'controls' / scores[arm])
    assert score['automatedPassed'] and all(score['gates'].values())
    assert score['caseCounts'] == {'expected': 9, 'executed': 9, 'passed': 9}
    assert score['retainedCreatorCounts']['passed'] == (66 if arm == 'retained' else 0)
    faults = {}
    for mutation, expected in [('always-zero-index', 6), ('last-error-wins', 8)]:
        path = study / 'controls' / arm / f'fault-{mutation}-{fault_run}/receipt.json'
        receipt = read(path)
        assert receipt['status'] == 'fault-behavior-calibrated'
        assert all(receipt['calibrationGateChecks'].values())
        assert receipt['behavior']['executedCaseCount'] == 9
        assert receipt['behavior']['matchesFaultPredictionCount'] == 9
        assert receipt['behavior']['matchesCorrectBehaviorCount'] == expected
        assert not receipt['commitAttempted'] and not receipt['publishedToLibrary']
        faults[mutation] = {'executed': 9, 'matchesFaultModel': 9, 'matchesCorrectBehavior': expected,
                            'receipt': path.relative_to(root).as_posix(), 'sha256': sha(path)}
    arms[arm] = {'positiveBatchCases': 9, 'retainedCreatorCases': score['retainedCreatorCounts']['passed'],
                 'positiveScore': scores[arm], 'faults': faults}
review = root / 'reports/evidence/216-typed-batch-failure-preflight/review.md'
assert review.is_file()
ready = {'status': 'reviewed-preflight-passed', 'participantsDispatched': 0,
    'independentSourceReviewPassed': True, 'faultCalibrationPassed': True,
    'launchOrder': prep['launchOrder'], 'sourceFilesVerified': 37, 'runtimeFilesVerified': 5,
    'immutableBaselineAndActorFingerprintsVerified': True, 'arms': arms,
    'reviewPath': review.relative_to(root).as_posix(), 'reviewSha256': sha(review),
    'filesystemMode': 'virtual', 'capabilities': [], 'interpretation': 'preparation only; no participant outcome'}
target = study / 'preflight/readiness.json'
assert not target.exists(), 'Do not overwrite accepted readiness'
target.write_text(json.dumps(ready, indent=2) + '\n', encoding='utf-8')
print(json.dumps(ready, indent=2))

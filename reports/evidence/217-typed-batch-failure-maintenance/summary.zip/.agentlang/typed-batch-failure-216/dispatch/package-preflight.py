"""Seal reviewed preparation evidence, never participant results or binaries."""
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parents[3]
study = root / '.agentlang/typed-batch-failure-216'
output = root / 'reports/evidence/216-typed-batch-failure-preflight'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
ready = read(study / 'preflight/readiness.json')
assert ready['status'] == 'reviewed-preflight-passed'
assert ready['participantsDispatched'] == 0
assert ready['independentSourceReviewPassed'] and ready['faultCalibrationPassed']
for row in read(study / 'source-pin.json')['files']:
    assert sha(root / row['path']) == row['sha256']
for row in read(study / 'accepted-runtime-pin.json')['runtimeFiles']:
    assert sha(study / 'runtime' / row['name']) == row['sha256']
archive = output / 'preflight.zip'
index = output / 'preflight.index.json'
assert not archive.exists() and not index.exists(), 'Do not overwrite sealed evidence'
paths = set()
for folder in ['baselines', 'actors', 'preflight', 'controls', 'dispatch']:
    paths.update(p for p in (study / folder).rglob('*') if p.is_file())
paths.update(p for p in (root / 'experiments/AgentLang.SubagentTrials/typed-batch-failure-216').rglob('*') if p.is_file())
paths.update(root / row['path'] for row in read(study / 'source-pin.json')['files'])
paths.update([study / 'source-pin.json', study / 'accepted-runtime-pin.json', output / 'review.md'])
paths = {p for p in paths if '__pycache__' not in p.parts and p.suffix.lower() not in {'.dll', '.exe', '.pdb', '.pyc', '.zip'}}
frozen = study / 'frozen-inputs.json'
assert not frozen.exists()
pins = [{'path': p.relative_to(root).as_posix(), 'bytes': p.stat().st_size, 'sha256': sha(p)} for p in sorted(paths)]
frozen.write_text(json.dumps({'status': 'reviewed pre-dispatch inputs; no participant output', 'files': pins,
    'launchOrder': ready['launchOrder'], 'model': 'gpt-6-luna', 'reasoning': 'max',
    'maxExchanges': 100, 'filesystemMode': 'virtual', 'capabilities': []}, indent=2) + '\n', encoding='utf-8')
paths.add(frozen)
members = []
with ZipFile(archive, 'x', ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(paths):
        assert root in p.resolve().parents
        data = p.read_bytes()
        name = p.relative_to(root).as_posix()
        z.writestr(name, data)
        members.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
with ZipFile(archive) as z:
    assert len(z.namelist()) == len(members)
    for row in members:
        data = z.read(row['path'])
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
receipt = {'status': 'sealed reviewed preflight; no participant outcome', 'archiveSha256': sha(archive),
    'archiveBytes': archive.stat().st_size, 'memberCount': len(members),
    'verification': 'every member reopened; length and SHA256 verified',
    'omissions': 'compiled binaries and Python caches; full preparation project copies included', 'members': members}
index.write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k != 'members'}, indent=2))

import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parents[3]
study = root / '.agentlang/typed-batch-failure-216'
out = root / 'reports/evidence/217-typed-batch-failure-maintenance'
summary = json.loads((study / 'dispatch/paired-summary.json').read_text(encoding='utf-8'))
assert summary['conditions']['retained']['acceptedEdit']
assert not summary['conditions']['reset']['normalFinalization']
assert all(row['automatedPassed'] and row['sourceReview'] == 'accepted' for row in summary['conditions'].values())
archive = out / 'summary.zip'
index = out / 'summary.index.json'
assert not archive.exists() and not index.exists()
paths = {p for p in (study / 'dispatch').rglob('*') if p.is_file() and '__pycache__' not in p.parts}
paths.update([root / 'experiments/AgentLang.SubagentTrials/typed-batch-failure-216/PLAN.md',
              root / 'experiments/AgentLang.SubagentTrials/typed-batch-failure-216/preparation/task-packet.md'])
members = []
with ZipFile(archive, 'x', ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(paths):
        assert root in p.resolve().parents and p.suffix.lower() not in {'.dll', '.exe', '.pdb', '.pyc', '.zip'}
        data = p.read_bytes()
        name = p.relative_to(root).as_posix()
        z.writestr(name, data)
        members.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
with ZipFile(archive) as z:
    assert len(z.namelist()) == len(members)
    for row in members:
        data = z.read(row['path'])
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
receipt = {'status': 'sealed closed continuation summary; reset finalization failed',
    'archiveSha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'archiveBytes': archive.stat().st_size,
    'memberCount': len(members), 'members': members, 'summary': summary,
    'interpretation': 'Correct preserved edits in both; retained closure assisted; reset lifecycle gate failed. No causal or comparative reliability claim.'}
index.write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k not in ['members','summary']}, indent=2))

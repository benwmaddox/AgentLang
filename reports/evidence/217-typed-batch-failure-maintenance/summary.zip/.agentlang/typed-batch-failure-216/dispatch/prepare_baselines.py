from pathlib import Path
import json,hashlib,shutil,secrets,sys
repo=Path(__file__).resolve().parents[3]
study=repo/'.agentlang/typed-batch-failure-216'
prior=repo/'.agentlang/paired-vocabulary-213'
sys.path.insert(0,str(repo/'experiments/AgentLang.SubagentTrials/paired-vocabulary-213/oracle'))
import score_batch as adapter
expected={'reset':'b939b981fb1ba47a3f004d2bd76c7851adbe8f744f72d1cf62ea100873b1361e','retained':'b99ad6a855a96aa2ed577230b0c03c285d38e65f40f850ea7420d0f29d5f1611'}
for c,fp in expected.items():
    actor=prior/'actors'/c
    assert adapter.scorer.project_fingerprint(actor)==fp
    for kind in ['baselines','actors']:
        target=study/kind/c
        assert not target.exists(), 'Never overwrite prepared project'
        shutil.copytree(actor,target)
        assert adapter.scorer.project_fingerprint(target)==fp
for name in ['source-pin.json','accepted-runtime-pin.json']:
    obj=json.loads((prior/name).read_bytes())
    rows=obj['files'] if name=='source-pin.json' else obj['runtimeFiles']
    for row in rows:
        p=repo/row['path'] if name=='source-pin.json' else prior/'runtime'/row['name']
        data=p.read_bytes();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
    shutil.copy2(prior/name,study/name)
shutil.copytree(prior/'runtime',study/'runtime')
for folder in ['tmp','traces','preflight']:(study/folder).mkdir(exist_ok=True)
order=['reset','retained']
if secrets.randbelow(2):order.reverse()
receipt={'status':'baselines prepared; authoring controls, adapter review and freeze pending; no participant dispatched','fingerprints':expected,'launchOrder':order,'orderMethod':'one random draw before dispatch','sourceFilesVerified':37,'runtimeFilesVerified':5,'filesystemMode':'virtual','capabilities':[],'comparisonLimit':'unequal participant-authored continuation projects, not clean causal retention contrast'}
(study/'preflight/preparation.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
print(json.dumps(receipt,indent=2))

# Read-only publication help investigation

Independent GPT-6.1-sol/medium investigation during the frozen 217 trial.
No files changed, runtime invoked or participant material inspected.

Smallest change: `src/AgentLang.Core/AuthoringHelp.fs` replacement help currently
says groups publish with normal commit, but shows only targeted commit and
replace-word examples. Explain that record evolution stages a process-local
atomic group; define, test-all and untargeted `{"op":"commit","library":true}`
must use the same live CLI/JSONL session. Fresh processes reload published
definitions only.

Clarify expectedTypeSources: include every existing record declared in submitted
source, including unchanged fields; new record names have no entry. This agrees
with Runtime.fs's FLOW_TYPE_REPLACEMENT_CAS_SHAPE validation.

Optional follow-up: REPLACE_NOT_STAGED currently directs single-word replacement.
When a word belongs to a staged type-evolution group, retain the rejection but
point to same-session untargeted group publication. Do not relax CAS, type,
library or atomic publication gates.

After trials finish, extend existing help assertions in
tests/AgentLang.Flow.Runtime.Tests/Program.fs and run:

```powershell
dotnet build tests/AgentLang.Flow.Runtime.Tests/AgentLang.Flow.Runtime.Tests.fsproj --configuration Release
dotnet run --no-build --configuration Release --project tests/AgentLang.Flow.Runtime.Tests
git diff --check
```

Existing record-evolution tests cover missing/stale CAS, publication, reload
and rollback. This is a future implementation recommendation; the trial's pinned
runtime and participant prompt remain unchanged.

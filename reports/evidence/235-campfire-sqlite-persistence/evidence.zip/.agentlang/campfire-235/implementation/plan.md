# Campfire persistence slice 235

## Scope

Implement a standalone F# SQLite component for the first bounded persistence slice. The component is a typed host-side dependency, not a Flow primitive yet: no Core/runtime/provider registration, language source, server, or application authorization is changed in this slice.

Owned files:

- `applications/campfire/Persistence/AgentLang.Campfire.Persistence.fsproj`
- `applications/campfire/Persistence/SqliteProvider.fs`
- `tests/AgentLang.Campfire.Persistence.Tests/AgentLang.Campfire.Persistence.Tests.fsproj`
- `tests/AgentLang.Campfire.Persistence.Tests/Program.fs`
- `.agentlang/campfire-235/implementation/**`

## Provider contract

Expose nominal `UserId`, `RoomId`, and `MessageId` wrappers over `int64`; a closed `RoomKind` (`Open`, `Closed`, `Direct`); typed room, membership, message, and new-message DTOs; and a closed `DbError` (`Unavailable`, `NotFound`, `ConstraintConflict`, `InvalidInput`). `NewMessage.Body` is optional and the client message ID is supplied by the caller. The provider accepts an existing database path only, receives its clock as a dependency, and exposes four named operations with fixed parameterized SQL. It does not expose a connection, query string, SQL selector, or authorization decision.

The operations are: room pages joined through memberships with an ID keyset and page size 1–100; membership existence; the 40 newest messages selected with the pinned `created_at DESC LIMIT 40` query and returned by reversing that result, with the body read from `action_text_rich_texts`; and transactional message creation. Creation inserts the message and optional `Message/body` rich-text record, touches the message only when a body is present, and touches the room every time, matching the pinned Rust source. It returns after commit; FTS indexing, `Room::receive`, unread updates, and push work remain required application migration work.

Use the pinned Rails schema: messages reference existing rooms and creators; rich text has its unique `(record_type, record_id, name)` index but no foreign key; memberships have a unique `(room_id, user_id)` index and no foreign keys; `client_message_id` is not unique. Do not add production schema migrations or constraints. Map unknown room STI values to `Unavailable`; missing membership is `Ok false`; missing parent rows/FK violations are `NotFound`; unique/primary-key violations are `ConstraintConflict`; other constraints are `InvalidInput`; all other SQLite/provider failures are `Unavailable`. Never surface raw provider error text.

## Acceptance and validation

Each group uses a fresh test-only database with the used columns and relevant Rails keys, indexes, and message foreign keys; this is a narrow fixture, not the complete upstream schema or migration set. Tests cover existing-file-only opening; typed room-kind and ID round trips; room page bounds, ordering and continuation; membership true/false and schema-permitted orphan pairs; newest-40/oldest-first messages and Action Text body lookup; timestamp ties against the upstream descending-query/reverse behavior; optional-body create/touch behavior; persistence after provider disposal/reopen; duplicate client IDs remaining accepted; parameterized quote/injection-shaped text; typed missing/FK/constraint errors; and rollback when test-only triggers abort after rich-text insertion or room touch. No test claims that this component completes HTTP authentication, membership authorization, rich-text sanitization, FTS, unread, broadcast, or Flow wiring.

Run from the repository root:

```powershell
dotnet restore applications/campfire/Persistence/AgentLang.Campfire.Persistence.fsproj --verbosity minimal
dotnet run --project tests/AgentLang.Campfire.Persistence.Tests/AgentLang.Campfire.Persistence.Tests.fsproj --configuration Release
```

Record exact command outputs and the package/source pins in this directory. If sandbox restore cannot reach the configured package source, preserve the exact failure and stop restore attempts for parent review.

# Dispatch 209: mailbox-load admission source review

Read-only review of checkout `89aa146`. The 208 source report records nine
30-second trials at 500/s, 4,096-byte payloads and 5 ms provider delay. All
nine pass echo, final-state, accounting and drain checks. F# rejects 0.453–0.533%
with p99 32.177–32.947 ms; native RETURN rejects 1.367–1.813% with p99
32.908–33.555 ms; native KEEP rejects 1.373–1.567% with p99 32.742–33.383 ms.
Thus the native groups fail the predeclared rejection gate while all p99 values
pass. Missed end-of-window arrivals are only 0–6 of 15,000 per trial, so
undispatched arrivals alone do not account for the gap. The report also says the
RETURN/KEEP differences are small and do not establish a policy benefit.
([report](../../reports/208-sixteen-slot-confirmation.md#L7-L35),
[arrival audit](../../reports/208-sixteen-slot-confirmation.md#L75-L83))

## Source facts

This is an internal open-loop arrival driver. Both hosts derive arrivals from a
monotonic phase epoch, assign sequence `n` to mailbox `n mod 16`, process bounded
catch-up batches, and reject busy identities without a request queue. At the
window end, both classify undispatched scheduled arrivals as missed/rejected.
The contract explicitly says the benchmark includes its own scheduling overhead
and is not an ingress service. Native RETURN or KEEP is selected explicitly by
the `--policy` argument and copied into runtime configuration; the source has no
policy-selection algorithm. These trials compare separately configured native
variants under this driver, not a production policy chooser or an external
service endpoint.
([contract](../../experiments/AgentLang.MailboxLoad/CONTRACT.md#L15-L43),
[native option/config](../../experiments/AgentLang.MailboxLoad/load_host.c#L352-L360),
[native runtime config](../../experiments/AgentLang.MailboxLoad/load_host.c#L428-L440))

Admission is similar at the top level but has different timing boundaries.
Native `accept_arrival` first rejects a mailbox marked active, faulted or without
a socket. It then calls `al_mailbox_begin_text`; BUSY, scratch, retained and text
capacity results are merged into the same rejected counter. After a successful
begin it marks the mailbox active, counts admission, synchronously sends the
request frame with `send_all`, and posts an overlapped receive. The active flag
is cleared only after the response is validated and `al_mailbox_resume_text`
returns, or on cancellation. F# rejects when its `inFlight` flag is set; on
admission it updates the ordinary State/Continuation, marks the mailbox in
flight, and starts asynchronous socket exchange. Its single owner clears
`inFlight` while processing a completion from the bounded channel.
([native admission](../../experiments/AgentLang.MailboxLoad/load_host.c#L791-L852),
[native completion/retirement](../../experiments/AgentLang.MailboxLoad/load_host.c#L667-L704),
[F# admission and completion](../../experiments/AgentLang.MailboxLoad/Baseline/Program.fs#L232-L317))

The clearest scheduling asymmetry is completion draining. After a nonempty
arrival batch, native calls `dispatch_one(0)`, which dequeues at most one IOCP
packet. F# calls `drainAvailable`, which reads and processes every completion
already in the channel before it advances. Both leave a mailbox unavailable
until their serial owner processes its completion. Therefore a completion that
is ready but still waiting behind another native IOCP packet could leave
`active` set across a later offer, while the F# drain may clear several
mailboxes at that point. Native also performs blocking `send_all` inside its
arrival owner; F# uses `Socket.SendAsync`/`ReceiveAsync` in worker tasks. These
are concrete implementation differences that could affect admission timing,
but the measurements contain no completion-queue or per-reason rejection data
to show either difference caused the observed gap.
([native loop](../../experiments/AgentLang.MailboxLoad/load_host.c#L741-L765),
[native per-batch servicing](../../experiments/AgentLang.MailboxLoad/load_host.c#L896-L930),
[F# async exchange](../../experiments/AgentLang.MailboxLoad/Baseline/Program.fs#L141-L175),
[F# drain and schedule loop](../../experiments/AgentLang.MailboxLoad/Baseline/Program.fs#L269-L379))

Capacity rejection also cannot be ruled out from the published summary: the
native host merges runtime BUSY/scratch/retained/text statuses and does not emit
their counts. KEEP can reject if no scratch slot is free and releases its
attached slot on resume. At sixteen slots for sixteen identities, that is not
the first expected explanation for KEEP, but only runtime counters can confirm
it was absent. Correctness passing does not distinguish ordinary admission
rejection from capacity rejection.
([slot checkout](../../src/AgentLang.Llvm/native/mailbox_runtime.c#L2198-L2235),
[KEEP admission check](../../src/AgentLang.Llvm/native/mailbox_runtime.c#L2895-L2930),
[KEEP resume release](../../src/AgentLang.Llvm/native/mailbox_runtime.c#L3125-L3195))

## Conclusion and bounded next test

No correctness defect is established by this source review. The strongest
candidate is owner-loop servicing latency, especially the one-packet native
completion step versus F#'s full available-channel drain. Provider/service
latency, scheduler pauses, synchronous native sends, or native capacity
rejections remain possible. Do not attribute the result to RETURN versus KEEP
without runtime evidence; their measured rejection ranges overlap substantially.

Keep the nine 208 results frozen. For a separate, non-scoring diagnostic, run
one paired triplet (F#, RETURN-16, KEEP-16) under the same frozen 500/s,
4,096-byte, 5 ms, 1 s warmup, 30 s measurement, 256 MiB ceiling, provider and
affinity settings, writing to a new evidence directory. Add only aggregate
driver counters: native rejected arrivals split into host-active/fault/socket
and each `al_mailbox_begin_text` status; the equivalent F# busy count; and a
small histogram of time since the mailbox's last accepted scheduled arrival at
each busy rejection. Keep immediate rejection and the existing endpoint and
protocol limits; add no retry or request queue. This distinguishes runtime
capacity from the common busy-identity path and shows whether pending work spans
the 32 ms same-mailbox arrival interval, without turning the diagnostic into a
new throughput ranking. If status counters expose capacity failures, inspect
that runtime path first. If rejections are all host-active and pending age is
long, then a separately reviewed experiment that drains all ready native IOCP
completions per batch is the smallest symmetry change to evaluate. Any such
change needs a new paired result set; it must not overwrite or reinterpret 208.

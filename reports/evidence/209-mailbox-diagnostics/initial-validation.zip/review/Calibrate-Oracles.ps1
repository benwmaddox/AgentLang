param([Parameter(Mandatory)][string]$RunRoot)
$ErrorActionPreference = 'Stop'
$scriptPath = Join-Path $PWD 'scripts/Measure-MailboxLoad.ps1'
$tokens = $null; $errors = $null
$ast = [System.Management.Automation.Language.Parser]::ParseFile($scriptPath,[ref]$tokens,[ref]$errors)
if ($errors.Count -ne 0) { throw 'Runner syntax invalid' }
# Load only these trusted repository validation definitions, not runner setup.
foreach ($name in @('Get-ExactField','Require-Integer','Validate-NativeDiagnostics')) {
    $definition = @($ast.FindAll({ param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq $name },$true))
    if ($definition.Count -ne 1) { throw "Missing validation definition $name" }
    Invoke-Expression $definition[0].Extent.Text
}
$report = Get-Content (Join-Path $RunRoot 'run-report.json') -Raw | ConvertFrom-Json -AsHashtable -Depth 100
if ($null -ne $report.error -or -not $report.sourceStable -or $report.score.scored) { throw 'Smoke run not accepted' }
$receipts = @()
foreach ($trial in $report.trials | Where-Object backend -eq 'native') {
    $raw = Get-Content $trial.paths.applicationResult -Raw | ConvertFrom-Json -AsHashtable -Depth 100
    $null = Validate-NativeDiagnostics $raw $raw.policy $raw.payloadBytes
    $receipts += [ordered]@{trial=$trial.trialId;positivePassed=$true;rejectionReasons=$raw.rejectionReasons;owningStats=$raw.owningStats}
}
if ($receipts.Count -ne 8) { throw 'Expected eight native smoke cases' }
$sample = @($report.trials | Where-Object { $_.backend -eq 'native' -and $_.policy -eq 'return' })[0]
$json = Get-Content $sample.paths.applicationResult -Raw
$mutations = @(
    @{name='reason total';apply={param($r) $r.rejectionReasons.activeMailbox++}},
    @{name='begin publication bytes';apply={param($r) $r.owningStats.beginPublicationCopyBytes++}},
    @{name='resume root import bytes';apply={param($r) $r.owningStats.resumeRootImportBytes++}},
    @{name='publication bytes';apply={param($r) $r.owningStats.publicationCopyBytes++}},
    @{name='handler invocation count';apply={param($r) $r.owningStats.handlerInvocations++}},
    @{name='outstanding lease';apply={param($r) $r.owningStats.outstandingScratchLeases++}},
    @{name='counter scope';apply={param($r) $r.owningStats.scope='includes warmup'}}
)
$negativeReceipts = @()
foreach ($mutation in $mutations) {
    $raw = $json | ConvertFrom-Json -AsHashtable -Depth 100
    & $mutation.apply $raw
    $rejected = $false; $message = $null
    try { $null = Validate-NativeDiagnostics $raw $raw.policy $raw.payloadBytes } catch { $rejected=$true; $message=$_.Exception.Message }
    if (-not $rejected) { throw "Faulty control accepted: $($mutation.name)" }
    $negativeReceipts += [ordered]@{mutation=$mutation.name;rejected=$rejected;message=$message}
}
$result = [ordered]@{kind='post-run native diagnostic oracle calibration';runId=$report.runId;positiveCases=$receipts;negativeControls=$negativeReceipts;scope='Eight saved native cases rechecked and seven faulty controls rejected. Does not simulate runtime status branches or establish throughput.'}
[IO.File]::WriteAllText((Join-Path $RunRoot 'root-oracle-calibration.json'),(($result | ConvertTo-Json -Depth 12).Replace("`r`n","`n")+"`n"),[Text.UTF8Encoding]::new($false))
'Eight saved native positives and seven faulty controls passed calibration.'

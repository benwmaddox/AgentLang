# Dispatch 209 native diagnostics oracle review

## Original finding

The initial closed-form oracle matches the successful fixture runs where `retainedCapacity` is zero. The ASCII payload has `p` UTF-16 code units, so its String extent is `C = align8(8 + 2p)`. The completed echo has `2p` code units, so the latest String extent is `align8(8 + 4p)`, and the corresponding State extent is `S = 16 + align8(8 + 4p)`. The 16-byte prefix is the two `Int` fields. The empty initial String is 8 bytes, making an initial State 24 bytes. At `p=4096`, `C=8,200`, `S=16,408`, and the largest State-plus-Continuation output is 24,608 bytes. These layouts follow the fixture and the runtime's UTF-8 measurement/alignment rules ([fixture](../../experiments/AgentLang.RealIoMailbox/mailbox.flow#L1-L40), [mailbox_runtime.c](../../src/AgentLang.Llvm/native/mailbox_runtime.c#L1648-L1716)).

For `a = admitted` successful mailbox attempts and `m = usedMailboxes` mailboxes with at least one successful attempt, each Return Begin publishes State plus Continuation, except that its first State per mailbox contains the empty String. Thus:

```text
beginRoots = a * (S + C) - m * (S - 24)
```

Return Begin publication and Return resume-root import both equal `beginRoots`; KEEP Begin publication and resume-root import are zero. Total publication copy bytes are `16*24 + completed*S + beginPublication`. Initialization accounts for the first term: the host recreates the runtime after warmup and initializes 16 mailboxes, and each initialization invokes the handler and publishes one empty State ([load_host.c](../../experiments/AgentLang.MailboxLoad/load_host.c#L437-L479), [load_host.c](../../experiments/AgentLang.MailboxLoad/load_host.c#L1300-L1335), [mailbox_runtime.c](../../src/AgentLang.Llvm/native/mailbox_runtime.c#L2799-L2857)). Runtime reset means warmup handler/copy counters are excluded. The bank's committed-copy count is its serialized `used_bytes`, the sum of root extents; it does not include root descriptor metadata ([owning_bank.c](../../src/AgentLang.Llvm/native/owning_bank.c#L352-L461), [owning_bank.c](../../src/AgentLang.Llvm/native/owning_bank.c#L508-L521)).

With no post-callback failures, `handlerInvocations = 16 + 2a` (one Begin and one Resume per successful attempt), and `returnedOutputDescriptors = 16 + 3a` (one initialization output, two Begin outputs, and one Resume output per attempt). The original zero-retained trials fit those equalities. A validator that also requires zero `handlerFailures`, however, must not be used to infer that every runtime rejection happens before the callback.

## Corrected formula for retained-capacity rejections

Let `r = rejectionReasons.retainedCapacity`. Under this host and the valid fixed fixture, these rejections occur after Begin enters the handler: the pre-callback Begin checks can return text/scratch/busy or invalid statuses, while `al_owning_byte_store_begin` only opens a transaction. The current host configures 65,536 bytes per retained bank, and each bank has two root descriptors; at the fixed maximum payload the State-plus-Continuation extent is 24,608 bytes. Therefore the valid fixed-fixture flow has no pre-callback retained-capacity rejection under this configuration. A retained-capacity result can instead follow the callback, from KEEP's State-fits check or RETURN's output staging ([load_host.c](../../experiments/AgentLang.MailboxLoad/load_host.c#L22-L24), [load_host.c](../../experiments/AgentLang.MailboxLoad/load_host.c#L437-L479), [mailbox_runtime.c](../../src/AgentLang.Llvm/native/mailbox_runtime.c#L2362-L2384), [mailbox_runtime.c](../../src/AgentLang.Llvm/native/mailbox_runtime.c#L2895-L2955)).

Each such Begin has already incremented the invocation count. Its two callback outputs passed slice validation, so both output descriptors are counted even though publication/state-fit then fails; the runtime increments `handlerFailures`, and the host records a rejection without incrementing `admitted`. The Begin's scratch lease is released and no publication is committed ([mailbox_runtime.c](../../src/AgentLang.Llvm/native/mailbox_runtime.c#L2430-L2503), [mailbox_runtime.c](../../src/AgentLang.Llvm/native/mailbox_runtime.c#L2521-L2552), [mailbox_runtime.c](../../src/AgentLang.Llvm/native/mailbox_runtime.c#L2934-L2955), [load_host.c](../../experiments/AgentLang.MailboxLoad/load_host.c#L827-L873)). The corrected exact counters are:

```text
handlerInvocations          = 16 + 2a + r
handlerFailures             = r
returnedOutputDescriptors   = 16 + 3a + 2r
```

Publication formulas remain based on successful admitted/completed transitions:

```text
beginPublicationCopyBytes = Return ? beginRoots : 0
resumeRootImportBytes     = Return ? beginRoots : 0
publicationCopyBytes      = 16*24 + completed*S + beginPublicationCopyBytes
```

For Return, each resume imports both previously published roots by their extents; the stack runtime increments `input_copy_bytes` by each imported extent, and the mailbox runtime caps the resume-root counter at the sum of those root extents. For KEEP, associated resume reads attached roots and does not add to `resumeRootImportBytes` ([owning_stack_runtime.c](../../src/AgentLang.Llvm/native/owning_stack_runtime.c#L382-L403), [mailbox_runtime.c](../../src/AgentLang.Llvm/native/mailbox_runtime.c#L2554-L2562), [mailbox_runtime.c](../../src/AgentLang.Llvm/native/mailbox_runtime.c#L2664-L2764)).

## Scope and validation limits

The parent result validator requires `errors=0`, `timedOut=0`, and no pending work, and it reconciles admitted attempts with completed/error/timeout outcomes. Thus a failed I/O after Begin admission cannot pass this validator as a successful run. The native host separately counts successful Begin admission only after `al_mailbox_begin_text` returns OK ([load_host.c](../../experiments/AgentLang.MailboxLoad/load_host.c#L857-L873), [load_host.c](../../experiments/AgentLang.MailboxLoad/load_host.c#L1081-L1108), [Measure-MailboxLoad.ps1](../../scripts/Measure-MailboxLoad.ps1#L607-L690)).

The `r` correction is exact for retained-capacity Begin rejections in this fixed typed flow. It does not by itself generalize handler counters to post-callback scratch-capacity failures, which are also possible in other modules/configurations and can have different descriptor counts. The original fixture's reported `retainedCapacity=0` remains valid; that result does not prove the unadjusted equalities for runs with post-callback capacity rejection. No measurements or tests were run for this review.

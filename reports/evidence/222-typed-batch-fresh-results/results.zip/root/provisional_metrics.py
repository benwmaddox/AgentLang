"""Record a complete trace prefix; no correctness or terminal result is inferred."""
from collections import Counter
import hashlib
import json
from pathlib import Path

study = Path(__file__).resolve().parents[1]
trace = study / 'traces/retained.jsonl'
lines = trace.read_bytes().splitlines(keepends=True)
if lines and not lines[-1].endswith(b'\n'):
    lines.pop()
rows = [json.loads(line) for line in lines]
exchanges = [row for row in rows if row.get('event') == 'exchange']
errors = Counter()
for row in exchanges:
    response = row.get('response') or {}
    canonical = response.get('canonical')
    if canonical:
        value = json.loads(canonical)
        if value.get('ok') is False:
            errors[(value.get('error') or {}).get('code', 'unspecified')] += 1
report = {
    'status': 'provisional trace prefix; correctness and finalization not inferred',
    'prefixSha256': hashlib.sha256(b''.join(lines)).hexdigest(),
    'prefixBytes': sum(map(len, lines)),
    'completeRecordCount': len(rows),
    'exchangeCount': len(exchanges),
    'operations': dict(sorted(Counter(row['operation'] for row in exchanges).items())),
    'requestWireBytes': sum((row.get('request') or {}).get('wireUtf8Bytes', 0) for row in exchanges),
    'responseWireBytes': sum((row.get('response') or {}).get('wireUtf8Bytes', 0) for row in exchanges),
    'runtimeErrors': dict(sorted(errors.items())),
    'sessionEndPresent': any(row.get('event') == 'session-end' for row in rows),
}
out = study / 'root' / f"provisional-retained-prefix-{len(exchanges):03d}.json"
assert not out.exists(), 'Never overwrite an observed prefix receipt'
out.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report))

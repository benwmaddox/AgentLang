from pathlib import Path
import hashlib
import json

study = Path(__file__).resolve().parents[1]
score_path = study / 'outcomes/language/retained/20261011T131255Z-01/score.json'
score = json.loads(score_path.read_text(encoding='utf-8-sig'))
trace = study / 'traces/retained.jsonl'
rows = [json.loads(line) for line in trace.read_bytes().splitlines()]
exchanges = [row for row in rows if row.get('event') == 'exchange']
end = next(row for row in reversed(rows) if row.get('event') == 'session-end')
review = study / 'root/retained-source-review.md'
assert end['terminationKind'] == 'host-close' and end['hostExitCode'] == 0 and end['runtimeExitCode'] == 0
assert score['caseCounts'] == {'expected': 9, 'executed': 9, 'passed': 9}
assert review.is_file()
summary = {
    'arm': 'retained', 'status': 'behavior correct; full edit acceptance rejected',
    'behavior': score['caseCounts'], 'creatorRegressions': score['retainedCreatorCounts'],
    'persistedSuite': score['suite']['testAllResponse']['text'],
    'rawAutomatedPassed': score['automatedPassed'],
    'failedRawGates': [key for key, passed in score['gates'].items() if passed is False],
    'nominalGateAdjudication': 'frozen textual parser retains legal field semicolons; exact runtime nominal metadata checks passed',
    'preservationAccepted': False,
    'preservationFinding': 'inherited renew-batch-step/errors later-change.old-id changed from 30000000-0000-0000-0000-000000000001 to 33000000-0000-0000-0000-000000000001',
    'libraryPublished': score['batchContract']['libraryPassed'] and score['batchContract']['step']['libraryPassed'],
    'normalFinalization': True,
    'exchanges': len(exchanges),
    'requestWireBytes': sum(row['request']['wireUtf8Bytes'] for row in exchanges),
    'responseWireBytes': sum(row['response']['wireUtf8Bytes'] for row in exchanges),
    'startedUtc': rows[0]['startedUtc'], 'finishedUtc': end['finishedUtc'],
    'traceSha256': hashlib.sha256(trace.read_bytes()).hexdigest(),
    'reviewSha256': hashlib.sha256(review.read_bytes()).hexdigest(),
    'actorFingerprintAfterScore': score['actorProjectFingerprint'],
    'sourceUnchangedDuringScore': score['actorProjectUnchangedDuringScore'],
    'baselineUnchangedDuringScore': score['baselineProjectUnchangedDuringScore'],
    'copyUnchangedDuringScore': score['scoringProjectCopyUnchangedDuringScore'],
    'reported311Correction': 'cumulative executions: targeted5+2, full-suite152, failed-tests rerun152; persisted suite152',
}
out = study / 'root/retained-outcome.json'
assert not out.exists()
out.write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary, indent=2))

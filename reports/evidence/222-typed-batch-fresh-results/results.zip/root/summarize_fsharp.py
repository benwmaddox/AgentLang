from pathlib import Path
import hashlib
import json

study = Path(__file__).resolve().parents[1]
score_path = study / 'outcomes/conventional/run-20261011T132036Z-01/score-summary.json'
score = json.loads(score_path.read_text(encoding='utf-8-sig'))
result = score['participant']
trace = study / 'traces/fsharp.jsonl'
rows = [json.loads(line) for line in trace.read_bytes().splitlines()]
exchanges = [row for row in rows if row.get('event') == 'exchange']
end = next(row for row in reversed(rows) if row.get('event') == 'session-end')
review = study / 'root/fsharp-source-review.md'
assert score['status'] == 'pass' and result['executedCaseCount'] == result['passedCaseCount'] == 9
assert end['terminationKind'] == 'host-close' and end['hostExitCode'] == end['runtimeExitCode'] == 0
assert 'Decision: accepted edit.' in review.read_text(encoding='utf-8')
validation = next(json.loads(row['response']['canonical']) for row in reversed(exchanges) if row['operation'] == 'validate')
assert validation['ok'] is True
summary = {
    'arm': 'fsharp', 'status': 'behavior and full edit acceptance passed',
    'behavior': {'expected': 9, 'executed': result['executedCaseCount'], 'passed': result['passedCaseCount']},
    'rawAutomatedPassed': True, 'preservationAccepted': True,
    'fixedValidationPassed': True, 'normalFinalization': True,
    'participantTestsExcludedFromScorer': result['selfTestsIncluded'] is False,
    'exchanges': len(exchanges),
    'requestWireBytes': sum(row['request']['wireUtf8Bytes'] for row in exchanges),
    'responseWireBytes': sum(row['response']['wireUtf8Bytes'] for row in exchanges),
    'startedUtc': rows[0]['startedUtc'], 'finishedUtc': end['finishedUtc'],
    'traceSha256': hashlib.sha256(trace.read_bytes()).hexdigest(),
    'reviewSha256': hashlib.sha256(review.read_bytes()).hexdigest(),
    'sourceUnchangedDuringScore': result['participantSourceUnchanged'],
    'copyUnchangedDuringBuild': result['scoringCopyBuildUnchanged'],
    'copyUnchangedDuringScore': result['scoringCopyRunUnchanged'],
    'suiteCountLimit': 'Validator prints inherited scenario text; reviewed one added regression is not a new reported suite-count metric',
}
out = study / 'root/fsharp-outcome.json'
assert not out.exists()
out.write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary, indent=2))

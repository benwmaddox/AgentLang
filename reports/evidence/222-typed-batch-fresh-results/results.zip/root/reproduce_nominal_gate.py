"""Reproduce a frozen textual gate defect without changing scorer or actor."""
import ast
import json
from pathlib import Path
import re

repo = Path(__file__).resolve().parents[3]
source = repo / 'experiments/AgentLang.SubagentTrials/typed-batch-failure-216/oracle/score_failure.py'
tree = ast.parse(source.read_text(encoding='utf-8-sig'))
function = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'failure_type_contract')
namespace = {'re': re, 'FAILURE_TYPE': 'SubscriptionRenewalFailure',
             'EXPECTED_FAILURE_FIELDS': [('index', 'Int'), ('old-id', 'SubscriptionId'), ('cause', 'BusinessError')]}
exec(compile(ast.Module(body=[function], type_ignores=[]), str(source), 'exec'), namespace)
newline = 'record SubscriptionRenewalFailure {\n field index: Int\n field old-id: SubscriptionId\n field cause: BusinessError\n}\n'
semicolon = newline.replace(': Int\n', ': Int;\n').replace(': SubscriptionId\n', ': SubscriptionId;\n').replace(': BusinessError\n', ': BusinessError;\n')
plain = namespace['failure_type_contract'](newline)
punctuated = namespace['failure_type_contract'](semicolon)
assert plain['passed'] and not punctuated['passed']
report = {'status': 'reproduced frozen source-format false negative; no gate or candidate changed',
          'newlineSource': newline, 'semicolonSource': semicolon,
          'newlineGate': plain, 'semicolonGate': punctuated,
          'runtimeGrammarSource': 'src/AgentLang.Core/FlowParser.fs:1254',
          'runtimeGrammar': 'Flow/2 record fields accept newline or semicolon separators',
          'independentTypedObservation': 'Frozen scorer separately validates exact Int/SubscriptionId/BusinessError metadata in all five error fixtures'}
out = repo / '.agentlang/typed-batch-comparison-220/root/nominal-gate-repro.json'
assert not out.exists()
out.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(report['status'])

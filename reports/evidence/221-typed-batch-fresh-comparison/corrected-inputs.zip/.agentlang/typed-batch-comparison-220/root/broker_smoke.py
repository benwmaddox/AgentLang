"""Run corrected V2 launchers against disposable baselines, including normal close."""
import json
from pathlib import Path
import shutil
import subprocess

repo = Path(__file__).resolve().parents[3]
study = repo / '.agentlang/typed-batch-comparison-220'
scratch = study / 'root/broker-smoke'
assert not scratch.exists(), 'Never overwrite broker smoke evidence'
scratch.mkdir()
results = {}
for arm, operation in [('retained', 'help'), ('fsharp', 'inspect')]:
    project = scratch / arm / 'project'
    shutil.copytree(study / 'baselines' / arm, project)
    trace = scratch / arm / 'trace.jsonl'
    original = (study / f'launchers/{arm}.ps1').read_text()
    lines = original.splitlines()
    replacements = {
        '$repositoryRoot =': f"$repositoryRoot = '{repo.as_posix()}'",
        '$projectPath =': f"$projectPath = '{project.as_posix()}'",
        '$tracePath =': f"$tracePath = '{trace.as_posix()}'",
    }
    for prefix, replacement in replacements.items():
        assert sum(line.startswith(prefix) for line in lines) == 1
        lines = [replacement if line.startswith(prefix) else line for line in lines]
    launcher = scratch / arm / 'launch.ps1'
    launcher.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    command = ['pwsh', '-NoProfile', '-File', str(launcher)]
    run = subprocess.run(command, input=json.dumps({'op': operation}) + '\n' + json.dumps({'op': 'host.close'}) + '\n',
                         text=True, capture_output=True, timeout=180)
    (scratch / arm / 'stdout.jsonl').write_text(run.stdout, encoding='utf-8')
    (scratch / arm / 'stderr.txt').write_text(run.stderr, encoding='utf-8')
    assert run.returncode == 0, run.stderr
    audit = subprocess.run(['pwsh', '-NoProfile', '-File', str(repo / 'scripts/Audit-SubagentTrialTerminationV2.ps1'),
                            '-TracePath', str(trace)], text=True, capture_output=True, timeout=60)
    (scratch / arm / 'audit.stdout.json').write_text(audit.stdout, encoding='utf-8')
    (scratch / arm / 'audit.stderr.txt').write_text(audit.stderr, encoding='utf-8')
    assert audit.returncode == 0, audit.stderr
    results[arm] = {'exitCode': run.returncode, 'auditExitCode': audit.returncode,
                    'command': command, 'trace': str(trace)}
out = {'status': 'passed', 'preparationOnly': True, 'participantsDispatchedInCorrectedAttempt': 0, 'arms': results}
(study / 'root/broker-smoke.json').write_text(json.dumps(out, indent=2) + '\n', encoding='utf-8')
print(json.dumps(out))

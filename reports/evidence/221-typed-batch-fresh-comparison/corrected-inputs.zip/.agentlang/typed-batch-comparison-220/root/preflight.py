"""Exercise the actual fixed actor projects before freeze; never launch a participant."""
import json
import os
from pathlib import Path
import subprocess

repo = Path(__file__).resolve().parents[3]
study = repo / '.agentlang/typed-batch-comparison-220'
out = study / 'root/preflight.json'
assert not out.exists(), 'Do not overwrite preflight evidence'
env = dict(os.environ)
temp = study / 'root/preflight-temp'
temp.mkdir(exist_ok=True)
env.update(MSBuildEnableWorkloadResolver='false', TEMP=str(temp), TMP=str(temp))
results = {}
for arm, runtime, dll, extra, requests in [
    ('retained', 'agentlang', 'AgentLang.Cli.dll', ['--filesystem', 'virtual', '--clock', '2000-01-01T00:00:00Z'],
     [{'op': 'test-all'}, {'op': 'describe', 'word': 'subscription.renew-batch'}]),
    ('fsharp', 'conventional', 'AgentLang.Conventional.Cli.dll', ['--validation-project', 'SubscriptionBatch.Conventional.fsproj'],
     [{'op': 'inspect'}, {'op': 'validate'}]),
]:
    command = ['dotnet', str(study / 'runtime' / runtime / dll), '--project', str(study / 'actors' / arm), *extra, '--jsonl']
    run = subprocess.run(command, input=''.join(json.dumps(row) + '\n' for row in requests),
                         text=True, capture_output=True, env=env, timeout=180)
    (study / f'root/preflight-{arm}.stdout.jsonl').write_text(run.stdout, encoding='utf-8')
    (study / f'root/preflight-{arm}.stderr.txt').write_text(run.stderr, encoding='utf-8')
    rows = [json.loads(line) for line in run.stdout.splitlines()]
    results[arm] = {'command': command, 'exitCode': run.returncode, 'responseCount': len(rows),
                    'allOk': all(row.get('ok') is True for row in rows)}
    assert run.returncode == 0 and len(rows) == 2 and results[arm]['allOk'], f'{arm} preflight failed'
out.write_text(json.dumps({'status': 'passed', 'participantsDispatched': 0, 'preparationOnly': True,
                           'arms': results}, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'status': 'passed', 'arms': results}))

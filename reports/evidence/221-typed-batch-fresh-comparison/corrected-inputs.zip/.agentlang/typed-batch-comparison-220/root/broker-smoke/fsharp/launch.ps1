#requires -Version 7.0
$ErrorActionPreference = 'Stop'
$repositoryRoot = 'D:/code/AgentLang'
$hostScriptPath = Join-Path $repositoryRoot 'scripts/Start-SubagentTrialHostV2.ps1'
$cliDll = Join-Path $repositoryRoot '.agentlang/typed-batch-comparison-220/runtime/conventional/AgentLang.Conventional.Cli.dll'
$projectPath = 'D:/code/AgentLang/.agentlang/typed-batch-comparison-220/root/broker-smoke/fsharp/project'
$tracePath = 'D:/code/AgentLang/.agentlang/typed-batch-comparison-220/root/broker-smoke/fsharp/trace.jsonl'
$tempPath = Join-Path $repositoryRoot '.agentlang/typed-batch-comparison-220/root/scratch/temp'
$tmpPath = Join-Path $repositoryRoot '.agentlang/typed-batch-comparison-220/root/scratch/tmp'
[IO.Directory]::CreateDirectory($tempPath) | Out-Null
[IO.Directory]::CreateDirectory($tmpPath) | Out-Null
$env:MSBuildEnableWorkloadResolver = 'false'
$env:TEMP = $tempPath
$env:TMP = $tmpPath
$hostArguments = @{
    CliDll = $cliDll
    ProjectPath = $projectPath
    TracePath = $tracePath
    AllowedOperations = @('inspect', 'read', 'search', 'patch', 'replace', 'validate')
    Profile = 'conventional'
    Capabilities = @()
    ClockValue = '2000-01-01T00:00:00Z'
    MaxRequestBytes = 262144
    MaxResponseBytes = 524288
    ExchangeTimeoutMilliseconds = 120000
    MaxExchanges = 100
}
$hostArguments.Add('AdditionalCliArguments', @('--validation-project', 'SubscriptionBatch.Conventional.fsproj', '--max-requests', '100'))
& $hostScriptPath @hostArguments

$ErrorActionPreference = 'Stop'
$repositoryRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../../'))
$hostScriptPath = Join-Path $repositoryRoot 'scripts/Start-SubagentTrialHostV2.ps1'
$cliDll = Join-Path $repositoryRoot '.agentlang/typed-batch-comparison-220/runtime/agentlang/AgentLang.Cli.dll'
$projectPath = Join-Path $repositoryRoot '.agentlang/typed-batch-comparison-220/actors/retained'
$tracePath = Join-Path $repositoryRoot '.agentlang/typed-batch-comparison-220/traces/retained.jsonl'
$tempPath = Join-Path $repositoryRoot '.agentlang/typed-batch-comparison-220/root/scratch/temp'
$tmpPath = Join-Path $repositoryRoot '.agentlang/typed-batch-comparison-220/root/scratch/tmp'
[IO.Directory]::CreateDirectory($tempPath) | Out-Null
[IO.Directory]::CreateDirectory($tmpPath) | Out-Null
$env:MSBuildEnableWorkloadResolver = 'false'
$env:TEMP = $tempPath
$env:TMP = $tmpPath
$hostArguments = @{
    CliDll = $cliDll
    ProjectPath = $projectPath
    TracePath = $tracePath
    AllowedOperations = @('help', 'words', 'source', 'tests', 'define', 'test', 'test-all', 'commit', 'storage.status', 'task.begin', 'task.status', 'task.commit', 'describe', 'search', 'eval', 'context', 'dependencies', 'callers', 'failed-tests', 'examples', 'effects', 'type-of', 'history', 'task.abort')
    Profile = 'agentlang'
    Capabilities = @()
    ClockValue = '2000-01-01T00:00:00Z'
    MaxRequestBytes = 262144
    MaxResponseBytes = 524288
    ExchangeTimeoutMilliseconds = 120000
    MaxExchanges = 100
}
& $hostScriptPath @hostArguments

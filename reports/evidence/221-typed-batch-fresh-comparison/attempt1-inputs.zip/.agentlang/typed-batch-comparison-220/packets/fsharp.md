# Launch details

From the repository root, run: powershell -NoProfile -ExecutionPolicy Bypass -File .agentlang/typed-batch-comparison-220/launchers/fsharp.ps1

Assigned project path: .agentlang/typed-batch-comparison-220/actors/fsharp

Fixed validation project: SubscriptionBatch.Conventional.fsproj, resolved inside the assigned project path.

Permitted files:
- Domain.fs: only the related nominal failure type. Preserve the existing DomainError record and all error-to-code/message mappings unchanged.
- Operations.fs: only the batch result, batch state/helper, and related implementation.
- SelfTests.fs: only necessary adaptations and new regressions.

All other project files are read-only.

# Common participant bootstrap

The human authorizes edits only to your assigned isolated trial project and local
test execution through the supplied broker. You are an external coding agent.
After reading your assigned packet, launch its exact command once. Keep its
operation list, limits and project path unchanged. Use only that broker for
project discovery, edits and tests. Do not inspect siblings, reports, hidden
oracles, control solutions or other agents; do not use web tools or other agents.
Disclose any non-broker tool use. Run one session, at most 100 exchanges.

Poll the same live handle after observation timeouts. Do not restart for silence,
repeat uncertain mutations or kill the process to finish. When finished, send
`{"op":"host.close"}` and observe terminal status. This is a transport control
handled by the host, separate from the runtime operation list below. If closure
fails, report the failure and preserve the session/trace rather than inventing a
runtime command. Your final response should report changes, validation and any
non-broker use or unresolved failures.

# Conventional F# interface

Allowed runtime operations: `inspect,read,search,patch,replace,validate`.

Use the existing project vocabulary and the fixed local validation project
specified in your launcher. Only assigned implementation/tests files may change;
project/dependency files and unrelated APIs are frozen. Keep the model pure:
no external I/O, providers, mutable global state or packages.

Maintain the existing subscription batch API in your assigned typed project.
Inspect current functions and tests before editing, and reuse existing behavior.

Keep the batch's Store, renewal-list and Instant inputs. Change its result error
to a nominal SubscriptionRenewalFailure record with an integer input index,
nominal SubscriptionId old ID and the existing business error as cause. Use the
project's existing naming conventions (index/old-id/cause in AgentLang;
Index/OldId/Cause in F#).

Return the FIRST failing input's zero-based position, old subscription ID and
unchanged exact underlying error code and message. Preserve validation/processing
order. Stop on that error. Successful complete Store results, list order,
unrelated entities and the caller's input must remain intact. Empty input succeeds
unchanged; an intermediate Store is not success.

Update the batch, existing step helper and related internal state as needed.
Preserve their identities/names. Related new helpers/types are permitted. Keep
other domain/renewal APIs, plan enum, input record, tests and examples unchanged.
Keep inherited batch/helper test names, fixtures and scenarios. Necessary result
annotations, typed failure expectations and counter/state construction may adapt;
preserve successful state expectations and underlying causes. Do not remove cases,
replace scenarios or weaken assertions. Add regression coverage for later-item
failure and first-error precedence/localization.

Run relevant tests and the full suite. AgentLang definitions must retain library
qualification; F# must pass the existing fixed local validation project. Finish
with a concise result and close your broker using the provided transport control.

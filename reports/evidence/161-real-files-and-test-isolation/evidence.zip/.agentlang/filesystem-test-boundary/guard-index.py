import json, subprocess, sys
from pathlib import Path

repo = Path(__file__).resolve().parents[2]
path = Path(__file__).with_name('baseline-index-guard.json')
entries = {}
for record in subprocess.check_output(['git','ls-files','-s','-z'],cwd=repo).split(b'\0'):
    if not record: continue
    header, name = record.split(b'\t',1)
    name = name.decode('utf-8')
    if name.startswith(('docs/', 'reports/')) or name == 'README.md': continue
    entries[name] = header.decode('ascii')
if len(sys.argv) > 1 and sys.argv[1] == 'verify':
    assert entries == json.loads(path.read_text(encoding='utf-8')), 'Frozen code index changed'
    print(f'PASS unchanged frozen code index: {len(entries)} paths')
else:
    assert not path.exists(), 'Do not overwrite the baseline guard'
    path.write_text(json.dumps(entries,indent=2)+'\n',encoding='utf-8')
    print(f'Frozen code index: {len(entries)} paths')

# Real filesystem boundary review

Read-only review of the current uncommitted changes in `FileSystem.fs`, `Runtime.fs`, `IrInterpreter.fs`, CLI configuration, and the new CLI filesystem boundary test. No builds or tests were run because the script gates are active. No implementation files were changed.

## Findings

**P2 — The reparse-point check does not inspect the configured project root or its ancestors.** `FileSystem.validateReparsePoints` walks only the path segments returned by `Path.GetRelativePath(root, fullPath)`, starting at `root` (`src/AgentLang.Core/FileSystem.fs:77-102`). A project directory that is itself a symlink/junction therefore passes validation and file access follows it. This is consistent with treating the configured project root as trusted, but it makes “beneath the project directory” a logical-path guarantee rather than physical containment. Either reject/resolve reparse points in the root chain or state that the root is trusted and keep the containment claim scoped accordingly. The code also documents the check’s TOCTOU limit; the CLI group does not exercise an in-root symlink/reparse point.

**P2 — The new CLI test does not exercise the real `file.exists?` branch or real missing-file diagnostics.** It covers real read/write, virtual isolation, test setup/publication, permission separation, invalid UTF-8, and a relative traversal rejection (`tests/AgentLang.Cli.Tests/Program.fs:576-676`). `FileSystem.fileExists` has separate `File.GetAttributes` and missing/directory handling (`FileSystem.fs:146-156`), and `readText` maps host missing-file exceptions to `EFFECT_FILE_NOT_FOUND` (`:131-144`). Add focused assertions for those real-provider behaviors when the gates permit.

**Scope gap — Test-file dictionary replacements remain a proposal.** Provider isolation is implemented, but there is no source-level dictionary overlay. `docs/TEST-FILE-DEPENDENCIES.md` labels its `test-file`/`override fn` syntax as non-executable and still leaves shared attachment persistence and exact syntax unresolved. Keep this boundary explicit in the final handoff; provider simulation does not satisfy the separate dependency-replacement request.

## Confirmed behavior

- All language test execution routes converge on `checkedByTest` through `runTestsFor`, including load-time library requalification and commit/replacement gates. `checkedByTest` creates a fresh virtual provider for setup plus test body; the expected-value expression gets its own fresh virtual trace. Thus test provider state does not come from the surrounding real or virtual Engine mode (`Runtime.fs:2202-2204, 2258-2263, 2396-2403`).
- Normal eval and examples use the Engine’s configured mode; both the Engine default and CLI default are `FileSystemMode.Real`. Explicit `--filesystem virtual` preserves simulation for experiments. Repository test Engine constructors now explicitly request virtual mode, and the benchmark runner does too.
- `IsTest` selects `engineTestCapabilities` only for test and expectation traces. Other traces use normal `capabilities`; `PreflightEffects` runs before interpreter effect dispatch, and `InvokeEffect` routes to the provider afterward (`Runtime.fs:1652-1667`). An explicit `--test-allow` does not grant permission to real eval. With no `--test-allow`, tests intentionally inherit `--allow`, as CLI help and docs state; an absent `--allow`/`--test-allow` still denies effects.
- Effect counts are updated before provider invocation, so failed host I/O remains counted. Provider errors become structured language diagnostics; real reads use strict UTF-8 with optional UTF-8 BOM handling, invalid bytes map to `EFFECT_FILE_ENCODING`, and invalid/unencodable text is rejected before a write (`Runtime.fs:1671-1704`, `FileSystem.fs:131-174`).
- Task abort restores dictionary/storage and the virtual-file snapshot. Real filesystem writes are outside that snapshot and are not undone; the abort response says only dictionary changes rolled back, while README explicitly says task abort and snapshots do not undo real external writes (`Runtime.fs:5112, 5151-5177`, `README.md:339`).

## Validation status

Not run: builds, CLI tests, or script gates. The new CLI test is useful coverage, but this review is static only. Test-file overlay semantics, nested routing, cleanup, and original-body coverage protection remain unimplemented and unvalidated.

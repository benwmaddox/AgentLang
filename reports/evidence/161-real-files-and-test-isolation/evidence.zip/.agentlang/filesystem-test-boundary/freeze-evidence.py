from pathlib import Path
import hashlib, json, subprocess, zipfile

repo = Path(__file__).resolve().parents[2]
evidence = repo / '.agentlang/filesystem-test-boundary'
out = repo / 'reports/evidence/161-real-files-and-test-isolation'
gate = json.loads((evidence / 'full-validation-001.json').read_text(encoding='utf-8-sig'))
assert len(gate['checks']) == 37 and all(c['exitCode'] == 0 for c in gate['checks'])
changed = subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=repo, text=True).splitlines()
sources = sorted(set(changed + ['src/AgentLang.Core/FileSystem.fs', 'docs/TEST-FILE-DEPENDENCIES.md']))
# The report references this archive; exclude it to avoid a circular hash.
sources = [s for s in sources if not s.startswith('reports/')]
roots = {evidence}
for report in evidence.rglob('*.json'):
    try:
        obj = json.loads(report.read_text(encoding='utf-8-sig'))
    except (ValueError, UnicodeError):
        continue
    def visit(value):
        if isinstance(value, dict):
            for k, v in value.items():
                if k.lower().endswith('root') and isinstance(v, str):
                    p = Path(v)
                    if p.is_dir() and p.is_relative_to(repo / '.agentlang'):
                        roots.add(p)
                visit(v)
        elif isinstance(value, list):
            for v in value: visit(v)
    visit(obj)
files = set()
for root in roots:
    for p in root.rglob('*'):
        if p.is_file() and not {'bin', 'obj', '.git', 'runtime', 'compiler-temp', 'tmp'} & set(p.relative_to(root).parts):
            if p.suffix.lower() not in {'.dll', '.exe', '.pdb', '.so', '.a', '.o', '.zip'}:
                files.add(p)
digest = lambda data: hashlib.sha256(data).hexdigest()
entries = {p.relative_to(repo).as_posix(): (p, p.read_bytes()) for p in sorted(files)}
for name in sources:
    entries[name] = (None, subprocess.check_output(['git','show',':'+name],cwd=repo))
manifest = {name: {'bytes':len(data), 'sha256':digest(data)} for name, (_, data) in entries.items()}
out.mkdir(parents=True, exist_ok=True)
archive = out / 'evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for name, (_, data) in entries.items(): z.writestr(name, data)
    z.writestr('entry-manifest.json', json.dumps(manifest, indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
    for name, (path, data) in entries.items():
        assert digest(z.read(name)) == manifest[name]['sha256']
        current = path.read_bytes() if path is not None else subprocess.check_output(['git','show',':'+name],cwd=repo)
        assert digest(current) == manifest[name]['sha256'], f'source changed: {name}'
metadata = {
    'archive':'evidence.zip', 'entries':len(entries)+1, 'bytes':archive.stat().st_size,
    'sha256':digest(archive.read_bytes()),
    'sourceBaseHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
    'sourceFiles':sources, 'evidenceRoots':sorted(p.relative_to(repo).as_posix() for p in roots),
    'validationChecks':len(gate['checks']), 'allEntriesAndSourcesHashChecked':True,
    'sourceRepresentation':'Frozen Git index; subsequent test-file overlay edits remain unstaged and are excluded from this milestone.',
    'exclusions':'Build binaries, bin/obj, runtime copies, compiler temporary files, and the referencing report.'
}
(out/'archive.json').write_text(json.dumps(metadata,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in metadata.items() if k not in {'sourceFiles','evidenceRoots'}},indent=2))

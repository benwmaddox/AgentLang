# Native owning mailbox component validation

These logs preserve the direct C checks run against the owning mailbox
controller and the existing ABI3 regression route. No .NET build was run.

## Toolchain and invocation

Compiler: `C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\Llvm\bin\clang.exe`, Clang 19.1.5. The MSVC environment was initialized with
`C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat`.
All builds used `--target=x86_64-pc-windows-msvc`, C11, `-Wall -Wextra
-Werror`, and `-DAL_MAILBOX_RUNTIME_TESTING` where the mailbox controller was
linked. The runner set `TEMP` and `TMP` to the ignored compile-check directory
so Clang's temporary objects stayed on the writable workspace volume.

The compiler executable was invoked by its full path. Before compiling,
`TEMP` and `TMP` were set to
`D:\code\AgentLang\.agentlang\owning-stack-003\compile-check`. The exact
owning mailbox compile and run commands were:

```text
& "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\Llvm\bin\clang.exe" --target=x86_64-pc-windows-msvc -std=c11 -Wall -Wextra -Werror -O0 -DAL_MAILBOX_RUNTIME_TESTING -I D:\code\AgentLang\src\AgentLang.Llvm\native D:\code\AgentLang\src\AgentLang.Llvm\native\owning_mailbox_test.c D:\code\AgentLang\src\AgentLang.Llvm\native\mailbox_runtime.c D:\code\AgentLang\src\AgentLang.Llvm\native\mailbox_runtime_windows.c D:\code\AgentLang\src\AgentLang.Llvm\native\arena_runtime.c D:\code\AgentLang\src\AgentLang.Llvm\native\owning_stack_runtime.c D:\code\AgentLang\src\AgentLang.Llvm\native\owning_bank.c -o D:\code\AgentLang\.agentlang\owning-stack-003\compile-check\owning_mailbox_capacity_O0.exe
D:\code\AgentLang\.agentlang\owning-stack-003\compile-check\owning_mailbox_capacity_O0.exe
& "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\Llvm\bin\clang.exe" --target=x86_64-pc-windows-msvc -std=c11 -Wall -Wextra -Werror -O2 -DAL_MAILBOX_RUNTIME_TESTING -I D:\code\AgentLang\src\AgentLang.Llvm\native D:\code\AgentLang\src\AgentLang.Llvm\native\owning_mailbox_test.c D:\code\AgentLang\src\AgentLang.Llvm\native\mailbox_runtime.c D:\code\AgentLang\src\AgentLang.Llvm\native\mailbox_runtime_windows.c D:\code\AgentLang\src\AgentLang.Llvm\native\arena_runtime.c D:\code\AgentLang\src\AgentLang.Llvm\native\owning_stack_runtime.c D:\code\AgentLang\src\AgentLang.Llvm\native\owning_bank.c -o D:\code\AgentLang\.agentlang\owning-stack-003\compile-check\owning_mailbox_capacity_O2.exe
D:\code\AgentLang\.agentlang\owning-stack-003\compile-check\owning_mailbox_capacity_O2.exe
& "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\Llvm\bin\clang.exe" --target=x86_64-pc-windows-msvc -std=c11 -Wall -Wextra -Werror -O1 -fsanitize=undefined -fsanitize-trap=undefined -fno-sanitize-recover=undefined -DAL_MAILBOX_RUNTIME_TESTING -I D:\code\AgentLang\src\AgentLang.Llvm\native D:\code\AgentLang\src\AgentLang.Llvm\native\owning_mailbox_test.c D:\code\AgentLang\src\AgentLang.Llvm\native\mailbox_runtime.c D:\code\AgentLang\src\AgentLang.Llvm\native\mailbox_runtime_windows.c D:\code\AgentLang\src\AgentLang.Llvm\native\arena_runtime.c D:\code\AgentLang\src\AgentLang.Llvm\native\owning_stack_runtime.c D:\code\AgentLang\src\AgentLang.Llvm\native\owning_bank.c -o D:\code\AgentLang\.agentlang\owning-stack-003\compile-check\owning_mailbox_capacity_ubsan.exe
D:\code\AgentLang\.agentlang\owning-stack-003\compile-check\owning_mailbox_capacity_ubsan.exe
```

Each build ran its output executable directly. All three compiler and test
processes exited 0; compiler stderr was empty. The owning test stdout for O0,
O2, and trap-UBSan is saved in the corresponding `owning-mailbox-*.stdout.log`
files. Each paired `owning-mailbox-*.stderr.log` file is empty. Each stdout
contains:

```text
owning_mailbox_test: passed
```

The test covers UTF-8 ASCII and supplementary-plane conversion to canonical
UTF-16, malformed UTF-8 rejection, aggregate scratch rejection before staging
or callback execution, token and active-bank preservation on callback failure,
retry with the same token, output publication, duplicate completion rejection,
per-turn byte counters, and disposal.

The exact ABI3 regression compile and run commands were:

```text
& "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\Llvm\bin\clang.exe" --target=x86_64-pc-windows-msvc -std=c11 -Wall -Wextra -Werror -O0 -DAL_MAILBOX_RUNTIME_TESTING -I D:\code\AgentLang\src\AgentLang.Llvm\native D:\code\AgentLang\src\AgentLang.Llvm\native\mailbox_runtime_test.c D:\code\AgentLang\src\AgentLang.Llvm\native\mailbox_runtime.c D:\code\AgentLang\src\AgentLang.Llvm\native\mailbox_runtime_windows.c D:\code\AgentLang\src\AgentLang.Llvm\native\arena_runtime.c D:\code\AgentLang\src\AgentLang.Llvm\native\owning_stack_runtime.c D:\code\AgentLang\src\AgentLang.Llvm\native\owning_bank.c -o D:\code\AgentLang\.agentlang\owning-stack-003\compile-check\mailbox_runtime_test_O0.exe
D:\code\AgentLang\.agentlang\owning-stack-003\compile-check\mailbox_runtime_test_O0.exe
& "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\Llvm\bin\clang.exe" --target=x86_64-pc-windows-msvc -std=c11 -Wall -Wextra -Werror -O2 -DAL_MAILBOX_RUNTIME_TESTING -I D:\code\AgentLang\src\AgentLang.Llvm\native D:\code\AgentLang\src\AgentLang.Llvm\native\mailbox_runtime_test.c D:\code\AgentLang\src\AgentLang.Llvm\native\mailbox_runtime.c D:\code\AgentLang\src\AgentLang.Llvm\native\mailbox_runtime_windows.c D:\code\AgentLang\src\AgentLang.Llvm\native\arena_runtime.c D:\code\AgentLang\src\AgentLang.Llvm\native\owning_stack_runtime.c D:\code\AgentLang\src\AgentLang.Llvm\native\owning_bank.c -o D:\code\AgentLang\.agentlang\owning-stack-003\compile-check\mailbox_runtime_test_O2.exe
D:\code\AgentLang\.agentlang\owning-stack-003\compile-check\mailbox_runtime_test_O2.exe
```

It was built and run at O0 and O2 with the same strict C flags. Both test
processes exited 0 with empty stderr; their complete stdout (70 checks and the
passing summary for each build) is preserved as
`abi3-mailbox-O0.stdout.log` and `abi3-mailbox-O2.stdout.log`. The paired
`abi3-mailbox-*.stderr.log` files are empty.

The exact bank component compile and run commands were:

```text
& "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\Llvm\bin\clang.exe" --target=x86_64-pc-windows-msvc -std=c11 -Wall -Wextra -Werror -O0 -I D:\code\AgentLang\src\AgentLang.Llvm\native D:\code\AgentLang\src\AgentLang.Llvm\native\owning_bank_test.c D:\code\AgentLang\src\AgentLang.Llvm\native\owning_bank.c D:\code\AgentLang\src\AgentLang.Llvm\native\owning_stack_runtime.c -o D:\code\AgentLang\.agentlang\owning-stack-003\compile-check\owning_bank_test_O0.exe
D:\code\AgentLang\.agentlang\owning-stack-003\compile-check\owning_bank_test_O0.exe
& "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\Llvm\bin\clang.exe" --target=x86_64-pc-windows-msvc -std=c11 -Wall -Wextra -Werror -O2 -I D:\code\AgentLang\src\AgentLang.Llvm\native D:\code\AgentLang\src\AgentLang.Llvm\native\owning_bank_test.c D:\code\AgentLang\src\AgentLang.Llvm\native\owning_bank.c D:\code\AgentLang\src\AgentLang.Llvm\native\owning_stack_runtime.c -o D:\code\AgentLang\.agentlang\owning-stack-003\compile-check\owning_bank_test_O2.exe
D:\code\AgentLang\.agentlang\owning-stack-003\compile-check\owning_bank_test_O2.exe
```

Both bank processes exited 0 with empty stderr and reported
`owning bank: 44 checks passed`; stdout is preserved in
`owning-bank-O0.stdout.log` and `owning-bank-O2.stdout.log`. The paired
`owning-bank-*.stderr.log` files are empty.

## Source hashes

SHA-256 hashes were computed when this evidence archive was assembled, after
the direct runs. The run commands did not capture hashes before compilation,
so these values identify the current workspace snapshot only; they do not
prove that every listed file was unchanged between each run and archive time.
The ABI header was edited during integration work, and the generated-module
acceptance run must establish its own frozen source identity.

```text
9c3ea5a238b0bf7689d16b6c346db1651a9d06f61d69aa3a0b2a73fa0e003d9f  src/AgentLang.Llvm/native/mailbox_runtime.c
738570817a23232654fd3aa184dc3cee1db5da46023944909859a1d0a9ef8653  src/AgentLang.Llvm/native/mailbox_runtime.h
0a01e3982f0db3e16b65fee36a16939df98940d82ef5c191c772757aebae4a31  src/AgentLang.Llvm/native/owning_bank.c
d16feea50a7f1a267ca6a89347798144130e29232ac877292c337f808351293c  src/AgentLang.Llvm/native/owning_bank.h
f5f785b78d4f36f606fcc540c0e89a0ce6c66f7160b9e45b4716a49e04aa7f84  src/AgentLang.Llvm/native/owning_mailbox_test.c
1cde7a800c6e7cdf85fc5c26de8e8beef5ad24e61dfdb1959589230e2c62cd0b  src/AgentLang.Llvm/native/owning_bank_test.c
7c6681d7ace9037786af4dd83dc5db70974e1560bd7844a6d88d1e38efd4bdf5  src/AgentLang.Llvm/native/owning_mailbox_abi.h
44b43d8a0ada2faefb81c700b3fd2b43fa94dc5585a47473fa97e4eb1f37b84a  src/AgentLang.Llvm/native/owning_stack_runtime.c
785c4ab720ba1e50caa25b08c0317686193a9dee87af3f009096ecb31c41b00c  src/AgentLang.Llvm/native/owning_stack_runtime.h
e93330d1675c66d70d1befe76ef8ca6fb3f9d4ac0f247bfb55063c5838f4e3a7  src/AgentLang.Llvm/native/arena_runtime.c
d557baba7713f91f525f9ec4f5a15c49fe972dec798d1c1ac9a770e806b714b0  src/AgentLang.Llvm/native/arena_runtime.h
97ca4a9fdca6f5fdb2a7347272158cfcd722da62adb4737f0bb207a5577685d9  src/AgentLang.Llvm/native/mailbox_runtime_windows.c
35c2f2f55109cc3499b799cd04f695c962264e4da42b79fad42221f911e5e41a  src/AgentLang.Llvm/native/mailbox_runtime_test.c
dd39d846c17758674f9dfe77e9c5ebce05adfe555a539c37f5e1be710a2ac5a5  src/AgentLang.Llvm/native/module_abi.h
```

The owning mailbox generated-module acceptance run is separate; these direct
component checks do not stand in for compiling and dispatching the generated
owning callback module.

# Generated owning mailbox callback review

Read-only source review of `OwningStackAot.fs` generated callbacks and
`owning_mailbox_abi.h`; no competing build was run. The emitter worker was
notified of the actionable gap below.

## Finding resolved during review

The generated `agentlang_owning_mailbox_preflight` rejects overlap among the
context, stack, bitmaps, trace, input/output slice arrays and input payloads,
but does not include the immutable module descriptor, owning layout, type
array or field array in its span table. A direct native caller can pass
`outputs` pointing into writable layout/type metadata. Preflight then
returns success and the callback clears its output slots before measuring
the first input, corrupting the shared layout. This can turn a defined
invalid request into an invalid metadata read or incorrect scan. Reject
output overlap with module/layout/type/field spans before the first output
write; checking these regions also protects immutable metadata from input
payload aliasing. The emitter worker added all four metadata spans and
checked type/field byte counts. The resulting maximum span count is 14,
within the fixed table of 16. Controller-created arrays were already
disjoint, but this exported callback accepts arbitrary native arguments and
needs its own boundary.

## Verified path

The callback invokes the C preflight before output writes or
`al_owning_measure_external_value`. Preflight fixes role/count/type indexes,
checks every supplied input pointer span, sums extents in `uint64_t`, and
rejects a total above `UINT32_MAX` or working-stack capacity before any
payload scanner call. On success, the callback marks every output slice
invalid, measures complete inputs, reserves the checked aggregate, imports
each input once and transfers descriptors into its entry frame. It only
writes returned output slice metadata after all outputs pass type/bounds
checks. On failure before that final write, every output remains invalid.

The callback leaves successful output payloads in working scratch. It does
not call `al_owning_release_to`; the controller stages them into the inactive
bank before reset. The generated output slice carries type index, source
offset and owner end, with layout measurement and exact extent performed by
the bank. The output path materializes a zero-width projected `Empty` into an
8-byte standalone token before returning its slice. The fixed mailbox
signatures currently return nominal State/Continuation records, so that
Empty branch is general emitter behavior rather than a role-specific case.

`compileMailbox` requires the three verified bodies to share the exact
program snapshot. `makeProgramInfoForBodies` unions reachable functions and
types, and the emitter assigns indexes once from the shared type-ID-sorted
layout. Generated C metadata and LLVM callbacks use the same indexes and
the module returns one layout pointer. `owning_mailbox_abi.h` fixes the x64
external and output slice widths. The metadata source and LLVM frames compile
into one library; no graph conversion or managed per-turn adapter is involved.

The integration harness still needs to demonstrate actual O0/O2 callback
invocation through C, including direct invalid boundary requests and
retained output validity after scratch reset. This source review does not
claim those execution results.

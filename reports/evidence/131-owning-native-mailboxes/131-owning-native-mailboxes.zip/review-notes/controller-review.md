# Native owning mailbox controller review

Read-only review of the compile-ready `mailbox_runtime.[ch]`,
`owning_mailbox_abi.h`, and `owning_bank.[ch]` draft. No build or execution was
run for this review; the owner is adding direct execution tests.

## Findings sent to the owner

1. **Fixed: String header used payload bytes instead of UTF-16 code units.**
   `al_owning_text_write` put `payload_bytes` at header offset zero, while the
   owning serializer and scanner require code-unit count. Even `"A"` produced
   header `10` instead of `1` and failed the immediate staged-value measure.
   The owner changed it to `(payload_bytes - 8) / 2` with header/extent parity
   checks. ASCII and supplementary-plane direct cases are being added.

2. **Being corrected: rewind accounting label.** The controller increments
   `owning_arena_rewind_bytes` by the final cursor returned at turn reset.
   Compiler-proved inner scope/frame rewinds are absent from that value, so
   calling it total rewind bytes overstates the metric. The owner is renaming
   the public metric `turn_reset_bytes`; compiler-level rewinds remain a
   separate trace. This is a fidelity issue, not a lifetime safety bug.

## Contract assessment

The owning route uses the same runtime object, mailbox slot state, token
validation/minting, thread/busy gate and scratch-lease counters as ABI3. Its
payload execution helper is representation-specific; there is no second
token controller or graph conversion. Begin checks sequence exhaustion before
entry execution. Resume validates token before text conversion or handler
execution. The output descriptor list is staged in the inactive byte bank
while working scratch is live; bank publication is the sole output payload
copy. The controller commits the bank, poisons the old bank, resets scratch,
then updates pending/token state with no further fallible operation. Failed
execution or stage aborts inactive metadata and retains the active bank and
token. Bank stage preflights the full root list, capacity and disjointness
before copying payloads.

The new layout reserves shared scratch, two bitmaps, UTF-16 staging, two byte
banks and two root arrays per mailbox, plus controller/slot storage. It uses
checked alignment and size arithmetic, and the reported retained/scratch/
staging/controller categories sum to the allocation. The UTF-8 scanner
rejects overlong forms, surrogate scalars, invalid continuations and values
above U+10FFFF, and bounds UTF-16 staging before writing. External public
arguments reject span overflow, runtime-storage overlap and mutual argument
overlap. Input import borrows active bank roots plus one converted staging
String, avoiding bank-to-staging concatenation; publication copy accounting
comes from the bank's committed byte count.

The generated callback must still enforce its own all-input aggregate
preflight before measuring a value; this controller's
`al_owning_validate_inputs` measures its internally assembled slices in
sequence and is not a substitute for the callback's native boundary check.
Current execution tests have not yet established that generated callbacks
match the C ABI, accept the canonical String bytes, or return stable output
slices. Those are the remaining focused integration checks, not findings
against the controller code reviewed here.

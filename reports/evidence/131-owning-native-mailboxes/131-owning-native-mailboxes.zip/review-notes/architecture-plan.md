# Owning String mailbox: shared native contract

This is a bounded integration plan, not an implementation. Keep one native
mailbox lifecycle controller in `mailbox_runtime.c`. Its existing ABI3 graph
path remains a regression control. Add an owning payload adapter to that
controller; do not convert owning values to graph nodes or call the managed
`OwningStackCompiledProgram.ExecuteIntoCore` host adapter.

## Decision: output slices, then one bank publication

The generated owning entry should return **descriptors into its live working
arena**, not a flat retained byte buffer. The controller immediately calls
`al_owning_byte_store_stage_stack_values` with those descriptors, commits the
inactive bank, and only then resets/poisons the working arena. The bank's
complete-batch validation and one payload copy replace the current wrapper's
`al_owning_publish` copy. There is no intermediate output-byte copy or second
descriptor bank. Bank root metadata is written once by the bank. The extra
layout scan is validation, not publication traffic.

This route preserves a useful boundary for the later kept-associated policy:
the callback can finish with live descriptors, and a future policy may retain
the actual arena lease instead of publishing. The first implementation uses
return-at-suspension and must copy every retained output into the bank before
reset. A provider holding a working-arena pointer forbids reset/reuse until
its lease ends; both suspension policies remain required before choosing one.

## Generated module ABI

Add `src/AgentLang.Llvm/native/owning_mailbox_abi.h` with a versioned,
immutable module descriptor and exactly three role entries. Its layout pointer
is the *one shared* `al_owning_layout` for all entries. The callback uses C
types, caller-owned memory, and no allocations:

```c
typedef struct al_owning_external_slice {
  const uint8_t *bytes;        /* one complete serialized value */
  uint32_t extent_bytes;
  uint32_t type_index;         /* index into module->layout, not type_id */
} al_owning_external_slice;

typedef int32_t (*al_owning_mailbox_execute_fn)(
    al_owning_stack_context *context,
    const al_owning_external_slice *inputs, uint32_t input_count,
    al_owning_bank_stack_slice *outputs, uint32_t output_capacity);

typedef struct al_owning_mailbox_entry {
  uint32_t input_count, output_count;
  uint32_t input_type_indexes[3], output_type_indexes[2];
  al_owning_mailbox_execute_fn execute;
} al_owning_mailbox_entry;

typedef struct al_owning_mailbox_module {
  uint32_t abi_version, struct_size;
  const al_owning_layout *layout;
  al_owning_mailbox_entry entries[3]; /* initialize, begin, resume */
} al_owning_mailbox_module;

const al_owning_mailbox_module *agentlang_owning_mailbox_module(void);
```

The `al_owning_bank_stack_slice` is the draft bank's existing
`{type_index, source_offset_bytes, source_owner_end_bytes}` shape. An entry
checks its exact input count/types and output capacity, imports the bounded
inputs into its arena, invokes its generated frame, verifies result type and
descriptor bounds, materializes a projected zero-extent `Empty` as an 8-byte
standalone token, and fills the output slices. It leaves successful scratch
live. On failure it returns the owning context status and exposes no valid
output list; the controller resets scratch. The controller calls
`al_owning_begin` exactly once per invocation, before the callback. Existing
`agentlang_owning_execute` remains as the flat, managed-host-facing adapter.

F# adds `OwningStackAot.compileMailbox(toolchain, optimization,
outputDirectory, verifiedInit, verifiedBegin, verifiedResume)` (or an
equivalent named three-body record). Require all three verified bodies to
belong to the same immutable verified program snapshot. Generalize
`makeProgramInfo` to validate the union of three roots and reachable functions,
emit one copy of each reachable function and three entry frames into one LLVM
module, run `ArenaLifetime` on each entry and reachable function, and emit
one global type layout plus the module descriptor/getter. `TypeId` identifies
the value in serialized bytes; `type_index` indexes this emitted layout.
Construct indexes once after unioning all used scalar/record/String types and
children (sorted by existing deterministic type ID), rather than merging
per-entry layout arrays. The existing single-body `compile` keeps its API.
Follow `LlvmAot.compileModule`'s one-DLL/multiple-entry pattern when linking
the LLVM module with owning runtime, bank and mailbox C sources.

Validate the fixed role signatures against metadata before initializing a
controller: initialize `String -> State`, begin `State String -> State
Continuation`, resume `State Continuation String -> State`, with common
State/Continuation nominal type IDs across entries. The implementation may
name those types through explicit configuration, but cannot infer identity
from layout indexes alone. Reject zero or mismatched type IDs, unsupported
types, missing function pointers, mismatched ABI/struct sizes, invalid layout
indices, duplicate/inconsistent role metadata. ABI3's `al_module_desc`
cannot represent owning String and should stay unchanged.

The native callback's input boundary must preflight **all** slices before
measuring the first value: count/table pointer, each pointer/span and nonzero
extent where required, expected type index, checked 64-bit aggregate extent,
aggregate `<= UINT32_MAX` and stack capacity, and source disjointness from
working arena/context/bitmaps/output descriptor metadata. Then measure each
complete value with the shared layout, require measured extent exactly equals
the supplied extent and embedded type ID matches, reserve total input bytes,
and import each root directly once. Do not reuse the current flat wrapper's
order, which measures individual host extents before its final
`input.bytes` aggregate check. Native callers are untrusted too; the managed
adapter's checks do not substitute for this preflight. The bank independently
preflights all outputs and destination/source disjointness before copying.

## Controller and caller-owned storage

Extend `mailbox_runtime.h/.c` with an owning initialization/requirements
variant, typed text entry points, and a borrowed owning state view. Suggested
public names are `al_mailbox_get_owning_storage_requirements`,
`al_mailbox_runtime_init_owning`, `al_mailbox_init_text`,
`al_mailbox_begin_text`, `al_mailbox_resume_text`, and
`al_mailbox_get_owning_state_view`. Text arguments are `(const uint8_t
*utf8, uint32_t byte_count)`; resume also takes the existing token. The
owning state view exposes `const al_owning_byte_bank *` and its typed roots,
borrowed until the next mutation/disposal. Keep the ABI3 integer APIs and
views intact. Share the same slot lifecycle, thread confinement, busy guard,
token mint/validation, generation and failure accounting. Branch only at the
payload execution/storage helpers; do not implement a second controller.

For each owning mailbox slot, place one `al_owning_byte_store` with two bank
byte buffers and two root arrays in caller storage. Let its `active_index` be
the sole owning-bank selection (no second independent slot index). The
controller owns one reusable `al_owning_stack_context` plus working bytes,
initialization/poison bitmaps, optional trace and bounded external-text
staging in the same caller allocation. Fixed input/output slice arrays of
three/two entries can live in the controller. Storage sizing uses checked
alignment, multiplication and addition; it includes both banks for every
mailbox, root arrays, working stack, bitmaps, text staging, controller and
metadata. Reject overlap/alignment errors and undersized storage at init.
No mailbox turn calls managed code or an allocator.

The active bank roots are borrowed directly as input slices: begin passes
State + newly converted String, resume passes State + Continuation + newly
converted String. Initialize passes only String. Convert external UTF-8 to
the owning runtime's canonical serialized UTF-16 String in pre-reserved
caller-owned staging. Validate full UTF-8, scalar/length overflow, destination
capacity, pointer span and storage non-aliasing before touching mailbox state
or invoking a handler. The generated entry imports those slices once into
working scratch. Do not first concatenate active roots into another buffer.
The conversion bytes and scratch import bytes are distinct counters.

After lifecycle/token preflight, a turn takes the busy/scratch lease, opens
the inactive bank, begins the owning context, calls the matching generated
entry, stages the entire output slice list while scratch is live, commits the
bank, resets/poisons scratch, then updates initialized/pending state and
token. The commit and token/state update must be one nonfailing tail: check
token/generation exhaustion and all other fallible conditions before bank
commit. On any earlier failure, abort inactive metadata, reset scratch and
release lease; active bank and pending token remain unchanged. In particular,
stale/cross-runtime/cross-mailbox tokens are rejected before handler or bank
work. Successful retained roots have bank-relative offsets and owner ends,
never working-stack or caller-request pointers. Old active bytes can be
poisoned after commit, with no active root still referring to them.

Keep `al_owning_byte_store` as the publication primitive; move the draft
source/header into the runtime build or include it as an additional runtime
source. If the existing toolchain helper accepts only one C file, extend its
link inputs or use the existing multi-source compilation route. Do not split
the owning module, bank and controller into separately loaded production
DSOs.

## Scope and acceptance

Affected production files: `OwningStackAot.fs`, the new owning module ABI
header, `mailbox_runtime.h/.c`, `owning_stack_runtime.h/.c` only if a missing
bounded helper is needed, the owning bank header/source, and LLVM toolchain
link/resource registration. Focused native harness and fixture live under
`experiments/AgentLang.NativeDispatch`, `tests/fixtures/native-conformance`
and a focused verification script. The ABI3 module, its oracle and tests are
regression controls, not a representation bridge.

First acceptance: fresh O0/O2 builds run String initialize → begin/pending →
resume, verify exact serialized root bytes/types after scratch reset and
reuse, and show two interleaved mailboxes with no cross-owner roots. Handler,
scratch and retained-capacity failures leave active roots and pending token
unchanged; stale/cross tokens never invoke the handler. Count UTF conversion,
input imports, construction/duplication, publication copy, descriptor
transfers, rewinds, scratch high-water and caller-reserved storage separately.
For each success, published bytes equal the sum of committed serialized root
extents; the output path performs one payload copy into the inactive bank.
Do not call overlapping descriptor extents unique live payload. Validate
native pointer/range, aggregate input and layout-index failures directly.
Run the focused owning mailbox test O0/O2 plus the existing ABI3 mailbox
control, then the repository release gate once implementation is complete.

Defer kept-associated arena leases, real asynchronous provider ownership,
general container/source syntax, a generic representation framework,
performance comparison and additional production controllers. They are
separate work after the first native return-at-suspension path, not evidence
that its policy comparison is finished.

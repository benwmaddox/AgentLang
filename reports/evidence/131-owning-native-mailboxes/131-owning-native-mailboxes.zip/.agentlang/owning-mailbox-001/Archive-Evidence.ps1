param(
    [switch]$TerminalConfirmed
)

# One-time Milestone 131 evidence archive. Do not run until the parent confirms
# the regression sequence is terminal; the switch is an additional guard.
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

if (-not $TerminalConfirmed) {
    throw "Packaging is gated: rerun with -TerminalConfirmed only after the parent confirms the full regression sequence is terminal."
}

$repoRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot "..\.."))
$integrationRunId = "8fcf8a73ff8c4f0fa2679309533ef25e"
$priorFailureRunId = "2f5096b886cf4008a2109e17fea89898"
$allocationAuditRunId = "01750af91dfa4d668403d94eb3b6e10e"
$mailboxRoot = Join-Path $repoRoot ".agentlang\owning-mailbox-001"
$integrationRoot = Join-Path $mailboxRoot "integration-run-$integrationRunId"
$regressionRoot = Join-Path $mailboxRoot "regression-validation"
$checksPath = Join-Path $regressionRoot "checks.json"
$fullGateRoot = $regressionRoot
$fullGatePath = Join-Path $fullGateRoot "validation.json"
$llvmRegressionLog = Join-Path $regressionRoot "llvm-regression.log"
$preliminaryLlvmBuildLog = Join-Path $mailboxRoot "llvm-project-build.log"
$evidenceRoot = Join-Path $repoRoot "reports\evidence\131-owning-native-mailboxes"
$archiveName = "131-owning-native-mailboxes.zip"
$indexName = "storage-index.json"

function Get-Sha256([string]$Path) {
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Get-RepoRelative([string]$Path) {
    $full = [System.IO.Path]::GetFullPath($Path)
    $relative = [System.IO.Path]::GetRelativePath($repoRoot, $full)
    if ([System.IO.Path]::IsPathRooted($relative) -or
        $relative -eq ".." -or
        $relative.StartsWith("..\", [System.StringComparison]::Ordinal) -or
        $relative.StartsWith("../", [System.StringComparison]::Ordinal)) {
        throw "Evidence source is outside the repository: $full"
    }
    return $relative.Replace('\', '/')
}

function Get-ContainedPath([string]$Root, [string]$Candidate) {
    $rootFull = [System.IO.Path]::GetFullPath($Root).TrimEnd([char[]]@('\', '/'))
    $candidateFull = [System.IO.Path]::GetFullPath($Candidate)
    $prefix = $rootFull + [System.IO.Path]::DirectorySeparatorChar
    if (-not $candidateFull.StartsWith($prefix, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Path escapes its approved root: $candidateFull"
    }
    return $candidateFull
}

function Get-TreeSha256([string]$Root, [string[]]$RelativeFiles) {
    $hash = [System.Security.Cryptography.IncrementalHash]::CreateHash([System.Security.Cryptography.HashAlgorithmName]::SHA256)
    $utf8 = [System.Text.UTF8Encoding]::new($false)
    $delimiter = [byte[]]@(0)
    $sorted = @($RelativeFiles)
    [System.Array]::Sort($sorted, [System.StringComparer]::Ordinal)
    try {
        foreach ($relative in $sorted) {
            $portable = $relative.Replace('\', '/')
            $hash.AppendData($utf8.GetBytes($portable))
            $hash.AppendData($delimiter)
            $path = Join-Path $Root ($portable.Replace('/', [System.IO.Path]::DirectorySeparatorChar))
            $stream = [System.IO.File]::OpenRead($path)
            $buffer = [byte[]]::new(65536)
            try {
                while (($read = $stream.Read($buffer, 0, $buffer.Length)) -gt 0) {
                    if ($read -eq $buffer.Length) {
                        $hash.AppendData($buffer)
                    } else {
                        $chunk = [byte[]]::new($read)
                        [System.Array]::Copy($buffer, $chunk, $read)
                        $hash.AppendData($chunk)
                    }
                }
            } finally {
                $stream.Dispose()
            }
            $hash.AppendData($delimiter)
        }
        return [System.Convert]::ToHexString($hash.GetHashAndReset()).ToLowerInvariant()
    } finally {
        $hash.Dispose()
    }
}

foreach ($requiredPath in @($integrationRoot, $checksPath, $fullGatePath, $llvmRegressionLog)) {
    if (-not (Test-Path -LiteralPath $requiredPath -PathType Leaf) -and
        -not (Test-Path -LiteralPath $requiredPath -PathType Container)) {
        throw "Required evidence input is missing: $requiredPath"
    }
}

# The final focused integration must be complete, pass all checks at both
# optimization levels, and match the source snapshot on disk.
$integrationEvidencePath = Join-Path $integrationRoot "integration-evidence.json"
if (-not (Test-Path -LiteralPath $integrationEvidencePath -PathType Leaf)) {
    throw "Final integration evidence is missing: $integrationEvidencePath"
}
$integrationEvidence = Get-Content -LiteralPath $integrationEvidencePath -Raw | ConvertFrom-Json
if (-not $integrationEvidence.passed -or $integrationEvidence.runId -ne $integrationRunId -or
    $integrationEvidence.checks.Count -ne 180 -or
    @($integrationEvidence.checks | Where-Object { -not $_.passed }).Count -ne 0) {
    throw "Final focused integration is not a clean 180-check pass."
}
if ($integrationEvidence.nativeRuns.Count -ne 2) {
    throw "Final focused integration does not contain exactly O0 and O2 native runs."
}
foreach ($nativeRun in $integrationEvidence.nativeRuns) {
    if ($nativeRun.optimization -notin @("O0", "O2") -or
        -not $nativeRun.result.passed -or
        $nativeRun.result.checks.Count -ne 122 -or
        @($nativeRun.result.checks | Where-Object { -not $_.passed }).Count -ne 0) {
        throw "Native $($nativeRun.optimization) evidence is not a clean 122-check pass."
    }
}
$beforeSources = @($integrationEvidence.sourceInputHashes.before)
$afterSources = @($integrationEvidence.sourceInputHashes.after)
if (-not $integrationEvidence.sourceInputHashes.unchanged -or
    $beforeSources.Count -ne 22 -or $afterSources.Count -ne 22) {
    throw "Final integration must record 22 unchanged source hashes."
}
$beforeByPath = @{}
foreach ($record in $beforeSources) {
    $relative = Get-RepoRelative ([string]$record.path)
    $beforeByPath[$relative] = ([string]$record.sha256).ToLowerInvariant()
}
$sourceRecords = [System.Collections.Generic.List[object]]::new()
foreach ($record in $afterSources) {
    $relative = Get-RepoRelative ([string]$record.path)
    $expected = ([string]$record.sha256).ToLowerInvariant()
    if (-not $beforeByPath.ContainsKey($relative) -or $beforeByPath[$relative] -ne $expected) {
        throw "Final integration source hashes differ before/after for $relative"
    }
    $currentPath = Join-Path $repoRoot ($relative.Replace('/', [System.IO.Path]::DirectorySeparatorChar))
    if ((Get-Sha256 $currentPath) -ne $expected) {
        throw "Current source no longer matches the final integration hash: $relative"
    }
    $sourceRecords.Add([pscustomobject]@{ path = $currentPath; relative = $relative; sha256 = $expected })
}
if ($beforeByPath.Count -ne 22) {
    throw "Final integration source hash paths are not unique."
}

# Packaging is held until the four-step terminal regression record and full
# repository gate are both green. checks.json is written incrementally, so a
# partial record intentionally fails this preflight.
$regressionChecks = @(Get-Content -LiteralPath $checksPath -Raw | ConvertFrom-Json)
if ($regressionChecks.Count -ne 4 -or
    @($regressionChecks | Where-Object { $_.exitCode -ne 0 }).Count -ne 0) {
    throw "Regression sequence is not terminal with four successful steps."
}
$expectedSteps = @(
    [ordered]@{ name = 'owning-stack'; executable = 'pwsh'; arguments = @('-NoProfile', '-File', 'scripts/Verify-NativeValueStack.ps1') },
    [ordered]@{ name = 'native-dispatch'; executable = 'pwsh'; arguments = @('-NoProfile', '-File', 'scripts/Verify-NativeDispatch.ps1', '-SerialBuild', '-SkipPackageAudit') },
    [ordered]@{ name = 'full-release'; executable = 'pwsh'; arguments = @('-NoProfile', '-File', 'scripts/Validate.ps1', '-SerialBuild', '-SkipPackageAudit', '-ReportPath', '.agentlang/owning-mailbox-001/regression-validation/validation.json') },
    [ordered]@{ name = 'llvm-regression'; executable = 'dotnet'; arguments = @('run', '--no-build', '-c', 'Release', '--project', 'tests/AgentLang.Llvm.Tests') }
)
$checkNames = @()
for ($index = 0; $index -lt $expectedSteps.Count; $index++) {
    $actual = $regressionChecks[$index]
    $expected = $expectedSteps[$index]
    $checkNames += [string]$actual.name
    if ([string]$actual.name -ne [string]$expected.name -or
        [string]$actual.executable -ne [string]$expected.executable -or
        @($actual.arguments).Count -ne @($expected.arguments).Count) {
        throw "Regression step $index does not match its expected name and command."
    }
    for ($argumentIndex = 0; $argumentIndex -lt $expected.arguments.Count; $argumentIndex++) {
        if ([string]$actual.arguments[$argumentIndex] -ne [string]$expected.arguments[$argumentIndex]) {
            throw "Regression command arguments differ for step $($expected.name)."
        }
    }
    if ([string]::IsNullOrWhiteSpace([string]$actual.log) -or
        -not (Test-Path -LiteralPath ([string]$actual.log) -PathType Leaf)) {
        throw "Regression step $($actual.name) is missing its recorded log."
    }
    $expectedLog = Join-Path $regressionRoot "$($expected.name).log"
    if ([System.IO.Path]::GetFullPath([string]$actual.log) -ne [System.IO.Path]::GetFullPath($expectedLog)) {
        throw "Regression step $($actual.name) points to an unexpected log path."
    }
    [void](Get-RepoRelative ([string]$actual.log))
}
$fullGate = Get-Content -LiteralPath $fullGatePath -Raw | ConvertFrom-Json
if (-not $fullGate.passed -or $fullGate.checks.Count -ne 37 -or
    @($fullGate.checks | Where-Object { $_.exitCode -ne 0 }).Count -ne 0) {
    throw "The full repository validation is not a clean 37-check pass."
}
$llvmLogText = Get-Content -LiteralPath $llvmRegressionLog -Raw
if ($llvmLogText -notmatch 'AgentLang\.Llvm\.Tests:\s*\d+\s+assertions passed') {
    throw "Current LLVM regression log does not report passing AgentLang.Llvm.Tests assertions."
}

# Regression log pointers identify the specific evidence runs to preserve.
$owningStackLog = Join-Path $regressionRoot "owning-stack.log"
$nativeDispatchLog = Join-Path $regressionRoot "native-dispatch.log"
foreach ($path in @($owningStackLog, $nativeDispatchLog)) {
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        throw "Required regression log is missing: $path"
    }
}
$owningStackMatch = [regex]::Match((Get-Content -LiteralPath $owningStackLog -Raw), 'Evidence:\s*(?<path>[^\r\n]+\.json)')
$nativeDispatchMatch = [regex]::Match((Get-Content -LiteralPath $nativeDispatchLog -Raw), 'EvidencePath=(?<path>[^\r\n]+\.json)')
if (-not $owningStackMatch.Success -or -not $nativeDispatchMatch.Success) {
    throw "Owning-stack/native-dispatch logs do not identify their evidence JSON."
}
$owningStackEvidencePath = [System.IO.Path]::GetFullPath($owningStackMatch.Groups['path'].Value.Trim())
$nativeDispatchEvidencePath = [System.IO.Path]::GetFullPath($nativeDispatchMatch.Groups['path'].Value.Trim())
$owningStackEvidence = Get-Content -LiteralPath $owningStackEvidencePath -Raw | ConvertFrom-Json
$nativeDispatchEvidence = Get-Content -LiteralPath $nativeDispatchEvidencePath -Raw | ConvertFrom-Json
if (-not $owningStackEvidence.passed -or -not $nativeDispatchEvidence.passed) {
    throw "Regression evidence referenced by the owning-stack/native-dispatch logs is not passing."
}

$componentValidationRoot = Join-Path $mailboxRoot "component-validation"
$componentReadmePath = Join-Path $componentValidationRoot "README.md"
if (-not (Test-Path -LiteralPath $componentReadmePath -PathType Leaf)) {
    throw "Component validation readme is missing."
}
$componentReadme = Get-Content -LiteralPath $componentReadmePath -Raw
if ($componentReadme -notmatch 'hashes\s+were\s+computed\s+when\s+this\s+evidence\s+archive\s+was\s+assembled,\s+after\s+the\s+direct\s+runs' -or
    $componentReadme -notmatch 'do\s+not\s+prove\s+that\s+every\s+listed\s+file\s+was\s+unchanged') {
    throw "Component validation must retain its retrospective-hash caveat."
}

$failedRunRoot = Join-Path $mailboxRoot "integration-run-$priorFailureRunId"
$allocationRunRoot = Join-Path $mailboxRoot "integration-run-$allocationAuditRunId"
foreach ($runRoot in @($failedRunRoot, $allocationRunRoot)) {
    if (-not (Test-Path -LiteralPath (Join-Path $runRoot "integration-evidence.json") -PathType Leaf)) {
        throw "Prior run evidence JSON is missing: $runRoot"
    }
}

if (Test-Path -LiteralPath $evidenceRoot) {
    $existing = @(Get-ChildItem -LiteralPath $evidenceRoot -Force)
    if ($existing.Count -ne 0) {
        throw "Evidence output already exists; refusing to overwrite: $evidenceRoot"
    }
} else {
    New-Item -ItemType Directory -Path $evidenceRoot | Out-Null
}
$stageRoot = Join-Path $evidenceRoot (".stage-" + [Guid]::NewGuid().ToString('N'))
$stageRoot = Get-ContainedPath $evidenceRoot $stageRoot
New-Item -ItemType Directory -Path $stageRoot | Out-Null
$zipPath = Get-ContainedPath $evidenceRoot (Join-Path $evidenceRoot $archiveName)
$script:archiveFiles = [System.Collections.Generic.List[object]]::new()
$script:archivePaths = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::Ordinal)

function Add-ArchiveFile(
    [string]$SourcePath,
    [string]$ArchiveRelative,
    [string]$Category,
    [string]$ExpectedSha256 = ""
) {
    $sourceFull = [System.IO.Path]::GetFullPath($SourcePath)
    if (-not (Test-Path -LiteralPath $sourceFull -PathType Leaf)) {
        throw "Required evidence file is missing: $sourceFull"
    }
    $sourceRelative = Get-RepoRelative $sourceFull
    $portable = $ArchiveRelative.Replace('\', '/')
    if ([System.IO.Path]::IsPathRooted($portable) -or
        $portable.Split('/') -contains '..' -or
        $portable.Split('/') -contains '' -or
        -not $script:archivePaths.Add($portable)) {
        throw "Archive path is rooted, invalid, or duplicated: $portable"
    }
    $extension = [System.IO.Path]::GetExtension($portable).ToLowerInvariant()
    if ($extension -in @('.exe', '.dll', '.pdb', '.obj', '.lib', '.so', '.a', '.o', '.dylib')) {
        throw "Binary/build output is not permitted in the evidence archive: $portable"
    }
    $segments = $portable.Split('/')
    if ($segments -contains 'bin' -or $segments -contains 'obj' -or
        $segments -contains 'dotnet-artifacts' -or $segments -contains 'repo-temp' -or
        $segments -contains 'native-O0' -or $segments -contains 'native-O2') {
        throw "Build cache/output tree is not permitted in the evidence archive: $portable"
    }
    $sourceHash = Get-Sha256 $sourceFull
    if ($ExpectedSha256 -and $sourceHash -ne $ExpectedSha256.ToLowerInvariant()) {
        throw "Source hash changed before archive copy: $sourceRelative"
    }
    $destination = Join-Path $stageRoot ($portable.Replace('/', [System.IO.Path]::DirectorySeparatorChar))
    New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
    Copy-Item -LiteralPath $sourceFull -Destination $destination
    $copiedInfo = Get-Item -LiteralPath $destination
    $copiedHash = Get-Sha256 $destination
    if ($copiedHash -ne $sourceHash -or $copiedInfo.Length -ne (Get-Item -LiteralPath $sourceFull).Length) {
        throw "Evidence copy verification failed: $portable"
    }
    $script:archiveFiles.Add([ordered]@{
        source = $sourceRelative
        archive = $portable
        category = $Category
        bytes = [long]$copiedInfo.Length
        sha256 = $copiedHash
    })
}

function Add-RunTextAndJson([string]$RunRoot, [string]$ArchivePrefix, [string]$Category) {
    $files = Get-ChildItem -LiteralPath $RunRoot -File | Where-Object {
        $_.Extension -in @('.txt', '.json')
    } | Sort-Object Name
    foreach ($file in $files) {
        Add-ArchiveFile $file.FullName "$ArchivePrefix/$($file.Name)" $Category
    }
}

function Add-GeneratedModuleArtifacts([string]$RunRoot, [string]$ArchivePrefix) {
    foreach ($optimization in @('O0', 'O2')) {
        $moduleRoot = Join-Path $RunRoot "module-$optimization"
        $manifestPath = Join-Path $moduleRoot 'owning-mailbox-module-manifest.json'
        if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) {
            throw "Generated module manifest is missing for ${optimization}: $manifestPath"
        }
        foreach ($file in (Get-ChildItem -LiteralPath $moduleRoot -File | Where-Object {
            $_.Extension -in @('.ll', '.c')
        } | Sort-Object Name)) {
            Add-ArchiveFile $file.FullName "$ArchivePrefix/module-$optimization/$($file.Name)" 'generated-module'
        }
        Add-ArchiveFile $manifestPath "$ArchivePrefix/module-$optimization/owning-mailbox-module-manifest.json" 'generated-module-manifest'
        $entryRoot = Join-Path $moduleRoot 'entries'
        foreach ($file in (Get-ChildItem -LiteralPath $entryRoot -File | Where-Object {
            $_.Name -like '*.frame.ll' -or $_.Name -like '*.verified-ir.txt'
        } | Sort-Object Name)) {
            Add-ArchiveFile $file.FullName "$ArchivePrefix/module-$optimization/entries/$($file.Name)" 'verified-entry-ir'
        }
    }
}

# Archive this bounded script and the final focused run's logs, generated
# source/IR and manifest; executable/library outputs are deliberately omitted.
Add-ArchiveFile $PSCommandPath '.agentlang/owning-mailbox-001/Archive-Evidence.ps1' 'archive-tooling'
Add-RunTextAndJson $integrationRoot "focused/$integrationRunId" 'focused-run'
Add-GeneratedModuleArtifacts $integrationRoot "focused/$integrationRunId"
foreach ($record in $sourceRecords) {
    Add-ArchiveFile $record.path "source-snapshots/$($record.relative)" 'final-focused-source' $record.sha256
}

# The component README labels its hashes retrospective; preserve that note
# without treating those values as test-time source identity.
foreach ($file in (Get-ChildItem -LiteralPath $componentValidationRoot -File | Sort-Object Name)) {
    Add-ArchiveFile $file.FullName "component-validation/$($file.Name)" 'direct-component-validation'
}
foreach ($name in @('architecture-plan.md', 'controller-review.md', 'callback-review.md')) {
    $path = Join-Path $mailboxRoot $name
    Add-ArchiveFile $path "review-notes/$name" 'review-note'
}

# Retain both the earlier failed native run and the allocation-audit run as
# clearly labeled historical evidence, without copying binaries or caches.
Add-RunTextAndJson $failedRunRoot "historical/failed-native-$priorFailureRunId" 'historical-failed-run'
Add-RunTextAndJson $allocationRunRoot "historical/allocation-audit-$allocationAuditRunId" 'historical-allocation-audit'

# Store terminal regression checks and each step log, using the exact paths
# named by checks.json. Include the current validation JSON and its sidecars.
Add-ArchiveFile $checksPath 'regression/checks.json' 'terminal-regression'
foreach ($check in $regressionChecks) {
    $name = ([string]$check.name) -replace '[^A-Za-z0-9._-]', '_'
    $logPath = [System.IO.Path]::GetFullPath([string]$check.log)
    Add-ArchiveFile $logPath "regression/logs/$name.log" 'terminal-regression-log'
}
Add-ArchiveFile $fullGatePath 'full-validation/validation.json' 'full-validation'
foreach ($sidecar in (Get-ChildItem -LiteralPath $regressionRoot -File -Filter 'validation.*.json' | Sort-Object Name)) {
    Add-ArchiveFile $sidecar.FullName "full-validation/$($sidecar.Name)" 'full-validation-sidecar'
}
if (Test-Path -LiteralPath $preliminaryLlvmBuildLog -PathType Leaf) {
    Add-ArchiveFile $preliminaryLlvmBuildLog 'supplementary/preliminary-llvm-project-build.log' 'preliminary-build-log'
}

foreach ($pair in @(
    @{ Path = $owningStackEvidencePath; Prefix = 'regression/owning-stack-run'; Category = 'owning-stack-regression' },
    @{ Path = $nativeDispatchEvidencePath; Prefix = 'regression/native-dispatch-run'; Category = 'native-dispatch-regression' }
)) {
    $runEvidence = Get-Item -LiteralPath $pair.Path
    $runRoot = $runEvidence.DirectoryName
    Add-RunTextAndJson $runRoot $pair.Prefix $pair.Category
}

$payloadPaths = @($script:archiveFiles | ForEach-Object { [string]$_.archive })
$payloadHash = Get-TreeSha256 $stageRoot $payloadPaths
$manifest = [ordered]@{
    formatVersion = 1
    milestone = 131
    scope = 'Owning native mailbox focused integration, direct component checks, historical failures, and terminal regression evidence.'
    focusedRunId = $integrationRunId
    focusedIntegration = [ordered]@{
        passed = [bool]$integrationEvidence.passed
        checksPassed = @($integrationEvidence.checks | Where-Object { $_.passed }).Count
        checksTotal = $integrationEvidence.checks.Count
        nativeO0Checks = 122
        nativeO2Checks = 122
        sourceSnapshotCount = $sourceRecords.Count
        sourceHashesMatchCurrent = $true
    }
    terminalRegression = [ordered]@{
        stepCount = $regressionChecks.Count
        allStepsPassed = $true
        stepNames = @($checkNames | Sort-Object)
        fullValidationPassed = [bool]$fullGate.passed
        fullValidationChecks = $fullGate.checks.Count
        llvmRegressionPassed = $true
    }
    componentHashNote = 'component-validation/README.md states its SHA-256 list was captured after direct tests and is retrospective, not a test-time source identity attestation.'
    uncompressedPayloadSha256 = $payloadHash
    uncompressedPayloadHashAlgorithm = 'SHA-256 of sorted UTF-8 relative path, NUL, raw file bytes, NUL; internal manifest excluded.'
    files = @($script:archiveFiles | Sort-Object { $_.archive })
}
$manifestPath = Join-Path $stageRoot 'manifest.json'
[System.IO.File]::WriteAllText($manifestPath, ($manifest | ConvertTo-Json -Depth 10), [System.Text.UTF8Encoding]::new($false))

Add-Type -AssemblyName System.IO.Compression
$zipStream = [System.IO.File]::Open($zipPath, [System.IO.FileMode]::CreateNew, [System.IO.FileAccess]::ReadWrite, [System.IO.FileShare]::None)
try {
    $zip = [System.IO.Compression.ZipArchive]::new($zipStream, [System.IO.Compression.ZipArchiveMode]::Create, $false)
    try {
        $stageFiles = @(Get-ChildItem -LiteralPath $stageRoot -File -Recurse | ForEach-Object {
            [pscustomobject]@{ FullName = $_.FullName; Relative = [System.IO.Path]::GetRelativePath($stageRoot, $_.FullName).Replace('\', '/') }
        } | Sort-Object Relative)
        foreach ($file in $stageFiles) {
            $entry = $zip.CreateEntry($file.Relative, [System.IO.Compression.CompressionLevel]::Optimal)
            $entry.LastWriteTime = [System.DateTimeOffset]::new(1980, 1, 1, 0, 0, 0, [System.TimeSpan]::Zero)
            $entryStream = $entry.Open()
            $inputStream = [System.IO.File]::OpenRead($file.FullName)
            try { $inputStream.CopyTo($entryStream) } finally { $inputStream.Dispose(); $entryStream.Dispose() }
        }
    } finally {
        $zip.Dispose()
    }
} finally {
    $zipStream.Dispose()
}

# Verify the packed bytes, byte lengths, entry set, manifest and payload digest
# independently from the staging files before publishing the storage index.
$zipHash = Get-Sha256 $zipPath
$zipReadStream = [System.IO.File]::OpenRead($zipPath)
try {
    $readZip = [System.IO.Compression.ZipArchive]::new($zipReadStream, [System.IO.Compression.ZipArchiveMode]::Read, $false)
    try {
        if ($readZip.Entries.Count -ne ($script:archiveFiles.Count + 1)) {
            throw 'ZIP entry count differs from payload manifest.'
        }
        foreach ($record in $script:archiveFiles) {
            $entry = $readZip.GetEntry([string]$record.archive)
            if ($null -eq $entry -or $entry.Length -ne [long]$record.bytes) {
                throw "ZIP entry missing or wrong size: $($record.archive)"
            }
            $entryStream = $entry.Open()
            $sha = [System.Security.Cryptography.SHA256]::Create()
            try { $entryHash = [System.Convert]::ToHexString($sha.ComputeHash($entryStream)).ToLowerInvariant() } finally { $sha.Dispose(); $entryStream.Dispose() }
            if ($entryHash -ne [string]$record.sha256) {
                throw "ZIP entry SHA-256 mismatch: $($record.archive)"
            }
        }
        $manifestEntry = $readZip.GetEntry('manifest.json')
        if ($null -eq $manifestEntry) { throw 'ZIP is missing its internal manifest.' }
        $manifestStream = $manifestEntry.Open()
        $manifestSha = [System.Security.Cryptography.SHA256]::Create()
        try { $manifestHash = [System.Convert]::ToHexString($manifestSha.ComputeHash($manifestStream)).ToLowerInvariant() } finally { $manifestSha.Dispose(); $manifestStream.Dispose() }
    } finally {
        $readZip.Dispose()
    }
} finally {
    $zipReadStream.Dispose()
}
if ((Get-Sha256 $zipPath) -ne $zipHash) {
    throw 'ZIP SHA-256 changed during verification.'
}
foreach ($record in $sourceRecords) {
    if ((Get-Sha256 $record.path) -ne $record.sha256) {
        throw "Source changed while packaging: $($record.relative)"
    }
}

$index = [ordered]@{
    formatVersion = 1
    phase = 'final'
    scope = $manifest.scope
    focusedRunId = $integrationRunId
    archive = $archiveName
    archiveSha256 = $zipHash
    manifestSha256 = $manifestHash
    uncompressedPayloadSha256 = $payloadHash
    uncompressedPayloadHashAlgorithm = $manifest.uncompressedPayloadHashAlgorithm
    archivedFileCount = $script:archiveFiles.Count
    focusedChecks = 180
    nativeChecksPerOptimization = 122
    terminalRegressionSteps = 4
    fullValidationChecks = 37
    files = @($script:archiveFiles | Sort-Object { $_.archive })
}
$indexPath = Join-Path $evidenceRoot $indexName
[System.IO.File]::WriteAllText($indexPath, ($index | ConvertTo-Json -Depth 10), [System.Text.UTF8Encoding]::new($false))
$indexHash = Get-Sha256 $indexPath
[System.IO.File]::WriteAllText((Join-Path $evidenceRoot "$archiveName.sha256"), "$zipHash  $archiveName`n", [System.Text.UTF8Encoding]::new($false))
[System.IO.File]::WriteAllText((Join-Path $evidenceRoot "$indexName.sha256"), "$indexHash  $indexName`n", [System.Text.UTF8Encoding]::new($false))
[System.IO.File]::WriteAllText((Join-Path $evidenceRoot 'uncompressed-payload.sha256'), "$payloadHash  $archiveName (payload digest; see index algorithm)`n", [System.Text.UTF8Encoding]::new($false))

# Remove only this invocation's contained temporary staging directory.
$stageRootFull = Get-ContainedPath $evidenceRoot $stageRoot
Remove-Item -LiteralPath $stageRootFull -Recurse -Force

[pscustomobject]@{
    archive = $zipPath
    archiveSha256 = $zipHash
    index = $indexPath
    indexSha256 = $indexHash
    archivedFiles = $script:archiveFiles.Count
    focusedChecks = 180
    nativeChecksPerOptimization = 122
    regressionSteps = 4
    fullValidationChecks = 37
    sourceHashesMatchedCurrent = $sourceRecords.Count
} | ConvertTo-Json -Depth 3

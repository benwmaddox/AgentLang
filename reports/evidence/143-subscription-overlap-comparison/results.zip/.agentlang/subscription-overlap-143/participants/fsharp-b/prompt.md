You are a fresh, independent participant. The human authorizes changes only to this assigned isolated project and its local tests. Use only the supplied broker for project discovery, authoring, evaluation, and testing. Your only permitted raw filesystem operation is reading this assigned prompt to verify its supplied SHA-256 before starting the broker. After that check, use the broker exclusively for project work. Do not read or edit files outside the assigned prompt and project. Do not use web tools or delegate work. Launch the specified broker once and keep using that process session.

Run the launch command from `D:\code\AgentLang` using `exec_command` with `tty:true` and `yield_time_ms:10000`. Send one newline-terminated JSON request at a time and inspect its response before the next mutation. The broker allows at most 100 exchanges, each with a 120000 ms timeout. On a timeout, poll the same process session; do not restart the broker.

Exact launch command:

```powershell
pwsh -NoProfile -File 'D:\code\AgentLang\scripts\Start-SubagentTrialHostV2.ps1' -CliDll 'D:\code\AgentLang\.agentlang\subscription-overlap-143\conventional-artifacts\bin\AgentLang.Conventional.Cli\release\AgentLang.Conventional.Cli.dll' -ProjectPath 'D:\code\AgentLang\.agentlang\subscription-overlap-143\participants\fsharp-b\project' -TracePath 'D:\code\AgentLang\.agentlang\subscription-overlap-143\participants\fsharp-b\actor.trace.jsonl' -AllowedOperations 'inspect,read,search,patch,replace,validate' -Profile conventional -AdditionalCliArgumentsJson '["--validation-project","tests/AgentLang.Business.Tests.fsproj"]' -ExchangeTimeoutMilliseconds 120000 -MaxExchanges 100
```

Use `inspect`, `read`, and `search` through the broker to understand the assigned project. Make edits only through `patch` or `replace`. Finish substantive work with `validate` and observe its full result, then send `{"op":"host.close"}` and wait for normal process exit.

# Task

Implement overlap rejection in the existing subscription start operation. Keep
its existing public signature and successful return representation. Use the
existing model, Store and public start/cancel operations. Preserve existing
validation precedence: duplicate ID, invalid term, invalid date range, missing
customer, missing product. Check overlap only after those validations pass.

Two subscriptions conflict only when they have the same customer and product
and their occupied half-open time intervals overlap. An active subscription
occupies [start, expiry). A cancelled subscription occupies
[start, min(expiry, cancellation time)); cancellation at start therefore leaves
an empty interval and must not block another subscription. A new subscription
occupies its requested [start, expiry). Adjacent intervals do not conflict.
Compare instants, retaining existing time-zone normalization behavior.

On overlap, return error code `SUBSCRIPTION_OVERLAP`. In the language arm use
the existing BusinessError representation; in F# add the DomainError case
`SubscriptionOverlap` and update its code/message mappings. Error text should
explain the conflicting subscription period; wording is not an acceptance gate.
Do not change the input
Store on failure. Other-customer and other-product subscriptions must not block
creation. Retain existing unrelated behavior and regression coverage. You may
minimally update an inherited test or example when its fixture or expectation directly
conflicts with the requested overlap rule; explain why. Keep its original
purpose covered. In particular, a success test for appending a subscription can
use a non-overlapping interval rather than continue expecting overlap to succeed.
Do not delete or broadly weaken tests. Add tests that protect this behavior,
run the suite and complete normal task finalization.
Do not remove or weaken existing validation to make the new behavior pass.

Library qualification requirements apply to authored library functions in the
language arm. Do not demote existing library functions. New helpers are allowed
where useful; the acceptance rubric will
not prescribe a private helper signature or require duplicate existing tests.

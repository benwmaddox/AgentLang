# F# B independent review

Only Business.fs and tests/Program.fs differ from the baseline. The public start signature, original validation order and inherited test bodies remain intact. The new error carries the conflicting period; start skips empty occupied intervals before checking strict half-open overlap. New tests include a request containing the timestamp of a cancellation-at-start, not merely adjacent to it. Scope passes.

On a copy, a fresh serial Release build with NuGetAudit=false and the unchanged full suite pass (19 groups, 165 assertions). This flag avoids the unavailable vulnerability service; it does not certify package security. Both submitted project files match the baseline. The broker trace contains three validate calls: one NU1900 environment failure, one unfinished-let compilation failure, then success under temporary audit suppression. The participant restored the project files before closing. All 44 exchanges and normal shutdown are independently audited; 9 responses report errors.

On another copy, changing only `startedAtUtc < existingEnd` to `startedAtUtc <= existingEnd` compiles, then the unchanged suite fails after 76 assertions at the adjacent-after-existing-period case. This kills the frozen semantic boundary mutant. It does not demonstrate detection of every overlap defect.

Original source inventories match before and after both runs. Exact source/mutation diffs, commands, stdout/stderr, exit codes, trace errors and validation responses accompany this note. The root's separate frozen public oracle passes 19/19 cases.

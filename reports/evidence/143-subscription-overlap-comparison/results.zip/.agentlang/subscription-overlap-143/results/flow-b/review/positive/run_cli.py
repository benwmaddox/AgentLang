from pathlib import Path
import subprocess

here = Path(__file__).resolve().parent
project = here / "working-project"
cli = Path(r"D:\code\AgentLang\.agentlang\library-closure-142\root-cli-artifacts\bin\AgentLang.Cli\release\AgentLang.Cli.dll")
request_path = here / "requests.jsonl"
completed = subprocess.run(
    ["dotnet", str(cli), "--project", str(project), "--jsonl"],
    cwd=project,
    input=request_path.read_text(encoding="utf-8"),
    text=True,
    encoding="utf-8",
    errors="replace",
    capture_output=True,
    check=False,
)
for name, value in (("stdout.txt", completed.stdout), ("stderr.txt", completed.stderr)):
    with (here / name).open("w", encoding="utf-8", newline="") as stream:
        stream.write(value)
(here / "exit-code.txt").write_text(f"{completed.returncode}\n", encoding="utf-8")
print(f"exit={completed.returncode} stdoutBytes={len(completed.stdout.encode('utf-8'))} stderrBytes={len(completed.stderr.encode('utf-8'))}")
from pathlib import Path
import difflib
import hashlib
import json
import subprocess

here = Path(__file__).resolve().parent
project = here / "working-project"
text = (project / "dictionary.agent").read_text(encoding="utf-8")
function_start = text.index("fn subscription.overlap-step(")
function_marker = "\n}\n\n// frontend: flow/1\n\nword subscription.replace-list"
function_end = text.index(function_marker, function_start) + 2
function_source = text[function_start:function_end]
lines = text.splitlines()
test_blocks = []
for index, line in enumerate(lines):
    if not line.startswith("test subscription.overlap-step/"):
        continue
    depth = 0
    opened = False
    block_lines = []
    for current in lines[index:]:
        block_lines.append(current)
        depth += current.count("{") - current.count("}")
        opened = opened or "{" in current
        if opened and depth == 0:
            break
    if not opened or depth != 0:
        raise SystemExit(f"Could not extract balanced test starting at: {line}")
    test_blocks.append("\n".join(block_lines))
if len(test_blocks) != 12:
    raise SystemExit(f"Expected 12 submitted helper tests, found {len(test_blocks)}")
tests_source = "\n\n".join(test_blocks) + "\n"
strict = "let existing-start-before-new-end = instant::before?(Instant::value(existing.started-at()), Instant::value(state.expires-at()));"
inclusive = "let existing-start-before-new-end = bool::or(instant::before?(Instant::value(existing.started-at()), Instant::value(state.expires-at())), equals(Instant::value(existing.started-at()), Instant::value(state.expires-at())));"
if function_source.count(strict) != 1:
    raise SystemExit("Expected exactly one strict boundary expression")
mutant_function = function_source.replace(strict, inclusive, 1)
submitted = function_source + "\n\n" + tests_source
mutant = mutant_function + "\n\n" + tests_source
(here / "submitted-helper.source").write_text(submitted, encoding="utf-8", newline="")
(here / "inclusive-helper.source").write_text(mutant, encoding="utf-8", newline="")
(here / "mutation.diff").write_text("".join(difflib.unified_diff(submitted.splitlines(keepends=True), mutant.splitlines(keepends=True), fromfile="submitted-helper.source", tofile="inclusive-helper.source")), encoding="utf-8", newline="")
test_hash = hashlib.sha256(tests_source.encode("utf-8")).hexdigest()
(here / "test-hashes.json").write_text(json.dumps({"submittedTestsSha256": test_hash, "mutantTestsSha256": test_hash, "testCount": len(test_blocks), "unchanged": True}, indent=2) + "\n", encoding="utf-8")
request_items = [
    {"op": "define", "source": mutant, "frontend": "flow", "syntaxVersion": 2, "replace": True, "expectedRevision": 3},
    {"op": "test-all"},
]
request_text = "".join(json.dumps(item, ensure_ascii=False, separators=(",", ":")) + "\n" for item in request_items)
(here / "requests.jsonl").write_text(request_text, encoding="utf-8", newline="")
cli = Path(r"D:\code\AgentLang\.agentlang\library-closure-142\root-cli-artifacts\bin\AgentLang.Cli\release\AgentLang.Cli.dll")
completed = subprocess.run(["dotnet", str(cli), "--project", str(project), "--jsonl"], cwd=project, input=request_text, text=True, encoding="utf-8", errors="replace", capture_output=True, check=False)
for name, value in (("stdout.txt", completed.stdout), ("stderr.txt", completed.stderr)):
    with (here / name).open("w", encoding="utf-8", newline="") as stream:
        stream.write(value)
(here / "exit-code.txt").write_text(f"{completed.returncode}\n", encoding="utf-8")
responses = []
for line in completed.stdout.splitlines():
    if line.strip().startswith("{"):
        try:
            responses.append(json.loads(line))
        except json.JSONDecodeError:
            pass
define = next((r for r in responses if r.get("kind") in {"defined", "error"}), None)
test = next((r for r in responses if r.get("kind") == "test"), None)
rows = (test or {}).get("data", {}).get("results", [])
failed = [{"word": r.get("word"), "name": r.get("name"), "actual": r.get("actual"), "expected": r.get("expected")} for r in rows if r.get("passed") is False]
summary = {"processExitCode": completed.returncode, "defineKind": (define or {}).get("kind"), "defineOk": (define or {}).get("ok"), "defineText": (define or {}).get("text"), "testKind": (test or {}).get("kind"), "testOk": (test or {}).get("ok"), "testText": (test or {}).get("text"), "testRows": len(rows), "failedCount": len(failed), "failed": failed, "unchangedHelperTests": len(test_blocks), "testHashesUnchanged": True}
(here / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
print(json.dumps(summary, indent=2))
# fsharp-a review

The submitted implementation passes the frozen 19-case overlap oracle (19/19), and every case confirms unchanged input state. A fresh source-only copy built in Release and passed the full F# suite: 19 groups and 172 assertions, up from the unchanged baseline's 18 groups and 157 assertions.

The baseline comparison shows changes only in business/Business.fs and tests/Program.fs. The public Subscription.start signature is unchanged, both project files are unchanged, and no inherited test lines were removed or edited. The added group covers overlap rejection and error details, input immutability, validation precedence, both adjacency boundaries, customer/product isolation, offset normalization, cancellation boundaries, and an empty interval after cancellation at start. The local group does not explicitly cover containment or cancellation beyond expiry; the frozen 19-case oracle covers those and passes them.

The mutation check changed requestedStartedAt < existingEnd to requestedStartedAt <= existingEnd in a copy. The mutant built successfully; with the submitted tests unchanged, the suite failed behaviorally at the adjacency assertion (period starting at existing expiry is adjacent). This is a valid mutation kill, not a compile failure.

The participant trace contains 42 exchanges: 14 inspect, 14 patch, 5 read, 4 search, and 5 validate. Eleven responses failed (7 request/patch rejections and 4 failed validations). A transient F# FS0588 error was corrected, and one validation passed after NuGetAudit=false was temporarily added to both project files. Those settings were then restored; the final validation failed with NU1900 because the NuGet vulnerability service index was unavailable. The trace shows normal host.close at exchange 42 and host/runtime exit codes 0/0. This final validation infrastructure failure is separate from the successful copy build, suite, and independent oracle results.

The five source-file hashes for both the baseline and submitted project match before and after this review. Frozen task and rubric hashes also match freeze.json.

Evidence is in this directory: participant-vs-baseline.diff, source-hashes.before.json, source-hashes.after.json, independent-acceptance.json, fresh-build.*, fresh-suite.*, mutant-boundary.diff, mutant-build.*, mutant-suite.*, participant-actor.trace.jsonl, and termination-audit.txt.

namespace SubscriptionOverlapOracle

open System
open System.Collections.Generic
open System.Globalization
open System.Text.Json
open AgentLang.Business.Domain

module Program =
    type private StateSnapshot = {
        Summary: StoreSummary
        Customers: Customer list
        Products: (ProductId * Product option) list
        Subscriptions: (SubscriptionId * Subscription option) list
        Payments: Payment list
        PendingEmails: EmailMessage list
        SentEmails: EmailMessage list
    }

    type private CaseAcceptance = {
        CaseId: string
        Expected: string list
        Actual: string list
        InputUnchanged: bool list
        Passed: bool
    }

    type private Acceptance = {
        SchemaVersion: int
        Arm: string
        Passed: bool
        Cases: CaseAcceptance list
    }

    let private ok label = function
        | Ok value -> value
        | Error error -> failwith $"{label}: {DomainError.code error}: {DomainError.message error}"

    let private text (element: JsonElement) (name: string) = element.GetProperty(name).GetString()

    let private parseId (parse: string -> Result<'Value, DomainError>) (label: string) (value: string) = parse value |> ok label

    let private instant (value: string) =
        DateTimeOffset.Parse(value, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind)

    let private createBaseStore (root: JsonElement) =
        let createdAt = instant "2026-01-01T00:00:00.0000000+00:00"
        let customers =
            root.GetProperty("customers").EnumerateArray()
            |> Seq.map (fun element ->
                let customerId = parseId CustomerId.parse "customer id" (text element "id")
                let email = Email.create (text element "email") |> ok "customer email"
                Customer.create customerId email "standard" Money.zero createdAt |> ok "customer create")
            |> Seq.toList
        let products =
            root.GetProperty("products").EnumerateArray()
            |> Seq.map (fun element ->
                let productId = parseId ProductId.parse "product id" (text element "id")
                Product.create productId (text element "name") (Money.ofMinorUnits 1L) |> ok "product create")
            |> Seq.toList
        let withCustomers =
            customers
            |> List.fold (fun store customer -> Store.addCustomer customer store |> ok "add customer") Store.empty
        products
        |> List.fold (fun store product -> Store.addProduct product store |> ok "add product") withCustomers

    let private subscriptionIds (root: JsonElement) =
        [
            for item in root.GetProperty("cases").EnumerateArray() do
                for seed in item.GetProperty("seed").EnumerateArray() do
                    yield text seed "id"
                for step in item.GetProperty("steps").EnumerateArray() do
                    match text step "op" with
                    | "start" -> yield text (step.GetProperty("subscription")) "id"
                    | "cancel" -> yield text step "subscriptionId"
                    | operation -> failwith $"Unknown operation '{operation}'."
        ]
        |> List.distinct
        |> List.map (parseId SubscriptionId.parse "subscription id")

    let private productIds (root: JsonElement) =
        root.GetProperty("products").EnumerateArray()
        |> Seq.map (fun element -> parseId ProductId.parse "product id" (text element "id"))
        |> Seq.toList

    let private snapshot (products: ProductId list) (subscriptions: SubscriptionId list) (store: Store) = {
        Summary = Store.summary store
        Customers = Store.customers store
        Products = products |> List.map (fun key -> key, Store.product key store)
        Subscriptions = subscriptions |> List.map (fun key -> key, Store.subscription key store)
        Payments = Store.payments store
        PendingEmails = Store.pendingEmails store
        SentEmails = Store.sentEmails store
    }

    let private applyTransition
        (snapshotStore: Store -> StateSnapshot)
        (beforeSnapshot: StateSnapshot)
        (before: Store)
        (actual: ResizeArray<string>)
        (invariants: ResizeArray<bool>)
        (result: Result<Store * Subscription, DomainError>) =
        match result with
        | Ok(updated, _) ->
            actual.Add("ok")
            invariants.Add((beforeSnapshot = snapshotStore before))
            Some updated
        | Error error ->
            actual.Add(DomainError.code error)
            invariants.Add((beforeSnapshot = snapshotStore before))
            None

    let private runCase root products subscriptions (caseElement: JsonElement) =
        let mutable store = createBaseStore root
        let actual = ResizeArray<string>()
        let invariants = ResizeArray<bool>()
        let snapshotStore = snapshot products subscriptions
        let apply beforeSnapshot result =
            match applyTransition snapshotStore beforeSnapshot store actual invariants result with
            | Some updated -> store <- updated
            | None -> ()

        for seed in caseElement.GetProperty("seed").EnumerateArray() do
            let subscriptionId = parseId SubscriptionId.parse "subscription id" (text seed "id")
            let customerId = parseId CustomerId.parse "customer id" (text seed "customerId")
            let productId = parseId ProductId.parse "product id" (text seed "productId")
            let beforeSnapshot = snapshotStore store
            let result =
                Subscription.start store subscriptionId customerId productId (text seed "term")
                    (instant (text seed "startsAt")) (instant (text seed "expiresAt"))
            apply beforeSnapshot result

        for step in caseElement.GetProperty("steps").EnumerateArray() do
            match text step "op" with
            | "start" ->
                let spec = step.GetProperty("subscription")
                let subscriptionId = parseId SubscriptionId.parse "subscription id" (text spec "id")
                let customerId = parseId CustomerId.parse "customer id" (text spec "customerId")
                let productId = parseId ProductId.parse "product id" (text spec "productId")
                let beforeSnapshot = snapshotStore store
                let result =
                    Subscription.start store subscriptionId customerId productId (text spec "term")
                        (instant (text spec "startsAt")) (instant (text spec "expiresAt"))
                apply beforeSnapshot result
            | "cancel" ->
                let subscriptionId = parseId SubscriptionId.parse "subscription id" (text step "subscriptionId")
                let beforeSnapshot = snapshotStore store
                let result = Subscription.cancel store subscriptionId (instant (text step "cancelledAt"))
                apply beforeSnapshot result
            | operation -> failwith $"Unknown operation '{operation}'."

        let expected =
            [ for _ in caseElement.GetProperty("seed").EnumerateArray() do yield "ok" ]
            @ [ for step in caseElement.GetProperty("steps").EnumerateArray() do yield text step "expected" ]
        let actual = List.ofSeq actual
        let unchanged = List.ofSeq invariants
        {
            CaseId = text caseElement "id"
            Expected = expected
            Actual = actual
            InputUnchanged = unchanged
            Passed = actual = expected && List.forall id unchanged
        }

    [<EntryPoint>]
    let main argv =
        if argv.Length <> 1 then
            eprintfn "Usage: oracle <cases.json>"
            2
        else
            use document = JsonDocument.Parse(IO.File.ReadAllText(argv[0]))
            let root = document.RootElement
            let products = productIds root
            let subscriptions = subscriptionIds root
            let cases =
                root.GetProperty("cases").EnumerateArray()
                |> Seq.map (runCase root products subscriptions)
                |> Seq.toList
            let result = {| 
                schemaVersion = 1
                arm = "fsharp"
                passed = cases |> List.forall (fun item -> item.Passed)
                cases = cases |> List.map (fun item -> {| caseId = item.CaseId; expected = item.Expected; actual = item.Actual; inputUnchanged = item.InputUnchanged; passed = item.Passed |})
            |}
            Console.WriteLine(JsonSerializer.Serialize(result))
            if result.passed then 0 else 1

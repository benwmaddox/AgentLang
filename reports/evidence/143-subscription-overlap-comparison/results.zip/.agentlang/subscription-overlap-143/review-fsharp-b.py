from pathlib import Path
import json,hashlib,shutil,subprocess,difflib
r=Path('.agentlang/subscription-overlap-143').resolve(); src=r/'participants/fsharp-b/project'; out=r/'results/fsharp-b/review'; out.mkdir(parents=True,exist_ok=False)
def inv(p):
 return {f.relative_to(p).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob('*') if f.is_file() and not {'bin','obj'}.intersection(x.lower() for x in f.relative_to(p).parts)}
before=inv(src); baseline=r/'baseline-smoke/fsharp/project'; base=inv(baseline); (out/'source-hashes.before.json').write_text(json.dumps(before,indent=2))
changed=[k for k in before if before[k]!=base.get(k)]; diffs=[]
for k in changed:
 diffs += list(difflib.unified_diff((baseline/k).read_text(encoding='utf-8-sig').splitlines(True),(src/k).read_text(encoding='utf-8-sig').splitlines(True),fromfile='baseline/'+k,tofile='submitted/'+k))
(out/'source.diff').write_text(''.join(diffs),encoding='utf-8')
runs=[]
for kind in ['fresh','mutant']:
 p=out/kind/'project'; shutil.copytree(src,p,ignore=shutil.ignore_patterns('bin','obj'))
 if kind=='mutant':
  f=p/'business/Business.fs'; a=f.read_text(encoding='utf-8-sig'); needle='&& startedAtUtc < existingEnd'; assert a.count(needle)==1
  b=a.replace(needle,'&& startedAtUtc <= existingEnd'); f.write_text(b,encoding='utf-8'); (out/'mutation.diff').write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='submitted/Business.fs',tofile='mutant/Business.fs')),encoding='utf-8')
 fsproj=p/'tests/AgentLang.Business.Tests.fsproj'; cmds=[['dotnet','build',str(fsproj),'--configuration','Release','--verbosity','minimal','--nologo','-m:1','-p:NuGetAudit=false'],['dotnet','run','--project',str(fsproj),'--configuration','Release','--no-build']]
 codes=[]
 for label,cmd in zip(['build','test'],cmds):
  proc=subprocess.run(cmd,cwd=p,capture_output=True,text=True); (out/kind/(label+'.stdout.txt')).write_text(proc.stdout,encoding='utf-8'); (out/kind/(label+'.stderr.txt')).write_text(proc.stderr,encoding='utf-8'); codes.append(proc.returncode)
  if label=='build' and proc.returncode: break
 runs.append({'kind':kind,'commands':cmds,'exitCodes':codes})
after=inv(src); assert before==after
rows=[json.loads(s) for s in (r/'participants/fsharp-b/actor.trace.jsonl').read_text(encoding='utf-8-sig').splitlines()]; ex=[x for x in rows if x.get('event')=='exchange']; errs=[]; vals=[]
for x in ex:
 d=json.loads(x['response']['rawLine'])
 if not d.get('ok',True): errs.append({'index':x['index'],'operation':x['operation'],'error':d.get('error')})
 if x['operation']=='validate': vals.append({'index':x['index'],'response':d})
summary={'inputUnchanged':before==after,'changedFiles':changed,'publicSignaturePreserved':True,'scopePassed':True,'inheritedTestsPreserved':True,'projectConfigurationRestored':all(before[k]==base[k] for k in before if k.endswith('fsproj')),'brokerExchanges':len(ex),'errorResponses':errs,'validationResponses':vals,'runs':runs}
(out/'review.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8'); print(json.dumps({'changed':changed,'exchanges':len(ex),'errors':len(errs),'runs':[(x['kind'],x['exitCodes']) for x in runs]}))

$ErrorActionPreference = 'Stop'
$receipt187 = Join-Path (Get-Location).Path '.agentlang/type-history-187'
$report187 = Get-Content -LiteralPath (Join-Path $receipt187 'full-validation.json') -Raw | ConvertFrom-Json
$exit187 = Get-Content -LiteralPath (Join-Path $receipt187 'full-validation-exit.json') -Raw | ConvertFrom-Json
if (-not $report187.passed -or $exit187.exitCode -ne 0 -or $report187.checks.Count -ne 37 -or @($report187.checks | Where-Object exitCode -ne 0).Count -ne 0) {
    throw 'Complete passing local validation is required before packaging'
}
$pins187 = Get-Content -LiteralPath (Join-Path $receipt187 'source-pins.json') -Raw | ConvertFrom-Json
$goldens187 = Get-Content -LiteralPath (Join-Path $receipt187 'legacy-golden-pins.json') -Raw | ConvertFrom-Json
foreach ($pin187 in @($pins187.files) + @($goldens187.files)) {
    if ((Get-FileHash -LiteralPath $pin187.path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $pin187.sha256) {
        throw "Pinned bytes changed: $($pin187.path)"
    }
}
$staging187 = Join-Path $receipt187 ('package-' + [Guid]::NewGuid().ToString('N'))
$destination187 = Join-Path (Get-Location).Path 'reports/evidence/187-durable-type-source-history'
New-Item -ItemType Directory -Path $staging187,$destination187 -Force | Out-Null
function Copy-Evidence187([string]$source187, [string]$member187) {
    $target187 = Join-Path $staging187 $member187
    New-Item -ItemType Directory -Path (Split-Path -Parent $target187) -Force | Out-Null
    Copy-Item -LiteralPath $source187 -Destination $target187
}
foreach ($pin187 in $pins187.files) { Copy-Evidence187 $pin187.path ('sources/' + $pin187.path) }
foreach ($file187 in @('full-validation.json','full-validation.log','full-validation-exit.json','source-pins.json','legacy-golden-pins.json','validation-receipt.md','acceptance-review.md','final-review.md','interrupted-1-full-validation.log','interrupted-1-full-validation-exit.json','interrupted-1-source-pins.json','run-full-validation.ps1','package-evidence.ps1')) {
    Copy-Evidence187 (Join-Path $receipt187 $file187) ('validation/' + $file187)
}
foreach ($companion187 in Get-ChildItem -LiteralPath $receipt187 -File -Filter 'full-validation.*.json') {
    Copy-Evidence187 $companion187.FullName ('validation/' + $companion187.Name)
}
$members187 = @(Get-ChildItem -LiteralPath $staging187 -File -Recurse | ForEach-Object {
    [ordered]@{path=[IO.Path]::GetRelativePath($staging187,$_.FullName).Replace('\','/'); bytes=$_.Length; sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()}
} | Sort-Object path)
$zip187 = Join-Path $destination187 'evidence.zip'
if (Test-Path -LiteralPath $zip187) { throw 'Evidence archive already exists; do not overwrite accepted evidence' }
[IO.Compression.ZipFile]::CreateFromDirectory($staging187,$zip187)
$archive187 = [IO.Compression.ZipFile]::OpenRead($zip187)
try {
    if ($archive187.Entries.Count -ne $members187.Count) { throw 'Archive member count differs' }
    foreach ($member187 in $members187) {
        $entry187 = $archive187.GetEntry($member187.path)
        if ($null -eq $entry187 -or $entry187.Length -ne $member187.bytes) { throw "Archive member differs: $($member187.path)" }
        $stream187 = $entry187.Open()
        try { $hash187 = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream187)).ToLowerInvariant() }
        finally { $stream187.Dispose() }
        if ($hash187 -ne $member187.sha256) { throw "Archive hash differs: $($member187.path)" }
    }
} finally { $archive187.Dispose() }
$index187 = [ordered]@{
    format=1; report='187-durable-type-source-history'; baseRevision=$pins187.baseRevision
    testedWorkingSourcePins=$pins187.files
    localValidation=[ordered]@{passed=$true; checks=$report187.checks.Count; terminalExitCode=$exit187.exitCode; runtimeGroups=42; runtimeAssertions=1934; storageGroups=18; storageAssertions=572}
    archive=[ordered]@{file='evidence.zip'; bytes=(Get-Item -LiteralPath $zip187).Length; sha256=(Get-FileHash -LiteralPath $zip187 -Algorithm SHA256).Hash.ToLowerInvariant()}
    verification=[ordered]@{sourcePinsUnchanged=$true; legacyGoldenPinsUnchanged=$true; memberHashes='passed'; count=$members187.Count}
    files=$members187
}
$index187 | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $destination187 'index.json') -Encoding utf8
$index187.archive | ConvertTo-Json

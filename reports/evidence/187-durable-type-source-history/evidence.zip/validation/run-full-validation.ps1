$ErrorActionPreference = 'Stop'
$repo = (Get-Location).Path
$receiptRoot = Join-Path $repo '.agentlang/type-history-187'
$temporaryRoot = Join-Path $receiptRoot 'tmp'
New-Item -ItemType Directory -Path $temporaryRoot -Force | Out-Null
$env:TEMP = $temporaryRoot
$env:TMP = $temporaryRoot
$paths = @(& git diff --name-only) + @('scripts/Validate.ps1')
$files = @($paths | Sort-Object -Unique | ForEach-Object {
    [ordered]@{path=$_; sha256=(Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash.ToLowerInvariant()}
})
[ordered]@{baseRevision=(& git rev-parse HEAD | Out-String).Trim(); files=$files} |
    ConvertTo-Json -Depth 6 | Set-Content (Join-Path $receiptRoot 'source-pins.json') -Encoding utf8
$logPath = Join-Path $receiptRoot 'full-validation.log'
& pwsh -NoProfile -File scripts/Validate.ps1 -Configuration Release -SerialBuild -SkipPackageAudit -ReportPath .agentlang/type-history-187/full-validation.json *> $logPath
$validationExit = $LASTEXITCODE
[ordered]@{exitCode=$validationExit; endedUtc=[DateTimeOffset]::UtcNow.ToString('O')} |
    ConvertTo-Json | Set-Content (Join-Path $receiptRoot 'full-validation-exit.json') -Encoding utf8
Get-Content -LiteralPath $logPath -Tail 9
exit $validationExit

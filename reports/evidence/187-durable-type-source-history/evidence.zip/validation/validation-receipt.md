# Type history Stage A focused validation

All focused builds ran serially in Release with `TEMP` and `TMP` set to `.agentlang/type-history-187/temp`; `NuGetAudit=false` and `--no-restore` avoided package-network activity. Console acceptance tests were run with `dotnet run --no-build`, not `dotnet test`.

- `dotnet build tests/AgentLang.Storage.Tests/AgentLang.Storage.Tests.fsproj --configuration Release --no-restore -m:1` — passed, 0 warnings/errors.
- `dotnet run --no-build --configuration Release --project tests/AgentLang.Storage.Tests/AgentLang.Storage.Tests.fsproj` — passed, 18 groups, 572 assertions.
- `dotnet build tests/AgentLang.Flow.Runtime.Tests/AgentLang.Flow.Runtime.Tests.fsproj --configuration Release --no-restore -m:1` — passed, 0 warnings/errors.
- `dotnet run --no-build --configuration Release --project tests/AgentLang.Flow.Runtime.Tests/AgentLang.Flow.Runtime.Tests.fsproj` — passed, 42 groups, 1,934 assertions.
- `git diff --check` — passed.

The runtime regression initially used an earlier captured project export for a later v5-to-v6 transition; Storage correctly rejected it with `STORAGE_EXPORT_MISMATCH`. The test now uses the exact v5 load's ProjectSource, and the final focused runtime run passed.

The parent intentionally stopped the earlier full validation while reviewing the two Runtime findings addressed in this continuation. Its recorded outer session 86054 exited 1 after the wrapper child exited -1; the parent archived that interruption evidence. This is not a full-validation pass. The parent owns the full gate restart after this focused freeze.

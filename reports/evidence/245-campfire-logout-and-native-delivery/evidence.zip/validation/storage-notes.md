# Campfire logout storage notes

- Reference: `.agentlang/campfire-reference` is pinned at Rust `6dae2fd3c1a2dce61ca11beb731bcce2b42b67ad`; Rails `SessionsController#destroy` destroys the current session and calls `Push::Subscription.destroy_by(endpoint:, user_id:)` when the endpoint parameter is present.
- `DeleteSession` deletes by `sessions.id`; missing rows succeed. SQLite statement errors map through the existing closed `DbError` conversion.
- `DestroyPushSubscriptions` deletes every row matching both exact `endpoint` and `user_id`; the single SQLite delete statement is atomic and preserves duplicate-match rollback behavior.
- Existing schema is untouched. Persistence and host test fixtures add the Rails-shaped `push_subscriptions` table. Coverage checks reopen behavior, duplicate matches, other users/endpoints, idempotence, strict host types, Unit values, and structured provider failures.
- Validation is delegated to the parent agent; no build or test command was run in the shared checkout.

# Campfire logout Flow notes

- Flow models `session-destroy` after session restoration, CSRF/browser checks, and the existing current-user check. The branch calls `campfire.http.logout` with `restored.session.id` directly; it never uses room lookup.
- An absent parsed logout form is accepted as sign-out without a push endpoint. Parser errors map to the closed `HttpFormError` statuses before any revocation.
- `campfire.authentication.sign-out` destroys the optional user-owned push endpoint first, then the current session. Push errors short-circuit; session errors propagate.
- Success returns the fixed signed-out redirect with an empty body and no pending refresh. HTTP failures preserve the restoration refresh token.
- Scoped tests cover endpoint absent/present, each `DbError` for push and session destruction, push short-circuiting, parser errors, CSRF/browser/current-user gates, no room lookup on success, and cookie refresh behavior.
- The shared checkout is concurrently edited. No build or test command was run for this Flow-owned change; the parent owns integrated validation after the other workers finish.

# Native conformance next step: closed enums in `OwningStackAot`

## Direction

Extend the bounded owning backend with closed, payload-free enums, represented
as 8-byte inline leaf values. This follows the implemented stable-arena policy
in [`docs/STABLE-ARENA-LOWERING.md`](../../docs/STABLE-ARENA-LOWERING.md):
records remain inline, locations retain their existing owner/extent rules, and
the compiler continues to decide rewinds from provenance. The existing Core IR
already carries verified `MakeEnumCase` and exhaustive `MatchEnum` operations,
so this slice needs no new semantic IR node and introduces no heap object,
graph traversal, or lifetime rule.

An enum value is its zero-based case ordinal in an 8-byte slot; the nominal
type ID supplies the type identity. `MakeEnumCase` writes the ordinal with the
existing scalar store path. `MatchEnum` switches on that ordinal and has a
structured invalid-tag failure path. Host input encoding accepts only the
matching `EnumValue(typeName, caseName)` from the verified case table; output
decoding rejects ordinals outside that table. Record fields containing enums
occupy the ordinary 8-byte inline field slot. An enum-only retained result is
therefore 8 bytes, and a record gains the normal 8 bytes for each enum field.
Option and Result stay explicitly unsupported; payload-bearing sum layouts
need a separate design for inline active payloads and their size/extent rules.

The earlier proposal to extend graph/promotion `LlvmAot` while leaving
`OwningStackAot` unsupported is rejected/deferred because it targets the wrong
backend for the selected stable-arena architecture. This plan does not choose
an actor versus specialized-mailbox architecture.

## Minimal implementation surface

- `src/AgentLang.Llvm/OwningStackAot.fs`: in `makeProgramInfoForBodies` /
  `buildType`, admit `IrEnumDefinition` as a fixed 8-byte, no-field leaf. In
  `validateBlock`, validate generated enum constructors and `MatchEnum`,
  retaining Core's verified case indices, exhaustiveness, and branch shapes.
  Add the corresponding operations in the active stable-arena emitter:
  enum values are static-size, but records containing both String and enum
  fields exercise its variable-size layout handling. Extend `measureValue`, `encodeValues`, and
  `decodeValues` to validate/translate the existing `EnumValue` representation.
  Reuse `typeIds` and the verified nominal case table; do not add an independent
  enum schema.
- `src/AgentLang.Llvm/OwningStackAot.fs` plus
  `src/AgentLang.Llvm/native/owning_stack_runtime.h` and
  `owning_stack_runtime.c`: emit a distinct enum leaf type kind (next available
  kind is 6), requiring 8-byte payload/extent and no fields. Append an explicit
  `uint32_t case_count` after the existing descriptor fields; it is positive
  for enums and zero for every non-enum. This makes the descriptor 36 bytes and
  requires `AL_OWNING_LAYOUT_ABI_VERSION` 2. Validate the descriptor invariant
  and check every scanned enum tag against `case_count`. For external bytes,
  including enum fields recursively nested in records, report
  `AL_OWNING_STATUS_INVALID_REQUEST`; internal generated/match failures keep
  their structured diagnostics. `AL_OWNING_STACK_ABI_VERSION` remains 1 because
  the context and event layouts do not change. Do not change the separate
  `OwningStackExecutionResult.LayoutSchemaVersion` unless its managed schema
  actually changes.
- Native ingress must reject malformed ordinals before user code can run,
  even when an input is ignored. The dynamic entry wrapper already calls
  `al_owning_measure_external_value` over every declared input before copying
  inputs and entering the body; the scanner recursively visits record fields.
  Later implementation inspection confirmed that `emitFixedModule` is inactive
  historical code: public `emitModule` and module compilation use
  `emitDynamicModule` for both fixed and variable-sized value layouts. Do not
  extend the unused emitter. Exercise the active wrapper with malformed tags,
  counts and extents, including ignored and nested inputs. Host validation is
  not a substitute for this native boundary.
- `experiments/AgentLang.NativeValueStack/Program.fs` and
  `tests/AgentLang.Llvm.Tests/Program.fs`: add compiler-built enum contexts and
  positive owning-backend cases. Compare interpreter and owning O0/O2 execution
  for every constructor, exhaustive match, equality, local/call round-trip,
  record construction/projection, and retained encode/decode. Cover enums in a
  fixed record and in a String-bearing dynamic record to cover both layouts.
  Include host rejection of an unknown case or mismatched enum type and a raw
  native-entry test for invalid ordinals.
  Keep the existing Option/Result rejection tests.
- `tests/fixtures/native-conformance/native-value-stack.json`: add an
  independent enum layout/value oracle and extend the owning storage test
  oracle. Update `layoutAbiVersion` from 1 to 2 and `typeDescriptorSizeBytes`
  from 32 to 36; `layoutSizeBytes` remains 40, the value remains 8 bytes, and
  the owning context/event ABI remains unchanged. Keep the fixture schema at 2
  unless its JSON format changes. The focused verifier already compares these
  ABI fields and hashes the current C header/runtime/test, runner sources, and
  fixture; add source inputs only if implementation introduces new files.
- Audit every consumer of the shared layout descriptor/version: generated
  descriptors in `OwningStackAot.fs`; `owning_stack_runtime.c`,
  `mailbox_runtime.c`, and `owning_bank.c`; descriptor initializers and ABI
  assertions in `owning_stack_runtime_test.c`, `owning_mailbox_test.c`,
  `owning_mailbox_release_test.c`, `owning_release_runtime_test.c`, and
  `owning_bank_test.c`; and the handwritten consumers
  `experiments/AgentLang.MailboxLoad/load_host.c` and
  `experiments/AgentLang.RealIoMailbox/native_host.c`. Append zero case counts
  for existing non-enum fixture descriptors. Generic mailbox/bank consumers accept validated enum leaves; fixed-schema handwritten hosts keep
  rejecting unsupported enum layouts. The 40-byte layout struct, Stack ABI1
  context/events, and mailbox module struct do not need a version bump solely
  because the pointed-to layout descriptor changes; all generated modules and
  native consumers must agree on Layout ABI2. Update `docs/BACKENDS.md` and
  clarify the version change in `docs/STABLE-ARENA-LOWERING.md`; leave pinned
  historical reports and source-hash snapshots untouched.

## Acceptance

The independent fixture should pin case ordinals, enum bytes, enum field
offsets, and retained output bytes. C tests must prove that enum descriptors
require a positive count, all non-enum descriptors require zero, external
invalid tags return `INVALID_REQUEST`, and nested invalid tags are rejected.
Exercise malformed enum roots that are used, ignored, and nested in fixed and
dynamic records by invoking the generated native entry with raw bytes; the
entry must reject each before any body operation can take precedence and leave
the caller's retained buffer unchanged. The runner should prove
interpreter/O0/O2 parity for all constructors, matches, equality, projections,
and retained encode/decode. Check that enum values remain inline and that
descriptors, locals, record fields, calls, and returns follow the stable-arena
placement and rewind rules. Update native storage case/check counts and the
ABI fixture oracle for the new descriptor field.

Run the focused gate from the repository root:

```powershell
pwsh -NoProfile -File .\scripts\Verify-NativeValueStack.ps1
```

Then run the required Release validation:

```powershell
pwsh -NoProfile -File .\scripts\Validate.ps1 -SerialBuild -SkipPackageAudit
```

The focused script fresh-builds the owning runner and dependencies, executes
the owning native storage tests at O0/O2 and under trap-mode UBSan, and compares
the same verified IR with the interpreter. This planning pass ran no builds or
tests.

from pathlib import Path
import hashlib
import json
import zipfile

root = Path(__file__).resolve().parents[2]
evidence = root / '.agentlang/occupied-period-152'
output = root / 'reports/evidence/152-occupied-period-domain'
output.mkdir(parents=True, exist_ok=True)
sources = [
    'examples/business-subscriptions.agent',
    'experiments/AgentLang.Business/Business.fs',
    'tests/AgentLang.Business.Tests/Program.fs',
    'tests/AgentLang.Business.Transitions.Tests/Program.fs',
    'scripts/Prepare-BusinessPolicyTrial.ps1',
    'docs/BUSINESS-LANGUAGE-PLAN.md',
    'docs/ROADMAP.md',
]
selected = []
for path in evidence.rglob('*'):
    if not path.is_file():
        continue
    relative = path.relative_to(evidence)
    # Preserve requests, replies, logs and review; omit temporary runtime stores.
    if any(part in {'tmp', 'validation-tmp', 'bin', 'obj'}
           or part.startswith('project') or part.startswith('preparer-probe')
           for part in relative.parts[:-1]):
        continue
    selected.append((path, 'evidence/' + relative.as_posix()))
selected += [(root / name, 'source/' + name) for name in sources]
manifest = []
archive = output / 'evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as target:
    for path, name in sorted(selected, key=lambda entry: entry[1]):
        data = path.read_bytes()
        target.writestr(name, data)
        manifest.append({'path': name, 'bytes': len(data),
                         'sha256': hashlib.sha256(data).hexdigest()})
    target.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    for item in manifest:
        assert hashlib.sha256(check.read(item['path'])).hexdigest() == item['sha256']
metadata = {'archive': 'evidence.zip', 'entries': len(manifest) + 1,
            'bytes': archive.stat().st_size,
            'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
            'sourceFiles': sources}
(output / 'archive.json').write_text(json.dumps(metadata, indent=2) + '\n', encoding='utf-8')
print(json.dumps(metadata))

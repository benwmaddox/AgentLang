# Occupied-period 152 code review

Scope reviewed: `experiments/AgentLang.Business/Business.fs`,
`tests/AgentLang.Business.Tests/Program.fs`,
`examples/business-subscriptions.agent`, and
`tests/AgentLang.Business.Transitions.Tests/Program.fs`.

## Blocker

The transition run recorded in `integration-run-004.log` passes the fixture,
subscription, and independent tick-occupancy checks (7 groups, 5,832
assertions), then fails during library promotion:

> `LIBRARY_COVERAGE_INCOMPLETE` for `subscription.start`: every instruction,
> case, and declared iteration outcome must be covered by its own tests.

The likely uncovered path is the `none` arm of
`occupied-period::try-create(started-at, expires-at)` inside `subscription.start`.
The earlier expiry check has already rejected both `expires-at < started-at`
and equality, so this helper must return `some` for every path reaching it.
The arm cannot be covered by a valid test. Reuse `try-create` at the existing
date-validation position—after term validation and before customer/product
lookup—map `none` to `SUBSCRIPTION_EXPIRY_MUST_FOLLOW_START`, and carry the
`some` period forward. That keeps the required precedence and leaves the actual
overlap decision after product lookup.

## Correctness review

The period logic otherwise matches the intended half-open policy. F# normalizes
endpoints to UTC before storing them; Flow compares canonical `Instant` values
through `instant::before?`. Both use strict comparisons, so adjacency is allowed.
Cancelled occupancy is clipped to the earlier of cancellation and expiry, and a
cancellation at start produces `None`. The Flow occupancy grid and F# domain
tests derive expectations from intersecting discrete day or 100 ns tick sets,
independently of the overlap predicate. They cover same-owner/product conflicts,
different owners/products, cancellation boundaries, failure-state preservation,
and UTC-equivalent offsets in F#.

Validation order remains duplicate ID, term, dates, customer, product, then
overlap. The successful example/test now begins at the seeded subscription's
exclusive expiry. The scoped changes add no Store field, persisted schema, or
core primitive. The transition fixture importer parses the subscription file
as Flow/2 and updates its expected declaration counts.

No other correctness blocker was apparent in the reviewed files. This review
does not treat manually forged or imported inconsistent subscription records
as an acceptance case.

## Follow-up review

The revised `subscription.start` implementations now call the occupied-period
constructor at the original date-validation point, after duplicate ID and term
checks and before customer/product lookup. The valid `Some` period is carried to
the overlap check after product lookup; `None` maps to the existing expiry error.
This removes the unreachable `None` arm from the later overlap block while
preserving the required validation order. Existing invalid-date and successful
start tests exercise both tags. The earlier library-coverage blocker is resolved
by inspection, and I found no new static correctness blocker. The root's fresh
transition and full validation runs are still in progress; I did not run tests.

## Seed-preflight script follow-up

The current growing-seed preflight in `scripts/Prepare-BusinessPolicyTrial.ps1`
is internally aligned with the expanded Flow source inventory: it expects 59
words, 33 types, 184 tests, 47 examples, 57 library words, and two project
words, then separately checks the 179 library-owned tests after removing the
five email-owner tests. Its declaration inventory now counts both `word` and
`fn`; it passes only `business-subscriptions.agent` as Flow/2 and keeps the
other five documents and the reintroduced email-only owner source at Flow/1.
The owner extraction still verifies exact words, tests, and examples, so the
new subscription declarations remain library vocabulary. The live transition
fixture importer has the same per-file version selection and expanded counts.

The existing seed-state schema remains version 1. A pre-change seed is rejected
by changed counts and current source hashes, while the generated project file
inventory and source-input hashes continue to be checked. The seed manifest
does not itself persist each source's syntax version; the current run is
nevertheless reproducible from the updated bootstrapper and source inputs, but
a future version-only change would not be distinguishable from the prior seed
by `sourceInputs` alone.

The shared bootstrapper is also pinned as a source artifact by frozen retention
003/004 verification (`scripts/Verify-RetentionTrial.ps1` and
`scripts/Verify-RetentionTrialV4.ps1` compare its working hash with the frozen
revision). Thus those historical verifiers will reject the updated live file
when run at a newer checkout. Their archived source snapshots and manifests
remain untouched; historical reproduction must use the pinned checkout/archive.
The current business-policy preflight remains the live path for validating the
updated seed. I found no stale live count assertion outside the current
preflight and transition fixture; the other retention references are part of
the frozen studies and were left unchanged. No core or persisted business
schema change is introduced by this script update.

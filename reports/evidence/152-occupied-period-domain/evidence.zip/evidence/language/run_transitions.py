from __future__ import annotations

import json
import subprocess
from pathlib import Path


root = Path(__file__).resolve().parents[3]
language = Path(__file__).resolve().parent
evidence = language / "transition-integration"
evidence.mkdir(parents=True, exist_ok=True)
command = [
    "dotnet",
    "run",
    "--project",
    "tests/AgentLang.Business.Transitions.Tests/AgentLang.Business.Transitions.Tests.fsproj",
    "--configuration",
    "Debug",
    "--",
    "--evidence",
    str(evidence),
]
result = subprocess.run(command, capture_output=True, cwd=root, timeout=300)
(evidence / "command.json").write_text(
    json.dumps({"workingDirectory": str(root), "command": command}, indent=2) + "\n",
    encoding="utf-8",
)
(evidence / "stdout.txt").write_bytes(result.stdout)
(evidence / "stderr.txt").write_bytes(result.stderr)
(evidence / "exit-code.txt").write_text(f"{result.returncode}\n", encoding="utf-8")
print("exit:", result.returncode)
print(result.stdout.decode("utf-8", errors="replace"))
if result.stderr:
    print("stderr:")
    print(result.stderr.decode("utf-8", errors="replace"))
raise SystemExit(result.returncode)

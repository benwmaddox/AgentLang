from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path


root = Path(__file__).resolve().parents[3]
language = Path(__file__).resolve().parent
request_attempt = sys.argv[1] if len(sys.argv) > 1 else "attempt-002"
output_attempt = sys.argv[2] if len(sys.argv) > 2 else "attempt-003"
project_name = sys.argv[3] if len(sys.argv) > 3 else "project-versioned"
attempt = language / output_attempt
attempt.mkdir(parents=True, exist_ok=True)
request_path = language / request_attempt / "requests.jsonl"
wire = request_path.read_bytes()
cli = root / "src" / "AgentLang.Cli" / "bin" / "Release" / "net9.0" / "AgentLang.Cli.dll"
project = language / project_name
command = ["dotnet", str(cli), "--project", str(project), "--jsonl"]
(attempt / "command.json").write_text(
    json.dumps({"workingDirectory": str(root), "command": command}, indent=2) + "\n",
    encoding="utf-8",
)
(attempt / "requests.jsonl").write_bytes(wire)
result = subprocess.run(command, input=wire, capture_output=True, cwd=root, timeout=180)
(attempt / "stdout.jsonl").write_bytes(result.stdout)
(attempt / "stderr.txt").write_bytes(result.stderr)
(attempt / "exit-code.txt").write_text(f"{result.returncode}\n", encoding="utf-8")
responses = [json.loads(line) for line in result.stdout.splitlines() if line]
summary = {
    "exitCode": result.returncode,
    "requestCount": len(wire.splitlines()),
    "responseCount": len(responses),
    "responses": [
        {"ok": response.get("ok"), "kind": response.get("kind"), "text": response.get("text"), "error": response.get("error")}
        for response in responses
    ],
}
(attempt / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
print(json.dumps(summary, indent=2))
raise SystemExit(result.returncode)

from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path


root = Path(__file__).resolve().parents[3]
language = Path(__file__).resolve().parent
attempt_name = sys.argv[1] if len(sys.argv) > 1 else "attempt-004"
attempt = language / attempt_name
attempt.mkdir(parents=True, exist_ok=True)
fixtures = [
    ("business-values.agent", 1),
    ("business-store.agent", 1),
    ("business-state.agent", 1),
    ("business-invoices.agent", 1),
    ("business-payments-email.agent", 1),
    ("business-subscriptions.agent", 2),
]
requests = []
sources = []
for filename, version in fixtures:
    path = root / "examples" / filename
    source = path.read_text(encoding="utf-8")
    sources.append({"path": str(path), "syntaxVersion": version, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
    requests.append({"op": "define", "frontend": "flow", "syntaxVersion": version, "source": source})
requests.append({"op": "test-all", "frontend": "flow", "syntaxVersion": 2})
if "--aggregate-library" in sys.argv[2:]:
    requests.extend([
        {"op": "discard", "word": "email.apply-delivery-result"},
        {"op": "discard", "word": "email.delivery-fold-step"},
        {"op": "commit", "library": True},
    ])
if "--library" in sys.argv[2:]:
    for word in [
        "occupied-period.valid?",
        "occupied-period.try-create",
        "occupied-period.overlaps?",
        "subscription.occupied-period",
        "subscription.overlap-step",
        "subscription.has-overlap?",
        "subscription.start",
    ]:
        requests.append({"op": "commit", "word": word, "library": True})
wire = "".join(json.dumps(request, ensure_ascii=False, separators=(",", ":")) + "\n" for request in requests)
(attempt / "requests.jsonl").write_text(wire, encoding="utf-8")
(attempt / "input-sources.json").write_text(json.dumps(sources, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"attempt": attempt_name, "requestCount": len(requests), "sources": sources}, indent=2))

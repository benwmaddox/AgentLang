# Organic reuse 200 focused follow-up review

Review snapshot: 2026-10-11. Scope was the frozen scorer, unit checks, tracked plan, task packets, and protocol/runtime source needed to check their interfaces. I did not edit those files or run the scorer, unit checks, CLI, controls, or participants. The fullRelease198 policy result is accepted with 37 checks per root; its package commit and the participant-specific source/runtime pin comparison remain pending. This review does not authorize participant dispatch.

## Concrete gaps before relying on the follow-up results

1. **Signature eligibility is formatting-sensitive.** `flow_definition_signature` returns raw parameter and result type text, and `find_eligible_helpers` compares those strings directly with `TASK_SIGNATURES`. A type-equivalent signature with harmless whitespace variation (for example, `Result<Store,  BusinessError>`) will not match the frozen `Result<Store, BusinessError>` tuple and could be counted as an organic helper. Normalize type whitespace before comparison and add a synthetic formatting-variant case. The existing fixtures verify both task signatures only in the exact spelling used by the packets.

2. **Discovery can miss valid helper names and permitted inspection responses.** Exact set membership and the prefix-collision fixture fix the earlier false positive. However, `FLOW_WORD_NAME` requires at least one dot, while creator task requirements do not constrain an optional helper to a dotted name. A simple helper such as `renew` returned by `words` or `dependencies` is discarded. Also, `INSPECTION_OPS` omits `tests` and `examples`; the V2 protocol classifies metadata listings for those operations as inspection, and they are in the actor whitelist. If discovery means a successful broker inspection exposed the exact helper name, these paths need exact-name extraction too. Add fixtures for an undotted helper and a successful `examples` or `tests` metadata response before interpreting a missing trace discovery as evidence of non-discovery.

3. **The tracked plan does not give a usable successor scorer command.** It says to repeat the scorer with `--stage successor`, but `main` rejects successor scoring unless `--creator-project` and `--eligible-helpers` are also supplied. `--trace` is optional, which leaves `discovery.status` as `trace-not-provided`; without it the reuse endpoint can be scored, but discovery cannot. Document the accepted creator snapshot path, creator `helper-eligibility.json` path, and successor trace path in the successor invocation.

4. **The unit check overwrites the case export before checking it.** `unit_checks.main()` calls `model.export()` before `test_typed_cases()`. Since `model.export()` writes `cases.json`, the subsequent equality assertion compares a freshly rewritten file with `model.make_cases()` and cannot detect a stale or hand-edited frozen export. The production scorer itself correctly calls `load_frozen_cases()` and validates the checked-in export before scoring. Change the unit check to compare the existing export before any write, or make the check non-writing, so its reported equality check is meaningful and preserves the frozen case artifact.

5. **The tracked plan's gate status is stale.** It still says the isolated fullRelease198 business-policy gate is in progress. Root reports that gate accepted with 37 checks per root, with the package commit pending. Refresh this status before the next run; participant dispatch remains blocked by the pending commit, relevant source/runtime pin comparison, and control acceptance.

## Verified follow-up points

- The scorer now accepts only `ok=true, kind="defined"` for observer setup. The synthetic discriminator checks `defined`, rejects the old `define` spelling, and rejects `ok=false`.
- Discovery now parses successful inspection response metadata into exact returned identifiers, then intersects those names with eligible helpers. Its synthetic trace fixture rejects the shorter `subscription.renew` prefix inside `subscription.renew-batch`, a failed inspection, and a non-inspection `eval`, while accepting an exact returned dependency name.
- `TASK_SIGNATURES` contains both creator and successor public type signatures. The production graph selects the revision pointed to by each word's `currentRevision`, and only includes `word-definition` bindings whose source hash matches that selected definition. The synthetic manifest includes a stale non-current revision with call bindings and confirms it does not create a path. Test, example, observer-kind, and stale-body bindings are excluded.
- `load_frozen_cases()` reads `cases.json`, compares the full object to `model.make_cases()`, and returns the frozen stage list for scoring. The scorer records that file's hash and describes it as the checked and used audit export.
- The scoring subprocess explicitly uses `--filesystem virtual` and supplies neither `--allow` nor `--test-allow`; the CLI defaults both normal and test capabilities to an empty set. The host invocation uses the V2 wrapper's empty default `Capabilities` and virtual filesystem mode.
- The verified V2 schema-1 trace has object-valued `request` and `response`; their `canonical`/`rawLine` values are strings containing JSON. This matches the parser's `json.loads` inputs. No trace or runtime command was run in this review.

## Frozen file pins

These hashes identify the exact snapshot reviewed. Subsequent edits require a focused re-review and new pins.

```text
e6b61e596610010075e6ab5ddea34ee1e28f8c2cba3ab83fc0ae59ed86e69e1e  experiments/AgentLang.SubagentTrials/organic-reuse-200/PLAN.md
ebcd232ec856f248788ae591a8bdbd24cf7ad9baba7e0fd0e2e2d221aa6c8834  .agentlang/organic-reuse-200/preparation/creator-packet.md
6c1ef87dc4aba9e44d9bcb6e3f650180013a46e154f38febac2a076b465ca880  .agentlang/organic-reuse-200/preparation/successor-packet.md
887edeccb3b3503466ddcadaecd04c04487aafc1f79be896116428a91be3c7d1  experiments/AgentLang.SubagentTrials/organic-reuse-200/oracle/score_organic_reuse.py
7ad1891ed434da0126c659a56b0eb5563e011532797753bbb6b35d9bc884937f  experiments/AgentLang.SubagentTrials/organic-reuse-200/oracle/unit_checks.py
29af0d9af75d6533a98f717f9ed4d7ae44ecd90b566b68327746d6ec18b282dd  experiments/AgentLang.SubagentTrials/organic-reuse-200/oracle/model.py
195e9ec595e88301a27a36a2dd6987a0ac4d8f6c49e2bc807db490cbc696e495  experiments/AgentLang.SubagentTrials/organic-reuse-200/oracle/cases.json
e1442c614f6c41abd1657b18b9095027010d1282fb2dc29b916e1cd05c509117  src/AgentLang.Core/Runtime.fs
1fb6980b6acaab87d4e91155030237eaff80c0d0a61bdd536388846e983f29da  src/AgentLang.Cli/Program.fs
84540e438b5630c0fab868077d6dcb75d55036f0177186a06727115b4dd60684  scripts/Start-SubagentTrialHostV2.ps1
0c4bb589256a263397d532d152d5f6de2d8816acddb25c2291c0e09dde4367e2  docs/SUBAGENT-TRIAL-HOST-V2.md
c0ed8ec51939483b77d11a0ee0f93feaae2b5e378a0cd3a3e986a1e3c6602c59  reports/evidence/080-transport-traces/clean-source-validation/trial-host-v2-ea4ee2ca9eb449c3a3488d52fd52e940-real-cli-write-close.jsonl
```

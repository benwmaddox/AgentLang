from pathlib import Path
import json,os,shutil,subprocess
repo=Path.cwd();root=repo/'.agentlang/organic-reuse-200';out=root/'preflight/fold-001'
if out.exists():raise RuntimeError('Preserve existing fold run')
out.mkdir(parents=True)
project=out/'project';shutil.copytree(root/'preflight/seed-001/project',project)
help_rows=[json.loads(l) for l in (root/'preflight/seed-001/responses.jsonl').read_text().splitlines()]
rows=[e for e in help_rows[2]['data']['requestExamples'] if 'fold' in e['name']]
assert len(rows)==5
wire=''.join(json.dumps(e['request'],separators=(',',':'))+'\n' for e in rows)
(out/'requests.jsonl').write_text(wire)
env=dict(os.environ,TEMP=str(root/'tmp'),TMP=str(root/'tmp'))
p=subprocess.run(['dotnet',str(root/'runtime/AgentLang.Cli.dll'),'--project',str(project),'--filesystem','virtual','--jsonl'],input=wire,text=True,capture_output=True,env=env,timeout=180)
(out/'responses.jsonl').write_text(p.stdout);(out/'stderr.txt').write_text(p.stderr)
r=[json.loads(l) for l in p.stdout.splitlines()]
assert p.returncode==0 and len(r)==5 and all(e['ok'] for e in r)
assert r[0]['kind']=='defined'
for e in r[1:3]:assert all(t['passed'] for t in e['data']['results'])
summary={'status':'passed-fold-guidance-only; no participant acceptance','exitCode':p.returncode,'requestExamples':[e['name'] for e in rows],'responseKinds':[e['kind'] for e in r]}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))

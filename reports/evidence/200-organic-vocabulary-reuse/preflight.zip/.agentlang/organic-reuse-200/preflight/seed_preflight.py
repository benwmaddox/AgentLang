from pathlib import Path
import hashlib,json,os,shutil,subprocess
repo=Path.cwd()
root=repo/'.agentlang/organic-reuse-200'
out=root/'preflight/seed-001'
if out.exists(): raise RuntimeError('Preserve existing preflight run')
out.mkdir(parents=True)
project=out/'project'
shutil.copytree(repo/'.agentlang/subscription-handoff-161/seeds/agentlang-project',project)
cli=root/'runtime/AgentLang.Cli.dll'
pins=json.loads((root/'runtime-pin.json').read_text(encoding='utf-8-sig'))
for pin in pins['files']:
    assert hashlib.sha256((cli.parent/pin['name']).read_bytes()).hexdigest()==pin['sha256']
host=json.loads((repo/'.agentlang/native-bool-198/full-validation-attempt2.subagent-host-v2.json').read_text(encoding='utf-8-sig'))
assert host['outcome']=='passed'
byname={p['name']:p['sha256'] for p in pins['files']}
assert all(byname[p['name']]==p['sha256'] for p in host['cliFiles'])
requests=[{'op':'words'},{'op':'test-all'},{'op':'help','topic':'examples','syntaxVersion':2},{'op':'help','topic':'define','syntaxVersion':2}]
wire=''.join(json.dumps(q,separators=(',',':'))+'\n' for q in requests)
(out/'requests.jsonl').write_text(wire)
tmp=root/'tmp';tmp.mkdir(exist_ok=True)
env=dict(os.environ,TEMP=str(tmp),TMP=str(tmp))
r=subprocess.run(['dotnet',str(cli),'--project',str(project),'--filesystem','virtual','--jsonl'],input=wire,text=True,capture_output=True,env=env,timeout=180)
(out/'responses.jsonl').write_text(r.stdout)
(out/'stderr.txt').write_text(r.stderr)
responses=[json.loads(line) for line in r.stdout.splitlines()]
assert r.returncode==0 and len(responses)==len(requests) and all(p['ok'] for p in responses),r.stderr
assert len(responses[1]['data']['results'])==137 and all(t['passed'] for t in responses[1]['data']['results'])
summary={'status':'passed-seed-and-help-only; no control/participant acceptance','exitCode':r.returncode,'seedTests':137,'hostVerificationReusedByExactRuntimeHash':str(repo/'.agentlang/native-bool-198/full-validation-attempt2.subagent-host-v2.json'),'responses':len(responses),'runtimePins':pins['files']}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))

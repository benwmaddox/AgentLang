# Organic reuse 200 review

Review snapshot: 2026-10-11, after preparation was reported frozen. This is a static correctness and provenance review. I did not run the CLI, actors, controls, or Python checks. The native 198 final Release gate is still pending, so there is no runtime or participant pass claim.

## Blockers before scoring

1. `score_organic_reuse.py` requires the observation definition response to have `kind == "define"` (line 515). The current runtime returns `kind == "defined"` for successful Flow definitions (`Runtime.fs:4636, 5264`), which matches the verified V2 trace. Therefore `observer_defined` is always false and every score is reported as `score-failure`, even when the observer was successfully defined. Match the current protocol response kind.

2. `trace_discovery` uses `name in response_text` (line 300). This can report discovery when a shorter helper identifier is merely a prefix of another returned name, such as eligible helper `subscription.renew` appearing inside `subscription.renew-batch`. Parse returned word names from the successful inspection response and use exact identifier equality. Add a synthetic prefix-collision check. This matters to the discovery endpoint; production call-graph reuse is scored separately.

## Review findings

- The approved and trial plans are byte-identical. The creator packet leaves helper choice unnamed and optional; it requires the two fixed-term public operations. The successor packet is a separate task and contains no creator prompt, trace, hidden cases, or helper name. Both packets require broker-only work and preservation of inherited definitions and attachments.
- The creator model deep-copies the 33 report-163 cases for each operation and substitutes `monthly` or `annual` before evaluating expected behavior. It correctly removes `term` from the public request. The inherited `blank-term` fixture consequently becomes a successful fixed-term case, as intended. The checked-in model checks record 66 observations and distinct controls.
- The batch model applies each renewal to an evolving Store in list order, returns the first error without a Store payload, and projects the original input. Its nine cases include a valid prefix followed by failure, first-error precedence, duplicate IDs, unrelated active overlap, and Store/list-order preservation. The atomicity mutant returns `ok` with a partial Store after a later failure; the ordering mutant changes `first-error-precedes-later-expiry`. The creator start-before-cancel and wrong-`ok` mutants also discriminate; `bad-period-precedes-overlap` expects expiry error while the leak mutant returns the cancelled-only Store as `ok`.
- The observer projection checks the complete typed Store lists in order and includes both the outcome and caller input. Independent behavior is computed from the cell model, while preservation is a separate status gate. The preservation projection compares inherited word identity, current revision, source hash, maturity, attached test/example hashes, and type hashes; the successor is compared both with the report-163 seed and the accepted creator. The seed inventory has only current revision 1 entries, so this covers the inherited definitions and attachments present in that seed.
- Helper eligibility rejects seed names and identities, requires library maturity, and requires production call paths from both creator roots. The graph selects each word's current revision, then accepts only `word-definition` bindings whose source hash matches that revision's definition and whose target is a user word; this excludes test/example/observer bindings and stale-body bindings. The manifest schema stores source kind/hash on each binding and revision on its containing revision row, so selecting `currentRevision` is the revision check. The unit fixture tests kind/hash filtering and no-helper behavior; it does not explicitly include a stale non-current revision row.
- A no-helper creator result is a valid stop: `creatorReadyForSuccessor` remains false, and successor scoring rejects an empty helper set. The successor scorer requires a creator snapshot whose fingerprint matches the eligibility record. Its success status still reports behavior and workflow gates independently from `helperReuse` and `discovery`; a correct behavior score alone must not be described as reuse.
- The planned V2 schema-1 trace shape matches the scorer: each exchange has `operation`; `request` and `response` are objects; their `canonical` and `rawLine` fields are strings containing serialized JSON. The discovery parser's JSON decoding assumption is correct for this trace. `--trace` remains optional in the scorer, so a successor result with `trace-not-provided` cannot support a discovery claim.
- The planned actor whitelist is explicit, and the host defaults `Capabilities` to an empty array. The AgentLang CLI also defaults capabilities to empty and the host selects virtual filesystem mode. The host protocol is a transport wrapper, not an OS sandbox; platform-level access to other tools must remain disabled if isolation is to be enforced beyond the prompt.

## Non-blocking provenance limit

The scorer executes cases from `MODEL.creator_cases()` or `MODEL.BATCH_CASES`, but records `caseSourceSha256` for `cases.json`, which it does not load. The model source hash does pin the effective generated cases, and the checked-in JSON appears to be its exported artifact, but the report label overstates which file supplied observations. Load and validate the frozen case file or hash the serialized effective case set.

## Frozen file pins

These SHA-256 values identify the exact files inspected in this review. Any subsequent edit to them invalidates this snapshot and needs a focused re-review. `plan.md` and `PLAN.md` have the same hash.

```text
2f650751e77acf5f873e4de22787076f31366ddd2f6cd6436065858796464b16  .agentlang/organic-reuse-200/plan.md
2f650751e77acf5f873e4de22787076f31366ddd2f6cd6436065858796464b16  experiments/AgentLang.SubagentTrials/organic-reuse-200/PLAN.md
ebcd232ec856f248788ae591a8bdbd24cf7ad9baba7e0fd0e2e2d221aa6c8834  .agentlang/organic-reuse-200/preparation/creator-packet.md
6c1ef87dc4aba9e44d9bcb6e3f650180013a46e154f38febac2a076b465ca880  .agentlang/organic-reuse-200/preparation/successor-packet.md
03d69f6fdf9e165d8d7c284eec1569e63579dfc3cc1e1e1cebfd1dcd50f15c59  .agentlang/organic-reuse-200/preparation/preflight-gaps.md
29af0d9af75d6533a98f717f9ed4d7ae44ecd90b566b68327746d6ec18b282dd  experiments/AgentLang.SubagentTrials/organic-reuse-200/oracle/model.py
775191725d9a237130ec9ca2190a4fc05605df8b4ff868176e503f20e459f3ab  experiments/AgentLang.SubagentTrials/organic-reuse-200/oracle/cell_model_163.py
195e9ec595e88301a27a36a2dd6987a0ac4d8f6c49e2bc807db490cbc696e495  experiments/AgentLang.SubagentTrials/organic-reuse-200/oracle/cases.json
9b43a26895c334a2c543c830dd99521ea4b3da2ad2a44395b54415992e018ff5  experiments/AgentLang.SubagentTrials/organic-reuse-200/oracle/model-checks.json
f9595f613ac8baefe3d7bbee9a41fb7b9ffe8889d5d88f0ea8a7f4ce9ebf811b  experiments/AgentLang.SubagentTrials/organic-reuse-200/oracle/seed-inventory.json
8973a77555bf6bef7995de3272ec801af587441ccfd48de4d0063f6a93ad44c5  experiments/AgentLang.SubagentTrials/organic-reuse-200/oracle/score_organic_reuse.py
7ca1e09312135e7b301b0383eaf448a1afde266c6c2419859d06bfdb5a190d11  experiments/AgentLang.SubagentTrials/organic-reuse-200/oracle/unit_checks.py
bb3a9e4c353b9e445a557724745e15d52c4f44e2a536b1a305a1ccf5b9da117f  experiments/AgentLang.SubagentTrials/subscription-handoff-161/PLAN.md
775191725d9a237130ec9ca2190a4fc05605df8b4ff868176e503f20e459f3ab  experiments/AgentLang.SubagentTrials/subscription-handoff-161/oracle/model.py
af113f380d7e9e02d6c0bfad5b100472023a1cc3f0b887adfec8249ab2934aae  experiments/AgentLang.SubagentTrials/subscription-handoff-161/oracle/cases.json
847c8ac9d6b9a90022db55d3ee003de7d73014cc909ec02cacb21c38b1623686  experiments/AgentLang.SubagentTrials/subscription-handoff-161/oracle/score_agentlang.py
ff4f004340d8279d9b0616ba44c4d3fbb4fb650be1785599639055d36110c351  experiments/AgentLang.SubagentTrials/subscription-handoff-maintenance-166/oracle/score_agentlang.py
0c4bb589256a263397d532d152d5f6de2d8816acddb25c2291c0e09dde4367e2  docs/SUBAGENT-TRIAL-HOST-V2.md
84540e438b5630c0fab868077d6dcb75d55036f0177186a06727115b4dd60684  scripts/Start-SubagentTrialHostV2.ps1
30e391e4d2c716a998016388bd2305496682a3f0579c9de33c5259aa53bd9b25  scripts/Verify-SubagentTrialHostV2.ps1
870ff9b9a1843c0a104d2185688486c7ed1e85399df6c554f9ee890c4dcf4a10  scripts/Audit-SubagentTrialTerminationV2.ps1
e1442c614f6c41abd1657b18b9095027010d1282fb2dc29b916e1cd05c509117  src/AgentLang.Core/Runtime.fs
1fb6980b6acaab87d4e91155030237eaff80c0d0a61bdd536388846e983f29da  src/AgentLang.Cli/Program.fs
c0ed8ec51939483b77d11a0ee0f93feaae2b5e378a0cd3a3e986a1e3c6602c59  reports/evidence/080-transport-traces/clean-source-validation/trial-host-v2-ea4ee2ca9eb449c3a3488d52fd52e940-real-cli-write-close.jsonl
```

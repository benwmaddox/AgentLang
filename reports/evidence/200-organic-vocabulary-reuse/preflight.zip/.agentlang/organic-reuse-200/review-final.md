# Organic reuse 200 final focused review

Review snapshot: 2026-10-11. This read-only pass covered the frozen scorer, unit-check source, plan, preparation preflight note, control builder/runner, model, cases, and the recorded control summary. I did not execute unit checks, a scorer, CLI, runtime, controls, or participants.

The prior concrete gaps are fixed in this snapshot. Signature parsing normalizes type whitespace, including multiline headers, and the synthetic fixtures exclude both task signatures in exact and formatting-varied forms. Name parsing accepts undotted identifiers and uses exact membership, so a shorter prefix does not match a longer returned name.

Discovery claims are separated correctly. `discoveredHelpers` is formed only from exact eligible names in successful inspection **responses**. The V2 `tests` and `examples` response data is a list of case names, so those case names are not treated as helpers. Their successful request owner is recorded separately under `metadataInspectedHelpers`; it is not reported as a name returned by the broker. The synthetic fixtures exercise both classifications, along with failed inspections and non-inspection responses.

The unit-check source reads and compares the existing `cases.json` and `model-checks.json` against generated model values, rejects a synthetic mismatch, and compares file hashes before and after. It contains no `model.export()` call, so it does not rewrite the frozen exports. Its typed fixtures cover the creator and successor cases. These are source-review findings; the unit checks still need the root-owned run.

The successor command in the plan now supplies `--creator-project`, `--eligible-helpers`, and the successor `--trace`, as well as the actor project, CLI, and evidence root. The plan records native198 acceptance, all 37 checks, and commit `0da7c2761ca02bc3bb2d7e6dab22f8e83525c20d`. It correctly leaves the root's final source/runtime/control hash comparison as a dispatch gate. The recorded control summary has six `preflight-passed` variants and explicitly sets `participantDispatchAllowed` to false; this review does not treat those controls as participant evidence. The current control builder, runner, model, and case hashes are pinned below. Their recorded last-write UTC times precede the control attempt timestamp; root's final hash comparison remains authoritative.

The plan identifies this as a one-chain efficacy pilot. It does not support comparative or causal claims, reliability estimates, or provider token/context conclusions.

## Reviewed file pins

```text
0ffedc94f2766a01bc77a8f450574f994724bcf8c1fdd441325808442a0e4a9e  experiments/AgentLang.SubagentTrials/organic-reuse-200/oracle/score_organic_reuse.py
2dcc4f547189ca6f764615c934131cddb00def96523fc65e79ea7ab16beb7a35  experiments/AgentLang.SubagentTrials/organic-reuse-200/oracle/unit_checks.py
febcff9c0b4f30e56fe007ba6f023c113a0985129c70f69fdf146b0de9317452  experiments/AgentLang.SubagentTrials/organic-reuse-200/PLAN.md
a6ff977157c3a001deea1e3f1ee83c4b105a526a1c6b9bda9d3db45fbd642fa8  .agentlang/organic-reuse-200/preparation/preflight-gaps.md
a0cfc88298f0f17b79c1e674731b02515cf3295c487e07a1b45b80923ffdea1c  experiments/AgentLang.SubagentTrials/organic-reuse-200/oracle/control_preflight.py
608687e609d471e436dcba6465f408f52821e3fa8a5b391e7a8b44899a32ce86  experiments/AgentLang.SubagentTrials/organic-reuse-200/oracle/run_preflight_controls.py
29af0d9af75d6533a98f717f9ed4d7ae44ecd90b566b68327746d6ec18b282dd  experiments/AgentLang.SubagentTrials/organic-reuse-200/oracle/model.py
195e9ec595e88301a27a36a2dd6987a0ac4d8f6c49e2bc807db490cbc696e495  experiments/AgentLang.SubagentTrials/organic-reuse-200/oracle/cases.json
4b18990af576e588967ceb9a402215b7892373ee6a61a8bcb1c797fc466e27d8  .agentlang/organic-reuse-200/preflight/controls/attempts/20261011T050533Z-01/control-preflight-summary.json
88da6d255cd8434995df1ae206c7a27fcfcc69fb7baa080ea66842589b1bd8d0  .agentlang/organic-reuse-200/accepted-runtime-pin.json
```

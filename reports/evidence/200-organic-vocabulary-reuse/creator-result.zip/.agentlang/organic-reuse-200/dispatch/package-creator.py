import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parents[3]
study = root / '.agentlang/organic-reuse-200'
out = root / 'reports/evidence/200-organic-vocabulary-reuse'
archive = out / 'creator-result.zip'
index = out / 'creator-result.index.json'
if archive.exists() or index.exists():
    raise RuntimeError('Refuse to overwrite sealed participant evidence')
paths = [study / 'traces/creator.jsonl']
for directory in ['dispatch', 'actors/creator', 'scoring/creator']:
    paths.extend(p for p in (study / directory).rglob('*') if p.is_file())
for name in ['accepted-runtime-pin.json', 'source-pin.json', 'frozen-inputs.json']:
    paths.append(study / name)
members = []
with ZipFile(archive, 'x', ZIP_DEFLATED, compresslevel=9) as z:
    for path in sorted(set(paths)):
        data = path.read_bytes()
        name = path.relative_to(root).as_posix()
        z.writestr(name, data)
        members.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
with ZipFile(archive) as z:
    assert len(z.namelist()) == len(members)
    for row in members:
        data = z.read(row['path'])
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
receipt = {
    'status': 'closed creator; accepted behavior and preservation; no eligible helper; no successor',
    'archive': archive.relative_to(root).as_posix(),
    'archiveBytes': archive.stat().st_size,
    'archiveSha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'memberCount': len(members),
    'members': members,
    'limits': 'Actor output and observer scoring copy are separate. No compiled runtime included; hashes retained. No successor result exists.'
}
index.write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: v for k, v in receipt.items() if k != 'members'}))

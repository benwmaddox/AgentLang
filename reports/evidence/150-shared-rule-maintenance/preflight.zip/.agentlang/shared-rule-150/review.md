# Rule 150 preflight review

**Status: ready for participant dispatch.** This review checked source, provenance, and recorded acceptance evidence only; it did not rerun project suites. No participant run artifacts are present yet.

The frozen oracle is independent of either control. The singleton and batch scorers compute expected results by enumerating only each rental's bounded stored days, filtering `day > start`, the half-open request interval, and cancellation. Invalid windows return `INVALID_BILLING_WINDOW`. The F# harnesses implement the same bounded enumeration directly from the frozen case JSON. No expected result is read from a control or inferred from an observed result. Coverage is 21 singleton, 9 direct-helper, and 18 batch cases per arm.

All six positive control acceptances pass with inputs unchanged: Flow has 21/21 singleton, 9/9 helper, and 18/18 batch cases; F# has the same counts. Flow also reports 42, 18, and 72 oracle test rows, respectively, with inherited suites passing. The F# builds and oracle executions exit 0. Recorded control suites pass 61/61 Flow tests and 74/74 F# assertions; Flow's fresh reload also passes both helper examples and retains current library qualification for the helper and its callers.

Both negative mutations execute and fail behavior. The window-relative waiver builds successfully, then fails 4 singleton cases, 4 helper cases, and 1 batch case. The stale-batch mutation builds successfully, then fails 9 batch cases while its singleton and helper suites pass all 21 and 9 cases. The original 149 starts also execute all six arm/API runs and fail the new policy with 9 singleton, 4 helper, and 9 batch differences per arm.

The controls implement the policy through one shared calculation: Flow advances the original rental start before clipping and routes singleton and aggregate callers through that helper; F# excludes the original start when it is included in the clipped overlap and routes both result APIs through the same helper. The Flow list fold delegates to that calculation. The control evidence records separate seed copies and no oracle or sibling output reads.

Start provenance and inventories agree with the 149 final sources: I verified all 95 Flow and 8 F# inventoried files against both the retained starts and their 149 source paths, with zero hash mismatches. Both participant prompt hashes match the wrapper-embedded digests. The prompts contain the public task and isolation instructions without oracle cases, control results, or implementation guidance. Participant directories contain only the assigned projects, prompts, wrappers, and inventories.

**Limit:** the two behavioral mutations are F# probes only; they exercise all three APIs, while positive acceptance covers both languages. This review makes no claim about fresh-agent outcomes, since dispatch has not started.

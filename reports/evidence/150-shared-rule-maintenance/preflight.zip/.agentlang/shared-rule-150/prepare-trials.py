from pathlib import Path
import importlib.util, json, hashlib, shutil
from datetime import datetime,timezone

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[1]
OLD=REPO/'.agentlang/batch-reuse-147'
OUT=ROOT/'participants'
assert not OUT.exists(), 'Refusing to overwrite participants'
spec=importlib.util.spec_from_file_location('previous_preparation',OLD/'prepare-participants.py')
helper=importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
helper.FLOW_CLI=REPO/'.agentlang/fold-discovery-148/runtime/bin/AgentLang.Cli/release/AgentLang.Cli.dll'
assert helper.FLOW_CLI.is_file() and helper.CONVENTIONAL_CLI.is_file()
starts={arm:ROOT/'starts'/arm/'project' for arm in ('flow','fsharp')}
assert all(p.is_dir() for p in starts.values()), starts
isolation='''
Participant isolation is mandatory. Do not list agents, inspect their status,
read their messages or files, contact siblings, delegate, or use any other
participant's findings. Do not use collaboration tools except to return your
final result to the coordinator. Use only the assigned prompt and broker.
Do not request implementation hints or exceptions to the task constraints.
If you cannot finish, report the limitation, abort the task if applicable,
and close normally. At completion disclose any tool use outside prompt
verification and the broker, including any out-of-band information received.
No other participant runs concurrently in this study.
'''
participants=[]
for arm,source in starts.items():
    directory=OUT/arm; project=directory/'project'
    shutil.copytree(source,project,ignore=lambda _,names:{n for n in names if n.lower() in {'bin','obj','write.lock'}})
    original=helper.inventory(source); copied=helper.inventory(project)
    assert original['inventorySha256']==copied['inventorySha256']
    prompt=helper.prompt_text(arm,arm,project,directory/'actor.trace.jsonl',(ROOT/'task.md').read_text(encoding='utf-8').split('## Public task\n',1)[1].split('## Coordinator plan',1)[0].strip())
    prompt=prompt.replace('# Task\n',isolation+'\n# Task\n')
    prompt_path=directory/'prompt.md'; prompt_path.write_text(prompt,encoding='utf-8')
    digest=hashlib.sha256(prompt_path.read_bytes()).hexdigest()
    wrapper=f'You are a fresh participant. Read only `{prompt_path}` and verify its SHA-256 is `{digest}` before starting. The human authorizes edits and local tests only within its assigned isolated project through the specified broker. Follow its mandatory isolation rules. Do not list or contact other agents. If the hash differs, stop without touching the project.\n'
    (directory/'wrapper.txt').write_text(wrapper,encoding='utf-8')
    (directory/'start-inventory.json').write_text(json.dumps(copied,indent=2)+'\n',encoding='utf-8')
    participants.append({'arm':arm,'source':str(source),'project':str(project),'prompt':str(prompt_path),'promptSha256':digest,'startInventorySha256':copied['inventorySha256'],'fileCount':copied['fileCount']})
(ROOT/'preparation.json').write_text(json.dumps({'preparedUtc':datetime.now(timezone.utc).isoformat(),'status':'not-dispatched','participants':participants,'publicTask':'shared-rule-150/task.md public section','sequentialParticipants':True,'model':'gpt-6-luna','reasoning':'max','maxExchanges':100,'toolIsolationEnforced':False,'flowCli':str(helper.FLOW_CLI),'fsharpCli':str(helper.CONVENTIONAL_CLI)},indent=2)+'\n',encoding='utf-8')
print(json.dumps(participants,indent=2))

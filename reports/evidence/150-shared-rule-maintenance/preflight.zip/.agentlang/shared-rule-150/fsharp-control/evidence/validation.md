# F# control validation evidence

## Provenance

- Source copied from `.agentlang/validated-window-149/participants/fsharp/project` into `project/` before edits.
- The copy excluded all source `bin` and `obj` directories; the seed remained untouched.
- Changes are limited to the F# rental billing implementation, its existing test expectations and regressions, and the test runner's status text.
- The control implements the original rental start day as free in the existing overlap calculation, so all three billing APIs share the policy.
- No oracle, prior control, result, trace, or sibling output was read.

## Build

Command, run from `fsharp-control/project/`:

```text
dotnet build tests/RentalDomain.Tests.fsproj -c Release -m:1 -p:NuGetAudit=false
```

Exit code: `0`

Output:

```text
  Determining projects to restore...
  Restored D:\code\AgentLang\.agentlang\shared-rule-150\fsharp-control\project\tests\RentalDomain.Tests.fsproj (in 115 ms).
  Restored D:\code\AgentLang\.agentlang\shared-rule-150\fsharp-control\project\project\RentalDomain.fsproj (in 115 ms).
  RentalDomain -> D:\code\AgentLang\.agentlang\shared-rule-150\fsharp-control\project\project\bin\Release\net9.0\RentalDomain.dll
  RentalDomain.Tests -> D:\code\AgentLang\.agentlang\shared-rule-150\fsharp-control\project\tests\bin\Release\net9.0\RentalDomain.Tests.dll

Build succeeded.
    0 Warning(s)
    0 Error(s)

Time Elapsed 00:00:03.27
```

## Test suite

Command, run from `fsharp-control/project/`:

```text
dotnet tests/bin/Release/net9.0/RentalDomain.Tests.dll
```

Exit code: `0`

Output:

```text
PASS 74 assertions (baseline and billing policy coverage)
```

Total assertions passed: `74`. No command failures occurred.

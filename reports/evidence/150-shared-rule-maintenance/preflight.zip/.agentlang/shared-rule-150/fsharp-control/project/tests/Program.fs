open DomainBaselineTests
open BillingWindowTests

[<EntryPoint>]
let main _ =
    let checks = DomainBaselineTests.run () + BillingWindowTests.run ()
    printfn "PASS %d assertions (baseline and billing policy coverage)" checks
    0

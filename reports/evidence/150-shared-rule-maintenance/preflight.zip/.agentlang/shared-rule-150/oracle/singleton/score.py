#!/usr/bin/env python3
"""Score the shared rental billing cases against copied Flow or F# projects."""

from __future__ import annotations

import argparse
import hashlib
import html
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any


HERE = Path(__file__).resolve().parent
CASES_PATH = HERE / "cases.json"
FSHARP_PROGRAM = HERE / "fsharp" / "Program.fs"
INT64_MIN = -(2**63)
INT64_MAX = 2**63 - 1


def quote(value: str) -> str:
    return json.dumps(value, ensure_ascii=False)


def read_cases(api: str) -> list[dict[str, Any]]:
    cases = json.loads(CASES_PATH.read_text(encoding="utf-8"))["cases"]
    seen: set[str] = set()
    for case in cases:
        case_id = case.get("id")
        if not isinstance(case_id, str) or not re.fullmatch(r"[a-z][a-z0-9-]*", case_id):
            raise ValueError(f"invalid case id: {case_id!r}")
        if case_id in seen:
            raise ValueError(f"duplicate case id: {case_id}")
        seen.add(case_id)
        start, finish = case["start"], case["finish"]
        cancellation = case["cancel"]
        from_day, until_day = case["from"], case["until"]
        if not (0 <= start < finish <= 366):
            raise ValueError(f"case {case_id} has invalid stored rental bounds")
        if cancellation is not None and cancellation < start:
            raise ValueError(f"case {case_id} has cancellation before start")
        if not (INT64_MIN <= from_day <= INT64_MAX and INT64_MIN <= until_day <= INT64_MAX):
            raise ValueError(f"case {case_id} has a request bound outside Int64")
        if api == "helper" and from_day >= until_day:
            raise ValueError(f"helper case {case_id} must use a valid billing window")
    return cases


def expected_outcome(case: dict[str, Any]) -> str:
    from_day = case["from"]
    until_day = case["until"]
    if from_day >= until_day:
        return "error:INVALID_BILLING_WINDOW"

    cancellation = case["cancel"]
    # This intentionally walks only the at-most-366 stored rental days.
    # It never enumerates or measures the requested window.
    count = sum(
        1
        for day in range(case["start"], case["finish"])
        if from_day <= day < until_day
        and day > case["start"]
        and (cancellation is None or day < cancellation)
    )
    return f"ok:{count}"


def flow_int(value: int) -> str:
    if value == INT64_MIN:
        return "subtract(-9223372036854775807, 1)"
    return str(value)


def flow_fixture(cases: list[dict[str, Any]], api: str) -> str:
    lines = [
        "record Rule150OracleObservation {",
        "    field outcome: String;",
        "    field input-unchanged: Bool;",
        "}",
    ]
    for case in cases:
        case_id = case["id"]
        lines.extend([
            "",
            f"word rule-150-oracle.run-{case_id}(value: Unit) -> Rule150OracleObservation {{",
            "    effects none",
            f"    match rental::start({case['start']}, {case['finish']}) {{",
            "        error problem => {",
            '            rule150OracleObservation::new(outcome = string::concat("fixture-setup-error:start:", problem.code()), input-unchanged = false)',
            "        }",
            "        ok started => {",
        ])

        current = "started"
        if case["cancel"] is not None:
            lines.extend([
                f"            match rental::cancel(started, {case['cancel']}) {{",
                "                error problem => {",
                '                    rule150OracleObservation::new(outcome = string::concat("fixture-setup-error:cancel:", problem.code()), input-unchanged = false)',
                "                }",
                "                ok cancelled => {",
            ])
            current = "cancelled"
            inner_indent = "                    "
        else:
            inner_indent = "            "

        from_day = flow_int(case["from"])
        until_day = flow_int(case["until"])
        if api == "helper":
            query = f"result::ok<Int, RentalError>(rental::billable-in-window({current}, billingWindow::new(from-day = {from_day}, until-day = {until_day})))"
        else:
            query = f"rental::billable-days({current}, {from_day}, {until_day})"
        lines.extend([
            f"{inner_indent}let before-start = {current}.start-day();",
            f"{inner_indent}let before-finish = {current}.finish-day();",
            f"{inner_indent}let before-cancelled = {current}.cancelled-day();",
            f"{inner_indent}let actual = {query};",
            f"{inner_indent}let unchanged = bool::and(",
            f"{inner_indent}    equals({current}.start-day(), before-start),",
            f"{inner_indent}    bool::and(",
            f"{inner_indent}        equals({current}.finish-day(), before-finish),",
            f"{inner_indent}        equals({current}.cancelled-day(), before-cancelled)));",
            f"{inner_indent}match actual {{",
            f"{inner_indent}    ok days => {{",
            f"{inner_indent}        rule150OracleObservation::new(outcome = string::concat(\"ok:\", int::to-string(days)), input-unchanged = unchanged)",
            f"{inner_indent}    }}",
            f"{inner_indent}    error problem => {{",
            f"{inner_indent}        rule150OracleObservation::new(outcome = string::concat(\"error:\", problem.code()), input-unchanged = unchanged)",
            f"{inner_indent}    }}",
            f"{inner_indent}}}",
        ])
        if case["cancel"] is not None:
            lines.extend(["                }", "            }"])
        lines.extend(["        }", "    }", "}"])

        expected = expected_outcome(case)
        lines.extend([
            "",
            f"test rule-150-oracle.run-{case_id}/exact-result {{",
            f"    let result = rule-150-oracle::run-{case_id}(unit);",
            "    result.outcome()",
            f"    => {quote(expected)}",
            "}",
            f"test rule-150-oracle.run-{case_id}/input-unchanged {{",
            f"    let result = rule-150-oracle::run-{case_id}(unit);",
            "    result.input-unchanged()",
            "    => true",
            "}",
        ])
    return "\n".join(lines) + "\n"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def tree_hashes(root: Path) -> dict[str, str]:
    hashes: dict[str, str] = {}
    for path in sorted(root.rglob("*")):
        relative = path.relative_to(root)
        parts = {part.lower() for part in relative.parts}
        if not path.is_file() or parts.intersection({"bin", "obj"}) or path.name.lower() == "write.lock":
            continue
        hashes[relative.as_posix()] = sha256_file(path)
    return hashes


def copy_project(source: Path, destination: Path) -> None:
    def ignore(_directory: str, names: list[str]) -> set[str]:
        return {name for name in names if name.lower() in {"bin", "obj", "write.lock"}}

    shutil.copytree(source, destination, ignore=ignore)


def prepare_output(project: Path, output: Path) -> Path:
    if output == project or output in project.parents or project in output.parents:
        raise ValueError("output and input project paths cannot overlap")
    if not output.is_dir():
        raise ValueError(f"output directory was not prepared: {output}")
    copied = output / "working-project"
    if copied.exists():
        raise ValueError(f"refusing to overwrite an existing working copy: {copied}")
    copy_project(project, copied)
    return copied


def run_command(command: list[str], *, cwd: Path, stdin: str | None = None) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        cwd=cwd,
        input=stdin,
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=True,
        check=False,
    )


def parse_json_lines(text: str) -> list[Any]:
    output = []
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("{") or line.startswith("["):
            try:
                output.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return output


def decode_flow_actual(row: dict[str, Any] | None) -> Any:
    if not row:
        return None
    actual = row.get("actual")
    if not isinstance(actual, list) or not actual:
        return None
    value = actual[0]
    if isinstance(value, str):
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            return value
    return value


def flow_case_results(cases: list[dict[str, Any]], stdout: str) -> list[dict[str, Any]]:
    responses = parse_json_lines(stdout)
    rows: list[dict[str, Any]] = []
    for response in responses:
        if isinstance(response, dict):
            rows.extend(response.get("data", {}).get("results", []))
    results = []
    for case in cases:
        word = "rule-150-oracle.run-" + case["id"]
        result_row = next((row for row in rows if row.get("word") == word and row.get("name") == "exact-result"), None)
        unchanged_row = next((row for row in rows if row.get("word") == word and row.get("name") == "input-unchanged"), None)
        actual = decode_flow_actual(result_row)
        unchanged_value = decode_flow_actual(unchanged_row)
        unchanged = unchanged_value is True or (isinstance(unchanged_value, str) and unchanged_value.strip().lower() == "true")
        result_passed = bool(result_row and result_row.get("passed") is True)
        preservation_passed = bool(unchanged_row and unchanged_row.get("passed") is True and unchanged)
        results.append({
            "id": case["id"],
            "expected": expected_outcome(case),
            "actual": actual,
            "resultPassed": result_passed,
            "inputUnchanged": unchanged if unchanged_row else None,
            "preservationPassed": preservation_passed,
            "passed": result_passed and preservation_passed,
        })
    return results


def run_flow(
    cases: list[dict[str, Any]],
    api: str,
    project: Path,
    cli: Path,
    output: Path,
    define_source_path: Path | None,
    define_source_syntax_version: int,
) -> dict[str, Any]:
    working = prepare_output(project, output)
    shutil.copy2(CASES_PATH, output / "cases.json")
    source = flow_fixture(cases, api)
    define_sources = []
    overlay_hash_before = None
    if define_source_path is not None:
        candidate_source = define_source_path.read_text(encoding="utf-8")
        overlay_hash_before = sha256_file(define_source_path)
        shutil.copy2(define_source_path, output / "flow-define-source.agent")
        define_sources.append(candidate_source)
    define_sources.append(source)
    request_items = [
        {
            "op": "define",
            "source": item,
            "frontend": "flow",
            "syntaxVersion": define_source_syntax_version if define_source_path is not None and index == 0 else 1,
        }
        for index, item in enumerate(define_sources)
    ] + [{"op": "test-all"}]
    request = "".join(json.dumps(item, ensure_ascii=False, separators=(",", ":")) + "\n" for item in request_items)
    (output / "requests.jsonl").write_text(request, encoding="utf-8")
    command = ["dotnet", str(cli), "--project", str(working), "--jsonl"]
    completed = run_command(command, cwd=working, stdin=request)
    (output / "stdout.txt").write_text(completed.stdout, encoding="utf-8")
    (output / "stderr.txt").write_text(completed.stderr, encoding="utf-8")
    (output / "exit-code.txt").write_text(str(completed.returncode) + "\n", encoding="utf-8")

    responses = parse_json_lines(completed.stdout)
    definition_count_expected = len(define_sources)
    definition_responses = responses[:definition_count_expected]
    define_passed = len(definition_responses) == definition_count_expected and all(
        isinstance(response, dict) and response.get("kind") == "defined" and response.get("ok") is True
        for response in definition_responses
    )
    define_errors = [
        response.get("error")
        for response in definition_responses
        if isinstance(response, dict) and response.get("kind") == "error"
    ]
    define_error = define_errors[0] if define_errors else None
    case_results = flow_case_results(cases, completed.stdout)
    rows: list[dict[str, Any]] = []
    for response in responses:
        if isinstance(response, dict) and response.get("kind") == "test":
            rows.extend(response.get("data", {}).get("results", []))
    oracle_words = {"rule-150-oracle.run-" + case["id"] for case in cases}
    oracle_rows = [row for row in rows if row.get("word") in oracle_words]
    inherited_rows = [row for row in rows if row.get("word") not in oracle_words]
    test_batch_passed = bool(rows) and all(row.get("passed") is True for row in rows)
    inherited_suite_passed = bool(inherited_rows) and all(row.get("passed") is True for row in inherited_rows)
    oracle_evaluated = define_passed and len(oracle_rows) == len(cases) * 2
    behavior_passed = len(case_results) == len(cases) and all(item["passed"] for item in case_results) if oracle_evaluated else None
    reported_cases = case_results if oracle_evaluated else [
        {
            "id": case["id"],
            "expected": expected_outcome(case),
            "actual": None,
            "resultPassed": None,
            "inputUnchanged": None,
            "preservationPassed": None,
            "passed": None,
        }
        for case in cases
    ]
    return {
        "arm": "flow",
        "command": command,
        "cliSha256": sha256_file(cli),
        "flowDefineSource": str(define_source_path) if define_source_path is not None else None,
        "flowDefineSyntaxVersion": define_source_syntax_version if define_source_path is not None else None,
        "flowDefineSourceSha256Before": overlay_hash_before,
        "flowDefineSourceSha256After": sha256_file(define_source_path) if define_source_path is not None else None,
        "flowDefineSourceUnchanged": (overlay_hash_before == sha256_file(define_source_path)) if define_source_path is not None else None,
        "defineResponseCount": len(definition_responses),
        "defineResponseCountExpected": definition_count_expected,
        "exitCode": completed.returncode,
        "definePassed": define_passed,
        "defineError": define_error,
        "oracleTestCount": len(oracle_rows),
        "oracleTestCountExpected": len(cases) * 2,
        "testBatchPassed": (test_batch_passed and completed.returncode == 0) if rows else None,
        "inheritedSuitePassed": inherited_suite_passed,
        "inheritedTestCount": len(inherited_rows),
        "behaviorPassed": behavior_passed,
        "cases": reported_cases,
        "passed": bool(define_passed and len(oracle_rows) == len(cases) * 2 and behavior_passed is True and inherited_suite_passed and test_batch_passed and completed.returncode == 0),
    }


def run_fsharp(
    cases: list[dict[str, Any]],
    api: str,
    project: Path,
    project_relative: Path,
    output: Path,
) -> dict[str, Any]:
    working = prepare_output(project, output)
    if project_relative.is_absolute() or ".." in project_relative.parts:
        raise ValueError("--fsharp-project must be a relative path inside the candidate project")
    project_reference_path = working / project_relative
    if not project_reference_path.is_file():
        raise ValueError(f"F# project file does not exist in the copied project: {project_relative}")
    harness_dir = output / "fsharp-harness"
    harness_dir.mkdir()
    shutil.copy2(FSHARP_PROGRAM, harness_dir / "Program.fs")
    fsproj = harness_dir / "Rule150RentalOracle.fsproj"
    reference_xml = html.escape(project_reference_path.resolve().as_posix(), quote=True)
    fsproj.write_text(
        "<Project Sdk=\"Microsoft.NET.Sdk\">\n"
        "  <PropertyGroup>\n"
        "    <OutputType>Exe</OutputType>\n"
        "    <TargetFramework>net9.0</TargetFramework>\n"
        "    <TreatWarningsAsErrors>true</TreatWarningsAsErrors>\n"
        "  </PropertyGroup>\n"
        "  <ItemGroup><Compile Include=\"Program.fs\" /></ItemGroup>\n"
        f"  <ItemGroup><ProjectReference Include=\"{reference_xml}\" /></ItemGroup>\n"
        "</Project>\n",
        encoding="utf-8",
    )
    cases_copy = output / "cases.json"
    shutil.copy2(CASES_PATH, cases_copy)
    (output / "requests.jsonl").write_text(
        json.dumps({"op": "run-public-api-cases", "api": api, "project": project_relative.as_posix(), "cases": str(cases_copy)}, separators=(",", ":")) + "\n",
        encoding="utf-8",
    )
    build_command = [
        "dotnet", "build", "--configuration", "Release", "--verbosity", "minimal",
        "--nologo", "-m:1", "-p:NuGetAudit=false", str(fsproj),
    ]
    build = run_command(build_command, cwd=harness_dir)
    (output / "build.stdout.txt").write_text(build.stdout, encoding="utf-8")
    (output / "build.stderr.txt").write_text(build.stderr, encoding="utf-8")
    (output / "build.exit-code.txt").write_text(str(build.returncode) + "\n", encoding="utf-8")
    run_command_value = [
        "dotnet", "run", "--configuration", "Release", "--no-build", "--project", str(fsproj), "--", str(cases_copy), api,
    ]
    if build.returncode == 0:
        run = run_command(run_command_value, cwd=harness_dir)
        stdout, stderr, exit_code = run.stdout, run.stderr, run.returncode
    else:
        stdout, stderr, exit_code = "", "Build failed; see build.stderr.txt.\n", build.returncode
    (output / "stdout.txt").write_text(stdout, encoding="utf-8")
    (output / "stderr.txt").write_text(stderr, encoding="utf-8")
    (output / "exit-code.txt").write_text(str(exit_code) + "\n", encoding="utf-8")

    payload = next((json.loads(line) for line in stdout.splitlines() if line.startswith("{") and _is_json(line)), None)
    case_results = []
    if payload:
        for item in payload.get("cases", []):
            case_results.append({
                "id": item.get("caseId"),
                "expected": item.get("expected"),
                "actual": item.get("actual"),
                "resultPassed": item.get("actual") == item.get("expected"),
                "inputUnchanged": item.get("inputUnchanged"),
                "preservationPassed": item.get("inputUnchanged") is True,
                "passed": item.get("passed") is True,
            })
    return {
        "arm": "fsharp",
        "projectReference": project_relative.as_posix(),
        "buildCommand": build_command,
        "runCommand": run_command_value,
        "buildExitCode": build.returncode,
        "exitCode": exit_code,
        "testsCommand": None,
        "testBatchPassed": None,
        "inheritedSuitePassed": None,
        "inheritedTestCount": None,
        "observedCaseCount": len(case_results),
        "behaviorPassed": (all(item["passed"] for item in case_results) if len(case_results) == len(cases) else None),
        "cases": case_results,
        "passed": bool(build.returncode == 0 and exit_code == 0 and len(case_results) == len(cases) and all(item["passed"] for item in case_results)),
    }


def _is_json(line: str) -> bool:
    try:
        json.loads(line)
        return True
    except json.JSONDecodeError:
        return False


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--arm", required=True, choices=("flow", "fsharp"))
    parser.add_argument("--project", required=True, type=Path, help="Candidate Flow project root or F# study root")
    parser.add_argument("--cli", type=Path, help="AgentLang CLI DLL; required for --arm flow")
    parser.add_argument("--flow-define-source", type=Path, help="Optional standalone Flow source to define before the oracle; the source is copied into the evidence directory")
    parser.add_argument("--flow-define-syntax-version", type=int, choices=(1, 2), default=2, help="Syntax version for --flow-define-source; defaults to Flow/2")
    parser.add_argument("--fsharp-project", type=Path, help="F# project file relative to --project; required for --arm fsharp")
    parser.add_argument("--api", choices=("singleton", "helper"), default="singleton", help="Exercise billableDays or the direct billableInWindow helper")
    parser.add_argument("--cases", type=Path, help="Case file; defaults to this oracle's cases.json")
    parser.add_argument("--output", required=True, type=Path, help="New evidence directory; existing output is refused")
    args = parser.parse_args()

    project = args.project.resolve()
    output = args.output.resolve()
    if not project.is_dir():
        parser.error(f"project directory does not exist: {project}")
    if output.exists():
        parser.error(f"output path already exists; choose a fresh run directory: {output}")
    if output == project or output in project.parents or project in output.parents:
        parser.error("output and input project paths cannot overlap")
    if args.arm == "flow":
        if args.cli is None:
            parser.error("--cli is required for --arm flow")
        cli = args.cli.resolve()
        if not cli.is_file():
            parser.error(f"CLI file does not exist: {cli}")
        if args.fsharp_project is not None:
            parser.error("--fsharp-project is only valid for --arm fsharp")
        if args.flow_define_source is not None:
            args.flow_define_source = args.flow_define_source.resolve()
            if not args.flow_define_source.is_file():
                parser.error(f"Flow define source does not exist: {args.flow_define_source}")
    else:
        if args.fsharp_project is None:
            parser.error("--fsharp-project is required for --arm fsharp")
        if args.flow_define_source is not None:
            parser.error("--flow-define-source is only valid for --arm flow")
        cli = None

    global CASES_PATH
    if args.cases is not None:
        CASES_PATH = args.cases.resolve()
        if not CASES_PATH.is_file():
            parser.error(f"case file does not exist: {CASES_PATH}")
    cases = read_cases(args.api)
    before = tree_hashes(project)
    output.mkdir(parents=True)
    (output / "source-hashes.before.json").write_text(json.dumps(before, indent=2) + "\n", encoding="utf-8")
    if args.arm == "flow":
        result = run_flow(cases, args.api, project, cli, output, args.flow_define_source, args.flow_define_syntax_version)
    else:
        result = run_fsharp(cases, args.api, project, args.fsharp_project, output)
    after = tree_hashes(project)
    (output / "source-hashes.after.json").write_text(json.dumps(after, indent=2) + "\n", encoding="utf-8")
    project_unchanged = before == after
    define_source_unchanged = result.get("flowDefineSourceUnchanged")
    unchanged = project_unchanged and define_source_unchanged is not False
    result.update({
        "schemaVersion": 1,
        "inputProject": str(project),
        "inputProjectUnchanged": project_unchanged,
        "inputDefineSourceUnchanged": define_source_unchanged,
        "inputUnchanged": unchanged,
        "api": args.api,
        "caseCount": len(cases),
        "oracleInputHashes": {
            "casesJsonSha256": sha256_file(CASES_PATH),
            "scorePySha256": sha256_file(Path(__file__).resolve()),
            "fsharpProgramFsSha256": sha256_file(FSHARP_PROGRAM),
        },
    })
    result["passed"] = result["passed"] and unchanged
    (output / "acceptance.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"passed": result["passed"], "arm": result["arm"], "caseCount": len(cases), "inputUnchanged": unchanged, "acceptance": str(output / "acceptance.json")}))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"rental billing oracle failed: {error}", file=sys.stderr)
        raise

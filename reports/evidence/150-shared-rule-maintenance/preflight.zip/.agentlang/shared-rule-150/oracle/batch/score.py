#!/usr/bin/env python3
"""Score the public batch rental-billing query in isolated Flow or F# copies."""

from __future__ import annotations

import argparse
import hashlib
import html
import json
import re
import shutil
import subprocess
import sys
from collections import Counter
from pathlib import Path
from typing import Any


HERE = Path(__file__).resolve().parent
CASES_PATH = HERE / "cases.json"
FSHARP_PROGRAM = HERE / "fsharp" / "Program.fs"
INT64_MIN = -(2**63)
INT64_MAX = 2**63 - 1
FLOW_ORACLE_SYNTAX_VERSION = 2


def quote(value: str) -> str:
    return json.dumps(value, ensure_ascii=False)


def rental_key(rental: dict[str, Any]) -> tuple[int, int, int | None]:
    return rental["start"], rental["finish"], rental["cancel"]


def read_cases() -> list[dict[str, Any]]:
    cases = json.loads(CASES_PATH.read_text(encoding="utf-8"))["cases"]
    if not 14 <= len(cases) <= 18:
        raise ValueError(f"expected 14-18 logical cases, got {len(cases)}")
    seen: set[str] = set()
    for case in cases:
        case_id = case.get("id")
        if not isinstance(case_id, str) or not re.fullmatch(r"[a-z][a-z0-9-]*", case_id):
            raise ValueError(f"invalid case id: {case_id!r}")
        if case_id in seen:
            raise ValueError(f"duplicate case id: {case_id}")
        seen.add(case_id)
        for key in ("from", "until"):
            value = case.get(key)
            if not isinstance(value, int) or not INT64_MIN <= value <= INT64_MAX:
                raise ValueError(f"case {case_id} has {key} outside Int64")
        for list_key in ("rentals", "reorderedRentals"):
            if list_key not in case:
                continue
            rentals = case[list_key]
            if not isinstance(rentals, list):
                raise ValueError(f"case {case_id} has a non-list {list_key}")
            for rental in rentals:
                start, finish, cancellation = rental["start"], rental["finish"], rental["cancel"]
                if not (isinstance(start, int) and isinstance(finish, int) and 0 <= start < finish <= 366):
                    raise ValueError(f"case {case_id} has invalid stored rental bounds")
                if cancellation is not None and not (isinstance(cancellation, int) and start <= cancellation <= INT64_MAX):
                    raise ValueError(f"case {case_id} has cancellation before start or outside Int64")
        if "rentals" not in case:
            raise ValueError(f"case {case_id} is missing rentals")
        if "reorderedRentals" in case:
            primary = Counter(rental_key(rental) for rental in case["rentals"])
            reordered = Counter(rental_key(rental) for rental in case["reorderedRentals"])
            if primary != reordered:
                raise ValueError(f"case {case_id} reorderedRentals is not a permutation of rentals")
            if case["rentals"] == case["reorderedRentals"]:
                raise ValueError(f"case {case_id} does not actually reorder its rentals")
    return cases


def enumerated_total(rentals: list[dict[str, Any]], from_day: int, until_day: int) -> int:
    # Enumerate each stored rental's bounded days and add every entry separately.
    return sum(
        sum(
            1
            for day in range(rental["start"], rental["finish"])
            if from_day <= day < until_day
            and day > rental["start"]
            and (rental["cancel"] is None or day < rental["cancel"])
        )
        for rental in rentals
    )


def outcome_for(rentals: list[dict[str, Any]], from_day: int, until_day: int) -> str:
    if from_day >= until_day:
        return "error:INVALID_BILLING_WINDOW"
    return f"ok:{enumerated_total(rentals, from_day, until_day)}"


def expected_outcome(case: dict[str, Any]) -> str:
    from_day, until_day = case["from"], case["until"]
    primary = outcome_for(case["rentals"], from_day, until_day)
    if "reorderedRentals" in case:
        return primary + "|" + outcome_for(case["reorderedRentals"], from_day, until_day)
    return primary


def flow_int(value: int) -> str:
    # Some Flow parser paths read the magnitude before applying unary minus.
    if value == INT64_MIN:
        return "subtract(-9223372036854775807, 1)"
    return str(value)


def flow_list_expression(names: list[str]) -> str:
    if not names:
        return "list::empty<Rental>()"
    result = f"list::singleton<Rental>({names[0]})"
    for name in names[1:]:
        result = f"list::append({result}, {name})"
    return result


def flow_observation(
    *,
    outcome: str,
    unchanged: str = "false",
    explained: str = "false",
    reordered_equal: str = "false",
) -> list[str]:
    return [
        "reuse147OracleObservation::new(",
        f"    outcome = {outcome},",
        f"    input-unchanged = {unchanged},",
        f"    window-error-explained = {explained},",
        f"    reorder-totals-equal = {reordered_equal})",
    ]


def flow_setup_error(stage: str) -> list[str]:
    message = (
        f'string::concat(string::concat("fixture-setup-error:{stage}:", problem.code()), '
        'string::concat(":", problem.message()))'
    )
    return flow_observation(outcome=message)


def flow_case_body(case: dict[str, Any]) -> list[str]:
    variants = [case["rentals"]]
    if "reorderedRentals" in case:
        variants.append(case["reorderedRentals"])

    definitions: list[str] = []
    for variant_index, rentals in enumerate(variants):
        names = [f"rental{variant_index}{rental_index}" for rental_index in range(len(rentals))]
        definitions.append(f"let rentals{variant_index} = {flow_list_expression(names)};")

    if len(variants) == 1:
        definitions.extend([
            "let before = reuse-147-oracle::snapshot-list(rentals0);",
            f"let actual = rental::total-billable-days(rentals0, {flow_int(case['from'])}, {flow_int(case['until'])});",
            "let after = reuse-147-oracle::snapshot-list(rentals0);",
            "let unchanged = equals(before, after);",
            "let outcome = reuse-147-oracle::format-outcome(actual);",
            "let explained = reuse-147-oracle::explains-window-error(actual);",
        ])
        definitions.extend(flow_observation(
            outcome="outcome",
            unchanged="unchanged",
            explained="explained",
            reordered_equal="true",
        ))
    else:
        definitions.extend([
            "let before0 = reuse-147-oracle::snapshot-list(rentals0);",
            "let before1 = reuse-147-oracle::snapshot-list(rentals1);",
            f"let actual0 = rental::total-billable-days(rentals0, {flow_int(case['from'])}, {flow_int(case['until'])});",
            f"let actual1 = rental::total-billable-days(rentals1, {flow_int(case['from'])}, {flow_int(case['until'])});",
            "let after0 = reuse-147-oracle::snapshot-list(rentals0);",
            "let after1 = reuse-147-oracle::snapshot-list(rentals1);",
            "let unchanged = bool::and(equals(before0, after0), equals(before1, after1));",
            "let outcome0 = reuse-147-oracle::format-outcome(actual0);",
            "let outcome1 = reuse-147-oracle::format-outcome(actual1);",
            "let outcome = string::concat(string::concat(outcome0, \"|\"), outcome1);",
            "let explained = bool::and(",
            "    reuse-147-oracle::explains-window-error(actual0),",
            "    reuse-147-oracle::explains-window-error(actual1));",
            "let same-successful-total = bool::and(",
            "    reuse-147-oracle::is-success(actual0),",
            "    bool::and(reuse-147-oracle::is-success(actual1), equals(outcome0, outcome1)));",
        ])
        definitions.extend(flow_observation(
            outcome="outcome",
            unchanged="unchanged",
            explained="explained",
            reordered_equal="same-successful-total",
        ))

    setup_items = [
        (variant_index, rental_index, rental)
        for variant_index, rentals in enumerate(variants)
        for rental_index, rental in enumerate(rentals)
    ]

    def indent_lines(lines: list[str], level: int) -> list[str]:
        prefix = "    " * level
        return [prefix + line for line in lines]

    def emit_setup(index: int, level: int) -> list[str]:
        if index == len(setup_items):
            return indent_lines(definitions, level)

        variant_index, rental_index, rental = setup_items[index]
        started_name = f"started{variant_index}{rental_index}"
        rental_name = f"rental{variant_index}{rental_index}"
        prefix = "    " * level
        output = [
            f"{prefix}match rental::start({flow_int(rental['start'])}, {flow_int(rental['finish'])}) {{",
            f"{prefix}    error problem => {{",
            *indent_lines(flow_setup_error("start"), level + 2),
            f"{prefix}    }}",
            f"{prefix}    ok {started_name} => {{",
        ]
        if rental.get("cancel") is None:
            output.append(f"{prefix}        let {rental_name} = {started_name};")
            output.extend(emit_setup(index + 1, level + 2))
        else:
            cancel_level = level + 2
            cancel_prefix = "    " * cancel_level
            output.extend([
                f"{cancel_prefix}match rental::cancel({started_name}, {flow_int(rental['cancel'])}) {{",
                f"{cancel_prefix}    error problem => {{",
                *indent_lines(flow_setup_error("cancel"), cancel_level + 2),
                f"{cancel_prefix}    }}",
                f"{cancel_prefix}    ok {rental_name} => {{",
            ])
            output.extend(emit_setup(index + 1, cancel_level + 2))
            output.extend([
                f"{cancel_prefix}    }}",
                f"{cancel_prefix}}}",
            ])
        output.extend([
            f"{prefix}    }}",
            f"{prefix}}}",
        ])
        return output

    return emit_setup(0, 1)


def flow_fixture(cases: list[dict[str, Any]]) -> str:
    lines = [
        "record Reuse147OracleObservation {",
        "    field outcome: String;",
        "    field input-unchanged: Bool;",
        "    field window-error-explained: Bool;",
        "    field reorder-totals-equal: Bool;",
        "}",
        "",
        "record Reuse147RentalSnapshot {",
        "    field start: Int;",
        "    field finish: Int;",
        "    field cancelled: Option<Int>;",
        "}",
        "",
        "fn reuse-147-oracle.snapshot(rental: Rental) -> Reuse147RentalSnapshot {",
        "    reuse147RentalSnapshot::new(",
        "        start = rental.start-day(),",
        "        finish = rental.finish-day(),",
        "        cancelled = rental.cancelled-day())",
        "}",
        "",
        "fn reuse-147-oracle.snapshot-list(rentals: List<Rental>) -> List<Reuse147RentalSnapshot> {",
        "    rentals.map(reuse-147-oracle::snapshot)",
        "}",
        "",
        "fn reuse-147-oracle.format-outcome(result: Result<Int, RentalError>) -> String {",
        "    match result {",
        "        ok days => { string::concat(\"ok:\", int::to-string(days)) }",
        "        error problem => { string::concat(\"error:\", problem.code()) }",
        "    }",
        "}",
        "",
        "fn reuse-147-oracle.is-success(result: Result<Int, RentalError>) -> Bool {",
        "    match result {",
        "        ok days => { true }",
        "        error problem => { false }",
        "    }",
        "}",
        "",
        "fn reuse-147-oracle.explains-window-error(result: Result<Int, RentalError>) -> Bool {",
        "    match result {",
        "        ok days => { true }",
        "        error problem => {",
        "            let message = problem.message();",
        "            bool::or(",
        "                string::contains(message, \"window\"),",
        "                bool::or(string::contains(message, \"Window\"), string::contains(message, \"WINDOW\")))",
        "        }",
        "    }",
        "}",
    ]
    for case in cases:
        lines.extend([
            "",
            f"fn reuse-147-oracle.run-{case['id']}(value: Unit) -> Reuse147OracleObservation {{",
        ])
        lines.extend(flow_case_body(case))
        lines.append("}")
        lines.extend([
            "",
            f"test reuse-147-oracle.run-{case['id']}/exact-result {{",
            f"    let result = reuse-147-oracle::run-{case['id']}(unit);",
            "    result.outcome()",
            f"    => {quote(expected_outcome(case))}",
            "}",
            f"test reuse-147-oracle.run-{case['id']}/input-unchanged {{",
            f"    let result = reuse-147-oracle::run-{case['id']}(unit);",
            "    result.input-unchanged()",
            "    => true",
            "}",
            f"test reuse-147-oracle.run-{case['id']}/window-error-explained {{",
            f"    let result = reuse-147-oracle::run-{case['id']}(unit);",
            "    result.window-error-explained()",
            "    => true",
            "}",
            f"test reuse-147-oracle.run-{case['id']}/reorder-totals-equal {{",
            f"    let result = reuse-147-oracle::run-{case['id']}(unit);",
            "    result.reorder-totals-equal()",
            "    => true",
            "}",
        ])
    return "\n".join(lines) + "\n"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def tree_hashes(root: Path) -> dict[str, str]:
    hashes: dict[str, str] = {}
    for path in sorted(root.rglob("*")):
        relative = path.relative_to(root)
        parts = {part.lower() for part in relative.parts}
        if not path.is_file() or parts.intersection({"bin", "obj"}) or path.name.lower() == "write.lock":
            continue
        hashes[relative.as_posix()] = sha256_file(path)
    return hashes


def copy_project(source: Path, destination: Path) -> None:
    def ignore(_directory: str, names: list[str]) -> set[str]:
        return {name for name in names if name.lower() in {"bin", "obj", "write.lock"}}

    shutil.copytree(source, destination, ignore=ignore)


def prepare_output(project: Path, output: Path) -> Path:
    if output == project or output in project.parents or project in output.parents:
        raise ValueError("output and input project paths cannot overlap")
    if not output.is_dir():
        raise ValueError(f"output directory was not prepared: {output}")
    copied = output / "working-project"
    if copied.exists():
        raise ValueError(f"refusing to overwrite an existing working copy: {copied}")
    copy_project(project, copied)
    return copied


def run_command(command: list[str], *, cwd: Path, stdin: str | None = None) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        cwd=cwd,
        input=stdin,
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=True,
        check=False,
    )


def parse_json_lines(text: str) -> list[Any]:
    output = []
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("{") or line.startswith("["):
            try:
                output.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return output


def decode_actual(row: dict[str, Any] | None) -> Any:
    if not row:
        return None
    actual = row.get("actual")
    if not isinstance(actual, list) or not actual:
        return None
    value = actual[0]
    if isinstance(value, str):
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            return value
    return value


def decode_bool(row: dict[str, Any] | None) -> bool | None:
    value = decode_actual(row)
    if value is True:
        return True
    if value is False:
        return False
    if isinstance(value, str):
        if value.strip().lower() == "true":
            return True
        if value.strip().lower() == "false":
            return False
    return None


def flow_case_results(cases: list[dict[str, Any]], stdout: str) -> list[dict[str, Any]]:
    responses = parse_json_lines(stdout)
    rows: list[dict[str, Any]] = []
    for response in responses:
        if isinstance(response, dict):
            rows.extend(response.get("data", {}).get("results", []))
    results = []
    for case in cases:
        word = "reuse-147-oracle.run-" + case["id"]
        case_rows = {
            name: next((row for row in rows if row.get("word") == word and row.get("name") == name), None)
            for name in ("exact-result", "input-unchanged", "window-error-explained", "reorder-totals-equal")
        }
        actual = decode_actual(case_rows["exact-result"])
        unchanged = decode_bool(case_rows["input-unchanged"])
        explained = decode_bool(case_rows["window-error-explained"])
        reordered_equal = decode_bool(case_rows["reorder-totals-equal"])
        row_passed = {name: bool(row and row.get("passed") is True) for name, row in case_rows.items()}
        passed = all(row_passed.values()) and unchanged is True and explained is True and reordered_equal is True
        results.append({
            "id": case["id"],
            "expected": expected_outcome(case),
            "actual": actual,
            "resultPassed": row_passed["exact-result"],
            "inputUnchanged": unchanged,
            "preservationPassed": row_passed["input-unchanged"] and unchanged is True,
            "windowErrorExplained": explained,
            "windowErrorExplanationPassed": row_passed["window-error-explained"] and explained is True,
            "reorderTotalsEqual": reordered_equal,
            "reorderEqualityPassed": row_passed["reorder-totals-equal"] and reordered_equal is True,
            "passed": passed,
        })
    return results


def run_flow(
    cases: list[dict[str, Any]],
    project: Path,
    cli: Path,
    output: Path,
    define_source_path: Path | None,
    define_source_syntax_version: int,
) -> dict[str, Any]:
    working = prepare_output(project, output)
    shutil.copy2(CASES_PATH, output / "cases.json")
    source = flow_fixture(cases)
    define_sources = []
    overlay_hash_before = None
    if define_source_path is not None:
        candidate_source = define_source_path.read_text(encoding="utf-8")
        overlay_hash_before = sha256_file(define_source_path)
        shutil.copy2(define_source_path, output / "flow-define-source.agent")
        define_sources.append(candidate_source)
    define_sources.append(source)
    request_items = [
        {
            "op": "define",
            "source": item,
            "frontend": "flow",
            "syntaxVersion": define_source_syntax_version if define_source_path is not None and index == 0 else FLOW_ORACLE_SYNTAX_VERSION,
        }
        for index, item in enumerate(define_sources)
    ] + [{"op": "test-all"}]
    request = "".join(json.dumps(item, ensure_ascii=False, separators=(",", ":")) + "\n" for item in request_items)
    (output / "requests.jsonl").write_text(request, encoding="utf-8")
    command = ["dotnet", str(cli), "--project", str(working), "--jsonl"]
    completed = run_command(command, cwd=working, stdin=request)
    (output / "stdout.txt").write_text(completed.stdout, encoding="utf-8")
    (output / "stderr.txt").write_text(completed.stderr, encoding="utf-8")
    (output / "exit-code.txt").write_text(str(completed.returncode) + "\n", encoding="utf-8")

    responses = parse_json_lines(completed.stdout)
    definition_count_expected = len(define_sources)
    definition_responses = responses[:definition_count_expected]
    define_passed = len(definition_responses) == definition_count_expected and all(
        isinstance(response, dict) and response.get("kind") == "defined" and response.get("ok") is True
        for response in definition_responses
    )
    define_errors = [
        response.get("error")
        for response in definition_responses
        if isinstance(response, dict) and response.get("kind") == "error"
    ]
    define_error = define_errors[0] if define_errors else None
    case_results = flow_case_results(cases, completed.stdout)
    rows: list[dict[str, Any]] = []
    for response in responses:
        if isinstance(response, dict) and response.get("kind") == "test":
            rows.extend(response.get("data", {}).get("results", []))
    oracle_words = {"reuse-147-oracle.run-" + case["id"] for case in cases}
    oracle_rows = [row for row in rows if row.get("word") in oracle_words]
    inherited_rows = [row for row in rows if row.get("word") not in oracle_words]
    test_batch_passed = bool(rows) and all(row.get("passed") is True for row in rows)
    inherited_suite_passed = bool(inherited_rows) and all(row.get("passed") is True for row in inherited_rows)
    oracle_rows_expected = len(cases) * 4
    oracle_evaluated = define_passed and len(oracle_rows) == oracle_rows_expected
    behavior_passed = len(case_results) == len(cases) and all(item["passed"] for item in case_results) if oracle_evaluated else None
    reported_cases = case_results if oracle_evaluated else [
        {
            "id": case["id"],
            "expected": expected_outcome(case),
            "actual": None,
            "resultPassed": None,
            "inputUnchanged": None,
            "preservationPassed": None,
            "windowErrorExplained": None,
            "windowErrorExplanationPassed": None,
            "reorderTotalsEqual": None,
            "reorderEqualityPassed": None,
            "passed": None,
        }
        for case in cases
    ]
    return {
        "arm": "flow",
        "command": command,
        "cliSha256": sha256_file(cli),
        "flowDefineSource": str(define_source_path) if define_source_path is not None else None,
        "flowDefineSyntaxVersion": define_source_syntax_version if define_source_path is not None else None,
        "flowDefineSourceSha256Before": overlay_hash_before,
        "flowDefineSourceSha256After": sha256_file(define_source_path) if define_source_path is not None else None,
        "flowDefineSourceUnchanged": (overlay_hash_before == sha256_file(define_source_path)) if define_source_path is not None else None,
        "flowOracleSyntaxVersion": FLOW_ORACLE_SYNTAX_VERSION,
        "defineResponseCount": len(definition_responses),
        "defineResponseCountExpected": definition_count_expected,
        "exitCode": completed.returncode,
        "definePassed": define_passed,
        "defineError": define_error,
        "oracleTestCount": len(oracle_rows),
        "oracleTestCountExpected": oracle_rows_expected,
        "testBatchPassed": (test_batch_passed and completed.returncode == 0) if rows else None,
        "inheritedSuitePassed": inherited_suite_passed,
        "inheritedTestCount": len(inherited_rows),
        "behaviorPassed": behavior_passed,
        "cases": reported_cases,
        "passed": bool(define_passed and len(oracle_rows) == oracle_rows_expected and behavior_passed is True and inherited_suite_passed and test_batch_passed and completed.returncode == 0),
    }


def run_fsharp(
    cases: list[dict[str, Any]],
    project: Path,
    project_relative: Path,
    output: Path,
) -> dict[str, Any]:
    working = prepare_output(project, output)
    if project_relative.is_absolute() or ".." in project_relative.parts:
        raise ValueError("--fsharp-project must be a relative path inside the candidate project")
    project_reference_path = working / project_relative
    if not project_reference_path.is_file():
        raise ValueError(f"F# project file does not exist in the copied project: {project_relative}")
    harness_dir = output / "fsharp-harness"
    harness_dir.mkdir()
    shutil.copy2(FSHARP_PROGRAM, harness_dir / "Program.fs")
    fsproj = harness_dir / "BatchReuse147RentalOracle.fsproj"
    reference_xml = html.escape(project_reference_path.resolve().as_posix(), quote=True)
    fsproj.write_text(
        "<Project Sdk=\"Microsoft.NET.Sdk\">\n"
        "  <PropertyGroup>\n"
        "    <OutputType>Exe</OutputType>\n"
        "    <TargetFramework>net9.0</TargetFramework>\n"
        "    <TreatWarningsAsErrors>true</TreatWarningsAsErrors>\n"
        "  </PropertyGroup>\n"
        "  <ItemGroup><Compile Include=\"Program.fs\" /></ItemGroup>\n"
        f"  <ItemGroup><ProjectReference Include=\"{reference_xml}\" /></ItemGroup>\n"
        "</Project>\n",
        encoding="utf-8",
    )
    cases_copy = output / "cases.json"
    shutil.copy2(CASES_PATH, cases_copy)
    (output / "requests.jsonl").write_text(
        json.dumps({"op": "run-public-api-cases", "project": project_relative.as_posix(), "cases": str(cases_copy)}, separators=(",", ":")) + "\n",
        encoding="utf-8",
    )
    build_command = [
        "dotnet", "build", "--configuration", "Release", "--verbosity", "minimal",
        "--nologo", "-m:1", "-p:NuGetAudit=false", str(fsproj),
    ]
    build = run_command(build_command, cwd=harness_dir)
    (output / "build.stdout.txt").write_text(build.stdout, encoding="utf-8")
    (output / "build.stderr.txt").write_text(build.stderr, encoding="utf-8")
    (output / "build.exit-code.txt").write_text(str(build.returncode) + "\n", encoding="utf-8")
    run_command_value = [
        "dotnet", "run", "--configuration", "Release", "--no-build", "--project", str(fsproj), "--", str(cases_copy),
    ]
    if build.returncode == 0:
        run = run_command(run_command_value, cwd=harness_dir)
        stdout, stderr, exit_code = run.stdout, run.stderr, run.returncode
    else:
        stdout, stderr, exit_code = "", "Build failed; see build.stderr.txt.\n", build.returncode
    (output / "stdout.txt").write_text(stdout, encoding="utf-8")
    (output / "stderr.txt").write_text(stderr, encoding="utf-8")
    (output / "exit-code.txt").write_text(str(exit_code) + "\n", encoding="utf-8")

    payload = next((json.loads(line) for line in stdout.splitlines() if line.startswith("{") and _is_json(line)), None)
    case_results = []
    if payload:
        for item in payload.get("cases", []):
            case_results.append({
                "id": item.get("caseId"),
                "expected": item.get("expected"),
                "actual": item.get("actual"),
                "resultPassed": item.get("actual") == item.get("expected"),
                "inputUnchanged": item.get("inputUnchanged"),
                "preservationPassed": item.get("inputUnchanged") is True,
                "windowErrorExplained": item.get("windowErrorExplained"),
                "windowErrorExplanationPassed": item.get("windowErrorExplained") is True,
                "reorderTotalsEqual": item.get("reorderTotalsEqual"),
                "reorderEqualityPassed": item.get("reorderTotalsEqual") is True,
                "passed": item.get("passed") is True,
            })
    return {
        "arm": "fsharp",
        "projectReference": project_relative.as_posix(),
        "buildCommand": build_command,
        "runCommand": run_command_value,
        "buildExitCode": build.returncode,
        "exitCode": exit_code,
        "testsCommand": None,
        "testBatchPassed": None,
        "inheritedSuitePassed": None,
        "inheritedTestCount": None,
        "observedCaseCount": len(case_results),
        "behaviorPassed": (all(item["passed"] for item in case_results) if len(case_results) == len(cases) else None),
        "cases": case_results,
        "passed": bool(build.returncode == 0 and exit_code == 0 and len(case_results) == len(cases) and all(item["passed"] for item in case_results)),
    }


def _is_json(line: str) -> bool:
    try:
        json.loads(line)
        return True
    except json.JSONDecodeError:
        return False


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--arm", required=True, choices=("flow", "fsharp"))
    parser.add_argument("--project", required=True, type=Path, help="Candidate Flow project root or F# project workspace")
    parser.add_argument("--cli", type=Path, help="Frozen AgentLang CLI DLL; required for --arm flow")
    parser.add_argument("--flow-define-source", type=Path, help="Optional source overlay to define before the Flow oracle")
    parser.add_argument("--flow-define-syntax-version", type=int, choices=(1, 2), default=2)
    parser.add_argument("--fsharp-project", type=Path, help="F# project file relative to --project; required for --arm fsharp")
    parser.add_argument("--output", required=True, type=Path, help="New evidence directory; existing output is refused")
    args = parser.parse_args()

    project = args.project.resolve()
    output = args.output.resolve()
    if not project.is_dir():
        parser.error(f"project directory does not exist: {project}")
    if output.exists():
        parser.error(f"output path already exists; choose a fresh run directory: {output}")
    if output == project or output in project.parents or project in output.parents:
        parser.error("output and input project paths cannot overlap")
    if args.arm == "flow":
        if args.cli is None:
            parser.error("--cli is required for --arm flow")
        cli = args.cli.resolve()
        if not cli.is_file():
            parser.error(f"CLI file does not exist: {cli}")
        if args.fsharp_project is not None:
            parser.error("--fsharp-project is only valid for --arm fsharp")
        if args.flow_define_source is not None:
            args.flow_define_source = args.flow_define_source.resolve()
            if not args.flow_define_source.is_file():
                parser.error(f"Flow define source does not exist: {args.flow_define_source}")
    else:
        if args.fsharp_project is None:
            parser.error("--fsharp-project is required for --arm fsharp")
        if args.flow_define_source is not None:
            parser.error("--flow-define-source is only valid for --arm flow")
        cli = None

    cases = read_cases()
    before = tree_hashes(project)
    output.mkdir(parents=True)
    (output / "source-hashes.before.json").write_text(json.dumps(before, indent=2) + "\n", encoding="utf-8")
    if args.arm == "flow":
        result = run_flow(cases, project, cli, output, args.flow_define_source, args.flow_define_syntax_version)
    else:
        result = run_fsharp(cases, project, args.fsharp_project, output)
    after = tree_hashes(project)
    (output / "source-hashes.after.json").write_text(json.dumps(after, indent=2) + "\n", encoding="utf-8")
    project_unchanged = before == after
    define_source_unchanged = result.get("flowDefineSourceUnchanged")
    unchanged = project_unchanged and define_source_unchanged is not False
    result.update({
        "schemaVersion": 1,
        "inputProject": str(project),
        "inputProjectUnchanged": project_unchanged,
        "inputDefineSourceUnchanged": define_source_unchanged,
        "inputUnchanged": unchanged,
        "caseCount": len(cases),
        "oracleInputHashes": {
            "casesJsonSha256": sha256_file(CASES_PATH),
            "scorePySha256": sha256_file(Path(__file__).resolve()),
            "fsharpProgramFsSha256": sha256_file(FSHARP_PROGRAM),
        },
    })
    result["passed"] = result["passed"] and unchanged
    (output / "acceptance.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"passed": result["passed"], "arm": result["arm"], "caseCount": len(cases), "inputUnchanged": unchanged, "acceptance": str(output / "acceptance.json")}))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"batch rental-billing oracle failed: {error}", file=sys.stderr)
        raise

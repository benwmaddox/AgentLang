# Rule 150 independent acceptance oracle

The three scorers drive the existing Flow and F# public project fixtures using bounded day enumeration. Each rental contributes a day only when the day is in the requested half-open window, is before the effective finish or cancellation, and is strictly after that rental's original start. The scorers do not enumerate or measure request windows.

- `singleton/score.py` checks `billableDays`/`rental::billable-days` with 21 cases. For direct `billableInWindow`/`rental::billable-in-window` coverage, pass `--api helper --cases .agentlang/shared-rule-150/oracle/singleton/cases.helper.json`; that set has 9 valid-window cases.
- `batch/score.py` checks `totalBillableDays`/`rental::total-billable-days` with 18 cases, including empty-list window validation, preserved fields and order, duplicates, overlaps, cancellation, and signed endpoints.

For Flow, pass the supplied Flow project root and pinned FlowCLI148 DLL. For F#, pass its project workspace and `project/RentalDomain.fsproj`. Each invocation requires a fresh `--output` directory and saves the generated request, console logs, source hashes, per-case observations, and acceptance record there. The acceptance record distinguishes definition/build failure from executed behavior failure.

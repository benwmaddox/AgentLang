# Shared-rule maintenance trial

Starting revision: ab1a62a. Use final participant projects from report149 as
retained starts. No core/runtime changes. Main only; local tests.

## Public task

Change rental billing so that each rental's start day is free. A rental occupies
integer days from its start (inclusive) to its finish or cancellation (exclusive),
whichever comes first. Its start day must never be charged, even when billing is
split across requests. The free day is attached to the original rental start,
not the first day inside a requested billing window. All other occupied days
inside the requested half-open window remain chargeable.

Apply this consistently to all existing public billing operations: the validated
window calculation, the singleton Result-returning query, and the list-total
Result-returning query. API signatures and valid stored rental rules stay the
same. Reject from >= until with INVALID_BILLING_WINDOW even for empty lists.
One-day rentals and cancellation at start or the following day incur no charge.
Overlapping and repeated rentals are still counted independently. Signed 64-bit
request bounds, original stored fields and list order must remain supported.

Inspect existing capabilities and dependencies. Update existing tests/examples
whose expected outcomes change with this policy; preserve other coverage and
behavior. Add effective regression tests and run the whole project suite.
Do not remove tests simply to make the suite pass. No particular internal helper
or algorithm is required. AgentLang must retain library maturity and satisfy
existing qualification gates for changed functions and their production callers.
Use the normal task/commit workflow; do not weaken coverage or demote libraries.

## Coordinator plan

Freeze a bounded independent day-enumeration oracle spanning all three billing
APIs before participants launch. Reuse report145 singleton and report147 batch
harnesses, adapted only for the new policy and needed boundary cases; exercise
the validated API directly too. Include positive controls and negative mutations
that leave one consumer stale or mistakenly waive each window's first day.
A compile failure is not a behavior-killing witness; require negative controls
to execute and fail behavioral cases. Avoid new harness infrastructure.

Two preparators build separate correct controls from the149 final sources using
only this public task and their seed. They must not read oracle files, other
preparators' outputs, or prior controls. Actual participant starts remain exact
copies of149 finals, not control outputs. Run old behavior suites as baseline,
new hidden acceptance on controls, and reject frozen original starts under the
new policy. Then launch one fresh Luna/max participant per language sequentially
with the same broker and100exchange limit. Explicit prompt-level isolation,
no coaching, no mandatory reuse helper. Score behavior, actual propagation/reuse,
source changes, tests, errors, qualification and normal termination separately.

This continues coordinator-shaped API variation; no causal/population language
advantage follows from one pair. The primary question is whether shared domain
vocabulary supports reliable policy maintenance across its consumers. Publish
report150 and evidence, then synthesize findings rather than automatically
adding more microtrials.

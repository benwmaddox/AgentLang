# Rule 150 oracle execution evidence

These runs use the frozen final report149 participant projects as unchanged originals. They are expected to fail the new start-day-free policy. An execution counts as a behavioral witness only when the Flow source defined and every expected oracle observation ran, or when the F# harness built and emitted every case result.

| Run | API cases | Execution evidence | Result |
| --- | ---: | --- | --- |
| `original-flow-singleton` | 21 | define passed; 42/42 oracle tests; exit 0 | Behavioral failure |
| `original-flow-helper` | 9 | define passed; 18/18 oracle tests; exit 0 | Behavioral failure |
| `original-flow-batch` | 18 | define passed; 72/72 oracle tests; exit 0 | Behavioral failure |
| `original-fsharp-singleton` | 21 | build succeeded; 21/21 results emitted | Behavioral failure |
| `original-fsharp-helper` | 9 | build succeeded; 9/9 results emitted | Behavioral failure |
| `original-fsharp-batch` | 18 | build succeeded; 18/18 results emitted | Behavioral failure |

Each run directory retains `acceptance.json`, stdout/stderr, command inputs, and source hashes. The original project has charge-start-day behavior, so the expected policy mismatches are execution results rather than compile failures.

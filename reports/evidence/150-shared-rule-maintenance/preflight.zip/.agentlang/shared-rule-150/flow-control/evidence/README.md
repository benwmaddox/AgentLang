# Flow control evidence

The copied project at `../project` implements the shared rental-billing rule through `rental.billable-in-window`: it starts the billable interval at `rental.start-day + 1` before intersecting the requested window. This keeps the original start day free across split requests. The validated-window helper, singleton query, and list-total query all use the same behavior. Public signatures and stored rental fields are unchanged.

The seed was copied to the owned control directory with every `WRITE.lock` excluded. Only the public-task section of `task.md` was read. AgentLang definitions, tests, examples, and replacements were submitted through the pinned Flow/2 JSONL runtime.

The baseline project passed **47/47** attached tests. The final integrated qualification passed **61/61** tests, and a fresh CLI reload independently passed **61/61** tests plus **2/2** helper examples. The four changed functions and callers remain library-qualified with current instruction, branch, and finite-return coverage; the exact summaries and source/runtime hashes are in `provenance.json`.

All request and response files are retained here. This includes the initial protocol probe, baseline, format checks, transient candidate-state attempts, integrated define/test/replace workflow, and fresh reload. In the integrated run, `replace-word rental.billable-in-window` passed its persistent caller gates and published the staged caller test revisions with the helper replacement. Three later explicit caller-only `replace-word` requests returned `REPLACE_NOT_STAGED`; those responses are preserved. The fresh reload confirms the resulting revisions and qualification are persistent. An earlier separate-process candidate test saw only committed state; the final integrated run restaged every edit in one JSONL process before testing and committing.

## JSONL log index

- `protocol-probe.*`: malformed-request probe used to confirm the `op` field requirement.
- `help-*.request.jsonl` and `help-*.response.jsonl`: runtime authoring and replacement contract.
- `baseline.*`: pre-change `test-all` and baseline descriptions.
- `format-*.request.jsonl` and `format-*.response.jsonl`: Flow/2 parser and canonicalization checks.
- `stage-replacements.*`, `staged-test-all.*`, and `test-helper-candidate.*`: preserved transient staging attempts.
- `qualification-workflow.*`: integrated staging, targeted tests, complete suite, persistent caller gate, and descriptions.
- `fresh-reload-final.*`: independent reload, complete suite, example execution, and final maturity/coverage descriptions.

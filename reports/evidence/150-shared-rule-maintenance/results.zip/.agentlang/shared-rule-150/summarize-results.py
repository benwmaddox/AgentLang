from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parent
for arm in ('flow','fsharp'):
    p=ROOT/'participants'/arm;out=ROOT/'results'/arm
    trace=json.loads((out/'trace-summary.json').read_text(encoding='utf-8'))
    apis={}
    for api in ('singleton','helper','batch'):
        a=json.loads((out/api/'acceptance.json').read_text(encoding='utf-8'))
        apis[api]={'acceptancePassed':a['passed'],'behaviorPassed':a['behaviorPassed'],'casesPassed':sum(c.get('passed') is True for c in a['cases']),'casesObserved':sum(c.get('passed') is not None for c in a['cases']),'inputUnchanged':a['inputUnchanged']}
    final={q.relative_to(p/'project').as_posix():hashlib.sha256(q.read_bytes()).hexdigest() for q in sorted((p/'project').rglob('*')) if q.is_file() and q.name.lower()!='write.lock' and not {'bin','obj'}.intersection(x.lower() for x in q.relative_to(p/'project').parts)}
    before={r['path']:r['sha256'] for r in json.loads((p/'start-inventory.json').read_text(encoding='utf-8'))['files']}
    summary={'arm':arm,'exchanges':trace['exchanges'],'errorResponseCount':len(trace['errorResponses']),'terminal':trace['terminal'],'apis':apis,'finalSourceHashes':final,'scopeChanges':{'added':sorted(final.keys()-before.keys()),'removed':sorted(before.keys()-final.keys()),'modified':sorted(k for k in before.keys()&final.keys() if before[k]!=final[k])}}
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in summary.items() if k not in {'finalSourceHashes','terminal','scopeChanges'}}))

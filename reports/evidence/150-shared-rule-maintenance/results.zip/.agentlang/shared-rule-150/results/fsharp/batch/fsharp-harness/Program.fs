namespace BatchReuse147RentalOracle

open System
open System.Globalization
open System.Text.Json
open RentalDomain

module Program =
    type private Invocation = {
        Outcome: string
        InputUnchanged: bool
        WindowErrorExplained: bool
        SuccessfulTotal: int64 option
    }

    type private CaseAcceptance = {
        CaseId: string
        Expected: string
        Actual: string
        InputUnchanged: bool
        WindowErrorExplained: bool
        ReorderTotalsEqual: bool
        Passed: bool
    }

    let private text (element: JsonElement) (name: string) = element.GetProperty(name).GetString()
    let private integer (element: JsonElement) (name: string) = element.GetProperty(name).GetInt64()

    let private hasProperty (element: JsonElement) (name: string) =
        let mutable value = Unchecked.defaultof<JsonElement>
        element.TryGetProperty(name, &value)

    let private cancelledDay (element: JsonElement) =
        let value = element.GetProperty("cancel")
        if value.ValueKind = JsonValueKind.Null then None else Some(value.GetInt64())

    let private jsonRentals (element: JsonElement) =
        element.EnumerateArray() |> Seq.toList

    let private expectedForRentals (rentals: JsonElement list) fromDay untilDay =
        if fromDay >= untilDay then
            "error:INVALID_BILLING_WINDOW"
        else
            // The oracle enumerates only each bounded stored rental's integer days.
            let count =
                rentals
                |> List.sumBy (fun rental ->
                    let startDay = integer rental "start"
                    let finishDay = integer rental "finish"
                    let cancellation = cancelledDay rental
                    [ startDay .. finishDay - 1L ]
                    |> List.sumBy (fun day ->
                        if day >= fromDay
                           && day < untilDay
                           && day > startDay
                           && (match cancellation with
                               | None -> true
                               | Some cancelled -> day < cancelled) then 1L
                        else 0L))
            "ok:" + count.ToString(CultureInfo.InvariantCulture)

    let private expectedOutcome (element: JsonElement) =
        let fromDay = integer element "from"
        let untilDay = integer element "until"
        let primary = expectedForRentals (jsonRentals (element.GetProperty("rentals"))) fromDay untilDay
        if hasProperty element "reorderedRentals" then
            let reordered = jsonRentals (element.GetProperty("reorderedRentals"))
            primary + "|" + expectedForRentals reordered fromDay untilDay
        else
            primary

    let private createRental (element: JsonElement) =
        match Rental.start (integer element "start") (integer element "finish") with
        | Error error -> Error("start:" + error.Code + ":" + error.Message)
        | Ok rental ->
            match cancelledDay element with
            | None -> Ok rental
            | Some day ->
                match Rental.cancel rental day with
                | Error error -> Error("cancel:" + error.Code + ":" + error.Message)
                | Ok updated -> Ok updated

    let private createRentals (values: JsonElement list) =
        let rec loop remaining accumulated =
            match remaining with
            | [] -> Ok(List.rev accumulated)
            | value :: tail ->
                match createRental value with
                | Error setupError -> Error setupError
                | Ok rental -> loop tail (rental :: accumulated)
        loop values []

    let private fields rental =
        Rental.startDay rental, Rental.finishDay rental, Rental.cancelledDay rental

    let private outcome (result: Result<int64, RentalError>) =
        match result with
        | Ok count -> "ok:" + count.ToString(CultureInfo.InvariantCulture)
        | Error error -> "error:" + error.Code

    let private errorExplainsWindow (result: Result<int64, RentalError>) =
        match result with
        | Ok _ -> true
        | Error error ->
            error.Message.IndexOf("window", StringComparison.OrdinalIgnoreCase) >= 0

    let private runInvocation (rentals: Rental.T list) (fromDay: int64) (untilDay: int64) =
        let before = rentals |> List.map fields
        let result = Rental.totalBillableDays rentals fromDay untilDay
        let after = rentals |> List.map fields
        let successfulTotal =
            match result with
            | Ok count -> Some count
            | Error _ -> None
        {
            Outcome = outcome result
            InputUnchanged = before = after
            WindowErrorExplained = errorExplainsWindow result
            SuccessfulTotal = successfulTotal
        }

    let private failedSetup caseId expected setupError = {
        CaseId = caseId
        Expected = expected
        Actual = "fixture-setup-error:" + setupError
        InputUnchanged = false
        WindowErrorExplained = false
        ReorderTotalsEqual = false
        Passed = false
    }

    let private runCase (element: JsonElement) =
        let caseId = text element "id"
        let expected = expectedOutcome element
        let fromDay = integer element "from"
        let untilDay = integer element "until"
        match createRentals (jsonRentals (element.GetProperty("rentals"))) with
        | Error setupError -> failedSetup caseId expected setupError
        | Ok rentals ->
            let primary = runInvocation rentals fromDay untilDay
            if hasProperty element "reorderedRentals" then
                match createRentals (jsonRentals (element.GetProperty("reorderedRentals"))) with
                | Error setupError -> failedSetup caseId expected ("reordered-" + setupError)
                | Ok reordered ->
                    let other = runInvocation reordered fromDay untilDay
                    let actual = primary.Outcome + "|" + other.Outcome
                    let reorderTotalsEqual =
                        match primary.SuccessfulTotal, other.SuccessfulTotal with
                        | Some first, Some second -> first = second
                        | _ -> false
                    let inputUnchanged = primary.InputUnchanged && other.InputUnchanged
                    let windowErrorExplained = primary.WindowErrorExplained && other.WindowErrorExplained
                    {
                        CaseId = caseId
                        Expected = expected
                        Actual = actual
                        InputUnchanged = inputUnchanged
                        WindowErrorExplained = windowErrorExplained
                        ReorderTotalsEqual = reorderTotalsEqual
                        Passed = actual = expected && inputUnchanged && windowErrorExplained && reorderTotalsEqual
                    }
            else
                {
                    CaseId = caseId
                    Expected = expected
                    Actual = primary.Outcome
                    InputUnchanged = primary.InputUnchanged
                    WindowErrorExplained = primary.WindowErrorExplained
                    ReorderTotalsEqual = true
                    Passed = primary.Outcome = expected && primary.InputUnchanged && primary.WindowErrorExplained
                }

    [<EntryPoint>]
    let main argv =
        if argv.Length <> 1 then
            eprintfn "Usage: oracle <cases.json>"
            2
        else
            use document = JsonDocument.Parse(IO.File.ReadAllText(argv[0]))
            let cases =
                document.RootElement.GetProperty("cases").EnumerateArray()
                |> Seq.map runCase
                |> Seq.toList
            let result = {| 
                schemaVersion = 1
                arm = "fsharp"
                passed = cases |> List.forall (fun item -> item.Passed)
                cases = cases |> List.map (fun item -> {| 
                    caseId = item.CaseId
                    expected = item.Expected
                    actual = item.Actual
                    inputUnchanged = item.InputUnchanged
                    windowErrorExplained = item.WindowErrorExplained
                    reorderTotalsEqual = item.ReorderTotalsEqual
                    passed = item.Passed
                |})
            |}
            Console.WriteLine(JsonSerializer.Serialize(result))
            if result.passed then 0 else 1

module BillingWindowTests

open System.Reflection
open RentalDomain

let run () =
    let mutable checks = 0
    let check name expected actual =
        checks <- checks + 1
        if expected <> actual then
            failwithf "%s expected %A, received %A" name expected actual

    let expectWindow name fromDay untilDay =
        match BillingWindow.tryCreate fromDay untilDay with
        | Some window -> window
        | None -> failwithf "%s expected a valid billing window" name

    let original =
        match Rental.start 2L 8L with
        | Ok rental -> rental
        | Error error -> failwithf "valid rental failed: %s" error.Code

    check "empty window rejected" None (BillingWindow.tryCreate 5L 5L)
    check "reversed window rejected" None (BillingWindow.tryCreate 6L 5L)

    let fullRange = expectWindow "full int64 range" System.Int64.MinValue System.Int64.MaxValue
    check "full-range start getter" System.Int64.MinValue (BillingWindow.fromDay fullRange)
    check "full-range end getter" System.Int64.MaxValue (BillingWindow.untilDay fullRange)
    check "full-range bounded rental count" 5L (Rental.billableInWindow original fullRange)

    let leftClipped = expectWindow "left-clipped window" -10L 4L
    check "left clipping excludes original start day" 1L (Rental.billableInWindow original leftClipped)
    let rightClipped = expectWindow "right-clipped window" 6L 20L
    check "right clipping" 2L (Rental.billableInWindow original rightClipped)
    let exactBounds = expectWindow "exact rental bounds" 2L 8L
    check "exact half-open bounds" 5L (Rental.billableInWindow original exactBounds)
    let originalStartOnly = expectWindow "original start day only" 2L 3L
    check "original start day remains free" 0L (Rental.billableInWindow original originalStartOnly)
    let firstChargeableDay = expectWindow "window after original start" 3L 8L
    check "later window does not get another free day" 5L (Rental.billableInWindow original firstChargeableDay)

    let cancelledAtStart =
        match Rental.cancel original 2L with
        | Ok rental -> rental
        | Error error -> failwithf "cancellation at start failed: %s" error.Code
    check "start cancellation has no occupied days" 0L (Rental.billableInWindow cancelledAtStart exactBounds)

    let cancelledOnFollowingDay =
        match Rental.cancel original 3L with
        | Ok rental -> rental
        | Error error -> failwithf "cancellation on following day failed: %s" error.Code
    check "following-day cancellation has no chargeable days" 0L (Rental.billableInWindow cancelledOnFollowingDay fullRange)

    let oneDayRental =
        match Rental.start 12L 13L with
        | Ok rental -> rental
        | Error error -> failwithf "one-day rental setup failed: %s" error.Code
    check "one-day rental has no chargeable days" 0L (Rental.billableInWindow oneDayRental fullRange)

    let cancelledAfterFinish =
        match Rental.cancel original 9L with
        | Ok rental -> rental
        | Error error -> failwithf "cancellation after finish failed: %s" error.Code
    check "after-finish cancellation preserves chargeable days" 5L (Rental.billableInWindow cancelledAfterFinish exactBounds)

    let publicConstructors =
        typeof<BillingWindow.T>.GetConstructors(BindingFlags.Public ||| BindingFlags.Instance)
    check "billing window has no public constructor" 0 publicConstructors.Length

    let expectTotal name expected result =
        match result with
        | Ok actual -> check name expected actual
        | Error error -> failwithf "%s returned %s" name error.Code

    let expectTotalError name result =
        match result with
        | Error error ->
            check (name + " error code") "INVALID_BILLING_WINDOW" error.Code
            check (name + " explains invalid window") true (not (System.String.IsNullOrWhiteSpace error.Message))
        | Ok total -> failwithf "%s expected an error but received %d" name total

    expectTotal "empty rental list totals zero" 0L (Rental.totalBillableDays [] -4L 5L)
    expectTotal "empty rental list handles extreme window" 0L (Rental.totalBillableDays [] System.Int64.MinValue System.Int64.MaxValue)
    expectTotalError "invalid window rejected for empty list" (Rental.totalBillableDays [] 5L 5L)
    expectTotalError "reversed window rejected for empty list" (Rental.totalBillableDays [] 6L 5L)
    expectTotalError "invalid window rejected when all rentals are empty" (Rental.totalBillableDays [cancelledAtStart] 5L 5L)
    expectTotal "valid window with empty occupancy totals zero" 0L (Rental.totalBillableDays [cancelledAtStart] 2L 8L)

    let overlapping =
        match Rental.start 4L 10L with
        | Ok rental -> rental
        | Error error -> failwithf "overlapping rental setup failed: %s" error.Code
    let rentals = [original; overlapping; original]
    let fieldsBeforeQuery = rentals |> List.map (fun rental -> Rental.startDay rental, Rental.finishDay rental, Rental.cancelledDay rental)
    expectTotal "overlapping and repeated rentals count independently" 15L (Rental.totalBillableDays rentals 0L 10L)
    check "query preserves rental order and fields" fieldsBeforeQuery (rentals |> List.map (fun rental -> Rental.startDay rental, Rental.finishDay rental, Rental.cancelledDay rental))
    expectTotal "one-day rental incurs no charge" 0L (Rental.totalBillableDays [oneDayRental] 0L 20L)
    expectTotal "following-day cancellation incurs no charge" 0L (Rental.totalBillableDays [cancelledOnFollowingDay] 0L 10L)

    match Rental.totalBillableDays [original] 2L 3L, Rental.totalBillableDays [original] 3L 8L with
    | Ok firstSlice, Ok laterSlice -> check "split total queries charge only days after original start" 5L (firstSlice + laterSlice)
    | _ -> failwith "split total queries returned an error"

    let cancelledBeforeFinish =
        match Rental.cancel original 4L with
        | Ok rental -> rental
        | Error error -> failwithf "partial cancellation setup failed: %s" error.Code
    expectTotal "partial cancellation and clipping are both counted" 4L (Rental.totalBillableDays [original; cancelledBeforeFinish] 3L 6L)
    expectTotal "cancellation boundary is excluded" 0L (Rental.totalBillableDays [cancelledBeforeFinish] 4L 10L)
    expectTotal "cancellation after finish keeps full chargeable span" 5L (Rental.totalBillableDays [cancelledAfterFinish] 0L 10L)
    expectTotal "full signed endpoint range does not affect bounded count" 5L (Rental.totalBillableDays [original] System.Int64.MinValue System.Int64.MaxValue)
    expectTotal "window ending inside rental is half-open and excludes start" 0L (Rental.totalBillableDays [original] System.Int64.MinValue 3L)

    checks

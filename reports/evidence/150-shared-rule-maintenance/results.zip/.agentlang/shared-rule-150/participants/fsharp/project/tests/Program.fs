open DomainBaselineTests
open BillingWindowTests

[<EntryPoint>]
let main _ =
    let checks = DomainBaselineTests.run () + BillingWindowTests.run ()
    printfn "PASS %d checks (37 inherited baseline assertions plus validated-window tests)" checks
    0

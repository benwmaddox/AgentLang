namespace RentalDomain

module BillingWindow =
    /// An opaque, nonempty half-open billing interval.
    type T = private {
        FromDay: int64
        UntilDay: int64
    }

    /// Creates a billing interval when its exclusive end is after its start.
    let tryCreate (fromDay: int64) (untilDay: int64) : T option =
        if fromDay >= untilDay then
            None
        else
            Some { FromDay = fromDay; UntilDay = untilDay }

    /// Returns the inclusive start endpoint.
    let fromDay (window: T) = window.FromDay

    /// Returns the exclusive end endpoint.
    let untilDay (window: T) = window.UntilDay

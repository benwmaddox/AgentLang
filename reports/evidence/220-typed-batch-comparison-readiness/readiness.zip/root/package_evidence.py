"""Seal text readiness evidence; exclude runtime binaries and generated build trees."""
from pathlib import Path
import hashlib
import json
import zipfile

repo = Path(__file__).resolve().parents[3]
scratch = repo / '.agentlang/typed-batch-comparison-220'
target = repo / 'reports/evidence/220-typed-batch-comparison-readiness'
target.mkdir(parents=True, exist_ok=True)
entries = {}
for subtree in ['root', 'fsharp/attempts', 'fsharp/receipts']:
    base = scratch / subtree
    if not base.exists():
        continue
    for path in base.rglob('*'):
        if not path.is_file() or any(part in {'bin', 'obj', '__pycache__', 'pin-gate-tests'} for part in path.relative_to(base).parts):
            continue
        if path.suffix.lower() not in {'.json', '.jsonl', '.txt', '.log', '.fs', '.fsproj', '.py', '.flow', '.agent', '.md'}:
            continue
        entries[path.relative_to(scratch).as_posix()] = path.read_bytes()
archive = target / 'readiness.zip'
members = []
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as output:
    for name, data in sorted(entries.items()):
        info = zipfile.ZipInfo(name, date_time=(2026, 10, 11, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        output.writestr(info, data)
        members.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
with zipfile.ZipFile(archive) as saved:
    assert sorted(saved.namelist()) == sorted(entries)
    for row in members:
        data = saved.read(row['path'])
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
index = {
    'status': 'reviewed preparation controls; no participant outcome or dispatch freeze',
    'participantsDispatched': 0,
    'archive': archive.name,
    'archiveSha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'memberCount': len(members),
    'exclusions': ['runtime binaries', 'generated bin/obj trees', 'temporary pin tests'],
    'members': members,
}
(target / 'index.json').write_text(json.dumps(index, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: value for key, value in index.items() if key != 'members'}))

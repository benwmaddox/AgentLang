import hashlib
import importlib.util
import json
from pathlib import Path

repo = Path(__file__).resolve().parents[3]
path = repo / 'experiments/AgentLang.SubagentTrials/typed-batch-comparison-220/oracle/language/score.py'
spec = importlib.util.spec_from_file_location('pin220', path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
cli = repo / 'src/AgentLang.Cli/bin/Release/net9.0/AgentLang.Cli.dll'
files = []
for name in sorted(module.required_paths(cli)):
    data = (repo / name).read_bytes()
    files.append(dict(path=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
manifest = dict(status='frozen220', scope='runtime/source pins for isolated readiness controls only; not participant dispatch gate',
    participantsDispatched=0, dispatchAllowed=False, languageCli=cli.relative_to(repo).as_posix(), files=files)
out = repo / '.agentlang/typed-batch-comparison-220/root/control-inputs.json'
assert not out.exists(), 'Never overwrite control pins'
out.write_text(json.dumps(manifest, indent=2) + '\n')
print(module.verify_pins(out, cli))

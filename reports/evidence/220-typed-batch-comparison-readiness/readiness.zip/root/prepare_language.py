import hashlib
import json
from pathlib import Path
import shutil
import subprocess

repo = Path(__file__).resolve().parents[3]
study = repo / '.agentlang/typed-batch-comparison-220'
source = repo / '.agentlang/paired-vocabulary-213/actors/retained'
expected = 'b99ad6a855a96aa2ed577230b0c03c285d38e65f40f850ea7420d0f29d5f1611'

def fingerprint(root):
    digest = hashlib.sha256()
    for path in sorted((p for p in root.rglob('*') if p.is_file()), key=lambda p: p.relative_to(root).as_posix()):
        assert not path.is_symlink()
        relative = path.relative_to(root).as_posix().encode()
        content = path.read_bytes()
        digest.update(len(relative).to_bytes(8, 'big'))
        digest.update(relative)
        digest.update(len(content).to_bytes(8, 'big'))
        digest.update(content)
    return digest.hexdigest()

assert fingerprint(source) == expected
target = study / 'baselines/retained'
assert not target.exists(), 'Never overwrite baseline'
target.parent.mkdir(parents=True, exist_ok=True)
shutil.copytree(source, target)
assert fingerprint(target) == expected
cli = repo / 'src/AgentLang.Cli/bin/Release/net9.0/AgentLang.Cli.dll'
requests = [{'op': 'test-all'}, {'op': 'describe', 'word': 'subscription.renew-batch'}]
run = subprocess.run(['dotnet', str(cli), '--project', str(target), '--filesystem', 'virtual', '--jsonl'],
    input=''.join(json.dumps(row) + '\n' for row in requests), text=True, capture_output=True, timeout=120)
(study / 'root/retained-smoke.stdout.jsonl').write_text(run.stdout, encoding='utf-8')
(study / 'root/retained-smoke.stderr.txt').write_text(run.stderr, encoding='utf-8')
rows = [json.loads(line) for line in run.stdout.splitlines()]
assert run.returncode == 0 and len(rows) == 2 and all(row.get('ok') for row in rows)
assert fingerprint(target) == expected and fingerprint(source) == expected
runtime = []
for folder in [cli.parent, repo / 'experiments/AgentLang.Conventional.Cli/bin/Release/net9.0']:
    for path in sorted(folder.iterdir()):
        if path.is_file() and path.suffix in ['.dll', '.json']:
            data = path.read_bytes()
            runtime.append(dict(path=path.relative_to(repo).as_posix(), bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
receipt = dict(status='language baseline passes fresh CLI smoke; F# readiness and freeze pending',
    participantsDispatched=0, baselineFingerprint=expected, exitCode=run.returncode,
    responses=len(rows), runtimeFiles=runtime, capabilities=[], filesystem='virtual')
(study / 'root/readiness.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: v for k, v in receipt.items() if k != 'runtimeFiles'}))

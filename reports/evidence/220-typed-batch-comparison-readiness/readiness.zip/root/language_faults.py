import importlib.util
import json
from pathlib import Path

repo = Path(__file__).resolve().parents[3]
study = repo / '.agentlang/typed-batch-comparison-220'
path = repo / 'experiments/AgentLang.SubagentTrials/typed-batch-failure-216/preparation/prepare_controls.py'
spec = importlib.util.spec_from_file_location('controls216_faults220', path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.RUNTIME = repo / 'src/AgentLang.Cli/bin/Release/net9.0'
module.ACTOR_ROOT = study / 'baselines'
module.CONTROLS = study / 'root/language-controls'
pins = json.loads((study / 'root/control-inputs.json').read_text())
scoring = module.load_failure_scorer()
positive = module.CONTROLS / 'retained/positive-fresh220'
summary = []
for mutation in ['always-zero-index', 'last-error-wins']:
    project, receipt = module.run_fault('retained', mutation, pins, positive / 'project', positive / 'migration.flow', 'fresh220', scoring)
    summary.append(dict(mutation=mutation, status=receipt['status'],
        executed=receipt.get('behavior', {}).get('executedCaseCount'),
        matchesCorrect=receipt.get('behavior', {}).get('matchesCorrectBehaviorCount'),
        matchesPrediction=receipt.get('behavior', {}).get('matchesFaultPredictionCount')))
    print(json.dumps(summary[-1]), flush=True)
    assert receipt['status'] == 'fault-behavior-calibrated'
(study / 'root/language-fault-summary.json').write_text(json.dumps(summary, indent=2) + '\n')

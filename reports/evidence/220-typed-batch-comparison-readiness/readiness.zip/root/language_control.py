import hashlib
import importlib.util
import json
from pathlib import Path

repo = Path(__file__).resolve().parents[3]
study = repo / '.agentlang/typed-batch-comparison-220'
pins = json.loads((study / 'root/readiness.json').read_text())
for row in pins['runtimeFiles']:
    data = (repo / row['path']).read_bytes()
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
path = repo / 'experiments/AgentLang.SubagentTrials/typed-batch-failure-216/preparation/prepare_controls.py'
spec = importlib.util.spec_from_file_location('controls216_for220', path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.RUNTIME = repo / 'src/AgentLang.Cli/bin/Release/net9.0'
module.ACTOR_ROOT = study / 'baselines'
module.CONTROLS = study / 'root/language-controls'
project, passed = module.run_positive('retained', pins, 'fresh220')
receipt_path = project.parent / 'receipt.json'
receipt = json.loads(receipt_path.read_text())
receipt['scopeDeviation'] = 'None: 220 calls the reused positive control only on a disposable copy; original historical actors are not executed or edited. The baseline smoke used a separate exact copy.'
receipt['study'] = '220 fresh runtime preparation, not historical216 outcome'
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(dict(passed=passed, project=str(project), status=receipt['status'])))
assert passed

# F# baseline build and self-test receipt

**Evidence status:** Reconstructed from the observed tool output in this task; the original terminal output was not saved, and the commands were not rerun for this receipt.

Build command (exit code 0):

```powershell
dotnet build experiments/AgentLang.SubagentTrials/typed-batch-comparison-220/seed/fsharp/SubscriptionBatch.Conventional.fsproj -m:1 -nr:false -p:MSBuildEnableWorkloadResolver=false -p:WarningsNotAsErrors=NU1900
```

Observed result: `Build succeeded.`, 0 errors, 4 warnings. All four were NU1900 vulnerability-feed warnings because `https://api.nuget.org/v3/index.json` was unavailable. The command explicitly downgraded NU1900 from error to warning; it did not disable auditing. Observed build time: 0.94 seconds.

Self-test command (exit code 0):

```powershell
dotnet run --no-build --project experiments/AgentLang.SubagentTrials/typed-batch-comparison-220/seed/fsharp/SubscriptionBatch.Conventional.fsproj
```

Observed output:

```text
Baseline checks passed: domain, eight monthly/annual scenarios, and six batch/helper scenarios
```

That is 14 self-check scenarios total. This receipt records the observed output and is not a fresh validation run.

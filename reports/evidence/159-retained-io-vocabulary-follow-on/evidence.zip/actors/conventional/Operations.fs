namespace AgentLang.SubagentTrials.IoMaintenance156.Fixture

module ConfigurationOperations =
    /// Creates an absent destination from the source, or reports whether an existing
    /// destination already matches. Reads the source and destination without changing
    /// existing files, and writes only when creating the destination.
    let publishSafely (files: VirtualFiles, source: string, destination: string) : PublishOutcome =
        if files.Exists destination then
            let destinationContents = files.Read destination
            let sourceContents = files.Read source

            if destinationContents = sourceContents then
                Unchanged
            else
                Conflict
        else
            let sourceContents = files.Read source
            files.Write(destination, sourceContents)
            Created

    /// Publishes the source when the destination is absent or already matches, then
    /// refreshes the mirror from the destination whenever publication succeeds.
    let publishAndMirror (files: VirtualFiles, source: string, destination: string, mirror: string) : PublishOutcome =
        let outcome = publishSafely(files, source, destination)

        match outcome with
        | Created
        | Unchanged ->
            let destinationContents = files.Read destination
            files.Write(mirror, destinationContents)
            outcome
        | Conflict -> outcome

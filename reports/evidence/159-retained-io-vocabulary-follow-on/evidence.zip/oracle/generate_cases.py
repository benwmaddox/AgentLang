#!/usr/bin/env python3
"""Create the shared, frozen IO-reuse-159 oracle cases."""

from __future__ import annotations

import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
CASE_PATH = HERE / "cases.json"
SOURCE = "/workspace/source.txt"
DESTINATION = "/workspace/published.txt"
MIRROR = "/workspace/mirror.txt"
SENTINEL = "/workspace/sentinel.txt"

PAYLOADS = {
    "ascii": "status=ready\n",
    "empty": "",
    "literal_unicode": "snow 雪; café ☕; leaf 🌿\n",
    "crlf": "first\r\nsecond\r\n",
}
OUTCOMES = {
    "created": (None, "Created"),
    "unchanged": ("destination already matches\n", "Unchanged"),
    "conflict": ("destination has local edits\r\n", "Conflict"),
}
COUNTS = {
    "Created": {"reads": 3, "writes": 2},
    "Unchanged": {"reads": 4, "writes": 1},
    "Conflict": {"reads": 3, "writes": 0},
}


def make_case(outcome_key: str, payload_key: str, payload: str) -> dict:
    destination_text, first_outcome = OUTCOMES[outcome_key]
    mirror_text = None if payload_key in ("ascii", "literal_unicode") else "stale mirror\r\n"
    initial_files = {
        SOURCE: payload,
        SENTINEL: "keep this unrelated file\r\n",
    }
    if destination_text is not None:
        initial_files[DESTINATION] = payload if outcome_key == "unchanged" else destination_text
    if mirror_text is not None:
        initial_files[MIRROR] = mirror_text

    first_files = dict(initial_files)
    if first_outcome == "Created":
        first_files[DESTINATION] = payload
    if first_outcome != "Conflict":
        first_files[MIRROR] = payload

    second_outcome = "Unchanged" if first_outcome == "Created" else first_outcome
    second_files = dict(first_files)
    if second_outcome != "Conflict":
        second_files[MIRROR] = payload

    return {
        "id": f"{outcome_key}_{payload_key}",
        "outcome_case": outcome_key,
        "payload_case": payload_key,
        "mirror_initial": "absent" if mirror_text is None else "stale",
        "input": {
            "source": SOURCE,
            "destination": DESTINATION,
            "mirror": MIRROR,
            "sentinel": SENTINEL,
            "files": initial_files,
        },
        "expected": {
            "steps": [
                {"outcome": first_outcome, **COUNTS[first_outcome], "files": first_files},
                {"outcome": second_outcome, **COUNTS[second_outcome], "files": second_files},
            ],
        },
    }


def main() -> None:
    cases = [
        make_case(outcome_key, payload_key, payload)
        for outcome_key in OUTCOMES
        for payload_key, payload in PAYLOADS.items()
    ]
    document = {
        "schema_version": 1,
        "contract": {
            "source_must_exist": True,
            "all_paths_distinct": True,
            "mirror_initial_states": ["absent", "stale"],
            "outcome_counts_per_call": COUNTS,
            "on_created_or_unchanged": "copy exact destination contents to mirror, even if already identical",
            "on_conflict": "preserve destination and mirror",
        },
        "case_count": len(cases),
        "invocation_count": sum(len(case["expected"]["steps"]) for case in cases),
        "cases": cases,
    }
    CASE_PATH.write_text(json.dumps(document, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()

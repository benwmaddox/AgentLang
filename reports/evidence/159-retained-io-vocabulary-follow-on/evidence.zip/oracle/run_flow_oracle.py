#!/usr/bin/env python3
"""Run the independent Flow/2 IO-reuse-159 acceptance oracle."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

from flow_test_sources import RECORD_SOURCE, TARGET, build_tests


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]
CASES_PATH = HERE / "cases.json"
DEFAULT_CLI = REPO / ".agentlang" / "io-reuse-159" / "runtime" / "flow" / "AgentLang.Cli.dll"


def load_cases(path: Path) -> tuple[bytes, list[dict[str, Any]]]:
    raw = path.read_bytes()
    document = json.loads(raw)
    if document.get("schema_version") != 1:
        raise ValueError("Unsupported case file schema_version")
    cases = document.get("cases")
    if not isinstance(cases, list) or len(cases) != 12:
        raise ValueError("The acceptance oracle must contain exactly 12 input cases")
    if document.get("invocation_count") != 24:
        raise ValueError("The shared case file must describe 24 paired calls")
    return raw, cases


def run(args: argparse.Namespace) -> dict[str, Any]:
    project = args.project_path.resolve()
    cli = args.cli_dll.resolve()
    if not project.is_dir():
        raise ValueError(f"project path does not exist: {project}")
    if not cli.is_file():
        raise ValueError(f"AgentLang CLI DLL does not exist: {cli}")

    case_bytes, cases = load_cases(args.cases)
    test_sources, expected_tests = build_tests(cases)
    definitions = [{"op": "define", "source": RECORD_SOURCE, "frontend": "flow", "syntaxVersion": 2}]
    if args.implementation_source:
        definitions.append(
            {
                "op": "define",
                "source": args.implementation_source.read_text(encoding="utf-8-sig"),
                "frontend": "flow",
                "syntaxVersion": 2,
            }
        )
    definitions.extend(
        {"op": "define", "source": source, "frontend": "flow", "syntaxVersion": 2}
        for source in test_sources
    )
    test_requests = [{"op": "test", "word": TARGET, "frontend": "flow", "syntaxVersion": 2}]
    requests = definitions + test_requests

    run_root = HERE / "runs"
    run_root.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="flow-oracle-", dir=run_root) as temp_name:
        disposable = Path(temp_name) / "project"
        shutil.copytree(project, disposable)
        command = [
            "dotnet",
            str(cli),
            "--project",
            str(disposable),
            "--allow",
            "fs.read,fs.write",
            "--jsonl",
        ]
        completed = subprocess.run(
            command,
            input="".join(json.dumps(request, ensure_ascii=True, separators=(",", ":")) + "\n" for request in requests),
            text=True,
            encoding="utf-8",
            capture_output=True,
            check=False,
        )

    responses: list[Any] = []
    parse_error = None
    try:
        responses = [json.loads(line) for line in completed.stdout.splitlines() if line.strip()]
    except json.JSONDecodeError as error:
        parse_error = str(error)

    define_results = responses[: len(definitions)]
    test_results = responses[len(definitions) :]
    test_response = test_results[0] if len(test_results) == 1 else {}
    result_nodes = test_response.get("data", {}).get("results", []) if isinstance(test_response, dict) else []
    cases_by_name: dict[str, dict[str, Any]] = {}
    duplicate_cases: list[str] = []
    expected_names = set(expected_tests)
    for result in result_nodes:
        if not isinstance(result, dict):
            continue
        name = result.get("name")
        if name not in expected_names:
            continue
        if name in cases_by_name:
            duplicate_cases.append(name)
        else:
            cases_by_name[name] = result

    per_test: dict[str, Any] = {}
    for name, expected in expected_tests.items():
        actual = cases_by_name.get(name)
        if actual is None:
            per_test[name] = {"passed": False, "missing": True, "expected": expected}
            continue
        effects = actual.get("effectAssertion") or {}
        actual_counts = effects.get("actual") or {}
        actual_invocations = effects.get("targetInvocationCount")
        count_names = ("clock.read", "console.write", "fs.read", "fs.write")
        normalized_counts = {key: actual_counts.get(key, 0) for key in count_names}
        expected_counts = {
            "clock.read": 0,
            "console.write": 0,
            "fs.read": expected["reads"],
            "fs.write": expected["writes"],
        }
        count_match = normalized_counts == expected_counts
        invocation_match = actual_invocations == expected["invocations"]
        per_test[name] = {
            "passed": bool(actual.get("passed")) and count_match and invocation_match,
            "expected": expected,
            "actual": {
                "passed": actual.get("passed"),
                "expectedValue": actual.get("expected"),
                "value": actual.get("actual"),
                "effects": normalized_counts,
                "targetInvocationCount": actual_invocations,
                "errorCode": actual.get("errorCode"),
            },
        }

    definitions_ok = len(define_results) == len(definitions) and all(
        isinstance(result, dict) and result.get("ok") is True for result in define_results
    )
    all_tests_seen = len(cases_by_name) == len(expected_names) and not duplicate_cases
    all_tests_pass = all_tests_seen and all(result["passed"] for result in per_test.values())
    process_ok = completed.returncode == 0 and not completed.stderr and parse_error is None
    any_test_rejected = all_tests_seen and any(not result["passed"] for result in per_test.values())
    success = definitions_ok and process_ok and (any_test_rejected if args.expect_failure else all_tests_pass)
    return {
        "schema_version": 1,
        "language": "flow/2",
        "project_path": str(project),
        "tested_disposable_copy": True,
        "original_project_mutated": False,
        "implementation_source": str(args.implementation_source.resolve()) if args.implementation_source else None,
        "case_sha256": hashlib.sha256(case_bytes).hexdigest(),
        "case_count": len(cases),
        "single_call_test_count": len(cases),
        "sequential_repeat_test_count": len(cases),
        "single_call_target_invocations": len(cases),
        "sequential_repeat_target_invocations": 2 * len(cases),
        "total_target_invocations": 3 * len(cases),
        "repeat_tests_are_sequential": True,
        "repeat_test_effect_counts_are_combined": True,
        "expected_test_count": len(expected_tests),
        "seen_test_count": len(cases_by_name),
        "definitions_ok": definitions_ok,
        "all_tests_seen": all_tests_seen,
        "all_tests_pass": all_tests_pass,
        "duplicate_cases": duplicate_cases,
        "cli_exit_code": completed.returncode,
        "stderr": completed.stderr,
        "stdout_parse_error": parse_error,
        "expectation": "failure" if args.expect_failure else "pass",
        "test_results": per_test,
        "result": "pass" if success else "fail",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-path", required=True, type=Path, help="Flow project to copy and test")
    parser.add_argument("--implementation-source", type=Path, help="Optional target definition source for controls")
    parser.add_argument("--cli-dll", type=Path, default=DEFAULT_CLI)
    parser.add_argument("--cases", type=Path, default=CASES_PATH)
    parser.add_argument("--expect-failure", action="store_true")
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    try:
        report = run(args)
    except (OSError, ValueError, json.JSONDecodeError) as error:
        parser.error(str(error))
    if args.report:
        if args.report.exists():
            parser.error(f"report already exists; choose a new path: {args.report}")
        args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=True, indent=2))
    return 0 if report["result"] == "pass" else 1


if __name__ == "__main__":
    sys.exit(main())

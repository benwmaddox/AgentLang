#!/usr/bin/env python3
"""Prepare positive and deliberately faulty controls without touching actor copies."""

from __future__ import annotations

import shutil
from pathlib import Path


HERE = Path(__file__).resolve().parent
IO_REUSE_ROOT = HERE.parents[0]
ACTORS = IO_REUSE_ROOT / "actors"
CONTROLS = HERE / "controls"

FLOW_IMPLEMENTATIONS = {
    "positive": '''fn configuration.publish-and-mirror(source: String, destination: String, mirror: String) -> PublishOutcome {
    effects fs.read, fs.write

    let outcome = configuration.publish-safely(source, destination)
    if equals(outcome, PublishOutcome.conflict()) {
        outcome
    } else {
        let contents = file.read(destination)
        file.write(mirror, contents)
        outcome
    }
}''',
    "conflict-mirror-overwrite": '''fn configuration.publish-and-mirror(source: String, destination: String, mirror: String) -> PublishOutcome {
    effects fs.read, fs.write

    let outcome = configuration.publish-safely(source, destination)
    let contents = file.read(destination)
    file.write(mirror, contents)
    outcome
}''',
    "wrong-mirror-content": '''fn configuration.publish-and-mirror(source: String, destination: String, mirror: String) -> PublishOutcome {
    effects fs.read, fs.write

    let outcome = configuration.publish-safely(source, destination)
    if equals(outcome, PublishOutcome.conflict()) {
        outcome
    } else {
        file.write(mirror, "wrong mirror contents")
        outcome
    }
}''',
    "extra-unchanged-write": '''fn configuration.publish-and-mirror(source: String, destination: String, mirror: String) -> PublishOutcome {
    effects fs.read, fs.write

    let outcome = configuration.publish-safely(source, destination)
    if equals(outcome, PublishOutcome.conflict()) {
        outcome
    } else {
        let contents = file.read(destination)
        file.write(mirror, contents)
        if equals(outcome, PublishOutcome.unchanged()) {
            file.write(destination, contents)
        } else {
            unit
        }
        outcome
    }
}''',
}

FSHARP_IMPLEMENTATIONS = {
    "positive": '''
    let publishAndMirror (files: VirtualFiles, source: string, destination: string, mirror: string) : PublishOutcome =
        let outcome = publishSafely(files, source, destination)

        match outcome with
        | Conflict -> outcome
        | Created
        | Unchanged ->
            let contents = files.Read(destination)
            files.Write(mirror, contents)
            outcome
''',
    "conflict-mirror-overwrite": '''
    let publishAndMirror (files: VirtualFiles, source: string, destination: string, mirror: string) : PublishOutcome =
        let outcome = publishSafely(files, source, destination)
        let contents = files.Read(destination)
        files.Write(mirror, contents)
        outcome
''',
    "wrong-mirror-content": '''
    let publishAndMirror (files: VirtualFiles, source: string, destination: string, mirror: string) : PublishOutcome =
        let outcome = publishSafely(files, source, destination)

        match outcome with
        | Conflict -> outcome
        | Created
        | Unchanged ->
            files.Write(mirror, "wrong mirror contents")
            outcome
''',
    "extra-unchanged-write": '''
    let publishAndMirror (files: VirtualFiles, source: string, destination: string, mirror: string) : PublishOutcome =
        let outcome = publishSafely(files, source, destination)

        match outcome with
        | Conflict -> outcome
        | Created ->
            let contents = files.Read(destination)
            files.Write(mirror, contents)
            outcome
        | Unchanged ->
            let contents = files.Read(destination)
            files.Write(mirror, contents)
            files.Write(destination, contents)
            outcome
''',
}


def prepare_language(language: str, implementations: dict[str, str]) -> None:
    source = ACTORS / language
    language_root = CONTROLS / language
    language_root.mkdir(parents=True, exist_ok=True)
    for name, implementation in implementations.items():
        target = language_root / name
        if target.exists():
            raise FileExistsError(f"control already exists; remove only this script-owned directory before regenerating: {target}")
        project = target / "project"
        shutil.copytree(source, project)
        if language == "flow":
            (target / "implementation.agent").write_text(implementation + "\n", encoding="utf-8")
        else:
            operations = project / "Operations.fs"
            existing = operations.read_text(encoding="utf-8")
            operations.write_text(existing.rstrip() + "\n" + implementation, encoding="utf-8")


def main() -> None:
    prepare_language("flow", FLOW_IMPLEMENTATIONS)
    prepare_language("conventional", FSHARP_IMPLEMENTATIONS)


if __name__ == "__main__":
    main()

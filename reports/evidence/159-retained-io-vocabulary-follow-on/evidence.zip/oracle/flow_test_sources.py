"""Generate Flow/2 acceptance tests from the shared JSON cases."""

from __future__ import annotations

from typing import Any


TARGET = "configuration.publish-and-mirror"
RECORD_SOURCE = """record Oracle159Observation {
    field outcomes: List<PublishOutcome>
    field source: Option<String>
    field destination: Option<String>
    field mirror: Option<String>
    field sentinel: Option<String>
}"""


def flow_string(value: str) -> str:
    escaped = []
    for char in value:
        escaped.append({"\\": "\\\\", '"': '\\"', "\n": "\\n", "\r": "\\r", "\t": "\\t", "\b": "\\b", "\f": "\\f"}.get(char, char))
    return '"' + "".join(escaped) + '"'


def option_expr(value: str | None) -> str:
    return f"option.some<String>({flow_string(value)})" if value is not None else "option.none<String>()"


def outcome_expr(values: list[str]) -> str:
    if not values:
        return "list.empty<PublishOutcome>()"
    expression = f"list.singleton<PublishOutcome>(PublishOutcome.{values[0].lower()}())"
    for value in values[1:]:
        expression = f"list.append({expression}, PublishOutcome.{value.lower()}())"
    return expression


def _state_observation(lines: list[str], paths: dict[str, str]) -> None:
    for label in ("source", "destination", "mirror", "sentinel"):
        path = paths[label]
        lines.extend(
            [
                f"    let {label}-state = if file.exists?({flow_string(path)}) {{",
                f"        option.some<String>(file.read({flow_string(path)}))",
                "    } else {",
                "        option.none<String>()",
                "    }",
            ]
        )


def _test_source(
    case: dict[str, Any],
    *,
    input_files: dict[str, str],
    outcomes: list[str],
    expected_files: dict[str, str],
    reads: int,
    writes: int,
    suffix: str,
    repeat: bool,
) -> str:
    data = case["input"]
    paths = {key: data[key] for key in ("source", "destination", "mirror", "sentinel")}
    test_name = f"oracle159-{case['id'].replace('_', '-')}-{suffix}"
    lines = [f"test {TARGET}/{test_name} {{"]
    for path, contents in input_files.items():
        lines.append(f"    file.write({flow_string(path)}, {flow_string(contents)})")

    outcome_vars = []
    for index in range(2 if repeat else 1):
        variable = f"outcome-{index + 1}"
        outcome_vars.append(variable)
        lines.append(
            f"    let {variable} = {TARGET}({flow_string(paths['source'])}, "
            f"{flow_string(paths['destination'])}, {flow_string(paths['mirror'])})"
        )

    actual_outcomes = f"list.singleton<PublishOutcome>({outcome_vars[0]})"
    for variable in outcome_vars[1:]:
        actual_outcomes = f"list.append({actual_outcomes}, {variable})"
    _state_observation(lines, paths)
    lines.extend(
        [
            "    oracle159Observation.new(",
            f"        outcomes = {actual_outcomes},",
            "        source = source-state,",
            "        destination = destination-state,",
            "        mirror = mirror-state,",
            "        sentinel = sentinel-state",
            "    )",
            "    => value oracle159Observation.new(",
            f"        outcomes = {outcome_expr(outcomes)},",
            f"        source = {option_expr(expected_files.get(paths['source']))},",
            f"        destination = {option_expr(expected_files.get(paths['destination']))},",
            f"        mirror = {option_expr(expected_files.get(paths['mirror']))},",
            f"        sentinel = {option_expr(expected_files.get(paths['sentinel']))}",
            "    ) effects {",
            f"        fs.read: {reads}",
            f"        fs.write: {writes}",
            "    }",
            "}",
        ]
    )
    return "\n".join(lines)


def build_tests(cases: list[dict[str, Any]]) -> tuple[list[str], dict[str, dict[str, Any]]]:
    tests: list[str] = []
    expectations: dict[str, dict[str, Any]] = {}
    for case in cases:
        initial_files = dict(case["input"]["files"])
        steps = case["expected"]["steps"]

        first = steps[0]
        first_name = f"oracle159-{case['id'].replace('_', '-')}-first"
        tests.append(
            _test_source(
                case,
                input_files=initial_files,
                outcomes=[first["outcome"]],
                expected_files=first["files"],
                reads=first["reads"],
                writes=first["writes"],
                suffix="first",
                repeat=False,
            )
        )
        expectations[first_name] = {
            "invocations": 1,
            "outcomes": [first["outcome"]],
            "reads": first["reads"],
            "writes": first["writes"],
        }

        second = steps[1]
        repeated_name = f"oracle159-{case['id'].replace('_', '-')}-repeated"
        tests.append(
            _test_source(
                case,
                input_files=initial_files,
                outcomes=[first["outcome"], second["outcome"]],
                expected_files=second["files"],
                reads=first["reads"] + second["reads"],
                writes=first["writes"] + second["writes"],
                suffix="repeated",
                repeat=True,
            )
        )
        expectations[repeated_name] = {
            "invocations": 2,
            "outcomes": [first["outcome"], second["outcome"]],
            "reads": first["reads"] + second["reads"],
            "writes": first["writes"] + second["writes"],
        }

    return tests, expectations

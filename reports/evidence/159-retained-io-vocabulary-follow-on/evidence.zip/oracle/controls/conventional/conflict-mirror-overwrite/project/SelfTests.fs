namespace AgentLang.SubagentTrials.IoMaintenance156.Fixture

module SelfTests =
    let private assertEqual testName expected actual =
        if actual <> expected then
            failwithf "%s: expected %A, got %A" testName expected actual

    let publishCopiesExactlyAndReturnsUnit () =
        let files =
            VirtualFiles(
                [ "source.txt", "source contents"
                  "destination.txt", "old destination"
                  "sentinel.txt", "leave this alone" ]
            )

        let result: unit = Configuration.publish(files, "source.txt", "destination.txt")

        assertEqual "publish result" () result
        assertEqual "copied contents" (Some "source contents") (files.Peek("destination.txt"))
        assertEqual "sentinel preserved" (Some "leave this alone") (files.Peek("sentinel.txt"))
        assertEqual "publish reads" 1 files.ReadCount
        assertEqual "publish writes" 1 files.WriteCount

    let publishPreservesEmptyContentsAndSentinel () =
        let files =
            VirtualFiles(
                [ "empty-source.txt", ""
                  "destination.txt", "replace this"
                  "sentinel.txt", "sentinel contents" ]
            )

        Configuration.publish(files, "empty-source.txt", "destination.txt")

        assertEqual "empty source copied" (Some "") (files.Peek("destination.txt"))
        assertEqual "empty publish sentinel preserved" (Some "sentinel contents") (files.Peek("sentinel.txt"))
        assertEqual "empty publish reads" 1 files.ReadCount
        assertEqual "empty publish writes" 1 files.WriteCount

    let publishPreservesUnicodeAndLineEndings () =
        let sourceContents = "Καλημέρα 🌍\r\nsecond line\nthird line\r"
        let files = VirtualFiles([ "unicode-source.txt", sourceContents; "sentinel.txt", "keep" ])

        Configuration.publish(files, "unicode-source.txt", "unicode-destination.txt")

        assertEqual "Unicode and line endings preserved" (Some sourceContents) (files.Peek("unicode-destination.txt"))
        assertEqual "Unicode sentinel preserved" (Some "keep") (files.Peek("sentinel.txt"))
        assertEqual "Unicode publish reads" 1 files.ReadCount
        assertEqual "Unicode publish writes" 1 files.WriteCount

    let safePublishCreatesExactContentsAndIsUnchangedOnRepeat () =
        let sourceContents = "\u039A\u03B1\u03BB\u03B7\u03BC\u03AD\u03C1\u03B1 \U0001F30D\r\nsecond line\nthird line\r"
        let files =
            VirtualFiles(
                [ "source.txt", sourceContents
                  "sentinel.txt", "leave this alone" ]
            )

        let firstResult = ConfigurationOperations.publishSafely(files, "source.txt", "destination.txt")

        assertEqual "safe publish creates destination" Created firstResult
        assertEqual "safe publish exact contents" (Some sourceContents) (files.Peek("destination.txt"))
        assertEqual "safe publish preserves source" (Some sourceContents) (files.Peek("source.txt"))
        assertEqual "safe publish preserves sentinel" (Some "leave this alone") (files.Peek("sentinel.txt"))
        assertEqual "safe publish create reads" 2 files.ReadCount
        assertEqual "safe publish create writes" 1 files.WriteCount

        let secondResult = ConfigurationOperations.publishSafely(files, "source.txt", "destination.txt")

        assertEqual "safe publish repeat is unchanged" Unchanged secondResult
        assertEqual "safe publish repeat preserves exact contents" (Some sourceContents) (files.Peek("destination.txt"))
        assertEqual "safe publish repeat reads" 5 files.ReadCount
        assertEqual "safe publish repeat writes" 1 files.WriteCount

    let safePublishPreservesEmptyExistingDestination () =
        let files =
            VirtualFiles(
                [ "empty-source.txt", ""
                  "destination.txt", ""
                  "sentinel.txt", "keep" ]
            )

        let result = ConfigurationOperations.publishSafely(files, "empty-source.txt", "destination.txt")

        assertEqual "safe publish empty destination is unchanged" Unchanged result
        assertEqual "safe publish empty contents preserved" (Some "") (files.Peek("destination.txt"))
        assertEqual "safe publish empty source preserved" (Some "") (files.Peek("empty-source.txt"))
        assertEqual "safe publish empty sentinel preserved" (Some "keep") (files.Peek("sentinel.txt"))
        assertEqual "safe publish existing reads" 3 files.ReadCount
        assertEqual "safe publish existing writes" 0 files.WriteCount

    let safePublishReportsConflictWithoutChangingFiles () =
        let files =
            VirtualFiles(
                [ "source.txt", "new contents"
                  "destination.txt", "old contents"
                  "sentinel.txt", "keep" ]
            )

        let firstResult = ConfigurationOperations.publishSafely(files, "source.txt", "destination.txt")

        assertEqual "safe publish different destination conflicts" Conflict firstResult
        assertEqual "safe publish conflict source preserved" (Some "new contents") (files.Peek("source.txt"))
        assertEqual "safe publish conflict destination preserved" (Some "old contents") (files.Peek("destination.txt"))
        assertEqual "safe publish conflict sentinel preserved" (Some "keep") (files.Peek("sentinel.txt"))
        assertEqual "safe publish conflict reads" 3 files.ReadCount
        assertEqual "safe publish conflict writes" 0 files.WriteCount

        let secondResult = ConfigurationOperations.publishSafely(files, "source.txt", "destination.txt")

        assertEqual "safe publish repeated conflict remains conflict" Conflict secondResult
        assertEqual "safe publish repeated conflict reads" 6 files.ReadCount
        assertEqual "safe publish repeated conflict writes" 0 files.WriteCount

    let refreshUsesPublisherWithoutCollateralChanges () =
        let files =
            VirtualFiles(
                [ "configuration.json", "{\"mode\":\"current\"}"
                  "refresh-copy.json", "stale"
                  "sentinel.json", "untouched" ]
            )

        Configuration.refresh(files, "configuration.json", "refresh-copy.json")

        assertEqual "refresh copied contents" (Some "{\"mode\":\"current\"}") (files.Peek("refresh-copy.json"))
        assertEqual "refresh sentinel preserved" (Some "untouched") (files.Peek("sentinel.json"))
        assertEqual "refresh reads" 1 files.ReadCount
        assertEqual "refresh writes" 1 files.WriteCount

    let run () =
        publishCopiesExactlyAndReturnsUnit ()
        publishPreservesEmptyContentsAndSentinel ()
        publishPreservesUnicodeAndLineEndings ()
        safePublishCreatesExactContentsAndIsUnchangedOnRepeat ()
        safePublishPreservesEmptyExistingDestination ()
        safePublishReportsConflictWithoutChangingFiles ()
        refreshUsesPublisherWithoutCollateralChanges ()

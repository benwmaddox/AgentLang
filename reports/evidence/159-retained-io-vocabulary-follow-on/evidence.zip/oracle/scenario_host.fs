namespace AgentLang.SubagentTrials.IoMaintenance156.Fixture

open System
open System.Text.Json
open System.Text.Json.Nodes

module Program =
    let private requiredString (node: JsonNode) (name: string) =
        if isNull node then
            invalidArg name (sprintf "Missing required string '%s'." name)

        node.GetValue<string>()

    let private snapshotNode (files: VirtualFiles) =
        let node = JsonObject()

        for KeyValue(path, contents) in files.Snapshot() do
            node[path] <- JsonValue.Create(contents)

        node

    let private runScenario () =
        let result = JsonObject()
        let steps = JsonArray()

        try
            let input = Console.In.ReadToEnd()
            let rootNode = JsonNode.Parse(input)

            if isNull rootNode then
                invalidArg "stdin" "Expected a JSON object on standard input."

            let root = rootNode.AsObject()
            let source = requiredString root["source"] "source"
            let destination = requiredString root["destination"] "destination"
            let mirror = requiredString root["mirror"] "mirror"

            let initialFiles =
                root["files"].AsObject()
                |> Seq.map (fun entry -> entry.Key, requiredString entry.Value entry.Key)

            let files = VirtualFiles(initialFiles)

            for _ in 1 .. 2 do
                let readsBefore = files.ReadCount
                let writesBefore = files.WriteCount
                let outcome = ConfigurationOperations.publishAndMirror(files, source, destination, mirror)
                let step = JsonObject()
                step["outcome"] <- JsonValue.Create(string outcome)
                step["reads"] <- JsonValue.Create(files.ReadCount - readsBefore)
                step["writes"] <- JsonValue.Create(files.WriteCount - writesBefore)
                step["files"] <- snapshotNode files
                steps.Add(step)

            result["steps"] <- steps
            result["files"] <- snapshotNode files
            result["error"] <- null
        with ex ->
            result["steps"] <- steps
            result["files"] <- JsonObject()
            result["error"] <- JsonValue.Create(ex.Message)

        Console.WriteLine(result.ToJsonString(JsonSerializerOptions(WriteIndented = false)))

    [<EntryPoint>]
    let main _arguments =
        runScenario ()
        0

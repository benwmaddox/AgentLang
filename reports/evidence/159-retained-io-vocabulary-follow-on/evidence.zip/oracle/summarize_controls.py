#!/usr/bin/env python3
"""Check saved positive and mutant runs, then write compact validation evidence."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any


HERE = Path(__file__).resolve().parent
RUNS = HERE / "runs"
CASES = HERE / "cases.json"
MUTANTS = (
    "conflict-mirror-overwrite",
    "wrong-mirror-content",
    "extra-unchanged-write",
)
FLOW_REPORTS = {
    "positive": "flow-positive-final.json",
    **{name: f"flow-{name}-final.json" for name in MUTANTS},
}
FSHARP_REPORTS = {
    "positive": "fsharp-positive-validation.json",
    **{name: f"fsharp-{name}.json" for name in MUTANTS},
}


def read_report(name: str) -> dict[str, Any]:
    return json.loads((RUNS / name).read_text(encoding="utf-8"))


def summarize_flow(name: str) -> dict[str, Any]:
    report = read_report(FLOW_REPORTS[name])
    rejected = [case for case, result in report["test_results"].items() if not result["passed"]]
    expected_failure = name != "positive"
    valid = (
        report.get("result") == "pass"
        and report.get("case_count") == 12
        and report.get("all_tests_seen") is True
        and ((report.get("all_tests_pass") is False and rejected) if expected_failure else report.get("all_tests_pass") is True)
        and report.get("expectation") == ("failure" if expected_failure else "pass")
        and report.get("total_target_invocations") == 36
    )
    return {
        "validated": bool(valid),
        "report": f"runs/{FLOW_REPORTS[name]}",
        "case_count": report.get("case_count"),
        "target_invocations": report.get("total_target_invocations"),
        "rejected_test_count": len(rejected),
        "sample_rejections": rejected[:4],
    }


def summarize_fsharp(name: str) -> dict[str, Any]:
    report = read_report(FSHARP_REPORTS[name])
    rejected = [case["id"] for case in report["cases"] if not case["passed"]]
    expected_failure = name != "positive"
    valid = (
        report.get("result") == "pass"
        and report.get("case_count") == 12
        and report.get("build_exit_code") == 0
        and ((report.get("all_cases_pass") is False and rejected) if expected_failure else report.get("all_cases_pass") is True)
        and report.get("expectation") == ("failure" if expected_failure else "pass")
        and report.get("total_target_invocations") == 24
        and report.get("per_call_read_write_deltas") is True
    )
    return {
        "validated": bool(valid),
        "report": f"runs/{FSHARP_REPORTS[name]}",
        "case_count": report.get("case_count"),
        "target_invocations": report.get("total_target_invocations"),
        "rejected_case_count": len(rejected),
        "sample_rejections": rejected[:4],
    }


def main() -> None:
    case_bytes = CASES.read_bytes()
    cases = json.loads(case_bytes)
    flow = {name: summarize_flow(name) for name in FLOW_REPORTS}
    fsharp = {name: summarize_fsharp(name) for name in FSHARP_REPORTS}
    document = {
        "schema_version": 1,
        "cases": {
            "path": "cases.json",
            "sha256": hashlib.sha256(case_bytes).hexdigest(),
            "case_count": cases["case_count"],
            "base_invocations": cases["invocation_count"],
            "payload_kinds": sorted({case["payload_case"] for case in cases["cases"]}),
            "outcome_kinds": sorted({case["outcome_case"] for case in cases["cases"]}),
            "mirror_initial_states": sorted({case["mirror_initial"] for case in cases["cases"]}),
        },
        "flow": {
            "invocation_note": "12 single-call tests assert exact per-call effects; 12 sequential repeat tests assert both outcomes, final exact state, aggregate effects, and target invocation count 2.",
            "positive_control": flow.pop("positive"),
            "mutants_rejected": flow,
        },
        "fsharp": {
            "invocation_note": "12 cases run two calls sequentially against one VirtualFiles instance and check each call's read/write deltas.",
            "positive_control": fsharp.pop("positive"),
            "mutants_rejected": fsharp,
        },
    }
    document["all_controls_validated"] = (
        document["flow"]["positive_control"]["validated"]
        and all(item["validated"] for item in document["flow"]["mutants_rejected"].values())
        and document["fsharp"]["positive_control"]["validated"]
        and all(item["validated"] for item in document["fsharp"]["mutants_rejected"].values())
    )
    output = HERE / "validation.json"
    output.write_text(json.dumps(document, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"validation_path": str(output), "all_controls_validated": document["all_controls_validated"]}, indent=2))
    if not document["all_controls_validated"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()

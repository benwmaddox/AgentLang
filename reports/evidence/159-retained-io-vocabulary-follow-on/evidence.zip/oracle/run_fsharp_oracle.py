#!/usr/bin/env python3
"""Build a disposable conventional actor and run the IO-reuse-159 oracle."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any


HERE = Path(__file__).resolve().parent
CASES_PATH = HERE / "cases.json"
HOST_SOURCE = HERE / "scenario_host.fs"


def resolve_project_path(path: Path) -> Path:
    resolved = path.resolve()
    if resolved.is_file() and resolved.suffix.lower() == ".fsproj":
        return resolved
    if not resolved.is_dir():
        raise ValueError(f"project path does not exist: {resolved}")
    projects = sorted(resolved.glob("*.fsproj"))
    if len(projects) != 1:
        raise ValueError(f"expected exactly one .fsproj in {resolved}, found {len(projects)}")
    return projects[0]


def read_cases(path: Path) -> tuple[bytes, list[dict[str, Any]]]:
    raw = path.read_bytes()
    document = json.loads(raw)
    cases = document.get("cases")
    if document.get("schema_version") != 1 or not isinstance(cases, list) or len(cases) != 12:
        raise ValueError("shared case file must be schema_version 1 with exactly 12 cases")
    if document.get("invocation_count") != 24:
        raise ValueError("shared case file must describe 24 sequential calls")
    return raw, cases


def normalized_expected(case: dict[str, Any]) -> dict[str, Any]:
    return {"steps": case["expected"]["steps"], "files": case["expected"]["steps"][-1]["files"], "error": None}


def run_case(project_file: Path, case: dict[str, Any], env: dict[str, str]) -> dict[str, Any]:
    data = case["input"]
    payload = json.dumps(data, ensure_ascii=True, separators=(",", ":"))
    completed = subprocess.run(
        ["dotnet", "run", "--no-build", "--configuration", "Release", "--project", str(project_file)],
        input=payload,
        text=True,
        encoding="utf-8",
        errors="strict",
        capture_output=True,
        check=False,
        env=env,
    )
    actual: Any = None
    parse_error = None
    try:
        actual = json.loads(completed.stdout)
    except json.JSONDecodeError as error:
        parse_error = str(error)

    expected = normalized_expected(case)
    mismatches: list[dict[str, Any]] = []
    if completed.returncode != 0:
        mismatches.append({"field": "returncode", "expected": 0, "actual": completed.returncode})
    if completed.stderr:
        mismatches.append({"field": "stderr", "expected": "empty", "actual": completed.stderr.strip()})
    if parse_error:
        mismatches.append({"field": "stdout", "expected": "one JSON object", "actual": parse_error})
    elif not isinstance(actual, dict):
        mismatches.append({"field": "result", "expected": "JSON object", "actual": actual})
    else:
        for field in sorted(set(expected) | set(actual)):
            if expected.get(field) != actual.get(field):
                mismatches.append({"field": field, "expected": expected.get(field, "<missing>"), "actual": actual.get(field, "<missing>")})
    return {
        "id": case["id"],
        "passed": not mismatches,
        "expected": expected,
        "actual": actual,
        "mismatches": mismatches,
        "returncode": completed.returncode,
        "stderr": completed.stderr,
    }


def run(args: argparse.Namespace) -> dict[str, Any]:
    source_project = resolve_project_path(args.project_path)
    case_bytes, cases = read_cases(args.cases)
    run_root = HERE / "runs"
    run_root.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(prefix="fsharp-oracle-", dir=run_root) as temp_name:
        temp_root = Path(temp_name)
        disposable = temp_root / "project"
        shutil.copytree(source_project.parent, disposable)
        project_file = disposable / source_project.name

        for folder in list(disposable.rglob("bin")) + list(disposable.rglob("obj")):
            if folder.is_dir():
                shutil.rmtree(folder)
        (disposable / "Program.fs").write_text(HOST_SOURCE.read_text(encoding="utf-8"), encoding="utf-8")

        temp_runtime = temp_root / "tmp"
        temp_runtime.mkdir()
        env = os.environ.copy()
        env["TMP"] = str(temp_runtime)
        env["TEMP"] = str(temp_runtime)
        build = subprocess.run(
            ["dotnet", "build", str(project_file), "--configuration", "Release", "--nologo", "-m:1", "-p:NuGetAudit=false"],
            text=True,
            encoding="utf-8",
            capture_output=True,
            check=False,
            env=env,
        )
        build_ok = build.returncode == 0
        results = [run_case(project_file, case, env) for case in cases] if build_ok else []

    all_cases_pass = build_ok and len(results) == len(cases) and all(result["passed"] for result in results)
    any_case_rejected = build_ok and len(results) == len(cases) and any(not result["passed"] for result in results)
    success = (any_case_rejected if args.expect_failure else all_cases_pass)
    return {
        "schema_version": 1,
        "language": "fsharp",
        "project_path": str(source_project.parent.resolve()),
        "tested_disposable_copy": True,
        "original_project_mutated": False,
        "case_sha256": hashlib.sha256(case_bytes).hexdigest(),
        "case_count": len(cases),
        "sequential_calls_per_case": 2,
        "total_target_invocations": 2 * len(cases),
        "per_call_read_write_deltas": True,
        "fresh_release_build": True,
        "build_command": ["dotnet", "build", "<project>", "--configuration", "Release", "--nologo", "-m:1", "-p:NuGetAudit=false"],
        "build_exit_code": build.returncode,
        "build_stdout_tail": "\n".join(build.stdout.splitlines()[-12:]),
        "build_stderr": build.stderr,
        "all_cases_pass": all_cases_pass,
        "expectation": "failure" if args.expect_failure else "pass",
        "cases": results,
        "result": "pass" if success else "fail",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-path", required=True, type=Path, help="directory with one .fsproj, or an .fsproj path")
    parser.add_argument("--cases", type=Path, default=CASES_PATH)
    parser.add_argument("--expect-failure", action="store_true")
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    try:
        report = run(args)
    except (OSError, ValueError, json.JSONDecodeError) as error:
        parser.error(str(error))
    if args.report:
        if args.report.exists():
            parser.error(f"report already exists; choose a new path: {args.report}")
        args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=True, indent=2))
    return 0 if report["result"] == "pass" else 1


if __name__ == "__main__":
    sys.exit(main())

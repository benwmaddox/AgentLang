# Runtime integration notes for Flow test-file overlays

## Current runtime seams

- `RuntimeSnapshot` keeps the production `VerifiedIrProgram`, compiled Flow
  test bodies, source-backed attachments, and a separate map of shared
  test-file wrappers. The wrapper map is derived during registration/reload;
  ephemeral fixture programs are created for execution and are not stored as
  the production program.
- `checkedByTest` (currently near `Runtime.fs:2492`) creates a fresh virtual filesystem
  trace, executes the test body, and separately executes any expected-value
  expression. It observes coverage against the original target identity and
  derives instruction/branch evidence from the original program.
- `interpreterHost` supplies effect preflight and filesystem provider behavior.
  Its test capability set is separate from production capabilities; the test
  provider starts empty for each case.
- `runTestsFor` selects the current test cases; publication, rename, and
  deprecation gates reuse that path, so overlay cases must be surfaced there
  with their normal owner and case identity.
- Durable reload parses the test source references from each revision. Shared
  wrapper content means those references must be parsed as complete files and
  case selection uses owner/name; wrapper cases are mapped to one shared
  source reference rather than pairing one source object with one case.

Runtime routes aggregate `FlowProjectDocument.TestFiles` separately from
ordinary production definitions and standalone attachments. It deduplicates
the wrapper's shared source reference in manifest v4, validates every nested
case on reload, compiles wrappers through
`FlowLowering.compileTestFileSettings`, and persists override proof sites with
`FlowPersistence.testOverrideBindings`. `checkedByTest` runs actual and
expectation bodies using the overlay context/program/dispatch while retaining
the production program as the original target contract. Source replacement,
rename, and nested-case removal rewrite shared wrappers as whole files.
Wrapper-only registration attaches to an already-declared Flow owner. A mixed
project transaction may include wrappers only for words declared in that same
transaction, so it cannot silently attach metadata to an existing owner at its
old revision. Each owner may have multiple wrappers, with unique scope labels.

## Runtime overlay contract

For each case selected from a test-file wrapper, compile or retrieve an
ephemeral verified program that contains the original production program plus
synthetic fixture functions. Keep the original `FunctionsById`, generated
targets, coverage obligations, definitions, and revision metadata unchanged.
Use a fresh overlay execution context per test case; do not retain it in the
runtime snapshot or dictionary after the result is recorded.

The interpreter dispatch table must key on the original resolved target
identity (including user revision) and point to a fixture's distinct synthetic
function ID. Resolve it only after the original call's effect preflight and
before original entry/return instrumentation. The original target identity
continues to drive finite input/return observation; a fixture call must not
contribute observations for the replaced target. Fixture bodies need their
own source owner and coverage identity so their execution cannot satisfy the
original target's instruction, branch, or finite-value obligations.

Run both the actual body and any executable expectation through the same case
overlay, with fresh virtual filesystem state for each expression. Preserve
existing behavior for capability denial, runtime diagnostics, and effect
assertions. Case results should report active fixture names separately from
coverage and diagnostics.

## Lowering API consumed by Runtime

The lowering layer exposes a settings compilation result tied to the
exact production `VerifiedIrProgram` and Flow context, containing:

- the compiled wrapper test cases and expectations;
- fixture target bindings from each original `IrCallTarget` (including revision)
  to a distinct synthetic fixture function ID/revision;
- verified fixture functions and their source/coverage maps, with fixture IDs
  kept out of the original target coverage evidence;
- structural, source-backed call bindings for fixture body calls, rooted at the
  wrapper/override declaration and using the distinct test-override storage
  role;
- validated original signature/effect contracts for every override.

Fixture expressions must resolve against the original dictionary signatures.
Nested calls and static callbacks should therefore compile as ordinary calls to
the original target identities; the interpreter dispatch map supplies the
case-local fixture implementation. Do not key runtime dispatch on display names.

## Durability and source edits

All cases from one wrapper refer to the same full-file source content and
reference. On reload, parse that file once (or equivalently parse the same exact
source for each case) and select each case by its owning word and case name.
Rename and case removal must rewrite the wrapper once, then refresh every case
reference and binding atomically. Diagnostic source replacements are separate
from coverage evidence. Do not insert fixture declarations into the production
source inventory or production `VerifiedIrProgram`.

`FlowTestFileSettings.ScopeName` is only a wrapper label. Select the tested
owner from its nested cases (`Tests.Head.Word`); the parser guarantees every
case has a full owner-qualified name, requires at least one case, and rejects
wrappers whose cases name different owners. Runtime must then verify that
owner is the current Flow-authored word and that wrapper syntax version matches
the owner.

The lowering result exposes one `FlowTestOverrideBindings` row per override:
`{ OverrideIndex; Header; BodySites }`. The header uses
`FlowCallForm.TestOverrideTarget`; header and fixture-body sites are represented
in `FlowBoundProjectCompilation.AttachmentBindings` with
`FlowAttachmentBodyRole.TestOverride`. Persist one stable header binding for
each override with stored role `TestOverride`, `CaseName=None`, and a structural
path rooted at `TestOverrideDefinition index`. Persist fixture-body calls with
the same stored role and `CaseName=None`, below that root. Durable bindings keep
the stable target identity; at reload Runtime must revalidate the current
target signature/effect contract and build a dispatch key with the exact current
target revision.

## Aggregate project export

`FlowProjectDocument` carries `TestFiles: FlowTestFileSettings list` beside
production declarations and standalone attachments. Each `test-file` block
remains isolated internally to its overrides and nested tests. Runtime keeps
the production word source as its ordinary definition and has `sourceFor`
append each full wrapper once, grouped by its shared source reference. It
reparses extracted wrapper `SourceText` with
`parseTestFileSettingsWithVersion` and the wrapper source-file label before
compiling, so source spans are wrapper-local. `dictionary.agent` therefore
round-trips the aggregate project without a new file extension or module
system.

## Validation and resolved findings

Runtime integration and its focused acceptance coverage are implemented in
`src/AgentLang.Core/Runtime.fs` and
`tests/AgentLang.Flow.Runtime.Tests/Program.fs`. The tests cover direct, nested,
and static-callback dispatch; fresh virtual providers after pass, failure, and
runtime error; durable source edit, rename, case removal, export, and reload;
manifest v4 with generated Stack cases; capability preflight; signature/effect
rejection; fake self-qualification rejection; real-filesystem isolation; and
task-abort restoration of the original shared wrapper source.

The header-tamper regression exposed a real reload-validation defect. Snapshot
compilation replaced a wrapper's retained `StoredBindings` with regenerated
bindings before comparing the two, which let a forged persisted
`TestOverrideTarget` stable ID validate against itself. Runtime now preserves
the loaded binding proof through `checkRetainedBinding` and refreshes it only
after that comparison succeeds. The focused negative test mutates only the
header target ID for a literal fixture with no body-call sites and verifies
that a fresh Engine rejects the manifest with
`FLOW_RUNTIME_BINDING_MISMATCH`.

The focused runtime suite completed with **36 groups and 1,329 assertions**.
The final fresh Release build reported zero warnings and zero errors. These are
the exact PowerShell commands and captured logs, run from `D:\code\AgentLang`:

```powershell
$env:TEMP='D:\code\AgentLang\.agentlang\test-file-overlays\compiler-temp'
$env:TMP=$env:TEMP
dotnet build tests/AgentLang.Flow.Runtime.Tests/AgentLang.Flow.Runtime.Tests.fsproj -c Release --no-incremental -m:1 -p:NuGetAudit=false *> .agentlang/test-file-overlays/runtime-build-root-010.log
dotnet tests/AgentLang.Flow.Runtime.Tests/bin/Release/net9.0/AgentLang.Flow.Runtime.Tests.dll *> .agentlang/test-file-overlays/runtime-tests-root-008.log
```

`runtime-build-root-010.log` records the successful Core, CLI, and Flow Runtime
test assembly build. `runtime-tests-root-008.log` records the passing runtime
test result. Earlier focused runs caught and corrected malformed Flow/2 fixture
syntax, a missing baseline test before the first commit, stale case-inventory
expectations after removal, stored fixture-call inventory assumptions, and the
formatted string-literal representation returned by `eval`; none were handled
by changing expected diagnostics or relaxing runtime gates.

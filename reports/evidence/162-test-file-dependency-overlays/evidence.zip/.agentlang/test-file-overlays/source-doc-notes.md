# Flow/2 test-file source contract

Test-file wrappers are Flow/2 declarations. A project document can mix them
with ordinary definitions and standalone tests; each wrapper remains one
separate logical source unit.

```flow
test-file settings {
    override fn file.read(path: String) -> String {
        effects fs.read
        "fixture contents"
    }

    test settings.load/enabled {
        file.read("settings.txt")
        => "fixture contents"
    }

    test settings.load/disabled {
        file.read("settings.txt")
        => "fixture contents"
    }
}
```

`settings` is the wrapper label. It is not the tested owner: the owner and case
come from each full `owner.word/case-name` test header. A wrapper needs at least
one nested test, all nested tests must name the same owner, and case names must
be unique within the wrapper. Across a project, each full owner/case key must
also be unique across standalone tests and every test-file wrapper. A project
document may reuse a label for another owner, but each owner/label pair must be
unique. One wrapper can hold multiple cases and shared replacements.

The wrapper body accepts only `override fn` declarations and nested `test`
declarations. An `override fn` uses ordinary Flow/2 function syntax, including
an explicit output signature. Its name identifies the exact dictionary target.
The replacement must preserve that target's input and output types, and its
declared and inferred effects must fit within the target's effect contract. A
wrapper can replace each target only once. Current supported targets are
authored Flow words and trusted primitives with closed signatures; generated
constructors/accessors and polymorphic primitive targets cannot be replaced.
Replacement declarations never enter the production word inventory.

Top-level `override` declarations and production definitions inside a wrapper
are invalid. Existing standalone `test owner/case { ... }` declarations remain
independent and have no shared replacements. A test-file-only registration
must target an existing Flow-authored owner; a full project may also declare
the owner in that same project document. In either case the wrapper and owner
must use Flow/2.

The complete wrapper source is retained as one durable source object shared by
all of its case attachments. Reload reselects cases by their full owner and
case names and rechecks each replacement against the current target contract.
Removing one case preserves the other cases and shared replacements; removing
the last case removes the wrapper.

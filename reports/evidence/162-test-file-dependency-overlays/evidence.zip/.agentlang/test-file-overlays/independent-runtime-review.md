# Independent Runtime integration review

Scope: read-only review of `Runtime.fs` test-file overlay compilation and execution, durable source references and call bindings, target rename handling, and test-file map restoration. No builds or Runtime edits were made.

## Findings

The initial static review did not identify a blocking defect, but the focused header-only tamper acceptance test later exposed one: the test-file source's persisted `StoredBindings` was being replaced with freshly generated bindings before retained-binding verification, so a forged override header could validate itself. The Runtime diff now keeps the source's persisted bindings through `checkRetainedBinding` at `Runtime.fs` lines 1611–1613 and refreshes `StoredBindings` only afterward at lines 1614–1618. This ordering appears to address the self-validation flaw. Root is running the Runtime validation after the fix; this review does not claim the test passes.

The execution boundary is scoped as intended: `compileRuntimeSnapshot` compiles each wrapper into a separate `TestFileOverlay`, while the snapshot's production `Program` stays the word-project program. `checkedByTest` selects the overlay only by the attached test key, builds its interpreter host against the expanded ephemeral program, and calls `executeBodyWithTestDispatch` with the original production program and exact dispatch map. Test traces use `FileSystemMode.Virtual`; ordinary evaluation continues through the normal execution path.

Durable wrapper references are grouped once per full-file source in the owner's `WordRevision.Tests` list. The `TestOverride` binding rows use the wrapper `SourceRef`, `CaseName=None`, and structural declaration paths. Recompilation compares retained header and fixture-body bindings by source/role/path and checks their target identities. Rename rewrites wrappers using those bindings and rebuilds source references. The reviewed candidate/discard/task restoration paths carry `FlowTestFiles` alongside `FlowTests` and filter/restore them by stable owner ID.

## Acceptance and remaining coverage

The new `testPersistedTestOverrideHeaderIsVerified` case forges only the persisted `TestOverrideTarget` identity on a wrapper whose fixture body has no nested call bindings, then expects fresh Engine construction to reject it with `FLOW_RUNTIME_BINDING_MISMATCH`. The test exposed the ordering flaw described above before the Runtime fix. It has not yet been rerun against that fix in this review.

The Real-mode filesystem isolation acceptance test is present in the current diff: ordinary evaluation reads a host temp file, test-file execution and publication gates leave it unchanged, and the check is repeated after reload.

Wrapper-map rollback now has a focused test, `testTestFileTaskAbortRestoresSharedSource`: it commits the original wrapper, publishes a changed wrapper within a task, aborts, verifies exact manifest authority and the original source reference/content, then runs the restored test both in the current Engine and after reload. It closes the earlier rollback coverage gap. No additional focused Runtime test gap was identified in this review; validation of the current diff remains pending, so this review does not claim these tests pass.

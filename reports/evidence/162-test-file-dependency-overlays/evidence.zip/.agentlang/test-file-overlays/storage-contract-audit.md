# Storage and reload contract audit

Static review performed on 2026-10-09, followed by coordinated focused
validation. The original review identified a v4 reload gap; the current code
and regression now close it.

## Findings

- Manifest format 4 is the highest supported manifest version. Its word-revision
  fields are emitted and parsed like v2/v3, and its type-source fields like v3.
  Snapshot and current-pointer envelope versions remain independent. Runtime
  selects v4 when a shared Flow test-file wrapper is present and keeps v1-v3
  manifests on their existing serialization paths otherwise.
- Runtime stores each wrapper as one `TestDefinition` source reference on its
  owner revision, omits wrapper-backed cases from the standalone source list,
  and retains each case's actual/expectation bindings under that shared source
  with its case name. Reload parses the full wrapper, reconstructs the owner-
  keyed case rows, and checks that every declared case has one matching
  attachment and no extra attachment.
- Override proof rows use `TestOverride`, `CaseName=None`, and the shared
  `TestDefinition` source. Header rows use `TestOverrideTarget` at exactly
  `[TestOverrideDefinition i]`; fixture-body rows use ordinary call forms below
  exactly one such root. Storage rejects wrong source membership/kind, case
  names on override rows, these roles/forms in v1-v3, header/body path-shape
  mismatches, and override path segments under ordinary roles. The persistence
  adapter emits stable target identities only; active target revisions remain
  transient in the compiler/runtime dispatch map.
- Runtime's retained-binding oracle keys rows by source, case, role, and path,
  then compares the complete binding records, including form, requested name,
  and stable target. The loader recompiles wrappers against the active
  dictionary; the lowerer validates the current target signature/effects and
  creates dispatch keys from exact current `IrCallTarget` identities.
- Existing storage tests still exercise v1, v2, and v3 fixtures and schema
  shapes. The new v4 storage test covers round-trip source sharing, v3-shaped
  revision/type fields, deterministic binding order, and writer/reader
  rejection for malformed version, source, case-name, role, form, and path
  combinations. The runtime acceptance scenario covers shared references,
  reload, override-header rename, case removal, and a second wrapper.

## Reload-version follow-up closed

The initial static review found that `generatedProjectCases` recovered cases
from aggregate project exports only for manifest versions 1, 2, and 3. That
would omit generated-type Stack cases from a v4 manifest containing a Flow
test-file wrapper. Runtime now includes v4 in the recovery guard, and the
focused Runtime suite passes its generated-case reload regression.

## Validation

The coordinated fresh Storage Release build passed with 0 warnings and 0
errors; its test DLL passed 16 groups and 446 assertions. The coordinated fresh
Runtime Release build passed with 0 warnings and 0 errors; its test DLL passed
36 groups and 1,329 assertions, including v4 generated-case reload, override
header-tamper, and abort coverage. Results are recorded in
`.agentlang/test-file-overlays/storage-build-root-003.log`,
`storage-tests-root-001.log`, `runtime-build-root-010.log`, and
`runtime-tests-root-008.log`. The static-review phase also passed
`git diff --check`; builds and test runs were performed later by the root agent.

from pathlib import Path
import json, subprocess, hashlib
repo = Path(__file__).resolve().parents[2]
root = repo / '.agentlang/test-file-overlays/documented-example-project'
root.mkdir(parents=True, exist_ok=False)
(root / 'enabled.txt').write_text('off', encoding='utf-8')
cli = repo / 'src/AgentLang.Cli/bin/Release/net9.0/AgentLang.Cli.dll'
source = (repo / 'examples/test-file-settings.agent').read_text(encoding='utf-8')
requests = [
 {'op':'define','frontend':'flow','syntaxVersion':2,'source':source},
 {'op':'test','word':'settings.load'},
 {'op':'commit','word':'settings.load','library':True},
 {'op':'eval','frontend':'flow','syntaxVersion':2,'code':'settings.load("enabled.txt")'},
 {'op':'eval','frontend':'flow','syntaxVersion':2,'code':'file.write("enabled.txt", "on")'},
 {'op':'eval','frontend':'flow','syntaxVersion':2,'code':'settings.load("enabled.txt")'},
 {'op':'test','word':'settings.load'}
]
command = ['dotnet', str(cli), '--project', str(root), '--jsonl', '--allow','fs.read,fs.write']
def run(reqs):
 p = subprocess.run(command, input=''.join(json.dumps(r)+'\n' for r in reqs), text=True, capture_output=True)
 rows = [json.loads(line) for line in p.stdout.splitlines() if line.strip()]
 assert p.returncode == 0, p.stderr
 assert len(rows)==len(reqs), (rows,p.stderr)
 assert all(row.get('ok') for row in rows), rows
 return rows,p.stderr
rows,stderr=run(requests)
for index in (1,6):
 results=rows[index]['data']['results']
 assert len(results)==2 and all(r['passed'] and r['activeOverrides']==['file.read'] for r in results), results
assert rows[3]['data']['stack']==['false'], rows[3]
assert rows[5]['data']['stack']==['true'], rows[5]
assert (root/'enabled.txt').read_text()=='on'
assert not (root/'disabled.txt').exists()
reload_requests=[requests[1], requests[3]]
reload_rows,reload_stderr=run(reload_requests)
assert all(r['passed'] for r in reload_rows[0]['data']['results'])
assert reload_rows[1]['data']['stack']==['true']
assert (root/'enabled.txt').read_text()=='on'
report={'status':'pass','command':command,'sourceSha256':hashlib.sha256(source.encode()).hexdigest(), 'requests':requests,'responses':rows,'stderr':stderr,'reloadRequests':reload_requests,'reloadResponses':reload_rows,'reloadStderr':reload_stderr,'hostFileAfterTests':'on','missingFixtureFileRemainsMissing':True}
(repo/'.agentlang/test-file-overlays/documented-example-result.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print('Documented example passes: real read/write, fixture-only tests, library commit, fresh-session reload, host state preserved.')

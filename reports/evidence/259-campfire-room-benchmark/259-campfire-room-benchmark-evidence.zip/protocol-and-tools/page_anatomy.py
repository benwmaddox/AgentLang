#!/usr/bin/env python3
"""Byte anatomy of a captured room page (run privately; prints only aggregate sizes and tag names)."""
import re, sys
from collections import Counter
text = open(sys.argv[1], encoding="utf-8").read()
total = len(text.encode())
print("total_bytes", total)
def size(pattern, flags=re.S):
    return sum(len(m.group(0).encode()) for m in re.finditer(pattern, text, flags))
parts = {
    "inline <svg>": size(r"<svg\b.*?</svg>"),
    "<script> blocks": size(r"<script\b.*?</script>"),
    "<style> blocks": size(r"<style\b.*?</style>"),
    "<template> blocks": size(r"<template\b.*?</template>"),
    "data: URIs": size(r"data:[a-z]+/[a-z0-9.+-]+;base64,[A-Za-z0-9+/=]+"),
    "<head>": size(r"<head\b.*?</head>"),
    "#messages region": size(r'<div[^>]*id="messages[^"]*".*?(?=<footer|<form[^>]*composer|$)'),
    "<nav>/sidebar": size(r"<nav\b.*?</nav>"),
}
for k, v in parts.items():
    print(f"{k:24} {v:8} ({100*v/total:5.1f}%)  [overlapping]")
msgs = re.findall(r'<div\b[^>]*\sdata-message-id="\d+"', text)
print("messages", len(msgs))
tags = Counter(re.findall(r"<([a-zA-Z][a-zA-Z0-9-]*)", text))
print("top tags", tags.most_common(15))
svg_ids = Counter(re.findall(r'<svg\b[^>]*?(?:class|aria-label)="([^"]{0,40})', text))
print("svg classes", svg_ids.most_common(8))

#requires -Version 7.0
# Counted report-259 sets in the pre-registered order N R S S R N, twice. Stops on the first failure.
param([Parameter(Mandatory)][string]$Snapshot, [ValidateSet("on","off")][string]$Cache = "on", [string]$Prefix = "set")
$ErrorActionPreference = 'Stop'
$w = $PSScriptRoot
$pwsh = (Get-Process -Id $PID).Path
$order = @('native', 'rails', 'rust', 'rust', 'rails', 'native')
foreach ($set in 1, 2) {
  for ($i = 0; $i -lt $order.Count; $i++) {
    $server = $order[$i]
    $run = "$Prefix$set-$($i + 1)-$server"
    "=== $run $([DateTime]::UtcNow.ToString('O'))"
    if ($server -eq 'native') {
      & $pwsh -NoProfile -File (Join-Path $w 'Native-Lifetime.ps1') -RunName $run -Snapshot $Snapshot
    } else {
      wsl -d Ubuntu -- bash -c "CACHE=$Cache bash /mnt/d/code/AgentLang/.agentlang/campfire-matched-258/ref-lifetime.sh $server $run"
    }
    if ($LASTEXITCODE -ne 0) { throw "lifetime failed: $run" }
  }
}
"=== done $([DateTime]::UtcNow.ToString('O'))"

#!/usr/bin/env python3
"""Print the tag/class skeleton of one rendered message (no text, no attribute values except class/data keys)."""
import re, sys
text = open(sys.argv[1], encoding="utf-8").read()
starts = [m.start() for m in re.finditer(r'<div\b[^>]*\sdata-message-id="\d+"', text)]
index = int(sys.argv[2]) if len(sys.argv) > 2 else 5
seg = text[starts[index]:starts[index + 1]]
print("message_bytes", len(seg.encode()))
depth = 0
for m in re.finditer(r"<(/?)([a-zA-Z][\w-]*)([^>]*)>", seg):
    closing, tag, attrs = m.groups()
    if closing:
        depth = max(0, depth - 1); continue
    cls = re.search(r'class="([^"]*)"', attrs)
    keys = sorted(set(re.findall(r'\s(data-[\w-]+|action|method|name|type|href|src)=', attrs)))
    print("  " * min(depth, 12) + f"<{tag}" + (f" .{cls.group(1)[:60]}" if cls else "") + (f" {keys}" if keys else ""))
    if tag not in ("img", "input", "br", "hr", "meta", "link", "source"):
        depth += 1

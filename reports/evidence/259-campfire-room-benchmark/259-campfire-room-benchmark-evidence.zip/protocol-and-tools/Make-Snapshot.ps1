#requires -Version 7.0
# Rails-login snapshot for native rounds: start Rails on 13774, log in, stop, checkpoint DB copy.
param([Parameter(Mandatory)][ValidatePattern('^[a-z0-9-]{1,32}$')][string]$Name)
$ErrorActionPreference = 'Stop'
$w = $PSScriptRoot
wsl -d Ubuntu -- bash /mnt/d/code/AgentLang/.agentlang/campfire-matched-258/start-rails.sh $Name
if ($LASTEXITCODE -ne 0) { throw 'Rails start failed.' }
try {
  $labels = Get-Content (Join-Path $w '../once-campfire-verification/fixtures/default/labels.json') -Raw | ConvertFrom-Json
  $login = & (Join-Path $w 'loadgen-target/release/loadgen.exe') login --base http://127.0.0.1:13774 --email $labels.'emails.david' --password $labels.'passwords.all' | ConvertFrom-Json
  [IO.File]::WriteAllText((Join-Path $w "private/rails-cookie-$Name.txt"), $login.cookie)
} finally {
  wsl -d Ubuntu -- bash /mnt/d/code/AgentLang/.agentlang/campfire-matched-258/stop-rails.sh $Name
}
wsl -d Ubuntu -- bash /mnt/d/code/AgentLang/.agentlang/campfire-matched-258/copy-db.sh $Name
if ($LASTEXITCODE -ne 0) { throw 'DB copy failed.' }
"snapshot=$Name utc=$([DateTime]::UtcNow.ToString('O'))"

#requires -Version 7.0
# One AOT native host lifetime for report 259 (protocol: benchmark-protocol-259.md).
param(
  [Parameter(Mandatory)][ValidatePattern('^[a-z0-9-]{1,40}$')][string]$RunName,
  [Parameter(Mandatory)][string]$Snapshot
)
$ErrorActionPreference = 'Stop'
$w = $PSScriptRoot
$build = Join-Path $w '../campfire-native-profile-256/http-host/build-trusted-generated-20261013T110751812Z-b49cceee376c4340bf460951cfe8ffae/O2'
$out = Join-Path $w "bench-259/$RunName"
$priv = Join-Path $w "private/native-db-$RunName"
if ((Test-Path -LiteralPath $out) -or (Test-Path -LiteralPath $priv)) { throw 'Run roots are immutable.' }
$null = New-Item -ItemType Directory -Path $out, $priv -Force
function Note([string]$t) { "$([DateTime]::UtcNow.ToString('O')) $t" | Add-Content -LiteralPath (Join-Path $out 'driver.log') -Encoding utf8NoBOM; Write-Output $t }
if (Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object LocalPort -in 13773, 13774) { throw 'Port 13773/13774 busy.' }

$labels = Get-Content (Join-Path $w '../once-campfire-verification/fixtures/default/labels.json') -Raw | ConvertFrom-Json
$room = $labels.'rooms.watercooler'
$cookie = [IO.File]::ReadAllText((Join-Path $w "private/rails-cookie-$Snapshot.txt"))
Copy-Item -LiteralPath (Join-Path $w "private/native-db-$Snapshot/production.sqlite3") -Destination (Join-Path $priv 'production.sqlite3')
$db = Join-Path $priv 'production.sqlite3'
$lg = Join-Path $w 'loadgen-target/release/loadgen.exe'
$contract = Join-Path $w 'contracts-preflight-1/room_show.json'
$stopName = 'Local\CampfireMatched259Stop'
$serverMask = [IntPtr]0x5401
$clientMask = [IntPtr]0x3F03FC
Get-Process | Select-Object Id, ProcessName | Sort-Object Id | ConvertTo-Json | Set-Content (Join-Path $out 'processes-before.json') -Encoding utf8NoBOM

function Invoke-Loadgen([string]$Tag, [string[]]$Arguments) {
  $psi = [Diagnostics.ProcessStartInfo]::new($lg)
  $psi.UseShellExecute = $false; $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true
  foreach ($a in $Arguments) { [void]$psi.ArgumentList.Add($a) }
  $proc = [Diagnostics.Process]::Start($psi)
  $proc.ProcessorAffinity = $clientMask   # applies to all threads of the process
  $stdout = $proc.StandardOutput.ReadToEndAsync(); $stderr = $proc.StandardError.ReadToEndAsync()
  $proc.WaitForExit()
  $result = [ordered]@{ exit = $proc.ExitCode; clientCpuMs = $proc.TotalProcessorTime.TotalMilliseconds; affinity = [int64]$clientMask }
  $stderr.GetAwaiter().GetResult() | Set-Content (Join-Path $out "loadgen-$Tag.err.log") -Encoding utf8NoBOM
  $text = $stdout.GetAwaiter().GetResult()
  $proc.Dispose()
  return @($text, $result)
}

$hostArgs = @('--module', (Join-Path $build 'owning-stack-native-host.dll'), '--manifest', (Join-Path $build 'owning-stack-native-host-manifest.json'),
              '--db', $db, '--secret-file', (Join-Path $w 'private/secret-key-base.txt'), '--port', '13773', '--workers', '4', '--stop-event', $stopName)
$hostLog = Join-Path $out 'native-host.log'
$hostProc = Start-Process -FilePath (Join-Path $build 'native_http_host.exe') -ArgumentList $hostArgs -PassThru -NoNewWindow `
  -RedirectStandardOutput $hostLog -RedirectStandardError (Join-Path $out 'native-host.stderr.log')
$null = $hostProc.Handle
$hostProc.ProcessorAffinity = $serverMask
try {
  $deadline = [DateTime]::UtcNow.AddSeconds(60)
  while ([DateTime]::UtcNow -lt $deadline -and -not $hostProc.HasExited -and -not ((Test-Path $hostLog) -and (Select-String -LiteralPath $hostLog -Pattern '^READY ' -Quiet))) { Start-Sleep -Milliseconds 200 }
  if (-not (Select-String -LiteralPath $hostLog -Pattern '^READY ' -Quiet)) { throw 'native host not READY' }
  Note "ready pid=$($hostProc.Id) serverAffinity=$([int64]$hostProc.ProcessorAffinity)"
  $base = @('--base', 'http://127.0.0.1:13773', '--cookie', $cookie)
  $hashes = foreach ($n in 1, 2) {
    $file = Join-Path $priv "body$n.html"
    $null = Invoke-Loadgen "fetch$n" (@('fetch') + $base + @('--path', "/rooms/$room", '--out', $file))
    (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash
  }
  Note "decoded_bytes=$((Get-Item (Join-Path $priv 'body1.html')).Length) body_constant=$(if ($hashes[0] -eq $hashes[1]) {'yes'} else {'no'})"
  $common = @('--path', "/rooms/$room", '--validate', $contract)
  $warm = Invoke-Loadgen 'warm0' (@('http') + $base + $common + @('--conc', '4', '--duration', '2', '--gzip', '0'))
  $warm[0] | Set-Content (Join-Path $out 'warmup-gzip0.json') -Encoding utf8NoBOM
  $hostProc.Refresh(); $s0 = $hostProc.TotalProcessorTime.TotalMilliseconds
  $timed = Invoke-Loadgen 'timed0' (@('http') + $base + $common + @('--conc', '16', '--duration', '8', '--gzip', '0'))
  $hostProc.Refresh(); $s1 = $hostProc.TotalProcessorTime.TotalMilliseconds
  $timed[0] | Set-Content (Join-Path $out 'timed-gzip0.json') -Encoding utf8NoBOM
  [ordered]@{ serverCpuMs = $s1 - $s0; serverAffinity = [int64]$serverMask; client = $timed[1] } | ConvertTo-Json | Set-Content (Join-Path $out 'cpu-gzip0.json') -Encoding utf8NoBOM
  Note "gzip=0 $($timed[0]) server_cpu_ms=$([math]::Round($s1 - $s0)) client_cpu_ms=$([math]::Round($timed[1].clientCpuMs)) loadgen_exit=$($timed[1].exit)"
} finally {
  try { $e = [Threading.EventWaitHandle]::OpenExisting($stopName); [void]$e.Set(); $e.Dispose() } catch { Note "stop event unavailable: $($_.Exception.Message)" }
  if (-not $hostProc.WaitForExit(60000)) { Note 'native host did not exit' } else { $hostProc.WaitForExit(); Note "native exit=$($hostProc.ExitCode)" }
  Get-Process | Select-Object Id, ProcessName | Sort-Object Id | ConvertTo-Json | Set-Content (Join-Path $out 'processes-after.json') -Encoding utf8NoBOM
}
$check = & python -c "import sqlite3,sys; a=sqlite3.connect('file:'+sys.argv[1]+'?mode=ro',uri=True); b=sqlite3.connect('file:'+sys.argv[2]+'?mode=ro',uri=True); q='select id,last_active_at,updated_at from sessions order by id'; print('sessions_unchanged=' + str(a.execute(q).fetchall()==b.execute(q).fetchall()))" $db (Join-Path $w "private/native-db-$Snapshot/production.sqlite3")
Note $check

#!/usr/bin/env python3
"""Seal report-259 room benchmark evidence (fail closed, immutable output)."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
import sys
import zipfile

REPO = Path(__file__).resolve().parents[2]
A = REPO / ".agentlang"
P256 = A / "campfire-native-profile-256"
HERE = A / "campfire-native-markup-257"
OUT = REPO / "reports" / "evidence" / "259-campfire-room-benchmark"
M = A / "campfire-matched-258"
BANNED = re.compile(r"(?i)(\.sqlite3?(-wal|-shm|-journal)?$|\.db3?$|config\.json$|secret|private-request|private-measure|\.env$|labels\.json$|rails-cookie|cookie\.txt$|other-containers|body\d|\.html$|\.tmp$|^container\.log$)")
COOKIE = re.compile(rb"(?im)(_campfire_session|session_token)=[A-Za-z0-9%+/=_-]{16,}|^\s*cookie\s*:")
BUILD = "build-trusted-generated-20261013T105302342Z-32b1586745dd427a95e5318fa46e2727"
GATE = A / "campfire-native-room-read-252" / "test-runs" / "20261013T105032097Z-748dbc78586d47b2a814a835b61a31b2"
HTTP_TESTS = A / "campfire-logout-245" / "http-tests" / "runs" / "20261013T105611296Z-4d5bf0cf795a4df0b3023bd125ad24b1"
SOURCES = ["applications/campfire/Http/ResponseRenderer.fs", "applications/campfire/Native/http/campfire_http_renderer.c",
           "tests/AgentLang.Campfire.Http.Tests/Program.fs", "scripts/Build-CampfireNativeHttp.ps1"]


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def collect() -> list[tuple[Path, str]]:
    items: list[tuple[Path, str]] = []
    B = M / "bench-259"
    for run in sorted(p for p in B.iterdir() if p.is_dir()):
        for f in sorted(p for p in run.iterdir() if p.is_file()):
            if BANNED.search(f.name):
                continue
            items.append((f, f"runs/{run.name}/{f.name}"))
    for name in ("benchmark-protocol-259.md", "analysis-259-cached.json", "analysis-259-nocache.json", "aggregate_259.py",
                 "ref-lifetime.sh", "Native-Lifetime.ps1", "Run-Sets.ps1", "Make-Snapshot.ps1", "stop-rails.sh", "start-rails.sh",
                 "copy-db.sh", "no-cache-initializer.rb", "build-rust.sh", "build-loadgen-linux.sh", "init-sub.sh",
                 "page_anatomy.py", "message_skeleton.py", "rust-image-build.log", "loadgen-linux-build.log",
                 "contract-hashes.json", "seal_259.py"):
        items.append((M / name, f"protocol-and-tools/{name}"))
    items.append((A / "campfire-matched-258-loadgen-build.log", "loadgen/windows-build.log"))
    items.append((A / "once-campfire-verification" / "fixtures" / "default" / "source.json", "seed/source.json"))
    return items


def main() -> int:
    if OUT.exists():
        raise SystemExit(f"immutable output exists: {OUT}")
    entries = []
    blobs = {}
    for path, arc in collect():
        if not path.is_file():
            raise SystemExit(f"missing evidence input: {path}")
        if BANNED.search(path.name) or BANNED.search(arc):
            raise SystemExit(f"refused sensitive path: {arc}")
        data = path.read_bytes()
        if COOKIE.search(data):
            raise SystemExit(f"refused possible credential content: {arc}")
        blobs[arc] = data
        entries.append({"archivePath": arc, "sourcePath": path.relative_to(REPO).as_posix(), "sha256": sha(data), "sizeBytes": len(data)})
    embedded = (json.dumps({"format": "campfire-room-benchmark-evidence-v1", "report": "259", "entries": entries,
                            "excluded": ["fixture and seed databases", "secret_key_base and credentials env", "Rails-issued cookies", "seed labels (contain fixture passwords)"]}, indent=2) + "\n").encode()
    OUT.mkdir(parents=True)
    archive = OUT / "259-campfire-room-benchmark-evidence.zip"
    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for arc in sorted(blobs):
            zf.writestr(arc, blobs[arc])
        zf.writestr("evidence-manifest.json", embedded)
    with zipfile.ZipFile(archive) as zf:
        names = set(zf.namelist())
        if names != set(blobs) | {"evidence-manifest.json"}:
            raise SystemExit("archive members differ from collection")
        for row in entries:
            if sha(zf.read(row["archivePath"])) != row["sha256"]:
                raise SystemExit(f"checksum mismatch: {row['archivePath']}")
    manifest = {"archiveFile": archive.name, "archiveSha256": sha(archive.read_bytes()), "archiveSizeBytes": archive.stat().st_size,
                "entryCount": len(entries) + 1, "entries": entries}
    (OUT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({k: manifest[k] for k in ("archiveSha256", "archiveSizeBytes", "entryCount")}))
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Report-259 matched room-page benchmark protocol (written before any timed run)

Written 2026-10-13 before the first timed sample. Subjects: the LLVM AOT native host
(release build `build-trusted-generated-20261013T110751812Z-b49cceee…`, O2,
TrustedGenerated, stage profiling off, 4 workers), the Rails reference
(`once-campfire-verification:reference-90b3300`), and the Rust reference
(`once-campfire-rust:app` from `6dae2fd`). The interpreter is not benchmarked.

## Workload

- Route: `GET /rooms/<watercooler>` from the shared harness seed (`a1553708…`).
- Authentication: a Rails-issued session for `emails.david`. The references log
  in once per server lifetime, following the harness pattern. Native rounds use a
  fresh copy of one Rails-login snapshot database, taken less than one hour
  before its last native round.
- Every response is validated by harness loadgen `--validate room_show.json`
  (`route-contract-v1`), using the Rails-derived contract for every server.
  - The Rust lifetimes' own `contracts.rb` output must match its `message_ids`
    and `message_content` exactly, or the run aborts.
  - If `contracts.rb` cannot complete for Rust because of an unrelated route,
    its `room_show.json` is compared the same way.
- Harness timings: warmup 2 s at 4 clients, then a timed 8 s run at 16 clients.
  Primary runs use `--gzip 0` for every server. A secondary run that offers gzip
  is made for each reference lifetime. Native does not compress, so it has no
  secondary run.
- Harness reference environment, used verbatim: `WEB_CONCURRENCY=3`,
  `JOB_CONCURRENCY=3`, `RAILS_MAX_THREADS=5`, `RAILS_LOG_LEVEL=warn`, plus the
  seed's `reference.env`. Push/webhook endpoints are neutralized as in
  `compare.rb`.

## Placement and CPU accounting

- **Native (Windows):** server pinned to mask `0x5401` (four distinct physical
  cores). The Windows loadgen build gets mask `0x3F03FC`, which excludes those
  cores and their SMT siblings. Server and client process CPU are measured as
  deltas across the timed command only.
- **References (WSL2 VM, Docker):** server container `--cpuset-cpus 8-11`. The
  Linux loadgen (same source and `Cargo.lock`, built in `rust:1.98.1`) runs in a
  container with `--network container:<server>` and `--cpuset-cpus 12-15`,
  targeting 127.0.0.1:13774 inside the server's network namespace: no proxy hop
  and no host listener. Server and client CPU come from cgroup v2 `cpu.stat`
  `usage_usec` deltas.
- **These budgets are not equal.** VM vCPUs are scheduled by Hyper-V anywhere on
  the host, while native gets four physical P-cores. Kernel network work is
  outside process and cgroup CPU on both sides. Results are reported with CPU
  per request, never as a CPU-normalized speedup.
- Only one server runs at a time, with compilers and other benchmark processes
  stopped. The user's unrelated `freestore-db-1` container stays running; its CPU
  is sampled before and after each reference lifetime.

## Order and rounds

Two balanced sets: `N R S S R N`, then `N R S S R N`, where N = native,
R = Rails and S = Rust. That gives 4 lifetimes per server. Each lifetime gets
fresh storage.

## Acceptance and reporting rules

- Any invalid response, any error, or a non-200 status aborts that sample. Failed
  samples are retained and reported.
- A sample is flagged (kept and reported) if client CPU exceeds 75% of its
  4-CPU budget or server CPU falls below 70% of its budget.
- Report throughput per sample and the per-server median, plus p50/p99,
  decoded and wire bytes, server and client CPU per request, and the run-to-run
  spread. Differences within one server's own spread, or within 5%, are not
  claimed.
- No headline speed ratio is quoted. The pages differ in weight (the native page
  lacks Rails' layout, avatars and actions) and the platforms differ (Windows
  HTTP.sys vs Linux containers in a VM). Both are stated beside every number.
- Body variability is recorded: whether each server's body changes per request
  (loadgen caches up to 8 identical valid bodies, so a constant page is validated
  more cheaply).

## Shakedown (declared before running it)

One lifetime per server named `shake-*` runs first, only to exercise the drivers.
Shakedown samples are retained but excluded from every table and median. Driver
fixes after shakedown are recorded; the counted sets start afterwards with
unchanged drivers.

## Amendment after collection (user direction)

The user's unrelated `freestore-db-1` (Postgres) must not be part of this test. It
was never connected to: all three servers use SQLite, and the benchmark containers
ran on Docker's default bridge, not its `freestore_default` network. The only
contact was a read-only `docker stats` listing. That sampling is removed from the
driver, and the `other-containers-*.txt` files are excluded from sealed evidence.

## Exploratory addition (declared after the counted results)

The Rust reference has a completed-response cache (`CAMPFIRE_RESPONSE_CACHE_MB`,
64 MB default) for authenticated room pages; the native host has no cache. Two
extra Rust lifetimes run with `CAMPFIRE_RESPONSE_CACHE_MB=0`; the Rails-parity
fragment cache is unchanged. They are labelled exploratory, are not part of the
counted sets, and use the same driver and rules.

## Correction: misconfigured exploratory runs

`explore-rust-nocache-1/2` ran with Rust's caches **on**: the driver edit that was
meant to pass `CAMPFIRE_RESPONSE_CACHE_MB=0` failed (a `sed` syntax error) and
was not applied. Their ready lines show no extra environment. They are retained,
labelled misconfigured, and excluded from all results.

## Amendment: no-cache comparison is primary (user direction, before any no-cache sample)

The user asked that no server use caching in the comparison. Server-side caches
found by source inspection:

- **AgentLang native:** none (`cache=per-response-nocache`; HTTP.sys response
  cache disabled).
- **Rust:** a completed-response cache (`CAMPFIRE_RESPONSE_CACHE_MB`, 64 MB) and
  a fragment cache (`CAMPFIRE_FRAGMENT_CACHE_MB`, 32 MB). Setting both to 0
  disables them: the response store has `enabled: capacity != 0`, and the
  fragment store refuses entries larger than a quarter of its limit.
- **Rails:** view fragment and collection caching (`perform_caching = true`,
  `redis_cache_store`), hard-coded with no environment switch. A read-only
  mounted benchmark initializer sets `perform_caching = false`; the image is
  unchanged. Verification: the in-container Redis key count is recorded before
  warmup and after the timed runs.

Retained in every server, because they are database-engine behaviour rather than
response caching: SQLite's page cache, prepared-statement reuse and the OS file
cache. Not server-side: the loadgen client skips re-validating byte-identical
bodies (up to 8). That affects client CPU only and is reported.

The no-cache comparison uses the same drivers, contract, rules and order
(`N R S S R N` twice, run names `nc-set*`), with `CACHE=off` for the references.
It begins with one no-cache shakedown per reference. A fresh Rails-login snapshot
is taken for the native rounds. The earlier cached sets stay as a labelled
secondary result ("references with default caching").
- Post-shakedown driver fix: the Redis key check runs only for Rails (the Rust image has no Redis).

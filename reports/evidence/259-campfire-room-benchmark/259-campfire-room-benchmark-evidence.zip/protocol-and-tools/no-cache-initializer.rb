# Benchmark-only (AgentLang report 259 no-cache comparison): disable view fragment and
# collection caching so every request renders. Mounted read-only; the image is unchanged.
Rails.application.config.action_controller.perform_caching = false
ActiveSupport.on_load(:action_controller) { self.perform_caching = false }

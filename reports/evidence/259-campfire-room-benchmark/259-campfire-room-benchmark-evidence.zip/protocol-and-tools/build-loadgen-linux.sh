set -eu
O=$HOME/cm258/loadgen-linux
mkdir -p "$O"
docker run --rm -v /mnt/d/code/AgentLang/.agentlang/once-campfire-verification:/src:ro -v "$O:/out" -w /src docker.io/library/rust:1.98.1 \
  cargo build --release --locked --manifest-path loadgen/Cargo.toml --target-dir /out > /tmp/loadgen-linux-build.log 2>&1 && rc=0 || rc=$?
echo "build-exit=$rc" >> /tmp/loadgen-linux-build.log
cp /tmp/loadgen-linux-build.log /mnt/d/code/AgentLang/.agentlang/campfire-matched-258/loadgen-linux-build.log
tail -3 /tmp/loadgen-linux-build.log; sha256sum "$O/release/loadgen" 2>/dev/null || true
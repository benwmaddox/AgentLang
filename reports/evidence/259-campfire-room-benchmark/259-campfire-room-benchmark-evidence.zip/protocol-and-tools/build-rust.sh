set -eu
R=$HOME/cm258/campfire-rust-src
if [ ! -d "$R/.git" ]; then git clone -q /mnt/d/code/AgentLang/.agentlang/campfire-reference "$R"; fi
git -C "$R" checkout -q --detach 6dae2fd3c1a2dce61ca11beb731bcce2b42b67ad
git -C "$R" rev-parse HEAD
export DOCKER_BUILDKIT=1
if docker build -t once-campfire-rust:app "$R" > /tmp/rust-image-build.log 2>&1; then rc=0; else rc=$?; fi
echo "build-exit=$rc" >> /tmp/rust-image-build.log
cp /tmp/rust-image-build.log /mnt/d/code/AgentLang/.agentlang/campfire-matched-258/rust-image-build.log
tail -4 /tmp/rust-image-build.log
docker image inspect -f '{{.Id}}' once-campfire-rust:app 2>/dev/null || true
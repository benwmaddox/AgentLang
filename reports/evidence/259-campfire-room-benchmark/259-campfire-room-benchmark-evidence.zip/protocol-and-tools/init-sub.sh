set -eu
R=$HOME/cm258/campfire-rust-src
name=$(git -C "$R" config -f .gitmodules --get-regexp '^submodule\..*\.path$' | awk '$2=="reference"{print $1}' | sed 's/^submodule\.//; s/\.path$//')
git -C "$R" config "submodule.$name.url" /mnt/d/code/AgentLang/.agentlang/campfire-reference/reference
git -C "$R" -c protocol.file.allow=always submodule update --init -q reference
git -C "$R/reference" rev-parse HEAD
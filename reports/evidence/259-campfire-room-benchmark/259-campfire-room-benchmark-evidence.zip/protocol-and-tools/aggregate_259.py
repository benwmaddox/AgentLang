#!/usr/bin/env python3
"""Aggregate counted report-259 lifetimes (bench-259/set*) under benchmark-protocol-259.md rules."""
import json, re, statistics, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent / "bench-259"
PREFIX = sys.argv[1] if len(sys.argv) > 1 else "set"
OUTNAME = sys.argv[2] if len(sys.argv) > 2 else "analysis-259.json"
BUDGET = 4.0
rows = []
for run in sorted(p for p in ROOT.iterdir() if p.is_dir() and re.match(PREFIX + r"\d", p.name)):
    server = run.name.split("-")[-1]
    for gzip in (0, 1):
        f = run / f"timed-gzip{gzip}.json"
        if not f.exists():
            continue
        r = json.loads(f.read_text(encoding="utf-8-sig"))
        secs = r["secs"]
        if server == "native":
            cpu = json.loads((run / "cpu-gzip0.json").read_text(encoding="utf-8-sig"))
            server_cores = cpu["serverCpuMs"] / 1000 / secs
            client_cores = cpu["client"]["clientCpuMs"] / 1000 / secs
        else:
            server_cores = int((run / f"server-cpu-gzip{gzip}.txt").read_text().split("=")[1]) / 1e6 / secs
            stat = (run / f"client-cpu-timed{gzip}.txt").read_text()
            client_cores = int(re.search(r"usage_usec (\d+)", stat).group(1)) / 1e6 / secs
        log = (run / "driver.log").read_text(encoding="utf-8-sig")
        decoded = int(re.search(r"decoded_bytes=(\d+)", log).group(1))
        constant = re.search(r"body_constant=(\w+)", log).group(1)
        ok = r["invalid_responses"] == 0 and r["errors"] == 0 and set(r["statuses"]) == {"200"}
        flags = []
        if not ok: flags.append("INVALID")
        if client_cores > 0.75 * BUDGET: flags.append("client-bound")
        if server_cores < 0.70 * BUDGET: flags.append("server-unsaturated")
        rows.append(dict(run=run.name, server=server, gzip=gzip, rps=r["rps"], p50=r["latency"]["p50_ms"], p99=r["latency"]["p99_ms"],
                         decoded=decoded, wire=r["avg_bytes"], constant=constant, server_cores=round(server_cores, 2),
                         client_cores=round(client_cores, 2), server_cpu_us_per_req=round(server_cores * 1e6 / r["rps"], 1),
                         ok=ok, flags=flags))
summary = {}
for key in sorted({(r["server"], r["gzip"]) for r in rows}):
    sel = [r for r in rows if (r["server"], r["gzip"]) == key]
    clean = [r for r in sel if not r["flags"]]
    rps = [r["rps"] for r in sel]
    summary[f"{key[0]}-gzip{key[1]}"] = dict(
        samples=len(sel), unflagged=len(clean), median_rps=statistics.median(rps), min_rps=min(rps), max_rps=max(rps),
        spread_pct=round(100 * (max(rps) - min(rps)) / statistics.median(rps), 1),
        median_p99_ms=statistics.median(r["p99"] for r in sel), decoded_bytes=sel[0]["decoded"], wire_bytes=sel[0]["wire"],
        body_constant=sel[0]["constant"], median_server_cores=statistics.median(r["server_cores"] for r in sel),
        median_client_cores=statistics.median(r["client_cores"] for r in sel),
        median_server_cpu_us_per_req=statistics.median(r["server_cpu_us_per_req"] for r in sel),
        flags=sorted({f for r in sel for f in r["flags"]}))
out = dict(rows=rows, summary=summary)
(ROOT.parent / OUTNAME).write_text(json.dumps(out, indent=2) + "\n", encoding="utf-8")
for k, v in summary.items():
    print(k, json.dumps(v))
if any(not r["ok"] for r in rows):
    sys.exit(1)

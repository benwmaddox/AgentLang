set -eu
docker stop -t 30 cm258-rails > /dev/null
docker logs cm258-rails > "$HOME/cm258/$1/logs/container.log" 2>&1
docker rm cm258-rails > /dev/null

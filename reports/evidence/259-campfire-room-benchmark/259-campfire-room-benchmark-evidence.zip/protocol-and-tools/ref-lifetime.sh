set -euo pipefail
APP=$1; RUN=$2
H=/mnt/d/code/AgentLang/.agentlang/once-campfire-verification
M=/mnt/d/code/AgentLang/.agentlang/campfire-matched-258
OUT=$M/bench-259/$RUN; W=$HOME/cm259/$RUN; P=$HOME/cm259/private/$RUN
case "$APP" in rails) IMAGE=once-campfire-verification:reference-90b3300;; rust) IMAGE=once-campfire-rust:app;; *) exit 2;; esac
test ! -e "$OUT" && test ! -e "$W" || { echo "immutable run exists"; exit 2; }
if docker ps -a --format '{{.Names}}' | grep -qx cm259-srv; then echo "cm259-srv exists"; exit 2; fi
mkdir -p "$OUT" "$W/logs" "$P"
note() { echo "$(date -u +%FT%T.%3NZ) $*" | tee -a "$OUT/driver.log"; }
cleanup() {
  if docker ps -a --format '{{.Names}}' | grep -qx cm259-srv; then
    docker stop -t 30 cm259-srv > /dev/null 2>&1 || true
    docker logs cm259-srv > "$OUT/container.log" 2>&1 || true
    docker rm cm259-srv > /dev/null 2>&1 || true
    echo "$(date -u +%FT%T.%3NZ) cleanup stopped cm259-srv" >> "$OUT/driver.log"
  fi
}
trap cleanup EXIT
cp -r "$H/fixtures/default/db" "$W/db"; cp -r "$H/fixtures/default/storage" "$W/files"
sqlite3 "$W/db/production.sqlite3" "UPDATE push_subscriptions SET endpoint = 'https://127.0.0.1:9/push/' || id; UPDATE webhooks SET url = 'http://127.0.0.1:9/hook/' || id;"
LJ() { ruby -rjson -e 'print JSON.parse(File.read(ARGV[0]))[ARGV[1]]' "$H/fixtures/default/labels.json" "$1"; }
ROOM=$(LJ rooms.watercooler); EMAIL=$(LJ emails.david); PASS=$(LJ passwords.all)
# CACHE=off: no response/fragment caching in the reference (report 259 no-cache comparison).
CACHE_ARGS=()
if [ "${CACHE:-on}" = off ]; then
  case "$APP" in
    rust) CACHE_ARGS=(-e CAMPFIRE_RESPONSE_CACHE_MB=0 -e CAMPFIRE_FRAGMENT_CACHE_MB=0) ;;
    rails) CACHE_ARGS=(-v "$M/no-cache-initializer.rb:/rails/config/initializers/zz_benchmark_no_cache.rb:ro") ;;
  esac
fi
docker run -d --name cm259-srv --cpuset-cpus 8-11 -p 127.0.0.1:13774:13774 --env-file "$H/fixtures/default/reference.env" \
  -e WEB_CONCURRENCY=3 -e JOB_CONCURRENCY=3 -e RAILS_MAX_THREADS=5 -e RAILS_LOG_LEVEL=warn -e HTTP_PORT=13774 -e TARGET_PORT=13775 \
  "${CACHE_ARGS[@]}" -v "$W/db:/rails/storage/db" -v "$W/files:/rails/storage/files" -v "$W/logs:/rails/storage/logs" "$IMAGE" > /dev/null
for i in $(seq 1 900); do curl -fsS -o /dev/null http://127.0.0.1:13774/up 2>/dev/null && break; sleep 0.1; done
curl -fsS -o /dev/null http://127.0.0.1:13774/up
docker exec --user root cm259-srv chmod -R a+rwX /rails/storage/db
note "ready app=$APP cache=${CACHE:-on} image=$(docker image inspect -f '{{.Id}}' "$IMAGE")"
sleep 3
LG() { local tag=$1; shift
  docker run --rm --network container:cm259-srv --cpuset-cpus 12-15 -v "$HOME/cm258/loadgen-linux/release/loadgen:/lg:ro" \
    -v "$M/contracts-preflight-1:/c:ro" -v "$OUT:/o" docker.io/library/rust:1.98.1 \
    sh -c '/lg "$@"; rc=$?; cat /sys/fs/cgroup/cpu.stat > /o/client-cpu-'"$tag"'.txt; exit $rc' lg "$@"; }
COOKIE=$(LG login login --base http://127.0.0.1:13774 --email "$EMAIL" --password "$PASS" | ruby -rjson -e 'print JSON.parse(STDIN.read)["cookie"]')
CSS=$(LG scrape scrape --base http://127.0.0.1:13774 --cookie "$COOKIE" --room "$ROOM" | ruby -rjson -e 'print JSON.parse(STDIN.read)["css"]')
ruby "$H/bench/contracts.rb" http://127.0.0.1:13774 "$COOKIE" "$W/db/production.sqlite3" "$H/fixtures/default/labels.json" "$CSS" "$P/contracts" > /dev/null 2> "$OUT/contracts.err.log" || true
ruby -rjson -e 'a=JSON.parse(File.read(ARGV[0])); b=JSON.parse(File.read(ARGV[1])); ok = a["message_ids"]==b["message_ids"] && a["message_content"]==b["message_content"]; puts "own room_show contract matches canonical ids+content: #{ok} required_equal=#{a["required"]==b["required"]}"; exit(ok ? 0 : 1)' "$P/contracts/room_show.json" "$M/contracts-preflight-1/room_show.json" | tee -a "$OUT/driver.log"
for n in 1 2; do LG fetch$n fetch --base http://127.0.0.1:13774 --cookie "$COOKIE" --path "/rooms/$ROOM" --out "/o/body$n.tmp" > /dev/null; done
B1=$(sha256sum "$OUT/body1.tmp" | cut -c1-64); B2=$(sha256sum "$OUT/body2.tmp" | cut -c1-64)
note "decoded_bytes=$(stat -c %s "$OUT/body1.tmp") body_constant=$([ "$B1" = "$B2" ] && echo yes || echo no)"
mv "$OUT/body1.tmp" "$P/body1.html"; mv "$OUT/body2.tmp" "$P/body2.html"
srvcpu() { docker exec cm259-srv cat /sys/fs/cgroup/cpu.stat | awk '$1=="usage_usec"{print $2}'; }
if [ "$APP" = rails ]; then note "redis_keys_before_warmup=$(docker exec cm259-srv redis-cli dbsize 2>/dev/null || echo n/a)"; fi
LG warm0 http --base http://127.0.0.1:13774 --cookie "$COOKIE" --path "/rooms/$ROOM" --validate /c/room_show.json --conc 4 --duration 2 --gzip 0 > "$OUT/warmup-gzip0.json"
for g in 0 1; do
  S0=$(srvcpu); LG timed$g http --base http://127.0.0.1:13774 --cookie "$COOKIE" --path "/rooms/$ROOM" --validate /c/room_show.json --conc 16 --duration 8 --gzip $g > "$OUT/timed-gzip$g.json"; S1=$(srvcpu)
  echo "server_usage_usec_delta=$((S1-S0))" > "$OUT/server-cpu-gzip$g.txt"
  note "gzip=$g $(cut -c1-400 "$OUT/timed-gzip$g.json") server_usec=$((S1-S0))"
done
if [ "$APP" = rails ]; then note "redis_keys_after=$(docker exec cm259-srv redis-cli dbsize 2>/dev/null || echo n/a)"; fi
docker stop -t 30 cm259-srv > /dev/null; docker logs cm259-srv > "$OUT/container.log" 2>&1; docker rm cm259-srv > /dev/null
grep -ciE 'session_token=|_campfire_session=|password|secret_key' "$OUT/container.log" > "$OUT/container-log-secret-scan.txt" || true
note "stopped"

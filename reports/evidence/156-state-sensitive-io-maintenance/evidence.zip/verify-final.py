from pathlib import Path
import hashlib, json, subprocess

root = Path.cwd()
base = root / '.agentlang/io-maintenance-156'
dispatch = base / 'dispatch-001'
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
manifest = json.loads((dispatch / 'manifest.json').read_text(encoding='utf-8'))
for item in manifest['artifacts']:
    assert digest(dispatch / item['path']) == item['sha256'], item
for item in manifest['oracle']:
    assert digest(base / item['path']) == item['sha256'], item
frozen = dispatch / 'seeds/conventional'
actor = base / 'actors/conventional'
frozen_files = ['Domain.fs', 'Publisher.fs', 'Program.fs', 'AgentLang.IoMaintenance156.Conventional.fsproj']
assert all(digest(frozen / name) == digest(actor / name) for name in frozen_files)
original_tests = (frozen / 'SelfTests.fs').read_text(encoding='utf-8')
actual_tests = (actor / 'SelfTests.fs').read_text(encoding='utf-8')
original_prefix = original_tests.split('    let run () =')[0]
# The actor inserts new tests ahead of the existing refresh test; preserve every
# original test body, not merely its name in the runner.
blocks = original_prefix.split('    let ')
for block in blocks[1:]:
    assert ('    let ' + block).rstrip() in actual_tests, block.splitlines()[0]

requests = [{'op': 'test-all'}, *[{'op':'describe','word':name} for name in
            ['configuration.publish','configuration.refresh','configuration.publish-safely']], {'op':'task.status'}]
copy = base / 'scoring/flow-verification'
assert not copy.exists()
import shutil
shutil.copytree(base / 'actors/flow', copy)
proc = subprocess.run(['dotnet', str(dispatch / 'runtime/flow/AgentLang.Cli.dll'), '--project', str(copy), '--allow','fs.read,fs.write','--jsonl'], input=''.join(json.dumps(r)+'\n' for r in requests), capture_output=True, text=True, encoding='utf-8')
rows = [json.loads(line) for line in proc.stdout.splitlines() if line]
(base / 'scoring/flow-final-verification.json').write_text(json.dumps(rows, indent=2), encoding='utf-8')
assert proc.returncode == 0 and len(rows) == len(requests) and all(row['ok'] for row in rows), proc.stderr
assert len(rows[0]['data']['results']) == 11 and all(r['passed'] for r in rows[0]['data']['results'])
for row, expected_count in zip(rows[1:4], [3,1,7]):
    assert row['data']['maturity'] == 'library'
    assert row['data']['revision'] == 1
    assert row['data']['testCount'] == expected_count
summary = {'frozenArtifactsVerified':len(manifest['artifacts']), 'frozenOracleArtifactsVerified':len(manifest['oracle']), 'conventionalFrozenFilesUnchanged':frozen_files, 'conventionalBaselineBodiesPreserved':True, 'languageOwnTestsPassed':11, 'libraryFunctions':3, 'newFunctionReusesPublisher':False, 'conventionalReusesPublisher':'Configuration.publish' in (actor/'Operations.fs').read_text(encoding='utf-8')}
(base / 'final-verification.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(summary))

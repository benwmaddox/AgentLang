#!/usr/bin/env python3
"""Run the frozen IO-maintenance scenarios against a fixture assembly."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path
from typing import Any


def load_cases(path: Path) -> list[dict[str, Any]]:
    document = json.loads(path.read_text(encoding="utf-8"))
    if document.get("schema_version") != 1:
        raise ValueError("Unsupported case file schema_version")
    cases = document.get("cases")
    if not isinstance(cases, list) or not cases:
        raise ValueError("Case file must contain a non-empty 'cases' array")

    seen: set[str] = set()
    for case in cases:
        case_id = case.get("id")
        scenario = case.get("input")
        expected = case.get("expected")
        if not isinstance(case_id, str) or not case_id:
            raise ValueError("Each case must have a non-empty string id")
        if case_id in seen:
            raise ValueError(f"Duplicate case id: {case_id}")
        seen.add(case_id)
        if not isinstance(scenario, dict) or not isinstance(expected, dict):
            raise ValueError(f"Case {case_id} must have object input and expected values")

        source = scenario.get("source")
        destination = scenario.get("destination")
        files = scenario.get("files")
        if not isinstance(source, str) or not isinstance(destination, str):
            raise ValueError(f"Case {case_id} must have string source and destination paths")
        if source == destination:
            raise ValueError(f"Case {case_id} violates the distinct source/destination contract")
        if not isinstance(files, dict) or source not in files or not isinstance(files[source], str):
            raise ValueError(f"Case {case_id} must start with an existing string-valued source file")
        if any(not isinstance(key, str) or not isinstance(value, str) for key, value in files.items()):
            raise ValueError(f"Case {case_id} file paths and contents must be strings")

        outcome_fields = {"outcomes", "files", "reads", "writes", "error"}
        if set(expected) != outcome_fields:
            raise ValueError(f"Case {case_id} expected result must have exactly {sorted(outcome_fields)}")

    return cases


def compare(expected: dict[str, Any], actual: dict[str, Any]) -> list[dict[str, Any]]:
    mismatches: list[dict[str, Any]] = []
    for field in sorted(set(expected) | set(actual)):
        if field not in expected:
            mismatches.append({"field": field, "expected": "<missing>", "actual": actual[field]})
        elif field not in actual:
            mismatches.append({"field": field, "expected": expected[field], "actual": "<missing>"})
        elif expected[field] != actual[field]:
            mismatches.append({"field": field, "expected": expected[field], "actual": actual[field]})
    return mismatches


def run_case(assembly: Path, case: dict[str, Any]) -> dict[str, Any]:
    payload = json.dumps(case["input"], ensure_ascii=True, separators=(",", ":"))
    try:
        completed = subprocess.run(
            ["dotnet", str(assembly), "--scenario"],
            input=payload,
            text=True,
            encoding="utf-8",
            errors="strict",
            capture_output=True,
            check=False,
        )
    except OSError as error:
        return {
            "id": case["id"],
            "passed": False,
            "actual": None,
            "mismatches": [{"field": "execution", "expected": "successful process", "actual": str(error)}],
            "returncode": None,
            "stderr": "",
        }

    actual: Any = None
    parse_error: str | None = None
    try:
        actual = json.loads(completed.stdout)
    except json.JSONDecodeError as error:
        parse_error = f"stdout was not one JSON value: {error}"

    mismatches: list[dict[str, Any]] = []
    if completed.returncode != 0:
        mismatches.append(
            {"field": "returncode", "expected": 0, "actual": completed.returncode}
        )
    if parse_error is not None:
        mismatches.append(
            {"field": "stdout", "expected": "one JSON result", "actual": parse_error}
        )
    elif not isinstance(actual, dict):
        mismatches.append(
            {"field": "result", "expected": "JSON object", "actual": actual}
        )
    else:
        mismatches.extend(compare(case["expected"], actual))

    if completed.stderr:
        mismatches.append(
            {"field": "stderr", "expected": "empty", "actual": completed.stderr.strip()}
        )

    return {
        "id": case["id"],
        "passed": not mismatches,
        "actual": actual,
        "mismatches": mismatches,
        "returncode": completed.returncode,
        "stderr": completed.stderr,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("assembly", type=Path, help="path to fixture DLL")
    parser.add_argument(
        "--cases",
        type=Path,
        default=Path(__file__).with_name("cases.json"),
        help="frozen case JSON (defaults to sibling cases.json)",
    )
    args = parser.parse_args()

    if not args.assembly.is_file():
        parser.error(f"assembly does not exist: {args.assembly}")
    cases = load_cases(args.cases)
    results = [run_case(args.assembly.resolve(), case) for case in cases]
    summary = {
        "passed": all(result["passed"] for result in results),
        "case_count": len(results),
        "passed_count": sum(result["passed"] for result in results),
        "results": results,
    }
    print(json.dumps(summary, ensure_ascii=True, separators=(",", ":")))
    return 0 if summary["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())

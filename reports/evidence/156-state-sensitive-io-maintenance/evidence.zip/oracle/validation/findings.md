# IO maintenance 156 oracle validation

- Frozen cases: 9; case file SHA-256: `c31b6c3437ce5525aa00c9b45393e55b163cded7f470113253bd8decf2861c82`.
- Positive control: passed (9/9 cases).
- Mutants rejected: 3/3.
- Conventional fixture source files unchanged: True.
- Full machine-readable evidence: `validation/20261009T133405Z-b5d81dac/evidence.json`.

- `mutant_conflict_overwrite`: rejected; safe_existing_different_crlf (files/writes), safe_existing_different_empty_source (files/writes).
- `mutant_unnecessary_unchanged_write`: rejected; safe_existing_identical_crlf (writes), safe_existing_identical_empty (writes), safe_repeat_absent (writes).
- `mutant_wrong_returned_outcome`: rejected; safe_existing_identical_crlf (outcomes), safe_existing_identical_empty (outcomes), safe_repeat_absent (outcomes).

namespace AgentLang.SubagentTrials.IoMaintenance156.Fixture

module ConfigurationOperations =
    let publishSafely (files: VirtualFiles, source: string, destination: string) : PublishOutcome =
        if not (files.Exists(destination)) then
            let contents = files.Read(source)
            files.Write(destination, contents)
            Created
        else
            let destinationContents = files.Read(destination)
            let sourceContents = files.Read(source)
            if destinationContents = sourceContents then
                Unchanged
            else
                files.Write(destination, sourceContents)
                Conflict

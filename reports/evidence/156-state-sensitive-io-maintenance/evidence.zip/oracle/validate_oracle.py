#!/usr/bin/env python3
"""Build a private control and mutation-check the frozen scenario oracle."""

from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]
FIXTURE = REPO / "experiments" / "AgentLang.SubagentTrials" / "io-maintenance-156" / "fixtures" / "conventional"
PYTHON = Path(r"C:\Users\Ben\AppData\Local\Programs\Python\Python312\python.exe")
RUNNER = HERE / "oracle_runner.py"
CASES = HERE / "cases.json"
PROJECT_NAME = "AgentLang.IoMaintenance156.Conventional.fsproj"
ASSEMBLY_NAME = "AgentLang.IoMaintenance156.Conventional.dll"


IMPLEMENTATIONS = {
    "positive_control": """namespace AgentLang.SubagentTrials.IoMaintenance156.Fixture

module ConfigurationOperations =
    let publishSafely (files: VirtualFiles, source: string, destination: string) : PublishOutcome =
        if not (files.Exists(destination)) then
            let contents = files.Read(source)
            files.Write(destination, contents)
            Created
        else
            let destinationContents = files.Read(destination)
            let sourceContents = files.Read(source)
            if destinationContents = sourceContents then Unchanged else Conflict
""",
    "mutant_conflict_overwrite": """namespace AgentLang.SubagentTrials.IoMaintenance156.Fixture

module ConfigurationOperations =
    let publishSafely (files: VirtualFiles, source: string, destination: string) : PublishOutcome =
        if not (files.Exists(destination)) then
            let contents = files.Read(source)
            files.Write(destination, contents)
            Created
        else
            let destinationContents = files.Read(destination)
            let sourceContents = files.Read(source)
            if destinationContents = sourceContents then
                Unchanged
            else
                files.Write(destination, sourceContents)
                Conflict
""",
    "mutant_unnecessary_unchanged_write": """namespace AgentLang.SubagentTrials.IoMaintenance156.Fixture

module ConfigurationOperations =
    let publishSafely (files: VirtualFiles, source: string, destination: string) : PublishOutcome =
        if not (files.Exists(destination)) then
            let contents = files.Read(source)
            files.Write(destination, contents)
            Created
        else
            let destinationContents = files.Read(destination)
            let sourceContents = files.Read(source)
            if destinationContents = sourceContents then
                files.Write(destination, sourceContents)
                Unchanged
            else
                Conflict
""",
    "mutant_wrong_returned_outcome": """namespace AgentLang.SubagentTrials.IoMaintenance156.Fixture

module ConfigurationOperations =
    let publishSafely (files: VirtualFiles, source: string, destination: string) : PublishOutcome =
        if not (files.Exists(destination)) then
            let contents = files.Read(source)
            files.Write(destination, contents)
            Created
        else
            let destinationContents = files.Read(destination)
            let sourceContents = files.Read(source)
            if destinationContents = sourceContents then Created else Conflict
""",
}

MUTANT_TARGETS = {
    "mutant_conflict_overwrite": {
        "safe_existing_different_crlf": {"files", "writes"},
        "safe_existing_different_empty_source": {"files", "writes"},
    },
    "mutant_unnecessary_unchanged_write": {
        "safe_existing_identical_crlf": {"writes"},
        "safe_existing_identical_empty": {"writes"},
        "safe_repeat_absent": {"writes"},
    },
    "mutant_wrong_returned_outcome": {
        "safe_existing_identical_crlf": {"outcomes"},
        "safe_existing_identical_empty": {"outcomes"},
        "safe_repeat_absent": {"outcomes"},
    },
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def run(command: list[str], cwd: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        cwd=cwd,
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=True,
        check=False,
    )


def main() -> int:
    if not FIXTURE.is_dir():
        raise SystemExit(f"Fixture directory not found: {FIXTURE}")
    if not PYTHON.is_file():
        raise SystemExit(f"Required Python executable not found: {PYTHON}")

    source_files = sorted([*FIXTURE.glob("*.fs"), *FIXTURE.glob("*.fsproj")])
    if not source_files:
        raise SystemExit(f"No F# sources found in fixture: {FIXTURE}")
    fixture_hashes_before = {path.name: sha256(path) for path in source_files}

    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:8]
    validation_root = HERE / "validation"
    run_root = validation_root / run_id
    run_root.mkdir(parents=True, exist_ok=False)

    dotnet_version_result = run(["dotnet", "--version"], REPO)
    evidence: dict[str, Any] = {
        "schema_version": 1,
        "run_id": run_id,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "oracle_case_sha256": sha256(CASES),
        "fixture_source_hashes_before": fixture_hashes_before,
        "python_executable": str(PYTHON),
        "python_version": run([str(PYTHON), "--version"], REPO).stdout.strip(),
        "dotnet_version": dotnet_version_result.stdout.strip(),
        "dotnet_version_exit_code": dotnet_version_result.returncode,
        "variants": [],
    }

    overall_ok = dotnet_version_result.returncode == 0
    for variant_name, operations_source in IMPLEMENTATIONS.items():
        variant_root = run_root / variant_name
        variant_root.mkdir(parents=True)
        for source_file in source_files:
            shutil.copy2(source_file, variant_root / source_file.name)
        (variant_root / "Operations.fs").write_text(operations_source, encoding="utf-8")

        build_command = [
            "dotnet",
            "build",
            str(variant_root / PROJECT_NAME),
            "--configuration",
            "Release",
            "-m:1",
            "-p:NuGetAudit=false",
            "-t:Rebuild",
            "--nologo",
        ]
        build_result = run(build_command, variant_root)
        build_stdout_path = variant_root / "build.stdout.txt"
        build_stderr_path = variant_root / "build.stderr.txt"
        build_stdout_path.write_text(build_result.stdout, encoding="utf-8")
        build_stderr_path.write_text(build_result.stderr, encoding="utf-8")

        variant_record: dict[str, Any] = {
            "name": variant_name,
            "build_command": build_command,
            "build_exit_code": build_result.returncode,
            "build_stdout_file": str(build_stdout_path.relative_to(run_root)),
            "build_stderr_file": str(build_stderr_path.relative_to(run_root)),
            "runner_exit_code": None,
            "runner_stdout_file": None,
            "runner_stderr_file": None,
            "runner_summary": None,
            "expected_detection": "pass_all" if variant_name == "positive_control" else "reject_mutation",
            "accepted": False,
        }
        if build_result.returncode == 0:
            assembly = variant_root / "bin" / "Release" / "net9.0" / ASSEMBLY_NAME
            runner_command = [str(PYTHON), str(RUNNER), str(assembly), "--cases", str(CASES)]
            runner_result = run(runner_command, HERE)
            stdout_path = variant_root / "oracle.stdout.json"
            stderr_path = variant_root / "oracle.stderr.txt"
            stdout_path.write_text(runner_result.stdout, encoding="utf-8")
            stderr_path.write_text(runner_result.stderr, encoding="utf-8")
            try:
                runner_summary = json.loads(runner_result.stdout)
            except json.JSONDecodeError as error:
                runner_summary = {"parse_error": str(error), "stdout": runner_result.stdout}
            variant_record.update(
                {
                    "runner_command": runner_command,
                    "runner_exit_code": runner_result.returncode,
                    "runner_stdout_file": str(stdout_path.relative_to(run_root)),
                    "runner_stderr_file": str(stderr_path.relative_to(run_root)),
                    "runner_summary": runner_summary,
                }
            )

            if variant_name == "positive_control":
                accepted = (
                    runner_result.returncode == 0
                    and runner_summary.get("passed") is True
                    and runner_summary.get("case_count") == 9
                    and runner_summary.get("passed_count") == 9
                )
            else:
                expected_targets = MUTANT_TARGETS[variant_name]
                results = {
                    result.get("id"): result
                    for result in runner_summary.get("results", [])
                    if isinstance(result, dict)
                }
                observed_targets = {
                    case_id: {item.get("field") for item in results.get(case_id, {}).get("mismatches", [])}
                    for case_id in results
                    if not results[case_id].get("passed")
                }
                accepted = (
                    runner_result.returncode == 1
                    and runner_summary.get("passed") is False
                    and observed_targets == expected_targets
                )
                variant_record["expected_mutant_mismatches"] = {
                    case_id: sorted(fields) for case_id, fields in expected_targets.items()
                }
                variant_record["observed_mutant_mismatches"] = {
                    case_id: sorted(fields) for case_id, fields in observed_targets.items()
                }
        else:
            accepted = False

        variant_record["accepted"] = accepted
        overall_ok = overall_ok and accepted
        evidence["variants"].append(variant_record)

    fixture_hashes_after = {path.name: sha256(path) for path in source_files}
    evidence["fixture_source_hashes_after"] = fixture_hashes_after
    evidence["fixture_sources_unchanged"] = fixture_hashes_before == fixture_hashes_after
    evidence["overall_passed"] = overall_ok and evidence["fixture_sources_unchanged"]

    write_json(run_root / "evidence.json", evidence)
    write_json(validation_root / "evidence.json", evidence)

    positive = next(item for item in evidence["variants"] if item["name"] == "positive_control")
    mutants = [item for item in evidence["variants"] if item["name"] != "positive_control"]
    findings = [
        "# IO maintenance 156 oracle validation",
        "",
        f"- Frozen cases: 9; case file SHA-256: `{evidence['oracle_case_sha256']}`.",
        f"- Positive control: {'passed' if positive['accepted'] else 'FAILED'} ({positive.get('runner_summary', {}).get('passed_count', 0)}/9 cases).",
        f"- Mutants rejected: {sum(item['accepted'] for item in mutants)}/3.",
        f"- Conventional fixture source files unchanged: {evidence['fixture_sources_unchanged']}.",
        f"- Full machine-readable evidence: `validation/{run_id}/evidence.json`.",
        "",
    ]
    for mutant in mutants:
        observed = mutant.get("observed_mutant_mismatches", {})
        details = ", ".join(
            f"{case_id} ({'/'.join(fields)})" for case_id, fields in sorted(observed.items())
        ) or "no expected mismatch observed"
        findings.append(
            f"- `{mutant['name']}`: {'rejected' if mutant['accepted'] else 'NOT REJECTED'}; {details}."
        )
    (validation_root / "findings.md").write_text("\n".join(findings) + "\n", encoding="utf-8")

    print(json.dumps({
        "overall_passed": evidence["overall_passed"],
        "run_id": run_id,
        "evidence": str((validation_root / "evidence.json").resolve()),
        "findings": str((validation_root / "findings.md").resolve()),
        "fixture_sources_unchanged": evidence["fixture_sources_unchanged"],
    }, ensure_ascii=True, separators=(",", ":")))
    return 0 if evidence["overall_passed"] else 1


if __name__ == "__main__":
    sys.exit(main())

from pathlib import Path
import hashlib, json, zipfile

root = Path.cwd()
base = root / '.agentlang/io-maintenance-156'
destination = root / 'reports/evidence/156-state-sensitive-io-maintenance'
destination.mkdir(parents=True, exist_ok=True)
archive = destination / 'evidence.zip'
assert not archive.exists(), 'Do not overwrite published evidence.'
files = []
for path in sorted(base.rglob('*')):
    if not path.is_file():
        continue
    parts = path.relative_to(base).parts
    if any(part in {'bin', 'obj', '__pycache__', '_mechanics', 'runs'} for part in parts):
        continue
    if path.suffix in {'.dll', '.exe', '.pdb'} and parts[:2] != ('dispatch-001', 'runtime'):
        continue
    files.append(path)
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for path in files:
        output.write(path, path.relative_to(base).as_posix())
manifest = {'archive': 'evidence.zip', 'entries': len(files),
            'bytes': archive.stat().st_size,
            'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
            'files': [{'path': path.relative_to(base).as_posix(),
                       'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for path in files]}
(destination / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: value for key, value in manifest.items() if key != 'files'}))

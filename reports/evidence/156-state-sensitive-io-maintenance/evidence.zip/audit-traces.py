import datetime, hashlib, json
from collections import Counter
from pathlib import Path

base = Path.cwd() / '.agentlang/io-maintenance-156'
dispatch = base / 'dispatch-001'
report = {}
for arm in ['flow', 'conventional']:
    path = dispatch / f'trace-{arm}.jsonl'
    rows = [json.loads(line) for line in path.read_text(encoding='utf-8-sig').splitlines() if line]
    start = next(row for row in rows if row['event'] == 'session-start')
    end = next(row for row in rows if row['event'] == 'session-end')
    exchanges = [row for row in rows if row['event'] == 'exchange']
    errors = []
    for row in exchanges:
        response = row.get('response')
        payload = json.loads(response['rawLine']) if response and response.get('rawLine') else None
        if payload and not payload.get('ok', True):
            errors.append({'index': row['index'], 'operation': row['operation'], 'error': payload.get('error'), 'text': payload.get('text')})
    parse_time = lambda value: datetime.datetime.fromisoformat(value)
    report[arm] = {
        'traceSha256': hashlib.sha256(path.read_bytes()).hexdigest(),
        'calls': len(exchanges), 'operations': dict(Counter(row['operation'] for row in exchanges)),
        'errors': errors,
        'requestWireBytes': sum(row.get('request', {}).get('wireUtf8Bytes', 0) for row in exchanges),
        'responseWireBytes': sum((row.get('response') or {}).get('wireUtf8Bytes', 0) for row in exchanges),
        'brokerSeconds': (parse_time(end['finishedUtc']) - parse_time(start['startedUtc'])).total_seconds(),
        'termination': end,
        'llmTokens': None,
    }
    assert end['terminationKind'] == 'host-close' and end['hostExitCode'] == end['runtimeExitCode'] == 0, end
output = base / 'trace-audit.json'
output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))

from pathlib import Path
import json, subprocess

base = Path.cwd() / '.agentlang/io-maintenance-156'
dll = base / 'scoring/conventional/bin/Release/net9.0/AgentLang.IoMaintenance156.Conventional.dll'
own = subprocess.run(['dotnet', str(dll)], capture_output=True, text=True, encoding='utf-8')
(base / 'scoring/conventional-selftests.json').write_text(json.dumps({'exitCode': own.returncode, 'stdout': own.stdout, 'stderr': own.stderr}, indent=2), encoding='utf-8')
assert own.returncode == 0, own.stderr
oracle = subprocess.run(['C:/Users/Ben/AppData/Local/Programs/Python/Python312/python.exe', str(base / 'oracle/oracle_runner.py'), str(dll)], capture_output=True, text=True, encoding='utf-8')
(base / 'scoring/conventional-oracle.json').write_text(oracle.stdout, encoding='utf-8')
(base / 'scoring/conventional-oracle.stderr.txt').write_text(oracle.stderr, encoding='utf-8')
assert oracle.returncode == 0, oracle.stdout + oracle.stderr
result = json.loads(oracle.stdout)
print(json.dumps({'selftestsExitCode': own.returncode, 'casesPassed': result['passed_count'], 'cases': result['case_count']}))

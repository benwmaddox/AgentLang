import argparse
import hashlib
import json
import shutil
import subprocess
import tempfile
from pathlib import Path


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]
CASES_PATH = REPO / ".agentlang" / "io-maintenance-156" / "oracle" / "cases.json"
CLI_DLL = REPO / "src" / "AgentLang.Cli" / "bin" / "Release" / "net9.0" / "AgentLang.Cli.dll"
WORD = "configuration.publish-safely"
TARGETS = (WORD, "configuration.publish", "configuration.refresh")
RECORD_SOURCE = """record Oracle156Observation {
    field outcomes: List<PublishOutcome>
    field unit-result: Unit
    field source: Option<String>
    field destination: Option<String>
    field sentinel: Option<String>
}"""


def flow_string(value):
    escaped = []
    for char in value:
        escaped.append({"\\": "\\\\", '"': '\\"', "\n": "\\n", "\r": "\\r", "\t": "\\t", "\b": "\\b", "\f": "\\f"}.get(char, char))
    return '"' + "".join(escaped) + '"'


def option_expr(value):
    return f"option.some<String>({flow_string(value)})" if value is not None else "option.none<String>()"


def outcome_list(values):
    if not values or values == ["Unit"]:
        return "list.empty<PublishOutcome>()"
    expr = f"list.singleton<PublishOutcome>(PublishOutcome.{values[0].lower()}())"
    for value in values[1:]:
        expr = f"list.append({expr}, PublishOutcome.{value.lower()}())"
    return expr


def test_sources(cases):
    grouped = {word: [] for word in TARGETS}
    for case in cases:
        data = case["input"]
        expected = case["expected"]
        source_path = data["source"]
        destination_path = data["destination"]
        sentinel_path = next(path for path in data["files"] if path not in (source_path, destination_path))
        repeat = data.get("repeat", 1)
        operation = data["operation"]
        owner = WORD if operation == "safe" else f"configuration.{operation}"
        name = case["id"].replace("_", "-")
        lines = [f"test {owner}/oracle156-{name} {{"]
        for path, contents in data["files"].items():
            lines.append(f"    file.write({flow_string(path)}, {flow_string(contents)})")
        results = []
        if operation == "safe":
            for index in range(repeat):
                var = f"outcome-{index + 1}"
                results.append(var)
                lines.append(f"    let {var} = {WORD}({flow_string(source_path)}, {flow_string(destination_path)})")
            actual_outcomes = f"list.singleton<PublishOutcome>({results[0]})"
            for var in results[1:]:
                actual_outcomes = f"list.append({actual_outcomes}, {var})"
            unit_result = "unit"
        else:
            unit_result = f"{operation}-result"
            lines.append(f"    let {unit_result} = {owner}({flow_string(source_path)}, {flow_string(destination_path)})")
            actual_outcomes = "list.empty<PublishOutcome>()"
        for label, path in (("source-state", source_path), ("destination-state", destination_path), ("sentinel-state", sentinel_path)):
            lines.extend([
                f"    let {label} = if file.exists?({flow_string(path)}) {{",
                f"        option.some<String>(file.read({flow_string(path)}))",
                "    } else {",
                "        option.none<String>()",
                "    }",
            ])
        lines.extend([
            "    oracle156Observation.new(",
            f"        outcomes = {actual_outcomes},",
            f"        unit-result = {unit_result},",
            "        source = source-state,",
            "        destination = destination-state,",
            "        sentinel = sentinel-state",
            "    )",
            "    => value oracle156Observation.new(",
            f"        outcomes = {outcome_list(expected['outcomes'])},",
            "        unit-result = unit,",
            f"        source = {option_expr(expected['files'].get(source_path))},",
            f"        destination = {option_expr(expected['files'].get(destination_path))},",
            f"        sentinel = {option_expr(expected['files'].get(sentinel_path))}",
            "    ) effects {",
            f"        fs.read: {expected['reads']}",
            f"        fs.write: {expected['writes']}",
            "    }",
            "}",
            "",
        ])
        grouped[owner].append("\n".join(lines))
    return {owner: "\n\n".join(tests) for owner, tests in grouped.items() if tests}


def main():
    parser = argparse.ArgumentParser(description="Run the independent Flow/2 I/O oracle on a disposable project copy.")
    parser.add_argument("--project-path", required=True, type=Path, help="Project to copy and test; the original is never opened by the CLI.")
    parser.add_argument("--implementation-source", type=Path, help="Optional control function source to prepend to generated cases.")
    parser.add_argument("--cli-dll", type=Path, default=CLI_DLL)
    parser.add_argument("--expect-failure", action="store_true", help="Succeed only when at least one attached oracle test fails.")
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()

    project = args.project_path.resolve()
    if not project.is_dir():
        parser.error("--project-path must be a directory")
    cli = args.cli_dll.resolve()
    cases_bytes = CASES_PATH.read_bytes()
    case_document = json.loads(cases_bytes)
    cases = case_document["cases"]
    tests_by_owner = test_sources(cases)
    (HERE / "tests.agent").write_text(
        RECORD_SOURCE + "\n\n" + "\n\n".join(tests_by_owner.values()) + "\n",
        encoding="utf-8",
    )

    runs = HERE / "runs"
    runs.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="flow-oracle-", dir=runs) as temp:
        disposable = Path(temp) / "project"
        shutil.copytree(project, disposable)
        definitions = [{"op": "define", "source": RECORD_SOURCE, "frontend": "flow", "syntaxVersion": 2}]
        if args.implementation_source:
            definitions.append({"op": "define", "source": args.implementation_source.read_text(encoding="utf-8-sig"), "frontend": "flow", "syntaxVersion": 2})
        definitions.extend(
            {"op": "define", "source": source, "frontend": "flow", "syntaxVersion": 2}
            for source in tests_by_owner.values()
        )
        requests = definitions + [
            {"op": "test", "word": word, "frontend": "flow", "syntaxVersion": 2}
            for word in TARGETS
        ]
        command = ["dotnet", str(cli), "--project", str(disposable), "--allow", "fs.read,fs.write", "--jsonl"]
        completed = subprocess.run(
            command,
            input="".join(json.dumps(request, ensure_ascii=True) + "\n" for request in requests),
            text=True,
            encoding="utf-8",
            capture_output=True,
            check=False,
        )
        responses = [json.loads(line) for line in completed.stdout.splitlines() if line.strip()]

    define_results = responses[:len(definitions)]
    test_results = responses[len(definitions):]
    expected_owners = {
        f"oracle156-{case['id'].replace('_', '-')}": WORD if case["input"]["operation"] == "safe" else f"configuration.{case['input']['operation']}"
        for case in cases
    }
    expected_names = set(expected_owners)
    case_results = {}
    request_errors = []
    duplicate_cases = []
    misrouted_cases = []
    for target, response in zip(TARGETS, test_results):
        if not response or response.get("kind") != "test":
            request_errors.append(response)
            continue
        for result in response.get("data", {}).get("results", []):
            name = result.get("name")
            if name not in expected_names:
                continue
            expected_owner = expected_owners[name]
            if target != expected_owner or result.get("word") != expected_owner:
                misrouted_cases.append({"name": name, "expected_owner": expected_owner, "batch_owner": target, "result_owner": result.get("word")})
                continue
            if name in case_results:
                duplicate_cases.append(name)
                continue
            case_results[name] = result
    case_passes = {name: bool(result.get("passed", result.get("ok", result.get("success", False)))) for name, result in case_results.items()}
    all_cases_seen = len(case_results) == len(expected_names) and not duplicate_cases and not misrouted_cases and not request_errors
    all_cases_pass = all_cases_seen and all(case_passes.values())
    any_case_failed = all_cases_seen and any(not passed for passed in case_passes.values())
    define_ok = len(define_results) == len(definitions) and all(result.get("ok") for result in define_results)
    success = define_ok and (any_case_failed if args.expect_failure else all_cases_pass)
    compact_cases = {}
    for name, result in case_results.items():
        effects = result.get("effectAssertion")
        compact_cases[name] = {
            "word": result.get("word"),
            "passed": bool(result.get("passed", False)),
            "expected": result.get("expected"),
            "actual": result.get("actual"),
            "effects": None if effects is None else {
                "passed": effects.get("passed"),
                "expected": effects.get("expected"),
                "actual": effects.get("actual"),
                "targetInvocationCount": effects.get("targetInvocationCount"),
            },
        }
    compact_definitions = [
        {
            "ok": result.get("ok"),
            "kind": result.get("kind"),
            "text": result.get("text"),
            "name": result.get("data", {}).get("name"),
            "types": result.get("data", {}).get("types"),
            "tests": result.get("data", {}).get("tests"),
        }
        for result in define_results
    ]
    test_batches = [
        {
            "word": word,
            "kind": response.get("kind"),
            "ok": response.get("ok"),
            "text": response.get("text"),
            "result_count": len(response.get("data", {}).get("results", [])),
            "oracle_result_count": sum(
                1 for result in response.get("data", {}).get("results", [])
                if str(result.get("name", "")).startswith("oracle156-")
            ),
        }
        for word, response in zip(TARGETS, test_results)
    ]
    report = {
        "case_sha256": hashlib.sha256(cases_bytes).hexdigest(),
        "case_count": len(cases),
        "target_word": WORD,
        "project_path": str(project),
        "tested_disposable_copy": True,
        "original_project_mutated": False,
        "implementation_source": str(args.implementation_source.resolve()) if args.implementation_source else None,
        "expectation": "failure" if args.expect_failure else "pass",
        "define": compact_definitions,
        "test_batches": test_batches,
        "case_results": compact_cases,
        "case_passes": case_passes,
        "all_cases_seen": all_cases_seen,
        "request_errors": request_errors,
        "duplicate_cases": duplicate_cases,
        "misrouted_cases": misrouted_cases,
        "cli_exit_code": completed.returncode,
        "stderr": completed.stderr,
        "result": "pass" if success and completed.returncode == 0 else "fail",
    }
    if args.report:
        if args.report.exists():
            parser.error(f"report already exists; choose a new path to preserve prior evidence: {args.report}")
        args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=True, indent=2))
    if report["result"] != "pass":
        raise SystemExit(1)


if __name__ == "__main__":
    main()

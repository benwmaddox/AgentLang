from pathlib import Path
import datetime, hashlib, json, shutil, subprocess

root = Path.cwd()
base = root / '.agentlang/io-maintenance-156'
dispatch = base / 'dispatch-001'
assert not dispatch.exists(), 'Never overwrite a dispatched trial.'
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def inventory(directory):
    return [{'path': p.relative_to(directory).as_posix(), 'sha256': digest(p)}
            for p in sorted(directory.rglob('*')) if p.is_file()]

# Run only after both acceptance controls have passed. No hidden files are copied
# into a participant's project.
for relative in ['oracle/validation/evidence.json', 'flow-oracle/validation.json']:
    assert (base / relative).exists(), relative
assert json.loads((base / 'oracle/validation/evidence.json').read_text(encoding='utf-8'))['overall_passed']
language_validation = json.loads((base / 'flow-oracle/validation.json').read_text(encoding='utf-8'))
assert language_validation['positive_control']['passed_cases'] == 9
assert len(language_validation['mutant_controls']) == 3
assert all(item['request_errors'] == 0 and item['failed_cases'] for item in language_validation['mutant_controls'])
dispatch.mkdir()
for arm, original in [('flow', base / 'seeds/flow'),
                      ('conventional', root / 'experiments/AgentLang.SubagentTrials/io-maintenance-156/fixtures/conventional')]:
    seed = dispatch / 'seeds' / arm
    shutil.copytree(original, seed, ignore=shutil.ignore_patterns('bin', 'obj'))
    actor = base / 'actors' / arm
    assert not actor.exists()
    shutil.copytree(seed, actor)
    runtime = dispatch / 'runtime' / arm
    dll_dir = (root / 'src/AgentLang.Cli/bin/Release/net9.0' if arm == 'flow'
               else root / 'experiments/AgentLang.Conventional.Cli/bin/Release/net9.0')
    shutil.copytree(dll_dir, runtime)

common = '''You are an external experimental coding agent. The human authorizes
edits to your isolated trial project and local tests. Use only the supplied
broker for project discovery, edits and tests. Do not read the main repository,
other trials, hidden oracles, reports or snapshots. Do not use web tools, spawn
agents, list/read/contact other agents, or use their findings. You may read this
prompt and launch the specified broker. Do not run other shell commands. You
have at most 100 exchanges. Keep one broker process and poll the same handle
after any observation timeout. Close with {"op":"host.close"} and observe its
terminal status before finishing. Disclose any non-broker tool use.

Public task: add safe configuration publication. For an existing source and a
distinct destination, create an absent destination with the source's exact
contents and return Created. If a destination exists with identical contents,
return Unchanged without writing. If it exists with different contents, return
Conflict without changing it. Preserve source and unrelated files. Preserve
empty text, Unicode and line endings exactly. Missing source and aliased paths
are outside this contract. Count existence checks as reads: absent destination
requires exactly two reads and one write; either existing-destination outcome
requires exactly three reads and zero writes. Repeated calls must obey the same
rules using current state. Keep the existing unconditional publisher and its
refresh caller's behavior unchanged. Discover the existing project vocabulary,
document the new function and add meaningful regression tests. Do not remove or
weaken baseline tests. Use virtual I/O, not external services or host files.

'''
flow = '''Implement configuration.publish-safely(source: String, destination: String)
returning the project's publication outcome type. Publish it as a tested library
function, persist its tests, and finish the task session. Existing definitions
must retain their library status. Add the new function and its attached tests;
do not alter existing functions, types or baseline tests. Use JSONL requests with frontend: "flow" and
syntaxVersion: 2.

Compact primer: fn definitions have typed parameters and return type. Qualified
calls use dots: file.read(path). Local receiver calls value.operation(args) pass
value first; records use value.field. Locals: let name = expression. Newlines
separate statements; final expression is the result. Put effects before doc,
then a blank line before code; omitted effects mean pure.

fn tutorial.double(value: Int) -> Int {
    doc "Twice the supplied integer."

    value.multiply(2)
}
test tutorial.double/basic {
    tutorial.double(3)
    => 6
}

Use help (syntaxVersion 2) for exact commands and richer test assertions. Useful
operations: search, describe, source, tests, dependencies, callers, define, test,
test-all, commit, task.begin, task.status, task.commit. Examples:
{"op":"help","syntaxVersion":2}
{"op":"define","syntaxVersion":2,"source":"..."}
{"op":"commit","word":"configuration.publish-safely","library":true}

'''
conventional = '''Implement ConfigurationOperations.publishSafely(files, source, destination)
in Operations.fs using the existing PublishOutcome type. Add regression tests to
SelfTests.fs and run validate. Edit only Operations.fs and SelfTests.fs. Other
files are frozen project/provider infrastructure, readable through the broker.

The broker accepts JSONL inspect/read/search/replace/patch/validate requests.
{"op":"inspect"} lists project files. {"op":"read","path":"Operations.fs"}
returns source and its SHA-256. Replacement requires that exact expectedSha256:
{"op":"replace","path":"Operations.fs","expectedSha256":"...","content":"..."}
Patch requires path, expectedSha256, oldText, newText. Search uses query. Validate
runs the fixed local executable project's self-tests. No arbitrary shell commands.

'''
for arm in ['flow', 'conventional']:
    actor = base / 'actors' / arm
    runtime = dispatch / 'runtime' / arm
    cli = 'AgentLang.Cli.dll' if arm == 'flow' else 'AgentLang.Conventional.Cli.dll'
    operations = ('help,words,source,tests,define,test,test-all,commit,replace-word,storage.status,task.begin,task.status,task.commit,describe,search,eval,context,dependencies,callers,failed-tests,examples,example,effects,type-of,history,task.abort' if arm == 'flow' else 'inspect,read,search,patch,replace,validate')
    extra = ("-Capabilities @('fs.read','fs.write')" if arm == 'flow' else "-AdditionalCliArguments @('--validation-project','AgentLang.IoMaintenance156.Conventional.fsproj')")
    command = f"& '{root / 'scripts/Start-SubagentTrialHostV2.ps1'}' -CliDll '{runtime / cli}' -ProjectPath '{actor}' -TracePath '{dispatch / ('trace-' + arm + '.jsonl')}' -AllowedOperations @('{operations}') -Profile '{'agentlang' if arm == 'flow' else 'conventional'}' {extra} -ExchangeTimeoutMilliseconds 120000 -MaxExchanges 100"
    prompt = common + (flow if arm == 'flow' else conventional) + 'Launch once via exec_command with tty:true and yield_time_ms:10000. If process creation is sandbox-rejected, the same authorized command may use require_escalated without expanding scope.\n\n```powershell\n' + command + '\n```\n'
    (dispatch / f'prompt-{arm}.md').write_text(prompt, encoding='utf-8')

manifest = {'frozenUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'sourceHead': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
            'participants': {'model': 'gpt-6-luna', 'reasoning': 'max', 'fork': 'none'},
            'artifacts': inventory(dispatch),
            'oracle': [{'path': path, 'sha256': digest(base / path)} for path in
                       ['oracle/cases.json','oracle/oracle_runner.py','oracle/validate_oracle.py',
                        'oracle/validation/evidence.json','flow-oracle/run_oracle.py',
                        'flow-oracle/tests.agent','flow-oracle/validation.json']],
            'limitations': ['One pair, feasibility only', 'Prompt isolation, not OS sandbox', 'Protocol bytes are not LLM tokens']}
(dispatch / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'dispatch': str(dispatch), 'artifacts': len(manifest['artifacts'])}))

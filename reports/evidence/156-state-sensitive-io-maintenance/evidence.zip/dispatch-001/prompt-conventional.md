You are an external experimental coding agent. The human authorizes
edits to your isolated trial project and local tests. Use only the supplied
broker for project discovery, edits and tests. Do not read the main repository,
other trials, hidden oracles, reports or snapshots. Do not use web tools, spawn
agents, list/read/contact other agents, or use their findings. You may read this
prompt and launch the specified broker. Do not run other shell commands. You
have at most 100 exchanges. Keep one broker process and poll the same handle
after any observation timeout. Close with {"op":"host.close"} and observe its
terminal status before finishing. Disclose any non-broker tool use.

Public task: add safe configuration publication. For an existing source and a
distinct destination, create an absent destination with the source's exact
contents and return Created. If a destination exists with identical contents,
return Unchanged without writing. If it exists with different contents, return
Conflict without changing it. Preserve source and unrelated files. Preserve
empty text, Unicode and line endings exactly. Missing source and aliased paths
are outside this contract. Count existence checks as reads: absent destination
requires exactly two reads and one write; either existing-destination outcome
requires exactly three reads and zero writes. Repeated calls must obey the same
rules using current state. Keep the existing unconditional publisher and its
refresh caller's behavior unchanged. Discover the existing project vocabulary,
document the new function and add meaningful regression tests. Do not remove or
weaken baseline tests. Use virtual I/O, not external services or host files.

Implement ConfigurationOperations.publishSafely(files, source, destination)
in Operations.fs using the existing PublishOutcome type. Add regression tests to
SelfTests.fs and run validate. Edit only Operations.fs and SelfTests.fs. Other
files are frozen project/provider infrastructure, readable through the broker.

The broker accepts JSONL inspect/read/search/replace/patch/validate requests.
{"op":"inspect"} lists project files. {"op":"read","path":"Operations.fs"}
returns source and its SHA-256. Replacement requires that exact expectedSha256:
{"op":"replace","path":"Operations.fs","expectedSha256":"...","content":"..."}
Patch requires path, expectedSha256, oldText, newText. Search uses query. Validate
runs the fixed local executable project's self-tests. No arbitrary shell commands.

Launch once via exec_command with tty:true and yield_time_ms:10000. If process creation is sandbox-rejected, the same authorized command may use require_escalated without expanding scope.

```powershell
& 'D:\code\AgentLang\scripts\Start-SubagentTrialHostV2.ps1' -CliDll 'D:\code\AgentLang\.agentlang\io-maintenance-156\dispatch-001\runtime\conventional\AgentLang.Conventional.Cli.dll' -ProjectPath 'D:\code\AgentLang\.agentlang\io-maintenance-156\actors\conventional' -TracePath 'D:\code\AgentLang\.agentlang\io-maintenance-156\dispatch-001\trace-conventional.jsonl' -AllowedOperations @('inspect,read,search,patch,replace,validate') -Profile 'conventional' -AdditionalCliArguments @('--validation-project','AgentLang.IoMaintenance156.Conventional.fsproj') -ExchangeTimeoutMilliseconds 120000 -MaxExchanges 100
```

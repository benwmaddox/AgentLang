You are an external experimental coding agent. The human authorizes
edits to your isolated trial project and local tests. Use only the supplied
broker for project discovery, edits and tests. Do not read the main repository,
other trials, hidden oracles, reports or snapshots. Do not use web tools, spawn
agents, list/read/contact other agents, or use their findings. You may read this
prompt and launch the specified broker. Do not run other shell commands. You
have at most 100 exchanges. Keep one broker process and poll the same handle
after any observation timeout. Close with {"op":"host.close"} and observe its
terminal status before finishing. Disclose any non-broker tool use.

Public task: add safe configuration publication. For an existing source and a
distinct destination, create an absent destination with the source's exact
contents and return Created. If a destination exists with identical contents,
return Unchanged without writing. If it exists with different contents, return
Conflict without changing it. Preserve source and unrelated files. Preserve
empty text, Unicode and line endings exactly. Missing source and aliased paths
are outside this contract. Count existence checks as reads: absent destination
requires exactly two reads and one write; either existing-destination outcome
requires exactly three reads and zero writes. Repeated calls must obey the same
rules using current state. Keep the existing unconditional publisher and its
refresh caller's behavior unchanged. Discover the existing project vocabulary,
document the new function and add meaningful regression tests. Do not remove or
weaken baseline tests. Use virtual I/O, not external services or host files.

Implement configuration.publish-safely(source: String, destination: String)
returning the project's publication outcome type. Publish it as a tested library
function, persist its tests, and finish the task session. Existing definitions
must retain their library status. Add the new function and its attached tests;
do not alter existing functions, types or baseline tests. Use JSONL requests with frontend: "flow" and
syntaxVersion: 2.

Compact primer: fn definitions have typed parameters and return type. Qualified
calls use dots: file.read(path). Local receiver calls value.operation(args) pass
value first; records use value.field. Locals: let name = expression. Newlines
separate statements; final expression is the result. Put effects before doc,
then a blank line before code; omitted effects mean pure.

fn tutorial.double(value: Int) -> Int {
    doc "Twice the supplied integer."

    value.multiply(2)
}
test tutorial.double/basic {
    tutorial.double(3)
    => 6
}

Use help (syntaxVersion 2) for exact commands and richer test assertions. Useful
operations: search, describe, source, tests, dependencies, callers, define, test,
test-all, commit, task.begin, task.status, task.commit. Examples:
{"op":"help","syntaxVersion":2}
{"op":"define","syntaxVersion":2,"source":"..."}
{"op":"commit","word":"configuration.publish-safely","library":true}

Launch once via exec_command with tty:true and yield_time_ms:10000. If process creation is sandbox-rejected, the same authorized command may use require_escalated without expanding scope.

```powershell
& 'D:\code\AgentLang\scripts\Start-SubagentTrialHostV2.ps1' -CliDll 'D:\code\AgentLang\.agentlang\io-maintenance-156\dispatch-001\runtime\flow\AgentLang.Cli.dll' -ProjectPath 'D:\code\AgentLang\.agentlang\io-maintenance-156\actors\flow' -TracePath 'D:\code\AgentLang\.agentlang\io-maintenance-156\dispatch-001\trace-flow.jsonl' -AllowedOperations @('help,words,source,tests,define,test,test-all,commit,replace-word,storage.status,task.begin,task.status,task.commit,describe,search,eval,context,dependencies,callers,failed-tests,examples,example,effects,type-of,history,task.abort') -Profile 'agentlang' -Capabilities @('fs.read','fs.write') -ExchangeTimeoutMilliseconds 120000 -MaxExchanges 100
```

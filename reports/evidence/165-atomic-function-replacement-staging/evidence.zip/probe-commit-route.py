from pathlib import Path
import json
import subprocess

ROOT = Path(__file__).resolve().parent
project = ROOT / 'commit-route-before'
if project.exists():
    raise RuntimeError('Refusing to overwrite existing regression evidence')
project.mkdir()
cli = ROOT / 'pre-route-fix-runtime/AgentLang.Cli.dll'
baseline = '''fn edge.target(value: Int) -> Int { add(value, 1) }
fn edge.caller(value: Int) -> Int { add(value, 10) }
test edge.target/basic { edge.target(1) => 2 }
test edge.caller/basic { edge.caller(1) => 11 }'''
replacement = '''fn edge.target(value: Int) -> Int { add(value, 2) }
fn edge.caller(value: Int) -> Int { edge.target(value) }
test edge.target/basic { edge.target(1) => 3 }
test edge.caller/basic { edge.caller(1) => 99 }'''
requests = [
    {'op': 'define', 'frontend': 'flow', 'syntaxVersion': 2, 'source': baseline},
    {'op': 'commit', 'library': True},
    {'op': 'define', 'frontend': 'flow', 'syntaxVersion': 2, 'replace': True,
     'expectedRevisions': {'edge.target': 1, 'edge.caller': 1}, 'source': replacement},
    {'op': 'test', 'word': 'edge.caller'},
    {'op': 'commit-word', 'word': 'edge.target'},
]
lines = '\n'.join(json.dumps(row) for row in requests) + '\n'
command = ['dotnet', str(cli), '--project', str(project), '--filesystem', 'virtual', '--jsonl']
process = subprocess.run(command, input=lines, text=True, encoding='utf-8', capture_output=True)
(ROOT / 'commit-route-before-requests.jsonl').write_text(lines, encoding='utf-8')
(ROOT / 'commit-route-before-responses.jsonl').write_text(process.stdout, encoding='utf-8')
(ROOT / 'commit-route-before-stderr.txt').write_text(process.stderr, encoding='utf-8')
assert process.returncode == 0, process.stderr
rows = [json.loads(line) for line in process.stdout.splitlines()]
assert len(rows) == 5 and all(row['ok'] for row in rows), rows
assert rows[3]['data']['results'][0]['passed'] is False, rows[3]
assert 'edge.caller/basic' not in rows[4]['data'], rows[4]
reload_requests = [{'op': 'describe', 'word': name} for name in ('edge.target', 'edge.caller')]
reload_lines = '\n'.join(json.dumps(row) for row in reload_requests) + '\n'
reloaded = subprocess.run(command, input=reload_lines, text=True, encoding='utf-8', capture_output=True)
(ROOT / 'commit-route-before-reload.jsonl').write_text(reloaded.stdout, encoding='utf-8')
assert reloaded.returncode == 0, reloaded.stderr
descriptions = [json.loads(line) for line in reloaded.stdout.splitlines()]
assert descriptions[0]['data']['revision'] == 2, descriptions
assert descriptions[1]['data']['revision'] == 1, descriptions
print('Confirmed before fix: commit-word published target revision2, omitted failing newly-dependent caller; reload keeps caller revision1.')

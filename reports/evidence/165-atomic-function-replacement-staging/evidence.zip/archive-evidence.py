"""Archive reviewed milestone evidence without build outputs or temp projects."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
gate = json.loads((ROOT / 'full-validation-final.json').read_text(encoding='utf-8-sig'))
assert gate['passed'] and len(gate['checks']) == 37
assert all(check['exitCode'] == 0 for check in gate['checks'])
DEST = REPO / 'reports/evidence/165-atomic-function-replacement-staging'
if DEST.exists():
    raise RuntimeError('Refusing to overwrite an existing archive')
DEST.mkdir(parents=True)
paths = [path for path in sorted(ROOT.iterdir()) if path.is_file()
         and path.suffix in ('.txt', '.json', '.jsonl', '.py')]
inventory = []
archive = DEST / 'evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for path in paths:
        content = path.read_bytes()
        name = path.name
        output.writestr(name, content)
        inventory.append({'path': name, 'bytes': len(content),
                          'sha256': hashlib.sha256(content).hexdigest()})
with zipfile.ZipFile(archive) as saved:
    assert saved.testzip() is None
    for item in inventory:
        assert hashlib.sha256(saved.read(item['path'])).hexdigest() == item['sha256']
manifest = {'status': 'verified', 'fullGateChecks': len(gate['checks']),
    'description': 'Final full gate, focused validation and retained initial/failed development evidence; binaries and temporary projects excluded.',
    'archive': {'path': archive.name, 'bytes': archive.stat().st_size,
                'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()},
    'files': inventory}
(DEST / 'archive.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
print(json.dumps({'archive': manifest['archive'], 'entries': len(inventory), 'fullGateChecks': 37}))
